package android.support.p001v4.app;

import android.app.Notification;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* renamed from: android.support.v4.app.a */
public interface C0001a extends IInterface {

    /* renamed from: android.support.v4.app.a$a */
    public static abstract class C0002a extends Binder implements C0001a {

        /* renamed from: a */
        public static final /* synthetic */ int f0a = 0;

        /* renamed from: android.support.v4.app.a$a$a */
        private static class C0003a implements C0001a {

            /* renamed from: a */
            private IBinder f1a;

            C0003a(IBinder iBinder) {
                this.f1a = iBinder;
            }

            /* renamed from: H0 */
            public void mo1H0(String str, int i, String str2, Notification notification) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("android.support.v4.app.INotificationSideChannel");
                    obtain.writeString(str);
                    obtain.writeInt(i);
                    obtain.writeString(str2);
                    if (notification != null) {
                        obtain.writeInt(1);
                        notification.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (!this.f1a.transact(1, obtain, (Parcel) null, 1)) {
                        int i2 = C0002a.f0a;
                    }
                } finally {
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.f1a;
            }
        }

        /* renamed from: O0 */
        public static C0001a m3O0(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("android.support.v4.app.INotificationSideChannel");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C0001a)) ? new C0003a(iBinder) : (C0001a) queryLocalInterface;
        }
    }

    /* renamed from: H0 */
    void mo1H0(String str, int i, String str2, Notification notification) throws RemoteException;
}
