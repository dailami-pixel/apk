package android.support.p001v4.media;

import androidx.media.AudioAttributesImplApi21;
import androidx.versionedparcelable.C1389a;

/* renamed from: android.support.v4.media.AudioAttributesImplApi21Parcelizer */
public final class AudioAttributesImplApi21Parcelizer extends androidx.media.AudioAttributesImplApi21Parcelizer {
    public static AudioAttributesImplApi21 read(C1389a aVar) {
        return androidx.media.AudioAttributesImplApi21Parcelizer.read(aVar);
    }

    public static void write(AudioAttributesImplApi21 audioAttributesImplApi21, C1389a aVar) {
        androidx.media.AudioAttributesImplApi21Parcelizer.write(audioAttributesImplApi21, aVar);
    }
}
