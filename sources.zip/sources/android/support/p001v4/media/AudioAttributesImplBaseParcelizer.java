package android.support.p001v4.media;

import androidx.media.AudioAttributesImplBase;
import androidx.versionedparcelable.C1389a;

/* renamed from: android.support.v4.media.AudioAttributesImplBaseParcelizer */
public final class AudioAttributesImplBaseParcelizer extends androidx.media.AudioAttributesImplBaseParcelizer {
    public static AudioAttributesImplBase read(C1389a aVar) {
        return androidx.media.AudioAttributesImplBaseParcelizer.read(aVar);
    }

    public static void write(AudioAttributesImplBase audioAttributesImplBase, C1389a aVar) {
        androidx.media.AudioAttributesImplBaseParcelizer.write(audioAttributesImplBase, aVar);
    }
}
