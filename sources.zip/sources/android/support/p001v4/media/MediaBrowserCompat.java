package android.support.p001v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.media.MediaDescription;
import android.media.browse.MediaBrowser;
import android.os.BadParcelableException;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.p001v4.media.session.C0057b;
import android.support.p001v4.media.session.MediaSessionCompat;
import android.support.p001v4.p002os.ResultReceiver;
import android.text.TextUtils;
import android.util.Log;
import androidx.lifecycle.p006w.C0927a;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import p098d.p112d.C4616a;

/* renamed from: android.support.v4.media.MediaBrowserCompat */
public final class MediaBrowserCompat {

    /* renamed from: a */
    static final boolean f2a = Log.isLoggable("MediaBrowserCompat", 3);

    /* renamed from: b */
    private final C0009c f3b;

    /* renamed from: android.support.v4.media.MediaBrowserCompat$CustomActionResultReceiver */
    private static class CustomActionResultReceiver extends ResultReceiver {
        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void mo6a(int i, Bundle bundle) {
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$ItemReceiver */
    private static class ItemReceiver extends ResultReceiver {
        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void mo6a(int i, Bundle bundle) {
            MediaSessionCompat.m115a(bundle);
            if (i != 0 || bundle == null || !bundle.containsKey("media_item")) {
                throw null;
            }
            Parcelable parcelable = bundle.getParcelable("media_item");
            if (parcelable == null || (parcelable instanceof MediaItem)) {
                MediaItem mediaItem = (MediaItem) parcelable;
                throw null;
            }
            throw null;
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$MediaItem */
    public static class MediaItem implements Parcelable {
        public static final Parcelable.Creator<MediaItem> CREATOR = new C0004a();

        /* renamed from: a */
        private final int f4a;

        /* renamed from: b */
        private final MediaDescriptionCompat f5b;

        /* renamed from: android.support.v4.media.MediaBrowserCompat$MediaItem$a */
        static class C0004a implements Parcelable.Creator<MediaItem> {
            C0004a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new MediaItem(parcel);
            }

            public Object[] newArray(int i) {
                return new MediaItem[i];
            }
        }

        MediaItem(Parcel parcel) {
            this.f4a = parcel.readInt();
            this.f5b = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
        }

        public MediaItem(MediaDescriptionCompat mediaDescriptionCompat, int i) {
            if (mediaDescriptionCompat == null) {
                throw new IllegalArgumentException("description cannot be null");
            } else if (!TextUtils.isEmpty(mediaDescriptionCompat.mo39h())) {
                this.f4a = i;
                this.f5b = mediaDescriptionCompat;
            } else {
                throw new IllegalArgumentException("description must have a non-empty media id");
            }
        }

        /* renamed from: a */
        public static List<MediaItem> m10a(List<?> list) {
            MediaItem mediaItem;
            if (list == null) {
                return null;
            }
            ArrayList arrayList = new ArrayList(list.size());
            for (Object next : list) {
                if (next != null) {
                    MediaBrowser.MediaItem mediaItem2 = (MediaBrowser.MediaItem) next;
                    mediaItem = new MediaItem(MediaDescriptionCompat.m29a(mediaItem2.getDescription()), mediaItem2.getFlags());
                } else {
                    mediaItem = null;
                }
                arrayList.add(mediaItem);
            }
            return arrayList;
        }

        public int describeContents() {
            return 0;
        }

        public String toString() {
            return "MediaItem{" + "mFlags=" + this.f4a + ", mDescription=" + this.f5b + '}';
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f4a);
            ((MediaDescription) this.f5b.mo38g()).writeToParcel(parcel, i);
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$SearchResultReceiver */
    private static class SearchResultReceiver extends ResultReceiver {
        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void mo6a(int i, Bundle bundle) {
            MediaSessionCompat.m115a(bundle);
            if (i != 0 || bundle == null || !bundle.containsKey("search_results")) {
                throw null;
            }
            Parcelable[] parcelableArray = bundle.getParcelableArray("search_results");
            if (parcelableArray != null) {
                ArrayList arrayList = new ArrayList();
                for (Parcelable parcelable : parcelableArray) {
                    arrayList.add((MediaItem) parcelable);
                }
            }
            throw null;
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$a */
    private static class C0005a extends Handler {

        /* renamed from: a */
        private final WeakReference<C0013g> f6a;

        /* renamed from: b */
        private WeakReference<Messenger> f7b;

        C0005a(C0013g gVar) {
            this.f6a = new WeakReference<>(gVar);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo12a(Messenger messenger) {
            this.f7b = new WeakReference<>(messenger);
        }

        public void handleMessage(Message message) {
            WeakReference<Messenger> weakReference = this.f7b;
            if (weakReference != null && weakReference.get() != null && this.f6a.get() != null) {
                Bundle data = message.getData();
                MediaSessionCompat.m115a(data);
                C0013g gVar = (C0013g) this.f6a.get();
                Messenger messenger = (Messenger) this.f7b.get();
                try {
                    int i = message.what;
                    if (i == 1) {
                        Bundle bundle = data.getBundle("data_root_hints");
                        MediaSessionCompat.m115a(bundle);
                        gVar.mo20a(messenger, data.getString("data_media_item_id"), (MediaSessionCompat.Token) data.getParcelable("data_media_session_token"), bundle);
                    } else if (i == 2) {
                        gVar.mo22c(messenger);
                    } else if (i != 3) {
                        Log.w("MediaBrowserCompat", "Unhandled message: " + message + "\n  Client version: " + 1 + "\n  Service version: " + message.arg1);
                    } else {
                        Bundle bundle2 = data.getBundle("data_options");
                        MediaSessionCompat.m115a(bundle2);
                        Bundle bundle3 = data.getBundle("data_notify_children_changed_options");
                        MediaSessionCompat.m115a(bundle3);
                        gVar.mo21b(messenger, data.getString("data_media_item_id"), data.getParcelableArrayList("data_media_item_list"), bundle2, bundle3);
                    }
                } catch (BadParcelableException unused) {
                    Log.e("MediaBrowserCompat", "Could not unparcel the data.");
                    if (message.what == 1) {
                        gVar.mo22c(messenger);
                    }
                }
            }
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$b */
    public static class C0006b {

        /* renamed from: a */
        final MediaBrowser.ConnectionCallback f8a = new C0007a();

        /* renamed from: b */
        C0008b f9b;

        /* renamed from: android.support.v4.media.MediaBrowserCompat$b$a */
        private class C0007a extends MediaBrowser.ConnectionCallback {
            C0007a() {
            }

            public void onConnected() {
                C0008b bVar = C0006b.this.f9b;
                if (bVar != null) {
                    ((C0010d) bVar).mo24e();
                }
                C0006b.this.mo14a();
            }

            public void onConnectionFailed() {
                C0008b bVar = C0006b.this.f9b;
                if (bVar != null) {
                    Objects.requireNonNull((C0010d) bVar);
                }
                C0006b.this.mo15b();
            }

            public void onConnectionSuspended() {
                C0008b bVar = C0006b.this.f9b;
                if (bVar != null) {
                    ((C0010d) bVar).mo25f();
                }
                C0006b.this.mo16c();
            }
        }

        /* renamed from: android.support.v4.media.MediaBrowserCompat$b$b */
        interface C0008b {
        }

        /* renamed from: a */
        public void mo14a() {
            throw null;
        }

        /* renamed from: b */
        public void mo15b() {
            throw null;
        }

        /* renamed from: c */
        public void mo16c() {
            throw null;
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$c */
    interface C0009c {
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$d */
    static class C0010d implements C0009c, C0013g, C0006b.C0008b {

        /* renamed from: a */
        final Context f11a;

        /* renamed from: b */
        protected final MediaBrowser f12b;

        /* renamed from: c */
        protected final Bundle f13c;

        /* renamed from: d */
        protected final C0005a f14d = new C0005a(this);

        /* renamed from: e */
        private final C4616a<String, C0015i> f15e = new C4616a<>();

        /* renamed from: f */
        protected C0014h f16f;

        /* renamed from: g */
        protected Messenger f17g;

        /* renamed from: h */
        private MediaSessionCompat.Token f18h;

        C0010d(Context context, ComponentName componentName, C0006b bVar, Bundle bundle) {
            Bundle bundle2;
            this.f11a = context;
            if (bundle == null) {
                bundle2 = new Bundle();
            }
            this.f13c = bundle2;
            bundle2.putInt("extra_client_version", 1);
            bVar.f9b = this;
            this.f12b = new MediaBrowser(context, componentName, bVar.f8a, bundle2);
        }

        /* renamed from: a */
        public void mo20a(Messenger messenger, String str, MediaSessionCompat.Token token, Bundle bundle) {
        }

        /* renamed from: b */
        public void mo21b(Messenger messenger, String str, List list, Bundle bundle, Bundle bundle2) {
            if (this.f17g == messenger) {
                C0015i orDefault = this.f15e.getOrDefault(str, null);
                if (orDefault != null) {
                    orDefault.mo28a(bundle);
                } else if (MediaBrowserCompat.f2a) {
                    Log.d("MediaBrowserCompat", "onLoadChildren for id that isn't subscribed id=" + str);
                }
            }
        }

        /* renamed from: c */
        public void mo22c(Messenger messenger) {
        }

        /* renamed from: d */
        public MediaSessionCompat.Token mo23d() {
            if (this.f18h == null) {
                this.f18h = MediaSessionCompat.Token.m132a(this.f12b.getSessionToken(), (C0057b) null);
            }
            return this.f18h;
        }

        /* renamed from: e */
        public void mo24e() {
            try {
                Bundle extras = this.f12b.getExtras();
                if (extras != null) {
                    extras.getInt("extra_service_version", 0);
                    IBinder binder = extras.getBinder("extra_messenger");
                    if (binder != null) {
                        this.f16f = new C0014h(binder, this.f13c);
                        Messenger messenger = new Messenger(this.f14d);
                        this.f17g = messenger;
                        this.f14d.mo12a(messenger);
                        try {
                            this.f16f.mo26a(this.f11a, this.f17g);
                        } catch (RemoteException unused) {
                            Log.i("MediaBrowserCompat", "Remote error registering client messenger.");
                        }
                    }
                    C0057b O0 = C0057b.C0058a.m311O0(extras.getBinder("extra_session_binder"));
                    if (O0 != null) {
                        this.f18h = MediaSessionCompat.Token.m132a(this.f12b.getSessionToken(), O0);
                    }
                }
            } catch (IllegalStateException e) {
                Log.e("MediaBrowserCompat", "Unexpected IllegalStateException", e);
            }
        }

        /* renamed from: f */
        public void mo25f() {
            this.f16f = null;
            this.f17g = null;
            this.f18h = null;
            this.f14d.mo12a((Messenger) null);
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$e */
    static class C0011e extends C0010d {
        C0011e(Context context, ComponentName componentName, C0006b bVar, Bundle bundle) {
            super(context, componentName, bVar, bundle);
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$f */
    static class C0012f extends C0011e {
        C0012f(Context context, ComponentName componentName, C0006b bVar, Bundle bundle) {
            super(context, componentName, bVar, bundle);
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$g */
    interface C0013g {
        /* renamed from: a */
        void mo20a(Messenger messenger, String str, MediaSessionCompat.Token token, Bundle bundle);

        /* renamed from: b */
        void mo21b(Messenger messenger, String str, List list, Bundle bundle, Bundle bundle2);

        /* renamed from: c */
        void mo22c(Messenger messenger);
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$h */
    private static class C0014h {

        /* renamed from: a */
        private Messenger f19a;

        /* renamed from: b */
        private Bundle f20b;

        public C0014h(IBinder iBinder, Bundle bundle) {
            this.f19a = new Messenger(iBinder);
            this.f20b = bundle;
        }

        /* renamed from: b */
        private void m25b(int i, Bundle bundle, Messenger messenger) throws RemoteException {
            Message obtain = Message.obtain();
            obtain.what = i;
            obtain.arg1 = 1;
            obtain.setData(bundle);
            obtain.replyTo = messenger;
            this.f19a.send(obtain);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo26a(Context context, Messenger messenger) throws RemoteException {
            Bundle bundle = new Bundle();
            bundle.putString("data_package_name", context.getPackageName());
            bundle.putBundle("data_root_hints", this.f20b);
            m25b(6, bundle, messenger);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: c */
        public void mo27c(Messenger messenger) throws RemoteException {
            m25b(7, (Bundle) null, messenger);
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$i */
    private static class C0015i {

        /* renamed from: a */
        private final List<C0016j> f21a = new ArrayList();

        /* renamed from: b */
        private final List<Bundle> f22b = new ArrayList();

        /* renamed from: a */
        public C0016j mo28a(Bundle bundle) {
            for (int i = 0; i < this.f22b.size(); i++) {
                if (C0927a.m3886a(this.f22b.get(i), bundle)) {
                    return this.f21a.get(i);
                }
            }
            return null;
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$j */
    public static abstract class C0016j {

        /* renamed from: a */
        final IBinder f23a = new Binder();

        /* renamed from: android.support.v4.media.MediaBrowserCompat$j$a */
        private class C0017a extends MediaBrowser.SubscriptionCallback {
            C0017a() {
            }

            public void onChildrenLoaded(String str, List<MediaBrowser.MediaItem> list) {
                Objects.requireNonNull(C0016j.this);
                C0016j jVar = C0016j.this;
                MediaItem.m10a(list);
                Objects.requireNonNull(jVar);
            }

            public void onError(String str) {
                Objects.requireNonNull(C0016j.this);
            }
        }

        /* renamed from: android.support.v4.media.MediaBrowserCompat$j$b */
        private class C0018b extends C0017a {
            C0018b() {
                super();
            }

            public void onChildrenLoaded(String str, List<MediaBrowser.MediaItem> list, Bundle bundle) {
                MediaSessionCompat.m115a(bundle);
                C0016j jVar = C0016j.this;
                MediaItem.m10a(list);
                Objects.requireNonNull(jVar);
            }

            public void onError(String str, Bundle bundle) {
                MediaSessionCompat.m115a(bundle);
                Objects.requireNonNull(C0016j.this);
            }
        }

        public C0016j() {
            if (Build.VERSION.SDK_INT >= 26) {
                new C0018b();
            } else {
                new C0017a();
            }
        }
    }

    public MediaBrowserCompat(Context context, ComponentName componentName, C0006b bVar, Bundle bundle) {
        int i = Build.VERSION.SDK_INT;
        this.f3b = i >= 26 ? new C0012f(context, componentName, bVar, (Bundle) null) : i >= 23 ? new C0011e(context, componentName, bVar, (Bundle) null) : new C0010d(context, componentName, bVar, (Bundle) null);
    }

    /* renamed from: a */
    public void mo3a() {
        Log.d("MediaBrowserCompat", "Connecting to a MediaBrowserService.");
        ((C0010d) this.f3b).f12b.connect();
    }

    /* renamed from: b */
    public void mo4b() {
        Messenger messenger;
        C0010d dVar = (C0010d) this.f3b;
        C0014h hVar = dVar.f16f;
        if (!(hVar == null || (messenger = dVar.f17g) == null)) {
            try {
                hVar.mo27c(messenger);
            } catch (RemoteException unused) {
                Log.i("MediaBrowserCompat", "Remote error unregistering client messenger.");
            }
        }
        dVar.f12b.disconnect();
    }

    /* renamed from: c */
    public MediaSessionCompat.Token mo5c() {
        return ((C0010d) this.f3b).mo23d();
    }
}
