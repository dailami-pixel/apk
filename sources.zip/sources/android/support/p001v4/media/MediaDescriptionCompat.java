package android.support.p001v4.media;

import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: android.support.v4.media.MediaDescriptionCompat */
public final class MediaDescriptionCompat implements Parcelable {
    public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new C0019a();

    /* renamed from: a */
    private final String f26a;

    /* renamed from: b */
    private final CharSequence f27b;

    /* renamed from: c */
    private final CharSequence f28c;

    /* renamed from: d */
    private final CharSequence f29d;

    /* renamed from: e */
    private final Bitmap f30e;

    /* renamed from: f */
    private final Uri f31f;

    /* renamed from: g */
    private final Bundle f32g;

    /* renamed from: h */
    private final Uri f33h;

    /* renamed from: i */
    private Object f34i;

    /* renamed from: android.support.v4.media.MediaDescriptionCompat$a */
    static class C0019a implements Parcelable.Creator<MediaDescriptionCompat> {
        C0019a() {
        }

        public Object createFromParcel(Parcel parcel) {
            return MediaDescriptionCompat.m29a(MediaDescription.CREATOR.createFromParcel(parcel));
        }

        public Object[] newArray(int i) {
            return new MediaDescriptionCompat[i];
        }
    }

    /* renamed from: android.support.v4.media.MediaDescriptionCompat$b */
    public static final class C0020b {

        /* renamed from: a */
        private String f35a;

        /* renamed from: b */
        private CharSequence f36b;

        /* renamed from: c */
        private CharSequence f37c;

        /* renamed from: d */
        private CharSequence f38d;

        /* renamed from: e */
        private Bitmap f39e;

        /* renamed from: f */
        private Uri f40f;

        /* renamed from: g */
        private Bundle f41g;

        /* renamed from: h */
        private Uri f42h;

        /* renamed from: a */
        public MediaDescriptionCompat mo47a() {
            return new MediaDescriptionCompat(this.f35a, this.f36b, this.f37c, this.f38d, this.f39e, this.f40f, this.f41g, this.f42h);
        }

        /* renamed from: b */
        public C0020b mo48b(CharSequence charSequence) {
            this.f38d = charSequence;
            return this;
        }

        /* renamed from: c */
        public C0020b mo49c(Bundle bundle) {
            this.f41g = bundle;
            return this;
        }

        /* renamed from: d */
        public C0020b mo50d(Bitmap bitmap) {
            this.f39e = bitmap;
            return this;
        }

        /* renamed from: e */
        public C0020b mo51e(Uri uri) {
            this.f40f = uri;
            return this;
        }

        /* renamed from: f */
        public C0020b mo52f(String str) {
            this.f35a = str;
            return this;
        }

        /* renamed from: g */
        public C0020b mo53g(Uri uri) {
            this.f42h = uri;
            return this;
        }

        /* renamed from: h */
        public C0020b mo54h(CharSequence charSequence) {
            this.f37c = charSequence;
            return this;
        }

        /* renamed from: i */
        public C0020b mo55i(CharSequence charSequence) {
            this.f36b = charSequence;
            return this;
        }
    }

    MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.f26a = str;
        this.f27b = charSequence;
        this.f28c = charSequence2;
        this.f29d = charSequence3;
        this.f30e = bitmap;
        this.f31f = uri;
        this.f32g = bundle;
        this.f33h = uri2;
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0068  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x006c  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.support.p001v4.media.MediaDescriptionCompat m29a(java.lang.Object r10) {
        /*
            r0 = 0
            if (r10 == 0) goto L_0x007d
            int r1 = android.os.Build.VERSION.SDK_INT
            android.support.v4.media.MediaDescriptionCompat$b r2 = new android.support.v4.media.MediaDescriptionCompat$b
            r2.<init>()
            r3 = r10
            android.media.MediaDescription r3 = (android.media.MediaDescription) r3
            java.lang.String r4 = r3.getMediaId()
            r2.mo52f(r4)
            java.lang.CharSequence r4 = r3.getTitle()
            r2.mo55i(r4)
            java.lang.CharSequence r4 = r3.getSubtitle()
            r2.mo54h(r4)
            java.lang.CharSequence r4 = r3.getDescription()
            r2.mo48b(r4)
            android.graphics.Bitmap r4 = r3.getIconBitmap()
            r2.mo50d(r4)
            android.net.Uri r4 = r3.getIconUri()
            r2.mo51e(r4)
            android.os.Bundle r4 = r3.getExtras()
            java.lang.String r5 = "android.support.v4.media.description.MEDIA_URI"
            if (r4 == 0) goto L_0x0049
            android.support.p001v4.media.session.MediaSessionCompat.m115a(r4)
            android.os.Parcelable r6 = r4.getParcelable(r5)
            android.net.Uri r6 = (android.net.Uri) r6
            goto L_0x004a
        L_0x0049:
            r6 = r0
        L_0x004a:
            if (r6 == 0) goto L_0x0062
            java.lang.String r7 = "android.support.v4.media.description.NULL_BUNDLE_FLAG"
            boolean r8 = r4.containsKey(r7)
            if (r8 == 0) goto L_0x005c
            int r8 = r4.size()
            r9 = 2
            if (r8 != r9) goto L_0x005c
            goto L_0x0063
        L_0x005c:
            r4.remove(r5)
            r4.remove(r7)
        L_0x0062:
            r0 = r4
        L_0x0063:
            r2.mo49c(r0)
            if (r6 == 0) goto L_0x006c
            r2.mo53g(r6)
            goto L_0x0077
        L_0x006c:
            r0 = 23
            if (r1 < r0) goto L_0x0077
            android.net.Uri r0 = r3.getMediaUri()
            r2.mo53g(r0)
        L_0x0077:
            android.support.v4.media.MediaDescriptionCompat r0 = r2.mo47a()
            r0.f34i = r10
        L_0x007d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.media.MediaDescriptionCompat.m29a(java.lang.Object):android.support.v4.media.MediaDescriptionCompat");
    }

    /* renamed from: c */
    public CharSequence mo33c() {
        return this.f29d;
    }

    /* renamed from: d */
    public Bundle mo34d() {
        return this.f32g;
    }

    public int describeContents() {
        return 0;
    }

    /* renamed from: e */
    public Bitmap mo36e() {
        return this.f30e;
    }

    /* renamed from: f */
    public Uri mo37f() {
        return this.f31f;
    }

    /* renamed from: g */
    public Object mo38g() {
        Object obj = this.f34i;
        if (obj != null) {
            return obj;
        }
        int i = Build.VERSION.SDK_INT;
        MediaDescription.Builder builder = new MediaDescription.Builder();
        builder.setMediaId(this.f26a);
        builder.setTitle(this.f27b);
        builder.setSubtitle(this.f28c);
        builder.setDescription(this.f29d);
        builder.setIconBitmap(this.f30e);
        builder.setIconUri(this.f31f);
        Bundle bundle = this.f32g;
        if (i < 23 && this.f33h != null) {
            if (bundle == null) {
                bundle = new Bundle();
                bundle.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
            }
            bundle.putParcelable("android.support.v4.media.description.MEDIA_URI", this.f33h);
        }
        builder.setExtras(bundle);
        if (i >= 23) {
            builder.setMediaUri(this.f33h);
        }
        MediaDescription build = builder.build();
        this.f34i = build;
        return build;
    }

    /* renamed from: h */
    public String mo39h() {
        return this.f26a;
    }

    /* renamed from: i */
    public Uri mo40i() {
        return this.f33h;
    }

    /* renamed from: k */
    public CharSequence mo41k() {
        return this.f28c;
    }

    /* renamed from: l */
    public CharSequence mo42l() {
        return this.f27b;
    }

    public String toString() {
        return this.f27b + ", " + this.f28c + ", " + this.f29d;
    }

    public void writeToParcel(Parcel parcel, int i) {
        ((MediaDescription) mo38g()).writeToParcel(parcel, i);
    }
}
