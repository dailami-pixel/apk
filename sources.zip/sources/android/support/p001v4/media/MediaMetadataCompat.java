package android.support.p001v4.media;

import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.p001v4.media.MediaDescriptionCompat;
import android.support.p001v4.media.session.MediaSessionCompat;
import android.text.TextUtils;
import android.util.Log;
import p098d.p112d.C4616a;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: android.support.v4.media.MediaMetadataCompat */
public final class MediaMetadataCompat implements Parcelable {
    public static final Parcelable.Creator<MediaMetadataCompat> CREATOR = new C0021a();

    /* renamed from: a */
    static final C4616a<String, Integer> f43a;

    /* renamed from: b */
    private static final String[] f44b = {"android.media.metadata.TITLE", "android.media.metadata.ARTIST", "android.media.metadata.ALBUM", "android.media.metadata.ALBUM_ARTIST", "android.media.metadata.WRITER", "android.media.metadata.AUTHOR", "android.media.metadata.COMPOSER"};

    /* renamed from: c */
    private static final String[] f45c = {"android.media.metadata.DISPLAY_ICON", "android.media.metadata.ART", "android.media.metadata.ALBUM_ART"};

    /* renamed from: d */
    private static final String[] f46d = {"android.media.metadata.DISPLAY_ICON_URI", "android.media.metadata.ART_URI", "android.media.metadata.ALBUM_ART_URI"};

    /* renamed from: e */
    final Bundle f47e;

    /* renamed from: f */
    private Object f48f;

    /* renamed from: g */
    private MediaDescriptionCompat f49g;

    /* renamed from: android.support.v4.media.MediaMetadataCompat$a */
    static class C0021a implements Parcelable.Creator<MediaMetadataCompat> {
        C0021a() {
        }

        public Object createFromParcel(Parcel parcel) {
            return new MediaMetadataCompat(parcel);
        }

        public Object[] newArray(int i) {
            return new MediaMetadataCompat[i];
        }
    }

    /* renamed from: android.support.v4.media.MediaMetadataCompat$b */
    public static final class C0022b {

        /* renamed from: a */
        private final Bundle f50a = new Bundle();

        /* renamed from: a */
        public MediaMetadataCompat mo66a() {
            return new MediaMetadataCompat(this.f50a);
        }

        /* renamed from: b */
        public C0022b mo67b(String str, Bitmap bitmap) {
            C4616a<String, Integer> aVar = MediaMetadataCompat.f43a;
            if (!(aVar.mo21452f(str) >= 0) || aVar.getOrDefault(str, null).intValue() == 2) {
                this.f50a.putParcelable(str, bitmap);
                return this;
            }
            throw new IllegalArgumentException(C4924a.m17909x("The ", str, " key cannot be used to put a Bitmap"));
        }

        /* renamed from: c */
        public C0022b mo68c(String str, long j) {
            C4616a<String, Integer> aVar = MediaMetadataCompat.f43a;
            if (!(aVar.mo21452f(str) >= 0) || aVar.getOrDefault(str, null).intValue() == 0) {
                this.f50a.putLong(str, j);
                return this;
            }
            throw new IllegalArgumentException(C4924a.m17909x("The ", str, " key cannot be used to put a long"));
        }

        /* renamed from: d */
        public C0022b mo69d(String str, RatingCompat ratingCompat) {
            C4616a<String, Integer> aVar = MediaMetadataCompat.f43a;
            if (!(aVar.mo21452f(str) >= 0) || aVar.getOrDefault(str, null).intValue() == 3) {
                this.f50a.putParcelable(str, (Parcelable) ratingCompat.mo72c());
                return this;
            }
            throw new IllegalArgumentException(C4924a.m17909x("The ", str, " key cannot be used to put a Rating"));
        }

        /* renamed from: e */
        public C0022b mo70e(String str, String str2) {
            C4616a<String, Integer> aVar = MediaMetadataCompat.f43a;
            if (!(aVar.mo21452f(str) >= 0) || aVar.getOrDefault(str, null).intValue() == 1) {
                this.f50a.putCharSequence(str, str2);
                return this;
            }
            throw new IllegalArgumentException(C4924a.m17909x("The ", str, " key cannot be used to put a String"));
        }

        /* renamed from: f */
        public C0022b mo71f(String str, CharSequence charSequence) {
            C4616a<String, Integer> aVar = MediaMetadataCompat.f43a;
            if (!(aVar.mo21452f(str) >= 0) || aVar.getOrDefault(str, null).intValue() == 1) {
                this.f50a.putCharSequence(str, charSequence);
                return this;
            }
            throw new IllegalArgumentException(C4924a.m17909x("The ", str, " key cannot be used to put a CharSequence"));
        }
    }

    static {
        C4616a<String, Integer> aVar = new C4616a<>();
        f43a = aVar;
        aVar.put("android.media.metadata.TITLE", 1);
        aVar.put("android.media.metadata.ARTIST", 1);
        aVar.put("android.media.metadata.DURATION", 0);
        aVar.put("android.media.metadata.ALBUM", 1);
        aVar.put("android.media.metadata.AUTHOR", 1);
        aVar.put("android.media.metadata.WRITER", 1);
        aVar.put("android.media.metadata.COMPOSER", 1);
        aVar.put("android.media.metadata.COMPILATION", 1);
        aVar.put("android.media.metadata.DATE", 1);
        aVar.put("android.media.metadata.YEAR", 0);
        aVar.put("android.media.metadata.GENRE", 1);
        aVar.put("android.media.metadata.TRACK_NUMBER", 0);
        aVar.put("android.media.metadata.NUM_TRACKS", 0);
        aVar.put("android.media.metadata.DISC_NUMBER", 0);
        aVar.put("android.media.metadata.ALBUM_ARTIST", 1);
        aVar.put("android.media.metadata.ART", 2);
        aVar.put("android.media.metadata.ART_URI", 1);
        aVar.put("android.media.metadata.ALBUM_ART", 2);
        aVar.put("android.media.metadata.ALBUM_ART_URI", 1);
        aVar.put("android.media.metadata.USER_RATING", 3);
        aVar.put("android.media.metadata.RATING", 3);
        aVar.put("android.media.metadata.DISPLAY_TITLE", 1);
        aVar.put("android.media.metadata.DISPLAY_SUBTITLE", 1);
        aVar.put("android.media.metadata.DISPLAY_DESCRIPTION", 1);
        aVar.put("android.media.metadata.DISPLAY_ICON", 2);
        aVar.put("android.media.metadata.DISPLAY_ICON_URI", 1);
        aVar.put("android.media.metadata.MEDIA_ID", 1);
        aVar.put("android.media.metadata.BT_FOLDER_TYPE", 0);
        aVar.put("android.media.metadata.MEDIA_URI", 1);
        aVar.put("android.media.metadata.ADVERTISEMENT", 0);
        aVar.put("android.media.metadata.DOWNLOAD_STATUS", 0);
    }

    MediaMetadataCompat(Bundle bundle) {
        Bundle bundle2 = new Bundle(bundle);
        this.f47e = bundle2;
        MediaSessionCompat.m115a(bundle2);
    }

    MediaMetadataCompat(Parcel parcel) {
        this.f47e = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
    }

    /* renamed from: c */
    public static MediaMetadataCompat m48c(Object obj) {
        if (obj == null) {
            return null;
        }
        Parcel obtain = Parcel.obtain();
        ((MediaMetadata) obj).writeToParcel(obtain, 0);
        obtain.setDataPosition(0);
        MediaMetadataCompat createFromParcel = CREATOR.createFromParcel(obtain);
        obtain.recycle();
        createFromParcel.f48f = obj;
        return createFromParcel;
    }

    /* renamed from: a */
    public boolean mo56a(String str) {
        return this.f47e.containsKey(str);
    }

    /* renamed from: d */
    public MediaDescriptionCompat mo57d() {
        Uri uri;
        Bitmap bitmap;
        Uri uri2;
        MediaDescriptionCompat mediaDescriptionCompat = this.f49g;
        if (mediaDescriptionCompat != null) {
            return mediaDescriptionCompat;
        }
        String g = mo61g("android.media.metadata.MEDIA_ID");
        CharSequence[] charSequenceArr = new CharSequence[3];
        CharSequence charSequence = this.f47e.getCharSequence("android.media.metadata.DISPLAY_TITLE");
        if (TextUtils.isEmpty(charSequence)) {
            int i = 0;
            int i2 = 0;
            while (i < 3) {
                String[] strArr = f44b;
                if (i2 >= strArr.length) {
                    break;
                }
                int i3 = i2 + 1;
                CharSequence h = mo62h(strArr[i2]);
                if (!TextUtils.isEmpty(h)) {
                    charSequenceArr[i] = h;
                    i++;
                }
                i2 = i3;
            }
        } else {
            charSequenceArr[0] = charSequence;
            charSequenceArr[1] = this.f47e.getCharSequence("android.media.metadata.DISPLAY_SUBTITLE");
            charSequenceArr[2] = this.f47e.getCharSequence("android.media.metadata.DISPLAY_DESCRIPTION");
        }
        int i4 = 0;
        while (true) {
            String[] strArr2 = f45c;
            uri = null;
            if (i4 >= strArr2.length) {
                bitmap = null;
                break;
            }
            try {
                bitmap = (Bitmap) this.f47e.getParcelable(strArr2[i4]);
            } catch (Exception e) {
                Log.w("MediaMetadata", "Failed to retrieve a key as Bitmap.", e);
                bitmap = null;
            }
            if (bitmap != null) {
                break;
            }
            i4++;
        }
        int i5 = 0;
        while (true) {
            String[] strArr3 = f46d;
            if (i5 >= strArr3.length) {
                uri2 = null;
                break;
            }
            String g2 = mo61g(strArr3[i5]);
            if (!TextUtils.isEmpty(g2)) {
                uri2 = Uri.parse(g2);
                break;
            }
            i5++;
        }
        String g3 = mo61g("android.media.metadata.MEDIA_URI");
        if (!TextUtils.isEmpty(g3)) {
            uri = Uri.parse(g3);
        }
        MediaDescriptionCompat.C0020b bVar = new MediaDescriptionCompat.C0020b();
        bVar.mo52f(g);
        bVar.mo55i(charSequenceArr[0]);
        bVar.mo54h(charSequenceArr[1]);
        bVar.mo48b(charSequenceArr[2]);
        bVar.mo50d(bitmap);
        bVar.mo51e(uri2);
        bVar.mo53g(uri);
        Bundle bundle = new Bundle();
        if (this.f47e.containsKey("android.media.metadata.BT_FOLDER_TYPE")) {
            bundle.putLong("android.media.extra.BT_FOLDER_TYPE", this.f47e.getLong("android.media.metadata.BT_FOLDER_TYPE", 0));
        }
        if (this.f47e.containsKey("android.media.metadata.DOWNLOAD_STATUS")) {
            bundle.putLong("android.media.extra.DOWNLOAD_STATUS", this.f47e.getLong("android.media.metadata.DOWNLOAD_STATUS", 0));
        }
        if (!bundle.isEmpty()) {
            bVar.mo49c(bundle);
        }
        MediaDescriptionCompat a = bVar.mo47a();
        this.f49g = a;
        return a;
    }

    public int describeContents() {
        return 0;
    }

    /* renamed from: e */
    public long mo59e(String str) {
        return this.f47e.getLong(str, 0);
    }

    /* renamed from: f */
    public Object mo60f() {
        if (this.f48f == null) {
            Parcel obtain = Parcel.obtain();
            obtain.writeBundle(this.f47e);
            obtain.setDataPosition(0);
            this.f48f = MediaMetadata.CREATOR.createFromParcel(obtain);
            obtain.recycle();
        }
        return this.f48f;
    }

    /* renamed from: g */
    public String mo61g(String str) {
        CharSequence charSequence = this.f47e.getCharSequence(str);
        if (charSequence != null) {
            return charSequence.toString();
        }
        return null;
    }

    /* renamed from: h */
    public CharSequence mo62h(String str) {
        return this.f47e.getCharSequence(str);
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeBundle(this.f47e);
    }
}
