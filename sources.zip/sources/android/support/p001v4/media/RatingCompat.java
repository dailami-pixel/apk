package android.support.p001v4.media;

import android.media.Rating;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: android.support.v4.media.RatingCompat */
public final class RatingCompat implements Parcelable {
    public static final Parcelable.Creator<RatingCompat> CREATOR = new C0023a();

    /* renamed from: a */
    private final int f51a;

    /* renamed from: b */
    private final float f52b;

    /* renamed from: c */
    private Object f53c;

    /* renamed from: android.support.v4.media.RatingCompat$a */
    static class C0023a implements Parcelable.Creator<RatingCompat> {
        C0023a() {
        }

        public Object createFromParcel(Parcel parcel) {
            return new RatingCompat(parcel.readInt(), parcel.readFloat());
        }

        public Object[] newArray(int i) {
            return new RatingCompat[i];
        }
    }

    RatingCompat(int i, float f) {
        this.f51a = i;
        this.f52b = f;
    }

    /* renamed from: a */
    public static RatingCompat m61a(Object obj) {
        RatingCompat ratingCompat;
        String str;
        float f;
        RatingCompat ratingCompat2 = null;
        if (obj != null) {
            Rating rating = (Rating) obj;
            int ratingStyle = rating.getRatingStyle();
            if (!rating.isRated()) {
                switch (ratingStyle) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        ratingCompat2 = new RatingCompat(ratingStyle, -1.0f);
                        break;
                }
            } else {
                float f2 = 1.0f;
                switch (ratingStyle) {
                    case 1:
                        if (!rating.hasHeart()) {
                            f2 = 0.0f;
                        }
                        ratingCompat = new RatingCompat(1, f2);
                        break;
                    case 2:
                        if (!rating.isThumbUp()) {
                            f2 = 0.0f;
                        }
                        ratingCompat = new RatingCompat(2, f2);
                        break;
                    case 3:
                    case 4:
                    case 5:
                        float starRating = rating.getStarRating();
                        if (ratingStyle == 3) {
                            f = 3.0f;
                        } else if (ratingStyle == 4) {
                            f = 4.0f;
                        } else if (ratingStyle != 5) {
                            str = C4924a.m17901p("Invalid rating style (", ratingStyle, ") for a star rating");
                            Log.e("Rating", str);
                            break;
                        } else {
                            f = 5.0f;
                        }
                        if (starRating >= 0.0f && starRating <= f) {
                            ratingCompat2 = new RatingCompat(ratingStyle, starRating);
                            break;
                        } else {
                            str = "Trying to set out of range star-based rating";
                            Log.e("Rating", str);
                        }
                        break;
                    case 6:
                        float percentRating = rating.getPercentRating();
                        if (percentRating >= 0.0f && percentRating <= 100.0f) {
                            ratingCompat2 = new RatingCompat(6, percentRating);
                            break;
                        } else {
                            Log.e("Rating", "Invalid percentage-based rating value");
                            break;
                        }
                    default:
                        return null;
                }
                ratingCompat2 = ratingCompat;
            }
            ratingCompat2.f53c = obj;
        }
        return ratingCompat2;
    }

    /* renamed from: c */
    public Object mo72c() {
        Rating rating;
        if (this.f53c == null) {
            if (mo73d()) {
                int i = this.f51a;
                float f = -1.0f;
                boolean z = false;
                switch (i) {
                    case 1:
                        if (i == 1 && this.f52b == 1.0f) {
                            z = true;
                        }
                        rating = Rating.newHeartRating(z);
                        break;
                    case 2:
                        if (i == 2 && this.f52b == 1.0f) {
                            z = true;
                        }
                        rating = Rating.newThumbRating(z);
                        break;
                    case 3:
                    case 4:
                    case 5:
                        if ((i == 3 || i == 4 || i == 5) && mo73d()) {
                            f = this.f52b;
                        }
                        rating = Rating.newStarRating(i, f);
                        break;
                    case 6:
                        if (i == 6 && mo73d()) {
                            f = this.f52b;
                        }
                        rating = Rating.newPercentageRating(f);
                        break;
                    default:
                        return null;
                }
            } else {
                rating = Rating.newUnratedRating(this.f51a);
            }
            this.f53c = rating;
        }
        return this.f53c;
    }

    /* renamed from: d */
    public boolean mo73d() {
        return this.f52b >= 0.0f;
    }

    public int describeContents() {
        return this.f51a;
    }

    public String toString() {
        StringBuilder P = C4924a.m17863P("Rating:style=");
        P.append(this.f51a);
        P.append(" rating=");
        float f = this.f52b;
        P.append(f < 0.0f ? "unrated" : String.valueOf(f));
        return P.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f51a);
        parcel.writeFloat(this.f52b);
    }
}
