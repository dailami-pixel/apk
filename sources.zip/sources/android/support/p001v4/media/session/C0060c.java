package android.support.p001v4.media.session;

/* renamed from: android.support.v4.media.session.c */
public interface C0060c {
}
