package android.support.p001v4.media.session;

import android.media.AudioAttributes;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.support.p001v4.media.session.C0060c;
import android.support.p001v4.media.session.MediaControllerCompat;
import java.util.List;

/* renamed from: android.support.v4.media.session.d */
class C0061d<T extends C0060c> extends MediaController.Callback {

    /* renamed from: a */
    protected final T f135a;

    public C0061d(T t) {
        this.f135a = t;
    }

    public void onAudioInfoChanged(MediaController.PlaybackInfo playbackInfo) {
        int i;
        T t = this.f135a;
        int playbackType = playbackInfo.getPlaybackType();
        AudioAttributes audioAttributes = playbackInfo.getAudioAttributes();
        if ((audioAttributes.getFlags() & 1) == 1) {
            i = 7;
        } else if ((audioAttributes.getFlags() & 4) == 4) {
            i = 6;
        } else {
            int usage = audioAttributes.getUsage();
            if (usage != 13) {
                switch (usage) {
                    case 2:
                        i = 0;
                        break;
                    case 3:
                        i = 8;
                        break;
                    case 4:
                        i = 4;
                        break;
                    case 5:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                        i = 5;
                        break;
                    case 6:
                        i = 2;
                        break;
                    default:
                        i = 3;
                        break;
                }
            } else {
                i = 1;
            }
        }
        ((MediaControllerCompat.C0025a.C0027b) t).mo103a(playbackType, i, playbackInfo.getVolumeControl(), playbackInfo.getMaxVolume(), playbackInfo.getCurrentVolume());
    }

    public void onExtrasChanged(Bundle bundle) {
        MediaSessionCompat.m115a(bundle);
        ((MediaControllerCompat.C0025a.C0027b) this.f135a).mo104b(bundle);
    }

    public void onMetadataChanged(MediaMetadata mediaMetadata) {
        ((MediaControllerCompat.C0025a.C0027b) this.f135a).mo105c(mediaMetadata);
    }

    public void onPlaybackStateChanged(PlaybackState playbackState) {
        ((MediaControllerCompat.C0025a.C0027b) this.f135a).mo106d(playbackState);
    }

    public void onQueueChanged(List<MediaSession.QueueItem> list) {
        ((MediaControllerCompat.C0025a.C0027b) this.f135a).mo107e(list);
    }

    public void onQueueTitleChanged(CharSequence charSequence) {
        ((MediaControllerCompat.C0025a.C0027b) this.f135a).mo108f(charSequence);
    }

    public void onSessionDestroyed() {
        ((MediaControllerCompat.C0025a.C0027b) this.f135a).mo109g();
    }

    public void onSessionEvent(String str, Bundle bundle) {
        MediaSessionCompat.m115a(bundle);
        ((MediaControllerCompat.C0025a.C0027b) this.f135a).mo110h(str, bundle);
    }
}
