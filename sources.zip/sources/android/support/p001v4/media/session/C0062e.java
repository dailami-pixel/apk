package android.support.p001v4.media.session;

import android.media.session.MediaController;

/* renamed from: android.support.v4.media.session.e */
public class C0062e {
    /* renamed from: a */
    public static Object m318a(Object obj) {
        return ((MediaController) obj).getTransportControls();
    }
}
