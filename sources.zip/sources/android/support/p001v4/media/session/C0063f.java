package android.support.p001v4.media.session;

import android.support.p001v4.media.session.MediaSessionCompat;

/* renamed from: android.support.v4.media.session.f */
class C0063f extends MediaSessionCompat.C0040a {
    C0063f(MediaSessionCompat mediaSessionCompat) {
    }
}
