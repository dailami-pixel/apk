package android.support.p001v4.media.session;

import android.support.p001v4.media.session.MediaSessionCompat;

/* renamed from: android.support.v4.media.session.g */
class C0064g extends MediaSessionCompat.C0040a {
    C0064g(MediaSessionCompat mediaSessionCompat) {
    }
}
