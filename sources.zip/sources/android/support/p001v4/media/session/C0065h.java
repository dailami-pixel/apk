package android.support.p001v4.media.session;

import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;

/* renamed from: android.support.v4.media.session.h */
interface C0065h {
    /* renamed from: a */
    void mo184a();

    /* renamed from: b */
    void mo185b();

    /* renamed from: c */
    void mo186c(String str, Bundle bundle, ResultReceiver resultReceiver);

    /* renamed from: d */
    void mo187d(long j);

    /* renamed from: e */
    void mo188e(Object obj);

    /* renamed from: g */
    void mo189g();

    /* renamed from: h */
    boolean mo190h(Intent intent);

    /* renamed from: k */
    void mo191k(String str, Bundle bundle);

    /* renamed from: l */
    void mo192l(String str, Bundle bundle);

    /* renamed from: m */
    void mo193m();

    /* renamed from: n */
    void mo194n(long j);

    /* renamed from: o */
    void mo195o(String str, Bundle bundle);

    void onPause();

    void onPlay();

    void onStop();
}
