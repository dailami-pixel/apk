package android.support.p001v4.media.session;

import android.content.Intent;
import android.media.Rating;
import android.media.session.MediaSession;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.support.p001v4.media.session.C0065h;

/* renamed from: android.support.v4.media.session.i */
class C0066i<T extends C0065h> extends MediaSession.Callback {

    /* renamed from: a */
    protected final T f136a;

    public C0066i(T t) {
        this.f136a = t;
    }

    public void onCommand(String str, Bundle bundle, ResultReceiver resultReceiver) {
        MediaSessionCompat.m115a(bundle);
        this.f136a.mo186c(str, bundle, resultReceiver);
    }

    public void onCustomAction(String str, Bundle bundle) {
        MediaSessionCompat.m115a(bundle);
        this.f136a.mo195o(str, bundle);
    }

    public void onFastForward() {
        this.f136a.mo193m();
    }

    public boolean onMediaButtonEvent(Intent intent) {
        return this.f136a.mo190h(intent) || super.onMediaButtonEvent(intent);
    }

    public void onPause() {
        this.f136a.onPause();
    }

    public void onPlay() {
        this.f136a.onPlay();
    }

    public void onPlayFromMediaId(String str, Bundle bundle) {
        MediaSessionCompat.m115a(bundle);
        this.f136a.mo192l(str, bundle);
    }

    public void onPlayFromSearch(String str, Bundle bundle) {
        MediaSessionCompat.m115a(bundle);
        this.f136a.mo191k(str, bundle);
    }

    public void onRewind() {
        this.f136a.mo185b();
    }

    public void onSeekTo(long j) {
        this.f136a.mo194n(j);
    }

    public void onSetRating(Rating rating) {
        this.f136a.mo188e(rating);
    }

    public void onSkipToNext() {
        this.f136a.mo184a();
    }

    public void onSkipToPrevious() {
        this.f136a.mo189g();
    }

    public void onSkipToQueueItem(long j) {
        this.f136a.mo187d(j);
    }

    public void onStop() {
        this.f136a.onStop();
    }
}
