package android.support.p001v4.media.session;

import android.net.Uri;
import android.os.Bundle;

/* renamed from: android.support.v4.media.session.j */
public interface C0067j extends C0065h {
    /* renamed from: q */
    void mo199q(Uri uri, Bundle bundle);
}
