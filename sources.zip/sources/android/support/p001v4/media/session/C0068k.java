package android.support.p001v4.media.session;

import android.net.Uri;
import android.os.Bundle;
import android.support.p001v4.media.session.C0067j;

/* renamed from: android.support.v4.media.session.k */
class C0068k<T extends C0067j> extends C0066i<T> {
    public C0068k(T t) {
        super(t);
    }

    public void onPlayFromUri(Uri uri, Bundle bundle) {
        MediaSessionCompat.m115a(bundle);
        ((C0067j) this.f136a).mo199q(uri, bundle);
    }
}
