package android.support.p001v4.media.session;

import android.net.Uri;
import android.os.Bundle;

/* renamed from: android.support.v4.media.session.l */
public interface C0069l extends C0067j {
    /* renamed from: f */
    void mo200f(String str, Bundle bundle);

    /* renamed from: i */
    void mo201i();

    /* renamed from: j */
    void mo202j(Uri uri, Bundle bundle);

    /* renamed from: p */
    void mo203p(String str, Bundle bundle);
}
