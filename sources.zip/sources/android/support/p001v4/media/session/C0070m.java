package android.support.p001v4.media.session;

import android.net.Uri;
import android.os.Bundle;
import android.support.p001v4.media.session.C0069l;

/* renamed from: android.support.v4.media.session.m */
class C0070m<T extends C0069l> extends C0068k<T> {
    public C0070m(T t) {
        super(t);
    }

    public void onPrepare() {
        ((C0069l) this.f136a).mo201i();
    }

    public void onPrepareFromMediaId(String str, Bundle bundle) {
        MediaSessionCompat.m115a(bundle);
        ((C0069l) this.f136a).mo200f(str, bundle);
    }

    public void onPrepareFromSearch(String str, Bundle bundle) {
        MediaSessionCompat.m115a(bundle);
        ((C0069l) this.f136a).mo203p(str, bundle);
    }

    public void onPrepareFromUri(Uri uri, Bundle bundle) {
        MediaSessionCompat.m115a(bundle);
        ((C0069l) this.f136a).mo202j(uri, bundle);
    }
}
