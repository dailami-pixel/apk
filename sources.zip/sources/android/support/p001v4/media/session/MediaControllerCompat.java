package android.support.p001v4.media.session;

import android.app.PendingIntent;
import android.content.Context;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.p001v4.media.MediaMetadataCompat;
import android.support.p001v4.media.session.C0054a;
import android.support.p001v4.media.session.C0057b;
import android.support.p001v4.media.session.MediaSessionCompat;
import android.util.Log;
import android.view.KeyEvent;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

/* renamed from: android.support.v4.media.session.MediaControllerCompat */
public final class MediaControllerCompat {

    /* renamed from: a */
    private final C0029b f54a;

    /* renamed from: b */
    private final MediaSessionCompat.Token f55b;

    /* renamed from: c */
    private final HashSet<C0025a> f56c = new HashSet<>();

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21 */
    static class MediaControllerImplApi21 implements C0029b {

        /* renamed from: a */
        protected final Object f57a;

        /* renamed from: b */
        final Object f58b = new Object();

        /* renamed from: c */
        private final List<C0025a> f59c = new ArrayList();

        /* renamed from: d */
        private HashMap<C0025a, C0024a> f60d = new HashMap<>();

        /* renamed from: e */
        final MediaSessionCompat.Token f61e;

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver */
        private static class ExtraBinderRequestResultReceiver extends ResultReceiver {

            /* renamed from: a */
            private WeakReference<MediaControllerImplApi21> f62a;

            ExtraBinderRequestResultReceiver(MediaControllerImplApi21 mediaControllerImplApi21) {
                super((Handler) null);
                this.f62a = new WeakReference<>(mediaControllerImplApi21);
            }

            /* access modifiers changed from: protected */
            public void onReceiveResult(int i, Bundle bundle) {
                MediaControllerImplApi21 mediaControllerImplApi21 = (MediaControllerImplApi21) this.f62a.get();
                if (mediaControllerImplApi21 != null && bundle != null) {
                    synchronized (mediaControllerImplApi21.f58b) {
                        mediaControllerImplApi21.f61e.mo148f(C0057b.C0058a.m311O0(bundle.getBinder("android.support.v4.media.session.EXTRA_BINDER")));
                        mediaControllerImplApi21.f61e.mo149g(bundle.getBundle("android.support.v4.media.session.SESSION_TOKEN2_BUNDLE"));
                        mediaControllerImplApi21.mo88d();
                    }
                }
            }
        }

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21$a */
        private static class C0024a extends C0025a.C0028c {
            C0024a(C0025a aVar) {
                super(aVar);
            }

            /* renamed from: A */
            public void mo90A(List<MediaSessionCompat.QueueItem> list) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: N0 */
            public void mo91N0(ParcelableVolumeInfo parcelableVolumeInfo) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: a0 */
            public void mo92a0(CharSequence charSequence) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: d0 */
            public void mo93d0() throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: f0 */
            public void mo94f0(MediaMetadataCompat mediaMetadataCompat) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: x */
            public void mo95x(Bundle bundle) throws RemoteException {
                throw new AssertionError();
            }
        }

        public MediaControllerImplApi21(Context context, MediaSessionCompat.Token token) throws RemoteException {
            this.f61e = token;
            MediaController mediaController = new MediaController(context, (MediaSession.Token) token.mo146e());
            this.f57a = mediaController;
            if (mediaController == null) {
                throw new RemoteException();
            } else if (token.mo143c() == null) {
                mediaController.sendCommand("android.support.v4.media.session.command.GET_EXTRA_BINDER", (Bundle) null, new ExtraBinderRequestResultReceiver(this));
            }
        }

        /* renamed from: a */
        public final void mo85a(C0025a aVar) {
            ((MediaController) this.f57a).unregisterCallback((MediaController.Callback) aVar.f63a);
            synchronized (this.f58b) {
                if (this.f61e.mo143c() != null) {
                    try {
                        C0024a remove = this.f60d.remove(aVar);
                        if (remove != null) {
                            aVar.f65c = null;
                            this.f61e.mo143c().mo225F(remove);
                        }
                    } catch (RemoteException e) {
                        Log.e("MediaControllerCompat", "Dead object in unregisterCallback.", e);
                    }
                } else {
                    this.f59c.remove(aVar);
                }
            }
        }

        /* renamed from: b */
        public PendingIntent mo86b() {
            return ((MediaController) this.f57a).getSessionActivity();
        }

        /* renamed from: c */
        public C0033f mo87c() {
            Object a = C0062e.m318a(this.f57a);
            if (a != null) {
                return new C0034g(a);
            }
            return null;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: d */
        public void mo88d() {
            if (this.f61e.mo143c() != null) {
                for (C0025a next : this.f59c) {
                    C0024a aVar = new C0024a(next);
                    this.f60d.put(next, aVar);
                    next.f65c = aVar;
                    try {
                        this.f61e.mo143c().mo237f(aVar);
                        next.mo100d(13, (Object) null, (Bundle) null);
                    } catch (RemoteException e) {
                        Log.e("MediaControllerCompat", "Dead object in registerCallback.", e);
                    }
                }
                this.f59c.clear();
            }
        }
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$a */
    public static abstract class C0025a implements IBinder.DeathRecipient {

        /* renamed from: a */
        final Object f63a = new C0061d(new C0027b(this));

        /* renamed from: b */
        C0026a f64b;

        /* renamed from: c */
        C0054a f65c;

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$a$a */
        private class C0026a extends Handler {

            /* renamed from: a */
            boolean f66a = false;

            C0026a(Looper looper) {
                super(looper);
            }

            public void handleMessage(Message message) {
                if (this.f66a) {
                    switch (message.what) {
                        case 1:
                            MediaSessionCompat.m115a(message.getData());
                            C0025a aVar = C0025a.this;
                            String str = (String) message.obj;
                            Objects.requireNonNull(aVar);
                            return;
                        case 2:
                            C0025a.this.mo97b((PlaybackStateCompat) message.obj);
                            return;
                        case 3:
                            C0025a.this.mo96a((MediaMetadataCompat) message.obj);
                            return;
                        case 4:
                            C0025a aVar2 = C0025a.this;
                            C0032e eVar = (C0032e) message.obj;
                            Objects.requireNonNull(aVar2);
                            return;
                        case 5:
                            C0025a aVar3 = C0025a.this;
                            List list = (List) message.obj;
                            Objects.requireNonNull(aVar3);
                            return;
                        case 6:
                            C0025a aVar4 = C0025a.this;
                            CharSequence charSequence = (CharSequence) message.obj;
                            Objects.requireNonNull(aVar4);
                            return;
                        case 7:
                            MediaSessionCompat.m115a((Bundle) message.obj);
                            Objects.requireNonNull(C0025a.this);
                            return;
                        case 8:
                            C0025a.this.mo99c();
                            return;
                        case 9:
                            C0025a aVar5 = C0025a.this;
                            ((Integer) message.obj).intValue();
                            Objects.requireNonNull(aVar5);
                            return;
                        case 11:
                            C0025a aVar6 = C0025a.this;
                            ((Boolean) message.obj).booleanValue();
                            Objects.requireNonNull(aVar6);
                            return;
                        case 12:
                            C0025a aVar7 = C0025a.this;
                            ((Integer) message.obj).intValue();
                            Objects.requireNonNull(aVar7);
                            return;
                        case 13:
                            Objects.requireNonNull(C0025a.this);
                            return;
                        default:
                            return;
                    }
                }
            }
        }

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$a$b */
        private static class C0027b implements C0060c {

            /* renamed from: a */
            private final WeakReference<C0025a> f68a;

            C0027b(C0025a aVar) {
                this.f68a = new WeakReference<>(aVar);
            }

            /* renamed from: a */
            public void mo103a(int i, int i2, int i3, int i4, int i5) {
                C0025a aVar = (C0025a) this.f68a.get();
            }

            /* renamed from: b */
            public void mo104b(Bundle bundle) {
                C0025a aVar = (C0025a) this.f68a.get();
            }

            /* renamed from: c */
            public void mo105c(Object obj) {
                C0025a aVar = (C0025a) this.f68a.get();
                if (aVar != null) {
                    aVar.mo96a(MediaMetadataCompat.m48c(obj));
                }
            }

            /* renamed from: d */
            public void mo106d(Object obj) {
                C0025a aVar = (C0025a) this.f68a.get();
                if (aVar != null && aVar.f65c == null) {
                    aVar.mo97b(PlaybackStateCompat.m245a(obj));
                }
            }

            /* renamed from: e */
            public void mo107e(List<?> list) {
                if (((C0025a) this.f68a.get()) != null) {
                    MediaSessionCompat.QueueItem.m128a(list);
                }
            }

            /* renamed from: f */
            public void mo108f(CharSequence charSequence) {
                C0025a aVar = (C0025a) this.f68a.get();
            }

            /* renamed from: g */
            public void mo109g() {
                C0025a aVar = (C0025a) this.f68a.get();
                if (aVar != null) {
                    aVar.mo99c();
                }
            }

            /* renamed from: h */
            public void mo110h(String str, Bundle bundle) {
                C0025a aVar = (C0025a) this.f68a.get();
                if (aVar != null) {
                    C0054a aVar2 = aVar.f65c;
                }
            }
        }

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$a$c */
        private static class C0028c extends C0054a.C0055a {

            /* renamed from: a */
            private final WeakReference<C0025a> f69a;

            C0028c(C0025a aVar) {
                this.f69a = new WeakReference<>(aVar);
            }

            /* renamed from: A */
            public void mo90A(List<MediaSessionCompat.QueueItem> list) throws RemoteException {
                C0025a aVar = (C0025a) this.f69a.get();
                if (aVar != null) {
                    aVar.mo100d(5, list, (Bundle) null);
                }
            }

            /* renamed from: K0 */
            public void mo111K0(PlaybackStateCompat playbackStateCompat) throws RemoteException {
                C0025a aVar = (C0025a) this.f69a.get();
                if (aVar != null) {
                    aVar.mo100d(2, playbackStateCompat, (Bundle) null);
                }
            }

            /* renamed from: N0 */
            public void mo91N0(ParcelableVolumeInfo parcelableVolumeInfo) throws RemoteException {
                C0025a aVar = (C0025a) this.f69a.get();
                if (aVar != null) {
                    aVar.mo100d(4, parcelableVolumeInfo != null ? new C0032e(parcelableVolumeInfo.f100a, parcelableVolumeInfo.f101b, parcelableVolumeInfo.f102c, parcelableVolumeInfo.f103d, parcelableVolumeInfo.f104e) : null, (Bundle) null);
                }
            }

            /* renamed from: P0 */
            public void mo112P0(boolean z) throws RemoteException {
                C0025a aVar = (C0025a) this.f69a.get();
                if (aVar != null) {
                    aVar.mo100d(11, Boolean.valueOf(z), (Bundle) null);
                }
            }

            /* renamed from: Q0 */
            public void mo113Q0(String str, Bundle bundle) throws RemoteException {
                C0025a aVar = (C0025a) this.f69a.get();
                if (aVar != null) {
                    aVar.mo100d(1, str, bundle);
                }
            }

            /* renamed from: R0 */
            public void mo114R0() throws RemoteException {
                C0025a aVar = (C0025a) this.f69a.get();
                if (aVar != null) {
                    aVar.mo100d(13, (Object) null, (Bundle) null);
                }
            }

            /* renamed from: a0 */
            public void mo92a0(CharSequence charSequence) throws RemoteException {
                C0025a aVar = (C0025a) this.f69a.get();
                if (aVar != null) {
                    aVar.mo100d(6, charSequence, (Bundle) null);
                }
            }

            /* renamed from: d0 */
            public void mo93d0() throws RemoteException {
                C0025a aVar = (C0025a) this.f69a.get();
                if (aVar != null) {
                    aVar.mo100d(8, (Object) null, (Bundle) null);
                }
            }

            /* renamed from: f0 */
            public void mo94f0(MediaMetadataCompat mediaMetadataCompat) throws RemoteException {
                C0025a aVar = (C0025a) this.f69a.get();
                if (aVar != null) {
                    aVar.mo100d(3, mediaMetadataCompat, (Bundle) null);
                }
            }

            public void onRepeatModeChanged(int i) throws RemoteException {
                C0025a aVar = (C0025a) this.f69a.get();
                if (aVar != null) {
                    aVar.mo100d(9, Integer.valueOf(i), (Bundle) null);
                }
            }

            /* renamed from: q0 */
            public void mo116q0(int i) throws RemoteException {
                C0025a aVar = (C0025a) this.f69a.get();
                if (aVar != null) {
                    aVar.mo100d(12, Integer.valueOf(i), (Bundle) null);
                }
            }

            /* renamed from: x */
            public void mo95x(Bundle bundle) throws RemoteException {
                C0025a aVar = (C0025a) this.f69a.get();
                if (aVar != null) {
                    aVar.mo100d(7, bundle, (Bundle) null);
                }
            }
        }

        /* renamed from: a */
        public void mo96a(MediaMetadataCompat mediaMetadataCompat) {
        }

        /* renamed from: b */
        public void mo97b(PlaybackStateCompat playbackStateCompat) {
        }

        public void binderDied() {
            mo100d(8, (Object) null, (Bundle) null);
        }

        /* renamed from: c */
        public void mo99c() {
        }

        /* access modifiers changed from: package-private */
        /* renamed from: d */
        public void mo100d(int i, Object obj, Bundle bundle) {
            C0026a aVar = this.f64b;
            if (aVar != null) {
                Message obtainMessage = aVar.obtainMessage(i, obj);
                obtainMessage.setData(bundle);
                obtainMessage.sendToTarget();
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: e */
        public void mo101e(Handler handler) {
            if (handler == null) {
                C0026a aVar = this.f64b;
                if (aVar != null) {
                    aVar.f66a = false;
                    aVar.removeCallbacksAndMessages((Object) null);
                    this.f64b = null;
                    return;
                }
                return;
            }
            C0026a aVar2 = new C0026a(handler.getLooper());
            this.f64b = aVar2;
            aVar2.f66a = true;
        }
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$b */
    interface C0029b {
        /* renamed from: a */
        void mo85a(C0025a aVar);

        /* renamed from: b */
        PendingIntent mo86b();

        /* renamed from: c */
        C0033f mo87c();
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$c */
    static class C0030c extends MediaControllerImplApi21 {
        public C0030c(Context context, MediaSessionCompat.Token token) throws RemoteException {
            super(context, token);
        }

        /* renamed from: c */
        public C0033f mo87c() {
            Object a = C0062e.m318a(this.f57a);
            if (a != null) {
                return new C0035h(a);
            }
            return null;
        }
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$d */
    static class C0031d extends C0030c {
        public C0031d(Context context, MediaSessionCompat.Token token) throws RemoteException {
            super(context, token);
        }

        /* renamed from: c */
        public C0033f mo87c() {
            Object a = C0062e.m318a(this.f57a);
            if (a != null) {
                return new C0036i(a);
            }
            return null;
        }
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$e */
    public static final class C0032e {
        C0032e(int i, int i2, int i3, int i4, int i5) {
        }
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$f */
    public static abstract class C0033f {
        C0033f() {
        }

        /* renamed from: a */
        public abstract void mo117a();

        /* renamed from: b */
        public abstract void mo118b();

        /* renamed from: c */
        public abstract void mo119c();
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$g */
    static class C0034g extends C0033f {

        /* renamed from: a */
        protected final Object f70a;

        public C0034g(Object obj) {
            this.f70a = obj;
        }

        /* renamed from: a */
        public void mo117a() {
            ((MediaController.TransportControls) this.f70a).pause();
        }

        /* renamed from: b */
        public void mo118b() {
            ((MediaController.TransportControls) this.f70a).play();
        }

        /* renamed from: c */
        public void mo119c() {
            ((MediaController.TransportControls) this.f70a).stop();
        }
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$h */
    static class C0035h extends C0034g {
        public C0035h(Object obj) {
            super(obj);
        }
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$i */
    static class C0036i extends C0035h {
        public C0036i(Object obj) {
            super(obj);
        }
    }

    public MediaControllerCompat(Context context, MediaSessionCompat.Token token) throws RemoteException {
        if (token != null) {
            this.f55b = token;
            int i = Build.VERSION.SDK_INT;
            this.f54a = i >= 24 ? new C0031d(context, token) : i >= 23 ? new C0030c(context, token) : new MediaControllerImplApi21(context, token);
            return;
        }
        throw new IllegalArgumentException("sessionToken must not be null");
    }

    public MediaControllerCompat(Context context, MediaSessionCompat mediaSessionCompat) {
        MediaSessionCompat.Token c = mediaSessionCompat.mo121c();
        this.f55b = c;
        C0029b bVar = null;
        try {
            int i = Build.VERSION.SDK_INT;
            bVar = i >= 24 ? new C0031d(context, c) : i >= 23 ? new C0030c(context, c) : new MediaControllerImplApi21(context, c);
        } catch (RemoteException e) {
            Log.w("MediaControllerCompat", "Failed to create MediaControllerImpl.", e);
        }
        this.f54a = bVar;
    }

    /* renamed from: a */
    public boolean mo79a(KeyEvent keyEvent) {
        if (keyEvent != null) {
            return ((MediaController) ((MediaControllerImplApi21) this.f54a).f57a).dispatchMediaButtonEvent(keyEvent);
        }
        throw new IllegalArgumentException("KeyEvent may not be null");
    }

    /* renamed from: b */
    public PlaybackStateCompat mo80b() {
        MediaControllerImplApi21 mediaControllerImplApi21 = (MediaControllerImplApi21) this.f54a;
        if (mediaControllerImplApi21.f61e.mo143c() != null) {
            try {
                return mediaControllerImplApi21.f61e.mo143c().getPlaybackState();
            } catch (RemoteException e) {
                Log.e("MediaControllerCompat", "Dead object in getPlaybackState.", e);
            }
        }
        PlaybackState playbackState = ((MediaController) mediaControllerImplApi21.f57a).getPlaybackState();
        if (playbackState != null) {
            return PlaybackStateCompat.m245a(playbackState);
        }
        return null;
    }

    /* renamed from: c */
    public List<MediaSessionCompat.QueueItem> mo81c() {
        List<MediaSession.QueueItem> queue = ((MediaController) ((MediaControllerImplApi21) this.f54a).f57a).getQueue();
        ArrayList arrayList = queue == null ? null : new ArrayList(queue);
        if (arrayList != null) {
            return MediaSessionCompat.QueueItem.m128a(arrayList);
        }
        return null;
    }

    /* renamed from: d */
    public PendingIntent mo82d() {
        return this.f54a.mo86b();
    }

    /* renamed from: e */
    public C0033f mo83e() {
        return this.f54a.mo87c();
    }

    /* renamed from: f */
    public void mo84f(C0025a aVar) {
        if (aVar != null) {
            try {
                this.f56c.remove(aVar);
                this.f54a.mo85a(aVar);
            } finally {
                aVar.mo101e((Handler) null);
            }
        } else {
            throw new IllegalArgumentException("callback must not be null");
        }
    }
}
