package android.support.p001v4.media.session;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import android.media.MediaDescription;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.support.p001v4.media.MediaDescriptionCompat;
import android.support.p001v4.media.MediaMetadataCompat;
import android.support.p001v4.media.RatingCompat;
import android.support.p001v4.media.session.C0057b;
import android.support.p001v4.media.session.PlaybackStateCompat;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.ViewConfiguration;
import androidx.media.C0968v;
import androidx.media.session.MediaButtonReceiver;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: android.support.v4.media.session.MediaSessionCompat */
public class MediaSessionCompat {

    /* renamed from: a */
    static int f71a;

    /* renamed from: b */
    private final C0045b f72b;

    /* renamed from: c */
    private final MediaControllerCompat f73c;

    /* renamed from: d */
    private final ArrayList<C0049e> f74d = new ArrayList<>();

    /* renamed from: android.support.v4.media.session.MediaSessionCompat$QueueItem */
    public static final class QueueItem implements Parcelable {
        public static final Parcelable.Creator<QueueItem> CREATOR = new C0037a();

        /* renamed from: a */
        private final MediaDescriptionCompat f75a;

        /* renamed from: b */
        private final long f76b;

        /* renamed from: c */
        private Object f77c;

        /* renamed from: android.support.v4.media.session.MediaSessionCompat$QueueItem$a */
        static class C0037a implements Parcelable.Creator<QueueItem> {
            C0037a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new QueueItem(parcel);
            }

            public Object[] newArray(int i) {
                return new QueueItem[i];
            }
        }

        QueueItem(Parcel parcel) {
            this.f75a = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
            this.f76b = parcel.readLong();
        }

        public QueueItem(MediaDescriptionCompat mediaDescriptionCompat, long j) {
            this((Object) null, mediaDescriptionCompat, j);
        }

        private QueueItem(Object obj, MediaDescriptionCompat mediaDescriptionCompat, long j) {
            if (mediaDescriptionCompat == null) {
                throw new IllegalArgumentException("Description cannot be null.");
            } else if (j != -1) {
                this.f75a = mediaDescriptionCompat;
                this.f76b = j;
                this.f77c = obj;
            } else {
                throw new IllegalArgumentException("Id cannot be QueueItem.UNKNOWN_ID");
            }
        }

        /* renamed from: a */
        public static List<QueueItem> m128a(List<?> list) {
            QueueItem queueItem;
            if (list == null) {
                return null;
            }
            ArrayList arrayList = new ArrayList();
            for (Object next : list) {
                if (next != null) {
                    MediaSession.QueueItem queueItem2 = (MediaSession.QueueItem) next;
                    queueItem = new QueueItem(next, MediaDescriptionCompat.m29a(queueItem2.getDescription()), queueItem2.getQueueId());
                } else {
                    queueItem = null;
                }
                arrayList.add(queueItem);
            }
            return arrayList;
        }

        /* renamed from: c */
        public MediaDescriptionCompat mo131c() {
            return this.f75a;
        }

        /* renamed from: d */
        public long mo132d() {
            return this.f76b;
        }

        public int describeContents() {
            return 0;
        }

        /* renamed from: e */
        public Object mo134e() {
            Object obj = this.f77c;
            if (obj != null) {
                return obj;
            }
            MediaSession.QueueItem queueItem = new MediaSession.QueueItem((MediaDescription) this.f75a.mo38g(), this.f76b);
            this.f77c = queueItem;
            return queueItem;
        }

        public String toString() {
            StringBuilder P = C4924a.m17863P("MediaSession.QueueItem {Description=");
            P.append(this.f75a);
            P.append(", Id=");
            return C4924a.m17849B(P, this.f76b, " }");
        }

        public void writeToParcel(Parcel parcel, int i) {
            ((MediaDescription) this.f75a.mo38g()).writeToParcel(parcel, i);
            parcel.writeLong(this.f76b);
        }
    }

    /* renamed from: android.support.v4.media.session.MediaSessionCompat$ResultReceiverWrapper */
    public static final class ResultReceiverWrapper implements Parcelable {
        public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new C0038a();

        /* renamed from: a */
        ResultReceiver f78a;

        /* renamed from: android.support.v4.media.session.MediaSessionCompat$ResultReceiverWrapper$a */
        static class C0038a implements Parcelable.Creator<ResultReceiverWrapper> {
            C0038a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new ResultReceiverWrapper(parcel);
            }

            public Object[] newArray(int i) {
                return new ResultReceiverWrapper[i];
            }
        }

        ResultReceiverWrapper(Parcel parcel) {
            this.f78a = (ResultReceiver) ResultReceiver.CREATOR.createFromParcel(parcel);
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            this.f78a.writeToParcel(parcel, i);
        }
    }

    /* renamed from: android.support.v4.media.session.MediaSessionCompat$Token */
    public static final class Token implements Parcelable {
        public static final Parcelable.Creator<Token> CREATOR = new C0039a();

        /* renamed from: a */
        private final Object f79a;

        /* renamed from: b */
        private C0057b f80b;

        /* renamed from: c */
        private Bundle f81c;

        /* renamed from: android.support.v4.media.session.MediaSessionCompat$Token$a */
        static class C0039a implements Parcelable.Creator<Token> {
            C0039a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new Token(parcel.readParcelable((ClassLoader) null));
            }

            public Object[] newArray(int i) {
                return new Token[i];
            }
        }

        Token(Object obj) {
            this.f79a = obj;
            this.f80b = null;
            this.f81c = null;
        }

        Token(Object obj, C0057b bVar, Bundle bundle) {
            this.f79a = obj;
            this.f80b = bVar;
            this.f81c = bundle;
        }

        /* renamed from: a */
        public static Token m132a(Object obj, C0057b bVar) {
            if (obj == null) {
                return null;
            }
            if (obj instanceof MediaSession.Token) {
                return new Token(obj, bVar);
            }
            throw new IllegalArgumentException("token is not a valid MediaSession.Token object");
        }

        /* renamed from: c */
        public C0057b mo143c() {
            return this.f80b;
        }

        /* renamed from: d */
        public Bundle mo144d() {
            return this.f81c;
        }

        public int describeContents() {
            return 0;
        }

        /* renamed from: e */
        public Object mo146e() {
            return this.f79a;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Token)) {
                return false;
            }
            Object obj2 = this.f79a;
            Object obj3 = ((Token) obj).f79a;
            if (obj2 == null) {
                return obj3 == null;
            }
            if (obj3 == null) {
                return false;
            }
            return obj2.equals(obj3);
        }

        /* renamed from: f */
        public void mo148f(C0057b bVar) {
            this.f80b = bVar;
        }

        /* renamed from: g */
        public void mo149g(Bundle bundle) {
            this.f81c = bundle;
        }

        public int hashCode() {
            Object obj = this.f79a;
            if (obj == null) {
                return 0;
            }
            return obj.hashCode();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable((Parcelable) this.f79a, i);
        }

        Token(Object obj, C0057b bVar) {
            this.f79a = obj;
            this.f80b = bVar;
            this.f81c = null;
        }
    }

    /* renamed from: android.support.v4.media.session.MediaSessionCompat$a */
    public static abstract class C0040a {

        /* renamed from: a */
        final Object f82a;

        /* renamed from: b */
        WeakReference<C0045b> f83b;

        /* renamed from: c */
        private C0041a f84c = null;

        /* renamed from: d */
        private boolean f85d;

        /* renamed from: android.support.v4.media.session.MediaSessionCompat$a$a */
        private class C0041a extends Handler {
            C0041a(Looper looper) {
                super(looper);
            }

            public void handleMessage(Message message) {
                if (message.what == 1) {
                    C0040a.this.mo157a((C0968v) message.obj);
                }
            }
        }

        /* renamed from: android.support.v4.media.session.MediaSessionCompat$a$b */
        private class C0042b implements C0065h {
            C0042b() {
            }

            /* renamed from: a */
            public void mo184a() {
                C0040a.this.mo181y();
            }

            /* renamed from: b */
            public void mo185b() {
                C0040a.this.mo174r();
            }

            /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v1, resolved type: android.support.v4.media.session.MediaSessionCompat$QueueItem} */
            /* JADX WARNING: type inference failed for: r1v0 */
            /* JADX WARNING: type inference failed for: r1v4, types: [android.os.IBinder] */
            /* JADX WARNING: type inference failed for: r1v6 */
            /* JADX WARNING: type inference failed for: r1v7 */
            /* JADX WARNING: Multi-variable type inference failed */
            /* renamed from: c */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void mo186c(java.lang.String r5, android.os.Bundle r6, android.os.ResultReceiver r7) {
                /*
                    r4 = this;
                    java.lang.String r0 = "android.support.v4.media.session.command.GET_EXTRA_BINDER"
                    boolean r0 = r5.equals(r0)     // Catch:{ BadParcelableException -> 0x00bf }
                    r1 = 0
                    if (r0 == 0) goto L_0x003b
                    android.support.v4.media.session.MediaSessionCompat$a r5 = android.support.p001v4.media.session.MediaSessionCompat.C0040a.this     // Catch:{ BadParcelableException -> 0x00bf }
                    java.lang.ref.WeakReference<android.support.v4.media.session.MediaSessionCompat$b> r5 = r5.f83b     // Catch:{ BadParcelableException -> 0x00bf }
                    java.lang.Object r5 = r5.get()     // Catch:{ BadParcelableException -> 0x00bf }
                    android.support.v4.media.session.MediaSessionCompat$c r5 = (android.support.p001v4.media.session.MediaSessionCompat.C0046c) r5     // Catch:{ BadParcelableException -> 0x00bf }
                    if (r5 == 0) goto L_0x00c6
                    android.os.Bundle r6 = new android.os.Bundle     // Catch:{ BadParcelableException -> 0x00bf }
                    r6.<init>()     // Catch:{ BadParcelableException -> 0x00bf }
                    android.support.v4.media.session.MediaSessionCompat$Token r5 = r5.f91b     // Catch:{ BadParcelableException -> 0x00bf }
                    android.support.v4.media.session.b r0 = r5.mo143c()     // Catch:{ BadParcelableException -> 0x00bf }
                    java.lang.String r2 = "android.support.v4.media.session.EXTRA_BINDER"
                    if (r0 != 0) goto L_0x0025
                    goto L_0x0029
                L_0x0025:
                    android.os.IBinder r1 = r0.asBinder()     // Catch:{ BadParcelableException -> 0x00bf }
                L_0x0029:
                    r6.putBinder(r2, r1)     // Catch:{ BadParcelableException -> 0x00bf }
                    android.os.Bundle r5 = r5.mo144d()     // Catch:{ BadParcelableException -> 0x00bf }
                    java.lang.String r0 = "android.support.v4.media.session.SESSION_TOKEN2_BUNDLE"
                    r6.putBundle(r0, r5)     // Catch:{ BadParcelableException -> 0x00bf }
                    r5 = 0
                    r7.send(r5, r6)     // Catch:{ BadParcelableException -> 0x00bf }
                    goto L_0x00c6
                L_0x003b:
                    java.lang.String r0 = "android.support.v4.media.session.command.ADD_QUEUE_ITEM"
                    boolean r0 = r5.equals(r0)     // Catch:{ BadParcelableException -> 0x00bf }
                    java.lang.String r2 = "android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"
                    if (r0 == 0) goto L_0x0052
                    android.support.v4.media.session.MediaSessionCompat$a r5 = android.support.p001v4.media.session.MediaSessionCompat.C0040a.this     // Catch:{ BadParcelableException -> 0x00bf }
                    android.os.Parcelable r6 = r6.getParcelable(r2)     // Catch:{ BadParcelableException -> 0x00bf }
                    android.support.v4.media.MediaDescriptionCompat r6 = (android.support.p001v4.media.MediaDescriptionCompat) r6     // Catch:{ BadParcelableException -> 0x00bf }
                    r5.mo158b(r6)     // Catch:{ BadParcelableException -> 0x00bf }
                    goto L_0x00c6
                L_0x0052:
                    java.lang.String r0 = "android.support.v4.media.session.command.ADD_QUEUE_ITEM_AT"
                    boolean r0 = r5.equals(r0)     // Catch:{ BadParcelableException -> 0x00bf }
                    java.lang.String r3 = "android.support.v4.media.session.command.ARGUMENT_INDEX"
                    if (r0 == 0) goto L_0x006c
                    android.support.v4.media.session.MediaSessionCompat$a r5 = android.support.p001v4.media.session.MediaSessionCompat.C0040a.this     // Catch:{ BadParcelableException -> 0x00bf }
                    android.os.Parcelable r7 = r6.getParcelable(r2)     // Catch:{ BadParcelableException -> 0x00bf }
                    android.support.v4.media.MediaDescriptionCompat r7 = (android.support.p001v4.media.MediaDescriptionCompat) r7     // Catch:{ BadParcelableException -> 0x00bf }
                    int r6 = r6.getInt(r3)     // Catch:{ BadParcelableException -> 0x00bf }
                    r5.mo159c(r7, r6)     // Catch:{ BadParcelableException -> 0x00bf }
                    goto L_0x00c6
                L_0x006c:
                    java.lang.String r0 = "android.support.v4.media.session.command.REMOVE_QUEUE_ITEM"
                    boolean r0 = r5.equals(r0)     // Catch:{ BadParcelableException -> 0x00bf }
                    if (r0 == 0) goto L_0x0080
                    android.support.v4.media.session.MediaSessionCompat$a r5 = android.support.p001v4.media.session.MediaSessionCompat.C0040a.this     // Catch:{ BadParcelableException -> 0x00bf }
                    android.os.Parcelable r6 = r6.getParcelable(r2)     // Catch:{ BadParcelableException -> 0x00bf }
                    android.support.v4.media.MediaDescriptionCompat r6 = (android.support.p001v4.media.MediaDescriptionCompat) r6     // Catch:{ BadParcelableException -> 0x00bf }
                L_0x007c:
                    r5.mo173q(r6)     // Catch:{ BadParcelableException -> 0x00bf }
                    goto L_0x00c6
                L_0x0080:
                    java.lang.String r0 = "android.support.v4.media.session.command.REMOVE_QUEUE_ITEM_AT"
                    boolean r0 = r5.equals(r0)     // Catch:{ BadParcelableException -> 0x00bf }
                    if (r0 == 0) goto L_0x00b9
                    android.support.v4.media.session.MediaSessionCompat$a r5 = android.support.p001v4.media.session.MediaSessionCompat.C0040a.this     // Catch:{ BadParcelableException -> 0x00bf }
                    java.lang.ref.WeakReference<android.support.v4.media.session.MediaSessionCompat$b> r5 = r5.f83b     // Catch:{ BadParcelableException -> 0x00bf }
                    java.lang.Object r5 = r5.get()     // Catch:{ BadParcelableException -> 0x00bf }
                    android.support.v4.media.session.MediaSessionCompat$c r5 = (android.support.p001v4.media.session.MediaSessionCompat.C0046c) r5     // Catch:{ BadParcelableException -> 0x00bf }
                    if (r5 == 0) goto L_0x00c6
                    java.util.List<android.support.v4.media.session.MediaSessionCompat$QueueItem> r7 = r5.f95f     // Catch:{ BadParcelableException -> 0x00bf }
                    if (r7 == 0) goto L_0x00c6
                    r7 = -1
                    int r6 = r6.getInt(r3, r7)     // Catch:{ BadParcelableException -> 0x00bf }
                    if (r6 < 0) goto L_0x00b0
                    java.util.List<android.support.v4.media.session.MediaSessionCompat$QueueItem> r7 = r5.f95f     // Catch:{ BadParcelableException -> 0x00bf }
                    int r7 = r7.size()     // Catch:{ BadParcelableException -> 0x00bf }
                    if (r6 >= r7) goto L_0x00b0
                    java.util.List<android.support.v4.media.session.MediaSessionCompat$QueueItem> r5 = r5.f95f     // Catch:{ BadParcelableException -> 0x00bf }
                    java.lang.Object r5 = r5.get(r6)     // Catch:{ BadParcelableException -> 0x00bf }
                    r1 = r5
                    android.support.v4.media.session.MediaSessionCompat$QueueItem r1 = (android.support.p001v4.media.session.MediaSessionCompat.QueueItem) r1     // Catch:{ BadParcelableException -> 0x00bf }
                L_0x00b0:
                    if (r1 == 0) goto L_0x00c6
                    android.support.v4.media.session.MediaSessionCompat$a r5 = android.support.p001v4.media.session.MediaSessionCompat.C0040a.this     // Catch:{ BadParcelableException -> 0x00bf }
                    android.support.v4.media.MediaDescriptionCompat r6 = r1.mo131c()     // Catch:{ BadParcelableException -> 0x00bf }
                    goto L_0x007c
                L_0x00b9:
                    android.support.v4.media.session.MediaSessionCompat$a r0 = android.support.p001v4.media.session.MediaSessionCompat.C0040a.this     // Catch:{ BadParcelableException -> 0x00bf }
                    r0.mo160d(r5, r6, r7)     // Catch:{ BadParcelableException -> 0x00bf }
                    goto L_0x00c6
                L_0x00bf:
                    java.lang.String r5 = "MediaSessionCompat"
                    java.lang.String r6 = "Could not unparcel the extra data."
                    android.util.Log.e(r5, r6)
                L_0x00c6:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.media.session.MediaSessionCompat.C0040a.C0042b.mo186c(java.lang.String, android.os.Bundle, android.os.ResultReceiver):void");
            }

            /* renamed from: d */
            public void mo187d(long j) {
                C0040a.this.mo154A(j);
            }

            /* renamed from: e */
            public void mo188e(Object obj) {
                C0040a.this.mo177u(RatingCompat.m61a(obj));
            }

            /* renamed from: g */
            public void mo189g() {
                C0040a.this.mo182z();
            }

            /* renamed from: h */
            public boolean mo190h(Intent intent) {
                return C0040a.this.mo163g(intent);
            }

            /* renamed from: k */
            public void mo191k(String str, Bundle bundle) {
                C0040a.this.mo167k(str, bundle);
            }

            /* renamed from: l */
            public void mo192l(String str, Bundle bundle) {
                C0040a.this.mo166j(str, bundle);
            }

            /* renamed from: m */
            public void mo193m() {
                C0040a.this.mo162f();
            }

            /* renamed from: n */
            public void mo194n(long j) {
                C0040a.this.mo175s(j);
            }

            /* renamed from: o */
            public void mo195o(String str, Bundle bundle) {
                Bundle bundle2 = bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
                MediaSessionCompat.m115a(bundle2);
                if (str.equals("android.support.v4.media.session.action.PLAY_FROM_URI")) {
                    C0040a.this.mo168l((Uri) bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI"), bundle2);
                } else if (str.equals("android.support.v4.media.session.action.PREPARE")) {
                    C0040a.this.mo169m();
                } else if (str.equals("android.support.v4.media.session.action.PREPARE_FROM_MEDIA_ID")) {
                    C0040a.this.mo170n(bundle.getString("android.support.v4.media.session.action.ARGUMENT_MEDIA_ID"), bundle2);
                } else if (str.equals("android.support.v4.media.session.action.PREPARE_FROM_SEARCH")) {
                    C0040a.this.mo171o(bundle.getString("android.support.v4.media.session.action.ARGUMENT_QUERY"), bundle2);
                } else if (str.equals("android.support.v4.media.session.action.PREPARE_FROM_URI")) {
                    C0040a.this.mo172p((Uri) bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI"), bundle2);
                } else if (str.equals("android.support.v4.media.session.action.SET_CAPTIONING_ENABLED")) {
                    C0040a.this.mo176t(bundle.getBoolean("android.support.v4.media.session.action.ARGUMENT_CAPTIONING_ENABLED"));
                } else if (str.equals("android.support.v4.media.session.action.SET_REPEAT_MODE")) {
                    C0040a.this.mo179w(bundle.getInt("android.support.v4.media.session.action.ARGUMENT_REPEAT_MODE"));
                } else if (str.equals("android.support.v4.media.session.action.SET_SHUFFLE_MODE")) {
                    C0040a.this.mo180x(bundle.getInt("android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE"));
                } else if (str.equals("android.support.v4.media.session.action.SET_RATING")) {
                    C0040a.this.mo178v((RatingCompat) bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_RATING"), bundle2);
                } else {
                    C0040a.this.mo161e(str, bundle);
                }
            }

            public void onPause() {
                C0040a.this.mo164h();
            }

            public void onPlay() {
                C0040a.this.mo165i();
            }

            public void onStop() {
                C0040a.this.mo155B();
            }
        }

        /* renamed from: android.support.v4.media.session.MediaSessionCompat$a$c */
        private class C0043c extends C0042b implements C0067j {
            C0043c() {
                super();
            }

            /* renamed from: q */
            public void mo199q(Uri uri, Bundle bundle) {
                C0040a.this.mo168l(uri, bundle);
            }
        }

        /* renamed from: android.support.v4.media.session.MediaSessionCompat$a$d */
        private class C0044d extends C0043c implements C0069l {
            C0044d() {
                super();
            }

            /* renamed from: f */
            public void mo200f(String str, Bundle bundle) {
                C0040a.this.mo170n(str, bundle);
            }

            /* renamed from: i */
            public void mo201i() {
                C0040a.this.mo169m();
            }

            /* renamed from: j */
            public void mo202j(Uri uri, Bundle bundle) {
                C0040a.this.mo172p(uri, bundle);
            }

            /* renamed from: p */
            public void mo203p(String str, Bundle bundle) {
                C0040a.this.mo171o(str, bundle);
            }
        }

        public C0040a() {
            Object obj;
            int i = Build.VERSION.SDK_INT;
            if (i >= 24) {
                obj = new C0070m(new C0044d());
            } else if (i >= 23) {
                obj = new C0068k(new C0043c());
            } else {
                obj = new C0066i(new C0042b());
            }
            this.f82a = obj;
        }

        /* renamed from: A */
        public void mo154A(long j) {
        }

        /* renamed from: B */
        public void mo155B() {
        }

        /* access modifiers changed from: package-private */
        /* renamed from: C */
        public void mo156C(C0045b bVar, Handler handler) {
            this.f83b = new WeakReference<>(bVar);
            C0041a aVar = this.f84c;
            if (aVar != null) {
                aVar.removeCallbacksAndMessages((Object) null);
            }
            this.f84c = new C0041a(handler.getLooper());
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo157a(C0968v vVar) {
            if (this.f85d) {
                boolean z = false;
                this.f85d = false;
                this.f84c.removeMessages(1);
                C0045b bVar = (C0045b) this.f83b.get();
                if (bVar != null) {
                    PlaybackStateCompat playbackState = bVar.getPlaybackState();
                    long j = playbackState == null ? 0 : playbackState.f109e;
                    boolean z2 = playbackState != null && playbackState.f105a == 3;
                    boolean z3 = (516 & j) != 0;
                    if ((j & 514) != 0) {
                        z = true;
                    }
                    bVar.mo212h(vVar);
                    if (z2 && z) {
                        mo164h();
                    } else if (!z2 && z3) {
                        mo165i();
                    }
                    bVar.mo212h((C0968v) null);
                }
            }
        }

        /* renamed from: b */
        public void mo158b(MediaDescriptionCompat mediaDescriptionCompat) {
        }

        /* renamed from: c */
        public void mo159c(MediaDescriptionCompat mediaDescriptionCompat, int i) {
        }

        /* renamed from: d */
        public void mo160d(String str, Bundle bundle, ResultReceiver resultReceiver) {
        }

        /* renamed from: e */
        public void mo161e(String str, Bundle bundle) {
        }

        /* renamed from: f */
        public void mo162f() {
        }

        /* renamed from: g */
        public boolean mo163g(Intent intent) {
            C0045b bVar;
            KeyEvent keyEvent;
            if (Build.VERSION.SDK_INT >= 27 || (bVar = (C0045b) this.f83b.get()) == null || this.f84c == null || (keyEvent = (KeyEvent) intent.getParcelableExtra("android.intent.extra.KEY_EVENT")) == null || keyEvent.getAction() != 0) {
                return false;
            }
            C0968v j = bVar.mo214j();
            int keyCode = keyEvent.getKeyCode();
            if (keyCode == 79 || keyCode == 85) {
                if (keyEvent.getRepeatCount() > 0) {
                    mo157a(j);
                } else if (this.f85d) {
                    this.f84c.removeMessages(1);
                    this.f85d = false;
                    PlaybackStateCompat playbackState = bVar.getPlaybackState();
                    if (((playbackState == null ? 0 : playbackState.f109e) & 32) != 0) {
                        mo181y();
                    }
                } else {
                    this.f85d = true;
                    C0041a aVar = this.f84c;
                    aVar.sendMessageDelayed(aVar.obtainMessage(1, j), (long) ViewConfiguration.getDoubleTapTimeout());
                }
                return true;
            }
            mo157a(j);
            return false;
        }

        /* renamed from: h */
        public void mo164h() {
        }

        /* renamed from: i */
        public void mo165i() {
        }

        /* renamed from: j */
        public void mo166j(String str, Bundle bundle) {
        }

        /* renamed from: k */
        public void mo167k(String str, Bundle bundle) {
        }

        /* renamed from: l */
        public void mo168l(Uri uri, Bundle bundle) {
        }

        /* renamed from: m */
        public void mo169m() {
        }

        /* renamed from: n */
        public void mo170n(String str, Bundle bundle) {
        }

        /* renamed from: o */
        public void mo171o(String str, Bundle bundle) {
        }

        /* renamed from: p */
        public void mo172p(Uri uri, Bundle bundle) {
        }

        /* renamed from: q */
        public void mo173q(MediaDescriptionCompat mediaDescriptionCompat) {
        }

        /* renamed from: r */
        public void mo174r() {
        }

        /* renamed from: s */
        public void mo175s(long j) {
        }

        /* renamed from: t */
        public void mo176t(boolean z) {
        }

        /* renamed from: u */
        public void mo177u(RatingCompat ratingCompat) {
        }

        /* renamed from: v */
        public void mo178v(RatingCompat ratingCompat, Bundle bundle) {
        }

        /* renamed from: w */
        public void mo179w(int i) {
        }

        /* renamed from: x */
        public void mo180x(int i) {
        }

        /* renamed from: y */
        public void mo181y() {
        }

        /* renamed from: z */
        public void mo182z() {
        }
    }

    /* renamed from: android.support.v4.media.session.MediaSessionCompat$b */
    interface C0045b {
        /* renamed from: a */
        Token mo204a();

        /* renamed from: b */
        void mo205b(C0040a aVar, Handler handler);

        /* renamed from: c */
        void mo206c(int i);

        /* renamed from: d */
        void mo207d(MediaMetadataCompat mediaMetadataCompat);

        /* renamed from: e */
        void mo208e(int i);

        /* renamed from: f */
        void mo209f(List<QueueItem> list);

        /* renamed from: g */
        void mo210g(boolean z);

        PlaybackStateCompat getPlaybackState();

        /* renamed from: h */
        void mo212h(C0968v vVar);

        /* renamed from: i */
        void mo213i(PlaybackStateCompat playbackStateCompat);

        /* renamed from: j */
        C0968v mo214j();

        void release();

        void setRepeatMode(int i);
    }

    /* renamed from: android.support.v4.media.session.MediaSessionCompat$c */
    static class C0046c implements C0045b {

        /* renamed from: a */
        final Object f90a;

        /* renamed from: b */
        final Token f91b;

        /* renamed from: c */
        boolean f92c = false;

        /* renamed from: d */
        final RemoteCallbackList<C0054a> f93d = new RemoteCallbackList<>();

        /* renamed from: e */
        PlaybackStateCompat f94e;

        /* renamed from: f */
        List<QueueItem> f95f;

        /* renamed from: g */
        MediaMetadataCompat f96g;

        /* renamed from: h */
        int f97h;

        /* renamed from: i */
        int f98i;

        /* renamed from: android.support.v4.media.session.MediaSessionCompat$c$a */
        class C0047a extends C0057b.C0058a {
            C0047a() {
            }

            /* renamed from: B */
            public CharSequence mo218B() {
                throw new AssertionError();
            }

            /* renamed from: B0 */
            public long mo219B0() {
                throw new AssertionError();
            }

            /* renamed from: C */
            public MediaMetadataCompat mo220C() {
                throw new AssertionError();
            }

            /* renamed from: C0 */
            public void mo221C0(long j) {
                throw new AssertionError();
            }

            /* renamed from: D */
            public void mo222D(String str, Bundle bundle) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: D0 */
            public void mo223D0(boolean z) throws RemoteException {
            }

            /* renamed from: E0 */
            public ParcelableVolumeInfo mo224E0() {
                throw new AssertionError();
            }

            /* renamed from: F */
            public void mo225F(C0054a aVar) {
                C0046c.this.f93d.unregister(aVar);
            }

            /* renamed from: I */
            public void mo226I(String str, Bundle bundle) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: I0 */
            public String mo227I0() {
                throw new AssertionError();
            }

            /* renamed from: K */
            public void mo228K(String str, Bundle bundle) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: M */
            public void mo229M() throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: P */
            public void mo230P(Uri uri, Bundle bundle) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: Y */
            public boolean mo231Y(KeyEvent keyEvent) {
                throw new AssertionError();
            }

            /* renamed from: b0 */
            public void mo232b0(int i, int i2, String str) {
                throw new AssertionError();
            }

            /* renamed from: c */
            public void mo233c(int i) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: c0 */
            public void mo234c0(RatingCompat ratingCompat, Bundle bundle) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: e */
            public void mo235e(String str, Bundle bundle) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: e0 */
            public void mo236e0(MediaDescriptionCompat mediaDescriptionCompat, int i) {
                throw new AssertionError();
            }

            /* renamed from: f */
            public void mo237f(C0054a aVar) {
                C0046c cVar = C0046c.this;
                if (!cVar.f92c) {
                    Objects.requireNonNull(cVar);
                    String str = null;
                    if (Build.VERSION.SDK_INT >= 24) {
                        MediaSession mediaSession = (MediaSession) cVar.f90a;
                        try {
                            str = (String) mediaSession.getClass().getMethod("getCallingPackage", new Class[0]).invoke(mediaSession, new Object[0]);
                        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                            Log.e("MediaSessionCompatApi24", "Cannot execute MediaSession.getCallingPackage()", e);
                        }
                    }
                    if (str == null) {
                        str = "android.media.session.MediaController";
                    }
                    C0046c.this.f93d.register(aVar, new C0968v(str, Binder.getCallingPid(), Binder.getCallingUid()));
                }
            }

            public Bundle getExtras() {
                throw new AssertionError();
            }

            public PlaybackStateCompat getPlaybackState() {
                C0046c cVar = C0046c.this;
                return MediaSessionCompat.m116d(cVar.f94e, cVar.f96g);
            }

            public int getRepeatMode() {
                return C0046c.this.f97h;
            }

            public String getTag() {
                throw new AssertionError();
            }

            /* renamed from: h */
            public boolean mo242h() {
                return false;
            }

            /* renamed from: h0 */
            public void mo243h0(boolean z) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: i */
            public void mo244i(RatingCompat ratingCompat) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: j */
            public void mo245j(int i, int i2, String str) {
                throw new AssertionError();
            }

            /* renamed from: k */
            public void mo246k(Uri uri, Bundle bundle) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: m0 */
            public int mo247m0() {
                return C0046c.this.f98i;
            }

            /* renamed from: n0 */
            public void mo248n0(int i) {
                throw new AssertionError();
            }

            public void next() throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: o */
            public void mo250o(MediaDescriptionCompat mediaDescriptionCompat) {
                throw new AssertionError();
            }

            /* renamed from: o0 */
            public boolean mo251o0() {
                Objects.requireNonNull(C0046c.this);
                return false;
            }

            public void pause() throws RemoteException {
                throw new AssertionError();
            }

            public void play() throws RemoteException {
                throw new AssertionError();
            }

            public void prepare() throws RemoteException {
                throw new AssertionError();
            }

            public void previous() throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: q */
            public boolean mo256q() {
                throw new AssertionError();
            }

            /* renamed from: r */
            public void mo257r(MediaDescriptionCompat mediaDescriptionCompat) {
                throw new AssertionError();
            }

            /* renamed from: s */
            public PendingIntent mo258s() {
                throw new AssertionError();
            }

            /* renamed from: s0 */
            public void mo259s0(String str, Bundle bundle, ResultReceiverWrapper resultReceiverWrapper) {
                throw new AssertionError();
            }

            public void seekTo(long j) throws RemoteException {
                throw new AssertionError();
            }

            public void setRepeatMode(int i) throws RemoteException {
                throw new AssertionError();
            }

            public void stop() throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: t */
            public int mo263t() {
                Objects.requireNonNull(C0046c.this);
                return 0;
            }

            /* renamed from: t0 */
            public List<QueueItem> mo264t0() {
                return null;
            }

            /* renamed from: u0 */
            public void mo265u0() throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: v */
            public void mo266v(String str, Bundle bundle) throws RemoteException {
                throw new AssertionError();
            }
        }

        C0046c(Context context, String str, Bundle bundle) {
            MediaSession mediaSession = new MediaSession(context, str);
            this.f90a = mediaSession;
            this.f91b = new Token(mediaSession.getSessionToken(), new C0047a(), bundle);
        }

        /* renamed from: a */
        public Token mo204a() {
            return this.f91b;
        }

        /* renamed from: b */
        public void mo205b(C0040a aVar, Handler handler) {
            ((MediaSession) this.f90a).setCallback((MediaSession.Callback) (aVar == null ? null : aVar.f82a), handler);
            if (aVar != null) {
                aVar.mo156C(this, handler);
            }
        }

        /* renamed from: c */
        public void mo206c(int i) {
            if (this.f98i != i) {
                this.f98i = i;
                for (int beginBroadcast = this.f93d.beginBroadcast() - 1; beginBroadcast >= 0; beginBroadcast--) {
                    try {
                        this.f93d.getBroadcastItem(beginBroadcast).mo116q0(i);
                    } catch (RemoteException unused) {
                    }
                }
                this.f93d.finishBroadcast();
            }
        }

        /* renamed from: d */
        public void mo207d(MediaMetadataCompat mediaMetadataCompat) {
            this.f96g = mediaMetadataCompat;
            ((MediaSession) this.f90a).setMetadata((MediaMetadata) (mediaMetadataCompat == null ? null : mediaMetadataCompat.mo60f()));
        }

        /* renamed from: e */
        public void mo208e(int i) {
            ((MediaSession) this.f90a).setFlags(i);
        }

        /* renamed from: f */
        public void mo209f(List<QueueItem> list) {
            ArrayList<MediaSession.QueueItem> arrayList;
            this.f95f = list;
            ArrayList arrayList2 = null;
            if (list != null) {
                arrayList = new ArrayList<>();
                for (QueueItem e : list) {
                    arrayList.add(e.mo134e());
                }
            } else {
                arrayList = null;
            }
            Object obj = this.f90a;
            if (arrayList != null) {
                arrayList2 = new ArrayList();
                for (MediaSession.QueueItem add : arrayList) {
                    arrayList2.add(add);
                }
            }
            ((MediaSession) obj).setQueue(arrayList2);
        }

        /* renamed from: g */
        public void mo210g(boolean z) {
            ((MediaSession) this.f90a).setActive(z);
        }

        public PlaybackStateCompat getPlaybackState() {
            return this.f94e;
        }

        /* renamed from: h */
        public void mo212h(C0968v vVar) {
        }

        /* renamed from: i */
        public void mo213i(PlaybackStateCompat playbackStateCompat) {
            this.f94e = playbackStateCompat;
            for (int beginBroadcast = this.f93d.beginBroadcast() - 1; beginBroadcast >= 0; beginBroadcast--) {
                try {
                    this.f93d.getBroadcastItem(beginBroadcast).mo111K0(playbackStateCompat);
                } catch (RemoteException unused) {
                }
            }
            this.f93d.finishBroadcast();
            ((MediaSession) this.f90a).setPlaybackState((PlaybackState) (playbackStateCompat == null ? null : playbackStateCompat.mo275e()));
        }

        /* renamed from: j */
        public C0968v mo214j() {
            return null;
        }

        /* renamed from: k */
        public void mo217k(PendingIntent pendingIntent) {
            ((MediaSession) this.f90a).setMediaButtonReceiver(pendingIntent);
        }

        public void release() {
            this.f92c = true;
            ((MediaSession) this.f90a).release();
        }

        public void setRepeatMode(int i) {
            if (this.f97h != i) {
                this.f97h = i;
                for (int beginBroadcast = this.f93d.beginBroadcast() - 1; beginBroadcast >= 0; beginBroadcast--) {
                    try {
                        this.f93d.getBroadcastItem(beginBroadcast).onRepeatModeChanged(i);
                    } catch (RemoteException unused) {
                    }
                }
                this.f93d.finishBroadcast();
            }
        }
    }

    /* renamed from: android.support.v4.media.session.MediaSessionCompat$d */
    static class C0048d extends C0046c {
        C0048d(Context context, String str, Bundle bundle) {
            super(context, str, bundle);
        }

        /* renamed from: h */
        public void mo212h(C0968v vVar) {
        }

        /* renamed from: j */
        public final C0968v mo214j() {
            return new C0968v(((MediaSession) this.f90a).getCurrentControllerInfo());
        }
    }

    /* renamed from: android.support.v4.media.session.MediaSessionCompat$e */
    public interface C0049e {
        /* renamed from: a */
        void mo267a();
    }

    public MediaSessionCompat(Context context, String str) {
        ComponentName componentName;
        PendingIntent pendingIntent;
        C0040a aVar;
        C0046c cVar;
        if (!TextUtils.isEmpty(str)) {
            int i = MediaButtonReceiver.f3821a;
            Intent intent = new Intent("android.intent.action.MEDIA_BUTTON");
            intent.setPackage(context.getPackageName());
            List<ResolveInfo> queryBroadcastReceivers = context.getPackageManager().queryBroadcastReceivers(intent, 0);
            if (queryBroadcastReceivers.size() == 1) {
                ActivityInfo activityInfo = queryBroadcastReceivers.get(0).activityInfo;
                componentName = new ComponentName(activityInfo.packageName, activityInfo.name);
            } else {
                if (queryBroadcastReceivers.size() > 1) {
                    Log.w("MediaButtonReceiver", "More than one BroadcastReceiver that handles android.intent.action.MEDIA_BUTTON was found, returning null.");
                }
                componentName = null;
            }
            if (componentName == null) {
                Log.w("MediaSessionCompat", "Couldn't find a unique registered media button receiver in the given context.");
            }
            if (componentName != null) {
                Intent intent2 = new Intent("android.intent.action.MEDIA_BUTTON");
                intent2.setComponent(componentName);
                pendingIntent = PendingIntent.getBroadcast(context, 0, intent2, 0);
            } else {
                pendingIntent = null;
            }
            if (Build.VERSION.SDK_INT >= 28) {
                cVar = new C0048d(context, str, (Bundle) null);
                this.f72b = cVar;
                aVar = new C0063f(this);
            } else {
                cVar = new C0046c(context, str, (Bundle) null);
                this.f72b = cVar;
                aVar = new C0064g(this);
            }
            mo124g(aVar, (Handler) null);
            cVar.mo217k(pendingIntent);
            this.f73c = new MediaControllerCompat(context, this);
            if (f71a == 0) {
                f71a = (int) (TypedValue.applyDimension(1, 320.0f, context.getResources().getDisplayMetrics()) + 0.5f);
                return;
            }
            return;
        }
        throw new IllegalArgumentException("tag must not be null or empty");
    }

    /* renamed from: a */
    public static void m115a(Bundle bundle) {
        if (bundle != null) {
            bundle.setClassLoader(MediaSessionCompat.class.getClassLoader());
        }
    }

    /* renamed from: d */
    static PlaybackStateCompat m116d(PlaybackStateCompat playbackStateCompat, MediaMetadataCompat mediaMetadataCompat) {
        if (playbackStateCompat == null) {
            return playbackStateCompat;
        }
        long j = -1;
        if (playbackStateCompat.f106b == -1) {
            return playbackStateCompat;
        }
        int i = playbackStateCompat.f105a;
        if (i != 3 && i != 4 && i != 5) {
            return playbackStateCompat;
        }
        long j2 = playbackStateCompat.f112h;
        if (j2 <= 0) {
            return playbackStateCompat;
        }
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long j3 = ((long) (playbackStateCompat.f108d * ((float) (elapsedRealtime - j2)))) + playbackStateCompat.f106b;
        if (mediaMetadataCompat != null && mediaMetadataCompat.mo56a("android.media.metadata.DURATION")) {
            j = mediaMetadataCompat.mo59e("android.media.metadata.DURATION");
        }
        long j4 = (j < 0 || j3 <= j) ? j3 < 0 ? 0 : j3 : j;
        PlaybackStateCompat.C0053b bVar = new PlaybackStateCompat.C0053b(playbackStateCompat);
        bVar.mo294g(playbackStateCompat.f105a, j4, playbackStateCompat.f108d, elapsedRealtime);
        return bVar.mo289b();
    }

    /* renamed from: b */
    public MediaControllerCompat mo120b() {
        return this.f73c;
    }

    /* renamed from: c */
    public Token mo121c() {
        return this.f72b.mo204a();
    }

    /* renamed from: e */
    public void mo122e() {
        this.f72b.release();
    }

    /* renamed from: f */
    public void mo123f(boolean z) {
        this.f72b.mo210g(z);
        Iterator<C0049e> it = this.f74d.iterator();
        while (it.hasNext()) {
            it.next().mo267a();
        }
    }

    /* renamed from: g */
    public void mo124g(C0040a aVar, Handler handler) {
        if (aVar == null) {
            this.f72b.mo205b((C0040a) null, (Handler) null);
            return;
        }
        C0045b bVar = this.f72b;
        if (handler == null) {
            handler = new Handler();
        }
        bVar.mo205b(aVar, handler);
    }

    /* renamed from: h */
    public void mo125h(int i) {
        this.f72b.mo208e(i);
    }

    /* renamed from: i */
    public void mo126i(MediaMetadataCompat mediaMetadataCompat) {
        this.f72b.mo207d(mediaMetadataCompat);
    }

    /* renamed from: j */
    public void mo127j(PlaybackStateCompat playbackStateCompat) {
        this.f72b.mo213i(playbackStateCompat);
    }

    /* renamed from: k */
    public void mo128k(List<QueueItem> list) {
        this.f72b.mo209f(list);
    }

    /* renamed from: l */
    public void mo129l(int i) {
        this.f72b.setRepeatMode(i);
    }

    /* renamed from: m */
    public void mo130m(int i) {
        this.f72b.mo206c(i);
    }
}
