package android.support.p001v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: android.support.v4.media.session.ParcelableVolumeInfo */
public class ParcelableVolumeInfo implements Parcelable {
    public static final Parcelable.Creator<ParcelableVolumeInfo> CREATOR = new C0050a();

    /* renamed from: a */
    public int f100a;

    /* renamed from: b */
    public int f101b;

    /* renamed from: c */
    public int f102c;

    /* renamed from: d */
    public int f103d;

    /* renamed from: e */
    public int f104e;

    /* renamed from: android.support.v4.media.session.ParcelableVolumeInfo$a */
    static class C0050a implements Parcelable.Creator<ParcelableVolumeInfo> {
        C0050a() {
        }

        public Object createFromParcel(Parcel parcel) {
            return new ParcelableVolumeInfo(parcel);
        }

        public Object[] newArray(int i) {
            return new ParcelableVolumeInfo[i];
        }
    }

    public ParcelableVolumeInfo(Parcel parcel) {
        this.f100a = parcel.readInt();
        this.f102c = parcel.readInt();
        this.f103d = parcel.readInt();
        this.f104e = parcel.readInt();
        this.f101b = parcel.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f100a);
        parcel.writeInt(this.f102c);
        parcel.writeInt(this.f103d);
        parcel.writeInt(this.f104e);
        parcel.writeInt(this.f101b);
    }
}
