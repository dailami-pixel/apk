package android.support.p001v4.media.session;

import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.List;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: android.support.v4.media.session.PlaybackStateCompat */
public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new C0052a();

    /* renamed from: a */
    final int f105a;

    /* renamed from: b */
    final long f106b;

    /* renamed from: c */
    final long f107c;

    /* renamed from: d */
    final float f108d;

    /* renamed from: e */
    final long f109e;

    /* renamed from: f */
    final int f110f;

    /* renamed from: g */
    final CharSequence f111g;

    /* renamed from: h */
    final long f112h;

    /* renamed from: i */
    List<CustomAction> f113i;

    /* renamed from: j */
    final long f114j;

    /* renamed from: k */
    final Bundle f115k;

    /* renamed from: l */
    private Object f116l;

    /* renamed from: android.support.v4.media.session.PlaybackStateCompat$CustomAction */
    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new C0051a();

        /* renamed from: a */
        private final String f117a;

        /* renamed from: b */
        private final CharSequence f118b;

        /* renamed from: c */
        private final int f119c;

        /* renamed from: d */
        private final Bundle f120d;

        /* renamed from: e */
        private Object f121e;

        /* renamed from: android.support.v4.media.session.PlaybackStateCompat$CustomAction$a */
        static class C0051a implements Parcelable.Creator<CustomAction> {
            C0051a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new CustomAction(parcel);
            }

            public Object[] newArray(int i) {
                return new CustomAction[i];
            }
        }

        CustomAction(Parcel parcel) {
            this.f117a = parcel.readString();
            this.f118b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f119c = parcel.readInt();
            this.f120d = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        }

        CustomAction(String str, CharSequence charSequence, int i, Bundle bundle) {
            this.f117a = str;
            this.f118b = charSequence;
            this.f119c = i;
            this.f120d = bundle;
        }

        /* renamed from: a */
        public static CustomAction m250a(Object obj) {
            if (obj == null) {
                return null;
            }
            PlaybackState.CustomAction customAction = (PlaybackState.CustomAction) obj;
            CustomAction customAction2 = new CustomAction(customAction.getAction(), customAction.getName(), customAction.getIcon(), customAction.getExtras());
            customAction2.f121e = obj;
            return customAction2;
        }

        /* renamed from: c */
        public String mo279c() {
            return this.f117a;
        }

        /* renamed from: d */
        public Object mo280d() {
            Object obj = this.f121e;
            if (obj != null) {
                return obj;
            }
            String str = this.f117a;
            CharSequence charSequence = this.f118b;
            int i = this.f119c;
            Bundle bundle = this.f120d;
            PlaybackState.CustomAction.Builder builder = new PlaybackState.CustomAction.Builder(str, charSequence, i);
            builder.setExtras(bundle);
            PlaybackState.CustomAction build = builder.build();
            this.f121e = build;
            return build;
        }

        public int describeContents() {
            return 0;
        }

        public String toString() {
            StringBuilder P = C4924a.m17863P("Action:mName='");
            P.append(this.f118b);
            P.append(", mIcon=");
            P.append(this.f119c);
            P.append(", mExtras=");
            P.append(this.f120d);
            return P.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(this.f117a);
            TextUtils.writeToParcel(this.f118b, parcel, i);
            parcel.writeInt(this.f119c);
            parcel.writeBundle(this.f120d);
        }
    }

    /* renamed from: android.support.v4.media.session.PlaybackStateCompat$a */
    static class C0052a implements Parcelable.Creator<PlaybackStateCompat> {
        C0052a() {
        }

        public Object createFromParcel(Parcel parcel) {
            return new PlaybackStateCompat(parcel);
        }

        public Object[] newArray(int i) {
            return new PlaybackStateCompat[i];
        }
    }

    /* renamed from: android.support.v4.media.session.PlaybackStateCompat$b */
    public static final class C0053b {

        /* renamed from: a */
        private final List<CustomAction> f122a;

        /* renamed from: b */
        private int f123b;

        /* renamed from: c */
        private long f124c;

        /* renamed from: d */
        private long f125d;

        /* renamed from: e */
        private float f126e;

        /* renamed from: f */
        private long f127f;

        /* renamed from: g */
        private int f128g;

        /* renamed from: h */
        private CharSequence f129h;

        /* renamed from: i */
        private long f130i;

        /* renamed from: j */
        private long f131j;

        /* renamed from: k */
        private Bundle f132k;

        public C0053b() {
            this.f122a = new ArrayList();
            this.f131j = -1;
        }

        public C0053b(PlaybackStateCompat playbackStateCompat) {
            ArrayList arrayList = new ArrayList();
            this.f122a = arrayList;
            this.f131j = -1;
            this.f123b = playbackStateCompat.f105a;
            this.f124c = playbackStateCompat.f106b;
            this.f126e = playbackStateCompat.f108d;
            this.f130i = playbackStateCompat.f112h;
            this.f125d = playbackStateCompat.f107c;
            this.f127f = playbackStateCompat.f109e;
            this.f128g = playbackStateCompat.f110f;
            this.f129h = playbackStateCompat.f111g;
            List<CustomAction> list = playbackStateCompat.f113i;
            if (list != null) {
                arrayList.addAll(list);
            }
            this.f131j = playbackStateCompat.f114j;
            this.f132k = playbackStateCompat.f115k;
        }

        /* renamed from: a */
        public C0053b mo288a(CustomAction customAction) {
            this.f122a.add(customAction);
            return this;
        }

        /* renamed from: b */
        public PlaybackStateCompat mo289b() {
            return new PlaybackStateCompat(this.f123b, this.f124c, this.f125d, this.f126e, this.f127f, this.f128g, this.f129h, this.f130i, this.f122a, this.f131j, this.f132k);
        }

        /* renamed from: c */
        public C0053b mo290c(long j) {
            this.f127f = j;
            return this;
        }

        /* renamed from: d */
        public C0053b mo291d(long j) {
            this.f131j = j;
            return this;
        }

        /* renamed from: e */
        public C0053b mo292e(long j) {
            this.f125d = j;
            return this;
        }

        /* renamed from: f */
        public C0053b mo293f(Bundle bundle) {
            this.f132k = bundle;
            return this;
        }

        /* renamed from: g */
        public C0053b mo294g(int i, long j, float f, long j2) {
            this.f123b = i;
            this.f124c = j;
            this.f130i = j2;
            this.f126e = f;
            return this;
        }
    }

    PlaybackStateCompat(int i, long j, long j2, float f, long j3, int i2, CharSequence charSequence, long j4, List<CustomAction> list, long j5, Bundle bundle) {
        this.f105a = i;
        this.f106b = j;
        this.f107c = j2;
        this.f108d = f;
        this.f109e = j3;
        this.f110f = i2;
        this.f111g = charSequence;
        this.f112h = j4;
        this.f113i = new ArrayList(list);
        this.f114j = j5;
        this.f115k = bundle;
    }

    PlaybackStateCompat(Parcel parcel) {
        this.f105a = parcel.readInt();
        this.f106b = parcel.readLong();
        this.f108d = parcel.readFloat();
        this.f112h = parcel.readLong();
        this.f107c = parcel.readLong();
        this.f109e = parcel.readLong();
        this.f111g = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f113i = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.f114j = parcel.readLong();
        this.f115k = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        this.f110f = parcel.readInt();
    }

    /* renamed from: a */
    public static PlaybackStateCompat m245a(Object obj) {
        ArrayList arrayList;
        Object obj2 = obj;
        Bundle bundle = null;
        if (obj2 == null) {
            return null;
        }
        PlaybackState playbackState = (PlaybackState) obj2;
        List<PlaybackState.CustomAction> customActions = playbackState.getCustomActions();
        if (customActions != null) {
            ArrayList arrayList2 = new ArrayList(customActions.size());
            for (PlaybackState.CustomAction a : customActions) {
                arrayList2.add(CustomAction.m250a(a));
            }
            arrayList = arrayList2;
        } else {
            arrayList = null;
        }
        if (Build.VERSION.SDK_INT >= 22) {
            bundle = playbackState.getExtras();
        }
        PlaybackStateCompat playbackStateCompat = new PlaybackStateCompat(playbackState.getState(), playbackState.getPosition(), playbackState.getBufferedPosition(), playbackState.getPlaybackSpeed(), playbackState.getActions(), 0, playbackState.getErrorMessage(), playbackState.getLastPositionUpdateTime(), arrayList, playbackState.getActiveQueueItemId(), bundle);
        playbackStateCompat.f116l = obj2;
        return playbackStateCompat;
    }

    /* renamed from: c */
    public long mo272c() {
        return this.f109e;
    }

    /* renamed from: d */
    public long mo273d() {
        return this.f114j;
    }

    public int describeContents() {
        return 0;
    }

    /* renamed from: e */
    public Object mo275e() {
        PlaybackStateCompat playbackStateCompat;
        PlaybackState playbackState;
        if (this.f116l == null) {
            ArrayList<PlaybackState.CustomAction> arrayList = null;
            if (this.f113i != null) {
                arrayList = new ArrayList<>(this.f113i.size());
                for (CustomAction d : this.f113i) {
                    arrayList.add(d.mo280d());
                }
            }
            if (Build.VERSION.SDK_INT >= 22) {
                int i = this.f105a;
                long j = this.f106b;
                long j2 = this.f107c;
                float f = this.f108d;
                long j3 = this.f109e;
                CharSequence charSequence = this.f111g;
                long j4 = this.f112h;
                long j5 = this.f114j;
                Bundle bundle = this.f115k;
                PlaybackState.Builder builder = new PlaybackState.Builder();
                Bundle bundle2 = bundle;
                builder.setState(i, j, f, j4);
                builder.setBufferedPosition(j2);
                builder.setActions(j3);
                builder.setErrorMessage(charSequence);
                for (PlaybackState.CustomAction addCustomAction : arrayList) {
                    builder.addCustomAction(addCustomAction);
                }
                builder.setActiveQueueItemId(j5);
                builder.setExtras(bundle2);
                playbackState = builder.build();
                playbackStateCompat = this;
            } else {
                playbackStateCompat = this;
                int i2 = playbackStateCompat.f105a;
                long j6 = playbackStateCompat.f106b;
                long j7 = playbackStateCompat.f107c;
                float f2 = playbackStateCompat.f108d;
                long j8 = playbackStateCompat.f109e;
                CharSequence charSequence2 = playbackStateCompat.f111g;
                long j9 = playbackStateCompat.f112h;
                long j10 = playbackStateCompat.f114j;
                PlaybackState.Builder builder2 = new PlaybackState.Builder();
                PlaybackState.Builder builder3 = builder2;
                builder2.setState(i2, j6, f2, j9);
                builder2.setBufferedPosition(j7);
                builder2.setActions(j8);
                builder2.setErrorMessage(charSequence2);
                for (PlaybackState.CustomAction addCustomAction2 : arrayList) {
                    builder2.addCustomAction(addCustomAction2);
                }
                builder2.setActiveQueueItemId(j10);
                playbackState = builder2.build();
            }
            playbackStateCompat.f116l = playbackState;
        } else {
            playbackStateCompat = this;
        }
        return playbackStateCompat.f116l;
    }

    /* renamed from: f */
    public int mo276f() {
        return this.f105a;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("PlaybackState {");
        sb.append("state=");
        sb.append(this.f105a);
        sb.append(", position=");
        sb.append(this.f106b);
        sb.append(", buffered position=");
        sb.append(this.f107c);
        sb.append(", speed=");
        sb.append(this.f108d);
        sb.append(", updated=");
        sb.append(this.f112h);
        sb.append(", actions=");
        sb.append(this.f109e);
        sb.append(", error code=");
        sb.append(this.f110f);
        sb.append(", error message=");
        sb.append(this.f111g);
        sb.append(", custom actions=");
        sb.append(this.f113i);
        sb.append(", active item id=");
        return C4924a.m17849B(sb, this.f114j, "}");
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f105a);
        parcel.writeLong(this.f106b);
        parcel.writeFloat(this.f108d);
        parcel.writeLong(this.f112h);
        parcel.writeLong(this.f107c);
        parcel.writeLong(this.f109e);
        TextUtils.writeToParcel(this.f111g, parcel, i);
        parcel.writeTypedList(this.f113i);
        parcel.writeLong(this.f114j);
        parcel.writeBundle(this.f115k);
        parcel.writeInt(this.f110f);
    }
}
