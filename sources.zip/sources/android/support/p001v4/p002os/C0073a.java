package android.support.p001v4.p002os;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.p001v4.p002os.ResultReceiver;

/* renamed from: android.support.v4.os.a */
public interface C0073a extends IInterface {

    /* renamed from: android.support.v4.os.a$a */
    public static abstract class C0074a extends Binder implements C0073a {

        /* renamed from: a */
        public static final /* synthetic */ int f139a = 0;

        /* renamed from: android.support.v4.os.a$a$a */
        private static class C0075a implements C0073a {

            /* renamed from: a */
            private IBinder f140a;

            C0075a(IBinder iBinder) {
                this.f140a = iBinder;
            }

            /* renamed from: M0 */
            public void mo334M0(int i, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("android.support.v4.os.IResultReceiver");
                    obtain.writeInt(i);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (!this.f140a.transact(1, obtain, (Parcel) null, 1)) {
                        int i2 = C0074a.f139a;
                    }
                } finally {
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.f140a;
            }
        }

        public C0074a() {
            attachInterface(this, "android.support.v4.os.IResultReceiver");
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i == 1) {
                parcel.enforceInterface("android.support.v4.os.IResultReceiver");
                ((ResultReceiver.C0072b) this).mo334M0(parcel.readInt(), parcel.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(parcel) : null);
                return true;
            } else if (i != 1598968902) {
                return super.onTransact(i, parcel, parcel2, i2);
            } else {
                parcel2.writeString("android.support.v4.os.IResultReceiver");
                return true;
            }
        }
    }

    /* renamed from: M0 */
    void mo334M0(int i, Bundle bundle) throws RemoteException;
}
