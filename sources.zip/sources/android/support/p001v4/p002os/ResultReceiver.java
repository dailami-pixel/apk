package android.support.p001v4.p002os;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.p001v4.p002os.C0073a;
import java.util.Objects;

/* renamed from: android.support.v4.os.ResultReceiver */
public class ResultReceiver implements Parcelable {
    public static final Parcelable.Creator<ResultReceiver> CREATOR = new C0071a();

    /* renamed from: a */
    C0073a f137a;

    /* renamed from: android.support.v4.os.ResultReceiver$a */
    class C0071a implements Parcelable.Creator<ResultReceiver> {
        C0071a() {
        }

        public Object createFromParcel(Parcel parcel) {
            return new ResultReceiver(parcel);
        }

        public Object[] newArray(int i) {
            return new ResultReceiver[i];
        }
    }

    /* renamed from: android.support.v4.os.ResultReceiver$b */
    class C0072b extends C0073a.C0074a {
        C0072b() {
        }

        /* renamed from: M0 */
        public void mo334M0(int i, Bundle bundle) {
            Objects.requireNonNull(ResultReceiver.this);
            ResultReceiver.this.mo6a(i, bundle);
        }
    }

    ResultReceiver(Parcel parcel) {
        C0073a aVar;
        IBinder readStrongBinder = parcel.readStrongBinder();
        int i = C0073a.C0074a.f139a;
        if (readStrongBinder == null) {
            aVar = null;
        } else {
            IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("android.support.v4.os.IResultReceiver");
            aVar = (queryLocalInterface == null || !(queryLocalInterface instanceof C0073a)) ? new C0073a.C0074a.C0075a(readStrongBinder) : (C0073a) queryLocalInterface;
        }
        this.f137a = aVar;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo6a(int i, Bundle bundle) {
    }

    /* renamed from: c */
    public void mo329c(int i, Bundle bundle) {
        C0073a aVar = this.f137a;
        if (aVar != null) {
            try {
                aVar.mo334M0(i, bundle);
            } catch (RemoteException unused) {
            }
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        synchronized (this) {
            if (this.f137a == null) {
                this.f137a = new C0072b();
            }
            parcel.writeStrongBinder(this.f137a.asBinder());
        }
    }
}
