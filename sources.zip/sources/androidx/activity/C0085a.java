package androidx.activity;

/* renamed from: androidx.activity.a */
interface C0085a {
    void cancel();
}
