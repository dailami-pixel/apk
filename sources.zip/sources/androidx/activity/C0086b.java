package androidx.activity;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

/* renamed from: androidx.activity.b */
public abstract class C0086b {

    /* renamed from: a */
    private boolean f172a;

    /* renamed from: b */
    private CopyOnWriteArrayList<C0085a> f173b = new CopyOnWriteArrayList<>();

    public C0086b(boolean z) {
        this.f172a = z;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo368a(C0085a aVar) {
        this.f173b.add(aVar);
    }

    /* renamed from: b */
    public abstract void mo369b();

    /* renamed from: c */
    public final boolean mo370c() {
        return this.f172a;
    }

    /* renamed from: d */
    public final void mo371d() {
        Iterator<C0085a> it = this.f173b.iterator();
        while (it.hasNext()) {
            it.next().cancel();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo372e(C0085a aVar) {
        this.f173b.remove(aVar);
    }

    /* renamed from: f */
    public final void mo373f(boolean z) {
        this.f172a = z;
    }
}
