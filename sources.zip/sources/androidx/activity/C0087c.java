package androidx.activity;

import androidx.lifecycle.C0909j;

/* renamed from: androidx.activity.c */
public interface C0087c extends C0909j {
    /* renamed from: O */
    OnBackPressedDispatcher mo343O();
}
