package androidx.activity;

import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Trace;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.p003d.C0088a;
import androidx.activity.p003d.C0089b;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.C0100c;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.p004d.C0101a;
import androidx.core.app.C0441a;
import androidx.core.app.C0445b;
import androidx.lifecycle.C0903f;
import androidx.lifecycle.C0907h;
import androidx.lifecycle.C0909j;
import androidx.lifecycle.C0910k;
import androidx.lifecycle.C0918r;
import androidx.lifecycle.C0925u;
import androidx.lifecycle.C0926v;
import androidx.savedstate.C1284a;
import androidx.savedstate.C1285b;
import androidx.savedstate.SavedStateRegistry;
import com.vidio.android.p195tv.R;
import java.util.concurrent.atomic.AtomicInteger;
import p098d.p157s.C4888a;

public class ComponentActivity extends androidx.core.app.ComponentActivity implements C0909j, C0926v, C1285b, C0087c, C0100c {

    /* renamed from: b */
    final C0088a f141b = new C0088a();

    /* renamed from: c */
    private final C0910k f142c;

    /* renamed from: d */
    final C1284a f143d;

    /* renamed from: e */
    private C0925u f144e;

    /* renamed from: f */
    private final OnBackPressedDispatcher f145f;

    /* renamed from: g */
    private final ActivityResultRegistry f146g;

    /* renamed from: androidx.activity.ComponentActivity$a */
    class C0079a implements Runnable {
        C0079a() {
        }

        public void run() {
            try {
                ComponentActivity.super.onBackPressed();
            } catch (IllegalStateException e) {
                if (!TextUtils.equals(e.getMessage(), "Can not perform this action after onSaveInstanceState")) {
                    throw e;
                }
            }
        }
    }

    /* renamed from: androidx.activity.ComponentActivity$b */
    class C0080b extends ActivityResultRegistry {

        /* renamed from: androidx.activity.ComponentActivity$b$a */
        class C0081a implements Runnable {

            /* renamed from: a */
            final /* synthetic */ int f152a;

            /* renamed from: b */
            final /* synthetic */ C0101a.C0102a f153b;

            C0081a(int i, C0101a.C0102a aVar) {
                this.f152a = i;
                this.f153b = aVar;
            }

            public void run() {
                C0080b.this.mo386b(this.f152a, this.f153b.mo411a());
            }
        }

        /* renamed from: androidx.activity.ComponentActivity$b$b */
        class C0082b implements Runnable {

            /* renamed from: a */
            final /* synthetic */ int f155a;

            /* renamed from: b */
            final /* synthetic */ IntentSender.SendIntentException f156b;

            C0082b(int i, IntentSender.SendIntentException sendIntentException) {
                this.f155a = i;
                this.f156b = sendIntentException;
            }

            public void run() {
                C0080b.this.mo385a(this.f155a, 0, new Intent().setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", this.f156b));
            }
        }

        C0080b() {
        }

        /* renamed from: c */
        public <I, O> void mo362c(int i, C0101a<I, O> aVar, I i2, C0445b bVar) {
            Bundle bundle;
            ComponentActivity componentActivity = ComponentActivity.this;
            C0101a.C0102a<O> b = aVar.mo409b(componentActivity, i2);
            if (b != null) {
                new Handler(Looper.getMainLooper()).post(new C0081a(i, b));
                return;
            }
            Intent a = aVar.mo408a(componentActivity, i2);
            if (a.getExtras() != null && a.getExtras().getClassLoader() == null) {
                a.setExtrasClassLoader(componentActivity.getClassLoader());
            }
            if (a.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
                Bundle bundleExtra = a.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                a.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                bundle = bundleExtra;
            } else if (bVar == null) {
                bundle = null;
            } else {
                throw null;
            }
            if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(a.getAction())) {
                String[] stringArrayExtra = a.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
                if (stringArrayExtra == null) {
                    stringArrayExtra = new String[0];
                }
                C0441a.m2080e(componentActivity, stringArrayExtra, i);
            } else if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(a.getAction())) {
                IntentSenderRequest intentSenderRequest = (IntentSenderRequest) a.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
                try {
                    IntentSender e = intentSenderRequest.mo400e();
                    Intent a2 = intentSenderRequest.mo396a();
                    int c = intentSenderRequest.mo397c();
                    int d = intentSenderRequest.mo398d();
                    int i3 = C0441a.f2105c;
                    componentActivity.startIntentSenderForResult(e, i, a2, c, d, 0, bundle);
                } catch (IntentSender.SendIntentException e2) {
                    new Handler(Looper.getMainLooper()).post(new C0082b(i, e2));
                }
            } else {
                int i4 = C0441a.f2105c;
                componentActivity.startActivityForResult(a, i, bundle);
            }
        }
    }

    /* renamed from: androidx.activity.ComponentActivity$c */
    static final class C0083c {

        /* renamed from: a */
        C0925u f158a;

        C0083c() {
        }
    }

    public ComponentActivity() {
        C0910k kVar = new C0910k(this);
        this.f142c = kVar;
        this.f143d = C1284a.m5335a(this);
        this.f145f = new OnBackPressedDispatcher(new C0079a());
        new AtomicInteger();
        this.f146g = new C0080b();
        if (kVar != null) {
            int i = Build.VERSION.SDK_INT;
            kVar.mo3940a(new C0907h() {
                /* renamed from: c */
                public void mo360c(C0909j jVar, C0903f.C0904a aVar) {
                    if (aVar == C0903f.C0904a.ON_STOP) {
                        Window window = ComponentActivity.this.getWindow();
                        View peekDecorView = window != null ? window.peekDecorView() : null;
                        if (peekDecorView != null) {
                            peekDecorView.cancelPendingInputEvents();
                        }
                    }
                }
            });
            kVar.mo3940a(new C0907h() {
                /* renamed from: c */
                public void mo360c(C0909j jVar, C0903f.C0904a aVar) {
                    if (aVar == C0903f.C0904a.ON_DESTROY) {
                        ComponentActivity.this.f141b.mo375b();
                        if (!ComponentActivity.this.isChangingConfigurations()) {
                            ComponentActivity.this.mo345h1().mo3972a();
                        }
                    }
                }
            });
            kVar.mo3940a(new C0907h() {
                /* renamed from: c */
                public void mo360c(C0909j jVar, C0903f.C0904a aVar) {
                    ComponentActivity.this.mo339C0();
                    ComponentActivity.this.mo341G().mo3942c(this);
                }
            });
            if (i <= 23) {
                kVar.mo3940a(new ImmLeaksCleaner(this));
                return;
            }
            return;
        }
        throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
    }

    /* renamed from: D0 */
    private void m342D0() {
        getWindow().getDecorView().setTag(R.id.view_tree_lifecycle_owner, this);
        getWindow().getDecorView().setTag(R.id.view_tree_view_model_store_owner, this);
        getWindow().getDecorView().setTag(R.id.view_tree_saved_state_registry_owner, this);
    }

    /* renamed from: B0 */
    public final void mo338B0(C0089b bVar) {
        this.f141b.mo374a(bVar);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: C0 */
    public void mo339C0() {
        if (this.f144e == null) {
            C0083c cVar = (C0083c) getLastNonConfigurationInstance();
            if (cVar != null) {
                this.f144e = cVar.f158a;
            }
            if (this.f144e == null) {
                this.f144e = new C0925u();
            }
        }
    }

    /* renamed from: F1 */
    public final SavedStateRegistry mo340F1() {
        return this.f143d.mo5354b();
    }

    /* renamed from: G */
    public C0903f mo341G() {
        return this.f142c;
    }

    /* renamed from: J */
    public final ActivityResultRegistry mo342J() {
        return this.f146g;
    }

    /* renamed from: O */
    public final OnBackPressedDispatcher mo343O() {
        return this.f145f;
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        m342D0();
        super.addContentView(view, layoutParams);
    }

    /* renamed from: h1 */
    public C0925u mo345h1() {
        if (getApplication() != null) {
            mo339C0();
            return this.f144e;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    /* access modifiers changed from: protected */
    @Deprecated
    public void onActivityResult(int i, int i2, Intent intent) {
        if (!this.f146g.mo385a(i, i2, intent)) {
            super.onActivityResult(i, i2, intent);
        }
    }

    public void onBackPressed() {
        this.f145f.mo366b();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        this.f143d.mo5355c(bundle);
        this.f141b.mo376c(this);
        super.onCreate(bundle);
        this.f146g.mo387d(bundle);
        C0918r.m3873c(this);
    }

    @Deprecated
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (!this.f146g.mo385a(i, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr)) && Build.VERSION.SDK_INT >= 23) {
            super.onRequestPermissionsResult(i, strArr, iArr);
        }
    }

    public final Object onRetainNonConfigurationInstance() {
        C0083c cVar;
        C0925u uVar = this.f144e;
        if (uVar == null && (cVar = (C0083c) getLastNonConfigurationInstance()) != null) {
            uVar = cVar.f158a;
        }
        if (uVar == null) {
            return null;
        }
        C0083c cVar2 = new C0083c();
        cVar2.f158a = uVar;
        return cVar2;
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        C0910k kVar = this.f142c;
        if (kVar instanceof C0910k) {
            kVar.mo3946k(C0903f.C0905b.CREATED);
        }
        super.onSaveInstanceState(bundle);
        this.f143d.mo5356d(bundle);
        this.f146g.mo388e(bundle);
    }

    public void reportFullyDrawn() {
        try {
            if (C4888a.m17794a()) {
                Trace.beginSection("reportFullyDrawn() for " + getComponentName());
            }
            super.reportFullyDrawn();
        } finally {
            Trace.endSection();
        }
    }

    public void setContentView(int i) {
        m342D0();
        super.setContentView(i);
    }

    public void setContentView(View view) {
        m342D0();
        super.setContentView(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        m342D0();
        super.setContentView(view, layoutParams);
    }

    @Deprecated
    public void startActivityForResult(Intent intent, int i) {
        super.startActivityForResult(intent, i);
    }

    @Deprecated
    public void startActivityForResult(Intent intent, int i, Bundle bundle) {
        super.startActivityForResult(intent, i, bundle);
    }

    @Deprecated
    public void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4) throws IntentSender.SendIntentException {
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4);
    }

    @Deprecated
    public void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) throws IntentSender.SendIntentException {
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4, bundle);
    }
}
