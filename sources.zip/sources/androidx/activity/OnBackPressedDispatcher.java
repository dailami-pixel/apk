package androidx.activity;

import androidx.lifecycle.C0903f;
import androidx.lifecycle.C0907h;
import androidx.lifecycle.C0909j;
import java.util.ArrayDeque;
import java.util.Iterator;

public final class OnBackPressedDispatcher {

    /* renamed from: a */
    private final Runnable f164a;

    /* renamed from: b */
    final ArrayDeque<C0086b> f165b = new ArrayDeque<>();

    private class LifecycleOnBackPressedCancellable implements C0907h, C0085a {

        /* renamed from: a */
        private final C0903f f166a;

        /* renamed from: b */
        private final C0086b f167b;

        /* renamed from: c */
        private C0085a f168c;

        LifecycleOnBackPressedCancellable(C0903f fVar, C0086b bVar) {
            this.f166a = fVar;
            this.f167b = bVar;
            fVar.mo3940a(this);
        }

        /* renamed from: c */
        public void mo360c(C0909j jVar, C0903f.C0904a aVar) {
            if (aVar == C0903f.C0904a.ON_START) {
                OnBackPressedDispatcher onBackPressedDispatcher = OnBackPressedDispatcher.this;
                C0086b bVar = this.f167b;
                onBackPressedDispatcher.f165b.add(bVar);
                C0084a aVar2 = new C0084a(bVar);
                bVar.mo368a(aVar2);
                this.f168c = aVar2;
            } else if (aVar == C0903f.C0904a.ON_STOP) {
                C0085a aVar3 = this.f168c;
                if (aVar3 != null) {
                    aVar3.cancel();
                }
            } else if (aVar == C0903f.C0904a.ON_DESTROY) {
                cancel();
            }
        }

        public void cancel() {
            this.f166a.mo3942c(this);
            this.f167b.mo372e(this);
            C0085a aVar = this.f168c;
            if (aVar != null) {
                aVar.cancel();
                this.f168c = null;
            }
        }
    }

    /* renamed from: androidx.activity.OnBackPressedDispatcher$a */
    private class C0084a implements C0085a {

        /* renamed from: a */
        private final C0086b f170a;

        C0084a(C0086b bVar) {
            this.f170a = bVar;
        }

        public void cancel() {
            OnBackPressedDispatcher.this.f165b.remove(this.f170a);
            this.f170a.mo372e(this);
        }
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this.f164a = runnable;
    }

    /* renamed from: a */
    public void mo365a(C0909j jVar, C0086b bVar) {
        C0903f G = jVar.mo341G();
        if (G.mo3941b() != C0903f.C0905b.DESTROYED) {
            bVar.mo368a(new LifecycleOnBackPressedCancellable(G, bVar));
        }
    }

    /* renamed from: b */
    public void mo366b() {
        Iterator<C0086b> descendingIterator = this.f165b.descendingIterator();
        while (descendingIterator.hasNext()) {
            C0086b next = descendingIterator.next();
            if (next.mo370c()) {
                next.mo369b();
                return;
            }
        }
        Runnable runnable = this.f164a;
        if (runnable != null) {
            runnable.run();
        }
    }
}
