package androidx.activity.p003d;

import android.content.Context;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

/* renamed from: androidx.activity.d.a */
public final class C0088a {

    /* renamed from: a */
    private final Set<C0089b> f174a = new CopyOnWriteArraySet();

    /* renamed from: b */
    private volatile Context f175b;

    /* renamed from: a */
    public void mo374a(C0089b bVar) {
        if (this.f175b != null) {
            bVar.mo377a(this.f175b);
        }
        this.f174a.add(bVar);
    }

    /* renamed from: b */
    public void mo375b() {
        this.f175b = null;
    }

    /* renamed from: c */
    public void mo376c(Context context) {
        this.f175b = context;
        for (C0089b a : this.f174a) {
            a.mo377a(context);
        }
    }
}
