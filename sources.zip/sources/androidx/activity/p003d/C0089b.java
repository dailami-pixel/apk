package androidx.activity.p003d;

import android.content.Context;

/* renamed from: androidx.activity.d.b */
public interface C0089b {
    /* renamed from: a */
    void mo377a(Context context);
}
