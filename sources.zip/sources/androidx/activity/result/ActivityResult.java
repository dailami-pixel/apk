package androidx.activity.result;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import p165e.p166a.p167a.p168a.C4924a;

public final class ActivityResult implements Parcelable {
    public static final Parcelable.Creator<ActivityResult> CREATOR = new C0090a();

    /* renamed from: a */
    private final int f176a;

    /* renamed from: b */
    private final Intent f177b;

    /* renamed from: androidx.activity.result.ActivityResult$a */
    class C0090a implements Parcelable.Creator<ActivityResult> {
        C0090a() {
        }

        public Object createFromParcel(Parcel parcel) {
            return new ActivityResult(parcel);
        }

        public Object[] newArray(int i) {
            return new ActivityResult[i];
        }
    }

    public ActivityResult(int i, Intent intent) {
        this.f176a = i;
        this.f177b = intent;
    }

    ActivityResult(Parcel parcel) {
        this.f176a = parcel.readInt();
        this.f177b = parcel.readInt() == 0 ? null : (Intent) Intent.CREATOR.createFromParcel(parcel);
    }

    /* renamed from: a */
    public Intent mo378a() {
        return this.f177b;
    }

    /* renamed from: c */
    public int mo379c() {
        return this.f176a;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        StringBuilder P = C4924a.m17863P("ActivityResult{resultCode=");
        int i = this.f176a;
        P.append(i != -1 ? i != 0 ? String.valueOf(i) : "RESULT_CANCELED" : "RESULT_OK");
        P.append(", data=");
        P.append(this.f177b);
        P.append('}');
        return P.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f176a);
        parcel.writeInt(this.f177b == null ? 0 : 1);
        Intent intent = this.f177b;
        if (intent != null) {
            intent.writeToParcel(parcel, i);
        }
    }
}
