package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.activity.result.p004d.C0101a;
import androidx.core.app.C0445b;
import androidx.lifecycle.C0903f;
import androidx.lifecycle.C0907h;
import androidx.lifecycle.C0909j;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import p165e.p166a.p167a.p168a.C4924a;

public abstract class ActivityResultRegistry {

    /* renamed from: a */
    private Random f178a = new Random();

    /* renamed from: b */
    private final Map<Integer, String> f179b = new HashMap();

    /* renamed from: c */
    private final Map<String, Integer> f180c = new HashMap();

    /* renamed from: d */
    private final Map<String, C0095d> f181d = new HashMap();

    /* renamed from: e */
    ArrayList<String> f182e = new ArrayList<>();

    /* renamed from: f */
    final transient Map<String, C0094c<?>> f183f = new HashMap();

    /* renamed from: g */
    final Map<String, Object> f184g = new HashMap();

    /* renamed from: h */
    final Bundle f185h = new Bundle();

    /* renamed from: androidx.activity.result.ActivityResultRegistry$a */
    class C0092a extends C0099b<I> {

        /* renamed from: a */
        final /* synthetic */ String f190a;

        /* renamed from: b */
        final /* synthetic */ int f191b;

        /* renamed from: c */
        final /* synthetic */ C0101a f192c;

        C0092a(String str, int i, C0101a aVar) {
            this.f190a = str;
            this.f191b = i;
            this.f192c = aVar;
        }

        /* renamed from: a */
        public void mo392a(I i, C0445b bVar) {
            ActivityResultRegistry.this.f182e.add(this.f190a);
            ActivityResultRegistry.this.mo362c(this.f191b, this.f192c, i, (C0445b) null);
        }

        /* renamed from: b */
        public void mo393b() {
            ActivityResultRegistry.this.mo391i(this.f190a);
        }
    }

    /* renamed from: androidx.activity.result.ActivityResultRegistry$b */
    class C0093b extends C0099b<I> {

        /* renamed from: a */
        final /* synthetic */ String f194a;

        /* renamed from: b */
        final /* synthetic */ int f195b;

        /* renamed from: c */
        final /* synthetic */ C0101a f196c;

        C0093b(String str, int i, C0101a aVar) {
            this.f194a = str;
            this.f195b = i;
            this.f196c = aVar;
        }

        /* renamed from: a */
        public void mo392a(I i, C0445b bVar) {
            ActivityResultRegistry.this.f182e.add(this.f194a);
            ActivityResultRegistry.this.mo362c(this.f195b, this.f196c, i, (C0445b) null);
        }

        /* renamed from: b */
        public void mo393b() {
            ActivityResultRegistry.this.mo391i(this.f194a);
        }
    }

    /* renamed from: androidx.activity.result.ActivityResultRegistry$c */
    private static class C0094c<O> {

        /* renamed from: a */
        final C0098a<O> f198a;

        /* renamed from: b */
        final C0101a<?, O> f199b;

        C0094c(C0098a<O> aVar, C0101a<?, O> aVar2) {
            this.f198a = aVar;
            this.f199b = aVar2;
        }
    }

    /* renamed from: androidx.activity.result.ActivityResultRegistry$d */
    private static class C0095d {

        /* renamed from: a */
        final C0903f f200a;

        /* renamed from: b */
        private final ArrayList<C0907h> f201b = new ArrayList<>();

        C0095d(C0903f fVar) {
            this.f200a = fVar;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo394a(C0907h hVar) {
            this.f200a.mo3940a(hVar);
            this.f201b.add(hVar);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo395b() {
            Iterator<C0907h> it = this.f201b.iterator();
            while (it.hasNext()) {
                this.f200a.mo3942c(it.next());
            }
            this.f201b.clear();
        }
    }

    /* renamed from: h */
    private int m371h(String str) {
        Integer num = this.f180c.get(str);
        if (num != null) {
            return num.intValue();
        }
        int nextInt = this.f178a.nextInt(2147418112);
        while (true) {
            int i = nextInt + 65536;
            if (this.f179b.containsKey(Integer.valueOf(i))) {
                nextInt = this.f178a.nextInt(2147418112);
            } else {
                this.f179b.put(Integer.valueOf(i), str);
                this.f180c.put(str, Integer.valueOf(i));
                return i;
            }
        }
    }

    /* renamed from: a */
    public final boolean mo385a(int i, int i2, Intent intent) {
        C0098a<O> aVar;
        String str = this.f179b.get(Integer.valueOf(i));
        if (str == null) {
            return false;
        }
        this.f182e.remove(str);
        C0094c cVar = this.f183f.get(str);
        if (cVar == null || (aVar = cVar.f198a) == null) {
            this.f184g.remove(str);
            this.f185h.putParcelable(str, new ActivityResult(i2, intent));
            return true;
        }
        aVar.mo407a(cVar.f199b.mo410c(i2, intent));
        return true;
    }

    /* renamed from: b */
    public final <O> boolean mo386b(int i, O o) {
        C0098a<O> aVar;
        String str = this.f179b.get(Integer.valueOf(i));
        if (str == null) {
            return false;
        }
        this.f182e.remove(str);
        C0094c cVar = this.f183f.get(str);
        if (cVar == null || (aVar = cVar.f198a) == null) {
            this.f185h.remove(str);
            this.f184g.put(str, o);
            return true;
        }
        aVar.mo407a(o);
        return true;
    }

    /* renamed from: c */
    public abstract <I, O> void mo362c(int i, C0101a<I, O> aVar, I i2, C0445b bVar);

    /* renamed from: d */
    public final void mo387d(Bundle bundle) {
        if (bundle != null) {
            ArrayList<Integer> integerArrayList = bundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
            ArrayList<String> stringArrayList = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
            if (stringArrayList != null && integerArrayList != null) {
                int size = stringArrayList.size();
                for (int i = 0; i < size; i++) {
                    int intValue = integerArrayList.get(i).intValue();
                    String str = stringArrayList.get(i);
                    this.f179b.put(Integer.valueOf(intValue), str);
                    this.f180c.put(str, Integer.valueOf(intValue));
                }
                this.f182e = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                this.f178a = (Random) bundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
                this.f185h.putAll(bundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
            }
        }
    }

    /* renamed from: e */
    public final void mo388e(Bundle bundle) {
        bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(this.f179b.keySet()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(this.f179b.values()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList(this.f182e));
        bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) this.f185h.clone());
        bundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", this.f178a);
    }

    /* renamed from: f */
    public final <I, O> C0099b<I> mo389f(String str, C0101a<I, O> aVar, C0098a<O> aVar2) {
        int h = m371h(str);
        this.f183f.put(str, new C0094c(aVar2, aVar));
        if (this.f184g.containsKey(str)) {
            Object obj = this.f184g.get(str);
            this.f184g.remove(str);
            aVar2.mo407a(obj);
        }
        ActivityResult activityResult = (ActivityResult) this.f185h.getParcelable(str);
        if (activityResult != null) {
            this.f185h.remove(str);
            aVar2.mo407a(aVar.mo410c(activityResult.mo379c(), activityResult.mo378a()));
        }
        return new C0093b(str, h, aVar);
    }

    /* renamed from: g */
    public final <I, O> C0099b<I> mo390g(final String str, C0909j jVar, final C0101a<I, O> aVar, final C0098a<O> aVar2) {
        C0903f G = jVar.mo341G();
        if (!(G.mo3941b().compareTo(C0903f.C0905b.STARTED) >= 0)) {
            int h = m371h(str);
            C0095d dVar = this.f181d.get(str);
            if (dVar == null) {
                dVar = new C0095d(G);
            }
            dVar.mo394a(new C0907h() {
                /* renamed from: c */
                public void mo360c(C0909j jVar, C0903f.C0904a aVar) {
                    if (C0903f.C0904a.ON_START.equals(aVar)) {
                        ActivityResultRegistry.this.f183f.put(str, new C0094c(aVar2, aVar));
                        if (ActivityResultRegistry.this.f184g.containsKey(str)) {
                            Object obj = ActivityResultRegistry.this.f184g.get(str);
                            ActivityResultRegistry.this.f184g.remove(str);
                            aVar2.mo407a(obj);
                        }
                        ActivityResult activityResult = (ActivityResult) ActivityResultRegistry.this.f185h.getParcelable(str);
                        if (activityResult != null) {
                            ActivityResultRegistry.this.f185h.remove(str);
                            aVar2.mo407a(aVar.mo410c(activityResult.mo379c(), activityResult.mo378a()));
                        }
                    } else if (C0903f.C0904a.ON_STOP.equals(aVar)) {
                        ActivityResultRegistry.this.f183f.remove(str);
                    } else if (C0903f.C0904a.ON_DESTROY.equals(aVar)) {
                        ActivityResultRegistry.this.mo391i(str);
                    }
                }
            });
            this.f181d.put(str, dVar);
            return new C0092a(str, h, aVar);
        }
        throw new IllegalStateException("LifecycleOwner " + jVar + " is attempting to register while current state is " + G.mo3941b() + ". LifecycleOwners must call register before they are STARTED.");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public final void mo391i(String str) {
        Integer remove;
        if (!this.f182e.contains(str) && (remove = this.f180c.remove(str)) != null) {
            this.f179b.remove(remove);
        }
        this.f183f.remove(str);
        if (this.f184g.containsKey(str)) {
            StringBuilder U = C4924a.m17868U("Dropping pending result for request ", str, ": ");
            U.append(this.f184g.get(str));
            Log.w("ActivityResultRegistry", U.toString());
            this.f184g.remove(str);
        }
        if (this.f185h.containsKey(str)) {
            StringBuilder U2 = C4924a.m17868U("Dropping pending result for request ", str, ": ");
            U2.append(this.f185h.getParcelable(str));
            Log.w("ActivityResultRegistry", U2.toString());
            this.f185h.remove(str);
        }
        C0095d dVar = this.f181d.get(str);
        if (dVar != null) {
            dVar.mo395b();
            this.f181d.remove(str);
        }
    }
}
