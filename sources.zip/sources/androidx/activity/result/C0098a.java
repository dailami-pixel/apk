package androidx.activity.result;

/* renamed from: androidx.activity.result.a */
public interface C0098a<O> {
    /* renamed from: a */
    void mo407a(O o);
}
