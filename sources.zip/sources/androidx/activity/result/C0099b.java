package androidx.activity.result;

import androidx.core.app.C0445b;

/* renamed from: androidx.activity.result.b */
public abstract class C0099b<I> {
    /* renamed from: a */
    public abstract void mo392a(I i, C0445b bVar);

    /* renamed from: b */
    public abstract void mo393b();
}
