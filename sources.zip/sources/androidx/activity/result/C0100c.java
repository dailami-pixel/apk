package androidx.activity.result;

/* renamed from: androidx.activity.result.c */
public interface C0100c {
    /* renamed from: J */
    ActivityResultRegistry mo342J();
}
