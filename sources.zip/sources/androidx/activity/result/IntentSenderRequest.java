package androidx.activity.result;

import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;

public final class IntentSenderRequest implements Parcelable {
    public static final Parcelable.Creator<IntentSenderRequest> CREATOR = new C0096a();

    /* renamed from: a */
    private final IntentSender f202a;

    /* renamed from: b */
    private final Intent f203b;

    /* renamed from: c */
    private final int f204c;

    /* renamed from: d */
    private final int f205d;

    /* renamed from: androidx.activity.result.IntentSenderRequest$a */
    class C0096a implements Parcelable.Creator<IntentSenderRequest> {
        C0096a() {
        }

        public Object createFromParcel(Parcel parcel) {
            return new IntentSenderRequest(parcel);
        }

        public Object[] newArray(int i) {
            return new IntentSenderRequest[i];
        }
    }

    /* renamed from: androidx.activity.result.IntentSenderRequest$b */
    public static final class C0097b {

        /* renamed from: a */
        private IntentSender f206a;

        /* renamed from: b */
        private Intent f207b;

        /* renamed from: c */
        private int f208c;

        /* renamed from: d */
        private int f209d;

        public C0097b(IntentSender intentSender) {
            this.f206a = intentSender;
        }

        /* renamed from: a */
        public IntentSenderRequest mo404a() {
            return new IntentSenderRequest(this.f206a, this.f207b, this.f208c, this.f209d);
        }

        /* renamed from: b */
        public C0097b mo405b(Intent intent) {
            this.f207b = null;
            return this;
        }

        /* renamed from: c */
        public C0097b mo406c(int i, int i2) {
            this.f209d = i;
            this.f208c = i2;
            return this;
        }
    }

    IntentSenderRequest(IntentSender intentSender, Intent intent, int i, int i2) {
        this.f202a = intentSender;
        this.f203b = intent;
        this.f204c = i;
        this.f205d = i2;
    }

    IntentSenderRequest(Parcel parcel) {
        this.f202a = (IntentSender) parcel.readParcelable(IntentSender.class.getClassLoader());
        this.f203b = (Intent) parcel.readParcelable(Intent.class.getClassLoader());
        this.f204c = parcel.readInt();
        this.f205d = parcel.readInt();
    }

    /* renamed from: a */
    public Intent mo396a() {
        return this.f203b;
    }

    /* renamed from: c */
    public int mo397c() {
        return this.f204c;
    }

    /* renamed from: d */
    public int mo398d() {
        return this.f205d;
    }

    public int describeContents() {
        return 0;
    }

    /* renamed from: e */
    public IntentSender mo400e() {
        return this.f202a;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.f202a, i);
        parcel.writeParcelable(this.f203b, i);
        parcel.writeInt(this.f204c);
        parcel.writeInt(this.f205d);
    }
}
