package androidx.activity.result.p004d;

import android.content.Context;
import android.content.Intent;

/* renamed from: androidx.activity.result.d.a */
public abstract class C0101a<I, O> {

    /* renamed from: androidx.activity.result.d.a$a */
    public static final class C0102a<T> {

        /* renamed from: a */
        private final T f210a;

        public C0102a(T t) {
            this.f210a = t;
        }

        /* renamed from: a */
        public T mo411a() {
            return this.f210a;
        }
    }

    /* renamed from: a */
    public abstract Intent mo408a(Context context, I i);

    /* renamed from: b */
    public C0102a<O> mo409b(Context context, I i) {
        return null;
    }

    /* renamed from: c */
    public abstract O mo410c(int i, Intent intent);
}
