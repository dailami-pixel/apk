package androidx.activity.result.p004d;

import android.content.Context;
import android.content.Intent;
import androidx.activity.result.p004d.C0101a;
import androidx.core.content.C0474a;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import p098d.p112d.C4616a;

/* renamed from: androidx.activity.result.d.b */
public final class C0103b extends C0101a<String[], Map<String, Boolean>> {
    /* renamed from: a */
    public Intent mo408a(Context context, Object obj) {
        return new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS").putExtra("androidx.activity.result.contract.extra.PERMISSIONS", (String[]) obj);
    }

    /* renamed from: b */
    public C0101a.C0102a mo409b(Context context, Object obj) {
        String[] strArr = (String[]) obj;
        if (strArr == null || strArr.length == 0) {
            return new C0101a.C0102a(Collections.emptyMap());
        }
        C4616a aVar = new C4616a();
        boolean z = true;
        for (String str : strArr) {
            boolean z2 = C0474a.m2160a(context, str) == 0;
            aVar.put(str, Boolean.valueOf(z2));
            if (!z2) {
                z = false;
            }
        }
        if (z) {
            return new C0101a.C0102a(aVar);
        }
        return null;
    }

    /* renamed from: c */
    public Object mo410c(int i, Intent intent) {
        if (i == -1 && intent != null) {
            String[] stringArrayExtra = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
            int[] intArrayExtra = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
            if (!(intArrayExtra == null || stringArrayExtra == null)) {
                HashMap hashMap = new HashMap();
                int length = stringArrayExtra.length;
                for (int i2 = 0; i2 < length; i2++) {
                    hashMap.put(stringArrayExtra[i2], Boolean.valueOf(intArrayExtra[i2] == 0));
                }
                return hashMap;
            }
        }
        return Collections.emptyMap();
    }
}
