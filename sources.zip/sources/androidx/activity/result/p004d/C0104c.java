package androidx.activity.result.p004d;

import android.content.Context;
import android.content.Intent;
import androidx.activity.result.ActivityResult;

/* renamed from: androidx.activity.result.d.c */
public final class C0104c extends C0101a<Intent, ActivityResult> {
    /* renamed from: a */
    public Intent mo408a(Context context, Object obj) {
        return (Intent) obj;
    }

    /* renamed from: c */
    public Object mo410c(int i, Intent intent) {
        return new ActivityResult(i, intent);
    }
}
