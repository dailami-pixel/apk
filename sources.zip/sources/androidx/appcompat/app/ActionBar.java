package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ViewGroup;
import p098d.p099a.C4568b;

public abstract class ActionBar {

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {

        /* renamed from: a */
        public int f211a;

        public LayoutParams(int i, int i2) {
            super(i, i2);
            this.f211a = 0;
            this.f211a = 8388627;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f211a = 0;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4568b.f16454b);
            this.f211a = obtainStyledAttributes.getInt(0, 0);
            obtainStyledAttributes.recycle();
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f211a = 0;
        }

        public LayoutParams(LayoutParams layoutParams) {
            super(layoutParams);
            this.f211a = 0;
            this.f211a = layoutParams.f211a;
        }
    }

    /* renamed from: androidx.appcompat.app.ActionBar$a */
    public interface C0105a {
        /* renamed from: a */
        void mo417a(boolean z);
    }

    /* renamed from: a */
    public abstract void mo412a(boolean z);

    /* renamed from: b */
    public abstract Context mo413b();

    /* renamed from: c */
    public abstract void mo414c(Configuration configuration);

    /* renamed from: d */
    public abstract void mo415d(boolean z);

    /* renamed from: e */
    public abstract void mo416e(boolean z);
}
