package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import com.vidio.android.p195tv.R;
import java.lang.ref.WeakReference;
import p098d.p099a.C4568b;

class AlertController {

    /* renamed from: A */
    NestedScrollView f212A;

    /* renamed from: B */
    private int f213B = 0;

    /* renamed from: C */
    private Drawable f214C;

    /* renamed from: D */
    private ImageView f215D;

    /* renamed from: E */
    private TextView f216E;

    /* renamed from: F */
    private TextView f217F;

    /* renamed from: G */
    private View f218G;

    /* renamed from: H */
    ListAdapter f219H;

    /* renamed from: I */
    int f220I = -1;

    /* renamed from: J */
    private int f221J;

    /* renamed from: K */
    private int f222K;

    /* renamed from: L */
    int f223L;

    /* renamed from: M */
    int f224M;

    /* renamed from: N */
    int f225N;

    /* renamed from: O */
    int f226O;

    /* renamed from: P */
    private boolean f227P;

    /* renamed from: Q */
    Handler f228Q;

    /* renamed from: R */
    private final View.OnClickListener f229R = new C0106a();

    /* renamed from: a */
    private final Context f230a;

    /* renamed from: b */
    final C0137m f231b;

    /* renamed from: c */
    private final Window f232c;

    /* renamed from: d */
    private final int f233d;

    /* renamed from: e */
    private CharSequence f234e;

    /* renamed from: f */
    private CharSequence f235f;

    /* renamed from: g */
    ListView f236g;

    /* renamed from: h */
    private View f237h;

    /* renamed from: i */
    private int f238i;

    /* renamed from: j */
    private int f239j;

    /* renamed from: k */
    private int f240k;

    /* renamed from: l */
    private int f241l;

    /* renamed from: m */
    private int f242m;

    /* renamed from: n */
    private boolean f243n = false;

    /* renamed from: o */
    Button f244o;

    /* renamed from: p */
    private CharSequence f245p;

    /* renamed from: q */
    Message f246q;

    /* renamed from: r */
    private Drawable f247r;

    /* renamed from: s */
    Button f248s;

    /* renamed from: t */
    private CharSequence f249t;

    /* renamed from: u */
    Message f250u;

    /* renamed from: v */
    private Drawable f251v;

    /* renamed from: w */
    Button f252w;

    /* renamed from: x */
    private CharSequence f253x;

    /* renamed from: y */
    Message f254y;

    /* renamed from: z */
    private Drawable f255z;

    public static class RecycleListView extends ListView {

        /* renamed from: a */
        private final int f256a;

        /* renamed from: b */
        private final int f257b;

        public RecycleListView(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4568b.f16473u);
            this.f257b = obtainStyledAttributes.getDimensionPixelOffset(0, -1);
            this.f256a = obtainStyledAttributes.getDimensionPixelOffset(1, -1);
        }

        /* renamed from: a */
        public void mo422a(boolean z, boolean z2) {
            if (!z2 || !z) {
                setPadding(getPaddingLeft(), z ? getPaddingTop() : this.f256a, getPaddingRight(), z2 ? getPaddingBottom() : this.f257b);
            }
        }
    }

    /* renamed from: androidx.appcompat.app.AlertController$a */
    class C0106a implements View.OnClickListener {
        C0106a() {
        }

        /* JADX WARNING: Code restructure failed: missing block: B:11:0x001c, code lost:
            r3 = r0.f254y;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onClick(android.view.View r3) {
            /*
                r2 = this;
                androidx.appcompat.app.AlertController r0 = androidx.appcompat.app.AlertController.this
                android.widget.Button r1 = r0.f244o
                if (r3 != r1) goto L_0x000f
                android.os.Message r1 = r0.f246q
                if (r1 == 0) goto L_0x000f
            L_0x000a:
                android.os.Message r3 = android.os.Message.obtain(r1)
                goto L_0x0026
            L_0x000f:
                android.widget.Button r1 = r0.f248s
                if (r3 != r1) goto L_0x0018
                android.os.Message r1 = r0.f250u
                if (r1 == 0) goto L_0x0018
                goto L_0x000a
            L_0x0018:
                android.widget.Button r1 = r0.f252w
                if (r3 != r1) goto L_0x0025
                android.os.Message r3 = r0.f254y
                if (r3 == 0) goto L_0x0025
                android.os.Message r3 = android.os.Message.obtain(r3)
                goto L_0x0026
            L_0x0025:
                r3 = 0
            L_0x0026:
                if (r3 == 0) goto L_0x002b
                r3.sendToTarget()
            L_0x002b:
                androidx.appcompat.app.AlertController r3 = androidx.appcompat.app.AlertController.this
                android.os.Handler r0 = r3.f228Q
                r1 = 1
                androidx.appcompat.app.m r3 = r3.f231b
                android.os.Message r3 = r0.obtainMessage(r1, r3)
                r3.sendToTarget()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AlertController.C0106a.onClick(android.view.View):void");
        }
    }

    /* renamed from: androidx.appcompat.app.AlertController$b */
    public static class C0107b {

        /* renamed from: a */
        public final Context f259a;

        /* renamed from: b */
        public final LayoutInflater f260b;

        /* renamed from: c */
        public Drawable f261c;

        /* renamed from: d */
        public CharSequence f262d;

        /* renamed from: e */
        public View f263e;

        /* renamed from: f */
        public DialogInterface.OnKeyListener f264f;

        /* renamed from: g */
        public ListAdapter f265g;

        /* renamed from: h */
        public DialogInterface.OnClickListener f266h;

        /* renamed from: i */
        public boolean f267i;

        /* renamed from: j */
        public int f268j = -1;

        public C0107b(Context context) {
            this.f259a = context;
            this.f260b = (LayoutInflater) context.getSystemService("layout_inflater");
        }
    }

    /* renamed from: androidx.appcompat.app.AlertController$c */
    private static final class C0108c extends Handler {

        /* renamed from: a */
        private WeakReference<DialogInterface> f269a;

        public C0108c(DialogInterface dialogInterface) {
            this.f269a = new WeakReference<>(dialogInterface);
        }

        public void handleMessage(Message message) {
            int i = message.what;
            if (i == -3 || i == -2 || i == -1) {
                ((DialogInterface.OnClickListener) message.obj).onClick((DialogInterface) this.f269a.get(), message.what);
            } else if (i == 1) {
                ((DialogInterface) message.obj).dismiss();
            }
        }
    }

    /* renamed from: androidx.appcompat.app.AlertController$d */
    private static class C0109d extends ArrayAdapter<CharSequence> {
        public C0109d(Context context, int i, int i2, CharSequence[] charSequenceArr) {
            super(context, i, i2, (Object[]) null);
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public boolean hasStableIds() {
            return true;
        }
    }

    public AlertController(Context context, C0137m mVar, Window window) {
        this.f230a = context;
        this.f231b = mVar;
        this.f232c = window;
        this.f228Q = new C0108c(mVar);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes((AttributeSet) null, C4568b.f16458f, R.attr.alertDialogStyle, 0);
        this.f221J = obtainStyledAttributes.getResourceId(0, 0);
        this.f222K = obtainStyledAttributes.getResourceId(2, 0);
        this.f223L = obtainStyledAttributes.getResourceId(4, 0);
        this.f224M = obtainStyledAttributes.getResourceId(5, 0);
        this.f225N = obtainStyledAttributes.getResourceId(7, 0);
        this.f226O = obtainStyledAttributes.getResourceId(3, 0);
        this.f227P = obtainStyledAttributes.getBoolean(6, true);
        this.f233d = obtainStyledAttributes.getDimensionPixelSize(1, 0);
        obtainStyledAttributes.recycle();
        mVar.supportRequestWindowFeature(1);
    }

    /* renamed from: a */
    static boolean m413a(View view) {
        if (view.onCheckIsTextEditor()) {
            return true;
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        while (childCount > 0) {
            childCount--;
            if (m413a(viewGroup.getChildAt(childCount))) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: b */
    private void m414b(Button button) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button.getLayoutParams();
        layoutParams.gravity = 1;
        layoutParams.weight = 0.5f;
        button.setLayoutParams(layoutParams);
    }

    /* renamed from: d */
    static void m415d(View view, View view2, View view3) {
        int i = 4;
        if (view2 != null) {
            view2.setVisibility(view.canScrollVertically(-1) ? 0 : 4);
        }
        if (view3 != null) {
            if (view.canScrollVertically(1)) {
                i = 0;
            }
            view3.setVisibility(i);
        }
    }

    /* renamed from: e */
    private ViewGroup m416e(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:142:0x0330, code lost:
        if (r5 != null) goto L_0x0384;
     */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo418c() {
        /*
            r17 = this;
            r0 = r17
            int r1 = r0.f222K
            int r1 = r0.f221J
            androidx.appcompat.app.m r2 = r0.f231b
            r2.setContentView((int) r1)
            android.view.Window r1 = r0.f232c
            r2 = 2131362611(0x7f0a0333, float:1.8345007E38)
            android.view.View r1 = r1.findViewById(r2)
            r2 = 2131362882(0x7f0a0442, float:1.8345557E38)
            android.view.View r3 = r1.findViewById(r2)
            r4 = 2131362079(0x7f0a011f, float:1.8343928E38)
            android.view.View r5 = r1.findViewById(r4)
            r6 = 2131362011(0x7f0a00db, float:1.834379E38)
            android.view.View r7 = r1.findViewById(r6)
            r8 = 2131362104(0x7f0a0138, float:1.834398E38)
            android.view.View r1 = r1.findViewById(r8)
            android.view.ViewGroup r1 = (android.view.ViewGroup) r1
            android.view.View r8 = r0.f237h
            r10 = 0
            if (r8 == 0) goto L_0x0038
            goto L_0x004a
        L_0x0038:
            int r8 = r0.f238i
            if (r8 == 0) goto L_0x0049
            android.content.Context r8 = r0.f230a
            android.view.LayoutInflater r8 = android.view.LayoutInflater.from(r8)
            int r11 = r0.f238i
            android.view.View r8 = r8.inflate(r11, r1, r10)
            goto L_0x004a
        L_0x0049:
            r8 = 0
        L_0x004a:
            if (r8 == 0) goto L_0x004e
            r12 = 1
            goto L_0x004f
        L_0x004e:
            r12 = 0
        L_0x004f:
            if (r12 == 0) goto L_0x0057
            boolean r13 = m413a(r8)
            if (r13 != 0) goto L_0x005e
        L_0x0057:
            android.view.Window r13 = r0.f232c
            r14 = 131072(0x20000, float:1.83671E-40)
            r13.setFlags(r14, r14)
        L_0x005e:
            r13 = -1
            r14 = 8
            if (r12 == 0) goto L_0x0093
            android.view.Window r12 = r0.f232c
            r15 = 2131362103(0x7f0a0137, float:1.8343977E38)
            android.view.View r12 = r12.findViewById(r15)
            android.widget.FrameLayout r12 = (android.widget.FrameLayout) r12
            android.view.ViewGroup$LayoutParams r15 = new android.view.ViewGroup$LayoutParams
            r15.<init>(r13, r13)
            r12.addView(r8, r15)
            boolean r8 = r0.f243n
            if (r8 == 0) goto L_0x0085
            int r8 = r0.f239j
            int r15 = r0.f240k
            int r11 = r0.f241l
            int r9 = r0.f242m
            r12.setPadding(r8, r15, r11, r9)
        L_0x0085:
            android.widget.ListView r8 = r0.f236g
            if (r8 == 0) goto L_0x0096
            android.view.ViewGroup$LayoutParams r8 = r1.getLayoutParams()
            androidx.appcompat.widget.LinearLayoutCompat$LayoutParams r8 = (androidx.appcompat.widget.LinearLayoutCompat.LayoutParams) r8
            r9 = 0
            r8.f864a = r9
            goto L_0x0096
        L_0x0093:
            r1.setVisibility(r14)
        L_0x0096:
            android.view.View r2 = r1.findViewById(r2)
            android.view.View r4 = r1.findViewById(r4)
            android.view.View r6 = r1.findViewById(r6)
            android.view.ViewGroup r2 = r0.m416e(r2, r3)
            android.view.ViewGroup r3 = r0.m416e(r4, r5)
            android.view.ViewGroup r4 = r0.m416e(r6, r7)
            android.view.Window r5 = r0.f232c
            r6 = 2131362711(0x7f0a0397, float:1.834521E38)
            android.view.View r5 = r5.findViewById(r6)
            androidx.core.widget.NestedScrollView r5 = (androidx.core.widget.NestedScrollView) r5
            r0.f212A = r5
            r5.setFocusable(r10)
            androidx.core.widget.NestedScrollView r5 = r0.f212A
            r5.setNestedScrollingEnabled(r10)
            r5 = 16908299(0x102000b, float:2.387726E-38)
            android.view.View r5 = r3.findViewById(r5)
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0.f217F = r5
            if (r5 != 0) goto L_0x00d1
            goto L_0x0106
        L_0x00d1:
            java.lang.CharSequence r6 = r0.f235f
            if (r6 == 0) goto L_0x00d9
            r5.setText(r6)
            goto L_0x0106
        L_0x00d9:
            r5.setVisibility(r14)
            androidx.core.widget.NestedScrollView r5 = r0.f212A
            android.widget.TextView r6 = r0.f217F
            r5.removeView(r6)
            android.widget.ListView r5 = r0.f236g
            if (r5 == 0) goto L_0x0103
            androidx.core.widget.NestedScrollView r5 = r0.f212A
            android.view.ViewParent r5 = r5.getParent()
            android.view.ViewGroup r5 = (android.view.ViewGroup) r5
            androidx.core.widget.NestedScrollView r6 = r0.f212A
            int r6 = r5.indexOfChild(r6)
            r5.removeViewAt(r6)
            android.widget.ListView r7 = r0.f236g
            android.view.ViewGroup$LayoutParams r8 = new android.view.ViewGroup$LayoutParams
            r8.<init>(r13, r13)
            r5.addView(r7, r6, r8)
            goto L_0x0106
        L_0x0103:
            r3.setVisibility(r14)
        L_0x0106:
            r5 = 16908313(0x1020019, float:2.38773E-38)
            android.view.View r5 = r4.findViewById(r5)
            android.widget.Button r5 = (android.widget.Button) r5
            r0.f244o = r5
            android.view.View$OnClickListener r6 = r0.f229R
            r5.setOnClickListener(r6)
            java.lang.CharSequence r5 = r0.f245p
            boolean r5 = android.text.TextUtils.isEmpty(r5)
            if (r5 == 0) goto L_0x0129
            android.graphics.drawable.Drawable r5 = r0.f247r
            if (r5 != 0) goto L_0x0129
            android.widget.Button r5 = r0.f244o
            r5.setVisibility(r14)
            r5 = 0
            goto L_0x0147
        L_0x0129:
            android.widget.Button r5 = r0.f244o
            java.lang.CharSequence r6 = r0.f245p
            r5.setText(r6)
            android.graphics.drawable.Drawable r5 = r0.f247r
            if (r5 == 0) goto L_0x0141
            int r6 = r0.f233d
            r5.setBounds(r10, r10, r6, r6)
            android.widget.Button r5 = r0.f244o
            android.graphics.drawable.Drawable r6 = r0.f247r
            r7 = 0
            r5.setCompoundDrawables(r6, r7, r7, r7)
        L_0x0141:
            android.widget.Button r5 = r0.f244o
            r5.setVisibility(r10)
            r5 = 1
        L_0x0147:
            r6 = 16908314(0x102001a, float:2.3877302E-38)
            android.view.View r6 = r4.findViewById(r6)
            android.widget.Button r6 = (android.widget.Button) r6
            r0.f248s = r6
            android.view.View$OnClickListener r7 = r0.f229R
            r6.setOnClickListener(r7)
            java.lang.CharSequence r6 = r0.f249t
            boolean r6 = android.text.TextUtils.isEmpty(r6)
            if (r6 == 0) goto L_0x0169
            android.graphics.drawable.Drawable r6 = r0.f251v
            if (r6 != 0) goto L_0x0169
            android.widget.Button r6 = r0.f248s
            r6.setVisibility(r14)
            goto L_0x0188
        L_0x0169:
            android.widget.Button r6 = r0.f248s
            java.lang.CharSequence r7 = r0.f249t
            r6.setText(r7)
            android.graphics.drawable.Drawable r6 = r0.f251v
            if (r6 == 0) goto L_0x0181
            int r7 = r0.f233d
            r6.setBounds(r10, r10, r7, r7)
            android.widget.Button r6 = r0.f248s
            android.graphics.drawable.Drawable r7 = r0.f251v
            r8 = 0
            r6.setCompoundDrawables(r7, r8, r8, r8)
        L_0x0181:
            android.widget.Button r6 = r0.f248s
            r6.setVisibility(r10)
            r5 = r5 | 2
        L_0x0188:
            r6 = 16908315(0x102001b, float:2.3877305E-38)
            android.view.View r6 = r4.findViewById(r6)
            android.widget.Button r6 = (android.widget.Button) r6
            r0.f252w = r6
            android.view.View$OnClickListener r7 = r0.f229R
            r6.setOnClickListener(r7)
            java.lang.CharSequence r6 = r0.f253x
            boolean r6 = android.text.TextUtils.isEmpty(r6)
            if (r6 == 0) goto L_0x01ab
            android.graphics.drawable.Drawable r6 = r0.f255z
            if (r6 != 0) goto L_0x01ab
            android.widget.Button r6 = r0.f252w
            r6.setVisibility(r14)
            r8 = 0
            goto L_0x01cc
        L_0x01ab:
            android.widget.Button r6 = r0.f252w
            java.lang.CharSequence r7 = r0.f253x
            r6.setText(r7)
            android.graphics.drawable.Drawable r6 = r0.f255z
            if (r6 == 0) goto L_0x01c4
            int r7 = r0.f233d
            r6.setBounds(r10, r10, r7, r7)
            android.widget.Button r6 = r0.f252w
            android.graphics.drawable.Drawable r7 = r0.f255z
            r8 = 0
            r6.setCompoundDrawables(r7, r8, r8, r8)
            goto L_0x01c5
        L_0x01c4:
            r8 = 0
        L_0x01c5:
            android.widget.Button r6 = r0.f252w
            r6.setVisibility(r10)
            r5 = r5 | 4
        L_0x01cc:
            android.content.Context r6 = r0.f230a
            android.util.TypedValue r7 = new android.util.TypedValue
            r7.<init>()
            android.content.res.Resources$Theme r6 = r6.getTheme()
            r9 = 2130968621(0x7f04002d, float:1.75459E38)
            r11 = 1
            r6.resolveAttribute(r9, r7, r11)
            int r6 = r7.data
            if (r6 == 0) goto L_0x01e5
            r16 = 1
            goto L_0x01e7
        L_0x01e5:
            r16 = 0
        L_0x01e7:
            r6 = 2
            if (r16 == 0) goto L_0x01fc
            if (r5 != r11) goto L_0x01ef
            android.widget.Button r7 = r0.f244o
            goto L_0x01f9
        L_0x01ef:
            if (r5 != r6) goto L_0x01f4
            android.widget.Button r7 = r0.f248s
            goto L_0x01f9
        L_0x01f4:
            r7 = 4
            if (r5 != r7) goto L_0x01fc
            android.widget.Button r7 = r0.f252w
        L_0x01f9:
            r0.m414b(r7)
        L_0x01fc:
            if (r5 == 0) goto L_0x0200
            r5 = 1
            goto L_0x0201
        L_0x0200:
            r5 = 0
        L_0x0201:
            if (r5 != 0) goto L_0x0206
            r4.setVisibility(r14)
        L_0x0206:
            android.view.View r5 = r0.f218G
            r7 = 2131362874(0x7f0a043a, float:1.834554E38)
            if (r5 == 0) goto L_0x0223
            android.view.ViewGroup$LayoutParams r5 = new android.view.ViewGroup$LayoutParams
            r9 = -2
            r5.<init>(r13, r9)
            android.view.View r9 = r0.f218G
            r2.addView(r9, r10, r5)
            android.view.Window r5 = r0.f232c
            android.view.View r5 = r5.findViewById(r7)
            r5.setVisibility(r14)
            goto L_0x0298
        L_0x0223:
            android.view.Window r5 = r0.f232c
            r9 = 16908294(0x1020006, float:2.3877246E-38)
            android.view.View r5 = r5.findViewById(r9)
            android.widget.ImageView r5 = (android.widget.ImageView) r5
            r0.f215D = r5
            java.lang.CharSequence r5 = r0.f234e
            boolean r5 = android.text.TextUtils.isEmpty(r5)
            r9 = 1
            r5 = r5 ^ r9
            if (r5 == 0) goto L_0x0287
            boolean r5 = r0.f227P
            if (r5 == 0) goto L_0x0287
            android.view.Window r5 = r0.f232c
            r7 = 2131361886(0x7f0a005e, float:1.8343537E38)
            android.view.View r5 = r5.findViewById(r7)
            android.widget.TextView r5 = (android.widget.TextView) r5
            r0.f216E = r5
            java.lang.CharSequence r7 = r0.f234e
            r5.setText(r7)
            int r5 = r0.f213B
            if (r5 == 0) goto L_0x025a
            android.widget.ImageView r7 = r0.f215D
            r7.setImageResource(r5)
            goto L_0x0298
        L_0x025a:
            android.graphics.drawable.Drawable r5 = r0.f214C
            if (r5 == 0) goto L_0x0264
            android.widget.ImageView r7 = r0.f215D
            r7.setImageDrawable(r5)
            goto L_0x0298
        L_0x0264:
            android.widget.TextView r5 = r0.f216E
            android.widget.ImageView r7 = r0.f215D
            int r7 = r7.getPaddingLeft()
            android.widget.ImageView r9 = r0.f215D
            int r9 = r9.getPaddingTop()
            android.widget.ImageView r11 = r0.f215D
            int r11 = r11.getPaddingRight()
            android.widget.ImageView r12 = r0.f215D
            int r12 = r12.getPaddingBottom()
            r5.setPadding(r7, r9, r11, r12)
            android.widget.ImageView r5 = r0.f215D
            r5.setVisibility(r14)
            goto L_0x0298
        L_0x0287:
            android.view.Window r5 = r0.f232c
            android.view.View r5 = r5.findViewById(r7)
            r5.setVisibility(r14)
            android.widget.ImageView r5 = r0.f215D
            r5.setVisibility(r14)
            r2.setVisibility(r14)
        L_0x0298:
            int r1 = r1.getVisibility()
            if (r1 == r14) goto L_0x02a0
            r11 = 1
            goto L_0x02a1
        L_0x02a0:
            r11 = 0
        L_0x02a1:
            if (r2 == 0) goto L_0x02ab
            int r1 = r2.getVisibility()
            if (r1 == r14) goto L_0x02ab
            r1 = 1
            goto L_0x02ac
        L_0x02ab:
            r1 = 0
        L_0x02ac:
            int r4 = r4.getVisibility()
            if (r4 == r14) goto L_0x02b4
            r4 = 1
            goto L_0x02b5
        L_0x02b4:
            r4 = 0
        L_0x02b5:
            if (r4 != 0) goto L_0x02c3
            r5 = 2131362842(0x7f0a041a, float:1.8345476E38)
            android.view.View r5 = r3.findViewById(r5)
            if (r5 == 0) goto L_0x02c3
            r5.setVisibility(r10)
        L_0x02c3:
            if (r1 == 0) goto L_0x02e5
            androidx.core.widget.NestedScrollView r5 = r0.f212A
            if (r5 == 0) goto L_0x02cd
            r7 = 1
            r5.setClipToPadding(r7)
        L_0x02cd:
            java.lang.CharSequence r5 = r0.f235f
            if (r5 != 0) goto L_0x02d8
            android.widget.ListView r5 = r0.f236g
            if (r5 == 0) goto L_0x02d6
            goto L_0x02d8
        L_0x02d6:
            r7 = r8
            goto L_0x02df
        L_0x02d8:
            r5 = 2131362864(0x7f0a0430, float:1.834552E38)
            android.view.View r7 = r2.findViewById(r5)
        L_0x02df:
            if (r7 == 0) goto L_0x02f1
            r7.setVisibility(r10)
            goto L_0x02f1
        L_0x02e5:
            r2 = 2131362843(0x7f0a041b, float:1.8345478E38)
            android.view.View r2 = r3.findViewById(r2)
            if (r2 == 0) goto L_0x02f1
            r2.setVisibility(r10)
        L_0x02f1:
            android.widget.ListView r2 = r0.f236g
            boolean r5 = r2 instanceof androidx.appcompat.app.AlertController.RecycleListView
            if (r5 == 0) goto L_0x02fc
            androidx.appcompat.app.AlertController$RecycleListView r2 = (androidx.appcompat.app.AlertController.RecycleListView) r2
            r2.mo422a(r1, r4)
        L_0x02fc:
            if (r11 != 0) goto L_0x0387
            android.widget.ListView r2 = r0.f236g
            if (r2 == 0) goto L_0x0303
            goto L_0x0305
        L_0x0303:
            androidx.core.widget.NestedScrollView r2 = r0.f212A
        L_0x0305:
            if (r2 == 0) goto L_0x0387
            if (r4 == 0) goto L_0x030a
            r10 = 2
        L_0x030a:
            r1 = r1 | r10
            r4 = 3
            android.view.Window r5 = r0.f232c
            r7 = 2131362710(0x7f0a0396, float:1.8345208E38)
            android.view.View r7 = r5.findViewById(r7)
            android.view.Window r5 = r0.f232c
            r9 = 2131362709(0x7f0a0395, float:1.8345206E38)
            android.view.View r5 = r5.findViewById(r9)
            int r9 = android.os.Build.VERSION.SDK_INT
            r10 = 23
            if (r9 < r10) goto L_0x0333
            int r6 = p098d.p120g.p130j.C4761m.f17241f
            if (r9 < r10) goto L_0x032b
            r2.setScrollIndicators(r1, r4)
        L_0x032b:
            if (r7 == 0) goto L_0x0330
            r3.removeView(r7)
        L_0x0330:
            if (r5 == 0) goto L_0x0387
            goto L_0x0384
        L_0x0333:
            if (r7 == 0) goto L_0x033d
            r2 = r1 & 1
            if (r2 != 0) goto L_0x033d
            r3.removeView(r7)
            r7 = r8
        L_0x033d:
            if (r5 == 0) goto L_0x0347
            r1 = r1 & r6
            if (r1 != 0) goto L_0x0347
            r3.removeView(r5)
            r9 = r8
            goto L_0x0348
        L_0x0347:
            r9 = r5
        L_0x0348:
            if (r7 != 0) goto L_0x034c
            if (r9 == 0) goto L_0x0387
        L_0x034c:
            java.lang.CharSequence r1 = r0.f235f
            if (r1 == 0) goto L_0x0365
            androidx.core.widget.NestedScrollView r1 = r0.f212A
            androidx.appcompat.app.a r2 = new androidx.appcompat.app.a
            r2.<init>(r0, r7, r9)
            r1.mo2374C(r2)
            androidx.core.widget.NestedScrollView r1 = r0.f212A
            androidx.appcompat.app.b r2 = new androidx.appcompat.app.b
            r2.<init>(r0, r7, r9)
            r1.post(r2)
            goto L_0x0387
        L_0x0365:
            android.widget.ListView r1 = r0.f236g
            if (r1 == 0) goto L_0x037c
            androidx.appcompat.app.c r2 = new androidx.appcompat.app.c
            r2.<init>(r0, r7, r9)
            r1.setOnScrollListener(r2)
            android.widget.ListView r1 = r0.f236g
            androidx.appcompat.app.d r2 = new androidx.appcompat.app.d
            r2.<init>(r0, r7, r9)
            r1.post(r2)
            goto L_0x0387
        L_0x037c:
            if (r7 == 0) goto L_0x0381
            r3.removeView(r7)
        L_0x0381:
            if (r9 == 0) goto L_0x0387
            r5 = r9
        L_0x0384:
            r3.removeView(r5)
        L_0x0387:
            android.widget.ListView r1 = r0.f236g
            if (r1 == 0) goto L_0x039d
            android.widget.ListAdapter r2 = r0.f219H
            if (r2 == 0) goto L_0x039d
            r1.setAdapter(r2)
            int r2 = r0.f220I
            if (r2 <= r13) goto L_0x039d
            r3 = 1
            r1.setItemChecked(r2, r3)
            r1.setSelection(r2)
        L_0x039d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AlertController.mo418c():void");
    }

    /* renamed from: f */
    public void mo419f(View view) {
        this.f218G = view;
    }

    /* renamed from: g */
    public void mo420g(Drawable drawable) {
        this.f214C = drawable;
        this.f213B = 0;
        ImageView imageView = this.f215D;
        if (imageView == null) {
            return;
        }
        if (drawable != null) {
            imageView.setVisibility(0);
            this.f215D.setImageDrawable(drawable);
            return;
        }
        imageView.setVisibility(8);
    }

    /* renamed from: h */
    public void mo421h(CharSequence charSequence) {
        this.f234e = charSequence;
        TextView textView = this.f216E;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }
}
