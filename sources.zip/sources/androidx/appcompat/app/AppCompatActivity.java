package androidx.appcompat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.C0275k0;
import androidx.core.app.C0441a;
import androidx.core.app.C0470o;
import androidx.fragment.app.FragmentActivity;
import p098d.p099a.p106g.C4589b;
import p098d.p120g.C4690a;

public class AppCompatActivity extends FragmentActivity implements C0130g, C0470o.C0471a {

    /* renamed from: m */
    private C0131h f270m;

    /* renamed from: I0 */
    public void mo427I0() {
        mo428J0().mo486k();
    }

    /* renamed from: J0 */
    public C0131h mo428J0() {
        if (this.f270m == null) {
            int i = C0131h.f384c;
            this.f270m = new AppCompatDelegateImpl((Activity) this, (C0130g) this);
        }
        return this.f270m;
    }

    /* renamed from: K0 */
    public ActionBar mo429K0() {
        return mo428J0().mo484i();
    }

    /* access modifiers changed from: protected */
    /* renamed from: L0 */
    public void mo430L0() {
    }

    /* renamed from: M */
    public Intent mo431M() {
        return C4690a.m17116g(this);
    }

    /* renamed from: M0 */
    public void mo432M0() {
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        mo428J0().mo478d(view, layoutParams);
    }

    /* access modifiers changed from: protected */
    public void attachBaseContext(Context context) {
        super.attachBaseContext(mo428J0().mo479e(context));
    }

    public void closeOptionsMenu() {
        ActionBar K0 = mo429K0();
        if (getWindow().hasFeature(0)) {
            super.closeOptionsMenu();
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        ActionBar K0 = mo429K0();
        return super.dispatchKeyEvent(keyEvent);
    }

    public <T extends View> T findViewById(int i) {
        return mo428J0().mo481f(i);
    }

    public MenuInflater getMenuInflater() {
        return mo428J0().mo483h();
    }

    public Resources getResources() {
        int i = C0275k0.f1170a;
        return super.getResources();
    }

    public void invalidateOptionsMenu() {
        mo428J0().mo486k();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        mo428J0().mo487l(configuration);
    }

    public void onContentChanged() {
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        C0131h J0 = mo428J0();
        J0.mo485j();
        J0.mo488m(bundle);
        super.onCreate(bundle);
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        mo428J0().mo489n();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0027, code lost:
        r0 = getWindow();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onKeyDown(int r4, android.view.KeyEvent r5) {
        /*
            r3 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 26
            r2 = 1
            if (r0 >= r1) goto L_0x003f
            boolean r0 = r5.isCtrlPressed()
            if (r0 != 0) goto L_0x003f
            int r0 = r5.getMetaState()
            boolean r0 = android.view.KeyEvent.metaStateHasNoModifiers(r0)
            if (r0 != 0) goto L_0x003f
            int r0 = r5.getRepeatCount()
            if (r0 != 0) goto L_0x003f
            int r0 = r5.getKeyCode()
            boolean r0 = android.view.KeyEvent.isModifierKey(r0)
            if (r0 != 0) goto L_0x003f
            android.view.Window r0 = r3.getWindow()
            if (r0 == 0) goto L_0x003f
            android.view.View r1 = r0.getDecorView()
            if (r1 == 0) goto L_0x003f
            android.view.View r0 = r0.getDecorView()
            boolean r0 = r0.dispatchKeyShortcutEvent(r5)
            if (r0 == 0) goto L_0x003f
            r0 = 1
            goto L_0x0040
        L_0x003f:
            r0 = 0
        L_0x0040:
            if (r0 == 0) goto L_0x0043
            return r2
        L_0x0043:
            boolean r4 = super.onKeyDown(r4, r5)
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AppCompatActivity.onKeyDown(int, android.view.KeyEvent):boolean");
    }

    public final boolean onMenuItemSelected(int i, MenuItem menuItem) {
        Intent g;
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        ActionBar K0 = mo429K0();
        if (menuItem.getItemId() != 16908332 || K0 == null || (((C0144q) K0).f417g.mo1640r() & 4) == 0 || (g = C4690a.m17116g(this)) == null) {
            return false;
        }
        if (shouldUpRecreateTask(g)) {
            C0470o c = C0470o.m2151c(this);
            c.mo2287b(this);
            mo432M0();
            c.mo2288e();
            try {
                int i2 = C0441a.f2105c;
                finishAffinity();
                return true;
            } catch (IllegalStateException unused) {
                finish();
                return true;
            }
        } else {
            navigateUpTo(g);
            return true;
        }
    }

    public boolean onMenuOpened(int i, Menu menu) {
        return super.onMenuOpened(i, menu);
    }

    public void onPanelClosed(int i, Menu menu) {
        super.onPanelClosed(i, menu);
    }

    /* access modifiers changed from: protected */
    public void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        mo428J0().mo490o(bundle);
    }

    /* access modifiers changed from: protected */
    public void onPostResume() {
        super.onPostResume();
        mo428J0().mo493p();
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        mo428J0().mo494q(bundle);
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        mo428J0().mo495r();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        mo428J0().mo496s();
    }

    public void onSupportActionModeFinished(C4589b bVar) {
    }

    public void onSupportActionModeStarted(C4589b bVar) {
    }

    /* access modifiers changed from: protected */
    public void onTitleChanged(CharSequence charSequence, int i) {
        super.onTitleChanged(charSequence, i);
        mo428J0().mo457A(charSequence);
    }

    public C4589b onWindowStartingSupportActionMode(C4589b.C4590a aVar) {
        return null;
    }

    public void openOptionsMenu() {
        ActionBar K0 = mo429K0();
        if (getWindow().hasFeature(0)) {
            super.openOptionsMenu();
        }
    }

    public void setContentView(int i) {
        mo428J0().mo498w(i);
    }

    public void setContentView(View view) {
        mo428J0().mo499x(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        mo428J0().mo500y(view, layoutParams);
    }

    public void setTheme(int i) {
        super.setTheme(i);
        mo428J0().mo501z(i);
    }
}
