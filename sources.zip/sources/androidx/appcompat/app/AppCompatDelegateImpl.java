package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.LongSparseArray;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.app.C0144q;
import androidx.appcompat.view.menu.C0160e;
import androidx.appcompat.view.menu.C0163g;
import androidx.appcompat.view.menu.C0178m;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.C0257e;
import androidx.appcompat.widget.C0259e0;
import androidx.appcompat.widget.C0275k0;
import androidx.appcompat.widget.C0280l0;
import androidx.appcompat.widget.C0281m;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.core.content.C0474a;
import androidx.core.content.p005b.C0476a;
import com.vidio.android.p195tv.R;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Objects;
import p098d.p099a.C4568b;
import p098d.p099a.p100c.p101a.C4569a;
import p098d.p099a.p106g.C4589b;
import p098d.p099a.p106g.C4592d;
import p098d.p099a.p106g.C4594f;
import p098d.p099a.p106g.C4596g;
import p098d.p099a.p106g.C4601i;
import p098d.p112d.C4631j;
import p098d.p120g.C4690a;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.C4774r;
import p098d.p120g.p130j.C4777s;
import p098d.p120g.p130j.C4778t;
import p098d.p120g.p130j.C4780v;
import p165e.p166a.p167a.p168a.C4924a;

class AppCompatDelegateImpl extends C0131h implements C0163g.C0164a, LayoutInflater.Factory2 {

    /* renamed from: d */
    private static final C4631j<String, Integer> f271d = new C4631j<>();

    /* renamed from: e */
    private static final int[] f272e = {16842836};

    /* renamed from: f */
    private static final boolean f273f = (!"robolectric".equals(Build.FINGERPRINT));

    /* renamed from: g */
    private static final boolean f274g = true;

    /* renamed from: A */
    private TextView f275A;

    /* renamed from: B */
    private View f276B;

    /* renamed from: C */
    private boolean f277C;

    /* renamed from: D */
    private boolean f278D;

    /* renamed from: E */
    boolean f279E;

    /* renamed from: F */
    boolean f280F;

    /* renamed from: G */
    boolean f281G;

    /* renamed from: H */
    boolean f282H;

    /* renamed from: I */
    boolean f283I;

    /* renamed from: J */
    private boolean f284J;

    /* renamed from: K */
    private PanelFeatureState[] f285K;

    /* renamed from: L */
    private PanelFeatureState f286L;

    /* renamed from: M */
    private boolean f287M;

    /* renamed from: N */
    private boolean f288N;

    /* renamed from: O */
    private boolean f289O;

    /* renamed from: P */
    private boolean f290P;

    /* renamed from: Q */
    boolean f291Q;

    /* renamed from: R */
    private int f292R;

    /* renamed from: Z */
    private int f293Z;

    /* renamed from: a0 */
    private boolean f294a0;

    /* renamed from: b0 */
    private boolean f295b0;

    /* renamed from: c0 */
    private C0117f f296c0;

    /* renamed from: d0 */
    private C0117f f297d0;

    /* renamed from: e0 */
    boolean f298e0;

    /* renamed from: f0 */
    int f299f0;

    /* renamed from: g0 */
    private final Runnable f300g0;

    /* renamed from: h */
    final Object f301h;

    /* renamed from: h0 */
    private boolean f302h0;

    /* renamed from: i */
    final Context f303i;

    /* renamed from: i0 */
    private Rect f304i0;

    /* renamed from: j */
    Window f305j;

    /* renamed from: j0 */
    private Rect f306j0;

    /* renamed from: k */
    private C0115d f307k;

    /* renamed from: k0 */
    private C0139n f308k0;

    /* renamed from: l */
    final C0130g f309l;

    /* renamed from: m */
    ActionBar f310m;

    /* renamed from: n */
    MenuInflater f311n;

    /* renamed from: o */
    private CharSequence f312o;

    /* renamed from: p */
    private C0281m f313p;

    /* renamed from: q */
    private C0112b f314q;

    /* renamed from: r */
    private C0122j f315r;

    /* renamed from: s */
    C4589b f316s;

    /* renamed from: t */
    ActionBarContextView f317t;

    /* renamed from: u */
    PopupWindow f318u;

    /* renamed from: v */
    Runnable f319v;

    /* renamed from: w */
    C4774r f320w;

    /* renamed from: x */
    private boolean f321x;

    /* renamed from: y */
    private boolean f322y;

    /* renamed from: z */
    ViewGroup f323z;

    protected static final class PanelFeatureState {

        /* renamed from: a */
        int f324a;

        /* renamed from: b */
        int f325b;

        /* renamed from: c */
        int f326c;

        /* renamed from: d */
        int f327d;

        /* renamed from: e */
        ViewGroup f328e;

        /* renamed from: f */
        View f329f;

        /* renamed from: g */
        View f330g;

        /* renamed from: h */
        C0163g f331h;

        /* renamed from: i */
        C0160e f332i;

        /* renamed from: j */
        Context f333j;

        /* renamed from: k */
        boolean f334k;

        /* renamed from: l */
        boolean f335l;

        /* renamed from: m */
        boolean f336m;

        /* renamed from: n */
        public boolean f337n;

        /* renamed from: o */
        boolean f338o = false;

        /* renamed from: p */
        boolean f339p;

        /* renamed from: q */
        Bundle f340q;

        private static class SavedState implements Parcelable {
            public static final Parcelable.Creator<SavedState> CREATOR = new C0110a();

            /* renamed from: a */
            int f341a;

            /* renamed from: b */
            boolean f342b;

            /* renamed from: c */
            Bundle f343c;

            /* renamed from: androidx.appcompat.app.AppCompatDelegateImpl$PanelFeatureState$SavedState$a */
            class C0110a implements Parcelable.ClassLoaderCreator<SavedState> {
                C0110a() {
                }

                public Object createFromParcel(Parcel parcel) {
                    return SavedState.m483a(parcel, (ClassLoader) null);
                }

                public Object[] newArray(int i) {
                    return new SavedState[i];
                }

                public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                    return SavedState.m483a(parcel, classLoader);
                }
            }

            SavedState() {
            }

            /* renamed from: a */
            static SavedState m483a(Parcel parcel, ClassLoader classLoader) {
                SavedState savedState = new SavedState();
                savedState.f341a = parcel.readInt();
                boolean z = true;
                if (parcel.readInt() != 1) {
                    z = false;
                }
                savedState.f342b = z;
                if (z) {
                    savedState.f343c = parcel.readBundle(classLoader);
                }
                return savedState;
            }

            public int describeContents() {
                return 0;
            }

            public void writeToParcel(Parcel parcel, int i) {
                parcel.writeInt(this.f341a);
                parcel.writeInt(this.f342b ? 1 : 0);
                if (this.f342b) {
                    parcel.writeBundle(this.f343c);
                }
            }
        }

        PanelFeatureState(int i) {
            this.f324a = i;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo502a(C0163g gVar) {
            C0160e eVar;
            C0163g gVar2 = this.f331h;
            if (gVar != gVar2) {
                if (gVar2 != null) {
                    gVar2.mo753B(this.f332i);
                }
                this.f331h = gVar;
                if (gVar != null && (eVar = this.f332i) != null) {
                    gVar.mo779b(eVar);
                }
            }
        }
    }

    /* renamed from: androidx.appcompat.app.AppCompatDelegateImpl$a */
    class C0111a implements Runnable {
        C0111a() {
        }

        public void run() {
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if ((appCompatDelegateImpl.f299f0 & 1) != 0) {
                appCompatDelegateImpl.mo464K(0);
            }
            AppCompatDelegateImpl appCompatDelegateImpl2 = AppCompatDelegateImpl.this;
            if ((appCompatDelegateImpl2.f299f0 & 4096) != 0) {
                appCompatDelegateImpl2.mo464K(108);
            }
            AppCompatDelegateImpl appCompatDelegateImpl3 = AppCompatDelegateImpl.this;
            appCompatDelegateImpl3.f298e0 = false;
            appCompatDelegateImpl3.f299f0 = 0;
        }
    }

    /* renamed from: androidx.appcompat.app.AppCompatDelegateImpl$b */
    private final class C0112b implements C0178m.C0179a {
        C0112b() {
        }

        /* renamed from: b */
        public void mo509b(C0163g gVar, boolean z) {
            AppCompatDelegateImpl.this.mo460F(gVar);
        }

        /* renamed from: c */
        public boolean mo510c(C0163g gVar) {
            Window.Callback Q = AppCompatDelegateImpl.this.mo468Q();
            if (Q == null) {
                return true;
            }
            Q.onMenuOpened(108, gVar);
            return true;
        }
    }

    /* renamed from: androidx.appcompat.app.AppCompatDelegateImpl$c */
    class C0113c implements C4589b.C4590a {

        /* renamed from: a */
        private C4589b.C4590a f346a;

        /* renamed from: androidx.appcompat.app.AppCompatDelegateImpl$c$a */
        class C0114a extends C4778t {
            C0114a() {
            }

            /* renamed from: b */
            public void mo515b(View view) {
                AppCompatDelegateImpl.this.f317t.setVisibility(8);
                AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
                PopupWindow popupWindow = appCompatDelegateImpl.f318u;
                if (popupWindow != null) {
                    popupWindow.dismiss();
                } else if (appCompatDelegateImpl.f317t.getParent() instanceof View) {
                    int i = C4761m.f17241f;
                    ((View) AppCompatDelegateImpl.this.f317t.getParent()).requestApplyInsets();
                }
                AppCompatDelegateImpl.this.f317t.removeAllViews();
                AppCompatDelegateImpl.this.f320w.mo21879f((C4777s) null);
                AppCompatDelegateImpl appCompatDelegateImpl2 = AppCompatDelegateImpl.this;
                appCompatDelegateImpl2.f320w = null;
                ViewGroup viewGroup = appCompatDelegateImpl2.f323z;
                int i2 = C4761m.f17241f;
                viewGroup.requestApplyInsets();
            }
        }

        public C0113c(C4589b.C4590a aVar) {
            this.f346a = aVar;
        }

        /* renamed from: a */
        public void mo511a(C4589b bVar) {
            this.f346a.mo511a(bVar);
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if (appCompatDelegateImpl.f318u != null) {
                appCompatDelegateImpl.f305j.getDecorView().removeCallbacks(AppCompatDelegateImpl.this.f319v);
            }
            AppCompatDelegateImpl appCompatDelegateImpl2 = AppCompatDelegateImpl.this;
            if (appCompatDelegateImpl2.f317t != null) {
                appCompatDelegateImpl2.mo465L();
                AppCompatDelegateImpl appCompatDelegateImpl3 = AppCompatDelegateImpl.this;
                C4774r a = C4761m.m17292a(appCompatDelegateImpl3.f317t);
                a.mo21874a(0.0f);
                appCompatDelegateImpl3.f320w = a;
                AppCompatDelegateImpl.this.f320w.mo21879f(new C0114a());
            }
            AppCompatDelegateImpl appCompatDelegateImpl4 = AppCompatDelegateImpl.this;
            C0130g gVar = appCompatDelegateImpl4.f309l;
            if (gVar != null) {
                gVar.onSupportActionModeFinished(appCompatDelegateImpl4.f316s);
            }
            AppCompatDelegateImpl appCompatDelegateImpl5 = AppCompatDelegateImpl.this;
            appCompatDelegateImpl5.f316s = null;
            ViewGroup viewGroup = appCompatDelegateImpl5.f323z;
            int i = C4761m.f17241f;
            viewGroup.requestApplyInsets();
        }

        /* renamed from: b */
        public boolean mo512b(C4589b bVar, Menu menu) {
            return this.f346a.mo512b(bVar, menu);
        }

        /* renamed from: c */
        public boolean mo513c(C4589b bVar, Menu menu) {
            ViewGroup viewGroup = AppCompatDelegateImpl.this.f323z;
            int i = C4761m.f17241f;
            viewGroup.requestApplyInsets();
            return this.f346a.mo513c(bVar, menu);
        }

        /* renamed from: d */
        public boolean mo514d(C4589b bVar, MenuItem menuItem) {
            return this.f346a.mo514d(bVar, menuItem);
        }
    }

    /* renamed from: androidx.appcompat.app.AppCompatDelegateImpl$d */
    class C0115d extends C4601i {
        C0115d(Window.Callback callback) {
            super(callback);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public final ActionMode mo516b(ActionMode.Callback callback) {
            C4594f.C4595a aVar = new C4594f.C4595a(AppCompatDelegateImpl.this.f303i, callback);
            C4589b c0 = AppCompatDelegateImpl.this.mo477c0(aVar);
            if (c0 != null) {
                return aVar.mo21247e(c0);
            }
            return null;
        }

        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return AppCompatDelegateImpl.this.mo463J(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
            return super.dispatchKeyShortcutEvent(keyEvent) || AppCompatDelegateImpl.this.mo471V(keyEvent.getKeyCode(), keyEvent);
        }

        public void onContentChanged() {
        }

        public boolean onCreatePanelMenu(int i, Menu menu) {
            if (i != 0 || (menu instanceof C0163g)) {
                return super.onCreatePanelMenu(i, menu);
            }
            return false;
        }

        public boolean onMenuOpened(int i, Menu menu) {
            super.onMenuOpened(i, menu);
            AppCompatDelegateImpl.this.mo472W(i);
            return true;
        }

        public void onPanelClosed(int i, Menu menu) {
            super.onPanelClosed(i, menu);
            AppCompatDelegateImpl.this.mo473X(i);
        }

        public boolean onPreparePanel(int i, View view, Menu menu) {
            C0163g gVar = menu instanceof C0163g ? (C0163g) menu : null;
            if (i == 0 && gVar == null) {
                return false;
            }
            if (gVar != null) {
                gVar.mo766P(true);
            }
            boolean onPreparePanel = super.onPreparePanel(i, view, menu);
            if (gVar != null) {
                gVar.mo766P(false);
            }
            return onPreparePanel;
        }

        public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> list, Menu menu, int i) {
            C0163g gVar = AppCompatDelegateImpl.this.mo467P(0).f331h;
            if (gVar != null) {
                super.onProvideKeyboardShortcuts(list, gVar, i);
            } else {
                super.onProvideKeyboardShortcuts(list, menu, i);
            }
        }

        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
            if (Build.VERSION.SDK_INT >= 23) {
                return null;
            }
            return AppCompatDelegateImpl.this.mo469T() ? mo516b(callback) : super.onWindowStartingActionMode(callback);
        }

        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int i) {
            return (!AppCompatDelegateImpl.this.mo469T() || i != 0) ? super.onWindowStartingActionMode(callback, i) : mo516b(callback);
        }
    }

    /* renamed from: androidx.appcompat.app.AppCompatDelegateImpl$e */
    private class C0116e extends C0117f {

        /* renamed from: c */
        private final PowerManager f350c;

        C0116e(Context context) {
            super();
            this.f350c = (PowerManager) context.getApplicationContext().getSystemService("power");
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public IntentFilter mo527b() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
            return intentFilter;
        }

        /* renamed from: c */
        public int mo528c() {
            return this.f350c.isPowerSaveMode() ? 2 : 1;
        }

        /* renamed from: d */
        public void mo529d() {
            AppCompatDelegateImpl.this.mo458B();
        }
    }

    /* renamed from: androidx.appcompat.app.AppCompatDelegateImpl$f */
    abstract class C0117f {

        /* renamed from: a */
        private BroadcastReceiver f352a;

        /* renamed from: androidx.appcompat.app.AppCompatDelegateImpl$f$a */
        class C0118a extends BroadcastReceiver {
            C0118a() {
            }

            public void onReceive(Context context, Intent intent) {
                C0117f.this.mo529d();
            }
        }

        C0117f() {
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo530a() {
            BroadcastReceiver broadcastReceiver = this.f352a;
            if (broadcastReceiver != null) {
                try {
                    AppCompatDelegateImpl.this.f303i.unregisterReceiver(broadcastReceiver);
                } catch (IllegalArgumentException unused) {
                }
                this.f352a = null;
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public abstract IntentFilter mo527b();

        /* access modifiers changed from: package-private */
        /* renamed from: c */
        public abstract int mo528c();

        /* access modifiers changed from: package-private */
        /* renamed from: d */
        public abstract void mo529d();

        /* access modifiers changed from: package-private */
        /* renamed from: e */
        public void mo531e() {
            mo530a();
            IntentFilter b = mo527b();
            if (b != null && b.countActions() != 0) {
                if (this.f352a == null) {
                    this.f352a = new C0118a();
                }
                AppCompatDelegateImpl.this.f303i.registerReceiver(this.f352a, b);
            }
        }
    }

    /* renamed from: androidx.appcompat.app.AppCompatDelegateImpl$g */
    private class C0119g extends C0117f {

        /* renamed from: c */
        private final C0142p f355c;

        C0119g(C0142p pVar) {
            super();
            this.f355c = pVar;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public IntentFilter mo527b() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.TIME_SET");
            intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
            intentFilter.addAction("android.intent.action.TIME_TICK");
            return intentFilter;
        }

        /* renamed from: c */
        public int mo528c() {
            return this.f355c.mo584c() ? 2 : 1;
        }

        /* renamed from: d */
        public void mo529d() {
            AppCompatDelegateImpl.this.mo458B();
        }
    }

    /* renamed from: androidx.appcompat.app.AppCompatDelegateImpl$h */
    static class C0120h {

        /* renamed from: a */
        private static Field f357a;

        /* renamed from: b */
        private static boolean f358b;

        /* renamed from: c */
        private static Class<?> f359c;

        /* renamed from: d */
        private static boolean f360d;

        /* renamed from: e */
        private static Field f361e;

        /* renamed from: f */
        private static boolean f362f;

        /* renamed from: g */
        private static Field f363g;

        /* renamed from: h */
        private static boolean f364h;

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v0, resolved type: java.util.Map} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v1, resolved type: java.util.Map} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v2, resolved type: java.util.Map} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v3, resolved type: java.util.Map} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v4, resolved type: java.lang.Object} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v5, resolved type: java.util.Map} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v6, resolved type: java.lang.Object} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v7, resolved type: java.util.Map} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v8, resolved type: java.util.Map} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        static void m503a(android.content.res.Resources r8) {
            /*
                int r0 = android.os.Build.VERSION.SDK_INT
                r1 = 28
                if (r0 < r1) goto L_0x0007
                return
            L_0x0007:
                r1 = 24
                java.lang.String r2 = "mDrawableCache"
                r3 = 0
                java.lang.String r4 = "ResourcesFlusher"
                r5 = 1
                if (r0 < r1) goto L_0x0070
                boolean r0 = f364h
                if (r0 != 0) goto L_0x002b
                java.lang.Class<android.content.res.Resources> r0 = android.content.res.Resources.class
                java.lang.String r1 = "mResourcesImpl"
                java.lang.reflect.Field r0 = r0.getDeclaredField(r1)     // Catch:{ NoSuchFieldException -> 0x0023 }
                f363g = r0     // Catch:{ NoSuchFieldException -> 0x0023 }
                r0.setAccessible(r5)     // Catch:{ NoSuchFieldException -> 0x0023 }
                goto L_0x0029
            L_0x0023:
                r0 = move-exception
                java.lang.String r1 = "Could not retrieve Resources#mResourcesImpl field"
                android.util.Log.e(r4, r1, r0)
            L_0x0029:
                f364h = r5
            L_0x002b:
                java.lang.reflect.Field r0 = f363g
                if (r0 != 0) goto L_0x0031
                goto L_0x00cd
            L_0x0031:
                java.lang.Object r8 = r0.get(r8)     // Catch:{ IllegalAccessException -> 0x0036 }
                goto L_0x003d
            L_0x0036:
                r8 = move-exception
                java.lang.String r0 = "Could not retrieve value from Resources#mResourcesImpl"
                android.util.Log.e(r4, r0, r8)
                r8 = r3
            L_0x003d:
                if (r8 != 0) goto L_0x0041
                goto L_0x00cd
            L_0x0041:
                boolean r0 = f358b
                if (r0 != 0) goto L_0x005b
                java.lang.Class r0 = r8.getClass()     // Catch:{ NoSuchFieldException -> 0x0053 }
                java.lang.reflect.Field r0 = r0.getDeclaredField(r2)     // Catch:{ NoSuchFieldException -> 0x0053 }
                f357a = r0     // Catch:{ NoSuchFieldException -> 0x0053 }
                r0.setAccessible(r5)     // Catch:{ NoSuchFieldException -> 0x0053 }
                goto L_0x0059
            L_0x0053:
                r0 = move-exception
                java.lang.String r1 = "Could not retrieve ResourcesImpl#mDrawableCache field"
                android.util.Log.e(r4, r1, r0)
            L_0x0059:
                f358b = r5
            L_0x005b:
                java.lang.reflect.Field r0 = f357a
                if (r0 == 0) goto L_0x006a
                java.lang.Object r3 = r0.get(r8)     // Catch:{ IllegalAccessException -> 0x0064 }
                goto L_0x006a
            L_0x0064:
                r8 = move-exception
                java.lang.String r0 = "Could not retrieve value from ResourcesImpl#mDrawableCache"
                android.util.Log.e(r4, r0, r8)
            L_0x006a:
                if (r3 == 0) goto L_0x00cd
                m504b(r3)
                goto L_0x00cd
            L_0x0070:
                r1 = 23
                java.lang.String r6 = "Could not retrieve Resources#mDrawableCache field"
                java.lang.String r7 = "Could not retrieve value from Resources#mDrawableCache"
                if (r0 < r1) goto L_0x00a2
                boolean r0 = f358b
                if (r0 != 0) goto L_0x008e
                java.lang.Class<android.content.res.Resources> r0 = android.content.res.Resources.class
                java.lang.reflect.Field r0 = r0.getDeclaredField(r2)     // Catch:{ NoSuchFieldException -> 0x0088 }
                f357a = r0     // Catch:{ NoSuchFieldException -> 0x0088 }
                r0.setAccessible(r5)     // Catch:{ NoSuchFieldException -> 0x0088 }
                goto L_0x008c
            L_0x0088:
                r0 = move-exception
                android.util.Log.e(r4, r6, r0)
            L_0x008c:
                f358b = r5
            L_0x008e:
                java.lang.reflect.Field r0 = f357a
                if (r0 == 0) goto L_0x009b
                java.lang.Object r3 = r0.get(r8)     // Catch:{ IllegalAccessException -> 0x0097 }
                goto L_0x009b
            L_0x0097:
                r8 = move-exception
                android.util.Log.e(r4, r7, r8)
            L_0x009b:
                if (r3 != 0) goto L_0x009e
                goto L_0x00cd
            L_0x009e:
                m504b(r3)
                goto L_0x00cd
            L_0x00a2:
                boolean r0 = f358b
                if (r0 != 0) goto L_0x00b8
                java.lang.Class<android.content.res.Resources> r0 = android.content.res.Resources.class
                java.lang.reflect.Field r0 = r0.getDeclaredField(r2)     // Catch:{ NoSuchFieldException -> 0x00b2 }
                f357a = r0     // Catch:{ NoSuchFieldException -> 0x00b2 }
                r0.setAccessible(r5)     // Catch:{ NoSuchFieldException -> 0x00b2 }
                goto L_0x00b6
            L_0x00b2:
                r0 = move-exception
                android.util.Log.e(r4, r6, r0)
            L_0x00b6:
                f358b = r5
            L_0x00b8:
                java.lang.reflect.Field r0 = f357a
                if (r0 == 0) goto L_0x00cd
                java.lang.Object r8 = r0.get(r8)     // Catch:{ IllegalAccessException -> 0x00c4 }
                java.util.Map r8 = (java.util.Map) r8     // Catch:{ IllegalAccessException -> 0x00c4 }
                r3 = r8
                goto L_0x00c8
            L_0x00c4:
                r8 = move-exception
                android.util.Log.e(r4, r7, r8)
            L_0x00c8:
                if (r3 == 0) goto L_0x00cd
                r3.clear()
            L_0x00cd:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AppCompatDelegateImpl.C0120h.m503a(android.content.res.Resources):void");
        }

        /* renamed from: b */
        private static void m504b(Object obj) {
            if (!f360d) {
                try {
                    f359c = Class.forName("android.content.res.ThemedResourceCache");
                } catch (ClassNotFoundException e) {
                    Log.e("ResourcesFlusher", "Could not find ThemedResourceCache class", e);
                }
                f360d = true;
            }
            Class<?> cls = f359c;
            if (cls != null) {
                if (!f362f) {
                    try {
                        Field declaredField = cls.getDeclaredField("mUnthemedEntries");
                        f361e = declaredField;
                        declaredField.setAccessible(true);
                    } catch (NoSuchFieldException e2) {
                        Log.e("ResourcesFlusher", "Could not retrieve ThemedResourceCache#mUnthemedEntries field", e2);
                    }
                    f362f = true;
                }
                Field field = f361e;
                if (field != null) {
                    LongSparseArray longSparseArray = null;
                    try {
                        longSparseArray = (LongSparseArray) field.get(obj);
                    } catch (IllegalAccessException e3) {
                        Log.e("ResourcesFlusher", "Could not retrieve value from ThemedResourceCache#mUnthemedEntries", e3);
                    }
                    if (longSparseArray != null) {
                        longSparseArray.clear();
                    }
                }
            }
        }
    }

    /* renamed from: androidx.appcompat.app.AppCompatDelegateImpl$i */
    private class C0121i extends ContentFrameLayout {
        public C0121i(Context context) {
            super(context, (AttributeSet) null);
        }

        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return AppCompatDelegateImpl.this.mo463J(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (motionEvent.getAction() == 0) {
                int x = (int) motionEvent.getX();
                int y = (int) motionEvent.getY();
                if (x < -5 || y < -5 || x > getWidth() + 5 || y > getHeight() + 5) {
                    AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
                    appCompatDelegateImpl.mo461G(appCompatDelegateImpl.mo467P(0), true);
                    return true;
                }
            }
            return super.onInterceptTouchEvent(motionEvent);
        }

        public void setBackgroundResource(int i) {
            setBackgroundDrawable(C4569a.m16431b(getContext(), i));
        }
    }

    /* renamed from: androidx.appcompat.app.AppCompatDelegateImpl$j */
    private final class C0122j implements C0178m.C0179a {
        C0122j() {
        }

        /* renamed from: b */
        public void mo509b(C0163g gVar, boolean z) {
            C0163g q = gVar.mo803q();
            boolean z2 = q != gVar;
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if (z2) {
                gVar = q;
            }
            PanelFeatureState O = appCompatDelegateImpl.mo466O(gVar);
            if (O == null) {
                return;
            }
            if (z2) {
                AppCompatDelegateImpl.this.mo459E(O.f324a, O, q);
                AppCompatDelegateImpl.this.mo461G(O, true);
                return;
            }
            AppCompatDelegateImpl.this.mo461G(O, z);
        }

        /* renamed from: c */
        public boolean mo510c(C0163g gVar) {
            Window.Callback Q;
            if (gVar != gVar.mo803q()) {
                return true;
            }
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if (!appCompatDelegateImpl.f279E || (Q = appCompatDelegateImpl.mo468Q()) == null || AppCompatDelegateImpl.this.f291Q) {
                return true;
            }
            Q.onMenuOpened(108, gVar);
            return true;
        }
    }

    AppCompatDelegateImpl(Activity activity, C0130g gVar) {
        this(activity, (Window) null, gVar, activity);
    }

    AppCompatDelegateImpl(Dialog dialog, C0130g gVar) {
        this(dialog.getContext(), dialog.getWindow(), gVar, dialog);
    }

    private AppCompatDelegateImpl(Context context, Window window, C0130g gVar, Object obj) {
        C4631j<String, Integer> jVar;
        Integer orDefault;
        AppCompatActivity appCompatActivity;
        this.f320w = null;
        this.f321x = true;
        this.f292R = -100;
        this.f300g0 = new C0111a();
        this.f303i = context;
        this.f309l = gVar;
        this.f301h = obj;
        if (obj instanceof Dialog) {
            while (true) {
                if (context != null) {
                    if (!(context instanceof AppCompatActivity)) {
                        if (!(context instanceof ContextWrapper)) {
                            break;
                        }
                        context = ((ContextWrapper) context).getBaseContext();
                    } else {
                        appCompatActivity = (AppCompatActivity) context;
                        break;
                    }
                } else {
                    break;
                }
            }
            appCompatActivity = null;
            if (appCompatActivity != null) {
                this.f292R = appCompatActivity.mo428J0().mo482g();
            }
        }
        if (this.f292R == -100 && (orDefault = jVar.getOrDefault(this.f301h.getClass().getName(), null)) != null) {
            this.f292R = orDefault.intValue();
            (jVar = f271d).remove(this.f301h.getClass().getName());
        }
        if (window != null) {
            m429D(window);
        }
        C0257e.m1168h();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:65:0x010f, code lost:
        if (r1 != false) goto L_0x0116;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x0114, code lost:
        if (r10.f290P != false) goto L_0x0116;
     */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00ad A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x011d  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x012a  */
    /* JADX WARNING: Removed duplicated region for block: B:79:0x0141  */
    /* JADX WARNING: Removed duplicated region for block: B:84:0x014b  */
    /* JADX WARNING: Removed duplicated region for block: B:88:0x015e  */
    /* renamed from: C */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean m428C(boolean r11) {
        /*
            r10 = this;
            boolean r0 = r10.f291Q
            r1 = 0
            if (r0 == 0) goto L_0x0006
            return r1
        L_0x0006:
            int r0 = r10.f292R
            r2 = -100
            if (r0 == r2) goto L_0x000d
            goto L_0x000f
        L_0x000d:
            r0 = -100
        L_0x000f:
            android.content.Context r2 = r10.f303i
            int r2 = r10.mo470U(r2, r0)
            android.content.Context r3 = r10.f303i
            r4 = 0
            android.content.res.Configuration r2 = r10.m430H(r3, r2, r4)
            boolean r3 = r10.f295b0
            r5 = 1
            if (r3 != 0) goto L_0x006b
            java.lang.Object r3 = r10.f301h
            boolean r3 = r3 instanceof android.app.Activity
            if (r3 == 0) goto L_0x006b
            android.content.Context r3 = r10.f303i
            android.content.pm.PackageManager r3 = r3.getPackageManager()
            if (r3 != 0) goto L_0x0031
            r3 = 0
            goto L_0x006f
        L_0x0031:
            int r6 = android.os.Build.VERSION.SDK_INT     // Catch:{ NameNotFoundException -> 0x0061 }
            r7 = 29
            if (r6 < r7) goto L_0x003a
            r6 = 269221888(0x100c0000, float:2.7610132E-29)
            goto L_0x0042
        L_0x003a:
            r7 = 24
            if (r6 < r7) goto L_0x0041
            r6 = 786432(0xc0000, float:1.102026E-39)
            goto L_0x0042
        L_0x0041:
            r6 = 0
        L_0x0042:
            android.content.ComponentName r7 = new android.content.ComponentName     // Catch:{ NameNotFoundException -> 0x0061 }
            android.content.Context r8 = r10.f303i     // Catch:{ NameNotFoundException -> 0x0061 }
            java.lang.Object r9 = r10.f301h     // Catch:{ NameNotFoundException -> 0x0061 }
            java.lang.Class r9 = r9.getClass()     // Catch:{ NameNotFoundException -> 0x0061 }
            r7.<init>(r8, r9)     // Catch:{ NameNotFoundException -> 0x0061 }
            android.content.pm.ActivityInfo r3 = r3.getActivityInfo(r7, r6)     // Catch:{ NameNotFoundException -> 0x0061 }
            if (r3 == 0) goto L_0x005d
            int r3 = r3.configChanges     // Catch:{ NameNotFoundException -> 0x0061 }
            r3 = r3 & 512(0x200, float:7.175E-43)
            if (r3 == 0) goto L_0x005d
            r3 = 1
            goto L_0x005e
        L_0x005d:
            r3 = 0
        L_0x005e:
            r10.f294a0 = r3     // Catch:{ NameNotFoundException -> 0x0061 }
            goto L_0x006b
        L_0x0061:
            r3 = move-exception
            java.lang.String r6 = "AppCompatDelegate"
            java.lang.String r7 = "Exception while getting ActivityInfo"
            android.util.Log.d(r6, r7, r3)
            r10.f294a0 = r1
        L_0x006b:
            r10.f295b0 = r5
            boolean r3 = r10.f294a0
        L_0x006f:
            android.content.Context r6 = r10.f303i
            android.content.res.Resources r6 = r6.getResources()
            android.content.res.Configuration r6 = r6.getConfiguration()
            int r6 = r6.uiMode
            r6 = r6 & 48
            int r2 = r2.uiMode
            r2 = r2 & 48
            if (r6 == r2) goto L_0x00aa
            if (r11 == 0) goto L_0x00aa
            if (r3 != 0) goto L_0x00aa
            boolean r11 = r10.f288N
            if (r11 == 0) goto L_0x00aa
            boolean r11 = f273f
            if (r11 != 0) goto L_0x0093
            boolean r11 = r10.f289O
            if (r11 == 0) goto L_0x00aa
        L_0x0093:
            java.lang.Object r11 = r10.f301h
            boolean r7 = r11 instanceof android.app.Activity
            if (r7 == 0) goto L_0x00aa
            android.app.Activity r11 = (android.app.Activity) r11
            boolean r11 = r11.isChild()
            if (r11 != 0) goto L_0x00aa
            java.lang.Object r11 = r10.f301h
            android.app.Activity r11 = (android.app.Activity) r11
            androidx.core.app.C0441a.m2079d(r11)
            r11 = 1
            goto L_0x00ab
        L_0x00aa:
            r11 = 0
        L_0x00ab:
            if (r11 != 0) goto L_0x011a
            if (r6 == r2) goto L_0x011a
            android.content.Context r11 = r10.f303i
            android.content.res.Resources r11 = r11.getResources()
            android.content.res.Configuration r6 = new android.content.res.Configuration
            android.content.res.Configuration r7 = r11.getConfiguration()
            r6.<init>(r7)
            android.content.res.Configuration r7 = r11.getConfiguration()
            int r7 = r7.uiMode
            r7 = r7 & -49
            r2 = r2 | r7
            r6.uiMode = r2
            r11.updateConfiguration(r6, r4)
            int r2 = android.os.Build.VERSION.SDK_INT
            r4 = 26
            if (r2 >= r4) goto L_0x00d5
            androidx.appcompat.app.AppCompatDelegateImpl.C0120h.m503a(r11)
        L_0x00d5:
            int r11 = r10.f293Z
            if (r11 == 0) goto L_0x00ed
            android.content.Context r4 = r10.f303i
            r4.setTheme(r11)
            r11 = 23
            if (r2 < r11) goto L_0x00ed
            android.content.Context r11 = r10.f303i
            android.content.res.Resources$Theme r11 = r11.getTheme()
            int r2 = r10.f293Z
            r11.applyStyle(r2, r5)
        L_0x00ed:
            if (r3 == 0) goto L_0x011b
            java.lang.Object r11 = r10.f301h
            boolean r2 = r11 instanceof android.app.Activity
            if (r2 == 0) goto L_0x011b
            android.app.Activity r11 = (android.app.Activity) r11
            boolean r2 = r11 instanceof androidx.lifecycle.C0909j
            if (r2 == 0) goto L_0x0112
            r2 = r11
            androidx.lifecycle.j r2 = (androidx.lifecycle.C0909j) r2
            androidx.lifecycle.f r2 = r2.mo341G()
            androidx.lifecycle.f$b r2 = r2.mo3941b()
            androidx.lifecycle.f$b r3 = androidx.lifecycle.C0903f.C0905b.STARTED
            int r2 = r2.compareTo(r3)
            if (r2 < 0) goto L_0x010f
            r1 = 1
        L_0x010f:
            if (r1 == 0) goto L_0x011b
            goto L_0x0116
        L_0x0112:
            boolean r1 = r10.f290P
            if (r1 == 0) goto L_0x011b
        L_0x0116:
            r11.onConfigurationChanged(r6)
            goto L_0x011b
        L_0x011a:
            r5 = r11
        L_0x011b:
            if (r5 == 0) goto L_0x0128
            java.lang.Object r11 = r10.f301h
            boolean r1 = r11 instanceof androidx.appcompat.app.AppCompatActivity
            if (r1 == 0) goto L_0x0128
            androidx.appcompat.app.AppCompatActivity r11 = (androidx.appcompat.app.AppCompatActivity) r11
            r11.mo430L0()
        L_0x0128:
            if (r0 != 0) goto L_0x0141
            android.content.Context r11 = r10.f303i
            androidx.appcompat.app.AppCompatDelegateImpl$f r1 = r10.f296c0
            if (r1 != 0) goto L_0x013b
            androidx.appcompat.app.AppCompatDelegateImpl$g r1 = new androidx.appcompat.app.AppCompatDelegateImpl$g
            androidx.appcompat.app.p r11 = androidx.appcompat.app.C0142p.m561a(r11)
            r1.<init>(r11)
            r10.f296c0 = r1
        L_0x013b:
            androidx.appcompat.app.AppCompatDelegateImpl$f r11 = r10.f296c0
            r11.mo531e()
            goto L_0x0148
        L_0x0141:
            androidx.appcompat.app.AppCompatDelegateImpl$f r11 = r10.f296c0
            if (r11 == 0) goto L_0x0148
            r11.mo530a()
        L_0x0148:
            r11 = 3
            if (r0 != r11) goto L_0x015e
            android.content.Context r11 = r10.f303i
            androidx.appcompat.app.AppCompatDelegateImpl$f r0 = r10.f297d0
            if (r0 != 0) goto L_0x0158
            androidx.appcompat.app.AppCompatDelegateImpl$e r0 = new androidx.appcompat.app.AppCompatDelegateImpl$e
            r0.<init>(r11)
            r10.f297d0 = r0
        L_0x0158:
            androidx.appcompat.app.AppCompatDelegateImpl$f r11 = r10.f297d0
            r11.mo531e()
            goto L_0x0165
        L_0x015e:
            androidx.appcompat.app.AppCompatDelegateImpl$f r11 = r10.f297d0
            if (r11 == 0) goto L_0x0165
            r11.mo530a()
        L_0x0165:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AppCompatDelegateImpl.m428C(boolean):boolean");
    }

    /* renamed from: D */
    private void m429D(Window window) {
        if (this.f305j == null) {
            Window.Callback callback = window.getCallback();
            if (!(callback instanceof C0115d)) {
                C0115d dVar = new C0115d(callback);
                this.f307k = dVar;
                window.setCallback(dVar);
                C0259e0 u = C0259e0.m1180u(this.f303i, (AttributeSet) null, f272e);
                Drawable h = u.mo1597h(0);
                if (h != null) {
                    window.setBackgroundDrawable(h);
                }
                u.mo1609w();
                this.f305j = window;
                return;
            }
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        throw new IllegalStateException("AppCompat has already installed itself into the Window");
    }

    /* renamed from: H */
    private Configuration m430H(Context context, int i, Configuration configuration) {
        int i2 = i != 1 ? i != 2 ? context.getApplicationContext().getResources().getConfiguration().uiMode & 48 : 32 : 16;
        Configuration configuration2 = new Configuration();
        configuration2.fontScale = 0.0f;
        if (configuration != null) {
            configuration2.setTo(configuration);
        }
        configuration2.uiMode = i2 | (configuration2.uiMode & -49);
        return configuration2;
    }

    /* renamed from: M */
    private void m431M() {
        ViewGroup viewGroup;
        if (!this.f322y) {
            TypedArray obtainStyledAttributes = this.f303i.obtainStyledAttributes(C4568b.f16463k);
            if (obtainStyledAttributes.hasValue(115)) {
                if (obtainStyledAttributes.getBoolean(124, false)) {
                    mo497v(1);
                } else if (obtainStyledAttributes.getBoolean(115, false)) {
                    mo497v(108);
                }
                if (obtainStyledAttributes.getBoolean(116, false)) {
                    mo497v(109);
                }
                if (obtainStyledAttributes.getBoolean(117, false)) {
                    mo497v(10);
                }
                this.f282H = obtainStyledAttributes.getBoolean(0, false);
                obtainStyledAttributes.recycle();
                m432N();
                this.f305j.getDecorView();
                LayoutInflater from = LayoutInflater.from(this.f303i);
                if (this.f283I) {
                    viewGroup = (ViewGroup) from.inflate(this.f281G ? R.layout.abc_screen_simple_overlay_action_mode : R.layout.abc_screen_simple, (ViewGroup) null);
                } else if (this.f282H) {
                    viewGroup = (ViewGroup) from.inflate(R.layout.abc_dialog_title_material, (ViewGroup) null);
                    this.f280F = false;
                    this.f279E = false;
                } else if (this.f279E) {
                    TypedValue typedValue = new TypedValue();
                    this.f303i.getTheme().resolveAttribute(R.attr.actionBarTheme, typedValue, true);
                    viewGroup = (ViewGroup) LayoutInflater.from(typedValue.resourceId != 0 ? new C4592d(this.f303i, typedValue.resourceId) : this.f303i).inflate(R.layout.abc_screen_toolbar, (ViewGroup) null);
                    C0281m mVar = (C0281m) viewGroup.findViewById(R.id.decor_content_parent);
                    this.f313p = mVar;
                    mVar.mo1053f(mo468Q());
                    if (this.f280F) {
                        this.f313p.mo1062j(109);
                    }
                    if (this.f277C) {
                        this.f313p.mo1062j(2);
                    }
                    if (this.f278D) {
                        this.f313p.mo1062j(5);
                    }
                } else {
                    viewGroup = null;
                }
                if (viewGroup != null) {
                    C4761m.m17312u(viewGroup, new C0132i(this));
                    if (this.f313p == null) {
                        this.f275A = (TextView) viewGroup.findViewById(R.id.title);
                    }
                    int i = C0280l0.f1186b;
                    try {
                        Method method = viewGroup.getClass().getMethod("makeOptionalFitsSystemWindows", new Class[0]);
                        if (!method.isAccessible()) {
                            method.setAccessible(true);
                        }
                        method.invoke(viewGroup, new Object[0]);
                    } catch (NoSuchMethodException unused) {
                        Log.d("ViewUtils", "Could not find method makeOptionalFitsSystemWindows. Oh well...");
                    } catch (IllegalAccessException | InvocationTargetException e) {
                        Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", e);
                    }
                    ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(R.id.action_bar_activity_content);
                    ViewGroup viewGroup2 = (ViewGroup) this.f305j.findViewById(16908290);
                    if (viewGroup2 != null) {
                        while (viewGroup2.getChildCount() > 0) {
                            View childAt = viewGroup2.getChildAt(0);
                            viewGroup2.removeViewAt(0);
                            contentFrameLayout.addView(childAt);
                        }
                        viewGroup2.setId(-1);
                        contentFrameLayout.setId(16908290);
                        if (viewGroup2 instanceof FrameLayout) {
                            ((FrameLayout) viewGroup2).setForeground((Drawable) null);
                        }
                    }
                    this.f305j.setContentView(viewGroup);
                    contentFrameLayout.mo1364g(new C0133j(this));
                    this.f323z = viewGroup;
                    Object obj = this.f301h;
                    CharSequence title = obj instanceof Activity ? ((Activity) obj).getTitle() : this.f312o;
                    if (!TextUtils.isEmpty(title)) {
                        C0281m mVar2 = this.f313p;
                        if (mVar2 != null) {
                            mVar2.mo1047b(title);
                        } else {
                            ActionBar actionBar = this.f310m;
                            if (actionBar != null) {
                                ((C0144q) actionBar).f417g.mo1622b(title);
                            } else {
                                TextView textView = this.f275A;
                                if (textView != null) {
                                    textView.setText(title);
                                }
                            }
                        }
                    }
                    ContentFrameLayout contentFrameLayout2 = (ContentFrameLayout) this.f323z.findViewById(16908290);
                    View decorView = this.f305j.getDecorView();
                    contentFrameLayout2.mo1365h(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
                    TypedArray obtainStyledAttributes2 = this.f303i.obtainStyledAttributes(C4568b.f16463k);
                    obtainStyledAttributes2.getValue(122, contentFrameLayout2.mo1362e());
                    obtainStyledAttributes2.getValue(123, contentFrameLayout2.mo1363f());
                    if (obtainStyledAttributes2.hasValue(120)) {
                        obtainStyledAttributes2.getValue(120, contentFrameLayout2.mo1360c());
                    }
                    if (obtainStyledAttributes2.hasValue(121)) {
                        obtainStyledAttributes2.getValue(121, contentFrameLayout2.mo1361d());
                    }
                    if (obtainStyledAttributes2.hasValue(118)) {
                        obtainStyledAttributes2.getValue(118, contentFrameLayout2.mo1358a());
                    }
                    if (obtainStyledAttributes2.hasValue(119)) {
                        obtainStyledAttributes2.getValue(119, contentFrameLayout2.mo1359b());
                    }
                    obtainStyledAttributes2.recycle();
                    contentFrameLayout2.requestLayout();
                    this.f322y = true;
                    PanelFeatureState P = mo467P(0);
                    if (!this.f291Q && P.f331h == null) {
                        m434S(108);
                        return;
                    }
                    return;
                }
                StringBuilder P2 = C4924a.m17863P("AppCompat does not support the current theme features: { windowActionBar: ");
                P2.append(this.f279E);
                P2.append(", windowActionBarOverlay: ");
                P2.append(this.f280F);
                P2.append(", android:windowIsFloating: ");
                P2.append(this.f282H);
                P2.append(", windowActionModeOverlay: ");
                P2.append(this.f281G);
                P2.append(", windowNoTitle: ");
                P2.append(this.f283I);
                P2.append(" }");
                throw new IllegalArgumentException(P2.toString());
            }
            obtainStyledAttributes.recycle();
            throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
        }
    }

    /* renamed from: N */
    private void m432N() {
        if (this.f305j == null) {
            Object obj = this.f301h;
            if (obj instanceof Activity) {
                m429D(((Activity) obj).getWindow());
            }
        }
        if (this.f305j == null) {
            throw new IllegalStateException("We have not been given a Window");
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0032  */
    /* JADX WARNING: Removed duplicated region for block: B:16:? A[RETURN, SYNTHETIC] */
    /* renamed from: R */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m433R() {
        /*
            r3 = this;
            r3.m431M()
            boolean r0 = r3.f279E
            if (r0 == 0) goto L_0x0037
            androidx.appcompat.app.ActionBar r0 = r3.f310m
            if (r0 == 0) goto L_0x000c
            goto L_0x0037
        L_0x000c:
            java.lang.Object r0 = r3.f301h
            boolean r1 = r0 instanceof android.app.Activity
            if (r1 == 0) goto L_0x0020
            androidx.appcompat.app.q r0 = new androidx.appcompat.app.q
            java.lang.Object r1 = r3.f301h
            android.app.Activity r1 = (android.app.Activity) r1
            boolean r2 = r3.f280F
            r0.<init>(r1, r2)
        L_0x001d:
            r3.f310m = r0
            goto L_0x002e
        L_0x0020:
            boolean r0 = r0 instanceof android.app.Dialog
            if (r0 == 0) goto L_0x002e
            androidx.appcompat.app.q r0 = new androidx.appcompat.app.q
            java.lang.Object r1 = r3.f301h
            android.app.Dialog r1 = (android.app.Dialog) r1
            r0.<init>(r1)
            goto L_0x001d
        L_0x002e:
            androidx.appcompat.app.ActionBar r0 = r3.f310m
            if (r0 == 0) goto L_0x0037
            boolean r1 = r3.f302h0
            r0.mo415d(r1)
        L_0x0037:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AppCompatDelegateImpl.m433R():void");
    }

    /* renamed from: S */
    private void m434S(int i) {
        this.f299f0 = (1 << i) | this.f299f0;
        if (!this.f298e0) {
            View decorView = this.f305j.getDecorView();
            Runnable runnable = this.f300g0;
            int i2 = C4761m.f17241f;
            decorView.postOnAnimation(runnable);
            this.f298e0 = true;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:66:0x0131, code lost:
        if (r14 != null) goto L_0x0133;
     */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x0138  */
    /* renamed from: Y */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m435Y(androidx.appcompat.app.AppCompatDelegateImpl.PanelFeatureState r13, android.view.KeyEvent r14) {
        /*
            r12 = this;
            boolean r0 = r13.f336m
            if (r0 != 0) goto L_0x01b0
            boolean r0 = r12.f291Q
            if (r0 == 0) goto L_0x000a
            goto L_0x01b0
        L_0x000a:
            int r0 = r13.f324a
            r1 = 1
            r2 = 0
            if (r0 != 0) goto L_0x0027
            android.content.Context r0 = r12.f303i
            android.content.res.Resources r0 = r0.getResources()
            android.content.res.Configuration r0 = r0.getConfiguration()
            int r0 = r0.screenLayout
            r0 = r0 & 15
            r3 = 4
            if (r0 != r3) goto L_0x0023
            r0 = 1
            goto L_0x0024
        L_0x0023:
            r0 = 0
        L_0x0024:
            if (r0 == 0) goto L_0x0027
            return
        L_0x0027:
            android.view.Window$Callback r0 = r12.mo468Q()
            if (r0 == 0) goto L_0x003b
            int r3 = r13.f324a
            androidx.appcompat.view.menu.g r4 = r13.f331h
            boolean r0 = r0.onMenuOpened(r3, r4)
            if (r0 != 0) goto L_0x003b
            r12.mo461G(r13, r1)
            return
        L_0x003b:
            android.content.Context r0 = r12.f303i
            java.lang.String r3 = "window"
            java.lang.Object r0 = r0.getSystemService(r3)
            android.view.WindowManager r0 = (android.view.WindowManager) r0
            if (r0 != 0) goto L_0x0048
            return
        L_0x0048:
            boolean r14 = r12.m437a0(r13, r14)
            if (r14 != 0) goto L_0x004f
            return
        L_0x004f:
            android.view.ViewGroup r14 = r13.f328e
            r3 = -2
            r4 = -1
            if (r14 == 0) goto L_0x006b
            boolean r5 = r13.f338o
            if (r5 == 0) goto L_0x005a
            goto L_0x006b
        L_0x005a:
            android.view.View r14 = r13.f330g
            if (r14 == 0) goto L_0x018d
            android.view.ViewGroup$LayoutParams r14 = r14.getLayoutParams()
            if (r14 == 0) goto L_0x018d
            int r14 = r14.width
            if (r14 != r4) goto L_0x018d
            r5 = -1
            goto L_0x018e
        L_0x006b:
            if (r14 != 0) goto L_0x00e3
            r12.m433R()
            androidx.appcompat.app.ActionBar r14 = r12.f310m
            if (r14 == 0) goto L_0x0079
            android.content.Context r14 = r14.mo413b()
            goto L_0x007a
        L_0x0079:
            r14 = 0
        L_0x007a:
            if (r14 != 0) goto L_0x007e
            android.content.Context r14 = r12.f303i
        L_0x007e:
            android.util.TypedValue r4 = new android.util.TypedValue
            r4.<init>()
            android.content.res.Resources r5 = r14.getResources()
            android.content.res.Resources$Theme r5 = r5.newTheme()
            android.content.res.Resources$Theme r6 = r14.getTheme()
            r5.setTo(r6)
            r6 = 2130968578(0x7f040002, float:1.7545814E38)
            r5.resolveAttribute(r6, r4, r1)
            int r6 = r4.resourceId
            if (r6 == 0) goto L_0x009f
            r5.applyStyle(r6, r1)
        L_0x009f:
            r6 = 2130969401(0x7f040339, float:1.7547483E38)
            r5.resolveAttribute(r6, r4, r1)
            int r4 = r4.resourceId
            if (r4 == 0) goto L_0x00aa
            goto L_0x00ad
        L_0x00aa:
            r4 = 2131821053(0x7f1101fd, float:1.9274838E38)
        L_0x00ad:
            r5.applyStyle(r4, r1)
            d.a.g.d r4 = new d.a.g.d
            r4.<init>((android.content.Context) r14, (int) r2)
            android.content.res.Resources$Theme r14 = r4.getTheme()
            r14.setTo(r5)
            r13.f333j = r4
            int[] r14 = p098d.p099a.C4568b.f16463k
            android.content.res.TypedArray r14 = r4.obtainStyledAttributes(r14)
            r4 = 84
            int r4 = r14.getResourceId(r4, r2)
            r13.f325b = r4
            int r4 = r14.getResourceId(r1, r2)
            r13.f327d = r4
            r14.recycle()
            androidx.appcompat.app.AppCompatDelegateImpl$i r14 = new androidx.appcompat.app.AppCompatDelegateImpl$i
            android.content.Context r4 = r13.f333j
            r14.<init>(r4)
            r13.f328e = r14
            r14 = 81
            r13.f326c = r14
            goto L_0x00f2
        L_0x00e3:
            boolean r4 = r13.f338o
            if (r4 == 0) goto L_0x00f2
            int r14 = r14.getChildCount()
            if (r14 <= 0) goto L_0x00f2
            android.view.ViewGroup r14 = r13.f328e
            r14.removeAllViews()
        L_0x00f2:
            android.view.View r14 = r13.f330g
            if (r14 == 0) goto L_0x00f9
            r13.f329f = r14
            goto L_0x0133
        L_0x00f9:
            androidx.appcompat.view.menu.g r14 = r13.f331h
            if (r14 != 0) goto L_0x00fe
            goto L_0x0135
        L_0x00fe:
            androidx.appcompat.app.AppCompatDelegateImpl$j r14 = r12.f315r
            if (r14 != 0) goto L_0x0109
            androidx.appcompat.app.AppCompatDelegateImpl$j r14 = new androidx.appcompat.app.AppCompatDelegateImpl$j
            r14.<init>()
            r12.f315r = r14
        L_0x0109:
            androidx.appcompat.app.AppCompatDelegateImpl$j r14 = r12.f315r
            androidx.appcompat.view.menu.e r4 = r13.f332i
            if (r4 != 0) goto L_0x0125
            androidx.appcompat.view.menu.e r4 = new androidx.appcompat.view.menu.e
            android.content.Context r5 = r13.f333j
            r6 = 2131558416(0x7f0d0010, float:1.8742147E38)
            r4.<init>(r5, r6)
            r13.f332i = r4
            r4.mo695g(r14)
            androidx.appcompat.view.menu.g r14 = r13.f331h
            androidx.appcompat.view.menu.e r4 = r13.f332i
            r14.mo779b(r4)
        L_0x0125:
            androidx.appcompat.view.menu.e r14 = r13.f332i
            android.view.ViewGroup r4 = r13.f328e
            androidx.appcompat.view.menu.n r14 = r14.mo735j(r4)
            android.view.View r14 = (android.view.View) r14
            r13.f329f = r14
            if (r14 == 0) goto L_0x0135
        L_0x0133:
            r14 = 1
            goto L_0x0136
        L_0x0135:
            r14 = 0
        L_0x0136:
            if (r14 == 0) goto L_0x01ae
            android.view.View r14 = r13.f329f
            if (r14 != 0) goto L_0x013d
            goto L_0x0150
        L_0x013d:
            android.view.View r14 = r13.f330g
            if (r14 == 0) goto L_0x0142
            goto L_0x014e
        L_0x0142:
            androidx.appcompat.view.menu.e r14 = r13.f332i
            android.widget.ListAdapter r14 = r14.mo734a()
            int r14 = r14.getCount()
            if (r14 <= 0) goto L_0x0150
        L_0x014e:
            r14 = 1
            goto L_0x0151
        L_0x0150:
            r14 = 0
        L_0x0151:
            if (r14 != 0) goto L_0x0154
            goto L_0x01ae
        L_0x0154:
            android.view.View r14 = r13.f329f
            android.view.ViewGroup$LayoutParams r14 = r14.getLayoutParams()
            if (r14 != 0) goto L_0x0161
            android.view.ViewGroup$LayoutParams r14 = new android.view.ViewGroup$LayoutParams
            r14.<init>(r3, r3)
        L_0x0161:
            int r4 = r13.f325b
            android.view.ViewGroup r5 = r13.f328e
            r5.setBackgroundResource(r4)
            android.view.View r4 = r13.f329f
            android.view.ViewParent r4 = r4.getParent()
            boolean r5 = r4 instanceof android.view.ViewGroup
            if (r5 == 0) goto L_0x0179
            android.view.ViewGroup r4 = (android.view.ViewGroup) r4
            android.view.View r5 = r13.f329f
            r4.removeView(r5)
        L_0x0179:
            android.view.ViewGroup r4 = r13.f328e
            android.view.View r5 = r13.f329f
            r4.addView(r5, r14)
            android.view.View r14 = r13.f329f
            boolean r14 = r14.hasFocus()
            if (r14 != 0) goto L_0x018d
            android.view.View r14 = r13.f329f
            r14.requestFocus()
        L_0x018d:
            r5 = -2
        L_0x018e:
            r13.f335l = r2
            android.view.WindowManager$LayoutParams r14 = new android.view.WindowManager$LayoutParams
            r6 = -2
            r7 = 0
            r8 = 0
            r9 = 1002(0x3ea, float:1.404E-42)
            r10 = 8519680(0x820000, float:1.1938615E-38)
            r11 = -3
            r4 = r14
            r4.<init>(r5, r6, r7, r8, r9, r10, r11)
            int r2 = r13.f326c
            r14.gravity = r2
            int r2 = r13.f327d
            r14.windowAnimations = r2
            android.view.ViewGroup r2 = r13.f328e
            r0.addView(r2, r14)
            r13.f336m = r1
            return
        L_0x01ae:
            r13.f338o = r1
        L_0x01b0:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AppCompatDelegateImpl.m435Y(androidx.appcompat.app.AppCompatDelegateImpl$PanelFeatureState, android.view.KeyEvent):void");
    }

    /* renamed from: Z */
    private boolean m436Z(PanelFeatureState panelFeatureState, int i, KeyEvent keyEvent, int i2) {
        C0163g gVar;
        boolean z = false;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((panelFeatureState.f334k || m437a0(panelFeatureState, keyEvent)) && (gVar = panelFeatureState.f331h) != null) {
            z = gVar.performShortcut(i, keyEvent, i2);
        }
        if (z && (i2 & 1) == 0 && this.f313p == null) {
            mo461G(panelFeatureState, true);
        }
        return z;
    }

    /* renamed from: a0 */
    private boolean m437a0(PanelFeatureState panelFeatureState, KeyEvent keyEvent) {
        C0281m mVar;
        C0281m mVar2;
        C0281m mVar3;
        Resources.Theme theme;
        C0281m mVar4;
        if (this.f291Q) {
            return false;
        }
        if (panelFeatureState.f334k) {
            return true;
        }
        PanelFeatureState panelFeatureState2 = this.f286L;
        if (!(panelFeatureState2 == null || panelFeatureState2 == panelFeatureState)) {
            mo461G(panelFeatureState2, false);
        }
        Window.Callback Q = mo468Q();
        if (Q != null) {
            panelFeatureState.f330g = Q.onCreatePanelView(panelFeatureState.f324a);
        }
        int i = panelFeatureState.f324a;
        boolean z = i == 0 || i == 108;
        if (z && (mVar4 = this.f313p) != null) {
            mVar4.mo1050d();
        }
        if (panelFeatureState.f330g == null) {
            C0163g gVar = panelFeatureState.f331h;
            if (gVar == null || panelFeatureState.f339p) {
                if (gVar == null) {
                    Context context = this.f303i;
                    int i2 = panelFeatureState.f324a;
                    if ((i2 == 0 || i2 == 108) && this.f313p != null) {
                        TypedValue typedValue = new TypedValue();
                        Resources.Theme theme2 = context.getTheme();
                        theme2.resolveAttribute(R.attr.actionBarTheme, typedValue, true);
                        if (typedValue.resourceId != 0) {
                            theme = context.getResources().newTheme();
                            theme.setTo(theme2);
                            theme.applyStyle(typedValue.resourceId, true);
                            theme.resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
                        } else {
                            theme2.resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
                            theme = null;
                        }
                        if (typedValue.resourceId != 0) {
                            if (theme == null) {
                                theme = context.getResources().newTheme();
                                theme.setTo(theme2);
                            }
                            theme.applyStyle(typedValue.resourceId, true);
                        }
                        if (theme != null) {
                            C4592d dVar = new C4592d(context, 0);
                            dVar.getTheme().setTo(theme);
                            context = dVar;
                        }
                    }
                    C0163g gVar2 = new C0163g(context);
                    gVar2.mo758G(this);
                    panelFeatureState.mo502a(gVar2);
                    if (panelFeatureState.f331h == null) {
                        return false;
                    }
                }
                if (z && (mVar3 = this.f313p) != null) {
                    if (this.f314q == null) {
                        this.f314q = new C0112b();
                    }
                    mVar3.mo1046a(panelFeatureState.f331h, this.f314q);
                }
                panelFeatureState.f331h.mo768R();
                if (!Q.onCreatePanelMenu(panelFeatureState.f324a, panelFeatureState.f331h)) {
                    panelFeatureState.mo502a((C0163g) null);
                    if (z && (mVar2 = this.f313p) != null) {
                        mVar2.mo1046a((Menu) null, this.f314q);
                    }
                    return false;
                }
                panelFeatureState.f339p = false;
            }
            panelFeatureState.f331h.mo768R();
            Bundle bundle = panelFeatureState.f340q;
            if (bundle != null) {
                panelFeatureState.f331h.mo754C(bundle);
                panelFeatureState.f340q = null;
            }
            if (!Q.onPreparePanel(0, panelFeatureState.f330g, panelFeatureState.f331h)) {
                if (z && (mVar = this.f313p) != null) {
                    mVar.mo1046a((Menu) null, this.f314q);
                }
                panelFeatureState.f331h.mo767Q();
                return false;
            }
            boolean z2 = KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1;
            panelFeatureState.f337n = z2;
            panelFeatureState.f331h.setQwertyMode(z2);
            panelFeatureState.f331h.mo767Q();
        }
        panelFeatureState.f334k = true;
        panelFeatureState.f335l = false;
        this.f286L = panelFeatureState;
        return true;
    }

    /* renamed from: d0 */
    private void m438d0() {
        if (this.f322y) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    /* renamed from: A */
    public final void mo457A(CharSequence charSequence) {
        this.f312o = charSequence;
        C0281m mVar = this.f313p;
        if (mVar != null) {
            mVar.mo1047b(charSequence);
            return;
        }
        ActionBar actionBar = this.f310m;
        if (actionBar != null) {
            ((C0144q) actionBar).f417g.mo1622b(charSequence);
            return;
        }
        TextView textView = this.f275A;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    /* renamed from: B */
    public boolean mo458B() {
        return m428C(true);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: E */
    public void mo459E(int i, PanelFeatureState panelFeatureState, Menu menu) {
        if (menu == null && panelFeatureState != null) {
            menu = panelFeatureState.f331h;
        }
        if ((panelFeatureState == null || panelFeatureState.f336m) && !this.f291Q) {
            this.f307k.mo21265a().onPanelClosed(i, menu);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: F */
    public void mo460F(C0163g gVar) {
        if (!this.f284J) {
            this.f284J = true;
            this.f313p.mo1063k();
            Window.Callback Q = mo468Q();
            if (Q != null && !this.f291Q) {
                Q.onPanelClosed(108, gVar);
            }
            this.f284J = false;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: G */
    public void mo461G(PanelFeatureState panelFeatureState, boolean z) {
        ViewGroup viewGroup;
        C0281m mVar;
        if (!z || panelFeatureState.f324a != 0 || (mVar = this.f313p) == null || !mVar.mo1048c()) {
            WindowManager windowManager = (WindowManager) this.f303i.getSystemService("window");
            if (!(windowManager == null || !panelFeatureState.f336m || (viewGroup = panelFeatureState.f328e) == null)) {
                windowManager.removeView(viewGroup);
                if (z) {
                    mo459E(panelFeatureState.f324a, panelFeatureState, (Menu) null);
                }
            }
            panelFeatureState.f334k = false;
            panelFeatureState.f335l = false;
            panelFeatureState.f336m = false;
            panelFeatureState.f329f = null;
            panelFeatureState.f338o = true;
            if (this.f286L == panelFeatureState) {
                this.f286L = null;
                return;
            }
            return;
        }
        mo460F(panelFeatureState.f331h);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: I */
    public void mo462I() {
        C0281m mVar = this.f313p;
        if (mVar != null) {
            mVar.mo1063k();
        }
        if (this.f318u != null) {
            this.f305j.getDecorView().removeCallbacks(this.f319v);
            if (this.f318u.isShowing()) {
                try {
                    this.f318u.dismiss();
                } catch (IllegalArgumentException unused) {
                }
            }
            this.f318u = null;
        }
        mo465L();
        C0163g gVar = mo467P(0).f331h;
        if (gVar != null) {
            gVar.mo785e(true);
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:84:0x0125, code lost:
        if (r7 != false) goto L_0x0127;
     */
    /* JADX WARNING: Removed duplicated region for block: B:65:0x00d4  */
    /* JADX WARNING: Removed duplicated region for block: B:91:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:96:? A[RETURN, SYNTHETIC] */
    /* renamed from: J */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo463J(android.view.KeyEvent r7) {
        /*
            r6 = this;
            java.lang.Object r0 = r6.f301h
            boolean r1 = r0 instanceof p098d.p120g.p130j.C4751d.C4752a
            r2 = 1
            if (r1 != 0) goto L_0x000b
            boolean r0 = r0 instanceof androidx.appcompat.app.C0137m
            if (r0 == 0) goto L_0x001a
        L_0x000b:
            android.view.Window r0 = r6.f305j
            android.view.View r0 = r0.getDecorView()
            if (r0 == 0) goto L_0x001a
            boolean r0 = p098d.p120g.p130j.C4751d.m17261a(r0, r7)
            if (r0 == 0) goto L_0x001a
            return r2
        L_0x001a:
            int r0 = r7.getKeyCode()
            r1 = 82
            if (r0 != r1) goto L_0x002f
            androidx.appcompat.app.AppCompatDelegateImpl$d r0 = r6.f307k
            android.view.Window$Callback r0 = r0.mo21265a()
            boolean r0 = r0.dispatchKeyEvent(r7)
            if (r0 == 0) goto L_0x002f
            return r2
        L_0x002f:
            int r0 = r7.getKeyCode()
            int r3 = r7.getAction()
            r4 = 0
            if (r3 != 0) goto L_0x003c
            r3 = 1
            goto L_0x003d
        L_0x003c:
            r3 = 0
        L_0x003d:
            r5 = 4
            if (r3 == 0) goto L_0x0067
            if (r0 == r5) goto L_0x0058
            if (r0 == r1) goto L_0x0045
            goto L_0x0064
        L_0x0045:
            int r0 = r7.getRepeatCount()
            if (r0 != 0) goto L_0x012c
            androidx.appcompat.app.AppCompatDelegateImpl$PanelFeatureState r0 = r6.mo467P(r4)
            boolean r1 = r0.f336m
            if (r1 != 0) goto L_0x012c
            r6.m437a0(r0, r7)
            goto L_0x012c
        L_0x0058:
            int r7 = r7.getFlags()
            r7 = r7 & 128(0x80, float:1.794E-43)
            if (r7 == 0) goto L_0x0061
            goto L_0x0062
        L_0x0061:
            r2 = 0
        L_0x0062:
            r6.f287M = r2
        L_0x0064:
            r2 = 0
            goto L_0x012c
        L_0x0067:
            if (r0 == r5) goto L_0x00f0
            if (r0 == r1) goto L_0x006c
            goto L_0x0064
        L_0x006c:
            d.a.g.b r0 = r6.f316s
            if (r0 == 0) goto L_0x0072
            goto L_0x012c
        L_0x0072:
            androidx.appcompat.app.AppCompatDelegateImpl$PanelFeatureState r0 = r6.mo467P(r4)
            androidx.appcompat.widget.m r1 = r6.f313p
            if (r1 == 0) goto L_0x00ac
            boolean r1 = r1.mo1052e()
            if (r1 == 0) goto L_0x00ac
            android.content.Context r1 = r6.f303i
            android.view.ViewConfiguration r1 = android.view.ViewConfiguration.get(r1)
            boolean r1 = r1.hasPermanentMenuKey()
            if (r1 != 0) goto L_0x00ac
            androidx.appcompat.widget.m r1 = r6.f313p
            boolean r1 = r1.mo1048c()
            if (r1 != 0) goto L_0x00a5
            boolean r1 = r6.f291Q
            if (r1 != 0) goto L_0x00cc
            boolean r7 = r6.m437a0(r0, r7)
            if (r7 == 0) goto L_0x00cc
            androidx.appcompat.widget.m r7 = r6.f313p
            boolean r7 = r7.mo1061i()
            goto L_0x00d2
        L_0x00a5:
            androidx.appcompat.widget.m r7 = r6.f313p
            boolean r7 = r7.mo1060h()
            goto L_0x00d2
        L_0x00ac:
            boolean r1 = r0.f336m
            if (r1 != 0) goto L_0x00ce
            boolean r3 = r0.f335l
            if (r3 == 0) goto L_0x00b5
            goto L_0x00ce
        L_0x00b5:
            boolean r1 = r0.f334k
            if (r1 == 0) goto L_0x00cc
            boolean r1 = r0.f339p
            if (r1 == 0) goto L_0x00c4
            r0.f334k = r4
            boolean r1 = r6.m437a0(r0, r7)
            goto L_0x00c5
        L_0x00c4:
            r1 = 1
        L_0x00c5:
            if (r1 == 0) goto L_0x00cc
            r6.m435Y(r0, r7)
            r7 = 1
            goto L_0x00d2
        L_0x00cc:
            r7 = 0
            goto L_0x00d2
        L_0x00ce:
            r6.mo461G(r0, r2)
            r7 = r1
        L_0x00d2:
            if (r7 == 0) goto L_0x012c
            android.content.Context r7 = r6.f303i
            android.content.Context r7 = r7.getApplicationContext()
            java.lang.String r0 = "audio"
            java.lang.Object r7 = r7.getSystemService(r0)
            android.media.AudioManager r7 = (android.media.AudioManager) r7
            if (r7 == 0) goto L_0x00e8
            r7.playSoundEffect(r4)
            goto L_0x012c
        L_0x00e8:
            java.lang.String r7 = "AppCompatDelegate"
            java.lang.String r0 = "Couldn't get audio manager"
            android.util.Log.w(r7, r0)
            goto L_0x012c
        L_0x00f0:
            boolean r7 = r6.f287M
            r6.f287M = r4
            androidx.appcompat.app.AppCompatDelegateImpl$PanelFeatureState r0 = r6.mo467P(r4)
            boolean r1 = r0.f336m
            if (r1 == 0) goto L_0x0102
            if (r7 != 0) goto L_0x012c
            r6.mo461G(r0, r2)
            goto L_0x012c
        L_0x0102:
            d.a.g.b r7 = r6.f316s
            if (r7 == 0) goto L_0x010a
            r7.mo592c()
            goto L_0x0127
        L_0x010a:
            r6.m433R()
            androidx.appcompat.app.ActionBar r7 = r6.f310m
            if (r7 == 0) goto L_0x0129
            androidx.appcompat.app.q r7 = (androidx.appcompat.app.C0144q) r7
            androidx.appcompat.widget.n r0 = r7.f417g
            if (r0 == 0) goto L_0x0124
            boolean r0 = r0.mo1634l()
            if (r0 == 0) goto L_0x0124
            androidx.appcompat.widget.n r7 = r7.f417g
            r7.collapseActionView()
            r7 = 1
            goto L_0x0125
        L_0x0124:
            r7 = 0
        L_0x0125:
            if (r7 == 0) goto L_0x0129
        L_0x0127:
            r7 = 1
            goto L_0x012a
        L_0x0129:
            r7 = 0
        L_0x012a:
            if (r7 == 0) goto L_0x0064
        L_0x012c:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AppCompatDelegateImpl.mo463J(android.view.KeyEvent):boolean");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: K */
    public void mo464K(int i) {
        PanelFeatureState P = mo467P(i);
        if (P.f331h != null) {
            Bundle bundle = new Bundle();
            P.f331h.mo756E(bundle);
            if (bundle.size() > 0) {
                P.f340q = bundle;
            }
            P.f331h.mo768R();
            P.f331h.clear();
        }
        P.f339p = true;
        P.f338o = true;
        if ((i == 108 || i == 0) && this.f313p != null) {
            PanelFeatureState P2 = mo467P(0);
            P2.f334k = false;
            m437a0(P2, (KeyEvent) null);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: L */
    public void mo465L() {
        C4774r rVar = this.f320w;
        if (rVar != null) {
            rVar.mo21875b();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: O */
    public PanelFeatureState mo466O(Menu menu) {
        PanelFeatureState[] panelFeatureStateArr = this.f285K;
        int length = panelFeatureStateArr != null ? panelFeatureStateArr.length : 0;
        for (int i = 0; i < length; i++) {
            PanelFeatureState panelFeatureState = panelFeatureStateArr[i];
            if (panelFeatureState != null && panelFeatureState.f331h == menu) {
                return panelFeatureState;
            }
        }
        return null;
    }

    /* access modifiers changed from: protected */
    /* renamed from: P */
    public PanelFeatureState mo467P(int i) {
        PanelFeatureState[] panelFeatureStateArr = this.f285K;
        if (panelFeatureStateArr == null || panelFeatureStateArr.length <= i) {
            PanelFeatureState[] panelFeatureStateArr2 = new PanelFeatureState[(i + 1)];
            if (panelFeatureStateArr != null) {
                System.arraycopy(panelFeatureStateArr, 0, panelFeatureStateArr2, 0, panelFeatureStateArr.length);
            }
            this.f285K = panelFeatureStateArr2;
            panelFeatureStateArr = panelFeatureStateArr2;
        }
        PanelFeatureState panelFeatureState = panelFeatureStateArr[i];
        if (panelFeatureState != null) {
            return panelFeatureState;
        }
        PanelFeatureState panelFeatureState2 = new PanelFeatureState(i);
        panelFeatureStateArr[i] = panelFeatureState2;
        return panelFeatureState2;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Q */
    public final Window.Callback mo468Q() {
        return this.f305j.getCallback();
    }

    /* renamed from: T */
    public boolean mo469T() {
        return this.f321x;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: U */
    public int mo470U(Context context, int i) {
        C0117f fVar;
        if (i == -100) {
            return -1;
        }
        if (i != -1) {
            if (i != 0) {
                if (!(i == 1 || i == 2)) {
                    if (i == 3) {
                        if (this.f297d0 == null) {
                            this.f297d0 = new C0116e(context);
                        }
                        fVar = this.f297d0;
                    } else {
                        throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
                    }
                }
            } else if (Build.VERSION.SDK_INT >= 23 && ((UiModeManager) context.getApplicationContext().getSystemService(UiModeManager.class)).getNightMode() == 0) {
                return -1;
            } else {
                if (this.f296c0 == null) {
                    this.f296c0 = new C0119g(C0142p.m561a(context));
                }
                fVar = this.f296c0;
            }
            return fVar.mo528c();
        }
        return i;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: V */
    public boolean mo471V(int i, KeyEvent keyEvent) {
        boolean z;
        Menu e;
        m433R();
        ActionBar actionBar = this.f310m;
        if (actionBar != null) {
            C0144q.C0148d dVar = ((C0144q) actionBar).f421k;
            if (dVar == null || (e = dVar.mo594e()) == null) {
                z = false;
            } else {
                e.setQwertyMode(KeyCharacterMap.load(keyEvent.getDeviceId()).getKeyboardType() != 1);
                z = ((C0163g) e).performShortcut(i, keyEvent, 0);
            }
            if (z) {
                return true;
            }
        }
        PanelFeatureState panelFeatureState = this.f286L;
        if (panelFeatureState == null || !m436Z(panelFeatureState, keyEvent.getKeyCode(), keyEvent, 1)) {
            if (this.f286L == null) {
                PanelFeatureState P = mo467P(0);
                m437a0(P, keyEvent);
                boolean Z = m436Z(P, keyEvent.getKeyCode(), keyEvent, 1);
                P.f334k = false;
                if (Z) {
                    return true;
                }
            }
            return false;
        }
        PanelFeatureState panelFeatureState2 = this.f286L;
        if (panelFeatureState2 != null) {
            panelFeatureState2.f335l = true;
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: W */
    public void mo472W(int i) {
        if (i == 108) {
            m433R();
            ActionBar actionBar = this.f310m;
            if (actionBar != null) {
                actionBar.mo412a(true);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: X */
    public void mo473X(int i) {
        if (i == 108) {
            m433R();
            ActionBar actionBar = this.f310m;
            if (actionBar != null) {
                actionBar.mo412a(false);
            }
        } else if (i == 0) {
            PanelFeatureState P = mo467P(i);
            if (P.f336m) {
                mo461G(P, false);
            }
        }
    }

    /* renamed from: a */
    public boolean mo474a(C0163g gVar, MenuItem menuItem) {
        PanelFeatureState O;
        Window.Callback Q = mo468Q();
        if (Q == null || this.f291Q || (O = mo466O(gVar.mo803q())) == null) {
            return false;
        }
        return Q.onMenuItemSelected(O.f324a, menuItem);
    }

    /* renamed from: b */
    public void mo475b(C0163g gVar) {
        C0281m mVar = this.f313p;
        if (mVar == null || !mVar.mo1052e() || (ViewConfiguration.get(this.f303i).hasPermanentMenuKey() && !this.f313p.mo1055g())) {
            PanelFeatureState P = mo467P(0);
            P.f338o = true;
            mo461G(P, false);
            m435Y(P, (KeyEvent) null);
            return;
        }
        Window.Callback Q = mo468Q();
        if (this.f313p.mo1048c()) {
            this.f313p.mo1060h();
            if (!this.f291Q) {
                Q.onPanelClosed(108, mo467P(0).f331h);
            }
        } else if (Q != null && !this.f291Q) {
            if (this.f298e0 && (1 & this.f299f0) != 0) {
                this.f305j.getDecorView().removeCallbacks(this.f300g0);
                this.f300g0.run();
            }
            PanelFeatureState P2 = mo467P(0);
            C0163g gVar2 = P2.f331h;
            if (gVar2 != null && !P2.f339p && Q.onPreparePanel(0, P2.f330g, gVar2)) {
                Q.onMenuOpened(108, P2.f331h);
                this.f313p.mo1061i();
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b0 */
    public final boolean mo476b0() {
        ViewGroup viewGroup;
        if (this.f322y && (viewGroup = this.f323z) != null) {
            int i = C4761m.f17241f;
            if (viewGroup.isLaidOut()) {
                return true;
            }
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:31:0x0079  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x007d  */
    /* renamed from: c0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p098d.p099a.p106g.C4589b mo477c0(p098d.p099a.p106g.C4589b.C4590a r9) {
        /*
            r8 = this;
            d.a.g.b r0 = r8.f316s
            if (r0 == 0) goto L_0x0007
            r0.mo592c()
        L_0x0007:
            androidx.appcompat.app.AppCompatDelegateImpl$c r0 = new androidx.appcompat.app.AppCompatDelegateImpl$c
            r0.<init>(r9)
            r8.m433R()
            androidx.appcompat.app.ActionBar r9 = r8.f310m
            r1 = 32
            r2 = 1
            r3 = 0
            r4 = 0
            if (r9 == 0) goto L_0x005b
            androidx.appcompat.app.q r9 = (androidx.appcompat.app.C0144q) r9
            androidx.appcompat.app.q$d r5 = r9.f421k
            if (r5 == 0) goto L_0x0021
            r5.mo592c()
        L_0x0021:
            androidx.appcompat.widget.ActionBarOverlayLayout r5 = r9.f415e
            r5.mo1091z(r4)
            androidx.appcompat.widget.ActionBarContextView r5 = r9.f418h
            r5.mo1031k()
            androidx.appcompat.app.q$d r5 = new androidx.appcompat.app.q$d
            androidx.appcompat.widget.ActionBarContextView r6 = r9.f418h
            android.content.Context r6 = r6.getContext()
            r5.<init>(r6, r0)
            boolean r6 = r5.mo606t()
            if (r6 == 0) goto L_0x004f
            r9.f421k = r5
            r5.mo598k()
            androidx.appcompat.widget.ActionBarContextView r6 = r9.f418h
            r6.mo1029h(r5)
            r9.mo585f(r2)
            androidx.appcompat.widget.ActionBarContextView r9 = r9.f418h
            r9.sendAccessibilityEvent(r1)
            goto L_0x0050
        L_0x004f:
            r5 = r3
        L_0x0050:
            r8.f316s = r5
            if (r5 == 0) goto L_0x005b
            androidx.appcompat.app.g r9 = r8.f309l
            if (r9 == 0) goto L_0x005b
            r9.onSupportActionModeStarted(r5)
        L_0x005b:
            d.a.g.b r9 = r8.f316s
            if (r9 != 0) goto L_0x01d3
            r8.mo465L()
            d.a.g.b r9 = r8.f316s
            if (r9 == 0) goto L_0x0069
            r9.mo592c()
        L_0x0069:
            androidx.appcompat.app.g r9 = r8.f309l
            if (r9 == 0) goto L_0x0076
            boolean r5 = r8.f291Q
            if (r5 != 0) goto L_0x0076
            d.a.g.b r9 = r9.onWindowStartingSupportActionMode(r0)     // Catch:{ AbstractMethodError -> 0x0076 }
            goto L_0x0077
        L_0x0076:
            r9 = r3
        L_0x0077:
            if (r9 == 0) goto L_0x007d
            r8.f316s = r9
            goto L_0x01c4
        L_0x007d:
            androidx.appcompat.widget.ActionBarContextView r9 = r8.f317t
            if (r9 != 0) goto L_0x0137
            boolean r9 = r8.f282H
            if (r9 == 0) goto L_0x010a
            android.util.TypedValue r9 = new android.util.TypedValue
            r9.<init>()
            android.content.Context r5 = r8.f303i
            android.content.res.Resources$Theme r5 = r5.getTheme()
            r6 = 2130968585(0x7f040009, float:1.7545828E38)
            r5.resolveAttribute(r6, r9, r2)
            int r6 = r9.resourceId
            if (r6 == 0) goto L_0x00bb
            android.content.Context r6 = r8.f303i
            android.content.res.Resources r6 = r6.getResources()
            android.content.res.Resources$Theme r6 = r6.newTheme()
            r6.setTo(r5)
            int r5 = r9.resourceId
            r6.applyStyle(r5, r2)
            d.a.g.d r5 = new d.a.g.d
            android.content.Context r7 = r8.f303i
            r5.<init>((android.content.Context) r7, (int) r4)
            android.content.res.Resources$Theme r7 = r5.getTheme()
            r7.setTo(r6)
            goto L_0x00bd
        L_0x00bb:
            android.content.Context r5 = r8.f303i
        L_0x00bd:
            androidx.appcompat.widget.ActionBarContextView r6 = new androidx.appcompat.widget.ActionBarContextView
            r6.<init>(r5, r3)
            r8.f317t = r6
            android.widget.PopupWindow r6 = new android.widget.PopupWindow
            r7 = 2130968599(0x7f040017, float:1.7545856E38)
            r6.<init>(r5, r3, r7)
            r8.f318u = r6
            r7 = 2
            androidx.core.widget.C0502c.m2297g(r6, r7)
            android.widget.PopupWindow r6 = r8.f318u
            androidx.appcompat.widget.ActionBarContextView r7 = r8.f317t
            r6.setContentView(r7)
            android.widget.PopupWindow r6 = r8.f318u
            r7 = -1
            r6.setWidth(r7)
            android.content.res.Resources$Theme r6 = r5.getTheme()
            r7 = 2130968579(0x7f040003, float:1.7545816E38)
            r6.resolveAttribute(r7, r9, r2)
            int r9 = r9.data
            android.content.res.Resources r5 = r5.getResources()
            android.util.DisplayMetrics r5 = r5.getDisplayMetrics()
            int r9 = android.util.TypedValue.complexToDimensionPixelSize(r9, r5)
            androidx.appcompat.widget.ActionBarContextView r5 = r8.f317t
            r5.mo1032l(r9)
            android.widget.PopupWindow r9 = r8.f318u
            r5 = -2
            r9.setHeight(r5)
            androidx.appcompat.app.k r9 = new androidx.appcompat.app.k
            r9.<init>(r8)
            r8.f319v = r9
            goto L_0x0137
        L_0x010a:
            android.view.ViewGroup r9 = r8.f323z
            r5 = 2131361865(0x7f0a0049, float:1.8343494E38)
            android.view.View r9 = r9.findViewById(r5)
            androidx.appcompat.widget.ViewStubCompat r9 = (androidx.appcompat.widget.ViewStubCompat) r9
            if (r9 == 0) goto L_0x0137
            r8.m433R()
            androidx.appcompat.app.ActionBar r5 = r8.f310m
            if (r5 == 0) goto L_0x0123
            android.content.Context r5 = r5.mo413b()
            goto L_0x0124
        L_0x0123:
            r5 = r3
        L_0x0124:
            if (r5 != 0) goto L_0x0128
            android.content.Context r5 = r8.f303i
        L_0x0128:
            android.view.LayoutInflater r5 = android.view.LayoutInflater.from(r5)
            r9.mo1552b(r5)
            android.view.View r9 = r9.mo1551a()
            androidx.appcompat.widget.ActionBarContextView r9 = (androidx.appcompat.widget.ActionBarContextView) r9
            r8.f317t = r9
        L_0x0137:
            androidx.appcompat.widget.ActionBarContextView r9 = r8.f317t
            if (r9 == 0) goto L_0x01c4
            r8.mo465L()
            androidx.appcompat.widget.ActionBarContextView r9 = r8.f317t
            r9.mo1031k()
            d.a.g.e r9 = new d.a.g.e
            androidx.appcompat.widget.ActionBarContextView r5 = r8.f317t
            android.content.Context r5 = r5.getContext()
            androidx.appcompat.widget.ActionBarContextView r6 = r8.f317t
            android.widget.PopupWindow r7 = r8.f318u
            if (r7 != 0) goto L_0x0152
            goto L_0x0153
        L_0x0152:
            r2 = 0
        L_0x0153:
            r9.<init>(r5, r6, r0, r2)
            android.view.Menu r2 = r9.mo594e()
            boolean r0 = r0.mo512b(r9, r2)
            if (r0 == 0) goto L_0x01c2
            r9.mo598k()
            androidx.appcompat.widget.ActionBarContextView r0 = r8.f317t
            r0.mo1029h(r9)
            r8.f316s = r9
            boolean r9 = r8.mo476b0()
            r0 = 1065353216(0x3f800000, float:1.0)
            if (r9 == 0) goto L_0x018c
            androidx.appcompat.widget.ActionBarContextView r9 = r8.f317t
            r1 = 0
            r9.setAlpha(r1)
            androidx.appcompat.widget.ActionBarContextView r9 = r8.f317t
            d.g.j.r r9 = p098d.p120g.p130j.C4761m.m17292a(r9)
            r9.mo21874a(r0)
            r8.f320w = r9
            androidx.appcompat.app.l r0 = new androidx.appcompat.app.l
            r0.<init>(r8)
            r9.mo21879f(r0)
            goto L_0x01b2
        L_0x018c:
            androidx.appcompat.widget.ActionBarContextView r9 = r8.f317t
            r9.setAlpha(r0)
            androidx.appcompat.widget.ActionBarContextView r9 = r8.f317t
            r9.setVisibility(r4)
            androidx.appcompat.widget.ActionBarContextView r9 = r8.f317t
            r9.sendAccessibilityEvent(r1)
            androidx.appcompat.widget.ActionBarContextView r9 = r8.f317t
            android.view.ViewParent r9 = r9.getParent()
            boolean r9 = r9 instanceof android.view.View
            if (r9 == 0) goto L_0x01b2
            androidx.appcompat.widget.ActionBarContextView r9 = r8.f317t
            android.view.ViewParent r9 = r9.getParent()
            android.view.View r9 = (android.view.View) r9
            int r0 = p098d.p120g.p130j.C4761m.f17241f
            r9.requestApplyInsets()
        L_0x01b2:
            android.widget.PopupWindow r9 = r8.f318u
            if (r9 == 0) goto L_0x01c4
            android.view.Window r9 = r8.f305j
            android.view.View r9 = r9.getDecorView()
            java.lang.Runnable r0 = r8.f319v
            r9.post(r0)
            goto L_0x01c4
        L_0x01c2:
            r8.f316s = r3
        L_0x01c4:
            d.a.g.b r9 = r8.f316s
            if (r9 == 0) goto L_0x01cf
            androidx.appcompat.app.g r0 = r8.f309l
            if (r0 == 0) goto L_0x01cf
            r0.onSupportActionModeStarted(r9)
        L_0x01cf:
            d.a.g.b r9 = r8.f316s
            r8.f316s = r9
        L_0x01d3:
            d.a.g.b r9 = r8.f316s
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AppCompatDelegateImpl.mo477c0(d.a.g.b$a):d.a.g.b");
    }

    /* renamed from: d */
    public void mo478d(View view, ViewGroup.LayoutParams layoutParams) {
        m431M();
        ((ViewGroup) this.f323z.findViewById(16908290)).addView(view, layoutParams);
        this.f307k.mo21265a().onContentChanged();
    }

    /* renamed from: e */
    public Context mo479e(Context context) {
        boolean z = true;
        this.f288N = true;
        int i = this.f292R;
        if (i == -100) {
            i = -100;
        }
        int U = mo470U(context, i);
        Configuration configuration = null;
        if (f274g && (context instanceof ContextThemeWrapper)) {
            try {
                ((ContextThemeWrapper) context).applyOverrideConfiguration(m430H(context, U, (Configuration) null));
                return context;
            } catch (IllegalStateException unused) {
            }
        }
        if (context instanceof C4592d) {
            try {
                ((C4592d) context).mo21222a(m430H(context, U, (Configuration) null));
                return context;
            } catch (IllegalStateException unused2) {
            }
        }
        if (!f273f) {
            return context;
        }
        try {
            Configuration configuration2 = context.getPackageManager().getResourcesForApplication(context.getApplicationInfo()).getConfiguration();
            Configuration configuration3 = context.getResources().getConfiguration();
            if (!configuration2.equals(configuration3)) {
                configuration = new Configuration();
                configuration.fontScale = 0.0f;
                if (!(configuration3 == null || configuration2.diff(configuration3) == 0)) {
                    float f = configuration2.fontScale;
                    float f2 = configuration3.fontScale;
                    if (f != f2) {
                        configuration.fontScale = f2;
                    }
                    int i2 = configuration2.mcc;
                    int i3 = configuration3.mcc;
                    if (i2 != i3) {
                        configuration.mcc = i3;
                    }
                    int i4 = configuration2.mnc;
                    int i5 = configuration3.mnc;
                    if (i4 != i5) {
                        configuration.mnc = i5;
                    }
                    int i6 = Build.VERSION.SDK_INT;
                    if (i6 >= 24) {
                        LocaleList locales = configuration2.getLocales();
                        LocaleList locales2 = configuration3.getLocales();
                        if (!locales.equals(locales2)) {
                            configuration.setLocales(locales2);
                            configuration.locale = configuration3.locale;
                        }
                    } else if (!Objects.equals(configuration2.locale, configuration3.locale)) {
                        configuration.locale = configuration3.locale;
                    }
                    int i7 = configuration2.touchscreen;
                    int i8 = configuration3.touchscreen;
                    if (i7 != i8) {
                        configuration.touchscreen = i8;
                    }
                    int i9 = configuration2.keyboard;
                    int i10 = configuration3.keyboard;
                    if (i9 != i10) {
                        configuration.keyboard = i10;
                    }
                    int i11 = configuration2.keyboardHidden;
                    int i12 = configuration3.keyboardHidden;
                    if (i11 != i12) {
                        configuration.keyboardHidden = i12;
                    }
                    int i13 = configuration2.navigation;
                    int i14 = configuration3.navigation;
                    if (i13 != i14) {
                        configuration.navigation = i14;
                    }
                    int i15 = configuration2.navigationHidden;
                    int i16 = configuration3.navigationHidden;
                    if (i15 != i16) {
                        configuration.navigationHidden = i16;
                    }
                    int i17 = configuration2.orientation;
                    int i18 = configuration3.orientation;
                    if (i17 != i18) {
                        configuration.orientation = i18;
                    }
                    int i19 = configuration2.screenLayout & 15;
                    int i20 = configuration3.screenLayout & 15;
                    if (i19 != i20) {
                        configuration.screenLayout |= i20;
                    }
                    int i21 = configuration2.screenLayout & 192;
                    int i22 = configuration3.screenLayout & 192;
                    if (i21 != i22) {
                        configuration.screenLayout |= i22;
                    }
                    int i23 = configuration2.screenLayout & 48;
                    int i24 = configuration3.screenLayout & 48;
                    if (i23 != i24) {
                        configuration.screenLayout |= i24;
                    }
                    int i25 = configuration2.screenLayout & 768;
                    int i26 = configuration3.screenLayout & 768;
                    if (i25 != i26) {
                        configuration.screenLayout |= i26;
                    }
                    if (i6 >= 26) {
                        int i27 = configuration2.colorMode & 3;
                        int i28 = configuration3.colorMode & 3;
                        if (i27 != i28) {
                            configuration.colorMode |= i28;
                        }
                        int i29 = configuration2.colorMode & 12;
                        int i30 = configuration3.colorMode & 12;
                        if (i29 != i30) {
                            configuration.colorMode |= i30;
                        }
                    }
                    int i31 = configuration2.uiMode & 15;
                    int i32 = configuration3.uiMode & 15;
                    if (i31 != i32) {
                        configuration.uiMode |= i32;
                    }
                    int i33 = configuration2.uiMode & 48;
                    int i34 = configuration3.uiMode & 48;
                    if (i33 != i34) {
                        configuration.uiMode |= i34;
                    }
                    int i35 = configuration2.screenWidthDp;
                    int i36 = configuration3.screenWidthDp;
                    if (i35 != i36) {
                        configuration.screenWidthDp = i36;
                    }
                    int i37 = configuration2.screenHeightDp;
                    int i38 = configuration3.screenHeightDp;
                    if (i37 != i38) {
                        configuration.screenHeightDp = i38;
                    }
                    int i39 = configuration2.smallestScreenWidthDp;
                    int i40 = configuration3.smallestScreenWidthDp;
                    if (i39 != i40) {
                        configuration.smallestScreenWidthDp = i40;
                    }
                    int i41 = configuration2.densityDpi;
                    int i42 = configuration3.densityDpi;
                    if (i41 != i42) {
                        configuration.densityDpi = i42;
                    }
                }
            }
            Configuration H = m430H(context, U, configuration);
            C4592d dVar = new C4592d(context, 2131821065);
            dVar.mo21222a(H);
            boolean z2 = false;
            try {
                if (context.getTheme() == null) {
                    z = false;
                }
                z2 = z;
            } catch (NullPointerException unused3) {
            }
            if (z2) {
                C0476a.m2183u(dVar.getTheme());
            }
            return dVar;
        } catch (PackageManager.NameNotFoundException e) {
            throw new RuntimeException("Application failed to obtain resources from itself", e);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e0 */
    public final int mo480e0(C4780v vVar, Rect rect) {
        boolean z;
        boolean z2;
        int i;
        Context context;
        ViewGroup.MarginLayoutParams marginLayoutParams;
        int i2;
        int g = vVar.mo21895g();
        ActionBarContextView actionBarContextView = this.f317t;
        int i3 = 8;
        if (actionBarContextView == null || !(actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) {
            z = false;
        } else {
            ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) this.f317t.getLayoutParams();
            boolean z3 = true;
            if (this.f317t.isShown()) {
                if (this.f304i0 == null) {
                    this.f304i0 = new Rect();
                    this.f306j0 = new Rect();
                }
                Rect rect2 = this.f304i0;
                Rect rect3 = this.f306j0;
                rect2.set(vVar.mo21892e(), vVar.mo21895g(), vVar.mo21894f(), vVar.mo21891d());
                C0280l0.m1309a(this.f323z, rect2, rect3);
                int i4 = rect2.top;
                int i5 = rect2.left;
                int i6 = rect2.right;
                C4780v j = C4761m.m17301j(this.f323z);
                int e = j == null ? 0 : j.mo21892e();
                int f = j == null ? 0 : j.mo21894f();
                if (marginLayoutParams2.topMargin == i4 && marginLayoutParams2.leftMargin == i5 && marginLayoutParams2.rightMargin == i6) {
                    z2 = false;
                } else {
                    marginLayoutParams2.topMargin = i4;
                    marginLayoutParams2.leftMargin = i5;
                    marginLayoutParams2.rightMargin = i6;
                    z2 = true;
                }
                if (i4 <= 0 || this.f276B != null) {
                    View view = this.f276B;
                    if (!(view == null || ((marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams()).height == (i2 = marginLayoutParams2.topMargin) && marginLayoutParams.leftMargin == e && marginLayoutParams.rightMargin == f))) {
                        marginLayoutParams.height = i2;
                        marginLayoutParams.leftMargin = e;
                        marginLayoutParams.rightMargin = f;
                        this.f276B.setLayoutParams(marginLayoutParams);
                    }
                } else {
                    View view2 = new View(this.f303i);
                    this.f276B = view2;
                    view2.setVisibility(8);
                    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams2.topMargin, 51);
                    layoutParams.leftMargin = e;
                    layoutParams.rightMargin = f;
                    this.f323z.addView(this.f276B, -1, layoutParams);
                }
                View view3 = this.f276B;
                z = view3 != null;
                if (z && view3.getVisibility() != 0) {
                    View view4 = this.f276B;
                    int i7 = C4761m.f17241f;
                    if ((view4.getWindowSystemUiVisibility() & 8192) == 0) {
                        z3 = false;
                    }
                    if (z3) {
                        context = this.f303i;
                        i = R.color.abc_decor_view_status_guard_light;
                    } else {
                        context = this.f303i;
                        i = R.color.abc_decor_view_status_guard;
                    }
                    view4.setBackgroundColor(C0474a.m2161b(context, i));
                }
                if (!this.f281G && z) {
                    g = 0;
                }
                z3 = z2;
            } else {
                if (marginLayoutParams2.topMargin != 0) {
                    marginLayoutParams2.topMargin = 0;
                } else {
                    z3 = false;
                }
                z = false;
            }
            if (z3) {
                this.f317t.setLayoutParams(marginLayoutParams2);
            }
        }
        View view5 = this.f276B;
        if (view5 != null) {
            if (z) {
                i3 = 0;
            }
            view5.setVisibility(i3);
        }
        return g;
    }

    /* renamed from: f */
    public <T extends View> T mo481f(int i) {
        m431M();
        return this.f305j.findViewById(i);
    }

    /* renamed from: g */
    public int mo482g() {
        return this.f292R;
    }

    /* renamed from: h */
    public MenuInflater mo483h() {
        if (this.f311n == null) {
            m433R();
            ActionBar actionBar = this.f310m;
            this.f311n = new C4596g(actionBar != null ? actionBar.mo413b() : this.f303i);
        }
        return this.f311n;
    }

    /* renamed from: i */
    public ActionBar mo484i() {
        m433R();
        return this.f310m;
    }

    /* renamed from: j */
    public void mo485j() {
        LayoutInflater from = LayoutInflater.from(this.f303i);
        if (from.getFactory() == null) {
            from.setFactory2(this);
        } else if (!(from.getFactory2() instanceof AppCompatDelegateImpl)) {
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }

    /* renamed from: k */
    public void mo486k() {
        m433R();
        ActionBar actionBar = this.f310m;
        m434S(0);
    }

    /* renamed from: l */
    public void mo487l(Configuration configuration) {
        if (this.f279E && this.f322y) {
            m433R();
            ActionBar actionBar = this.f310m;
            if (actionBar != null) {
                actionBar.mo414c(configuration);
            }
        }
        C0257e.m1166b().mo1586g(this.f303i);
        m428C(false);
    }

    /* renamed from: m */
    public void mo488m(Bundle bundle) {
        this.f288N = true;
        m428C(false);
        m432N();
        Object obj = this.f301h;
        if (obj instanceof Activity) {
            String str = null;
            try {
                Activity activity = (Activity) obj;
                str = C4690a.m17118i(activity, activity.getComponentName());
            } catch (PackageManager.NameNotFoundException e) {
                throw new IllegalArgumentException(e);
            } catch (IllegalArgumentException unused) {
            }
            if (str != null) {
                ActionBar actionBar = this.f310m;
                if (actionBar == null) {
                    this.f302h0 = true;
                } else {
                    actionBar.mo415d(true);
                }
            }
            C0131h.m518c(this);
        }
        this.f289O = true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x005b  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0062  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0069  */
    /* JADX WARNING: Removed duplicated region for block: B:24:? A[RETURN, SYNTHETIC] */
    /* renamed from: n */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo489n() {
        /*
            r3 = this;
            java.lang.Object r0 = r3.f301h
            boolean r0 = r0 instanceof android.app.Activity
            if (r0 == 0) goto L_0x0009
            androidx.appcompat.app.C0131h.m519t(r3)
        L_0x0009:
            boolean r0 = r3.f298e0
            if (r0 == 0) goto L_0x0018
            android.view.Window r0 = r3.f305j
            android.view.View r0 = r0.getDecorView()
            java.lang.Runnable r1 = r3.f300g0
            r0.removeCallbacks(r1)
        L_0x0018:
            r0 = 0
            r3.f290P = r0
            r0 = 1
            r3.f291Q = r0
            int r0 = r3.f292R
            r1 = -100
            if (r0 == r1) goto L_0x0048
            java.lang.Object r0 = r3.f301h
            boolean r1 = r0 instanceof android.app.Activity
            if (r1 == 0) goto L_0x0048
            android.app.Activity r0 = (android.app.Activity) r0
            boolean r0 = r0.isChangingConfigurations()
            if (r0 == 0) goto L_0x0048
            d.d.j<java.lang.String, java.lang.Integer> r0 = f271d
            java.lang.Object r1 = r3.f301h
            java.lang.Class r1 = r1.getClass()
            java.lang.String r1 = r1.getName()
            int r2 = r3.f292R
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r0.put(r1, r2)
            goto L_0x0057
        L_0x0048:
            d.d.j<java.lang.String, java.lang.Integer> r0 = f271d
            java.lang.Object r1 = r3.f301h
            java.lang.Class r1 = r1.getClass()
            java.lang.String r1 = r1.getName()
            r0.remove(r1)
        L_0x0057:
            androidx.appcompat.app.ActionBar r0 = r3.f310m
            if (r0 == 0) goto L_0x005e
            java.util.Objects.requireNonNull(r0)
        L_0x005e:
            androidx.appcompat.app.AppCompatDelegateImpl$f r0 = r3.f296c0
            if (r0 == 0) goto L_0x0065
            r0.mo530a()
        L_0x0065:
            androidx.appcompat.app.AppCompatDelegateImpl$f r0 = r3.f297d0
            if (r0 == 0) goto L_0x006c
            r0.mo530a()
        L_0x006c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AppCompatDelegateImpl.mo489n():void");
    }

    /* renamed from: o */
    public void mo490o(Bundle bundle) {
        m431M();
    }

    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        C0139n nVar;
        if (this.f308k0 == null) {
            String string = this.f303i.obtainStyledAttributes(C4568b.f16463k).getString(114);
            if (string == null) {
                nVar = new C0139n();
            } else {
                try {
                    this.f308k0 = (C0139n) Class.forName(string).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                } catch (Throwable th) {
                    Log.i("AppCompatDelegate", "Failed to instantiate custom view inflater " + string + ". Falling back to default.", th);
                    nVar = new C0139n();
                }
            }
            this.f308k0 = nVar;
        }
        C0139n nVar2 = this.f308k0;
        int i = C0275k0.f1170a;
        return nVar2.mo581g(view, str, context, attributeSet, false, false, true, false);
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView((View) null, str, context, attributeSet);
    }

    /* renamed from: p */
    public void mo493p() {
        m433R();
        ActionBar actionBar = this.f310m;
        if (actionBar != null) {
            actionBar.mo416e(true);
        }
    }

    /* renamed from: q */
    public void mo494q(Bundle bundle) {
    }

    /* renamed from: r */
    public void mo495r() {
        this.f290P = true;
        mo458B();
    }

    /* renamed from: s */
    public void mo496s() {
        this.f290P = false;
        m433R();
        ActionBar actionBar = this.f310m;
        if (actionBar != null) {
            actionBar.mo416e(false);
        }
    }

    /* renamed from: v */
    public boolean mo497v(int i) {
        if (i == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            i = 108;
        } else if (i == 9) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
            i = 109;
        }
        if (this.f283I && i == 108) {
            return false;
        }
        if (this.f279E && i == 1) {
            this.f279E = false;
        }
        if (i == 1) {
            m438d0();
            this.f283I = true;
            return true;
        } else if (i == 2) {
            m438d0();
            this.f277C = true;
            return true;
        } else if (i == 5) {
            m438d0();
            this.f278D = true;
            return true;
        } else if (i == 10) {
            m438d0();
            this.f281G = true;
            return true;
        } else if (i == 108) {
            m438d0();
            this.f279E = true;
            return true;
        } else if (i != 109) {
            return this.f305j.requestFeature(i);
        } else {
            m438d0();
            this.f280F = true;
            return true;
        }
    }

    /* renamed from: w */
    public void mo498w(int i) {
        m431M();
        ViewGroup viewGroup = (ViewGroup) this.f323z.findViewById(16908290);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.f303i).inflate(i, viewGroup);
        this.f307k.mo21265a().onContentChanged();
    }

    /* renamed from: x */
    public void mo499x(View view) {
        m431M();
        ViewGroup viewGroup = (ViewGroup) this.f323z.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.f307k.mo21265a().onContentChanged();
    }

    /* renamed from: y */
    public void mo500y(View view, ViewGroup.LayoutParams layoutParams) {
        m431M();
        ViewGroup viewGroup = (ViewGroup) this.f323z.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.f307k.mo21265a().onContentChanged();
    }

    /* renamed from: z */
    public void mo501z(int i) {
        this.f293Z = i;
    }
}
