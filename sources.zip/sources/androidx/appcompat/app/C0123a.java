package androidx.appcompat.app;

import android.view.View;
import androidx.core.widget.NestedScrollView;

/* renamed from: androidx.appcompat.app.a */
class C0123a implements NestedScrollView.C0497b {

    /* renamed from: a */
    final /* synthetic */ View f367a;

    /* renamed from: b */
    final /* synthetic */ View f368b;

    C0123a(AlertController alertController, View view, View view2) {
        this.f367a = view;
        this.f368b = view2;
    }

    /* renamed from: a */
    public void mo536a(NestedScrollView nestedScrollView, int i, int i2, int i3, int i4) {
        AlertController.m415d(nestedScrollView, this.f367a, this.f368b);
    }
}
