package androidx.appcompat.app;

import android.view.View;

/* renamed from: androidx.appcompat.app.b */
class C0124b implements Runnable {

    /* renamed from: a */
    final /* synthetic */ View f369a;

    /* renamed from: b */
    final /* synthetic */ View f370b;

    /* renamed from: c */
    final /* synthetic */ AlertController f371c;

    C0124b(AlertController alertController, View view, View view2) {
        this.f371c = alertController;
        this.f369a = view;
        this.f370b = view2;
    }

    public void run() {
        AlertController.m415d(this.f371c.f212A, this.f369a, this.f370b);
    }
}
