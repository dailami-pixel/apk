package androidx.appcompat.app;

import android.view.View;
import android.widget.AbsListView;

/* renamed from: androidx.appcompat.app.c */
class C0125c implements AbsListView.OnScrollListener {

    /* renamed from: a */
    final /* synthetic */ View f372a;

    /* renamed from: b */
    final /* synthetic */ View f373b;

    C0125c(AlertController alertController, View view, View view2) {
        this.f372a = view;
        this.f373b = view2;
    }

    public void onScroll(AbsListView absListView, int i, int i2, int i3) {
        AlertController.m415d(absListView, this.f372a, this.f373b);
    }

    public void onScrollStateChanged(AbsListView absListView, int i) {
    }
}
