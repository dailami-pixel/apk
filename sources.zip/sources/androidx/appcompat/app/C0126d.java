package androidx.appcompat.app;

import android.view.View;

/* renamed from: androidx.appcompat.app.d */
class C0126d implements Runnable {

    /* renamed from: a */
    final /* synthetic */ View f374a;

    /* renamed from: b */
    final /* synthetic */ View f375b;

    /* renamed from: c */
    final /* synthetic */ AlertController f376c;

    C0126d(AlertController alertController, View view, View view2) {
        this.f376c = alertController;
        this.f374a = view;
        this.f375b = view2;
    }

    public void run() {
        AlertController.m415d(this.f376c.f236g, this.f374a, this.f375b);
    }
}
