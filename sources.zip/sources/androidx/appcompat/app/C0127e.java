package androidx.appcompat.app;

import android.view.View;
import android.widget.AdapterView;
import androidx.appcompat.app.AlertController;

/* renamed from: androidx.appcompat.app.e */
class C0127e implements AdapterView.OnItemClickListener {

    /* renamed from: a */
    final /* synthetic */ AlertController f377a;

    /* renamed from: b */
    final /* synthetic */ AlertController.C0107b f378b;

    C0127e(AlertController.C0107b bVar, AlertController alertController) {
        this.f378b = bVar;
        this.f377a = alertController;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        this.f378b.f266h.onClick(this.f377a.f231b, i);
        if (!this.f378b.f267i) {
            this.f377a.f231b.dismiss();
        }
    }
}
