package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AlertController;
import androidx.core.widget.NestedScrollView;
import com.vidio.android.p195tv.R;
import java.util.Objects;

/* renamed from: androidx.appcompat.app.f */
public class C0128f extends C0137m implements DialogInterface {

    /* renamed from: a */
    final AlertController f379a = new AlertController(getContext(), this, getWindow());

    /* renamed from: androidx.appcompat.app.f$a */
    public static class C0129a {

        /* renamed from: a */
        private final AlertController.C0107b f380a;

        /* renamed from: b */
        private final int f381b;

        public C0129a(Context context) {
            int b = C0128f.m508b(context, 0);
            this.f380a = new AlertController.C0107b(new ContextThemeWrapper(context, C0128f.m508b(context, b)));
            this.f381b = b;
        }

        /* renamed from: a */
        public C0128f mo547a() {
            C0128f fVar = new C0128f(this.f380a.f259a, this.f381b);
            AlertController.C0107b bVar = this.f380a;
            AlertController alertController = fVar.f379a;
            View view = bVar.f263e;
            if (view != null) {
                alertController.mo419f(view);
            } else {
                CharSequence charSequence = bVar.f262d;
                if (charSequence != null) {
                    alertController.mo421h(charSequence);
                }
                Drawable drawable = bVar.f261c;
                if (drawable != null) {
                    alertController.mo420g(drawable);
                }
            }
            if (bVar.f265g != null) {
                AlertController.RecycleListView recycleListView = (AlertController.RecycleListView) bVar.f260b.inflate(alertController.f223L, (ViewGroup) null);
                int i = bVar.f267i ? alertController.f225N : alertController.f226O;
                ListAdapter listAdapter = bVar.f265g;
                if (listAdapter == null) {
                    listAdapter = new AlertController.C0109d(bVar.f259a, i, 16908308, (CharSequence[]) null);
                }
                alertController.f219H = listAdapter;
                alertController.f220I = bVar.f268j;
                if (bVar.f266h != null) {
                    recycleListView.setOnItemClickListener(new C0127e(bVar, alertController));
                }
                if (bVar.f267i) {
                    recycleListView.setChoiceMode(1);
                }
                alertController.f236g = recycleListView;
            }
            Objects.requireNonNull(this.f380a);
            fVar.setCancelable(true);
            Objects.requireNonNull(this.f380a);
            fVar.setCanceledOnTouchOutside(true);
            Objects.requireNonNull(this.f380a);
            fVar.setOnCancelListener((DialogInterface.OnCancelListener) null);
            Objects.requireNonNull(this.f380a);
            fVar.setOnDismissListener((DialogInterface.OnDismissListener) null);
            DialogInterface.OnKeyListener onKeyListener = this.f380a.f264f;
            if (onKeyListener != null) {
                fVar.setOnKeyListener(onKeyListener);
            }
            return fVar;
        }

        /* renamed from: b */
        public Context mo548b() {
            return this.f380a.f259a;
        }

        /* renamed from: c */
        public C0129a mo549c(ListAdapter listAdapter, DialogInterface.OnClickListener onClickListener) {
            AlertController.C0107b bVar = this.f380a;
            bVar.f265g = listAdapter;
            bVar.f266h = onClickListener;
            return this;
        }

        /* renamed from: d */
        public C0129a mo550d(View view) {
            this.f380a.f263e = view;
            return this;
        }

        /* renamed from: e */
        public C0129a mo551e(Drawable drawable) {
            this.f380a.f261c = drawable;
            return this;
        }

        /* renamed from: f */
        public C0129a mo552f(DialogInterface.OnKeyListener onKeyListener) {
            this.f380a.f264f = onKeyListener;
            return this;
        }

        /* renamed from: g */
        public C0129a mo553g(ListAdapter listAdapter, int i, DialogInterface.OnClickListener onClickListener) {
            AlertController.C0107b bVar = this.f380a;
            bVar.f265g = listAdapter;
            bVar.f266h = onClickListener;
            bVar.f268j = i;
            bVar.f267i = true;
            return this;
        }

        /* renamed from: h */
        public C0129a mo554h(CharSequence charSequence) {
            this.f380a.f262d = charSequence;
            return this;
        }
    }

    protected C0128f(Context context, int i) {
        super(context, m508b(context, i));
    }

    /* renamed from: b */
    static int m508b(Context context, int i) {
        if (((i >>> 24) & 255) >= 1) {
            return i;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.alertDialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    /* renamed from: a */
    public ListView mo542a() {
        return this.f379a.f236g;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f379a.mo418c();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f379a.f212A;
        if (nestedScrollView != null && nestedScrollView.mo2402i(keyEvent)) {
            return true;
        }
        return super.onKeyDown(i, keyEvent);
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f379a.f212A;
        if (nestedScrollView != null && nestedScrollView.mo2402i(keyEvent)) {
            return true;
        }
        return super.onKeyUp(i, keyEvent);
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        this.f379a.mo421h(charSequence);
    }
}
