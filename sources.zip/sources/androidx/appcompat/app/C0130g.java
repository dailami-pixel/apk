package androidx.appcompat.app;

import p098d.p099a.p106g.C4589b;

/* renamed from: androidx.appcompat.app.g */
public interface C0130g {
    void onSupportActionModeFinished(C4589b bVar);

    void onSupportActionModeStarted(C4589b bVar);

    C4589b onWindowStartingSupportActionMode(C4589b.C4590a aVar);
}
