package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import p098d.p112d.C4619c;

/* renamed from: androidx.appcompat.app.h */
public abstract class C0131h {

    /* renamed from: a */
    private static final C4619c<WeakReference<C0131h>> f382a = new C4619c<>(0);

    /* renamed from: b */
    private static final Object f383b = new Object();

    /* renamed from: c */
    public static final /* synthetic */ int f384c = 0;

    C0131h() {
    }

    /* renamed from: c */
    static void m518c(C0131h hVar) {
        synchronized (f383b) {
            m520u(hVar);
            f382a.add(new WeakReference(hVar));
        }
    }

    /* renamed from: t */
    static void m519t(C0131h hVar) {
        synchronized (f383b) {
            m520u(hVar);
        }
    }

    /* renamed from: u */
    private static void m520u(C0131h hVar) {
        synchronized (f383b) {
            Iterator<WeakReference<C0131h>> it = f382a.iterator();
            while (it.hasNext()) {
                C0131h hVar2 = (C0131h) it.next().get();
                if (hVar2 == hVar || hVar2 == null) {
                    it.remove();
                }
            }
        }
    }

    /* renamed from: A */
    public abstract void mo457A(CharSequence charSequence);

    /* renamed from: d */
    public abstract void mo478d(View view, ViewGroup.LayoutParams layoutParams);

    /* renamed from: e */
    public Context mo479e(Context context) {
        return context;
    }

    /* renamed from: f */
    public abstract <T extends View> T mo481f(int i);

    /* renamed from: g */
    public int mo482g() {
        return -100;
    }

    /* renamed from: h */
    public abstract MenuInflater mo483h();

    /* renamed from: i */
    public abstract ActionBar mo484i();

    /* renamed from: j */
    public abstract void mo485j();

    /* renamed from: k */
    public abstract void mo486k();

    /* renamed from: l */
    public abstract void mo487l(Configuration configuration);

    /* renamed from: m */
    public abstract void mo488m(Bundle bundle);

    /* renamed from: n */
    public abstract void mo489n();

    /* renamed from: o */
    public abstract void mo490o(Bundle bundle);

    /* renamed from: p */
    public abstract void mo493p();

    /* renamed from: q */
    public abstract void mo494q(Bundle bundle);

    /* renamed from: r */
    public abstract void mo495r();

    /* renamed from: s */
    public abstract void mo496s();

    /* renamed from: v */
    public abstract boolean mo497v(int i);

    /* renamed from: w */
    public abstract void mo498w(int i);

    /* renamed from: x */
    public abstract void mo499x(View view);

    /* renamed from: y */
    public abstract void mo500y(View view, ViewGroup.LayoutParams layoutParams);

    /* renamed from: z */
    public void mo501z(int i) {
    }
}
