package androidx.appcompat.app;

import android.graphics.Rect;
import android.view.View;
import p098d.p120g.p121c.C4694c;
import p098d.p120g.p130j.C4758j;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.C4780v;

/* renamed from: androidx.appcompat.app.i */
class C0132i implements C4758j {

    /* renamed from: a */
    final /* synthetic */ AppCompatDelegateImpl f385a;

    C0132i(AppCompatDelegateImpl appCompatDelegateImpl) {
        this.f385a = appCompatDelegateImpl;
    }

    /* renamed from: a */
    public C4780v mo555a(View view, C4780v vVar) {
        int g = vVar.mo21895g();
        int e0 = this.f385a.mo480e0(vVar, (Rect) null);
        if (g != e0) {
            int e = vVar.mo21892e();
            int f = vVar.mo21894f();
            int d = vVar.mo21891d();
            C4780v.C4781a aVar = new C4780v.C4781a(vVar);
            aVar.mo21903c(C4694c.m17140a(e, e0, f, d));
            vVar = aVar.mo21901a();
        }
        return C4761m.m17305n(view, vVar);
    }
}
