package androidx.appcompat.app;

import androidx.appcompat.widget.ContentFrameLayout;

/* renamed from: androidx.appcompat.app.j */
class C0133j implements ContentFrameLayout.C0222a {

    /* renamed from: a */
    final /* synthetic */ AppCompatDelegateImpl f386a;

    C0133j(AppCompatDelegateImpl appCompatDelegateImpl) {
        this.f386a = appCompatDelegateImpl;
    }

    /* renamed from: a */
    public void mo556a() {
    }

    public void onDetachedFromWindow() {
        this.f386a.mo462I();
    }
}
