package androidx.appcompat.app;

import android.view.View;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.C4774r;
import p098d.p120g.p130j.C4777s;
import p098d.p120g.p130j.C4778t;

/* renamed from: androidx.appcompat.app.k */
class C0134k implements Runnable {

    /* renamed from: a */
    final /* synthetic */ AppCompatDelegateImpl f387a;

    /* renamed from: androidx.appcompat.app.k$a */
    class C0135a extends C4778t {
        C0135a() {
        }

        /* renamed from: b */
        public void mo515b(View view) {
            C0134k.this.f387a.f317t.setAlpha(1.0f);
            C0134k.this.f387a.f320w.mo21879f((C4777s) null);
            C0134k.this.f387a.f320w = null;
        }

        /* renamed from: c */
        public void mo559c(View view) {
            C0134k.this.f387a.f317t.setVisibility(0);
        }
    }

    C0134k(AppCompatDelegateImpl appCompatDelegateImpl) {
        this.f387a = appCompatDelegateImpl;
    }

    public void run() {
        AppCompatDelegateImpl appCompatDelegateImpl = this.f387a;
        appCompatDelegateImpl.f318u.showAtLocation(appCompatDelegateImpl.f317t, 55, 0, 0);
        this.f387a.mo465L();
        if (this.f387a.mo476b0()) {
            this.f387a.f317t.setAlpha(0.0f);
            AppCompatDelegateImpl appCompatDelegateImpl2 = this.f387a;
            C4774r a = C4761m.m17292a(appCompatDelegateImpl2.f317t);
            a.mo21874a(1.0f);
            appCompatDelegateImpl2.f320w = a;
            this.f387a.f320w.mo21879f(new C0135a());
            return;
        }
        this.f387a.f317t.setAlpha(1.0f);
        this.f387a.f317t.setVisibility(0);
    }
}
