package androidx.appcompat.app;

import android.view.View;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.C4777s;
import p098d.p120g.p130j.C4778t;

/* renamed from: androidx.appcompat.app.l */
class C0136l extends C4778t {

    /* renamed from: a */
    final /* synthetic */ AppCompatDelegateImpl f389a;

    C0136l(AppCompatDelegateImpl appCompatDelegateImpl) {
        this.f389a = appCompatDelegateImpl;
    }

    /* renamed from: b */
    public void mo515b(View view) {
        this.f389a.f317t.setAlpha(1.0f);
        this.f389a.f320w.mo21879f((C4777s) null);
        this.f389a.f320w = null;
    }

    /* renamed from: c */
    public void mo559c(View view) {
        this.f389a.f317t.setVisibility(0);
        this.f389a.f317t.sendAccessibilityEvent(32);
        if (this.f389a.f317t.getParent() instanceof View) {
            int i = C4761m.f17241f;
            ((View) this.f389a.f317t.getParent()).requestApplyInsets();
        }
    }
}
