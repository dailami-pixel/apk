package androidx.appcompat.app;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import com.vidio.android.p195tv.R;
import p098d.p099a.p106g.C4589b;
import p098d.p120g.p130j.C4751d;

/* renamed from: androidx.appcompat.app.m */
public class C0137m extends Dialog implements C0130g {
    private C0131h mDelegate;
    private final C4751d.C4752a mKeyDispatcher;

    /* renamed from: androidx.appcompat.app.m$a */
    class C0138a implements C4751d.C4752a {
        C0138a() {
        }

        /* renamed from: a0 */
        public boolean mo574a0(KeyEvent keyEvent) {
            return C0137m.this.superDispatchKeyEvent(keyEvent);
        }
    }

    public C0137m(Context context) {
        this(context, 0);
    }

    public C0137m(Context context, int i) {
        super(context, getThemeResId(context, i));
        this.mKeyDispatcher = new C0138a();
        C0131h delegate = getDelegate();
        delegate.mo501z(getThemeResId(context, i));
        delegate.mo488m((Bundle) null);
    }

    protected C0137m(Context context, boolean z, DialogInterface.OnCancelListener onCancelListener) {
        super(context, z, onCancelListener);
        this.mKeyDispatcher = new C0138a();
    }

    private static int getThemeResId(Context context, int i) {
        if (i != 0) {
            return i;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.dialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        getDelegate().mo478d(view, layoutParams);
    }

    public void dismiss() {
        super.dismiss();
        getDelegate().mo489n();
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return C4751d.m17262b(this.mKeyDispatcher, getWindow().getDecorView(), this, keyEvent);
    }

    public <T extends View> T findViewById(int i) {
        return getDelegate().mo481f(i);
    }

    public C0131h getDelegate() {
        if (this.mDelegate == null) {
            int i = C0131h.f384c;
            this.mDelegate = new AppCompatDelegateImpl((Dialog) this, (C0130g) this);
        }
        return this.mDelegate;
    }

    public ActionBar getSupportActionBar() {
        return getDelegate().mo484i();
    }

    public void invalidateOptionsMenu() {
        getDelegate().mo486k();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        getDelegate().mo485j();
        super.onCreate(bundle);
        getDelegate().mo488m(bundle);
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        getDelegate().mo496s();
    }

    public void onSupportActionModeFinished(C4589b bVar) {
    }

    public void onSupportActionModeStarted(C4589b bVar) {
    }

    public C4589b onWindowStartingSupportActionMode(C4589b.C4590a aVar) {
        return null;
    }

    public void setContentView(int i) {
        getDelegate().mo498w(i);
    }

    public void setContentView(View view) {
        getDelegate().mo499x(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        getDelegate().mo500y(view, layoutParams);
    }

    public void setTitle(int i) {
        super.setTitle(i);
        getDelegate().mo457A(getContext().getString(i));
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        getDelegate().mo457A(charSequence);
    }

    /* access modifiers changed from: package-private */
    public boolean superDispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean supportRequestWindowFeature(int i) {
        return getDelegate().mo497v(i);
    }
}
