package androidx.appcompat.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.util.AttributeSet;
import android.view.InflateException;
import android.view.View;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.appcompat.widget.AppCompatTextView;
import com.appsflyer.oaid.BuildConfig;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import p098d.p112d.C4631j;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.appcompat.app.n */
public class C0139n {

    /* renamed from: a */
    private static final Class<?>[] f391a = {Context.class, AttributeSet.class};

    /* renamed from: b */
    private static final int[] f392b = {16843375};

    /* renamed from: c */
    private static final String[] f393c = {"android.widget.", "android.view.", "android.webkit."};

    /* renamed from: d */
    private static final C4631j<String, Constructor<? extends View>> f394d = new C4631j<>();

    /* renamed from: e */
    private final Object[] f395e = new Object[2];

    /* renamed from: androidx.appcompat.app.n$a */
    private static class C0140a implements View.OnClickListener {

        /* renamed from: a */
        private final View f396a;

        /* renamed from: b */
        private final String f397b;

        /* renamed from: c */
        private Method f398c;

        /* renamed from: d */
        private Context f399d;

        public C0140a(View view, String str) {
            this.f396a = view;
            this.f397b = str;
        }

        public void onClick(View view) {
            String str;
            Method method;
            if (this.f398c == null) {
                for (Context context = this.f396a.getContext(); context != null; context = context instanceof ContextWrapper ? ((ContextWrapper) context).getBaseContext() : null) {
                    try {
                        if (!context.isRestricted() && (method = context.getClass().getMethod(this.f397b, new Class[]{View.class})) != null) {
                            this.f398c = method;
                            this.f399d = context;
                        }
                    } catch (NoSuchMethodException unused) {
                    }
                }
                int id = this.f396a.getId();
                if (id == -1) {
                    str = BuildConfig.FLAVOR;
                } else {
                    StringBuilder P = C4924a.m17863P(" with id '");
                    P.append(this.f396a.getContext().getResources().getResourceEntryName(id));
                    P.append("'");
                    str = P.toString();
                }
                StringBuilder P2 = C4924a.m17863P("Could not find method ");
                P2.append(this.f397b);
                P2.append("(View) in a parent or ancestor Context for android:onClick attribute defined on view ");
                P2.append(this.f396a.getClass());
                P2.append(str);
                throw new IllegalStateException(P2.toString());
            }
            try {
                this.f398c.invoke(this.f399d, new Object[]{view});
            } catch (IllegalAccessException e) {
                throw new IllegalStateException("Could not execute non-public method for android:onClick", e);
            } catch (InvocationTargetException e2) {
                throw new IllegalStateException("Could not execute method for android:onClick", e2);
            }
        }
    }

    /* renamed from: h */
    private View m550h(Context context, String str, String str2) throws ClassNotFoundException, InflateException {
        String str3;
        C4631j<String, Constructor<? extends View>> jVar = f394d;
        Constructor<? extends U> orDefault = jVar.getOrDefault(str, null);
        if (orDefault == null) {
            if (str2 != null) {
                try {
                    str3 = str2 + str;
                } catch (Exception unused) {
                    return null;
                }
            } else {
                str3 = str;
            }
            orDefault = Class.forName(str3, false, context.getClassLoader()).asSubclass(View.class).getConstructor(f391a);
            jVar.put(str, orDefault);
        }
        orDefault.setAccessible(true);
        return (View) orDefault.newInstance(this.f395e);
    }

    /* renamed from: i */
    private void m551i(View view, String str) {
        if (view == null) {
            throw new IllegalStateException(getClass().getName() + " asked to inflate view for <" + str + ">, but returned null");
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public AppCompatAutoCompleteTextView mo575a(Context context, AttributeSet attributeSet) {
        return new AppCompatAutoCompleteTextView(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public AppCompatButton mo576b(Context context, AttributeSet attributeSet) {
        return new AppCompatButton(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public AppCompatCheckBox mo577c(Context context, AttributeSet attributeSet) {
        return new AppCompatCheckBox(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    /* renamed from: d */
    public AppCompatRadioButton mo578d(Context context, AttributeSet attributeSet) {
        return new AppCompatRadioButton(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    /* renamed from: e */
    public AppCompatTextView mo579e(Context context, AttributeSet attributeSet) {
        return new AppCompatTextView(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public View mo580f() {
        return null;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v5, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v7, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v8, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v8, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v9, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v10, resolved type: d.a.g.d} */
    /* JADX WARNING: type inference failed for: r8v3 */
    /* JADX WARNING: type inference failed for: r8v4, types: [android.view.View] */
    /* JADX WARNING: type inference failed for: r8v5, types: [java.lang.String] */
    /* JADX WARNING: type inference failed for: r8v6 */
    /* JADX WARNING: type inference failed for: r8v7 */
    /* JADX WARNING: type inference failed for: r8v67 */
    /* JADX WARNING: type inference failed for: r8v79 */
    /* access modifiers changed from: package-private */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:56:0x00cf, code lost:
        if (r5.equals("ImageButton") == false) goto L_0x0058;
     */
    /* JADX WARNING: Failed to insert additional move for type inference */
    /* JADX WARNING: Multi-variable type inference failed */
    /* renamed from: g */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View mo581g(android.view.View r4, java.lang.String r5, android.content.Context r6, android.util.AttributeSet r7, boolean r8, boolean r9, boolean r10, boolean r11) {
        /*
            r3 = this;
            if (r8 == 0) goto L_0x0009
            if (r4 == 0) goto L_0x0009
            android.content.Context r4 = r4.getContext()
            goto L_0x000a
        L_0x0009:
            r4 = r6
        L_0x000a:
            r8 = 4
            r0 = 0
            if (r9 != 0) goto L_0x0010
            if (r10 == 0) goto L_0x0047
        L_0x0010:
            int[] r1 = p098d.p099a.C4568b.f16450A
            android.content.res.TypedArray r1 = r4.obtainStyledAttributes(r7, r1, r0, r0)
            if (r9 == 0) goto L_0x001d
            int r9 = r1.getResourceId(r0, r0)
            goto L_0x001e
        L_0x001d:
            r9 = 0
        L_0x001e:
            if (r10 == 0) goto L_0x002f
            if (r9 != 0) goto L_0x002f
            int r9 = r1.getResourceId(r8, r0)
            if (r9 == 0) goto L_0x002f
            java.lang.String r10 = "AppCompatViewInflater"
            java.lang.String r2 = "app:theme is now deprecated. Please move to using android:theme instead."
            android.util.Log.i(r10, r2)
        L_0x002f:
            r1.recycle()
            if (r9 == 0) goto L_0x0047
            boolean r10 = r4 instanceof p098d.p099a.p106g.C4592d
            if (r10 == 0) goto L_0x0041
            r10 = r4
            d.a.g.d r10 = (p098d.p099a.p106g.C4592d) r10
            int r10 = r10.mo21224b()
            if (r10 == r9) goto L_0x0047
        L_0x0041:
            d.a.g.d r10 = new d.a.g.d
            r10.<init>((android.content.Context) r4, (int) r9)
            r4 = r10
        L_0x0047:
            if (r11 == 0) goto L_0x004c
            androidx.appcompat.widget.C0252b0.m1152a(r4)
        L_0x004c:
            r5.hashCode()
            int r9 = r5.hashCode()
            r10 = -1
            r11 = 1
            switch(r9) {
                case -1946472170: goto L_0x00f6;
                case -1455429095: goto L_0x00ea;
                case -1346021293: goto L_0x00de;
                case -938935918: goto L_0x00d2;
                case -937446323: goto L_0x00c9;
                case -658531749: goto L_0x00be;
                case -339785223: goto L_0x00b3;
                case 776382189: goto L_0x00a8;
                case 799298502: goto L_0x009c;
                case 1125864064: goto L_0x008f;
                case 1413872058: goto L_0x0082;
                case 1601505219: goto L_0x0075;
                case 1666676343: goto L_0x0068;
                case 2001146706: goto L_0x005b;
                default: goto L_0x0058;
            }
        L_0x0058:
            r8 = -1
            goto L_0x0101
        L_0x005b:
            java.lang.String r8 = "Button"
            boolean r8 = r5.equals(r8)
            if (r8 != 0) goto L_0x0064
            goto L_0x0058
        L_0x0064:
            r8 = 13
            goto L_0x0101
        L_0x0068:
            java.lang.String r8 = "EditText"
            boolean r8 = r5.equals(r8)
            if (r8 != 0) goto L_0x0071
            goto L_0x0058
        L_0x0071:
            r8 = 12
            goto L_0x0101
        L_0x0075:
            java.lang.String r8 = "CheckBox"
            boolean r8 = r5.equals(r8)
            if (r8 != 0) goto L_0x007e
            goto L_0x0058
        L_0x007e:
            r8 = 11
            goto L_0x0101
        L_0x0082:
            java.lang.String r8 = "AutoCompleteTextView"
            boolean r8 = r5.equals(r8)
            if (r8 != 0) goto L_0x008b
            goto L_0x0058
        L_0x008b:
            r8 = 10
            goto L_0x0101
        L_0x008f:
            java.lang.String r8 = "ImageView"
            boolean r8 = r5.equals(r8)
            if (r8 != 0) goto L_0x0098
            goto L_0x0058
        L_0x0098:
            r8 = 9
            goto L_0x0101
        L_0x009c:
            java.lang.String r8 = "ToggleButton"
            boolean r8 = r5.equals(r8)
            if (r8 != 0) goto L_0x00a5
            goto L_0x0058
        L_0x00a5:
            r8 = 8
            goto L_0x0101
        L_0x00a8:
            java.lang.String r8 = "RadioButton"
            boolean r8 = r5.equals(r8)
            if (r8 != 0) goto L_0x00b1
            goto L_0x0058
        L_0x00b1:
            r8 = 7
            goto L_0x0101
        L_0x00b3:
            java.lang.String r8 = "Spinner"
            boolean r8 = r5.equals(r8)
            if (r8 != 0) goto L_0x00bc
            goto L_0x0058
        L_0x00bc:
            r8 = 6
            goto L_0x0101
        L_0x00be:
            java.lang.String r8 = "SeekBar"
            boolean r8 = r5.equals(r8)
            if (r8 != 0) goto L_0x00c7
            goto L_0x0058
        L_0x00c7:
            r8 = 5
            goto L_0x0101
        L_0x00c9:
            java.lang.String r9 = "ImageButton"
            boolean r9 = r5.equals(r9)
            if (r9 != 0) goto L_0x0101
            goto L_0x0058
        L_0x00d2:
            java.lang.String r8 = "TextView"
            boolean r8 = r5.equals(r8)
            if (r8 != 0) goto L_0x00dc
            goto L_0x0058
        L_0x00dc:
            r8 = 3
            goto L_0x0101
        L_0x00de:
            java.lang.String r8 = "MultiAutoCompleteTextView"
            boolean r8 = r5.equals(r8)
            if (r8 != 0) goto L_0x00e8
            goto L_0x0058
        L_0x00e8:
            r8 = 2
            goto L_0x0101
        L_0x00ea:
            java.lang.String r8 = "CheckedTextView"
            boolean r8 = r5.equals(r8)
            if (r8 != 0) goto L_0x00f4
            goto L_0x0058
        L_0x00f4:
            r8 = 1
            goto L_0x0101
        L_0x00f6:
            java.lang.String r8 = "RatingBar"
            boolean r8 = r5.equals(r8)
            if (r8 != 0) goto L_0x0100
            goto L_0x0058
        L_0x0100:
            r8 = 0
        L_0x0101:
            switch(r8) {
                case 0: goto L_0x0155;
                case 1: goto L_0x014f;
                case 2: goto L_0x0149;
                case 3: goto L_0x0141;
                case 4: goto L_0x013b;
                case 5: goto L_0x0135;
                case 6: goto L_0x012f;
                case 7: goto L_0x012a;
                case 8: goto L_0x0124;
                case 9: goto L_0x011e;
                case 10: goto L_0x0119;
                case 11: goto L_0x0114;
                case 12: goto L_0x010e;
                case 13: goto L_0x0109;
                default: goto L_0x0104;
            }
        L_0x0104:
            android.view.View r8 = r3.mo580f()
            goto L_0x015b
        L_0x0109:
            androidx.appcompat.widget.AppCompatButton r8 = r3.mo576b(r4, r7)
            goto L_0x0145
        L_0x010e:
            androidx.appcompat.widget.AppCompatEditText r8 = new androidx.appcompat.widget.AppCompatEditText
            r8.<init>(r4, r7)
            goto L_0x0145
        L_0x0114:
            androidx.appcompat.widget.AppCompatCheckBox r8 = r3.mo577c(r4, r7)
            goto L_0x0145
        L_0x0119:
            androidx.appcompat.widget.AppCompatAutoCompleteTextView r8 = r3.mo575a(r4, r7)
            goto L_0x0145
        L_0x011e:
            androidx.appcompat.widget.AppCompatImageView r8 = new androidx.appcompat.widget.AppCompatImageView
            r8.<init>(r4, r7)
            goto L_0x0145
        L_0x0124:
            androidx.appcompat.widget.AppCompatToggleButton r8 = new androidx.appcompat.widget.AppCompatToggleButton
            r8.<init>(r4, r7)
            goto L_0x0145
        L_0x012a:
            androidx.appcompat.widget.AppCompatRadioButton r8 = r3.mo578d(r4, r7)
            goto L_0x0145
        L_0x012f:
            androidx.appcompat.widget.AppCompatSpinner r8 = new androidx.appcompat.widget.AppCompatSpinner
            r8.<init>(r4, r7)
            goto L_0x0145
        L_0x0135:
            androidx.appcompat.widget.AppCompatSeekBar r8 = new androidx.appcompat.widget.AppCompatSeekBar
            r8.<init>(r4, r7)
            goto L_0x0145
        L_0x013b:
            androidx.appcompat.widget.AppCompatImageButton r8 = new androidx.appcompat.widget.AppCompatImageButton
            r8.<init>(r4, r7)
            goto L_0x0145
        L_0x0141:
            androidx.appcompat.widget.AppCompatTextView r8 = r3.mo579e(r4, r7)
        L_0x0145:
            r3.m551i(r8, r5)
            goto L_0x015b
        L_0x0149:
            androidx.appcompat.widget.AppCompatMultiAutoCompleteTextView r8 = new androidx.appcompat.widget.AppCompatMultiAutoCompleteTextView
            r8.<init>(r4, r7)
            goto L_0x0145
        L_0x014f:
            androidx.appcompat.widget.AppCompatCheckedTextView r8 = new androidx.appcompat.widget.AppCompatCheckedTextView
            r8.<init>(r4, r7)
            goto L_0x0145
        L_0x0155:
            androidx.appcompat.widget.AppCompatRatingBar r8 = new androidx.appcompat.widget.AppCompatRatingBar
            r8.<init>(r4, r7)
            goto L_0x0145
        L_0x015b:
            if (r8 != 0) goto L_0x01b6
            if (r6 == r4) goto L_0x01b6
            java.lang.String r6 = "view"
            boolean r6 = r5.equals(r6)
            r8 = 0
            if (r6 == 0) goto L_0x016e
            java.lang.String r5 = "class"
            java.lang.String r5 = r7.getAttributeValue(r8, r5)
        L_0x016e:
            java.lang.Object[] r6 = r3.f395e     // Catch:{ Exception -> 0x01b0, all -> 0x01a8 }
            r6[r0] = r4     // Catch:{ Exception -> 0x01b0, all -> 0x01a8 }
            r6[r11] = r7     // Catch:{ Exception -> 0x01b0, all -> 0x01a8 }
            r6 = 46
            int r6 = r5.indexOf(r6)     // Catch:{ Exception -> 0x01b0, all -> 0x01a8 }
            if (r10 != r6) goto L_0x019c
            r6 = 0
        L_0x017d:
            java.lang.String[] r9 = f393c     // Catch:{ Exception -> 0x01b0, all -> 0x01a8 }
            int r10 = r9.length     // Catch:{ Exception -> 0x01b0, all -> 0x01a8 }
            if (r6 >= r10) goto L_0x0195
            r9 = r9[r6]     // Catch:{ Exception -> 0x01b0, all -> 0x01a8 }
            android.view.View r9 = r3.m550h(r4, r5, r9)     // Catch:{ Exception -> 0x01b0, all -> 0x01a8 }
            if (r9 == 0) goto L_0x0192
            java.lang.Object[] r4 = r3.f395e
            r4[r0] = r8
            r4[r11] = r8
            r8 = r9
            goto L_0x01b6
        L_0x0192:
            int r6 = r6 + 1
            goto L_0x017d
        L_0x0195:
            java.lang.Object[] r4 = r3.f395e
            r4[r0] = r8
            r4[r11] = r8
            goto L_0x01b6
        L_0x019c:
            android.view.View r4 = r3.m550h(r4, r5, r8)     // Catch:{ Exception -> 0x01b0, all -> 0x01a8 }
            java.lang.Object[] r5 = r3.f395e
            r5[r0] = r8
            r5[r11] = r8
            r8 = r4
            goto L_0x01b6
        L_0x01a8:
            r4 = move-exception
            java.lang.Object[] r5 = r3.f395e
            r5[r0] = r8
            r5[r11] = r8
            throw r4
        L_0x01b0:
            java.lang.Object[] r4 = r3.f395e
            r4[r0] = r8
            r4[r11] = r8
        L_0x01b6:
            if (r8 == 0) goto L_0x01e0
            android.content.Context r4 = r8.getContext()
            boolean r5 = r4 instanceof android.content.ContextWrapper
            if (r5 == 0) goto L_0x01e0
            int r5 = p098d.p120g.p130j.C4761m.f17241f
            boolean r5 = r8.hasOnClickListeners()
            if (r5 != 0) goto L_0x01c9
            goto L_0x01e0
        L_0x01c9:
            int[] r5 = f392b
            android.content.res.TypedArray r4 = r4.obtainStyledAttributes(r7, r5)
            java.lang.String r5 = r4.getString(r0)
            if (r5 == 0) goto L_0x01dd
            androidx.appcompat.app.n$a r6 = new androidx.appcompat.app.n$a
            r6.<init>(r8, r5)
            r8.setOnClickListener(r6)
        L_0x01dd:
            r4.recycle()
        L_0x01e0:
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.C0139n.mo581g(android.view.View, java.lang.String, android.content.Context, android.util.AttributeSet, boolean, boolean, boolean, boolean):android.view.View");
    }
}
