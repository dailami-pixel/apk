package androidx.appcompat.app;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;
import java.util.Calendar;
import p098d.p120g.C4690a;

/* renamed from: androidx.appcompat.app.p */
class C0142p {

    /* renamed from: a */
    private static C0142p f404a;

    /* renamed from: b */
    private final Context f405b;

    /* renamed from: c */
    private final LocationManager f406c;

    /* renamed from: d */
    private final C0143a f407d = new C0143a();

    /* renamed from: androidx.appcompat.app.p$a */
    private static class C0143a {

        /* renamed from: a */
        boolean f408a;

        /* renamed from: b */
        long f409b;

        C0143a() {
        }
    }

    C0142p(Context context, LocationManager locationManager) {
        this.f405b = context;
        this.f406c = locationManager;
    }

    /* renamed from: a */
    static C0142p m561a(Context context) {
        if (f404a == null) {
            Context applicationContext = context.getApplicationContext();
            f404a = new C0142p(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
        }
        return f404a;
    }

    /* renamed from: b */
    private Location m562b(String str) {
        try {
            if (this.f406c.isProviderEnabled(str)) {
                return this.f406c.getLastKnownLocation(str);
            }
            return null;
        } catch (Exception e) {
            Log.d("TwilightManager", "Failed to get last known location", e);
            return null;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public boolean mo584c() {
        long j;
        C0143a aVar = this.f407d;
        boolean z = false;
        if (aVar.f409b > System.currentTimeMillis()) {
            return aVar.f408a;
        }
        Location location = null;
        Location b = C4690a.m17113d(this.f405b, "android.permission.ACCESS_COARSE_LOCATION") == 0 ? m562b("network") : null;
        if (C4690a.m17113d(this.f405b, "android.permission.ACCESS_FINE_LOCATION") == 0) {
            location = m562b("gps");
        }
        if (location == null || b == null ? location != null : location.getTime() > b.getTime()) {
            b = location;
        }
        if (b != null) {
            C0143a aVar2 = this.f407d;
            long currentTimeMillis = System.currentTimeMillis();
            C0141o b2 = C0141o.m559b();
            C0141o oVar = b2;
            oVar.mo583a(currentTimeMillis - 86400000, b.getLatitude(), b.getLongitude());
            oVar.mo583a(currentTimeMillis, b.getLatitude(), b.getLongitude());
            if (b2.f403d == 1) {
                z = true;
            }
            long j2 = b2.f402c;
            long j3 = b2.f401b;
            long j4 = j2;
            b2.mo583a(currentTimeMillis + 86400000, b.getLatitude(), b.getLongitude());
            long j5 = b2.f402c;
            if (j4 == -1 || j3 == -1) {
                j = 43200000 + currentTimeMillis;
            } else {
                j = (currentTimeMillis > j3 ? j5 + 0 : currentTimeMillis > j4 ? j3 + 0 : j4 + 0) + 60000;
            }
            aVar2.f408a = z;
            aVar2.f409b = j;
            return aVar.f408a;
        }
        Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
        int i = Calendar.getInstance().get(11);
        if (i < 6 || i >= 22) {
            return true;
        }
        return false;
    }
}
