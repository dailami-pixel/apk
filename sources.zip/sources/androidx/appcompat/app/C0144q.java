package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.view.menu.C0163g;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.C0283n;
import androidx.appcompat.widget.C0305y;
import androidx.appcompat.widget.Toolbar;
import com.vidio.android.p195tv.R;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import p098d.p099a.C4568b;
import p098d.p099a.p106g.C4588a;
import p098d.p099a.p106g.C4589b;
import p098d.p099a.p106g.C4596g;
import p098d.p099a.p106g.C4599h;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.C4774r;
import p098d.p120g.p130j.C4777s;
import p098d.p120g.p130j.C4778t;
import p098d.p120g.p130j.C4779u;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.appcompat.app.q */
public class C0144q extends ActionBar implements ActionBarOverlayLayout.C0193d {

    /* renamed from: a */
    private static final Interpolator f410a = new AccelerateInterpolator();

    /* renamed from: b */
    private static final Interpolator f411b = new DecelerateInterpolator();

    /* renamed from: A */
    final C4779u f412A = new C0147c();

    /* renamed from: c */
    Context f413c;

    /* renamed from: d */
    private Context f414d;

    /* renamed from: e */
    ActionBarOverlayLayout f415e;

    /* renamed from: f */
    ActionBarContainer f416f;

    /* renamed from: g */
    C0283n f417g;

    /* renamed from: h */
    ActionBarContextView f418h;

    /* renamed from: i */
    View f419i;

    /* renamed from: j */
    private boolean f420j;

    /* renamed from: k */
    C0148d f421k;

    /* renamed from: l */
    C4589b f422l;

    /* renamed from: m */
    C4589b.C4590a f423m;

    /* renamed from: n */
    private boolean f424n;

    /* renamed from: o */
    private ArrayList<ActionBar.C0105a> f425o = new ArrayList<>();

    /* renamed from: p */
    private boolean f426p;

    /* renamed from: q */
    private int f427q = 0;

    /* renamed from: r */
    boolean f428r = true;

    /* renamed from: s */
    boolean f429s;

    /* renamed from: t */
    private boolean f430t;

    /* renamed from: u */
    private boolean f431u = true;

    /* renamed from: v */
    C4599h f432v;

    /* renamed from: w */
    private boolean f433w;

    /* renamed from: x */
    boolean f434x;

    /* renamed from: y */
    final C4777s f435y = new C0145a();

    /* renamed from: z */
    final C4777s f436z = new C0146b();

    /* renamed from: androidx.appcompat.app.q$a */
    class C0145a extends C4778t {
        C0145a() {
        }

        /* renamed from: b */
        public void mo515b(View view) {
            View view2;
            C0144q qVar = C0144q.this;
            if (qVar.f428r && (view2 = qVar.f419i) != null) {
                view2.setTranslationY(0.0f);
                C0144q.this.f416f.setTranslationY(0.0f);
            }
            C0144q.this.f416f.setVisibility(8);
            C0144q.this.f416f.mo1012e(false);
            C0144q qVar2 = C0144q.this;
            qVar2.f432v = null;
            C4589b.C4590a aVar = qVar2.f423m;
            if (aVar != null) {
                aVar.mo511a(qVar2.f422l);
                qVar2.f422l = null;
                qVar2.f423m = null;
            }
            ActionBarOverlayLayout actionBarOverlayLayout = C0144q.this.f415e;
            if (actionBarOverlayLayout != null) {
                int i = C4761m.f17241f;
                actionBarOverlayLayout.requestApplyInsets();
            }
        }
    }

    /* renamed from: androidx.appcompat.app.q$b */
    class C0146b extends C4778t {
        C0146b() {
        }

        /* renamed from: b */
        public void mo515b(View view) {
            C0144q qVar = C0144q.this;
            qVar.f432v = null;
            qVar.f416f.requestLayout();
        }
    }

    /* renamed from: androidx.appcompat.app.q$c */
    class C0147c implements C4779u {
        C0147c() {
        }

        /* renamed from: a */
        public void mo591a(View view) {
            ((View) C0144q.this.f416f.getParent()).invalidate();
        }
    }

    /* renamed from: androidx.appcompat.app.q$d */
    public class C0148d extends C4589b implements C0163g.C0164a {

        /* renamed from: c */
        private final Context f440c;

        /* renamed from: d */
        private final C0163g f441d;

        /* renamed from: e */
        private C4589b.C4590a f442e;

        /* renamed from: f */
        private WeakReference<View> f443f;

        public C0148d(Context context, C4589b.C4590a aVar) {
            this.f440c = context;
            this.f442e = aVar;
            C0163g gVar = new C0163g(context);
            gVar.mo759H(1);
            this.f441d = gVar;
            gVar.mo758G(this);
        }

        /* renamed from: a */
        public boolean mo474a(C0163g gVar, MenuItem menuItem) {
            C4589b.C4590a aVar = this.f442e;
            if (aVar != null) {
                return aVar.mo514d(this, menuItem);
            }
            return false;
        }

        /* renamed from: b */
        public void mo475b(C0163g gVar) {
            if (this.f442e != null) {
                mo598k();
                C0144q.this.f418h.mo1042r();
            }
        }

        /* renamed from: c */
        public void mo592c() {
            C0144q qVar = C0144q.this;
            if (qVar.f421k == this) {
                if (!(!qVar.f429s)) {
                    qVar.f422l = this;
                    qVar.f423m = this.f442e;
                } else {
                    this.f442e.mo511a(this);
                }
                this.f442e = null;
                C0144q.this.mo585f(false);
                C0144q.this.f418h.mo1024e();
                C0144q.this.f417g.mo1638p().sendAccessibilityEvent(32);
                C0144q qVar2 = C0144q.this;
                qVar2.f415e.mo1091z(qVar2.f434x);
                C0144q.this.f421k = null;
            }
        }

        /* renamed from: d */
        public View mo593d() {
            WeakReference<View> weakReference = this.f443f;
            if (weakReference != null) {
                return (View) weakReference.get();
            }
            return null;
        }

        /* renamed from: e */
        public Menu mo594e() {
            return this.f441d;
        }

        /* renamed from: f */
        public MenuInflater mo595f() {
            return new C4596g(this.f440c);
        }

        /* renamed from: g */
        public CharSequence mo596g() {
            return C0144q.this.f418h.mo1025f();
        }

        /* renamed from: i */
        public CharSequence mo597i() {
            return C0144q.this.f418h.mo1026g();
        }

        /* renamed from: k */
        public void mo598k() {
            if (C0144q.this.f421k == this) {
                this.f441d.mo768R();
                try {
                    this.f442e.mo513c(this, this.f441d);
                } finally {
                    this.f441d.mo767Q();
                }
            }
        }

        /* renamed from: l */
        public boolean mo599l() {
            return C0144q.this.f418h.mo1030j();
        }

        /* renamed from: m */
        public void mo600m(View view) {
            C0144q.this.f418h.mo1033m(view);
            this.f443f = new WeakReference<>(view);
        }

        /* renamed from: n */
        public void mo601n(int i) {
            C0144q.this.f418h.mo1034n(C0144q.this.f413c.getResources().getString(i));
        }

        /* renamed from: o */
        public void mo602o(CharSequence charSequence) {
            C0144q.this.f418h.mo1034n(charSequence);
        }

        /* renamed from: q */
        public void mo603q(int i) {
            C0144q.this.f418h.mo1035o(C0144q.this.f413c.getResources().getString(i));
        }

        /* renamed from: r */
        public void mo604r(CharSequence charSequence) {
            C0144q.this.f418h.mo1035o(charSequence);
        }

        /* renamed from: s */
        public void mo605s(boolean z) {
            super.mo605s(z);
            C0144q.this.f418h.mo1040p(z);
        }

        /* renamed from: t */
        public boolean mo606t() {
            this.f441d.mo768R();
            try {
                return this.f442e.mo512b(this, this.f441d);
            } finally {
                this.f441d.mo767Q();
            }
        }
    }

    public C0144q(Activity activity, boolean z) {
        new ArrayList();
        View decorView = activity.getWindow().getDecorView();
        m564i(decorView);
        if (!z) {
            this.f419i = decorView.findViewById(16908290);
        }
    }

    public C0144q(Dialog dialog) {
        new ArrayList();
        m564i(dialog.getWindow().getDecorView());
    }

    /* renamed from: i */
    private void m564i(View view) {
        C0283n nVar;
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) view.findViewById(R.id.decor_content_parent);
        this.f415e = actionBarOverlayLayout;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.mo1089x(this);
        }
        View findViewById = view.findViewById(R.id.action_bar);
        if (findViewById instanceof C0283n) {
            nVar = (C0283n) findViewById;
        } else if (findViewById instanceof Toolbar) {
            nVar = ((Toolbar) findViewById).mo1498B();
        } else {
            StringBuilder P = C4924a.m17863P("Can't make a decor toolbar out of ");
            P.append(findViewById != null ? findViewById.getClass().getSimpleName() : "null");
            throw new IllegalStateException(P.toString());
        }
        this.f417g = nVar;
        this.f418h = (ActionBarContextView) view.findViewById(R.id.action_context_bar);
        ActionBarContainer actionBarContainer = (ActionBarContainer) view.findViewById(R.id.action_bar_container);
        this.f416f = actionBarContainer;
        C0283n nVar2 = this.f417g;
        if (nVar2 == null || this.f418h == null || actionBarContainer == null) {
            throw new IllegalStateException(C0144q.class.getSimpleName() + " can only be used with a compatible window decor layout");
        }
        this.f413c = nVar2.getContext();
        boolean z = (this.f417g.mo1640r() & 4) != 0;
        if (z) {
            this.f420j = true;
        }
        C4588a b = C4588a.m16481b(this.f413c);
        this.f417g.mo1639q(b.mo21215a() || z);
        m565l(b.mo21218e());
        TypedArray obtainStyledAttributes = this.f413c.obtainStyledAttributes((AttributeSet) null, C4568b.f16453a, R.attr.actionBarStyle, 0);
        if (obtainStyledAttributes.getBoolean(14, false)) {
            if (this.f415e.mo1086u()) {
                this.f434x = true;
                this.f415e.mo1091z(true);
            } else {
                throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
            }
        }
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(12, 0);
        if (dimensionPixelSize != 0) {
            ActionBarContainer actionBarContainer2 = this.f416f;
            int i = C4761m.f17241f;
            actionBarContainer2.setElevation((float) dimensionPixelSize);
        }
        obtainStyledAttributes.recycle();
    }

    /* renamed from: l */
    private void m565l(boolean z) {
        this.f426p = z;
        if (!z) {
            this.f417g.mo1633k((C0305y) null);
            this.f416f.mo1010d((C0305y) null);
        } else {
            this.f416f.mo1010d((C0305y) null);
            this.f417g.mo1633k((C0305y) null);
        }
        boolean z2 = true;
        boolean z3 = this.f417g.mo1636n() == 2;
        this.f417g.mo1644u(!this.f426p && z3);
        ActionBarOverlayLayout actionBarOverlayLayout = this.f415e;
        if (this.f426p || !z3) {
            z2 = false;
        }
        actionBarOverlayLayout.mo1090y(z2);
    }

    /* renamed from: n */
    private void m566n(boolean z) {
        View view;
        View view2;
        View view3;
        if (this.f430t || !this.f429s) {
            if (!this.f431u) {
                this.f431u = true;
                C4599h hVar = this.f432v;
                if (hVar != null) {
                    hVar.mo21257a();
                }
                this.f416f.setVisibility(0);
                if (this.f427q != 0 || (!this.f433w && !z)) {
                    this.f416f.setAlpha(1.0f);
                    this.f416f.setTranslationY(0.0f);
                    if (this.f428r && (view2 = this.f419i) != null) {
                        view2.setTranslationY(0.0f);
                    }
                    this.f436z.mo515b((View) null);
                } else {
                    this.f416f.setTranslationY(0.0f);
                    float f = (float) (-this.f416f.getHeight());
                    if (z) {
                        int[] iArr = {0, 0};
                        this.f416f.getLocationInWindow(iArr);
                        f -= (float) iArr[1];
                    }
                    this.f416f.setTranslationY(f);
                    C4599h hVar2 = new C4599h();
                    C4774r a = C4761m.m17292a(this.f416f);
                    a.mo21883k(0.0f);
                    a.mo21881i(this.f412A);
                    hVar2.mo21259c(a);
                    if (this.f428r && (view3 = this.f419i) != null) {
                        view3.setTranslationY(f);
                        C4774r a2 = C4761m.m17292a(this.f419i);
                        a2.mo21883k(0.0f);
                        hVar2.mo21259c(a2);
                    }
                    hVar2.mo21262f(f411b);
                    hVar2.mo21261e(250);
                    hVar2.mo21263g(this.f436z);
                    this.f432v = hVar2;
                    hVar2.mo21264h();
                }
                ActionBarOverlayLayout actionBarOverlayLayout = this.f415e;
                if (actionBarOverlayLayout != null) {
                    int i = C4761m.f17241f;
                    actionBarOverlayLayout.requestApplyInsets();
                }
            }
        } else if (this.f431u) {
            this.f431u = false;
            C4599h hVar3 = this.f432v;
            if (hVar3 != null) {
                hVar3.mo21257a();
            }
            if (this.f427q != 0 || (!this.f433w && !z)) {
                this.f435y.mo515b((View) null);
                return;
            }
            this.f416f.setAlpha(1.0f);
            this.f416f.mo1012e(true);
            C4599h hVar4 = new C4599h();
            float f2 = (float) (-this.f416f.getHeight());
            if (z) {
                int[] iArr2 = {0, 0};
                this.f416f.getLocationInWindow(iArr2);
                f2 -= (float) iArr2[1];
            }
            C4774r a3 = C4761m.m17292a(this.f416f);
            a3.mo21883k(f2);
            a3.mo21881i(this.f412A);
            hVar4.mo21259c(a3);
            if (this.f428r && (view = this.f419i) != null) {
                C4774r a4 = C4761m.m17292a(view);
                a4.mo21883k(f2);
                hVar4.mo21259c(a4);
            }
            hVar4.mo21262f(f410a);
            hVar4.mo21261e(250);
            hVar4.mo21263g(this.f435y);
            this.f432v = hVar4;
            hVar4.mo21264h();
        }
    }

    /* renamed from: a */
    public void mo412a(boolean z) {
        if (z != this.f424n) {
            this.f424n = z;
            int size = this.f425o.size();
            for (int i = 0; i < size; i++) {
                this.f425o.get(i).mo417a(z);
            }
        }
    }

    /* renamed from: b */
    public Context mo413b() {
        if (this.f414d == null) {
            TypedValue typedValue = new TypedValue();
            this.f413c.getTheme().resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
            int i = typedValue.resourceId;
            if (i != 0) {
                this.f414d = new ContextThemeWrapper(this.f413c, i);
            } else {
                this.f414d = this.f413c;
            }
        }
        return this.f414d;
    }

    /* renamed from: c */
    public void mo414c(Configuration configuration) {
        m565l(C4588a.m16481b(this.f413c).mo21218e());
    }

    /* renamed from: d */
    public void mo415d(boolean z) {
        if (!this.f420j) {
            int i = z ? 4 : 0;
            int r = this.f417g.mo1640r();
            this.f420j = true;
            this.f417g.mo1635m((i & 4) | (r & -5));
        }
    }

    /* renamed from: e */
    public void mo416e(boolean z) {
        C4599h hVar;
        this.f433w = z;
        if (!z && (hVar = this.f432v) != null) {
            hVar.mo21257a();
        }
    }

    /* renamed from: f */
    public void mo585f(boolean z) {
        C4774r rVar;
        C4774r rVar2;
        if (z) {
            if (!this.f430t) {
                this.f430t = true;
                ActionBarOverlayLayout actionBarOverlayLayout = this.f415e;
                if (actionBarOverlayLayout != null) {
                    actionBarOverlayLayout.mo1045A();
                }
                m566n(false);
            }
        } else if (this.f430t) {
            this.f430t = false;
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.f415e;
            if (actionBarOverlayLayout2 != null) {
                actionBarOverlayLayout2.mo1045A();
            }
            m566n(false);
        }
        ActionBarContainer actionBarContainer = this.f416f;
        int i = C4761m.f17241f;
        if (actionBarContainer.isLaidOut()) {
            if (z) {
                rVar = this.f417g.mo1637o(4, 100);
                rVar2 = this.f418h.mo1041q(0, 200);
            } else {
                rVar2 = this.f417g.mo1637o(0, 200);
                rVar = this.f418h.mo1041q(8, 100);
            }
            C4599h hVar = new C4599h();
            hVar.mo21260d(rVar, rVar2);
            hVar.mo21264h();
        } else if (z) {
            this.f417g.setVisibility(4);
            this.f418h.setVisibility(0);
        } else {
            this.f417g.setVisibility(0);
            this.f418h.setVisibility(8);
        }
    }

    /* renamed from: g */
    public void mo586g(boolean z) {
        this.f428r = z;
    }

    /* renamed from: h */
    public void mo587h() {
        if (!this.f429s) {
            this.f429s = true;
            m566n(true);
        }
    }

    /* renamed from: j */
    public void mo588j() {
        C4599h hVar = this.f432v;
        if (hVar != null) {
            hVar.mo21257a();
            this.f432v = null;
        }
    }

    /* renamed from: k */
    public void mo589k(int i) {
        this.f427q = i;
    }

    /* renamed from: m */
    public void mo590m() {
        if (this.f429s) {
            this.f429s = false;
            m566n(true);
        }
    }
}
