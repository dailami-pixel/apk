package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.appcompat.view.menu.C0163g;
import androidx.appcompat.view.menu.C0180n;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.C0266h0;
import androidx.appcompat.widget.C0289r;
import p098d.p099a.C4568b;

public class ActionMenuItemView extends AppCompatTextView implements C0180n.C0181a, View.OnClickListener, ActionMenuView.C0202a {

    /* renamed from: d */
    C0167i f445d;

    /* renamed from: e */
    private CharSequence f446e;

    /* renamed from: f */
    private Drawable f447f;

    /* renamed from: g */
    C0163g.C0165b f448g;

    /* renamed from: h */
    private C0289r f449h;

    /* renamed from: i */
    C0150b f450i;

    /* renamed from: j */
    private boolean f451j;

    /* renamed from: k */
    private int f452k;

    /* renamed from: l */
    private int f453l;

    /* renamed from: m */
    private int f454m;

    /* renamed from: androidx.appcompat.view.menu.ActionMenuItemView$a */
    private class C0149a extends C0289r {
        public C0149a() {
            super(ActionMenuItemView.this);
        }

        /* renamed from: b */
        public C0183p mo621b() {
            C0150b bVar = ActionMenuItemView.this.f450i;
            if (bVar != null) {
                return bVar.mo623a();
            }
            return null;
        }

        /* access modifiers changed from: protected */
        /* JADX WARNING: Code restructure failed: missing block: B:4:0x000f, code lost:
            r0 = mo621b();
         */
        /* renamed from: c */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo622c() {
            /*
                r3 = this;
                androidx.appcompat.view.menu.ActionMenuItemView r0 = androidx.appcompat.view.menu.ActionMenuItemView.this
                androidx.appcompat.view.menu.g$b r1 = r0.f448g
                r2 = 0
                if (r1 == 0) goto L_0x001c
                androidx.appcompat.view.menu.i r0 = r0.f445d
                boolean r0 = r1.mo624a(r0)
                if (r0 == 0) goto L_0x001c
                androidx.appcompat.view.menu.p r0 = r3.mo621b()
                if (r0 == 0) goto L_0x001c
                boolean r0 = r0.mo710a()
                if (r0 == 0) goto L_0x001c
                r2 = 1
            L_0x001c:
                return r2
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.ActionMenuItemView.C0149a.mo622c():boolean");
        }
    }

    /* renamed from: androidx.appcompat.view.menu.ActionMenuItemView$b */
    public static abstract class C0150b {
        /* renamed from: a */
        public abstract C0183p mo623a();
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Resources resources = context.getResources();
        this.f451j = m598i();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4568b.f16455c, i, 0);
        this.f452k = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        obtainStyledAttributes.recycle();
        this.f454m = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f453l = -1;
        setSaveEnabled(false);
    }

    /* renamed from: i */
    private boolean m598i() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        return i >= 480 || (i >= 640 && configuration.screenHeightDp >= 480) || configuration.orientation == 2;
    }

    /* renamed from: j */
    private void m599j() {
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.f446e);
        if (this.f447f != null && (!this.f445d.mo877w() || !this.f451j)) {
            z = false;
        }
        boolean z3 = z2 & z;
        CharSequence charSequence = null;
        setText(z3 ? this.f446e : null);
        CharSequence contentDescription = this.f445d.getContentDescription();
        if (TextUtils.isEmpty(contentDescription)) {
            contentDescription = z3 ? null : this.f445d.getTitle();
        }
        setContentDescription(contentDescription);
        CharSequence tooltipText = this.f445d.getTooltipText();
        if (TextUtils.isEmpty(tooltipText)) {
            if (!z3) {
                charSequence = this.f445d.getTitle();
            }
            C0266h0.m1246b(this, charSequence);
            return;
        }
        C0266h0.m1246b(this, tooltipText);
    }

    /* renamed from: a */
    public boolean mo607a() {
        return mo610d();
    }

    /* renamed from: b */
    public C0167i mo608b() {
        return this.f445d;
    }

    /* renamed from: c */
    public boolean mo609c() {
        return mo610d() && this.f445d.getIcon() == null;
    }

    /* renamed from: d */
    public boolean mo610d() {
        return !TextUtils.isEmpty(getText());
    }

    /* renamed from: e */
    public boolean mo611e() {
        return true;
    }

    /* renamed from: f */
    public void mo612f(C0167i iVar, int i) {
        this.f445d = iVar;
        Drawable icon = iVar.getIcon();
        this.f447f = icon;
        int i2 = 0;
        if (icon != null) {
            int intrinsicWidth = icon.getIntrinsicWidth();
            int intrinsicHeight = icon.getIntrinsicHeight();
            int i3 = this.f454m;
            if (intrinsicWidth > i3) {
                intrinsicHeight = (int) (((float) intrinsicHeight) * (((float) i3) / ((float) intrinsicWidth)));
                intrinsicWidth = i3;
            }
            if (intrinsicHeight > i3) {
                intrinsicWidth = (int) (((float) intrinsicWidth) * (((float) i3) / ((float) intrinsicHeight)));
            } else {
                i3 = intrinsicHeight;
            }
            icon.setBounds(0, 0, intrinsicWidth, i3);
        }
        setCompoundDrawables(icon, (Drawable) null, (Drawable) null, (Drawable) null);
        m599j();
        this.f446e = iVar.mo840h(this);
        m599j();
        setId(iVar.getItemId());
        if (!iVar.isVisible()) {
            i2 = 8;
        }
        setVisibility(i2);
        setEnabled(iVar.isEnabled());
        if (iVar.hasSubMenu() && this.f449h == null) {
            this.f449h = new C0149a();
        }
    }

    /* renamed from: g */
    public void mo613g(C0163g.C0165b bVar) {
        this.f448g = bVar;
    }

    /* renamed from: h */
    public void mo614h(C0150b bVar) {
        this.f450i = bVar;
    }

    public void onClick(View view) {
        C0163g.C0165b bVar = this.f448g;
        if (bVar != null) {
            bVar.mo624a(this.f445d);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f451j = m598i();
        m599j();
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3;
        boolean d = mo610d();
        if (d && (i3 = this.f453l) >= 0) {
            super.setPadding(i3, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i, i2);
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int measuredWidth = getMeasuredWidth();
        int min = mode == Integer.MIN_VALUE ? Math.min(size, this.f452k) : this.f452k;
        if (mode != 1073741824 && this.f452k > 0 && measuredWidth < min) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(min, 1073741824), i2);
        }
        if (!d && this.f447f != null) {
            super.setPadding((getMeasuredWidth() - this.f447f.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState((Parcelable) null);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        C0289r rVar;
        if (!this.f445d.hasSubMenu() || (rVar = this.f449h) == null || !rVar.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public void setPadding(int i, int i2, int i3, int i4) {
        this.f453l = i;
        super.setPadding(i, i2, i3, i4);
    }
}
