package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import androidx.core.content.C0474a;
import androidx.core.graphics.drawable.C0487a;
import p098d.p120g.p124e.p125a.C4707b;
import p098d.p120g.p130j.C4747b;

/* renamed from: androidx.appcompat.view.menu.a */
public class C0151a implements C4707b {

    /* renamed from: a */
    private CharSequence f475a;

    /* renamed from: b */
    private CharSequence f476b;

    /* renamed from: c */
    private Intent f477c;

    /* renamed from: d */
    private char f478d;

    /* renamed from: e */
    private int f479e = 4096;

    /* renamed from: f */
    private char f480f;

    /* renamed from: g */
    private int f481g = 4096;

    /* renamed from: h */
    private Drawable f482h;

    /* renamed from: i */
    private Context f483i;

    /* renamed from: j */
    private CharSequence f484j;

    /* renamed from: k */
    private CharSequence f485k;

    /* renamed from: l */
    private ColorStateList f486l = null;

    /* renamed from: m */
    private PorterDuff.Mode f487m = null;

    /* renamed from: n */
    private boolean f488n = false;

    /* renamed from: o */
    private boolean f489o = false;

    /* renamed from: p */
    private int f490p = 16;

    public C0151a(Context context, int i, int i2, int i3, CharSequence charSequence) {
        this.f483i = context;
        this.f475a = charSequence;
    }

    /* renamed from: c */
    private void m620c() {
        Drawable drawable = this.f482h;
        if (drawable == null) {
            return;
        }
        if (this.f488n || this.f489o) {
            Drawable h = C0487a.m2226h(drawable);
            this.f482h = h;
            Drawable mutate = h.mutate();
            this.f482h = mutate;
            if (this.f488n) {
                mutate.setTintList(this.f486l);
            }
            if (this.f489o) {
                this.f482h.setTintMode(this.f487m);
            }
        }
    }

    /* renamed from: a */
    public C4707b mo634a(C4747b bVar) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: b */
    public C4747b mo635b() {
        return null;
    }

    public boolean collapseActionView() {
        return false;
    }

    public boolean expandActionView() {
        return false;
    }

    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException();
    }

    public View getActionView() {
        return null;
    }

    public int getAlphabeticModifiers() {
        return this.f481g;
    }

    public char getAlphabeticShortcut() {
        return this.f480f;
    }

    public CharSequence getContentDescription() {
        return this.f484j;
    }

    public int getGroupId() {
        return 0;
    }

    public Drawable getIcon() {
        return this.f482h;
    }

    public ColorStateList getIconTintList() {
        return this.f486l;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.f487m;
    }

    public Intent getIntent() {
        return this.f477c;
    }

    public int getItemId() {
        return 16908332;
    }

    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    public int getNumericModifiers() {
        return this.f479e;
    }

    public char getNumericShortcut() {
        return this.f478d;
    }

    public int getOrder() {
        return 0;
    }

    public SubMenu getSubMenu() {
        return null;
    }

    public CharSequence getTitle() {
        return this.f475a;
    }

    public CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f476b;
        return charSequence != null ? charSequence : this.f475a;
    }

    public CharSequence getTooltipText() {
        return this.f485k;
    }

    public boolean hasSubMenu() {
        return false;
    }

    public boolean isActionViewExpanded() {
        return false;
    }

    public boolean isCheckable() {
        return (this.f490p & 1) != 0;
    }

    public boolean isChecked() {
        return (this.f490p & 2) != 0;
    }

    public boolean isEnabled() {
        return (this.f490p & 16) != 0;
    }

    public boolean isVisible() {
        return (this.f490p & 8) == 0;
    }

    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException();
    }

    public MenuItem setActionView(int i) {
        throw new UnsupportedOperationException();
    }

    public MenuItem setAlphabeticShortcut(char c) {
        this.f480f = Character.toLowerCase(c);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c, int i) {
        this.f480f = Character.toLowerCase(c);
        this.f481g = KeyEvent.normalizeMetaState(i);
        return this;
    }

    public MenuItem setCheckable(boolean z) {
        this.f490p = z | (this.f490p & true) ? 1 : 0;
        return this;
    }

    public MenuItem setChecked(boolean z) {
        this.f490p = (z ? 2 : 0) | (this.f490p & -3);
        return this;
    }

    public MenuItem setContentDescription(CharSequence charSequence) {
        this.f484j = charSequence;
        return this;
    }

    /* renamed from: setContentDescription  reason: collision with other method in class */
    public C4707b m41557setContentDescription(CharSequence charSequence) {
        this.f484j = charSequence;
        return this;
    }

    public MenuItem setEnabled(boolean z) {
        this.f490p = (z ? 16 : 0) | (this.f490p & -17);
        return this;
    }

    public MenuItem setIcon(int i) {
        Context context = this.f483i;
        int i2 = C0474a.f2214b;
        this.f482h = context.getDrawable(i);
        m620c();
        return this;
    }

    public MenuItem setIcon(Drawable drawable) {
        this.f482h = drawable;
        m620c();
        return this;
    }

    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f486l = colorStateList;
        this.f488n = true;
        m620c();
        return this;
    }

    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f487m = mode;
        this.f489o = true;
        m620c();
        return this;
    }

    public MenuItem setIntent(Intent intent) {
        this.f477c = intent;
        return this;
    }

    public MenuItem setNumericShortcut(char c) {
        this.f478d = c;
        return this;
    }

    public MenuItem setNumericShortcut(char c, int i) {
        this.f478d = c;
        this.f479e = KeyEvent.normalizeMetaState(i);
        return this;
    }

    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        throw new UnsupportedOperationException();
    }

    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        return this;
    }

    public MenuItem setShortcut(char c, char c2) {
        this.f478d = c;
        this.f480f = Character.toLowerCase(c2);
        return this;
    }

    public MenuItem setShortcut(char c, char c2, int i, int i2) {
        this.f478d = c;
        this.f479e = KeyEvent.normalizeMetaState(i);
        this.f480f = Character.toLowerCase(c2);
        this.f481g = KeyEvent.normalizeMetaState(i2);
        return this;
    }

    public void setShowAsAction(int i) {
    }

    public MenuItem setShowAsActionFlags(int i) {
        return this;
    }

    public MenuItem setTitle(int i) {
        this.f475a = this.f483i.getResources().getString(i);
        return this;
    }

    public MenuItem setTitle(CharSequence charSequence) {
        this.f475a = charSequence;
        return this;
    }

    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f476b = charSequence;
        return this;
    }

    public MenuItem setTooltipText(CharSequence charSequence) {
        this.f485k = charSequence;
        return this;
    }

    /* renamed from: setTooltipText  reason: collision with other method in class */
    public C4707b m41558setTooltipText(CharSequence charSequence) {
        this.f485k = charSequence;
        return this;
    }

    public MenuItem setVisible(boolean z) {
        int i = 8;
        int i2 = this.f490p & 8;
        if (z) {
            i = 0;
        }
        this.f490p = i2 | i;
        return this;
    }

    public MenuItem setActionView(View view) {
        throw new UnsupportedOperationException();
    }
}
