package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.C0178m;
import androidx.appcompat.view.menu.C0180n;
import java.util.ArrayList;

/* renamed from: androidx.appcompat.view.menu.b */
public abstract class C0152b implements C0178m {

    /* renamed from: a */
    protected Context f491a;

    /* renamed from: b */
    protected Context f492b;

    /* renamed from: c */
    protected C0163g f493c;

    /* renamed from: d */
    protected LayoutInflater f494d;

    /* renamed from: e */
    private C0178m.C0179a f495e;

    /* renamed from: f */
    private int f496f;

    /* renamed from: g */
    private int f497g;

    /* renamed from: h */
    protected C0180n f498h;

    /* renamed from: i */
    private int f499i;

    public C0152b(Context context, int i, int i2) {
        this.f491a = context;
        this.f494d = LayoutInflater.from(context);
        this.f496f = i;
        this.f497g = i2;
    }

    /* renamed from: a */
    public abstract void mo690a(C0167i iVar, C0180n.C0181a aVar);

    /* renamed from: b */
    public void mo691b(C0163g gVar, boolean z) {
        C0178m.C0179a aVar = this.f495e;
        if (aVar != null) {
            aVar.mo509b(gVar, z);
        }
    }

    /* renamed from: c */
    public void mo692c(boolean z) {
        ViewGroup viewGroup = (ViewGroup) this.f498h;
        if (viewGroup != null) {
            C0163g gVar = this.f493c;
            int i = 0;
            if (gVar != null) {
                gVar.mo795k();
                ArrayList<C0167i> r = this.f493c.mo804r();
                int size = r.size();
                int i2 = 0;
                for (int i3 = 0; i3 < size; i3++) {
                    C0167i iVar = r.get(i3);
                    if (mo704q(i2, iVar)) {
                        View childAt = viewGroup.getChildAt(i2);
                        C0167i b = childAt instanceof C0180n.C0181a ? ((C0180n.C0181a) childAt).mo608b() : null;
                        View n = mo701n(iVar, childAt, viewGroup);
                        if (iVar != b) {
                            n.setPressed(false);
                            n.jumpDrawablesToCurrentState();
                        }
                        if (n != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) n.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(n);
                            }
                            ((ViewGroup) this.f498h).addView(n, i2);
                        }
                        i2++;
                    }
                }
                i = i2;
            }
            while (i < viewGroup.getChildCount()) {
                if (!mo698j(viewGroup, i)) {
                    i++;
                }
            }
        }
    }

    /* renamed from: e */
    public boolean mo693e(C0163g gVar, C0167i iVar) {
        return false;
    }

    /* renamed from: f */
    public boolean mo694f(C0163g gVar, C0167i iVar) {
        return false;
    }

    /* renamed from: g */
    public void mo695g(C0178m.C0179a aVar) {
        this.f495e = aVar;
    }

    public int getId() {
        return this.f499i;
    }

    /* renamed from: h */
    public void mo697h(Context context, C0163g gVar) {
        this.f492b = context;
        LayoutInflater.from(context);
        this.f493c = gVar;
    }

    /* access modifiers changed from: protected */
    /* renamed from: j */
    public abstract boolean mo698j(ViewGroup viewGroup, int i);

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x000e, code lost:
        return false;
     */
    /* renamed from: k */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo699k(androidx.appcompat.view.menu.C0187r r2) {
        /*
            r1 = this;
            androidx.appcompat.view.menu.m$a r0 = r1.f495e
            if (r0 == 0) goto L_0x000e
            if (r2 == 0) goto L_0x0007
            goto L_0x0009
        L_0x0007:
            androidx.appcompat.view.menu.g r2 = r1.f493c
        L_0x0009:
            boolean r2 = r0.mo510c(r2)
            return r2
        L_0x000e:
            r2 = 0
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.C0152b.mo699k(androidx.appcompat.view.menu.r):boolean");
    }

    /* renamed from: m */
    public C0178m.C0179a mo700m() {
        return this.f495e;
    }

    /* renamed from: n */
    public View mo701n(C0167i iVar, View view, ViewGroup viewGroup) {
        C0180n.C0181a aVar = view instanceof C0180n.C0181a ? (C0180n.C0181a) view : (C0180n.C0181a) this.f494d.inflate(this.f497g, viewGroup, false);
        mo690a(iVar, aVar);
        return (View) aVar;
    }

    /* renamed from: o */
    public C0180n mo702o(ViewGroup viewGroup) {
        if (this.f498h == null) {
            C0180n nVar = (C0180n) this.f494d.inflate(this.f496f, viewGroup, false);
            this.f498h = nVar;
            nVar.mo625c(this.f493c);
            mo692c(true);
        }
        return this.f498h;
    }

    /* renamed from: p */
    public void mo703p(int i) {
        this.f499i = i;
    }

    /* renamed from: q */
    public abstract boolean mo704q(int i, C0167i iVar);
}
