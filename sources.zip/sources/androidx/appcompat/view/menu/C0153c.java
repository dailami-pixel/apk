package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import p098d.p112d.C4631j;
import p098d.p120g.p124e.p125a.C4707b;
import p098d.p120g.p124e.p125a.C4708c;

/* renamed from: androidx.appcompat.view.menu.c */
abstract class C0153c {

    /* renamed from: a */
    final Context f500a;

    /* renamed from: b */
    private C4631j<C4707b, MenuItem> f501b;

    /* renamed from: c */
    private C4631j<C4708c, SubMenu> f502c;

    C0153c(Context context) {
        this.f500a = context;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public final MenuItem mo705c(MenuItem menuItem) {
        if (!(menuItem instanceof C4707b)) {
            return menuItem;
        }
        C4707b bVar = (C4707b) menuItem;
        if (this.f501b == null) {
            this.f501b = new C4631j<>();
        }
        MenuItem orDefault = this.f501b.getOrDefault(menuItem, null);
        if (orDefault != null) {
            return orDefault;
        }
        C0169j jVar = new C0169j(this.f500a, bVar);
        this.f501b.put(bVar, jVar);
        return jVar;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public final SubMenu mo706d(SubMenu subMenu) {
        if (!(subMenu instanceof C4708c)) {
            return subMenu;
        }
        C4708c cVar = (C4708c) subMenu;
        if (this.f502c == null) {
            this.f502c = new C4631j<>();
        }
        SubMenu subMenu2 = this.f502c.get(cVar);
        if (subMenu2 != null) {
            return subMenu2;
        }
        C0188s sVar = new C0188s(this.f500a, cVar);
        this.f502c.put(cVar, sVar);
        return sVar;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public final void mo707e() {
        C4631j<C4707b, MenuItem> jVar = this.f501b;
        if (jVar != null) {
            jVar.clear();
        }
        C4631j<C4708c, SubMenu> jVar2 = this.f502c;
        if (jVar2 != null) {
            jVar2.clear();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public final void mo708f(int i) {
        if (this.f501b != null) {
            int i2 = 0;
            while (i2 < this.f501b.size()) {
                if (this.f501b.mo21457i(i2).getGroupId() == i) {
                    this.f501b.mo7295k(i2);
                    i2--;
                }
                i2++;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public final void mo709g(int i) {
        if (this.f501b != null) {
            for (int i2 = 0; i2 < this.f501b.size(); i2++) {
                if (this.f501b.mo21457i(i2).getItemId() == i) {
                    this.f501b.mo7295k(i2);
                    return;
                }
            }
        }
    }
}
