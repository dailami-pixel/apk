package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.os.Parcelable;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.C0178m;
import androidx.appcompat.widget.C0293t;
import androidx.appcompat.widget.C0294u;
import com.vidio.android.p195tv.R;
import java.util.ArrayList;
import java.util.List;
import p098d.p120g.p130j.C4761m;

/* renamed from: androidx.appcompat.view.menu.d */
final class C0154d extends C0175k implements C0178m, View.OnKeyListener, PopupWindow.OnDismissListener {

    /* renamed from: A */
    boolean f503A;

    /* renamed from: b */
    private final Context f504b;

    /* renamed from: c */
    private final int f505c;

    /* renamed from: d */
    private final int f506d;

    /* renamed from: e */
    private final int f507e;

    /* renamed from: f */
    private final boolean f508f;

    /* renamed from: g */
    final Handler f509g;

    /* renamed from: h */
    private final List<C0163g> f510h = new ArrayList();

    /* renamed from: i */
    final List<C0159d> f511i = new ArrayList();

    /* renamed from: j */
    final ViewTreeObserver.OnGlobalLayoutListener f512j = new C0155a();

    /* renamed from: k */
    private final View.OnAttachStateChangeListener f513k = new C0156b();

    /* renamed from: l */
    private final C0293t f514l = new C0157c();

    /* renamed from: m */
    private int f515m;

    /* renamed from: n */
    private int f516n;

    /* renamed from: o */
    private View f517o;

    /* renamed from: p */
    View f518p;

    /* renamed from: q */
    private int f519q;

    /* renamed from: r */
    private boolean f520r;

    /* renamed from: s */
    private boolean f521s;

    /* renamed from: t */
    private int f522t;

    /* renamed from: u */
    private int f523u;

    /* renamed from: v */
    private boolean f524v;

    /* renamed from: w */
    private boolean f525w;

    /* renamed from: x */
    private C0178m.C0179a f526x;

    /* renamed from: y */
    ViewTreeObserver f527y;

    /* renamed from: z */
    private PopupWindow.OnDismissListener f528z;

    /* renamed from: androidx.appcompat.view.menu.d$a */
    class C0155a implements ViewTreeObserver.OnGlobalLayoutListener {
        C0155a() {
        }

        public void onGlobalLayout() {
            if (C0154d.this.mo710a() && C0154d.this.f511i.size() > 0 && !C0154d.this.f511i.get(0).f536a.mo1408v()) {
                View view = C0154d.this.f518p;
                if (view == null || !view.isShown()) {
                    C0154d.this.dismiss();
                    return;
                }
                for (C0159d dVar : C0154d.this.f511i) {
                    dVar.f536a.show();
                }
            }
        }
    }

    /* renamed from: androidx.appcompat.view.menu.d$b */
    class C0156b implements View.OnAttachStateChangeListener {
        C0156b() {
        }

        public void onViewAttachedToWindow(View view) {
        }

        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = C0154d.this.f527y;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    C0154d.this.f527y = view.getViewTreeObserver();
                }
                C0154d dVar = C0154d.this;
                dVar.f527y.removeGlobalOnLayoutListener(dVar.f512j);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    /* renamed from: androidx.appcompat.view.menu.d$c */
    class C0157c implements C0293t {

        /* renamed from: androidx.appcompat.view.menu.d$c$a */
        class C0158a implements Runnable {

            /* renamed from: a */
            final /* synthetic */ C0159d f532a;

            /* renamed from: b */
            final /* synthetic */ MenuItem f533b;

            /* renamed from: c */
            final /* synthetic */ C0163g f534c;

            C0158a(C0159d dVar, MenuItem menuItem, C0163g gVar) {
                this.f532a = dVar;
                this.f533b = menuItem;
                this.f534c = gVar;
            }

            public void run() {
                C0159d dVar = this.f532a;
                if (dVar != null) {
                    C0154d.this.f503A = true;
                    dVar.f537b.mo785e(false);
                    C0154d.this.f503A = false;
                }
                if (this.f533b.isEnabled() && this.f533b.hasSubMenu()) {
                    this.f534c.mo819y(this.f533b, 4);
                }
            }
        }

        C0157c() {
        }

        /* renamed from: c */
        public void mo730c(C0163g gVar, MenuItem menuItem) {
            C0159d dVar = null;
            C0154d.this.f509g.removeCallbacksAndMessages((Object) null);
            int size = C0154d.this.f511i.size();
            int i = 0;
            while (true) {
                if (i >= size) {
                    i = -1;
                    break;
                } else if (gVar == C0154d.this.f511i.get(i).f537b) {
                    break;
                } else {
                    i++;
                }
            }
            if (i != -1) {
                int i2 = i + 1;
                if (i2 < C0154d.this.f511i.size()) {
                    dVar = C0154d.this.f511i.get(i2);
                }
                C0154d.this.f509g.postAtTime(new C0158a(dVar, menuItem, gVar), gVar, SystemClock.uptimeMillis() + 200);
            }
        }

        /* renamed from: f */
        public void mo731f(C0163g gVar, MenuItem menuItem) {
            C0154d.this.f509g.removeCallbacksAndMessages(gVar);
        }
    }

    /* renamed from: androidx.appcompat.view.menu.d$d */
    private static class C0159d {

        /* renamed from: a */
        public final C0294u f536a;

        /* renamed from: b */
        public final C0163g f537b;

        /* renamed from: c */
        public final int f538c;

        public C0159d(C0294u uVar, C0163g gVar, int i) {
            this.f536a = uVar;
            this.f537b = gVar;
            this.f538c = i;
        }

        /* renamed from: a */
        public ListView mo733a() {
            return this.f536a.mo714j();
        }
    }

    public C0154d(Context context, View view, int i, int i2, boolean z) {
        int i3 = 0;
        this.f515m = 0;
        this.f516n = 0;
        this.f504b = context;
        this.f517o = view;
        this.f506d = i;
        this.f507e = i2;
        this.f508f = z;
        this.f524v = false;
        int i4 = C4761m.f17241f;
        this.f519q = view.getLayoutDirection() != 1 ? 1 : i3;
        Resources resources = context.getResources();
        this.f505c = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
        this.f509g = new Handler();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:42:0x0120, code lost:
        if (((r7.getWidth() + r8[0]) + r2) > r10.right) goto L_0x012a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x0126, code lost:
        if ((r8[0] - r2) < 0) goto L_0x0128;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x012a, code lost:
        r7 = 0;
     */
    /* renamed from: y */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m642y(androidx.appcompat.view.menu.C0163g r15) {
        /*
            r14 = this;
            android.content.Context r0 = r14.f504b
            android.view.LayoutInflater r0 = android.view.LayoutInflater.from(r0)
            androidx.appcompat.view.menu.f r1 = new androidx.appcompat.view.menu.f
            boolean r2 = r14.f508f
            r3 = 2131558411(0x7f0d000b, float:1.8742137E38)
            r1.<init>(r15, r0, r2, r3)
            boolean r2 = r14.mo710a()
            r3 = 1
            if (r2 != 0) goto L_0x001f
            boolean r2 = r14.f524v
            if (r2 == 0) goto L_0x001f
            r1.mo747d(r3)
            goto L_0x002c
        L_0x001f:
            boolean r2 = r14.mo710a()
            if (r2 == 0) goto L_0x002c
            boolean r2 = androidx.appcompat.view.menu.C0175k.m766x(r15)
            r1.mo747d(r2)
        L_0x002c:
            android.content.Context r2 = r14.f504b
            int r4 = r14.f505c
            r5 = 0
            int r2 = androidx.appcompat.view.menu.C0175k.m765o(r1, r5, r2, r4)
            androidx.appcompat.widget.u r4 = new androidx.appcompat.widget.u
            android.content.Context r6 = r14.f504b
            int r7 = r14.f506d
            int r8 = r14.f507e
            r4.<init>(r6, r5, r7, r8)
            androidx.appcompat.widget.t r6 = r14.f514l
            r4.mo1729J(r6)
            r4.mo1393E(r14)
            r4.mo1392D(r14)
            android.view.View r6 = r14.f517o
            r4.mo1409w(r6)
            int r6 = r14.f516n
            r4.mo1412z(r6)
            r4.mo1391C(r3)
            r6 = 2
            r4.mo1390B(r6)
            r4.mo1304o(r1)
            r4.mo1411y(r2)
            int r1 = r14.f516n
            r4.mo1412z(r1)
            java.util.List<androidx.appcompat.view.menu.d$d> r1 = r14.f511i
            int r1 = r1.size()
            r6 = 0
            if (r1 <= 0) goto L_0x00e6
            java.util.List<androidx.appcompat.view.menu.d$d> r1 = r14.f511i
            int r7 = r1.size()
            int r7 = r7 - r3
            java.lang.Object r1 = r1.get(r7)
            androidx.appcompat.view.menu.d$d r1 = (androidx.appcompat.view.menu.C0154d.C0159d) r1
            androidx.appcompat.view.menu.g r3 = r1.f537b
            int r7 = r3.size()
            r8 = 0
        L_0x0084:
            if (r8 >= r7) goto L_0x009a
            android.view.MenuItem r9 = r3.getItem(r8)
            boolean r10 = r9.hasSubMenu()
            if (r10 == 0) goto L_0x0097
            android.view.SubMenu r10 = r9.getSubMenu()
            if (r15 != r10) goto L_0x0097
            goto L_0x009b
        L_0x0097:
            int r8 = r8 + 1
            goto L_0x0084
        L_0x009a:
            r9 = r5
        L_0x009b:
            if (r9 != 0) goto L_0x009e
            goto L_0x00e4
        L_0x009e:
            android.widget.ListView r3 = r1.mo733a()
            android.widget.ListAdapter r7 = r3.getAdapter()
            boolean r8 = r7 instanceof android.widget.HeaderViewListAdapter
            if (r8 == 0) goto L_0x00b7
            android.widget.HeaderViewListAdapter r7 = (android.widget.HeaderViewListAdapter) r7
            int r8 = r7.getHeadersCount()
            android.widget.ListAdapter r7 = r7.getWrappedAdapter()
            androidx.appcompat.view.menu.f r7 = (androidx.appcompat.view.menu.C0162f) r7
            goto L_0x00ba
        L_0x00b7:
            androidx.appcompat.view.menu.f r7 = (androidx.appcompat.view.menu.C0162f) r7
            r8 = 0
        L_0x00ba:
            int r10 = r7.getCount()
            r11 = 0
        L_0x00bf:
            r12 = -1
            if (r11 >= r10) goto L_0x00cc
            androidx.appcompat.view.menu.i r13 = r7.getItem(r11)
            if (r9 != r13) goto L_0x00c9
            goto L_0x00cd
        L_0x00c9:
            int r11 = r11 + 1
            goto L_0x00bf
        L_0x00cc:
            r11 = -1
        L_0x00cd:
            if (r11 != r12) goto L_0x00d0
            goto L_0x00e4
        L_0x00d0:
            int r11 = r11 + r8
            int r7 = r3.getFirstVisiblePosition()
            int r11 = r11 - r7
            if (r11 < 0) goto L_0x00e4
            int r7 = r3.getChildCount()
            if (r11 < r7) goto L_0x00df
            goto L_0x00e4
        L_0x00df:
            android.view.View r3 = r3.getChildAt(r11)
            goto L_0x00e8
        L_0x00e4:
            r3 = r5
            goto L_0x00e8
        L_0x00e6:
            r1 = r5
            r3 = r1
        L_0x00e8:
            if (r3 == 0) goto L_0x0195
            r4.mo1730K(r6)
            r4.mo1727H(r5)
            java.util.List<androidx.appcompat.view.menu.d$d> r7 = r14.f511i
            int r8 = r7.size()
            r9 = 1
            int r8 = r8 - r9
            java.lang.Object r7 = r7.get(r8)
            androidx.appcompat.view.menu.d$d r7 = (androidx.appcompat.view.menu.C0154d.C0159d) r7
            android.widget.ListView r7 = r7.mo733a()
            r8 = 2
            int[] r8 = new int[r8]
            r7.getLocationOnScreen(r8)
            android.graphics.Rect r10 = new android.graphics.Rect
            r10.<init>()
            android.view.View r11 = r14.f518p
            r11.getWindowVisibleDisplayFrame(r10)
            int r11 = r14.f519q
            if (r11 != r9) goto L_0x0123
            r8 = r8[r6]
            int r7 = r7.getWidth()
            int r7 = r7 + r8
            int r7 = r7 + r2
            int r8 = r10.right
            if (r7 <= r8) goto L_0x0128
            goto L_0x012a
        L_0x0123:
            r7 = r8[r6]
            int r7 = r7 - r2
            if (r7 >= 0) goto L_0x012a
        L_0x0128:
            r7 = 1
            goto L_0x012b
        L_0x012a:
            r7 = 0
        L_0x012b:
            r8 = 1
            if (r7 != r8) goto L_0x0130
            r8 = 1
            goto L_0x0131
        L_0x0130:
            r8 = 0
        L_0x0131:
            r14.f519q = r7
            int r7 = android.os.Build.VERSION.SDK_INT
            r9 = 26
            r10 = 5
            if (r7 < r9) goto L_0x0140
            r4.mo1409w(r3)
            r7 = 0
            r9 = 0
            goto L_0x0173
        L_0x0140:
            r7 = 2
            int[] r9 = new int[r7]
            android.view.View r11 = r14.f517o
            r11.getLocationOnScreen(r9)
            int[] r7 = new int[r7]
            r3.getLocationOnScreen(r7)
            int r11 = r14.f516n
            r11 = r11 & 7
            if (r11 != r10) goto L_0x0167
            r11 = r9[r6]
            android.view.View r12 = r14.f517o
            int r12 = r12.getWidth()
            int r12 = r12 + r11
            r9[r6] = r12
            r11 = r7[r6]
            int r12 = r3.getWidth()
            int r12 = r12 + r11
            r7[r6] = r12
        L_0x0167:
            r11 = r7[r6]
            r12 = r9[r6]
            int r11 = r11 - r12
            r12 = 1
            r7 = r7[r12]
            r9 = r9[r12]
            int r7 = r7 - r9
            r9 = r11
        L_0x0173:
            int r11 = r14.f516n
            r11 = r11 & r10
            if (r11 != r10) goto L_0x0181
            if (r8 == 0) goto L_0x017c
            int r9 = r9 + r2
            goto L_0x018a
        L_0x017c:
            int r2 = r3.getWidth()
            goto L_0x0189
        L_0x0181:
            if (r8 == 0) goto L_0x0189
            int r2 = r3.getWidth()
            int r9 = r9 + r2
            goto L_0x018a
        L_0x0189:
            int r9 = r9 - r2
        L_0x018a:
            r4.mo1397d(r9)
            r2 = 1
            r4.mo1394F(r2)
            r4.mo1400k(r7)
            goto L_0x01ae
        L_0x0195:
            boolean r2 = r14.f520r
            if (r2 == 0) goto L_0x019e
            int r2 = r14.f522t
            r4.mo1397d(r2)
        L_0x019e:
            boolean r2 = r14.f521s
            if (r2 == 0) goto L_0x01a7
            int r2 = r14.f523u
            r4.mo1400k(r2)
        L_0x01a7:
            android.graphics.Rect r2 = r14.mo947n()
            r4.mo1389A(r2)
        L_0x01ae:
            androidx.appcompat.view.menu.d$d r2 = new androidx.appcompat.view.menu.d$d
            int r3 = r14.f519q
            r2.<init>(r4, r15, r3)
            java.util.List<androidx.appcompat.view.menu.d$d> r3 = r14.f511i
            r3.add(r2)
            r4.show()
            android.widget.ListView r2 = r4.mo714j()
            r2.setOnKeyListener(r14)
            if (r1 != 0) goto L_0x01ee
            boolean r1 = r14.f525w
            if (r1 == 0) goto L_0x01ee
            java.lang.CharSequence r1 = r15.f566n
            if (r1 == 0) goto L_0x01ee
            r1 = 2131558418(0x7f0d0012, float:1.8742151E38)
            android.view.View r0 = r0.inflate(r1, r2, r6)
            android.widget.FrameLayout r0 = (android.widget.FrameLayout) r0
            r1 = 16908310(0x1020016, float:2.387729E-38)
            android.view.View r1 = r0.findViewById(r1)
            android.widget.TextView r1 = (android.widget.TextView) r1
            r0.setEnabled(r6)
            java.lang.CharSequence r15 = r15.f566n
            r1.setText(r15)
            r2.addHeaderView(r0, r5, r6)
            r4.show()
        L_0x01ee:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.C0154d.m642y(androidx.appcompat.view.menu.g):void");
    }

    /* renamed from: a */
    public boolean mo710a() {
        return this.f511i.size() > 0 && this.f511i.get(0).f536a.mo710a();
    }

    /* renamed from: b */
    public void mo691b(C0163g gVar, boolean z) {
        int i;
        int size = this.f511i.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                i2 = -1;
                break;
            } else if (gVar == this.f511i.get(i2).f537b) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 >= 0) {
            int i3 = i2 + 1;
            if (i3 < this.f511i.size()) {
                this.f511i.get(i3).f537b.mo785e(false);
            }
            C0159d remove = this.f511i.remove(i2);
            remove.f537b.mo753B(this);
            if (this.f503A) {
                remove.f536a.mo1728I((Object) null);
                remove.f536a.mo1410x(0);
            }
            remove.f536a.dismiss();
            int size2 = this.f511i.size();
            if (size2 > 0) {
                i = this.f511i.get(size2 - 1).f538c;
            } else {
                View view = this.f517o;
                int i4 = C4761m.f17241f;
                i = view.getLayoutDirection() == 1 ? 0 : 1;
            }
            this.f519q = i;
            if (size2 == 0) {
                dismiss();
                C0178m.C0179a aVar = this.f526x;
                if (aVar != null) {
                    aVar.mo509b(gVar, true);
                }
                ViewTreeObserver viewTreeObserver = this.f527y;
                if (viewTreeObserver != null) {
                    if (viewTreeObserver.isAlive()) {
                        this.f527y.removeGlobalOnLayoutListener(this.f512j);
                    }
                    this.f527y = null;
                }
                this.f518p.removeOnAttachStateChangeListener(this.f513k);
                this.f528z.onDismiss();
            } else if (z) {
                this.f511i.get(0).f537b.mo785e(false);
            }
        }
    }

    /* renamed from: c */
    public void mo692c(boolean z) {
        for (C0159d a : this.f511i) {
            ListAdapter adapter = a.mo733a().getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                adapter = ((HeaderViewListAdapter) adapter).getWrappedAdapter();
            }
            ((C0162f) adapter).notifyDataSetChanged();
        }
    }

    /* renamed from: d */
    public boolean mo711d() {
        return false;
    }

    public void dismiss() {
        int size = this.f511i.size();
        if (size > 0) {
            C0159d[] dVarArr = (C0159d[]) this.f511i.toArray(new C0159d[size]);
            for (int i = size - 1; i >= 0; i--) {
                C0159d dVar = dVarArr[i];
                if (dVar.f536a.mo710a()) {
                    dVar.f536a.dismiss();
                }
            }
        }
    }

    /* renamed from: g */
    public void mo695g(C0178m.C0179a aVar) {
        this.f526x = aVar;
    }

    /* renamed from: i */
    public void mo713i(Parcelable parcelable) {
    }

    /* renamed from: j */
    public ListView mo714j() {
        if (this.f511i.isEmpty()) {
            return null;
        }
        List<C0159d> list = this.f511i;
        return list.get(list.size() - 1).mo733a();
    }

    /* renamed from: k */
    public boolean mo699k(C0187r rVar) {
        for (C0159d next : this.f511i) {
            if (rVar == next.f537b) {
                next.mo733a().requestFocus();
                return true;
            }
        }
        if (!rVar.hasVisibleItems()) {
            return false;
        }
        rVar.mo780c(this, this.f504b);
        if (mo710a()) {
            m642y(rVar);
        } else {
            this.f510h.add(rVar);
        }
        C0178m.C0179a aVar = this.f526x;
        if (aVar != null) {
            aVar.mo510c(rVar);
        }
        return true;
    }

    /* renamed from: l */
    public Parcelable mo715l() {
        return null;
    }

    /* renamed from: m */
    public void mo716m(C0163g gVar) {
        gVar.mo780c(this, this.f504b);
        if (mo710a()) {
            m642y(gVar);
        } else {
            this.f510h.add(gVar);
        }
    }

    public void onDismiss() {
        C0159d dVar;
        int size = this.f511i.size();
        int i = 0;
        while (true) {
            if (i >= size) {
                dVar = null;
                break;
            }
            dVar = this.f511i.get(i);
            if (!dVar.f536a.mo710a()) {
                break;
            }
            i++;
        }
        if (dVar != null) {
            dVar.f537b.mo785e(false);
        }
    }

    public boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    /* renamed from: p */
    public void mo719p(View view) {
        if (this.f517o != view) {
            this.f517o = view;
            int i = this.f515m;
            int i2 = C4761m.f17241f;
            this.f516n = Gravity.getAbsoluteGravity(i, view.getLayoutDirection());
        }
    }

    /* renamed from: r */
    public void mo720r(boolean z) {
        this.f524v = z;
    }

    /* renamed from: s */
    public void mo721s(int i) {
        if (this.f515m != i) {
            this.f515m = i;
            View view = this.f517o;
            int i2 = C4761m.f17241f;
            this.f516n = Gravity.getAbsoluteGravity(i, view.getLayoutDirection());
        }
    }

    public void show() {
        if (!mo710a()) {
            for (C0163g y : this.f510h) {
                m642y(y);
            }
            this.f510h.clear();
            View view = this.f517o;
            this.f518p = view;
            if (view != null) {
                boolean z = this.f527y == null;
                ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
                this.f527y = viewTreeObserver;
                if (z) {
                    viewTreeObserver.addOnGlobalLayoutListener(this.f512j);
                }
                this.f518p.addOnAttachStateChangeListener(this.f513k);
            }
        }
    }

    /* renamed from: t */
    public void mo723t(int i) {
        this.f520r = true;
        this.f522t = i;
    }

    /* renamed from: u */
    public void mo724u(PopupWindow.OnDismissListener onDismissListener) {
        this.f528z = onDismissListener;
    }

    /* renamed from: v */
    public void mo725v(boolean z) {
        this.f525w = z;
    }

    /* renamed from: w */
    public void mo726w(int i) {
        this.f521s = true;
        this.f523u = i;
    }
}
