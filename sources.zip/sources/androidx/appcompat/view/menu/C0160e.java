package androidx.appcompat.view.menu;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.C0178m;
import androidx.appcompat.view.menu.C0180n;
import com.vidio.android.p195tv.R;
import java.util.ArrayList;
import java.util.Objects;

/* renamed from: androidx.appcompat.view.menu.e */
public class C0160e implements C0178m, AdapterView.OnItemClickListener {

    /* renamed from: a */
    Context f539a;

    /* renamed from: b */
    LayoutInflater f540b;

    /* renamed from: c */
    C0163g f541c;

    /* renamed from: d */
    ExpandedMenuView f542d;

    /* renamed from: e */
    private C0178m.C0179a f543e;

    /* renamed from: f */
    C0161a f544f;

    /* renamed from: androidx.appcompat.view.menu.e$a */
    private class C0161a extends BaseAdapter {

        /* renamed from: a */
        private int f545a = -1;

        public C0161a() {
            mo737a();
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo737a() {
            C0167i o = C0160e.this.f541c.mo799o();
            if (o != null) {
                ArrayList<C0167i> p = C0160e.this.f541c.mo800p();
                int size = p.size();
                for (int i = 0; i < size; i++) {
                    if (p.get(i) == o) {
                        this.f545a = i;
                        return;
                    }
                }
            }
            this.f545a = -1;
        }

        /* renamed from: b */
        public C0167i getItem(int i) {
            ArrayList<C0167i> p = C0160e.this.f541c.mo800p();
            Objects.requireNonNull(C0160e.this);
            int i2 = i + 0;
            int i3 = this.f545a;
            if (i3 >= 0 && i2 >= i3) {
                i2++;
            }
            return p.get(i2);
        }

        public int getCount() {
            int size = C0160e.this.f541c.mo800p().size();
            Objects.requireNonNull(C0160e.this);
            int i = size + 0;
            return this.f545a < 0 ? i : i - 1;
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = C0160e.this.f540b.inflate(R.layout.abc_list_menu_item_layout, viewGroup, false);
            }
            ((C0180n.C0181a) view).mo612f(getItem(i), 0);
            return view;
        }

        public void notifyDataSetChanged() {
            mo737a();
            super.notifyDataSetChanged();
        }
    }

    public C0160e(Context context, int i) {
        this.f539a = context;
        this.f540b = LayoutInflater.from(context);
    }

    /* renamed from: a */
    public ListAdapter mo734a() {
        if (this.f544f == null) {
            this.f544f = new C0161a();
        }
        return this.f544f;
    }

    /* renamed from: b */
    public void mo691b(C0163g gVar, boolean z) {
        C0178m.C0179a aVar = this.f543e;
        if (aVar != null) {
            aVar.mo509b(gVar, z);
        }
    }

    /* renamed from: c */
    public void mo692c(boolean z) {
        C0161a aVar = this.f544f;
        if (aVar != null) {
            aVar.notifyDataSetChanged();
        }
    }

    /* renamed from: d */
    public boolean mo711d() {
        return false;
    }

    /* renamed from: e */
    public boolean mo693e(C0163g gVar, C0167i iVar) {
        return false;
    }

    /* renamed from: f */
    public boolean mo694f(C0163g gVar, C0167i iVar) {
        return false;
    }

    /* renamed from: g */
    public void mo695g(C0178m.C0179a aVar) {
        this.f543e = aVar;
    }

    public int getId() {
        return 0;
    }

    /* renamed from: h */
    public void mo697h(Context context, C0163g gVar) {
        if (this.f539a != null) {
            this.f539a = context;
            if (this.f540b == null) {
                this.f540b = LayoutInflater.from(context);
            }
        }
        this.f541c = gVar;
        C0161a aVar = this.f544f;
        if (aVar != null) {
            aVar.notifyDataSetChanged();
        }
    }

    /* renamed from: i */
    public void mo713i(Parcelable parcelable) {
        SparseArray sparseParcelableArray = ((Bundle) parcelable).getSparseParcelableArray("android:menu:list");
        if (sparseParcelableArray != null) {
            this.f542d.restoreHierarchyState(sparseParcelableArray);
        }
    }

    /* renamed from: j */
    public C0180n mo735j(ViewGroup viewGroup) {
        if (this.f542d == null) {
            this.f542d = (ExpandedMenuView) this.f540b.inflate(R.layout.abc_expanded_menu_layout, viewGroup, false);
            if (this.f544f == null) {
                this.f544f = new C0161a();
            }
            this.f542d.setAdapter(this.f544f);
            this.f542d.setOnItemClickListener(this);
        }
        return this.f542d;
    }

    /* renamed from: k */
    public boolean mo699k(C0187r rVar) {
        if (!rVar.hasVisibleItems()) {
            return false;
        }
        new C0166h(rVar).mo821a((IBinder) null);
        C0178m.C0179a aVar = this.f543e;
        if (aVar == null) {
            return true;
        }
        aVar.mo510c(rVar);
        return true;
    }

    /* renamed from: l */
    public Parcelable mo715l() {
        if (this.f542d == null) {
            return null;
        }
        Bundle bundle = new Bundle();
        SparseArray sparseArray = new SparseArray();
        ExpandedMenuView expandedMenuView = this.f542d;
        if (expandedMenuView != null) {
            expandedMenuView.saveHierarchyState(sparseArray);
        }
        bundle.putSparseParcelableArray("android:menu:list", sparseArray);
        return bundle;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        this.f541c.mo820z(this.f544f.getItem(i), this, 0);
    }
}
