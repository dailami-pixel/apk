package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.appcompat.view.menu.C0180n;
import java.util.ArrayList;

/* renamed from: androidx.appcompat.view.menu.f */
public class C0162f extends BaseAdapter {

    /* renamed from: a */
    C0163g f547a;

    /* renamed from: b */
    private int f548b = -1;

    /* renamed from: c */
    private boolean f549c;

    /* renamed from: d */
    private final boolean f550d;

    /* renamed from: e */
    private final LayoutInflater f551e;

    /* renamed from: f */
    private final int f552f;

    public C0162f(C0163g gVar, LayoutInflater layoutInflater, boolean z, int i) {
        this.f550d = z;
        this.f551e = layoutInflater;
        this.f547a = gVar;
        this.f552f = i;
        mo744a();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo744a() {
        C0167i o = this.f547a.mo799o();
        if (o != null) {
            ArrayList<C0167i> p = this.f547a.mo800p();
            int size = p.size();
            for (int i = 0; i < size; i++) {
                if (p.get(i) == o) {
                    this.f548b = i;
                    return;
                }
            }
        }
        this.f548b = -1;
    }

    /* renamed from: b */
    public C0163g mo745b() {
        return this.f547a;
    }

    /* renamed from: c */
    public C0167i getItem(int i) {
        ArrayList<C0167i> p = this.f550d ? this.f547a.mo800p() : this.f547a.mo804r();
        int i2 = this.f548b;
        if (i2 >= 0 && i >= i2) {
            i++;
        }
        return p.get(i);
    }

    /* renamed from: d */
    public void mo747d(boolean z) {
        this.f549c = z;
    }

    public int getCount() {
        ArrayList<C0167i> p = this.f550d ? this.f547a.mo800p() : this.f547a.mo804r();
        int i = this.f548b;
        int size = p.size();
        return i < 0 ? size : size - 1;
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.f551e.inflate(this.f552f, viewGroup, false);
        }
        int groupId = getItem(i).getGroupId();
        int i2 = i - 1;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        listMenuItemView.mo630d(this.f547a.mo807s() && groupId != (i2 >= 0 ? getItem(i2).getGroupId() : groupId));
        C0180n.C0181a aVar = (C0180n.C0181a) view;
        if (this.f549c) {
            listMenuItemView.mo629c(true);
        }
        aVar.mo612f(getItem(i), 0);
        return view;
    }

    public void notifyDataSetChanged() {
        mo744a();
        super.notifyDataSetChanged();
    }
}
