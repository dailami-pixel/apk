package androidx.appcompat.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import androidx.core.content.C0474a;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import p098d.p120g.p124e.p125a.C4706a;
import p098d.p120g.p130j.C4773q;

/* renamed from: androidx.appcompat.view.menu.g */
public class C0163g implements C4706a {

    /* renamed from: a */
    private static final int[] f553a = {1, 4, 5, 3, 2, 0};

    /* renamed from: b */
    private final Context f554b;

    /* renamed from: c */
    private final Resources f555c;

    /* renamed from: d */
    private boolean f556d;

    /* renamed from: e */
    private boolean f557e;

    /* renamed from: f */
    private C0164a f558f;

    /* renamed from: g */
    private ArrayList<C0167i> f559g;

    /* renamed from: h */
    private ArrayList<C0167i> f560h;

    /* renamed from: i */
    private boolean f561i;

    /* renamed from: j */
    private ArrayList<C0167i> f562j;

    /* renamed from: k */
    private ArrayList<C0167i> f563k;

    /* renamed from: l */
    private boolean f564l;

    /* renamed from: m */
    private int f565m = 0;

    /* renamed from: n */
    CharSequence f566n;

    /* renamed from: o */
    Drawable f567o;

    /* renamed from: p */
    View f568p;

    /* renamed from: q */
    private boolean f569q = false;

    /* renamed from: r */
    private boolean f570r = false;

    /* renamed from: s */
    private boolean f571s = false;

    /* renamed from: t */
    private boolean f572t = false;

    /* renamed from: u */
    private ArrayList<C0167i> f573u = new ArrayList<>();

    /* renamed from: v */
    private CopyOnWriteArrayList<WeakReference<C0178m>> f574v = new CopyOnWriteArrayList<>();

    /* renamed from: w */
    private C0167i f575w;

    /* renamed from: x */
    private boolean f576x = false;

    /* renamed from: y */
    private boolean f577y;

    /* renamed from: androidx.appcompat.view.menu.g$a */
    public interface C0164a {
        /* renamed from: a */
        boolean mo474a(C0163g gVar, MenuItem menuItem);

        /* renamed from: b */
        void mo475b(C0163g gVar);
    }

    /* renamed from: androidx.appcompat.view.menu.g$b */
    public interface C0165b {
        /* renamed from: a */
        boolean mo624a(C0167i iVar);
    }

    public C0163g(Context context) {
        boolean z;
        boolean z2 = false;
        this.f554b = context;
        Resources resources = context.getResources();
        this.f555c = resources;
        this.f559g = new ArrayList<>();
        this.f560h = new ArrayList<>();
        this.f561i = true;
        this.f562j = new ArrayList<>();
        this.f563k = new ArrayList<>();
        this.f564l = true;
        if (resources.getConfiguration().keyboard != 1) {
            ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
            int i = C4773q.f17253b;
            if (Build.VERSION.SDK_INT >= 28) {
                z = viewConfiguration.shouldShowMenuShortcutsWhenKeyboardPresent();
            } else {
                Resources resources2 = context.getResources();
                int identifier = resources2.getIdentifier("config_showMenuShortcutsWhenKeyboardPresent", "bool", "android");
                z = identifier != 0 && resources2.getBoolean(identifier);
            }
            if (z) {
                z2 = true;
            }
        }
        this.f557e = z2;
    }

    /* renamed from: A */
    private void m681A(int i, boolean z) {
        if (i >= 0 && i < this.f559g.size()) {
            this.f559g.remove(i);
            if (z) {
                mo818x(true);
            }
        }
    }

    /* renamed from: L */
    private void m682L(int i, CharSequence charSequence, int i2, Drawable drawable, View view) {
        Resources resources = this.f555c;
        if (view != null) {
            this.f568p = view;
            this.f566n = null;
            this.f567o = null;
        } else {
            if (i > 0) {
                this.f566n = resources.getText(i);
            } else if (charSequence != null) {
                this.f566n = charSequence;
            }
            if (i2 > 0) {
                Context context = this.f554b;
                int i3 = C0474a.f2214b;
                this.f567o = context.getDrawable(i2);
            } else if (drawable != null) {
                this.f567o = drawable;
            }
            this.f568p = null;
        }
        mo818x(false);
    }

    /* renamed from: B */
    public void mo753B(C0178m mVar) {
        Iterator<WeakReference<C0178m>> it = this.f574v.iterator();
        while (it.hasNext()) {
            WeakReference next = it.next();
            C0178m mVar2 = (C0178m) next.get();
            if (mVar2 == null || mVar2 == mVar) {
                this.f574v.remove(next);
            }
        }
    }

    /* renamed from: C */
    public void mo754C(Bundle bundle) {
        MenuItem findItem;
        if (bundle != null) {
            SparseArray sparseParcelableArray = bundle.getSparseParcelableArray(mo797m());
            int size = size();
            for (int i = 0; i < size; i++) {
                MenuItem item = getItem(i);
                View actionView = item.getActionView();
                if (!(actionView == null || actionView.getId() == -1)) {
                    actionView.restoreHierarchyState(sparseParcelableArray);
                }
                if (item.hasSubMenu()) {
                    ((C0187r) item.getSubMenu()).mo754C(bundle);
                }
            }
            int i2 = bundle.getInt("android:menu:expandedactionview");
            if (i2 > 0 && (findItem = findItem(i2)) != null) {
                findItem.expandActionView();
            }
        }
    }

    /* renamed from: D */
    public void mo755D(Bundle bundle) {
        Parcelable parcelable;
        SparseArray sparseParcelableArray = bundle.getSparseParcelableArray("android:menu:presenters");
        if (sparseParcelableArray != null && !this.f574v.isEmpty()) {
            Iterator<WeakReference<C0178m>> it = this.f574v.iterator();
            while (it.hasNext()) {
                WeakReference next = it.next();
                C0178m mVar = (C0178m) next.get();
                if (mVar == null) {
                    this.f574v.remove(next);
                } else {
                    int id = mVar.getId();
                    if (id > 0 && (parcelable = (Parcelable) sparseParcelableArray.get(id)) != null) {
                        mVar.mo713i(parcelable);
                    }
                }
            }
        }
    }

    /* renamed from: E */
    public void mo756E(Bundle bundle) {
        int size = size();
        SparseArray sparseArray = null;
        for (int i = 0; i < size; i++) {
            MenuItem item = getItem(i);
            View actionView = item.getActionView();
            if (!(actionView == null || actionView.getId() == -1)) {
                if (sparseArray == null) {
                    sparseArray = new SparseArray();
                }
                actionView.saveHierarchyState(sparseArray);
                if (item.isActionViewExpanded()) {
                    bundle.putInt("android:menu:expandedactionview", item.getItemId());
                }
            }
            if (item.hasSubMenu()) {
                ((C0187r) item.getSubMenu()).mo756E(bundle);
            }
        }
        if (sparseArray != null) {
            bundle.putSparseParcelableArray(mo797m(), sparseArray);
        }
    }

    /* renamed from: F */
    public void mo757F(Bundle bundle) {
        Parcelable l;
        if (!this.f574v.isEmpty()) {
            SparseArray sparseArray = new SparseArray();
            Iterator<WeakReference<C0178m>> it = this.f574v.iterator();
            while (it.hasNext()) {
                WeakReference next = it.next();
                C0178m mVar = (C0178m) next.get();
                if (mVar == null) {
                    this.f574v.remove(next);
                } else {
                    int id = mVar.getId();
                    if (id > 0 && (l = mVar.mo715l()) != null) {
                        sparseArray.put(id, l);
                    }
                }
            }
            bundle.putSparseParcelableArray("android:menu:presenters", sparseArray);
        }
    }

    /* renamed from: G */
    public void mo758G(C0164a aVar) {
        this.f558f = aVar;
    }

    /* renamed from: H */
    public C0163g mo759H(int i) {
        this.f565m = i;
        return this;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: I */
    public void mo760I(MenuItem menuItem) {
        int groupId = ((C0167i) menuItem).getGroupId();
        int size = this.f559g.size();
        mo768R();
        for (int i = 0; i < size; i++) {
            C0167i iVar = this.f559g.get(i);
            if (iVar.getGroupId() == groupId && iVar.mo849l() && iVar.isCheckable()) {
                iVar.mo854q(iVar == menuItem);
            }
        }
        mo767Q();
    }

    /* access modifiers changed from: protected */
    /* renamed from: J */
    public C0163g mo761J(int i) {
        m682L(0, (CharSequence) null, i, (Drawable) null, (View) null);
        return this;
    }

    /* access modifiers changed from: protected */
    /* renamed from: K */
    public C0163g mo762K(Drawable drawable) {
        m682L(0, (CharSequence) null, 0, drawable, (View) null);
        return this;
    }

    /* access modifiers changed from: protected */
    /* renamed from: M */
    public C0163g mo763M(int i) {
        m682L(i, (CharSequence) null, 0, (Drawable) null, (View) null);
        return this;
    }

    /* access modifiers changed from: protected */
    /* renamed from: N */
    public C0163g mo764N(CharSequence charSequence) {
        m682L(0, charSequence, 0, (Drawable) null, (View) null);
        return this;
    }

    /* access modifiers changed from: protected */
    /* renamed from: O */
    public C0163g mo765O(View view) {
        m682L(0, (CharSequence) null, 0, (Drawable) null, view);
        return this;
    }

    /* renamed from: P */
    public void mo766P(boolean z) {
        this.f577y = z;
    }

    /* renamed from: Q */
    public void mo767Q() {
        this.f569q = false;
        if (this.f570r) {
            this.f570r = false;
            mo818x(this.f571s);
        }
    }

    /* renamed from: R */
    public void mo768R() {
        if (!this.f569q) {
            this.f569q = true;
            this.f570r = false;
            this.f571s = false;
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public MenuItem mo769a(int i, int i2, int i3, CharSequence charSequence) {
        int i4;
        int i5 = (-65536 & i3) >> 16;
        if (i5 >= 0) {
            int[] iArr = f553a;
            if (i5 < iArr.length) {
                int i6 = (iArr[i5] << 16) | (65535 & i3);
                C0167i iVar = new C0167i(this, i, i2, i3, i6, charSequence, this.f565m);
                ArrayList<C0167i> arrayList = this.f559g;
                int size = arrayList.size();
                while (true) {
                    size--;
                    if (size >= 0) {
                        if (arrayList.get(size).mo825e() <= i6) {
                            i4 = size + 1;
                            break;
                        }
                    } else {
                        i4 = 0;
                        break;
                    }
                }
                arrayList.add(i4, iVar);
                mo818x(true);
                return iVar;
            }
        }
        throw new IllegalArgumentException("order does not contain a valid category.");
    }

    public MenuItem add(int i) {
        return mo769a(0, 0, 0, this.f555c.getString(i));
    }

    public MenuItem add(int i, int i2, int i3, int i4) {
        return mo769a(i, i2, i3, this.f555c.getString(i4));
    }

    public MenuItem add(int i, int i2, int i3, CharSequence charSequence) {
        return mo769a(i, i2, i3, charSequence);
    }

    public MenuItem add(CharSequence charSequence) {
        return mo769a(0, 0, 0, charSequence);
    }

    public int addIntentOptions(int i, int i2, int i3, ComponentName componentName, Intent[] intentArr, Intent intent, int i4, MenuItem[] menuItemArr) {
        int i5;
        PackageManager packageManager = this.f554b.getPackageManager();
        List<ResolveInfo> queryIntentActivityOptions = packageManager.queryIntentActivityOptions(componentName, intentArr, intent, 0);
        int size = queryIntentActivityOptions != null ? queryIntentActivityOptions.size() : 0;
        if ((i4 & 1) == 0) {
            removeGroup(i);
        }
        for (int i6 = 0; i6 < size; i6++) {
            ResolveInfo resolveInfo = queryIntentActivityOptions.get(i6);
            int i7 = resolveInfo.specificIndex;
            Intent intent2 = new Intent(i7 < 0 ? intent : intentArr[i7]);
            ActivityInfo activityInfo = resolveInfo.activityInfo;
            intent2.setComponent(new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name));
            MenuItem intent3 = mo769a(i, i2, i3, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setIntent(intent2);
            if (menuItemArr != null && (i5 = resolveInfo.specificIndex) >= 0) {
                menuItemArr[i5] = intent3;
            }
        }
        return size;
    }

    public SubMenu addSubMenu(int i) {
        return addSubMenu(0, 0, 0, (CharSequence) this.f555c.getString(i));
    }

    public SubMenu addSubMenu(int i, int i2, int i3, int i4) {
        return addSubMenu(i, i2, i3, (CharSequence) this.f555c.getString(i4));
    }

    public SubMenu addSubMenu(int i, int i2, int i3, CharSequence charSequence) {
        C0167i iVar = (C0167i) mo769a(i, i2, i3, charSequence);
        C0187r rVar = new C0187r(this.f554b, this, iVar);
        iVar.mo873t(rVar);
        return rVar;
    }

    public SubMenu addSubMenu(CharSequence charSequence) {
        return addSubMenu(0, 0, 0, charSequence);
    }

    /* renamed from: b */
    public void mo779b(C0178m mVar) {
        mo780c(mVar, this.f554b);
    }

    /* renamed from: c */
    public void mo780c(C0178m mVar, Context context) {
        this.f574v.add(new WeakReference(mVar));
        mVar.mo697h(context, this);
        this.f564l = true;
    }

    public void clear() {
        C0167i iVar = this.f575w;
        if (iVar != null) {
            mo786f(iVar);
        }
        this.f559g.clear();
        mo818x(true);
    }

    public void clearHeader() {
        this.f567o = null;
        this.f566n = null;
        this.f568p = null;
        mo818x(false);
    }

    public void close() {
        mo785e(true);
    }

    /* renamed from: d */
    public void mo784d() {
        C0164a aVar = this.f558f;
        if (aVar != null) {
            aVar.mo475b(this);
        }
    }

    /* renamed from: e */
    public final void mo785e(boolean z) {
        if (!this.f572t) {
            this.f572t = true;
            Iterator<WeakReference<C0178m>> it = this.f574v.iterator();
            while (it.hasNext()) {
                WeakReference next = it.next();
                C0178m mVar = (C0178m) next.get();
                if (mVar == null) {
                    this.f574v.remove(next);
                } else {
                    mVar.mo691b(this, z);
                }
            }
            this.f572t = false;
        }
    }

    /* renamed from: f */
    public boolean mo786f(C0167i iVar) {
        boolean z = false;
        if (!this.f574v.isEmpty() && this.f575w == iVar) {
            mo768R();
            Iterator<WeakReference<C0178m>> it = this.f574v.iterator();
            while (it.hasNext()) {
                WeakReference next = it.next();
                C0178m mVar = (C0178m) next.get();
                if (mVar == null) {
                    this.f574v.remove(next);
                } else {
                    z = mVar.mo693e(this, iVar);
                    if (z) {
                        break;
                    }
                }
            }
            mo767Q();
            if (z) {
                this.f575w = null;
            }
        }
        return z;
    }

    public MenuItem findItem(int i) {
        MenuItem findItem;
        int size = size();
        for (int i2 = 0; i2 < size; i2++) {
            C0167i iVar = this.f559g.get(i2);
            if (iVar.getItemId() == i) {
                return iVar;
            }
            if (iVar.hasSubMenu() && (findItem = ((C0163g) iVar.getSubMenu()).findItem(i)) != null) {
                return findItem;
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public boolean mo788g(C0163g gVar, MenuItem menuItem) {
        C0164a aVar = this.f558f;
        return aVar != null && aVar.mo474a(gVar, menuItem);
    }

    public MenuItem getItem(int i) {
        return this.f559g.get(i);
    }

    /* renamed from: h */
    public boolean mo790h(C0167i iVar) {
        boolean z = false;
        if (this.f574v.isEmpty()) {
            return false;
        }
        mo768R();
        Iterator<WeakReference<C0178m>> it = this.f574v.iterator();
        while (it.hasNext()) {
            WeakReference next = it.next();
            C0178m mVar = (C0178m) next.get();
            if (mVar == null) {
                this.f574v.remove(next);
            } else {
                z = mVar.mo694f(this, iVar);
                if (z) {
                    break;
                }
            }
        }
        mo767Q();
        if (z) {
            this.f575w = iVar;
        }
        return z;
    }

    public boolean hasVisibleItems() {
        if (this.f577y) {
            return true;
        }
        int size = size();
        for (int i = 0; i < size; i++) {
            if (this.f559g.get(i).isVisible()) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public C0167i mo792i(int i, KeyEvent keyEvent) {
        ArrayList<C0167i> arrayList = this.f573u;
        arrayList.clear();
        mo794j(arrayList, i, keyEvent);
        if (arrayList.isEmpty()) {
            return null;
        }
        int metaState = keyEvent.getMetaState();
        KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
        keyEvent.getKeyData(keyData);
        int size = arrayList.size();
        if (size == 1) {
            return arrayList.get(0);
        }
        boolean t = mo814t();
        for (int i2 = 0; i2 < size; i2++) {
            C0167i iVar = arrayList.get(i2);
            char alphabeticShortcut = t ? iVar.getAlphabeticShortcut() : iVar.getNumericShortcut();
            char[] cArr = keyData.meta;
            if ((alphabeticShortcut == cArr[0] && (metaState & 2) == 0) || ((alphabeticShortcut == cArr[2] && (metaState & 2) != 0) || (t && alphabeticShortcut == 8 && i == 67))) {
                return iVar;
            }
        }
        return null;
    }

    public boolean isShortcutKey(int i, KeyEvent keyEvent) {
        return mo792i(i, keyEvent) != null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j */
    public void mo794j(List<C0167i> list, int i, KeyEvent keyEvent) {
        boolean t = mo814t();
        int modifiers = keyEvent.getModifiers();
        KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
        if (keyEvent.getKeyData(keyData) || i == 67) {
            int size = this.f559g.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0167i iVar = this.f559g.get(i2);
                if (iVar.hasSubMenu()) {
                    ((C0163g) iVar.getSubMenu()).mo794j(list, i, keyEvent);
                }
                char alphabeticShortcut = t ? iVar.getAlphabeticShortcut() : iVar.getNumericShortcut();
                if (((modifiers & 69647) == ((t ? iVar.getAlphabeticModifiers() : iVar.getNumericModifiers()) & 69647)) && alphabeticShortcut != 0) {
                    char[] cArr = keyData.meta;
                    if ((alphabeticShortcut == cArr[0] || alphabeticShortcut == cArr[2] || (t && alphabeticShortcut == 8 && i == 67)) && iVar.isEnabled()) {
                        list.add(iVar);
                    }
                }
            }
        }
    }

    /* renamed from: k */
    public void mo795k() {
        ArrayList<C0167i> r = mo804r();
        if (this.f564l) {
            Iterator<WeakReference<C0178m>> it = this.f574v.iterator();
            boolean z = false;
            while (it.hasNext()) {
                WeakReference next = it.next();
                C0178m mVar = (C0178m) next.get();
                if (mVar == null) {
                    this.f574v.remove(next);
                } else {
                    z |= mVar.mo711d();
                }
            }
            if (z) {
                this.f562j.clear();
                this.f563k.clear();
                int size = r.size();
                for (int i = 0; i < size; i++) {
                    C0167i iVar = r.get(i);
                    (iVar.mo848k() ? this.f562j : this.f563k).add(iVar);
                }
            } else {
                this.f562j.clear();
                this.f563k.clear();
                this.f563k.addAll(mo804r());
            }
            this.f564l = false;
        }
    }

    /* renamed from: l */
    public ArrayList<C0167i> mo796l() {
        mo795k();
        return this.f562j;
    }

    /* access modifiers changed from: protected */
    /* renamed from: m */
    public String mo797m() {
        return "android:menu:actionviewstates";
    }

    /* renamed from: n */
    public Context mo798n() {
        return this.f554b;
    }

    /* renamed from: o */
    public C0167i mo799o() {
        return this.f575w;
    }

    /* renamed from: p */
    public ArrayList<C0167i> mo800p() {
        mo795k();
        return this.f563k;
    }

    public boolean performIdentifierAction(int i, int i2) {
        return mo819y(findItem(i), i2);
    }

    public boolean performShortcut(int i, KeyEvent keyEvent, int i2) {
        C0167i i3 = mo792i(i, keyEvent);
        boolean z = i3 != null ? mo820z(i3, (C0178m) null, i2) : false;
        if ((i2 & 2) != 0) {
            mo785e(true);
        }
        return z;
    }

    /* renamed from: q */
    public C0163g mo803q() {
        return this;
    }

    /* renamed from: r */
    public ArrayList<C0167i> mo804r() {
        if (!this.f561i) {
            return this.f560h;
        }
        this.f560h.clear();
        int size = this.f559g.size();
        for (int i = 0; i < size; i++) {
            C0167i iVar = this.f559g.get(i);
            if (iVar.isVisible()) {
                this.f560h.add(iVar);
            }
        }
        this.f561i = false;
        this.f564l = true;
        return this.f560h;
    }

    public void removeGroup(int i) {
        int size = size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                i2 = -1;
                break;
            } else if (this.f559g.get(i2).getGroupId() == i) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 >= 0) {
            int size2 = this.f559g.size() - i2;
            int i3 = 0;
            while (true) {
                int i4 = i3 + 1;
                if (i3 >= size2 || this.f559g.get(i2).getGroupId() != i) {
                    mo818x(true);
                } else {
                    m681A(i2, false);
                    i3 = i4;
                }
            }
            mo818x(true);
        }
    }

    public void removeItem(int i) {
        int size = size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                i2 = -1;
                break;
            } else if (this.f559g.get(i2).getItemId() == i) {
                break;
            } else {
                i2++;
            }
        }
        m681A(i2, true);
    }

    /* renamed from: s */
    public boolean mo807s() {
        return this.f576x;
    }

    public void setGroupCheckable(int i, boolean z, boolean z2) {
        int size = this.f559g.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0167i iVar = this.f559g.get(i2);
            if (iVar.getGroupId() == i) {
                iVar.mo855r(z2);
                iVar.setCheckable(z);
            }
        }
    }

    public void setGroupDividerEnabled(boolean z) {
        this.f576x = z;
    }

    public void setGroupEnabled(int i, boolean z) {
        int size = this.f559g.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0167i iVar = this.f559g.get(i2);
            if (iVar.getGroupId() == i) {
                iVar.setEnabled(z);
            }
        }
    }

    public void setGroupVisible(int i, boolean z) {
        int size = this.f559g.size();
        boolean z2 = false;
        for (int i2 = 0; i2 < size; i2++) {
            C0167i iVar = this.f559g.get(i2);
            if (iVar.getGroupId() == i && iVar.mo875u(z)) {
                z2 = true;
            }
        }
        if (z2) {
            mo818x(true);
        }
    }

    public void setQwertyMode(boolean z) {
        this.f556d = z;
        mo818x(false);
    }

    public int size() {
        return this.f559g.size();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: t */
    public boolean mo814t() {
        return this.f556d;
    }

    /* renamed from: u */
    public boolean mo815u() {
        return this.f557e;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: v */
    public void mo816v() {
        this.f564l = true;
        mo818x(true);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: w */
    public void mo817w() {
        this.f561i = true;
        mo818x(true);
    }

    /* renamed from: x */
    public void mo818x(boolean z) {
        if (!this.f569q) {
            if (z) {
                this.f561i = true;
                this.f564l = true;
            }
            if (!this.f574v.isEmpty()) {
                mo768R();
                Iterator<WeakReference<C0178m>> it = this.f574v.iterator();
                while (it.hasNext()) {
                    WeakReference next = it.next();
                    C0178m mVar = (C0178m) next.get();
                    if (mVar == null) {
                        this.f574v.remove(next);
                    } else {
                        mVar.mo692c(z);
                    }
                }
                mo767Q();
                return;
            }
            return;
        }
        this.f570r = true;
        if (z) {
            this.f571s = true;
        }
    }

    /* renamed from: y */
    public boolean mo819y(MenuItem menuItem, int i) {
        return mo820z(menuItem, (C0178m) null, i);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x002c, code lost:
        if (r1 != false) goto L_0x002e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x003e, code lost:
        if ((r9 & 1) == 0) goto L_0x002e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x009a, code lost:
        if (r1 == false) goto L_0x002e;
     */
    /* renamed from: z */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo820z(android.view.MenuItem r7, androidx.appcompat.view.menu.C0178m r8, int r9) {
        /*
            r6 = this;
            androidx.appcompat.view.menu.i r7 = (androidx.appcompat.view.menu.C0167i) r7
            r0 = 0
            if (r7 == 0) goto L_0x009e
            boolean r1 = r7.isEnabled()
            if (r1 != 0) goto L_0x000d
            goto L_0x009e
        L_0x000d:
            boolean r1 = r7.mo847j()
            d.g.j.b r2 = r7.mo635b()
            r3 = 1
            if (r2 == 0) goto L_0x0020
            boolean r4 = r2.mo933a()
            if (r4 == 0) goto L_0x0020
            r4 = 1
            goto L_0x0021
        L_0x0020:
            r4 = 0
        L_0x0021:
            boolean r5 = r7.mo842i()
            if (r5 == 0) goto L_0x0033
            boolean r7 = r7.expandActionView()
            r1 = r1 | r7
            if (r1 == 0) goto L_0x009d
        L_0x002e:
            r6.mo785e(r3)
            goto L_0x009d
        L_0x0033:
            boolean r5 = r7.hasSubMenu()
            if (r5 != 0) goto L_0x0041
            if (r4 == 0) goto L_0x003c
            goto L_0x0041
        L_0x003c:
            r7 = r9 & 1
            if (r7 != 0) goto L_0x009d
            goto L_0x002e
        L_0x0041:
            r9 = r9 & 4
            if (r9 != 0) goto L_0x0048
            r6.mo785e(r0)
        L_0x0048:
            boolean r9 = r7.hasSubMenu()
            if (r9 != 0) goto L_0x0058
            androidx.appcompat.view.menu.r r9 = new androidx.appcompat.view.menu.r
            android.content.Context r5 = r6.f554b
            r9.<init>(r5, r6, r7)
            r7.mo873t(r9)
        L_0x0058:
            android.view.SubMenu r7 = r7.getSubMenu()
            androidx.appcompat.view.menu.r r7 = (androidx.appcompat.view.menu.C0187r) r7
            if (r4 == 0) goto L_0x0063
            r2.mo936f(r7)
        L_0x0063:
            java.util.concurrent.CopyOnWriteArrayList<java.lang.ref.WeakReference<androidx.appcompat.view.menu.m>> r9 = r6.f574v
            boolean r9 = r9.isEmpty()
            if (r9 == 0) goto L_0x006c
            goto L_0x0099
        L_0x006c:
            if (r8 == 0) goto L_0x0072
            boolean r0 = r8.mo699k(r7)
        L_0x0072:
            java.util.concurrent.CopyOnWriteArrayList<java.lang.ref.WeakReference<androidx.appcompat.view.menu.m>> r8 = r6.f574v
            java.util.Iterator r8 = r8.iterator()
        L_0x0078:
            boolean r9 = r8.hasNext()
            if (r9 == 0) goto L_0x0099
            java.lang.Object r9 = r8.next()
            java.lang.ref.WeakReference r9 = (java.lang.ref.WeakReference) r9
            java.lang.Object r2 = r9.get()
            androidx.appcompat.view.menu.m r2 = (androidx.appcompat.view.menu.C0178m) r2
            if (r2 != 0) goto L_0x0092
            java.util.concurrent.CopyOnWriteArrayList<java.lang.ref.WeakReference<androidx.appcompat.view.menu.m>> r2 = r6.f574v
            r2.remove(r9)
            goto L_0x0078
        L_0x0092:
            if (r0 != 0) goto L_0x0078
            boolean r0 = r2.mo699k(r7)
            goto L_0x0078
        L_0x0099:
            r1 = r1 | r0
            if (r1 != 0) goto L_0x009d
            goto L_0x002e
        L_0x009d:
            return r1
        L_0x009e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.C0163g.mo820z(android.view.MenuItem, androidx.appcompat.view.menu.m, int):boolean");
    }
}
