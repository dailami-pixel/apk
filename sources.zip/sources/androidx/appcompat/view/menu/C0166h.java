package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.C0128f;
import androidx.appcompat.view.menu.C0160e;
import androidx.appcompat.view.menu.C0178m;
import com.vidio.android.p195tv.R;

/* renamed from: androidx.appcompat.view.menu.h */
class C0166h implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, C0178m.C0179a {

    /* renamed from: a */
    private C0163g f578a;

    /* renamed from: b */
    private C0128f f579b;

    /* renamed from: c */
    C0160e f580c;

    public C0166h(C0163g gVar) {
        this.f578a = gVar;
    }

    /* renamed from: a */
    public void mo821a(IBinder iBinder) {
        C0163g gVar = this.f578a;
        C0128f.C0129a aVar = new C0128f.C0129a(gVar.mo798n());
        C0160e eVar = new C0160e(aVar.mo548b(), R.layout.abc_list_menu_item_layout);
        this.f580c = eVar;
        eVar.mo695g(this);
        this.f578a.mo779b(this.f580c);
        aVar.mo549c(this.f580c.mo734a(), this);
        View view = gVar.f568p;
        if (view != null) {
            aVar.mo550d(view);
        } else {
            aVar.mo551e(gVar.f567o);
            aVar.mo554h(gVar.f566n);
        }
        aVar.mo552f(this);
        C0128f a = aVar.mo547a();
        this.f579b = a;
        a.setOnDismissListener(this);
        WindowManager.LayoutParams attributes = this.f579b.getWindow().getAttributes();
        attributes.type = 1003;
        attributes.flags |= 131072;
        this.f579b.show();
    }

    /* renamed from: b */
    public void mo509b(C0163g gVar, boolean z) {
        C0128f fVar;
        if ((z || gVar == this.f578a) && (fVar = this.f579b) != null) {
            fVar.dismiss();
        }
    }

    /* renamed from: c */
    public boolean mo510c(C0163g gVar) {
        return false;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        this.f578a.mo819y(((C0160e.C0161a) this.f580c.mo734a()).getItem(i), 0);
    }

    public void onDismiss(DialogInterface dialogInterface) {
        this.f580c.mo691b(this.f578a, true);
    }

    public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
        Window window;
        View decorView;
        KeyEvent.DispatcherState keyDispatcherState;
        View decorView2;
        KeyEvent.DispatcherState keyDispatcherState2;
        if (i == 82 || i == 4) {
            if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                Window window2 = this.f579b.getWindow();
                if (!(window2 == null || (decorView2 = window2.getDecorView()) == null || (keyDispatcherState2 = decorView2.getKeyDispatcherState()) == null)) {
                    keyDispatcherState2.startTracking(keyEvent, this);
                    return true;
                }
            } else if (keyEvent.getAction() == 1 && !keyEvent.isCanceled() && (window = this.f579b.getWindow()) != null && (decorView = window.getDecorView()) != null && (keyDispatcherState = decorView.getKeyDispatcherState()) != null && keyDispatcherState.isTracking(keyEvent)) {
                this.f578a.mo785e(true);
                dialogInterface.dismiss();
                return true;
            }
        }
        return this.f578a.performShortcut(i, keyEvent, 0);
    }
}
