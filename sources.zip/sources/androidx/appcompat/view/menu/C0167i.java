package androidx.appcompat.view.menu;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewDebug;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.C0180n;
import androidx.core.graphics.drawable.C0487a;
import com.appsflyer.oaid.BuildConfig;
import com.vidio.android.p195tv.R;
import p098d.p099a.p100c.p101a.C4569a;
import p098d.p120g.p124e.p125a.C4707b;
import p098d.p120g.p130j.C4747b;

/* renamed from: androidx.appcompat.view.menu.i */
public final class C0167i implements C4707b {

    /* renamed from: A */
    private C4747b f581A;

    /* renamed from: B */
    private MenuItem.OnActionExpandListener f582B;

    /* renamed from: C */
    private boolean f583C = false;

    /* renamed from: D */
    private ContextMenu.ContextMenuInfo f584D;

    /* renamed from: a */
    private final int f585a;

    /* renamed from: b */
    private final int f586b;

    /* renamed from: c */
    private final int f587c;

    /* renamed from: d */
    private final int f588d;

    /* renamed from: e */
    private CharSequence f589e;

    /* renamed from: f */
    private CharSequence f590f;

    /* renamed from: g */
    private Intent f591g;

    /* renamed from: h */
    private char f592h;

    /* renamed from: i */
    private int f593i = 4096;

    /* renamed from: j */
    private char f594j;

    /* renamed from: k */
    private int f595k = 4096;

    /* renamed from: l */
    private Drawable f596l;

    /* renamed from: m */
    private int f597m = 0;

    /* renamed from: n */
    C0163g f598n;

    /* renamed from: o */
    private C0187r f599o;

    /* renamed from: p */
    private MenuItem.OnMenuItemClickListener f600p;

    /* renamed from: q */
    private CharSequence f601q;

    /* renamed from: r */
    private CharSequence f602r;

    /* renamed from: s */
    private ColorStateList f603s = null;

    /* renamed from: t */
    private PorterDuff.Mode f604t = null;

    /* renamed from: u */
    private boolean f605u = false;

    /* renamed from: v */
    private boolean f606v = false;

    /* renamed from: w */
    private boolean f607w = false;

    /* renamed from: x */
    private int f608x = 16;

    /* renamed from: y */
    private int f609y = 0;

    /* renamed from: z */
    private View f610z;

    /* renamed from: androidx.appcompat.view.menu.i$a */
    class C0168a implements C4747b.C4749b {
        C0168a() {
        }
    }

    C0167i(C0163g gVar, int i, int i2, int i3, int i4, CharSequence charSequence, int i5) {
        this.f598n = gVar;
        this.f585a = i2;
        this.f586b = i;
        this.f587c = i3;
        this.f588d = i4;
        this.f589e = charSequence;
        this.f609y = i5;
    }

    /* renamed from: c */
    private static void m731c(StringBuilder sb, int i, int i2, String str) {
        if ((i & i2) == i2) {
            sb.append(str);
        }
    }

    /* renamed from: d */
    private Drawable m732d(Drawable drawable) {
        if (drawable != null && this.f607w && (this.f605u || this.f606v)) {
            drawable = C0487a.m2226h(drawable).mutate();
            if (this.f605u) {
                drawable.setTintList(this.f603s);
            }
            if (this.f606v) {
                drawable.setTintMode(this.f604t);
            }
            this.f607w = false;
        }
        return drawable;
    }

    /* renamed from: a */
    public C4707b mo634a(C4747b bVar) {
        C4747b bVar2 = this.f581A;
        if (bVar2 != null) {
            bVar2.mo21836h();
        }
        this.f610z = null;
        this.f581A = bVar;
        this.f598n.mo818x(true);
        C4747b bVar3 = this.f581A;
        if (bVar3 != null) {
            bVar3.mo940j(new C0168a());
        }
        return this;
    }

    /* renamed from: b */
    public C4747b mo635b() {
        return this.f581A;
    }

    public boolean collapseActionView() {
        if ((this.f609y & 8) == 0) {
            return false;
        }
        if (this.f610z == null) {
            return true;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f582B;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionCollapse(this)) {
            return this.f598n.mo786f(this);
        }
        return false;
    }

    /* renamed from: e */
    public int mo825e() {
        return this.f588d;
    }

    public boolean expandActionView() {
        if (!mo842i()) {
            return false;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f582B;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionExpand(this)) {
            return this.f598n.mo790h(this);
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public char mo826f() {
        return this.f598n.mo814t() ? this.f594j : this.f592h;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public String mo827g() {
        int i;
        char f = mo826f();
        if (f == 0) {
            return BuildConfig.FLAVOR;
        }
        Resources resources = this.f598n.mo798n().getResources();
        StringBuilder sb = new StringBuilder();
        if (ViewConfiguration.get(this.f598n.mo798n()).hasPermanentMenuKey()) {
            sb.append(resources.getString(R.string.abc_prepend_shortcut_label));
        }
        int i2 = this.f598n.mo814t() ? this.f595k : this.f593i;
        m731c(sb, i2, 65536, resources.getString(R.string.abc_menu_meta_shortcut_label));
        m731c(sb, i2, 4096, resources.getString(R.string.abc_menu_ctrl_shortcut_label));
        m731c(sb, i2, 2, resources.getString(R.string.abc_menu_alt_shortcut_label));
        m731c(sb, i2, 1, resources.getString(R.string.abc_menu_shift_shortcut_label));
        m731c(sb, i2, 4, resources.getString(R.string.abc_menu_sym_shortcut_label));
        m731c(sb, i2, 8, resources.getString(R.string.abc_menu_function_shortcut_label));
        if (f == 8) {
            i = R.string.abc_menu_delete_shortcut_label;
        } else if (f == 10) {
            i = R.string.abc_menu_enter_shortcut_label;
        } else if (f != ' ') {
            sb.append(f);
            return sb.toString();
        } else {
            i = R.string.abc_menu_space_shortcut_label;
        }
        sb.append(resources.getString(i));
        return sb.toString();
    }

    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.getActionProvider()");
    }

    public View getActionView() {
        View view = this.f610z;
        if (view != null) {
            return view;
        }
        C4747b bVar = this.f581A;
        if (bVar == null) {
            return null;
        }
        View d = bVar.mo938d(this);
        this.f610z = d;
        return d;
    }

    public int getAlphabeticModifiers() {
        return this.f595k;
    }

    public char getAlphabeticShortcut() {
        return this.f594j;
    }

    public CharSequence getContentDescription() {
        return this.f601q;
    }

    public int getGroupId() {
        return this.f586b;
    }

    public Drawable getIcon() {
        Drawable drawable = this.f596l;
        if (drawable != null) {
            return m732d(drawable);
        }
        if (this.f597m == 0) {
            return null;
        }
        Drawable b = C4569a.m16431b(this.f598n.mo798n(), this.f597m);
        this.f597m = 0;
        this.f596l = b;
        return m732d(b);
    }

    public ColorStateList getIconTintList() {
        return this.f603s;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.f604t;
    }

    public Intent getIntent() {
        return this.f591g;
    }

    @ViewDebug.CapturedViewProperty
    public int getItemId() {
        return this.f585a;
    }

    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return this.f584D;
    }

    public int getNumericModifiers() {
        return this.f593i;
    }

    public char getNumericShortcut() {
        return this.f592h;
    }

    public int getOrder() {
        return this.f587c;
    }

    public SubMenu getSubMenu() {
        return this.f599o;
    }

    @ViewDebug.CapturedViewProperty
    public CharSequence getTitle() {
        return this.f589e;
    }

    public CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f590f;
        return charSequence != null ? charSequence : this.f589e;
    }

    public CharSequence getTooltipText() {
        return this.f602r;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public CharSequence mo840h(C0180n.C0181a aVar) {
        return aVar.mo611e() ? getTitleCondensed() : this.f589e;
    }

    public boolean hasSubMenu() {
        return this.f599o != null;
    }

    /* renamed from: i */
    public boolean mo842i() {
        C4747b bVar;
        if ((this.f609y & 8) == 0) {
            return false;
        }
        if (this.f610z == null && (bVar = this.f581A) != null) {
            this.f610z = bVar.mo938d(this);
        }
        return this.f610z != null;
    }

    public boolean isActionViewExpanded() {
        return this.f583C;
    }

    public boolean isCheckable() {
        return (this.f608x & 1) == 1;
    }

    public boolean isChecked() {
        return (this.f608x & 2) == 2;
    }

    public boolean isEnabled() {
        return (this.f608x & 16) != 0;
    }

    public boolean isVisible() {
        C4747b bVar = this.f581A;
        return (bVar == null || !bVar.mo939g()) ? (this.f608x & 8) == 0 : (this.f608x & 8) == 0 && this.f581A.mo937b();
    }

    /* renamed from: j */
    public boolean mo847j() {
        MenuItem.OnMenuItemClickListener onMenuItemClickListener = this.f600p;
        if (onMenuItemClickListener != null && onMenuItemClickListener.onMenuItemClick(this)) {
            return true;
        }
        C0163g gVar = this.f598n;
        if (gVar.mo788g(gVar, this)) {
            return true;
        }
        if (this.f591g != null) {
            try {
                this.f598n.mo798n().startActivity(this.f591g);
                return true;
            } catch (ActivityNotFoundException e) {
                Log.e("MenuItemImpl", "Can't find activity to handle intent; ignoring", e);
            }
        }
        C4747b bVar = this.f581A;
        return bVar != null && bVar.mo935e();
    }

    /* renamed from: k */
    public boolean mo848k() {
        return (this.f608x & 32) == 32;
    }

    /* renamed from: l */
    public boolean mo849l() {
        return (this.f608x & 4) != 0;
    }

    /* renamed from: m */
    public boolean mo850m() {
        return (this.f609y & 1) == 1;
    }

    /* renamed from: n */
    public boolean mo851n() {
        return (this.f609y & 2) == 2;
    }

    /* renamed from: o */
    public C4707b mo852o(View view) {
        int i;
        this.f610z = view;
        this.f581A = null;
        if (view != null && view.getId() == -1 && (i = this.f585a) > 0) {
            view.setId(i);
        }
        this.f598n.mo816v();
        return this;
    }

    /* renamed from: p */
    public void mo853p(boolean z) {
        this.f583C = z;
        this.f598n.mo818x(false);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q */
    public void mo854q(boolean z) {
        int i = this.f608x;
        int i2 = (z ? 2 : 0) | (i & -3);
        this.f608x = i2;
        if (i != i2) {
            this.f598n.mo818x(false);
        }
    }

    /* renamed from: r */
    public void mo855r(boolean z) {
        this.f608x = (z ? 4 : 0) | (this.f608x & -5);
    }

    /* renamed from: s */
    public void mo856s(boolean z) {
        this.f608x = z ? this.f608x | 32 : this.f608x & -33;
    }

    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.setActionProvider()");
    }

    public MenuItem setActionView(int i) {
        Context n = this.f598n.mo798n();
        mo852o(LayoutInflater.from(n).inflate(i, new LinearLayout(n), false));
        return this;
    }

    public /* bridge */ /* synthetic */ MenuItem setActionView(View view) {
        mo852o(view);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c) {
        if (this.f594j == c) {
            return this;
        }
        this.f594j = Character.toLowerCase(c);
        this.f598n.mo818x(false);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c, int i) {
        if (this.f594j == c && this.f595k == i) {
            return this;
        }
        this.f594j = Character.toLowerCase(c);
        this.f595k = KeyEvent.normalizeMetaState(i);
        this.f598n.mo818x(false);
        return this;
    }

    public MenuItem setCheckable(boolean z) {
        int i = this.f608x;
        boolean z2 = z | (i & true);
        this.f608x = z2 ? 1 : 0;
        if (i != z2) {
            this.f598n.mo818x(false);
        }
        return this;
    }

    public MenuItem setChecked(boolean z) {
        if ((this.f608x & 4) != 0) {
            this.f598n.mo760I(this);
        } else {
            mo854q(z);
        }
        return this;
    }

    public MenuItem setContentDescription(CharSequence charSequence) {
        this.f601q = charSequence;
        this.f598n.mo818x(false);
        return this;
    }

    /* renamed from: setContentDescription  reason: collision with other method in class */
    public C4707b m41559setContentDescription(CharSequence charSequence) {
        this.f601q = charSequence;
        this.f598n.mo818x(false);
        return this;
    }

    public MenuItem setEnabled(boolean z) {
        this.f608x = z ? this.f608x | 16 : this.f608x & -17;
        this.f598n.mo818x(false);
        return this;
    }

    public MenuItem setIcon(int i) {
        this.f596l = null;
        this.f597m = i;
        this.f607w = true;
        this.f598n.mo818x(false);
        return this;
    }

    public MenuItem setIcon(Drawable drawable) {
        this.f597m = 0;
        this.f596l = drawable;
        this.f607w = true;
        this.f598n.mo818x(false);
        return this;
    }

    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f603s = colorStateList;
        this.f605u = true;
        this.f607w = true;
        this.f598n.mo818x(false);
        return this;
    }

    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f604t = mode;
        this.f606v = true;
        this.f607w = true;
        this.f598n.mo818x(false);
        return this;
    }

    public MenuItem setIntent(Intent intent) {
        this.f591g = intent;
        return this;
    }

    public MenuItem setNumericShortcut(char c) {
        if (this.f592h == c) {
            return this;
        }
        this.f592h = c;
        this.f598n.mo818x(false);
        return this;
    }

    public MenuItem setNumericShortcut(char c, int i) {
        if (this.f592h == c && this.f593i == i) {
            return this;
        }
        this.f592h = c;
        this.f593i = KeyEvent.normalizeMetaState(i);
        this.f598n.mo818x(false);
        return this;
    }

    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        this.f582B = onActionExpandListener;
        return this;
    }

    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f600p = onMenuItemClickListener;
        return this;
    }

    public MenuItem setShortcut(char c, char c2) {
        this.f592h = c;
        this.f594j = Character.toLowerCase(c2);
        this.f598n.mo818x(false);
        return this;
    }

    public MenuItem setShortcut(char c, char c2, int i, int i2) {
        this.f592h = c;
        this.f593i = KeyEvent.normalizeMetaState(i);
        this.f594j = Character.toLowerCase(c2);
        this.f595k = KeyEvent.normalizeMetaState(i2);
        this.f598n.mo818x(false);
        return this;
    }

    public void setShowAsAction(int i) {
        int i2 = i & 3;
        if (i2 == 0 || i2 == 1 || i2 == 2) {
            this.f609y = i;
            this.f598n.mo816v();
            return;
        }
        throw new IllegalArgumentException("SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive.");
    }

    public MenuItem setShowAsActionFlags(int i) {
        setShowAsAction(i);
        return this;
    }

    public MenuItem setTitle(int i) {
        setTitle((CharSequence) this.f598n.mo798n().getString(i));
        return this;
    }

    public MenuItem setTitle(CharSequence charSequence) {
        this.f589e = charSequence;
        this.f598n.mo818x(false);
        C0187r rVar = this.f599o;
        if (rVar != null) {
            rVar.mo764N(charSequence);
        }
        return this;
    }

    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f590f = charSequence;
        this.f598n.mo818x(false);
        return this;
    }

    public MenuItem setTooltipText(CharSequence charSequence) {
        this.f602r = charSequence;
        this.f598n.mo818x(false);
        return this;
    }

    /* renamed from: setTooltipText  reason: collision with other method in class */
    public C4707b m41560setTooltipText(CharSequence charSequence) {
        this.f602r = charSequence;
        this.f598n.mo818x(false);
        return this;
    }

    public MenuItem setVisible(boolean z) {
        if (mo875u(z)) {
            this.f598n.mo817w();
        }
        return this;
    }

    /* renamed from: t */
    public void mo873t(C0187r rVar) {
        this.f599o = rVar;
        rVar.setHeaderTitle(this.f589e);
    }

    public String toString() {
        CharSequence charSequence = this.f589e;
        if (charSequence != null) {
            return charSequence.toString();
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: u */
    public boolean mo875u(boolean z) {
        int i = this.f608x;
        int i2 = (z ? 0 : 8) | (i & -9);
        this.f608x = i2;
        return i != i2;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: v */
    public boolean mo876v() {
        return this.f598n.mo815u() && mo826f() != 0;
    }

    /* renamed from: w */
    public boolean mo877w() {
        return (this.f609y & 4) == 4;
    }
}
