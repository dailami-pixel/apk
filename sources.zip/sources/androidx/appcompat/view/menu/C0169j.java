package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ActionProvider;
import android.view.CollapsibleActionView;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.FrameLayout;
import java.lang.reflect.Method;
import p098d.p099a.p106g.C4591c;
import p098d.p120g.p124e.p125a.C4707b;
import p098d.p120g.p130j.C4747b;

/* renamed from: androidx.appcompat.view.menu.j */
public class C0169j extends C0153c implements MenuItem {

    /* renamed from: d */
    private final C4707b f612d;

    /* renamed from: e */
    private Method f613e;

    /* renamed from: androidx.appcompat.view.menu.j$a */
    private class C0170a extends C4747b {

        /* renamed from: c */
        final ActionProvider f614c;

        C0170a(Context context, ActionProvider actionProvider) {
            super(context);
            this.f614c = actionProvider;
        }

        /* renamed from: a */
        public boolean mo933a() {
            return this.f614c.hasSubMenu();
        }

        /* renamed from: c */
        public View mo934c() {
            return this.f614c.onCreateActionView();
        }

        /* renamed from: e */
        public boolean mo935e() {
            return this.f614c.onPerformDefaultAction();
        }

        /* renamed from: f */
        public void mo936f(SubMenu subMenu) {
            this.f614c.onPrepareSubMenu(C0169j.this.mo706d(subMenu));
        }
    }

    /* renamed from: androidx.appcompat.view.menu.j$b */
    private class C0171b extends C0170a implements ActionProvider.VisibilityListener {

        /* renamed from: e */
        private C4747b.C4749b f616e;

        C0171b(C0169j jVar, Context context, ActionProvider actionProvider) {
            super(context, actionProvider);
        }

        /* renamed from: b */
        public boolean mo937b() {
            return this.f614c.isVisible();
        }

        /* renamed from: d */
        public View mo938d(MenuItem menuItem) {
            return this.f614c.onCreateActionView(menuItem);
        }

        /* renamed from: g */
        public boolean mo939g() {
            return this.f614c.overridesItemVisibility();
        }

        /* renamed from: j */
        public void mo940j(C4747b.C4749b bVar) {
            this.f616e = bVar;
            this.f614c.setVisibilityListener(this);
        }

        public void onActionProviderVisibilityChanged(boolean z) {
            C4747b.C4749b bVar = this.f616e;
            if (bVar != null) {
                C0167i.this.f598n.mo817w();
            }
        }
    }

    /* renamed from: androidx.appcompat.view.menu.j$c */
    static class C0172c extends FrameLayout implements C4591c {

        /* renamed from: a */
        final CollapsibleActionView f617a;

        C0172c(View view) {
            super(view.getContext());
            this.f617a = (CollapsibleActionView) view;
            addView(view);
        }

        /* renamed from: d */
        public void mo942d() {
            this.f617a.onActionViewExpanded();
        }

        /* renamed from: g */
        public void mo943g() {
            this.f617a.onActionViewCollapsed();
        }
    }

    /* renamed from: androidx.appcompat.view.menu.j$d */
    private class C0173d implements MenuItem.OnActionExpandListener {

        /* renamed from: a */
        private final MenuItem.OnActionExpandListener f618a;

        C0173d(MenuItem.OnActionExpandListener onActionExpandListener) {
            this.f618a = onActionExpandListener;
        }

        public boolean onMenuItemActionCollapse(MenuItem menuItem) {
            return this.f618a.onMenuItemActionCollapse(C0169j.this.mo705c(menuItem));
        }

        public boolean onMenuItemActionExpand(MenuItem menuItem) {
            return this.f618a.onMenuItemActionExpand(C0169j.this.mo705c(menuItem));
        }
    }

    /* renamed from: androidx.appcompat.view.menu.j$e */
    private class C0174e implements MenuItem.OnMenuItemClickListener {

        /* renamed from: a */
        private final MenuItem.OnMenuItemClickListener f620a;

        C0174e(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
            this.f620a = onMenuItemClickListener;
        }

        public boolean onMenuItemClick(MenuItem menuItem) {
            return this.f620a.onMenuItemClick(C0169j.this.mo705c(menuItem));
        }
    }

    public C0169j(Context context, C4707b bVar) {
        super(context);
        if (bVar != null) {
            this.f612d = bVar;
            return;
        }
        throw new IllegalArgumentException("Wrapped Object can not be null.");
    }

    public boolean collapseActionView() {
        return this.f612d.collapseActionView();
    }

    public boolean expandActionView() {
        return this.f612d.expandActionView();
    }

    public ActionProvider getActionProvider() {
        C4747b b = this.f612d.mo635b();
        if (b instanceof C0170a) {
            return ((C0170a) b).f614c;
        }
        return null;
    }

    public View getActionView() {
        View actionView = this.f612d.getActionView();
        return actionView instanceof C0172c ? (View) ((C0172c) actionView).f617a : actionView;
    }

    public int getAlphabeticModifiers() {
        return this.f612d.getAlphabeticModifiers();
    }

    public char getAlphabeticShortcut() {
        return this.f612d.getAlphabeticShortcut();
    }

    public CharSequence getContentDescription() {
        return this.f612d.getContentDescription();
    }

    public int getGroupId() {
        return this.f612d.getGroupId();
    }

    public Drawable getIcon() {
        return this.f612d.getIcon();
    }

    public ColorStateList getIconTintList() {
        return this.f612d.getIconTintList();
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.f612d.getIconTintMode();
    }

    public Intent getIntent() {
        return this.f612d.getIntent();
    }

    public int getItemId() {
        return this.f612d.getItemId();
    }

    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return this.f612d.getMenuInfo();
    }

    public int getNumericModifiers() {
        return this.f612d.getNumericModifiers();
    }

    public char getNumericShortcut() {
        return this.f612d.getNumericShortcut();
    }

    public int getOrder() {
        return this.f612d.getOrder();
    }

    public SubMenu getSubMenu() {
        return mo706d(this.f612d.getSubMenu());
    }

    public CharSequence getTitle() {
        return this.f612d.getTitle();
    }

    public CharSequence getTitleCondensed() {
        return this.f612d.getTitleCondensed();
    }

    public CharSequence getTooltipText() {
        return this.f612d.getTooltipText();
    }

    /* renamed from: h */
    public void mo899h(boolean z) {
        try {
            if (this.f613e == null) {
                this.f613e = this.f612d.getClass().getDeclaredMethod("setExclusiveCheckable", new Class[]{Boolean.TYPE});
            }
            this.f613e.invoke(this.f612d, new Object[]{Boolean.valueOf(z)});
        } catch (Exception e) {
            Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e);
        }
    }

    public boolean hasSubMenu() {
        return this.f612d.hasSubMenu();
    }

    public boolean isActionViewExpanded() {
        return this.f612d.isActionViewExpanded();
    }

    public boolean isCheckable() {
        return this.f612d.isCheckable();
    }

    public boolean isChecked() {
        return this.f612d.isChecked();
    }

    public boolean isEnabled() {
        return this.f612d.isEnabled();
    }

    public boolean isVisible() {
        return this.f612d.isVisible();
    }

    public MenuItem setActionProvider(ActionProvider actionProvider) {
        C0171b bVar = new C0171b(this, this.f500a, actionProvider);
        C4707b bVar2 = this.f612d;
        if (actionProvider == null) {
            bVar = null;
        }
        bVar2.mo634a(bVar);
        return this;
    }

    public MenuItem setActionView(int i) {
        this.f612d.setActionView(i);
        View actionView = this.f612d.getActionView();
        if (actionView instanceof CollapsibleActionView) {
            this.f612d.setActionView((View) new C0172c(actionView));
        }
        return this;
    }

    public MenuItem setActionView(View view) {
        if (view instanceof CollapsibleActionView) {
            view = new C0172c(view);
        }
        this.f612d.setActionView(view);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c) {
        this.f612d.setAlphabeticShortcut(c);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c, int i) {
        this.f612d.setAlphabeticShortcut(c, i);
        return this;
    }

    public MenuItem setCheckable(boolean z) {
        this.f612d.setCheckable(z);
        return this;
    }

    public MenuItem setChecked(boolean z) {
        this.f612d.setChecked(z);
        return this;
    }

    public MenuItem setContentDescription(CharSequence charSequence) {
        this.f612d.setContentDescription(charSequence);
        return this;
    }

    public MenuItem setEnabled(boolean z) {
        this.f612d.setEnabled(z);
        return this;
    }

    public MenuItem setIcon(int i) {
        this.f612d.setIcon(i);
        return this;
    }

    public MenuItem setIcon(Drawable drawable) {
        this.f612d.setIcon(drawable);
        return this;
    }

    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f612d.setIconTintList(colorStateList);
        return this;
    }

    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f612d.setIconTintMode(mode);
        return this;
    }

    public MenuItem setIntent(Intent intent) {
        this.f612d.setIntent(intent);
        return this;
    }

    public MenuItem setNumericShortcut(char c) {
        this.f612d.setNumericShortcut(c);
        return this;
    }

    public MenuItem setNumericShortcut(char c, int i) {
        this.f612d.setNumericShortcut(c, i);
        return this;
    }

    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        this.f612d.setOnActionExpandListener(onActionExpandListener != null ? new C0173d(onActionExpandListener) : null);
        return this;
    }

    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f612d.setOnMenuItemClickListener(onMenuItemClickListener != null ? new C0174e(onMenuItemClickListener) : null);
        return this;
    }

    public MenuItem setShortcut(char c, char c2) {
        this.f612d.setShortcut(c, c2);
        return this;
    }

    public MenuItem setShortcut(char c, char c2, int i, int i2) {
        this.f612d.setShortcut(c, c2, i, i2);
        return this;
    }

    public void setShowAsAction(int i) {
        this.f612d.setShowAsAction(i);
    }

    public MenuItem setShowAsActionFlags(int i) {
        this.f612d.setShowAsActionFlags(i);
        return this;
    }

    public MenuItem setTitle(int i) {
        this.f612d.setTitle(i);
        return this;
    }

    public MenuItem setTitle(CharSequence charSequence) {
        this.f612d.setTitle(charSequence);
        return this;
    }

    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f612d.setTitleCondensed(charSequence);
        return this;
    }

    public MenuItem setTooltipText(CharSequence charSequence) {
        this.f612d.setTooltipText(charSequence);
        return this;
    }

    public MenuItem setVisible(boolean z) {
        return this.f612d.setVisible(z);
    }
}
