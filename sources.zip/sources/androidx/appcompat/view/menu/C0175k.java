package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;

/* renamed from: androidx.appcompat.view.menu.k */
abstract class C0175k implements C0183p, C0178m, AdapterView.OnItemClickListener {

    /* renamed from: a */
    private Rect f622a;

    C0175k() {
    }

    /* renamed from: o */
    protected static int m765o(ListAdapter listAdapter, ViewGroup viewGroup, Context context, int i) {
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(0, 0);
        C0162f fVar = (C0162f) listAdapter;
        int count = fVar.getCount();
        FrameLayout frameLayout = null;
        View view = null;
        int i2 = 0;
        int i3 = 0;
        for (int i4 = 0; i4 < count; i4++) {
            int itemViewType = fVar.getItemViewType(i4);
            if (itemViewType != i3) {
                view = null;
                i3 = itemViewType;
            }
            if (frameLayout == null) {
                frameLayout = new FrameLayout(context);
            }
            view = fVar.getView(i4, view, frameLayout);
            view.measure(makeMeasureSpec, makeMeasureSpec2);
            int measuredWidth = view.getMeasuredWidth();
            if (measuredWidth >= i) {
                return i;
            }
            if (measuredWidth > i2) {
                i2 = measuredWidth;
            }
        }
        return i2;
    }

    /* renamed from: x */
    protected static boolean m766x(C0163g gVar) {
        int size = gVar.size();
        for (int i = 0; i < size; i++) {
            MenuItem item = gVar.getItem(i);
            if (item.isVisible() && item.getIcon() != null) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: e */
    public boolean mo693e(C0163g gVar, C0167i iVar) {
        return false;
    }

    /* renamed from: f */
    public boolean mo694f(C0163g gVar, C0167i iVar) {
        return false;
    }

    public int getId() {
        return 0;
    }

    /* renamed from: h */
    public void mo697h(Context context, C0163g gVar) {
    }

    /* renamed from: m */
    public abstract void mo716m(C0163g gVar);

    /* renamed from: n */
    public Rect mo947n() {
        return this.f622a;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        ListAdapter listAdapter = (ListAdapter) adapterView.getAdapter();
        (listAdapter instanceof HeaderViewListAdapter ? (C0162f) ((HeaderViewListAdapter) listAdapter).getWrappedAdapter() : (C0162f) listAdapter).f547a.mo820z((MenuItem) listAdapter.getItem(i), this, (this instanceof C0154d) ^ true ? 0 : 4);
    }

    /* renamed from: p */
    public abstract void mo719p(View view);

    /* renamed from: q */
    public void mo949q(Rect rect) {
        this.f622a = rect;
    }

    /* renamed from: r */
    public abstract void mo720r(boolean z);

    /* renamed from: s */
    public abstract void mo721s(int i);

    /* renamed from: t */
    public abstract void mo723t(int i);

    /* renamed from: u */
    public abstract void mo724u(PopupWindow.OnDismissListener onDismissListener);

    /* renamed from: v */
    public abstract void mo725v(boolean z);

    /* renamed from: w */
    public abstract void mo726w(int i);
}
