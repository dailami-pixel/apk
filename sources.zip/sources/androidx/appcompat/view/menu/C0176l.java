package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.view.Gravity;
import android.view.View;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.C0178m;
import p098d.p120g.p130j.C4761m;

/* renamed from: androidx.appcompat.view.menu.l */
public class C0176l {

    /* renamed from: a */
    private final Context f623a;

    /* renamed from: b */
    private final C0163g f624b;

    /* renamed from: c */
    private final boolean f625c;

    /* renamed from: d */
    private final int f626d;

    /* renamed from: e */
    private final int f627e;

    /* renamed from: f */
    private View f628f;

    /* renamed from: g */
    private int f629g = 8388611;

    /* renamed from: h */
    private boolean f630h;

    /* renamed from: i */
    private C0178m.C0179a f631i;

    /* renamed from: j */
    private C0175k f632j;

    /* renamed from: k */
    private PopupWindow.OnDismissListener f633k;

    /* renamed from: l */
    private final PopupWindow.OnDismissListener f634l = new C0177a();

    /* renamed from: androidx.appcompat.view.menu.l$a */
    class C0177a implements PopupWindow.OnDismissListener {
        C0177a() {
        }

        public void onDismiss() {
            C0176l.this.mo953d();
        }
    }

    public C0176l(Context context, C0163g gVar, View view, boolean z, int i, int i2) {
        this.f623a = context;
        this.f624b = gVar;
        this.f628f = view;
        this.f625c = z;
        this.f626d = i;
        this.f627e = i2;
    }

    /* renamed from: j */
    private void m780j(int i, int i2, boolean z, boolean z2) {
        C0175k b = mo951b();
        b.mo725v(z2);
        if (z) {
            int i3 = this.f629g;
            View view = this.f628f;
            int i4 = C4761m.f17241f;
            if ((Gravity.getAbsoluteGravity(i3, view.getLayoutDirection()) & 7) == 5) {
                i -= this.f628f.getWidth();
            }
            b.mo723t(i);
            b.mo726w(i2);
            int i5 = (int) ((this.f623a.getResources().getDisplayMetrics().density * 48.0f) / 2.0f);
            b.mo949q(new Rect(i - i5, i2 - i5, i + i5, i2 + i5));
        }
        b.show();
    }

    /* renamed from: a */
    public void mo950a() {
        if (mo952c()) {
            this.f632j.dismiss();
        }
    }

    /* JADX WARNING: type inference failed for: r0v9, types: [androidx.appcompat.view.menu.m, androidx.appcompat.view.menu.k] */
    /* JADX WARNING: type inference failed for: r7v1, types: [androidx.appcompat.view.menu.q] */
    /* JADX WARNING: type inference failed for: r1v13, types: [androidx.appcompat.view.menu.d] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public androidx.appcompat.view.menu.C0175k mo951b() {
        /*
            r14 = this;
            androidx.appcompat.view.menu.k r0 = r14.f632j
            if (r0 != 0) goto L_0x0079
            android.content.Context r0 = r14.f623a
            java.lang.String r1 = "window"
            java.lang.Object r0 = r0.getSystemService(r1)
            android.view.WindowManager r0 = (android.view.WindowManager) r0
            android.view.Display r0 = r0.getDefaultDisplay()
            android.graphics.Point r1 = new android.graphics.Point
            r1.<init>()
            r0.getRealSize(r1)
            int r0 = r1.x
            int r1 = r1.y
            int r0 = java.lang.Math.min(r0, r1)
            android.content.Context r1 = r14.f623a
            android.content.res.Resources r1 = r1.getResources()
            r2 = 2131165206(0x7f070016, float:1.7944623E38)
            int r1 = r1.getDimensionPixelSize(r2)
            if (r0 < r1) goto L_0x0033
            r0 = 1
            goto L_0x0034
        L_0x0033:
            r0 = 0
        L_0x0034:
            if (r0 == 0) goto L_0x0047
            androidx.appcompat.view.menu.d r0 = new androidx.appcompat.view.menu.d
            android.content.Context r2 = r14.f623a
            android.view.View r3 = r14.f628f
            int r4 = r14.f626d
            int r5 = r14.f627e
            boolean r6 = r14.f625c
            r1 = r0
            r1.<init>(r2, r3, r4, r5, r6)
            goto L_0x0059
        L_0x0047:
            androidx.appcompat.view.menu.q r0 = new androidx.appcompat.view.menu.q
            android.content.Context r8 = r14.f623a
            androidx.appcompat.view.menu.g r9 = r14.f624b
            android.view.View r10 = r14.f628f
            int r11 = r14.f626d
            int r12 = r14.f627e
            boolean r13 = r14.f625c
            r7 = r0
            r7.<init>(r8, r9, r10, r11, r12, r13)
        L_0x0059:
            androidx.appcompat.view.menu.g r1 = r14.f624b
            r0.mo716m(r1)
            android.widget.PopupWindow$OnDismissListener r1 = r14.f634l
            r0.mo724u(r1)
            android.view.View r1 = r14.f628f
            r0.mo719p(r1)
            androidx.appcompat.view.menu.m$a r1 = r14.f631i
            r0.mo695g(r1)
            boolean r1 = r14.f630h
            r0.mo720r(r1)
            int r1 = r14.f629g
            r0.mo721s(r1)
            r14.f632j = r0
        L_0x0079:
            androidx.appcompat.view.menu.k r0 = r14.f632j
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.C0176l.mo951b():androidx.appcompat.view.menu.k");
    }

    /* renamed from: c */
    public boolean mo952c() {
        C0175k kVar = this.f632j;
        return kVar != null && kVar.mo710a();
    }

    /* access modifiers changed from: protected */
    /* renamed from: d */
    public void mo953d() {
        this.f632j = null;
        PopupWindow.OnDismissListener onDismissListener = this.f633k;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    /* renamed from: e */
    public void mo954e(View view) {
        this.f628f = view;
    }

    /* renamed from: f */
    public void mo955f(boolean z) {
        this.f630h = z;
        C0175k kVar = this.f632j;
        if (kVar != null) {
            kVar.mo720r(z);
        }
    }

    /* renamed from: g */
    public void mo956g(int i) {
        this.f629g = i;
    }

    /* renamed from: h */
    public void mo957h(PopupWindow.OnDismissListener onDismissListener) {
        this.f633k = onDismissListener;
    }

    /* renamed from: i */
    public void mo958i(C0178m.C0179a aVar) {
        this.f631i = aVar;
        C0175k kVar = this.f632j;
        if (kVar != null) {
            kVar.mo695g(aVar);
        }
    }

    /* renamed from: k */
    public boolean mo959k() {
        if (mo952c()) {
            return true;
        }
        if (this.f628f == null) {
            return false;
        }
        m780j(0, 0, false, false);
        return true;
    }

    /* renamed from: l */
    public boolean mo960l(int i, int i2) {
        if (mo952c()) {
            return true;
        }
        if (this.f628f == null) {
            return false;
        }
        m780j(i, i2, true, true);
        return true;
    }
}
