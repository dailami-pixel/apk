package androidx.appcompat.view.menu;

import android.content.Context;
import android.os.Parcelable;

/* renamed from: androidx.appcompat.view.menu.m */
public interface C0178m {

    /* renamed from: androidx.appcompat.view.menu.m$a */
    public interface C0179a {
        /* renamed from: b */
        void mo509b(C0163g gVar, boolean z);

        /* renamed from: c */
        boolean mo510c(C0163g gVar);
    }

    /* renamed from: b */
    void mo691b(C0163g gVar, boolean z);

    /* renamed from: c */
    void mo692c(boolean z);

    /* renamed from: d */
    boolean mo711d();

    /* renamed from: e */
    boolean mo693e(C0163g gVar, C0167i iVar);

    /* renamed from: f */
    boolean mo694f(C0163g gVar, C0167i iVar);

    /* renamed from: g */
    void mo695g(C0179a aVar);

    int getId();

    /* renamed from: h */
    void mo697h(Context context, C0163g gVar);

    /* renamed from: i */
    void mo713i(Parcelable parcelable);

    /* renamed from: k */
    boolean mo699k(C0187r rVar);

    /* renamed from: l */
    Parcelable mo715l();
}
