package androidx.appcompat.view.menu;

/* renamed from: androidx.appcompat.view.menu.n */
public interface C0180n {

    /* renamed from: androidx.appcompat.view.menu.n$a */
    public interface C0181a {
        /* renamed from: b */
        C0167i mo608b();

        /* renamed from: e */
        boolean mo611e();

        /* renamed from: f */
        void mo612f(C0167i iVar, int i);
    }

    /* renamed from: c */
    void mo625c(C0163g gVar);
}
