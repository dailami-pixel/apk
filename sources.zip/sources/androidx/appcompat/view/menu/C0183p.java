package androidx.appcompat.view.menu;

import android.widget.ListView;

/* renamed from: androidx.appcompat.view.menu.p */
public interface C0183p {
    /* renamed from: a */
    boolean mo710a();

    void dismiss();

    /* renamed from: j */
    ListView mo714j();

    void show();
}
