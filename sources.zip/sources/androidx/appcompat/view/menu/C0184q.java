package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.C0178m;
import androidx.appcompat.widget.C0294u;
import com.vidio.android.p195tv.R;
import p098d.p120g.p130j.C4761m;

/* renamed from: androidx.appcompat.view.menu.q */
final class C0184q extends C0175k implements PopupWindow.OnDismissListener, AdapterView.OnItemClickListener, C0178m, View.OnKeyListener {

    /* renamed from: b */
    private final Context f637b;

    /* renamed from: c */
    private final C0163g f638c;

    /* renamed from: d */
    private final C0162f f639d;

    /* renamed from: e */
    private final boolean f640e;

    /* renamed from: f */
    private final int f641f;

    /* renamed from: g */
    private final int f642g;

    /* renamed from: h */
    private final int f643h;

    /* renamed from: i */
    final C0294u f644i;

    /* renamed from: j */
    final ViewTreeObserver.OnGlobalLayoutListener f645j = new C0185a();

    /* renamed from: k */
    private final View.OnAttachStateChangeListener f646k = new C0186b();

    /* renamed from: l */
    private PopupWindow.OnDismissListener f647l;

    /* renamed from: m */
    private View f648m;

    /* renamed from: n */
    View f649n;

    /* renamed from: o */
    private C0178m.C0179a f650o;

    /* renamed from: p */
    ViewTreeObserver f651p;

    /* renamed from: q */
    private boolean f652q;

    /* renamed from: r */
    private boolean f653r;

    /* renamed from: s */
    private int f654s;

    /* renamed from: t */
    private int f655t = 0;

    /* renamed from: u */
    private boolean f656u;

    /* renamed from: androidx.appcompat.view.menu.q$a */
    class C0185a implements ViewTreeObserver.OnGlobalLayoutListener {
        C0185a() {
        }

        public void onGlobalLayout() {
            if (C0184q.this.mo710a() && !C0184q.this.f644i.mo1408v()) {
                View view = C0184q.this.f649n;
                if (view == null || !view.isShown()) {
                    C0184q.this.dismiss();
                } else {
                    C0184q.this.f644i.show();
                }
            }
        }
    }

    /* renamed from: androidx.appcompat.view.menu.q$b */
    class C0186b implements View.OnAttachStateChangeListener {
        C0186b() {
        }

        public void onViewAttachedToWindow(View view) {
        }

        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = C0184q.this.f651p;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    C0184q.this.f651p = view.getViewTreeObserver();
                }
                C0184q qVar = C0184q.this;
                qVar.f651p.removeGlobalOnLayoutListener(qVar.f645j);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    public C0184q(Context context, C0163g gVar, View view, int i, int i2, boolean z) {
        this.f637b = context;
        this.f638c = gVar;
        this.f640e = z;
        this.f639d = new C0162f(gVar, LayoutInflater.from(context), z, R.layout.abc_popup_menu_item_layout);
        this.f642g = i;
        this.f643h = i2;
        Resources resources = context.getResources();
        this.f641f = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
        this.f648m = view;
        this.f644i = new C0294u(context, (AttributeSet) null, i, i2);
        gVar.mo780c(this, context);
    }

    /* renamed from: a */
    public boolean mo710a() {
        return !this.f652q && this.f644i.mo710a();
    }

    /* renamed from: b */
    public void mo691b(C0163g gVar, boolean z) {
        if (gVar == this.f638c) {
            dismiss();
            C0178m.C0179a aVar = this.f650o;
            if (aVar != null) {
                aVar.mo509b(gVar, z);
            }
        }
    }

    /* renamed from: c */
    public void mo692c(boolean z) {
        this.f653r = false;
        C0162f fVar = this.f639d;
        if (fVar != null) {
            fVar.notifyDataSetChanged();
        }
    }

    /* renamed from: d */
    public boolean mo711d() {
        return false;
    }

    public void dismiss() {
        if (mo710a()) {
            this.f644i.dismiss();
        }
    }

    /* renamed from: g */
    public void mo695g(C0178m.C0179a aVar) {
        this.f650o = aVar;
    }

    /* renamed from: i */
    public void mo713i(Parcelable parcelable) {
    }

    /* renamed from: j */
    public ListView mo714j() {
        return this.f644i.mo714j();
    }

    /* renamed from: k */
    public boolean mo699k(C0187r rVar) {
        if (rVar.hasVisibleItems()) {
            C0176l lVar = new C0176l(this.f637b, rVar, this.f649n, this.f640e, this.f642g, this.f643h);
            lVar.mo958i(this.f650o);
            lVar.mo955f(C0175k.m766x(rVar));
            lVar.mo957h(this.f647l);
            this.f647l = null;
            this.f638c.mo785e(false);
            int b = this.f644i.mo1396b();
            int n = this.f644i.mo1401n();
            int i = this.f655t;
            View view = this.f648m;
            int i2 = C4761m.f17241f;
            if ((Gravity.getAbsoluteGravity(i, view.getLayoutDirection()) & 7) == 5) {
                b += this.f648m.getWidth();
            }
            if (lVar.mo960l(b, n)) {
                C0178m.C0179a aVar = this.f650o;
                if (aVar == null) {
                    return true;
                }
                aVar.mo510c(rVar);
                return true;
            }
        }
        return false;
    }

    /* renamed from: l */
    public Parcelable mo715l() {
        return null;
    }

    /* renamed from: m */
    public void mo716m(C0163g gVar) {
    }

    public void onDismiss() {
        this.f652q = true;
        this.f638c.mo785e(true);
        ViewTreeObserver viewTreeObserver = this.f651p;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.f651p = this.f649n.getViewTreeObserver();
            }
            this.f651p.removeGlobalOnLayoutListener(this.f645j);
            this.f651p = null;
        }
        this.f649n.removeOnAttachStateChangeListener(this.f646k);
        PopupWindow.OnDismissListener onDismissListener = this.f647l;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    /* renamed from: p */
    public void mo719p(View view) {
        this.f648m = view;
    }

    /* renamed from: r */
    public void mo720r(boolean z) {
        this.f639d.mo747d(z);
    }

    /* renamed from: s */
    public void mo721s(int i) {
        this.f655t = i;
    }

    /* JADX WARNING: Removed duplicated region for block: B:27:0x00c5 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00c6  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void show() {
        /*
            r7 = this;
            boolean r0 = r7.mo710a()
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x000b
        L_0x0008:
            r1 = 1
            goto L_0x00c3
        L_0x000b:
            boolean r0 = r7.f652q
            if (r0 != 0) goto L_0x00c3
            android.view.View r0 = r7.f648m
            if (r0 != 0) goto L_0x0015
            goto L_0x00c3
        L_0x0015:
            r7.f649n = r0
            androidx.appcompat.widget.u r0 = r7.f644i
            r0.mo1392D(r7)
            androidx.appcompat.widget.u r0 = r7.f644i
            r0.mo1393E(r7)
            androidx.appcompat.widget.u r0 = r7.f644i
            r0.mo1391C(r2)
            android.view.View r0 = r7.f649n
            android.view.ViewTreeObserver r3 = r7.f651p
            if (r3 != 0) goto L_0x002e
            r3 = 1
            goto L_0x002f
        L_0x002e:
            r3 = 0
        L_0x002f:
            android.view.ViewTreeObserver r4 = r0.getViewTreeObserver()
            r7.f651p = r4
            if (r3 == 0) goto L_0x003c
            android.view.ViewTreeObserver$OnGlobalLayoutListener r3 = r7.f645j
            r4.addOnGlobalLayoutListener(r3)
        L_0x003c:
            android.view.View$OnAttachStateChangeListener r3 = r7.f646k
            r0.addOnAttachStateChangeListener(r3)
            androidx.appcompat.widget.u r3 = r7.f644i
            r3.mo1409w(r0)
            androidx.appcompat.widget.u r0 = r7.f644i
            int r3 = r7.f655t
            r0.mo1412z(r3)
            boolean r0 = r7.f653r
            r3 = 0
            if (r0 != 0) goto L_0x0060
            androidx.appcompat.view.menu.f r0 = r7.f639d
            android.content.Context r4 = r7.f637b
            int r5 = r7.f641f
            int r0 = androidx.appcompat.view.menu.C0175k.m765o(r0, r3, r4, r5)
            r7.f654s = r0
            r7.f653r = r2
        L_0x0060:
            androidx.appcompat.widget.u r0 = r7.f644i
            int r4 = r7.f654s
            r0.mo1411y(r4)
            androidx.appcompat.widget.u r0 = r7.f644i
            r4 = 2
            r0.mo1390B(r4)
            androidx.appcompat.widget.u r0 = r7.f644i
            android.graphics.Rect r4 = r7.mo947n()
            r0.mo1389A(r4)
            androidx.appcompat.widget.u r0 = r7.f644i
            r0.show()
            androidx.appcompat.widget.u r0 = r7.f644i
            android.widget.ListView r0 = r0.mo714j()
            r0.setOnKeyListener(r7)
            boolean r4 = r7.f656u
            if (r4 == 0) goto L_0x00b5
            androidx.appcompat.view.menu.g r4 = r7.f638c
            java.lang.CharSequence r4 = r4.f566n
            if (r4 == 0) goto L_0x00b5
            android.content.Context r4 = r7.f637b
            android.view.LayoutInflater r4 = android.view.LayoutInflater.from(r4)
            r5 = 2131558418(0x7f0d0012, float:1.8742151E38)
            android.view.View r4 = r4.inflate(r5, r0, r1)
            android.widget.FrameLayout r4 = (android.widget.FrameLayout) r4
            r5 = 16908310(0x1020016, float:2.387729E-38)
            android.view.View r5 = r4.findViewById(r5)
            android.widget.TextView r5 = (android.widget.TextView) r5
            if (r5 == 0) goto L_0x00af
            androidx.appcompat.view.menu.g r6 = r7.f638c
            java.lang.CharSequence r6 = r6.f566n
            r5.setText(r6)
        L_0x00af:
            r4.setEnabled(r1)
            r0.addHeaderView(r4, r3, r1)
        L_0x00b5:
            androidx.appcompat.widget.u r0 = r7.f644i
            androidx.appcompat.view.menu.f r1 = r7.f639d
            r0.mo1304o(r1)
            androidx.appcompat.widget.u r0 = r7.f644i
            r0.show()
            goto L_0x0008
        L_0x00c3:
            if (r1 == 0) goto L_0x00c6
            return
        L_0x00c6:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "StandardMenuPopup cannot be used without an anchor"
            r0.<init>(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.C0184q.show():void");
    }

    /* renamed from: t */
    public void mo723t(int i) {
        this.f644i.mo1397d(i);
    }

    /* renamed from: u */
    public void mo724u(PopupWindow.OnDismissListener onDismissListener) {
        this.f647l = onDismissListener;
    }

    /* renamed from: v */
    public void mo725v(boolean z) {
        this.f656u = z;
    }

    /* renamed from: w */
    public void mo726w(int i) {
        this.f644i.mo1400k(i);
    }
}
