package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import androidx.appcompat.view.menu.C0163g;

/* renamed from: androidx.appcompat.view.menu.r */
public class C0187r extends C0163g implements SubMenu {

    /* renamed from: A */
    private C0167i f659A;

    /* renamed from: z */
    private C0163g f660z;

    public C0187r(Context context, C0163g gVar, C0167i iVar) {
        super(context);
        this.f660z = gVar;
        this.f659A = iVar;
    }

    /* renamed from: G */
    public void mo758G(C0163g.C0164a aVar) {
        this.f660z.mo758G(aVar);
    }

    /* renamed from: S */
    public Menu mo991S() {
        return this.f660z;
    }

    /* renamed from: f */
    public boolean mo786f(C0167i iVar) {
        return this.f660z.mo786f(iVar);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public boolean mo788g(C0163g gVar, MenuItem menuItem) {
        return super.mo788g(gVar, menuItem) || this.f660z.mo788g(gVar, menuItem);
    }

    public MenuItem getItem() {
        return this.f659A;
    }

    /* renamed from: h */
    public boolean mo790h(C0167i iVar) {
        return this.f660z.mo790h(iVar);
    }

    /* renamed from: m */
    public String mo797m() {
        C0167i iVar = this.f659A;
        int itemId = iVar != null ? iVar.getItemId() : 0;
        if (itemId == 0) {
            return null;
        }
        return "android:menu:actionviewstates" + ":" + itemId;
    }

    /* renamed from: q */
    public C0163g mo803q() {
        return this.f660z.mo803q();
    }

    /* renamed from: s */
    public boolean mo807s() {
        return this.f660z.mo807s();
    }

    public void setGroupDividerEnabled(boolean z) {
        this.f660z.setGroupDividerEnabled(z);
    }

    public SubMenu setHeaderIcon(int i) {
        mo761J(i);
        return this;
    }

    public SubMenu setHeaderIcon(Drawable drawable) {
        mo762K(drawable);
        return this;
    }

    public SubMenu setHeaderTitle(int i) {
        mo763M(i);
        return this;
    }

    public SubMenu setHeaderTitle(CharSequence charSequence) {
        mo764N(charSequence);
        return this;
    }

    public SubMenu setHeaderView(View view) {
        mo765O(view);
        return this;
    }

    public SubMenu setIcon(int i) {
        this.f659A.setIcon(i);
        return this;
    }

    public SubMenu setIcon(Drawable drawable) {
        this.f659A.setIcon(drawable);
        return this;
    }

    public void setQwertyMode(boolean z) {
        this.f660z.setQwertyMode(z);
    }

    /* renamed from: t */
    public boolean mo814t() {
        return this.f660z.mo814t();
    }

    /* renamed from: u */
    public boolean mo815u() {
        return this.f660z.mo815u();
    }
}
