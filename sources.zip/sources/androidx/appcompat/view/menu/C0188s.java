package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import p098d.p120g.p124e.p125a.C4708c;

/* renamed from: androidx.appcompat.view.menu.s */
class C0188s extends C0182o implements SubMenu {

    /* renamed from: e */
    private final C4708c f661e;

    C0188s(Context context, C4708c cVar) {
        super(context, cVar);
        this.f661e = cVar;
    }

    public void clearHeader() {
        this.f661e.clearHeader();
    }

    public MenuItem getItem() {
        return mo705c(this.f661e.getItem());
    }

    public SubMenu setHeaderIcon(int i) {
        this.f661e.setHeaderIcon(i);
        return this;
    }

    public SubMenu setHeaderIcon(Drawable drawable) {
        this.f661e.setHeaderIcon(drawable);
        return this;
    }

    public SubMenu setHeaderTitle(int i) {
        this.f661e.setHeaderTitle(i);
        return this;
    }

    public SubMenu setHeaderTitle(CharSequence charSequence) {
        this.f661e.setHeaderTitle(charSequence);
        return this;
    }

    public SubMenu setHeaderView(View view) {
        this.f661e.setHeaderView(view);
        return this;
    }

    public SubMenu setIcon(int i) {
        this.f661e.setIcon(i);
        return this;
    }

    public SubMenu setIcon(Drawable drawable) {
        this.f661e.setIcon(drawable);
        return this;
    }
}
