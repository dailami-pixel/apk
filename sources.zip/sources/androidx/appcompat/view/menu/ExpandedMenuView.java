package androidx.appcompat.view.menu;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.appcompat.view.menu.C0163g;
import androidx.appcompat.widget.C0259e0;

public final class ExpandedMenuView extends ListView implements C0163g.C0165b, C0180n, AdapterView.OnItemClickListener {

    /* renamed from: a */
    private static final int[] f456a = {16842964, 16843049};

    /* renamed from: b */
    private C0163g f457b;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842868);
    }

    public ExpandedMenuView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        C0259e0 v = C0259e0.m1181v(context, attributeSet, f456a, i, 0);
        if (v.mo1608s(0)) {
            setBackgroundDrawable(v.mo1596g(0));
        }
        if (v.mo1608s(1)) {
            setDivider(v.mo1596g(1));
        }
        v.mo1609w();
    }

    /* renamed from: a */
    public boolean mo624a(C0167i iVar) {
        return this.f457b.mo820z(iVar, (C0178m) null, 0);
    }

    /* renamed from: c */
    public void mo625c(C0163g gVar) {
        this.f457b = gVar;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        mo624a((C0167i) getAdapter().getItem(i));
    }
}
