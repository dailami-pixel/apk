package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.view.menu.C0180n;
import androidx.appcompat.widget.C0259e0;
import com.vidio.android.p195tv.R;
import p098d.p099a.C4568b;
import p098d.p120g.p130j.C4761m;

public class ListMenuItemView extends LinearLayout implements C0180n.C0181a, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: a */
    private C0167i f458a;

    /* renamed from: b */
    private ImageView f459b;

    /* renamed from: c */
    private RadioButton f460c;

    /* renamed from: d */
    private TextView f461d;

    /* renamed from: e */
    private CheckBox f462e;

    /* renamed from: f */
    private TextView f463f;

    /* renamed from: g */
    private ImageView f464g;

    /* renamed from: h */
    private ImageView f465h;

    /* renamed from: i */
    private LinearLayout f466i;

    /* renamed from: j */
    private Drawable f467j;

    /* renamed from: k */
    private int f468k;

    /* renamed from: l */
    private Context f469l;

    /* renamed from: m */
    private boolean f470m;

    /* renamed from: n */
    private Drawable f471n;

    /* renamed from: o */
    private boolean f472o;

    /* renamed from: p */
    private LayoutInflater f473p;

    /* renamed from: q */
    private boolean f474q;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.listMenuViewStyle);
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        C0259e0 v = C0259e0.m1181v(getContext(), attributeSet, C4568b.f16471s, i, 0);
        this.f467j = v.mo1596g(5);
        this.f468k = v.mo1603n(1, -1);
        this.f470m = v.mo1590a(7, false);
        this.f469l = context;
        this.f471n = v.mo1596g(8);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes((AttributeSet) null, new int[]{16843049}, R.attr.dropDownListViewStyle, 0);
        this.f472o = obtainStyledAttributes.hasValue(0);
        v.mo1609w();
        obtainStyledAttributes.recycle();
    }

    /* renamed from: a */
    private LayoutInflater m613a() {
        if (this.f473p == null) {
            this.f473p = LayoutInflater.from(getContext());
        }
        return this.f473p;
    }

    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f465h;
        if (imageView != null && imageView.getVisibility() == 0) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f465h.getLayoutParams();
            rect.top = this.f465h.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
        }
    }

    /* renamed from: b */
    public C0167i mo608b() {
        return this.f458a;
    }

    /* renamed from: c */
    public void mo629c(boolean z) {
        this.f474q = z;
        this.f470m = z;
    }

    /* renamed from: d */
    public void mo630d(boolean z) {
        ImageView imageView = this.f465h;
        if (imageView != null) {
            imageView.setVisibility((this.f472o || !z) ? 8 : 0);
        }
    }

    /* renamed from: e */
    public boolean mo611e() {
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x0051  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x0074  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0098  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00b6  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x00ef  */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x0110  */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x0116  */
    /* renamed from: f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo612f(androidx.appcompat.view.menu.C0167i r6, int r7) {
        /*
            r5 = this;
            r5.f458a = r6
            boolean r7 = r6.isVisible()
            r0 = 0
            r1 = 8
            if (r7 == 0) goto L_0x000d
            r7 = 0
            goto L_0x000f
        L_0x000d:
            r7 = 8
        L_0x000f:
            r5.setVisibility(r7)
            java.lang.CharSequence r7 = r6.mo840h(r5)
            if (r7 == 0) goto L_0x0029
            android.widget.TextView r2 = r5.f461d
            r2.setText(r7)
            android.widget.TextView r7 = r5.f461d
            int r7 = r7.getVisibility()
            if (r7 == 0) goto L_0x0038
            android.widget.TextView r7 = r5.f461d
            r2 = 0
            goto L_0x0035
        L_0x0029:
            android.widget.TextView r7 = r5.f461d
            int r7 = r7.getVisibility()
            if (r7 == r1) goto L_0x0038
            android.widget.TextView r7 = r5.f461d
            r2 = 8
        L_0x0035:
            r7.setVisibility(r2)
        L_0x0038:
            boolean r7 = r6.isCheckable()
            if (r7 != 0) goto L_0x0048
            android.widget.RadioButton r2 = r5.f460c
            if (r2 != 0) goto L_0x0048
            android.widget.CheckBox r2 = r5.f462e
            if (r2 != 0) goto L_0x0048
            goto L_0x00c4
        L_0x0048:
            androidx.appcompat.view.menu.i r2 = r5.f458a
            boolean r2 = r2.mo849l()
            r3 = -1
            if (r2 == 0) goto L_0x0074
            android.widget.RadioButton r2 = r5.f460c
            if (r2 != 0) goto L_0x006f
            android.view.LayoutInflater r2 = r5.m613a()
            r4 = 2131558417(0x7f0d0011, float:1.874215E38)
            android.view.View r2 = r2.inflate(r4, r5, r0)
            android.widget.RadioButton r2 = (android.widget.RadioButton) r2
            r5.f460c = r2
            android.widget.LinearLayout r4 = r5.f466i
            if (r4 == 0) goto L_0x006c
            r4.addView(r2, r3)
            goto L_0x006f
        L_0x006c:
            r5.addView(r2, r3)
        L_0x006f:
            android.widget.RadioButton r2 = r5.f460c
            android.widget.CheckBox r3 = r5.f462e
            goto L_0x0096
        L_0x0074:
            android.widget.CheckBox r2 = r5.f462e
            if (r2 != 0) goto L_0x0092
            android.view.LayoutInflater r2 = r5.m613a()
            r4 = 2131558414(0x7f0d000e, float:1.8742143E38)
            android.view.View r2 = r2.inflate(r4, r5, r0)
            android.widget.CheckBox r2 = (android.widget.CheckBox) r2
            r5.f462e = r2
            android.widget.LinearLayout r4 = r5.f466i
            if (r4 == 0) goto L_0x008f
            r4.addView(r2, r3)
            goto L_0x0092
        L_0x008f:
            r5.addView(r2, r3)
        L_0x0092:
            android.widget.CheckBox r2 = r5.f462e
            android.widget.RadioButton r3 = r5.f460c
        L_0x0096:
            if (r7 == 0) goto L_0x00b6
            androidx.appcompat.view.menu.i r7 = r5.f458a
            boolean r7 = r7.isChecked()
            r2.setChecked(r7)
            int r7 = r2.getVisibility()
            if (r7 == 0) goto L_0x00aa
            r2.setVisibility(r0)
        L_0x00aa:
            if (r3 == 0) goto L_0x00c4
            int r7 = r3.getVisibility()
            if (r7 == r1) goto L_0x00c4
            r3.setVisibility(r1)
            goto L_0x00c4
        L_0x00b6:
            android.widget.CheckBox r7 = r5.f462e
            if (r7 == 0) goto L_0x00bd
            r7.setVisibility(r1)
        L_0x00bd:
            android.widget.RadioButton r7 = r5.f460c
            if (r7 == 0) goto L_0x00c4
            r7.setVisibility(r1)
        L_0x00c4:
            boolean r7 = r6.mo876v()
            r6.mo826f()
            r5.mo631g(r7)
            android.graphics.drawable.Drawable r7 = r6.getIcon()
            androidx.appcompat.view.menu.i r2 = r5.f458a
            androidx.appcompat.view.menu.g r2 = r2.f598n
            java.util.Objects.requireNonNull(r2)
            boolean r2 = r5.f474q
            if (r2 != 0) goto L_0x00e2
            boolean r3 = r5.f470m
            if (r3 != 0) goto L_0x00e2
            goto L_0x012c
        L_0x00e2:
            android.widget.ImageView r3 = r5.f459b
            if (r3 != 0) goto L_0x00ed
            if (r7 != 0) goto L_0x00ed
            boolean r4 = r5.f470m
            if (r4 != 0) goto L_0x00ed
            goto L_0x012c
        L_0x00ed:
            if (r3 != 0) goto L_0x0109
            android.view.LayoutInflater r3 = r5.m613a()
            r4 = 2131558415(0x7f0d000f, float:1.8742145E38)
            android.view.View r3 = r3.inflate(r4, r5, r0)
            android.widget.ImageView r3 = (android.widget.ImageView) r3
            r5.f459b = r3
            android.widget.LinearLayout r4 = r5.f466i
            if (r4 == 0) goto L_0x0106
            r4.addView(r3, r0)
            goto L_0x0109
        L_0x0106:
            r5.addView(r3, r0)
        L_0x0109:
            if (r7 != 0) goto L_0x0116
            boolean r3 = r5.f470m
            if (r3 == 0) goto L_0x0110
            goto L_0x0116
        L_0x0110:
            android.widget.ImageView r7 = r5.f459b
            r7.setVisibility(r1)
            goto L_0x012c
        L_0x0116:
            android.widget.ImageView r3 = r5.f459b
            if (r2 == 0) goto L_0x011b
            goto L_0x011c
        L_0x011b:
            r7 = 0
        L_0x011c:
            r3.setImageDrawable(r7)
            android.widget.ImageView r7 = r5.f459b
            int r7 = r7.getVisibility()
            if (r7 == 0) goto L_0x012c
            android.widget.ImageView r7 = r5.f459b
            r7.setVisibility(r0)
        L_0x012c:
            boolean r7 = r6.isEnabled()
            r5.setEnabled(r7)
            boolean r7 = r6.hasSubMenu()
            android.widget.ImageView r2 = r5.f464g
            if (r2 == 0) goto L_0x0143
            if (r7 == 0) goto L_0x013e
            goto L_0x0140
        L_0x013e:
            r0 = 8
        L_0x0140:
            r2.setVisibility(r0)
        L_0x0143:
            java.lang.CharSequence r6 = r6.getContentDescription()
            r5.setContentDescription(r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.ListMenuItemView.mo612f(androidx.appcompat.view.menu.i, int):void");
    }

    /* renamed from: g */
    public void mo631g(boolean z) {
        int i = (!z || !this.f458a.mo876v()) ? 8 : 0;
        if (i == 0) {
            this.f463f.setText(this.f458a.mo827g());
        }
        if (this.f463f.getVisibility() != i) {
            this.f463f.setVisibility(i);
        }
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        super.onFinishInflate();
        Drawable drawable = this.f467j;
        int i = C4761m.f17241f;
        setBackground(drawable);
        TextView textView = (TextView) findViewById(R.id.title);
        this.f461d = textView;
        int i2 = this.f468k;
        if (i2 != -1) {
            textView.setTextAppearance(this.f469l, i2);
        }
        this.f463f = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f464g = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f471n);
        }
        this.f465h = (ImageView) findViewById(R.id.group_divider);
        this.f466i = (LinearLayout) findViewById(R.id.content);
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        if (this.f459b != null && this.f470m) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f459b.getLayoutParams();
            int i3 = layoutParams.height;
            if (i3 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i3;
            }
        }
        super.onMeasure(i, i2);
    }
}
