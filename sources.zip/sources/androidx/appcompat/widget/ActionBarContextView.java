package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.ActionMenuPresenter;
import androidx.appcompat.widget.C0248a;
import androidx.recyclerview.widget.RecyclerView;
import com.vidio.android.p195tv.R;
import p098d.p099a.C4568b;
import p098d.p099a.p106g.C4589b;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.C4774r;

public class ActionBarContextView extends C0248a {

    /* renamed from: i */
    private CharSequence f672i;

    /* renamed from: j */
    private CharSequence f673j;

    /* renamed from: k */
    private View f674k;

    /* renamed from: l */
    private View f675l;

    /* renamed from: m */
    private LinearLayout f676m;

    /* renamed from: n */
    private TextView f677n;

    /* renamed from: o */
    private TextView f678o;

    /* renamed from: p */
    private int f679p;

    /* renamed from: q */
    private int f680q;

    /* renamed from: r */
    private boolean f681r;

    /* renamed from: s */
    private int f682s;

    /* renamed from: androidx.appcompat.widget.ActionBarContextView$a */
    class C0189a implements View.OnClickListener {

        /* renamed from: a */
        final /* synthetic */ C4589b f683a;

        C0189a(ActionBarContextView actionBarContextView, C4589b bVar) {
            this.f683a = bVar;
        }

        public void onClick(View view) {
            this.f683a.mo592c();
        }
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.actionModeStyle);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        C0259e0 v = C0259e0.m1181v(context, attributeSet, C4568b.f16456d, i, 0);
        Drawable g = v.mo1596g(0);
        int i2 = C4761m.f17241f;
        setBackground(g);
        this.f679p = v.mo1603n(5, 0);
        this.f680q = v.mo1603n(4, 0);
        this.f1058e = v.mo1602m(3, 0);
        this.f682s = v.mo1603n(2, R.layout.abc_action_mode_close_item_material);
        v.mo1609w();
    }

    /* renamed from: i */
    private void m842i() {
        if (this.f676m == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f676m = linearLayout;
            this.f677n = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.f678o = (TextView) this.f676m.findViewById(R.id.action_bar_subtitle);
            if (this.f679p != 0) {
                this.f677n.setTextAppearance(getContext(), this.f679p);
            }
            if (this.f680q != 0) {
                this.f678o.setTextAppearance(getContext(), this.f680q);
            }
        }
        this.f677n.setText(this.f672i);
        this.f678o.setText(this.f673j);
        boolean z = !TextUtils.isEmpty(this.f672i);
        boolean z2 = !TextUtils.isEmpty(this.f673j);
        int i = 0;
        this.f678o.setVisibility(z2 ? 0 : 8);
        LinearLayout linearLayout2 = this.f676m;
        if (!z && !z2) {
            i = 8;
        }
        linearLayout2.setVisibility(i);
        if (this.f676m.getParent() == null) {
            addView(this.f676m);
        }
    }

    /* renamed from: e */
    public void mo1024e() {
        if (this.f674k == null) {
            mo1031k();
        }
    }

    /* renamed from: f */
    public CharSequence mo1025f() {
        return this.f673j;
    }

    /* renamed from: g */
    public CharSequence mo1026g() {
        return this.f672i;
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    /* JADX WARNING: Removed duplicated region for block: B:9:0x003c  */
    /* renamed from: h */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1029h(p098d.p099a.p106g.C4589b r4) {
        /*
            r3 = this;
            android.view.View r0 = r3.f674k
            if (r0 != 0) goto L_0x0016
            android.content.Context r0 = r3.getContext()
            android.view.LayoutInflater r0 = android.view.LayoutInflater.from(r0)
            int r1 = r3.f682s
            r2 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            r3.f674k = r0
            goto L_0x001e
        L_0x0016:
            android.view.ViewParent r0 = r0.getParent()
            if (r0 != 0) goto L_0x0021
            android.view.View r0 = r3.f674k
        L_0x001e:
            r3.addView(r0)
        L_0x0021:
            android.view.View r0 = r3.f674k
            r1 = 2131361866(0x7f0a004a, float:1.8343496E38)
            android.view.View r0 = r0.findViewById(r1)
            androidx.appcompat.widget.ActionBarContextView$a r1 = new androidx.appcompat.widget.ActionBarContextView$a
            r1.<init>(r3, r4)
            r0.setOnClickListener(r1)
            android.view.Menu r4 = r4.mo594e()
            androidx.appcompat.view.menu.g r4 = (androidx.appcompat.view.menu.C0163g) r4
            androidx.appcompat.widget.ActionMenuPresenter r0 = r3.f1057d
            if (r0 == 0) goto L_0x003f
            r0.mo1102y()
        L_0x003f:
            androidx.appcompat.widget.ActionMenuPresenter r0 = new androidx.appcompat.widget.ActionMenuPresenter
            android.content.Context r1 = r3.getContext()
            r0.<init>(r1)
            r3.f1057d = r0
            r1 = 1
            r0.mo1100E(r1)
            android.view.ViewGroup$LayoutParams r0 = new android.view.ViewGroup$LayoutParams
            r1 = -2
            r2 = -1
            r0.<init>(r1, r2)
            androidx.appcompat.widget.ActionMenuPresenter r1 = r3.f1057d
            android.content.Context r2 = r3.f1055b
            r4.mo780c(r1, r2)
            androidx.appcompat.widget.ActionMenuPresenter r4 = r3.f1057d
            androidx.appcompat.view.menu.n r4 = r4.mo702o(r3)
            androidx.appcompat.widget.ActionMenuView r4 = (androidx.appcompat.widget.ActionMenuView) r4
            r3.f1056c = r4
            r1 = 0
            int r2 = p098d.p120g.p130j.C4761m.f17241f
            r4.setBackground(r1)
            androidx.appcompat.widget.ActionMenuView r4 = r3.f1056c
            r3.addView(r4, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarContextView.mo1029h(d.a.g.b):void");
    }

    /* renamed from: j */
    public boolean mo1030j() {
        return this.f681r;
    }

    /* renamed from: k */
    public void mo1031k() {
        removeAllViews();
        this.f675l = null;
        this.f1056c = null;
    }

    /* renamed from: l */
    public void mo1032l(int i) {
        this.f1058e = i;
    }

    /* renamed from: m */
    public void mo1033m(View view) {
        LinearLayout linearLayout;
        View view2 = this.f675l;
        if (view2 != null) {
            removeView(view2);
        }
        this.f675l = view;
        if (!(view == null || (linearLayout = this.f676m) == null)) {
            removeView(linearLayout);
            this.f676m = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    /* renamed from: n */
    public void mo1034n(CharSequence charSequence) {
        this.f673j = charSequence;
        m842i();
    }

    /* renamed from: o */
    public void mo1035o(CharSequence charSequence) {
        this.f672i = charSequence;
        m842i();
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ActionMenuPresenter actionMenuPresenter = this.f1057d;
        if (actionMenuPresenter != null) {
            actionMenuPresenter.mo1103z();
            ActionMenuPresenter.C0195a aVar = this.f1057d.f729t;
            if (aVar != null) {
                aVar.mo950a();
            }
        }
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 32) {
            accessibilityEvent.setSource(this);
            accessibilityEvent.setClassName(getClass().getName());
            accessibilityEvent.setPackageName(getContext().getPackageName());
            accessibilityEvent.setContentDescription(this.f672i);
            return;
        }
        super.onInitializeAccessibilityEvent(accessibilityEvent);
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean b = C0280l0.m1310b(this);
        int paddingRight = b ? (i3 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
        View view = this.f674k;
        if (!(view == null || view.getVisibility() == 8)) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f674k.getLayoutParams();
            int i5 = b ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i6 = b ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i7 = b ? paddingRight - i5 : paddingRight + i5;
            int d = i7 + mo1558d(this.f674k, i7, paddingTop, paddingTop2, b);
            paddingRight = b ? d - i6 : d + i6;
        }
        int i8 = paddingRight;
        LinearLayout linearLayout = this.f676m;
        if (!(linearLayout == null || this.f675l != null || linearLayout.getVisibility() == 8)) {
            i8 += mo1558d(this.f676m, i8, paddingTop, paddingTop2, b);
        }
        int i9 = i8;
        View view2 = this.f675l;
        if (view2 != null) {
            mo1558d(view2, i9, paddingTop, paddingTop2, b);
        }
        int paddingLeft = b ? getPaddingLeft() : (i3 - i) - getPaddingRight();
        ActionMenuView actionMenuView = this.f1056c;
        if (actionMenuView != null) {
            mo1558d(actionMenuView, paddingLeft, paddingTop, paddingTop2, !b);
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3 = 1073741824;
        if (View.MeasureSpec.getMode(i) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        } else if (View.MeasureSpec.getMode(i2) != 0) {
            int size = View.MeasureSpec.getSize(i);
            int i4 = this.f1058e;
            if (i4 <= 0) {
                i4 = View.MeasureSpec.getSize(i2);
            }
            int paddingBottom = getPaddingBottom() + getPaddingTop();
            int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
            int i5 = i4 - paddingBottom;
            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i5, RecyclerView.UNDEFINED_DURATION);
            View view = this.f674k;
            if (view != null) {
                int c = mo1557c(view, paddingLeft, makeMeasureSpec, 0);
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f674k.getLayoutParams();
                paddingLeft = c - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
            }
            ActionMenuView actionMenuView = this.f1056c;
            if (actionMenuView != null && actionMenuView.getParent() == this) {
                paddingLeft = mo1557c(this.f1056c, paddingLeft, makeMeasureSpec, 0);
            }
            LinearLayout linearLayout = this.f676m;
            if (linearLayout != null && this.f675l == null) {
                if (this.f681r) {
                    this.f676m.measure(View.MeasureSpec.makeMeasureSpec(0, 0), makeMeasureSpec);
                    int measuredWidth = this.f676m.getMeasuredWidth();
                    boolean z = measuredWidth <= paddingLeft;
                    if (z) {
                        paddingLeft -= measuredWidth;
                    }
                    this.f676m.setVisibility(z ? 0 : 8);
                } else {
                    paddingLeft = mo1557c(linearLayout, paddingLeft, makeMeasureSpec, 0);
                }
            }
            View view2 = this.f675l;
            if (view2 != null) {
                ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
                int i6 = layoutParams.width;
                int i7 = i6 != -2 ? 1073741824 : RecyclerView.UNDEFINED_DURATION;
                if (i6 >= 0) {
                    paddingLeft = Math.min(i6, paddingLeft);
                }
                int i8 = layoutParams.height;
                if (i8 == -2) {
                    i3 = RecyclerView.UNDEFINED_DURATION;
                }
                if (i8 >= 0) {
                    i5 = Math.min(i8, i5);
                }
                this.f675l.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i7), View.MeasureSpec.makeMeasureSpec(i5, i3));
            }
            if (this.f1058e <= 0) {
                int childCount = getChildCount();
                i4 = 0;
                for (int i9 = 0; i9 < childCount; i9++) {
                    int measuredHeight = getChildAt(i9).getMeasuredHeight() + paddingBottom;
                    if (measuredHeight > i4) {
                        i4 = measuredHeight;
                    }
                }
            }
            setMeasuredDimension(size, i4);
        } else {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_height=\"wrap_content\"");
        }
    }

    /* renamed from: p */
    public void mo1040p(boolean z) {
        if (z != this.f681r) {
            requestLayout();
        }
        this.f681r = z;
    }

    /* renamed from: q */
    public C4774r mo1041q(int i, long j) {
        C4774r rVar = this.f1059f;
        if (rVar != null) {
            rVar.mo21875b();
        }
        if (i == 0) {
            if (getVisibility() != 0) {
                setAlpha(0.0f);
            }
            C4774r a = C4761m.m17292a(this);
            a.mo21874a(1.0f);
            a.mo21877d(j);
            C0248a.C0249a aVar = this.f1054a;
            C0248a.this.f1059f = a;
            aVar.f1063b = i;
            a.mo21879f(aVar);
            return a;
        }
        C4774r a2 = C4761m.m17292a(this);
        a2.mo21874a(0.0f);
        a2.mo21877d(j);
        C0248a.C0249a aVar2 = this.f1054a;
        C0248a.this.f1059f = a2;
        aVar2.f1063b = i;
        a2.mo21879f(aVar2);
        return a2;
    }

    /* renamed from: r */
    public boolean mo1042r() {
        ActionMenuPresenter actionMenuPresenter = this.f1057d;
        if (actionMenuPresenter != null) {
            return actionMenuPresenter.mo1101F();
        }
        return false;
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
