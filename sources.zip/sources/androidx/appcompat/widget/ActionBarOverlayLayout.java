package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.appcompat.app.C0144q;
import androidx.appcompat.view.menu.C0178m;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.common.api.C4291a;
import com.vidio.android.p195tv.R;
import java.util.Objects;
import p098d.p120g.p121c.C4694c;
import p098d.p120g.p130j.C4755g;
import p098d.p120g.p130j.C4756h;
import p098d.p120g.p130j.C4757i;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.C4780v;
import p165e.p166a.p167a.p168a.C4924a;

public class ActionBarOverlayLayout extends ViewGroup implements C0281m, C4755g, C4756h {

    /* renamed from: a */
    static final int[] f684a = {R.attr.actionBarSize, 16842841};

    /* renamed from: A */
    private OverScroller f685A;

    /* renamed from: B */
    ViewPropertyAnimator f686B;

    /* renamed from: C */
    final AnimatorListenerAdapter f687C;

    /* renamed from: D */
    private final Runnable f688D;

    /* renamed from: E */
    private final Runnable f689E;

    /* renamed from: F */
    private final C4757i f690F;

    /* renamed from: b */
    private int f691b;

    /* renamed from: c */
    private int f692c = 0;

    /* renamed from: d */
    private ContentFrameLayout f693d;

    /* renamed from: e */
    ActionBarContainer f694e;

    /* renamed from: f */
    private C0283n f695f;

    /* renamed from: g */
    private Drawable f696g;

    /* renamed from: h */
    private boolean f697h;

    /* renamed from: i */
    private boolean f698i;

    /* renamed from: j */
    private boolean f699j;

    /* renamed from: k */
    private boolean f700k;

    /* renamed from: l */
    boolean f701l;

    /* renamed from: m */
    private int f702m;

    /* renamed from: n */
    private int f703n;

    /* renamed from: o */
    private final Rect f704o = new Rect();

    /* renamed from: p */
    private final Rect f705p = new Rect();

    /* renamed from: q */
    private final Rect f706q = new Rect();

    /* renamed from: r */
    private final Rect f707r = new Rect();

    /* renamed from: s */
    private final Rect f708s = new Rect();

    /* renamed from: t */
    private final Rect f709t = new Rect();

    /* renamed from: u */
    private final Rect f710u = new Rect();

    /* renamed from: v */
    private C4780v f711v;

    /* renamed from: w */
    private C4780v f712w;

    /* renamed from: x */
    private C4780v f713x;

    /* renamed from: y */
    private C4780v f714y;

    /* renamed from: z */
    private C0193d f715z;

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {
        public LayoutParams(int i, int i2) {
            super(i, i2);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$a */
    class C0190a extends AnimatorListenerAdapter {
        C0190a() {
        }

        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f686B = null;
            actionBarOverlayLayout.f701l = false;
        }

        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f686B = null;
            actionBarOverlayLayout.f701l = false;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$b */
    class C0191b implements Runnable {
        C0191b() {
        }

        public void run() {
            ActionBarOverlayLayout.this.mo1084s();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f686B = actionBarOverlayLayout.f694e.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.f687C);
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$c */
    class C0192c implements Runnable {
        C0192c() {
        }

        public void run() {
            ActionBarOverlayLayout.this.mo1084s();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f686B = actionBarOverlayLayout.f694e.animate().translationY((float) (-ActionBarOverlayLayout.this.f694e.getHeight())).setListener(ActionBarOverlayLayout.this.f687C);
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$d */
    public interface C0193d {
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C4780v vVar = C4780v.f17260a;
        this.f711v = vVar;
        this.f712w = vVar;
        this.f713x = vVar;
        this.f714y = vVar;
        this.f687C = new C0190a();
        this.f688D = new C0191b();
        this.f689E = new C0192c();
        m857t(context);
        this.f690F = new C4757i();
    }

    /* renamed from: r */
    private boolean m856r(View view, Rect rect, boolean z, boolean z2, boolean z3, boolean z4) {
        boolean z5;
        int i;
        int i2;
        int i3;
        int i4;
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (!z || layoutParams.leftMargin == (i4 = rect.left)) {
            z5 = false;
        } else {
            layoutParams.leftMargin = i4;
            z5 = true;
        }
        if (z2 && layoutParams.topMargin != (i3 = rect.top)) {
            layoutParams.topMargin = i3;
            z5 = true;
        }
        if (z4 && layoutParams.rightMargin != (i2 = rect.right)) {
            layoutParams.rightMargin = i2;
            z5 = true;
        }
        if (!z3 || layoutParams.bottomMargin == (i = rect.bottom)) {
            return z5;
        }
        layoutParams.bottomMargin = i;
        return true;
    }

    /* renamed from: t */
    private void m857t(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f684a);
        boolean z = false;
        this.f691b = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.f696g = drawable;
        setWillNotDraw(drawable == null);
        obtainStyledAttributes.recycle();
        if (context.getApplicationInfo().targetSdkVersion < 19) {
            z = true;
        }
        this.f697h = z;
        this.f685A = new OverScroller(context);
    }

    /* renamed from: A */
    public void mo1045A() {
    }

    /* renamed from: a */
    public void mo1046a(Menu menu, C0178m.C0179a aVar) {
        mo1087v();
        this.f695f.mo1621a(menu, aVar);
    }

    /* renamed from: b */
    public void mo1047b(CharSequence charSequence) {
        mo1087v();
        this.f695f.mo1622b(charSequence);
    }

    /* renamed from: c */
    public boolean mo1048c() {
        mo1087v();
        return this.f695f.mo1623c();
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    /* renamed from: d */
    public void mo1050d() {
        mo1087v();
        this.f695f.mo1625d();
    }

    public void draw(Canvas canvas) {
        int i;
        super.draw(canvas);
        if (this.f696g != null && !this.f697h) {
            if (this.f694e.getVisibility() == 0) {
                i = (int) (this.f694e.getTranslationY() + ((float) this.f694e.getBottom()) + 0.5f);
            } else {
                i = 0;
            }
            this.f696g.setBounds(0, i, getWidth(), this.f696g.getIntrinsicHeight() + i);
            this.f696g.draw(canvas);
        }
    }

    /* renamed from: e */
    public boolean mo1052e() {
        mo1087v();
        return this.f695f.mo1626e();
    }

    /* renamed from: f */
    public void mo1053f(Window.Callback callback) {
        mo1087v();
        this.f695f.mo1627f(callback);
    }

    /* access modifiers changed from: protected */
    public boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    /* renamed from: g */
    public boolean mo1055g() {
        mo1087v();
        return this.f695f.mo1628g();
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-1, -1);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    public int getNestedScrollAxes() {
        return this.f690F.mo21852a();
    }

    /* renamed from: h */
    public boolean mo1060h() {
        mo1087v();
        return this.f695f.mo1630h();
    }

    /* renamed from: i */
    public boolean mo1061i() {
        mo1087v();
        return this.f695f.mo1631i();
    }

    /* renamed from: j */
    public void mo1062j(int i) {
        mo1087v();
        if (i == 2) {
            this.f695f.mo1641s();
        } else if (i == 5) {
            this.f695f.mo1643t();
        } else if (i == 109) {
            boolean z = true;
            this.f698i = true;
            if (getContext().getApplicationInfo().targetSdkVersion >= 19) {
                z = false;
            }
            this.f697h = z;
        }
    }

    /* renamed from: k */
    public void mo1063k() {
        mo1087v();
        this.f695f.mo1632j();
    }

    /* renamed from: l */
    public void mo1064l(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        if (i5 == 0) {
            onNestedScroll(view, i, i2, i3, i4);
        }
    }

    /* renamed from: m */
    public void mo1065m(View view, int i, int i2, int i3, int i4, int i5) {
        if (i5 == 0) {
            onNestedScroll(view, i, i2, i3, i4);
        }
    }

    /* renamed from: n */
    public boolean mo1066n(View view, View view2, int i, int i2) {
        return i2 == 0 && onStartNestedScroll(view, view2, i);
    }

    /* renamed from: o */
    public void mo1067o(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }

    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        mo1087v();
        C4780v m = C4780v.m17359m(windowInsets);
        boolean r = m856r(this.f694e, new Rect(m.mo21892e(), m.mo21895g(), m.mo21894f(), m.mo21891d()), true, true, false, true);
        C4761m.m17295d(this, m, this.f704o);
        Rect rect = this.f704o;
        C4780v i = m.mo21898i(rect.left, rect.top, rect.right, rect.bottom);
        this.f711v = i;
        boolean z = true;
        if (!this.f712w.equals(i)) {
            this.f712w = this.f711v;
            r = true;
        }
        if (!this.f705p.equals(this.f704o)) {
            this.f705p.set(this.f704o);
        } else {
            z = r;
        }
        if (z) {
            requestLayout();
        }
        return m.mo21888a().mo21890c().mo21889b().mo21900l();
    }

    /* access modifiers changed from: protected */
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        m857t(getContext());
        int i = C4761m.f17241f;
        requestApplyInsets();
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        mo1084s();
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i6 = layoutParams.leftMargin + paddingLeft;
                int i7 = layoutParams.topMargin + paddingTop;
                childAt.layout(i6, i7, measuredWidth + i6, measuredHeight + i7);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3;
        C4780v vVar;
        mo1087v();
        measureChildWithMargins(this.f694e, i, 0, i2, 0);
        LayoutParams layoutParams = (LayoutParams) this.f694e.getLayoutParams();
        int max = Math.max(0, this.f694e.getMeasuredWidth() + layoutParams.leftMargin + layoutParams.rightMargin);
        int max2 = Math.max(0, this.f694e.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.f694e.getMeasuredState());
        int i4 = C4761m.f17241f;
        boolean z = (getWindowSystemUiVisibility() & 256) != 0;
        if (z) {
            i3 = this.f691b;
            if (this.f699j && this.f694e.mo1009b() != null) {
                i3 += this.f691b;
            }
        } else {
            i3 = this.f694e.getVisibility() != 8 ? this.f694e.getMeasuredHeight() : 0;
        }
        this.f706q.set(this.f704o);
        C4780v vVar2 = this.f711v;
        this.f713x = vVar2;
        if (this.f698i || z) {
            C4694c a = C4694c.m17140a(vVar2.mo21892e(), this.f713x.mo21895g() + i3, this.f713x.mo21894f(), this.f713x.mo21891d() + 0);
            C4780v.C4781a aVar = new C4780v.C4781a(this.f713x);
            aVar.mo21903c(a);
            vVar = aVar.mo21901a();
        } else {
            Rect rect = this.f706q;
            rect.top += i3;
            rect.bottom += 0;
            vVar = vVar2.mo21898i(0, i3, 0, 0);
        }
        this.f713x = vVar;
        m856r(this.f693d, this.f706q, true, true, true, true);
        if (!this.f714y.equals(this.f713x)) {
            C4780v vVar3 = this.f713x;
            this.f714y = vVar3;
            C4761m.m17296e(this.f693d, vVar3);
        }
        measureChildWithMargins(this.f693d, i, 0, i2, 0);
        LayoutParams layoutParams2 = (LayoutParams) this.f693d.getLayoutParams();
        int max3 = Math.max(max, this.f693d.getMeasuredWidth() + layoutParams2.leftMargin + layoutParams2.rightMargin);
        int max4 = Math.max(max2, this.f693d.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.f693d.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + max3, getSuggestedMinimumWidth()), i, combineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + max4, getSuggestedMinimumHeight()), i2, combineMeasuredStates2 << 16));
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        boolean z2 = false;
        if (!this.f700k || !z) {
            return false;
        }
        this.f685A.fling(0, 0, 0, (int) f2, 0, 0, RecyclerView.UNDEFINED_DURATION, C4291a.C4299e.API_PRIORITY_OTHER);
        if (this.f685A.getFinalY() > this.f694e.getHeight()) {
            z2 = true;
        }
        if (z2) {
            mo1084s();
            this.f689E.run();
        } else {
            mo1084s();
            this.f688D.run();
        }
        this.f701l = true;
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        int i5 = this.f702m + i2;
        this.f702m = i5;
        mo1088w(i5);
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.f690F.mo21854c(view, view2, i);
        ActionBarContainer actionBarContainer = this.f694e;
        this.f702m = actionBarContainer != null ? -((int) actionBarContainer.getTranslationY()) : 0;
        mo1084s();
        C0193d dVar = this.f715z;
        if (dVar != null) {
            ((C0144q) dVar).mo588j();
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) == 0 || this.f694e.getVisibility() != 0) {
            return false;
        }
        return this.f700k;
    }

    public void onStopNestedScroll(View view) {
        if (this.f700k && !this.f701l) {
            if (this.f702m <= this.f694e.getHeight()) {
                mo1084s();
                postDelayed(this.f688D, 600);
            } else {
                mo1084s();
                postDelayed(this.f689E, 600);
            }
        }
        C0193d dVar = this.f715z;
        if (dVar != null) {
            Objects.requireNonNull((C0144q) dVar);
        }
    }

    public void onWindowSystemUiVisibilityChanged(int i) {
        super.onWindowSystemUiVisibilityChanged(i);
        mo1087v();
        int i2 = this.f703n ^ i;
        this.f703n = i;
        boolean z = false;
        boolean z2 = (i & 4) == 0;
        if ((i & 256) != 0) {
            z = true;
        }
        C0193d dVar = this.f715z;
        if (dVar != null) {
            ((C0144q) dVar).mo586g(!z);
            if (z2 || !z) {
                ((C0144q) this.f715z).mo590m();
            } else {
                ((C0144q) this.f715z).mo587h();
            }
        }
        if ((i2 & 256) != 0 && this.f715z != null) {
            int i3 = C4761m.f17241f;
            requestApplyInsets();
        }
    }

    /* access modifiers changed from: protected */
    public void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.f692c = i;
        C0193d dVar = this.f715z;
        if (dVar != null) {
            ((C0144q) dVar).mo589k(i);
        }
    }

    /* renamed from: p */
    public void mo1082p(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    /* renamed from: q */
    public void mo1083q(View view, int i, int i2, int[] iArr, int i3) {
        if (i3 == 0) {
            onNestedPreScroll(view, i, i2, iArr);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: s */
    public void mo1084s() {
        removeCallbacks(this.f688D);
        removeCallbacks(this.f689E);
        ViewPropertyAnimator viewPropertyAnimator = this.f686B;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    /* renamed from: u */
    public boolean mo1086u() {
        return this.f698i;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: v */
    public void mo1087v() {
        C0283n nVar;
        if (this.f693d == null) {
            this.f693d = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.f694e = (ActionBarContainer) findViewById(R.id.action_bar_container);
            View findViewById = findViewById(R.id.action_bar);
            if (findViewById instanceof C0283n) {
                nVar = (C0283n) findViewById;
            } else if (findViewById instanceof Toolbar) {
                nVar = ((Toolbar) findViewById).mo1498B();
            } else {
                StringBuilder P = C4924a.m17863P("Can't make a decor toolbar out of ");
                P.append(findViewById.getClass().getSimpleName());
                throw new IllegalStateException(P.toString());
            }
            this.f695f = nVar;
        }
    }

    /* renamed from: w */
    public void mo1088w(int i) {
        mo1084s();
        this.f694e.setTranslationY((float) (-Math.max(0, Math.min(i, this.f694e.getHeight()))));
    }

    /* renamed from: x */
    public void mo1089x(C0193d dVar) {
        this.f715z = dVar;
        if (getWindowToken() != null) {
            ((C0144q) this.f715z).mo589k(this.f692c);
            int i = this.f703n;
            if (i != 0) {
                onWindowSystemUiVisibilityChanged(i);
                int i2 = C4761m.f17241f;
                requestApplyInsets();
            }
        }
    }

    /* renamed from: y */
    public void mo1090y(boolean z) {
        this.f699j = z;
    }

    /* renamed from: z */
    public void mo1091z(boolean z) {
        if (z != this.f700k) {
            this.f700k = z;
            if (!z) {
                mo1084s();
                mo1088w(0);
            }
        }
    }
}
