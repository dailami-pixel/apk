package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.C0152b;
import androidx.appcompat.view.menu.C0163g;
import androidx.appcompat.view.menu.C0167i;
import androidx.appcompat.view.menu.C0176l;
import androidx.appcompat.view.menu.C0178m;
import androidx.appcompat.view.menu.C0180n;
import androidx.appcompat.view.menu.C0183p;
import androidx.appcompat.view.menu.C0187r;
import androidx.appcompat.widget.ActionMenuView;
import com.vidio.android.p195tv.R;
import java.util.ArrayList;
import p098d.p099a.p106g.C4588a;
import p098d.p120g.p130j.C4747b;

class ActionMenuPresenter extends C0152b implements C4747b.C4748a {

    /* renamed from: j */
    C0198d f719j;

    /* renamed from: k */
    private boolean f720k;

    /* renamed from: l */
    private boolean f721l;

    /* renamed from: m */
    private int f722m;

    /* renamed from: n */
    private int f723n;

    /* renamed from: o */
    private int f724o;

    /* renamed from: p */
    private boolean f725p;

    /* renamed from: q */
    private int f726q;

    /* renamed from: r */
    private final SparseBooleanArray f727r = new SparseBooleanArray();

    /* renamed from: s */
    C0200e f728s;

    /* renamed from: t */
    C0195a f729t;

    /* renamed from: u */
    C0197c f730u;

    /* renamed from: v */
    private C0196b f731v;

    /* renamed from: w */
    final C0201f f732w = new C0201f();

    /* renamed from: x */
    int f733x;

    private static class SavedState implements Parcelable {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0194a();

        /* renamed from: a */
        public int f734a;

        /* renamed from: androidx.appcompat.widget.ActionMenuPresenter$SavedState$a */
        class C0194a implements Parcelable.Creator<SavedState> {
            C0194a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public Object[] newArray(int i) {
                return new SavedState[i];
            }
        }

        SavedState() {
        }

        SavedState(Parcel parcel) {
            this.f734a = parcel.readInt();
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f734a);
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuPresenter$a */
    private class C0195a extends C0176l {
        public C0195a(Context context, C0187r rVar, View view) {
            super(context, rVar, view, false, R.attr.actionOverflowMenuStyle, 0);
            if (!((C0167i) rVar.getItem()).mo848k()) {
                View view2 = ActionMenuPresenter.this.f719j;
                mo954e(view2 == null ? (View) ActionMenuPresenter.this.f498h : view2);
            }
            mo958i(ActionMenuPresenter.this.f732w);
        }

        /* access modifiers changed from: protected */
        /* renamed from: d */
        public void mo953d() {
            ActionMenuPresenter actionMenuPresenter = ActionMenuPresenter.this;
            actionMenuPresenter.f729t = null;
            actionMenuPresenter.f733x = 0;
            super.mo953d();
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuPresenter$b */
    private class C0196b extends ActionMenuItemView.C0150b {
        C0196b() {
        }

        /* renamed from: a */
        public C0183p mo623a() {
            C0195a aVar = ActionMenuPresenter.this.f729t;
            if (aVar != null) {
                return aVar.mo951b();
            }
            return null;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuPresenter$c */
    private class C0197c implements Runnable {

        /* renamed from: a */
        private C0200e f737a;

        public C0197c(C0200e eVar) {
            this.f737a = eVar;
        }

        public void run() {
            if (ActionMenuPresenter.this.f493c != null) {
                ActionMenuPresenter.this.f493c.mo784d();
            }
            View view = (View) ActionMenuPresenter.this.f498h;
            if (!(view == null || view.getWindowToken() == null || !this.f737a.mo959k())) {
                ActionMenuPresenter.this.f728s = this.f737a;
            }
            ActionMenuPresenter.this.f730u = null;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuPresenter$d */
    private class C0198d extends AppCompatImageView implements ActionMenuView.C0202a {

        /* renamed from: androidx.appcompat.widget.ActionMenuPresenter$d$a */
        class C0199a extends C0289r {
            C0199a(View view, ActionMenuPresenter actionMenuPresenter) {
                super(view);
            }

            /* renamed from: b */
            public C0183p mo621b() {
                C0200e eVar = ActionMenuPresenter.this.f728s;
                if (eVar == null) {
                    return null;
                }
                return eVar.mo951b();
            }

            /* renamed from: c */
            public boolean mo622c() {
                ActionMenuPresenter.this.mo1101F();
                return true;
            }

            /* renamed from: d */
            public boolean mo1111d() {
                ActionMenuPresenter actionMenuPresenter = ActionMenuPresenter.this;
                if (actionMenuPresenter.f730u != null) {
                    return false;
                }
                actionMenuPresenter.mo1103z();
                return true;
            }
        }

        public C0198d(Context context) {
            super(context, (AttributeSet) null, R.attr.actionOverflowButtonStyle);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            C0266h0.m1246b(this, getContentDescription());
            setOnTouchListener(new C0199a(this, ActionMenuPresenter.this));
        }

        /* renamed from: a */
        public boolean mo607a() {
            return false;
        }

        /* renamed from: c */
        public boolean mo609c() {
            return false;
        }

        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            ActionMenuPresenter.this.mo1101F();
            return true;
        }

        /* access modifiers changed from: protected */
        public boolean setFrame(int i, int i2, int i3, int i4) {
            boolean frame = super.setFrame(i, i2, i3, i4);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (!(drawable == null || background == null)) {
                int width = getWidth();
                int height = getHeight();
                int max = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                background.setHotspotBounds(paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
            }
            return frame;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuPresenter$e */
    private class C0200e extends C0176l {
        public C0200e(Context context, C0163g gVar, View view, boolean z) {
            super(context, gVar, view, z, R.attr.actionOverflowMenuStyle, 0);
            mo956g(8388613);
            mo958i(ActionMenuPresenter.this.f732w);
        }

        /* access modifiers changed from: protected */
        /* renamed from: d */
        public void mo953d() {
            if (ActionMenuPresenter.this.f493c != null) {
                ActionMenuPresenter.this.f493c.mo785e(true);
            }
            ActionMenuPresenter.this.f728s = null;
            super.mo953d();
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuPresenter$f */
    private class C0201f implements C0178m.C0179a {
        C0201f() {
        }

        /* renamed from: b */
        public void mo509b(C0163g gVar, boolean z) {
            if (gVar instanceof C0187r) {
                gVar.mo803q().mo785e(false);
            }
            C0178m.C0179a m = ActionMenuPresenter.this.mo700m();
            if (m != null) {
                m.mo509b(gVar, z);
            }
        }

        /* renamed from: c */
        public boolean mo510c(C0163g gVar) {
            if (gVar == ActionMenuPresenter.this.f493c) {
                return false;
            }
            ActionMenuPresenter.this.f733x = ((C0167i) ((C0187r) gVar).getItem()).getItemId();
            C0178m.C0179a m = ActionMenuPresenter.this.mo700m();
            if (m != null) {
                return m.mo510c(gVar);
            }
            return false;
        }
    }

    public ActionMenuPresenter(Context context) {
        super(context, R.layout.abc_action_menu_layout, R.layout.abc_action_menu_item_layout);
    }

    /* renamed from: A */
    public boolean mo1096A() {
        C0200e eVar = this.f728s;
        return eVar != null && eVar.mo952c();
    }

    /* renamed from: B */
    public void mo1097B() {
        this.f724o = C4588a.m16481b(this.f492b).mo21217d();
        C0163g gVar = this.f493c;
        if (gVar != null) {
            gVar.mo818x(true);
        }
    }

    /* renamed from: C */
    public void mo1098C(boolean z) {
        this.f725p = z;
    }

    /* renamed from: D */
    public void mo1099D(ActionMenuView actionMenuView) {
        this.f498h = actionMenuView;
        actionMenuView.mo625c(this.f493c);
    }

    /* renamed from: E */
    public void mo1100E(boolean z) {
        this.f720k = z;
        this.f721l = true;
    }

    /* renamed from: F */
    public boolean mo1101F() {
        C0163g gVar;
        if (!this.f720k || mo1096A() || (gVar = this.f493c) == null || this.f498h == null || this.f730u != null || gVar.mo800p().isEmpty()) {
            return false;
        }
        C0197c cVar = new C0197c(new C0200e(this.f492b, this.f493c, this.f719j, true));
        this.f730u = cVar;
        ((View) this.f498h).post(cVar);
        return true;
    }

    /* renamed from: a */
    public void mo690a(C0167i iVar, C0180n.C0181a aVar) {
        aVar.mo612f(iVar, 0);
        ActionMenuItemView actionMenuItemView = (ActionMenuItemView) aVar;
        actionMenuItemView.mo613g((ActionMenuView) this.f498h);
        if (this.f731v == null) {
            this.f731v = new C0196b();
        }
        actionMenuItemView.mo614h(this.f731v);
    }

    /* renamed from: b */
    public void mo691b(C0163g gVar, boolean z) {
        mo1102y();
        super.mo691b(gVar, z);
    }

    /* renamed from: c */
    public void mo692c(boolean z) {
        C0180n nVar;
        super.mo692c(z);
        ((View) this.f498h).requestLayout();
        C0163g gVar = this.f493c;
        boolean z2 = false;
        if (gVar != null) {
            ArrayList<C0167i> l = gVar.mo796l();
            int size = l.size();
            for (int i = 0; i < size; i++) {
                C4747b b = l.get(i).mo635b();
                if (b != null) {
                    b.mo21837i(this);
                }
            }
        }
        C0163g gVar2 = this.f493c;
        ArrayList<C0167i> p = gVar2 != null ? gVar2.mo800p() : null;
        if (this.f720k && p != null) {
            int size2 = p.size();
            if (size2 == 1) {
                z2 = !p.get(0).isActionViewExpanded();
            } else if (size2 > 0) {
                z2 = true;
            }
        }
        C0198d dVar = this.f719j;
        if (z2) {
            if (dVar == null) {
                this.f719j = new C0198d(this.f491a);
            }
            ViewGroup viewGroup = (ViewGroup) this.f719j.getParent();
            if (viewGroup != this.f498h) {
                if (viewGroup != null) {
                    viewGroup.removeView(this.f719j);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.f498h;
                C0198d dVar2 = this.f719j;
                ActionMenuView.LayoutParams y = actionMenuView.mo1130j();
                y.f755c = true;
                actionMenuView.addView(dVar2, y);
            }
        } else if (dVar != null && dVar.getParent() == (nVar = this.f498h)) {
            ((ViewGroup) nVar).removeView(this.f719j);
        }
        ((ActionMenuView) this.f498h).mo1121K(this.f720k);
    }

    /* renamed from: d */
    public boolean mo711d() {
        int i;
        ArrayList<C0167i> arrayList;
        boolean z;
        C0163g gVar = this.f493c;
        View view = null;
        if (gVar != null) {
            arrayList = gVar.mo804r();
            i = arrayList.size();
        } else {
            arrayList = null;
            i = 0;
        }
        int i2 = this.f724o;
        int i3 = this.f723n;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) this.f498h;
        int i4 = 0;
        boolean z2 = false;
        int i5 = 0;
        int i6 = 0;
        while (true) {
            z = true;
            if (i4 >= i) {
                break;
            }
            C0167i iVar = arrayList.get(i4);
            if (iVar.mo851n()) {
                i5++;
            } else if (iVar.mo850m()) {
                i6++;
            } else {
                z2 = true;
            }
            if (this.f725p && iVar.isActionViewExpanded()) {
                i2 = 0;
            }
            i4++;
        }
        if (this.f720k && (z2 || i6 + i5 > i2)) {
            i2--;
        }
        int i7 = i2 - i5;
        SparseBooleanArray sparseBooleanArray = this.f727r;
        sparseBooleanArray.clear();
        int i8 = 0;
        int i9 = 0;
        while (i8 < i) {
            C0167i iVar2 = arrayList.get(i8);
            if (iVar2.mo851n()) {
                View n = mo701n(iVar2, view, viewGroup);
                n.measure(makeMeasureSpec, makeMeasureSpec);
                int measuredWidth = n.getMeasuredWidth();
                i3 -= measuredWidth;
                if (i9 == 0) {
                    i9 = measuredWidth;
                }
                int groupId = iVar2.getGroupId();
                if (groupId != 0) {
                    sparseBooleanArray.put(groupId, z);
                }
                iVar2.mo856s(z);
            } else if (iVar2.mo850m()) {
                int groupId2 = iVar2.getGroupId();
                boolean z3 = sparseBooleanArray.get(groupId2);
                boolean z4 = (i7 > 0 || z3) && i3 > 0;
                if (z4) {
                    View n2 = mo701n(iVar2, view, viewGroup);
                    n2.measure(makeMeasureSpec, makeMeasureSpec);
                    int measuredWidth2 = n2.getMeasuredWidth();
                    i3 -= measuredWidth2;
                    if (i9 == 0) {
                        i9 = measuredWidth2;
                    }
                    z4 &= i3 + i9 > 0;
                }
                boolean z5 = z4;
                if (z5 && groupId2 != 0) {
                    sparseBooleanArray.put(groupId2, z);
                } else if (z3) {
                    sparseBooleanArray.put(groupId2, false);
                    for (int i10 = 0; i10 < i8; i10++) {
                        C0167i iVar3 = arrayList.get(i10);
                        if (iVar3.getGroupId() == groupId2) {
                            if (iVar3.mo848k()) {
                                i7++;
                            }
                            iVar3.mo856s(false);
                        }
                    }
                }
                if (z5) {
                    i7--;
                }
                iVar2.mo856s(z5);
            } else {
                iVar2.mo856s(false);
                i8++;
                view = null;
                z = true;
            }
            i8++;
            view = null;
            z = true;
        }
        return true;
    }

    /* renamed from: h */
    public void mo697h(Context context, C0163g gVar) {
        super.mo697h(context, gVar);
        Resources resources = context.getResources();
        C4588a b = C4588a.m16481b(context);
        if (!this.f721l) {
            this.f720k = true;
        }
        this.f722m = b.mo21216c();
        this.f724o = b.mo21217d();
        int i = this.f722m;
        if (this.f720k) {
            if (this.f719j == null) {
                this.f719j = new C0198d(this.f491a);
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f719j.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i -= this.f719j.getMeasuredWidth();
        } else {
            this.f719j = null;
        }
        this.f723n = i;
        this.f726q = (int) (resources.getDisplayMetrics().density * 56.0f);
    }

    /* renamed from: i */
    public void mo713i(Parcelable parcelable) {
        int i;
        MenuItem findItem;
        if ((parcelable instanceof SavedState) && (i = ((SavedState) parcelable).f734a) > 0 && (findItem = this.f493c.findItem(i)) != null) {
            mo699k((C0187r) findItem.getSubMenu());
        }
    }

    /* renamed from: j */
    public boolean mo698j(ViewGroup viewGroup, int i) {
        if (viewGroup.getChildAt(i) == this.f719j) {
            return false;
        }
        viewGroup.removeViewAt(i);
        return true;
    }

    /* renamed from: k */
    public boolean mo699k(C0187r rVar) {
        boolean z = false;
        if (!rVar.hasVisibleItems()) {
            return false;
        }
        C0187r rVar2 = rVar;
        while (rVar2.mo991S() != this.f493c) {
            rVar2 = (C0187r) rVar2.mo991S();
        }
        MenuItem item = rVar2.getItem();
        ViewGroup viewGroup = (ViewGroup) this.f498h;
        View view = null;
        if (viewGroup != null) {
            int childCount = viewGroup.getChildCount();
            int i = 0;
            while (true) {
                if (i >= childCount) {
                    break;
                }
                View childAt = viewGroup.getChildAt(i);
                if ((childAt instanceof C0180n.C0181a) && ((C0180n.C0181a) childAt).mo608b() == item) {
                    view = childAt;
                    break;
                }
                i++;
            }
        }
        if (view == null) {
            return false;
        }
        this.f733x = ((C0167i) rVar.getItem()).getItemId();
        int size = rVar.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                break;
            }
            MenuItem item2 = rVar.getItem(i2);
            if (item2.isVisible() && item2.getIcon() != null) {
                z = true;
                break;
            }
            i2++;
        }
        C0195a aVar = new C0195a(this.f492b, rVar, view);
        this.f729t = aVar;
        aVar.mo955f(z);
        if (this.f729t.mo959k()) {
            super.mo699k(rVar);
            return true;
        }
        throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
    }

    /* renamed from: l */
    public Parcelable mo715l() {
        SavedState savedState = new SavedState();
        savedState.f734a = this.f733x;
        return savedState;
    }

    /* renamed from: n */
    public View mo701n(C0167i iVar, View view, ViewGroup viewGroup) {
        View actionView = iVar.getActionView();
        if (actionView == null || iVar.mo842i()) {
            actionView = super.mo701n(iVar, view, viewGroup);
        }
        actionView.setVisibility(iVar.isActionViewExpanded() ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(actionMenuView.mo1132l(layoutParams));
        }
        return actionView;
    }

    /* renamed from: o */
    public C0180n mo702o(ViewGroup viewGroup) {
        C0180n nVar = this.f498h;
        C0180n o = super.mo702o(viewGroup);
        if (nVar != o) {
            ((ActionMenuView) o).mo1123M(this);
        }
        return o;
    }

    /* renamed from: q */
    public boolean mo704q(int i, C0167i iVar) {
        return iVar.mo848k();
    }

    /* renamed from: y */
    public boolean mo1102y() {
        boolean z;
        boolean z2 = mo1103z();
        C0195a aVar = this.f729t;
        if (aVar != null) {
            aVar.mo950a();
            z = true;
        } else {
            z = false;
        }
        return z2 | z;
    }

    /* renamed from: z */
    public boolean mo1103z() {
        C0180n nVar;
        C0197c cVar = this.f730u;
        if (cVar == null || (nVar = this.f498h) == null) {
            C0200e eVar = this.f728s;
            if (eVar == null) {
                return false;
            }
            eVar.mo950a();
            return true;
        }
        ((View) nVar).removeCallbacks(cVar);
        this.f730u = null;
        return true;
    }
}
