package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.C0163g;
import androidx.appcompat.view.menu.C0167i;
import androidx.appcompat.view.menu.C0178m;
import androidx.appcompat.view.menu.C0180n;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.common.api.C4291a;
import java.util.Objects;

public class ActionMenuView extends LinearLayoutCompat implements C0163g.C0165b, C0180n {

    /* renamed from: A */
    C0205d f743A;

    /* renamed from: p */
    private C0163g f744p;

    /* renamed from: q */
    private Context f745q;

    /* renamed from: r */
    private int f746r = 0;

    /* renamed from: s */
    private boolean f747s;

    /* renamed from: t */
    private ActionMenuPresenter f748t;

    /* renamed from: u */
    private C0178m.C0179a f749u;

    /* renamed from: v */
    C0163g.C0164a f750v;

    /* renamed from: w */
    private boolean f751w;

    /* renamed from: x */
    private int f752x;

    /* renamed from: y */
    private int f753y;

    /* renamed from: z */
    private int f754z;

    public static class LayoutParams extends LinearLayoutCompat.LayoutParams {
        @ViewDebug.ExportedProperty

        /* renamed from: c */
        public boolean f755c;
        @ViewDebug.ExportedProperty

        /* renamed from: d */
        public int f756d;
        @ViewDebug.ExportedProperty

        /* renamed from: e */
        public int f757e;
        @ViewDebug.ExportedProperty

        /* renamed from: f */
        public boolean f758f;
        @ViewDebug.ExportedProperty

        /* renamed from: g */
        public boolean f759g;

        /* renamed from: h */
        boolean f760h;

        public LayoutParams(int i, int i2) {
            super(i, i2);
            this.f755c = false;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(LayoutParams layoutParams) {
            super(layoutParams);
            this.f755c = layoutParams.f755c;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuView$a */
    public interface C0202a {
        /* renamed from: a */
        boolean mo607a();

        /* renamed from: c */
        boolean mo609c();
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuView$b */
    private static class C0203b implements C0178m.C0179a {
        C0203b() {
        }

        /* renamed from: b */
        public void mo509b(C0163g gVar, boolean z) {
        }

        /* renamed from: c */
        public boolean mo510c(C0163g gVar) {
            return false;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuView$c */
    private class C0204c implements C0163g.C0164a {
        C0204c() {
        }

        /* renamed from: a */
        public boolean mo474a(C0163g gVar, MenuItem menuItem) {
            C0205d dVar = ActionMenuView.this.f743A;
            if (dVar == null) {
                return false;
            }
            Objects.requireNonNull(Toolbar.this);
            return false;
        }

        /* renamed from: b */
        public void mo475b(C0163g gVar) {
            C0163g.C0164a aVar = ActionMenuView.this.f750v;
            if (aVar != null) {
                aVar.mo475b(gVar);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuView$d */
    public interface C0205d {
    }

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        mo1387v(false);
        float f = context.getResources().getDisplayMetrics().density;
        this.f753y = (int) (56.0f * f);
        this.f754z = (int) (f * 4.0f);
        this.f745q = context;
    }

    /* renamed from: G */
    static int m920G(View view, int i, int i2, int i3, int i4) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(i3) - i4, View.MeasureSpec.getMode(i3));
        ActionMenuItemView actionMenuItemView = view instanceof ActionMenuItemView ? (ActionMenuItemView) view : null;
        boolean z = false;
        boolean z2 = actionMenuItemView != null && actionMenuItemView.mo610d();
        int i5 = 2;
        if (i2 <= 0 || (z2 && i2 < 2)) {
            i5 = 0;
        } else {
            view.measure(View.MeasureSpec.makeMeasureSpec(i2 * i, RecyclerView.UNDEFINED_DURATION), makeMeasureSpec);
            int measuredWidth = view.getMeasuredWidth();
            int i6 = measuredWidth / i;
            if (measuredWidth % i != 0) {
                i6++;
            }
            if (!z2 || i6 >= 2) {
                i5 = i6;
            }
        }
        if (!layoutParams.f755c && z2) {
            z = true;
        }
        layoutParams.f758f = z;
        layoutParams.f756d = i5;
        view.measure(View.MeasureSpec.makeMeasureSpec(i * i5, 1073741824), makeMeasureSpec);
        return i5;
    }

    /* renamed from: A */
    public Menu mo1112A() {
        if (this.f744p == null) {
            Context context = getContext();
            C0163g gVar = new C0163g(context);
            this.f744p = gVar;
            gVar.mo758G(new C0204c());
            ActionMenuPresenter actionMenuPresenter = new ActionMenuPresenter(context);
            this.f748t = actionMenuPresenter;
            actionMenuPresenter.mo1100E(true);
            ActionMenuPresenter actionMenuPresenter2 = this.f748t;
            C0178m.C0179a aVar = this.f749u;
            if (aVar == null) {
                aVar = new C0203b();
            }
            actionMenuPresenter2.mo695g(aVar);
            this.f744p.mo780c(this.f748t, this.f745q);
            this.f748t.mo1099D(this);
        }
        return this.f744p;
    }

    /* access modifiers changed from: protected */
    /* renamed from: B */
    public boolean mo1113B(int i) {
        boolean z = false;
        if (i == 0) {
            return false;
        }
        View childAt = getChildAt(i - 1);
        View childAt2 = getChildAt(i);
        if (i < getChildCount() && (childAt instanceof C0202a)) {
            z = false | ((C0202a) childAt).mo607a();
        }
        return (i <= 0 || !(childAt2 instanceof C0202a)) ? z : z | ((C0202a) childAt2).mo609c();
    }

    /* renamed from: C */
    public boolean mo1114C() {
        ActionMenuPresenter actionMenuPresenter = this.f748t;
        return actionMenuPresenter != null && actionMenuPresenter.mo1103z();
    }

    /* renamed from: D */
    public boolean mo1115D() {
        ActionMenuPresenter actionMenuPresenter = this.f748t;
        if (actionMenuPresenter != null) {
            if (actionMenuPresenter.f730u != null || actionMenuPresenter.mo1096A()) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: E */
    public boolean mo1116E() {
        ActionMenuPresenter actionMenuPresenter = this.f748t;
        return actionMenuPresenter != null && actionMenuPresenter.mo1096A();
    }

    /* renamed from: F */
    public boolean mo1117F() {
        return this.f747s;
    }

    /* renamed from: H */
    public C0163g mo1118H() {
        return this.f744p;
    }

    /* renamed from: I */
    public void mo1119I(boolean z) {
        this.f748t.mo1098C(z);
    }

    /* renamed from: J */
    public void mo1120J(C0178m.C0179a aVar, C0163g.C0164a aVar2) {
        this.f749u = null;
        this.f750v = null;
    }

    /* renamed from: K */
    public void mo1121K(boolean z) {
        this.f747s = z;
    }

    /* renamed from: L */
    public void mo1122L(int i) {
        if (this.f746r != i) {
            this.f746r = i;
            if (i == 0) {
                this.f745q = getContext();
            } else {
                this.f745q = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    /* renamed from: M */
    public void mo1123M(ActionMenuPresenter actionMenuPresenter) {
        this.f748t = actionMenuPresenter;
        actionMenuPresenter.mo1099D(this);
    }

    /* renamed from: N */
    public boolean mo1124N() {
        ActionMenuPresenter actionMenuPresenter = this.f748t;
        return actionMenuPresenter != null && actionMenuPresenter.mo1101F();
    }

    /* renamed from: a */
    public boolean mo624a(C0167i iVar) {
        return this.f744p.mo820z(iVar, (C0178m) null, 0);
    }

    /* renamed from: c */
    public void mo625c(C0163g gVar) {
        this.f744p = gVar;
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    /* renamed from: k */
    public LinearLayoutCompat.LayoutParams mo1131k(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        ActionMenuPresenter actionMenuPresenter = this.f748t;
        if (actionMenuPresenter != null) {
            actionMenuPresenter.mo692c(false);
            if (this.f748t.mo1096A()) {
                this.f748t.mo1103z();
                this.f748t.mo1101F();
            }
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ActionMenuPresenter actionMenuPresenter = this.f748t;
        if (actionMenuPresenter != null) {
            actionMenuPresenter.mo1102y();
        }
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        if (!this.f751w) {
            super.onLayout(z, i, i2, i3, i4);
            return;
        }
        int childCount = getChildCount();
        int i7 = (i4 - i2) / 2;
        int o = mo1376o();
        int i8 = i3 - i;
        int paddingRight = (i8 - getPaddingRight()) - getPaddingLeft();
        boolean b = C0280l0.m1310b(this);
        int i9 = 0;
        int i10 = 0;
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (layoutParams.f755c) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (mo1113B(i11)) {
                        measuredWidth += o;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (b) {
                        i5 = getPaddingLeft() + layoutParams.leftMargin;
                        i6 = i5 + measuredWidth;
                    } else {
                        i6 = (getWidth() - getPaddingRight()) - layoutParams.rightMargin;
                        i5 = i6 - measuredWidth;
                    }
                    int i12 = i7 - (measuredHeight / 2);
                    childAt.layout(i5, i12, i6, measuredHeight + i12);
                    paddingRight -= measuredWidth;
                    i9 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + layoutParams.leftMargin) + layoutParams.rightMargin;
                    mo1113B(i11);
                    i10++;
                }
            }
        }
        if (childCount == 1 && i9 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i13 = (i8 / 2) - (measuredWidth2 / 2);
            int i14 = i7 - (measuredHeight2 / 2);
            childAt2.layout(i13, i14, measuredWidth2 + i13, measuredHeight2 + i14);
            return;
        }
        int i15 = i10 - (i9 ^ 1);
        int max = Math.max(0, i15 > 0 ? paddingRight / i15 : 0);
        if (b) {
            int width = getWidth() - getPaddingRight();
            for (int i16 = 0; i16 < childCount; i16++) {
                View childAt3 = getChildAt(i16);
                LayoutParams layoutParams2 = (LayoutParams) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !layoutParams2.f755c) {
                    int i17 = width - layoutParams2.rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i18 = i7 - (measuredHeight3 / 2);
                    childAt3.layout(i17 - measuredWidth3, i18, i17, measuredHeight3 + i18);
                    width = i17 - ((measuredWidth3 + layoutParams2.leftMargin) + max);
                }
            }
            return;
        }
        int paddingLeft = getPaddingLeft();
        for (int i19 = 0; i19 < childCount; i19++) {
            View childAt4 = getChildAt(i19);
            LayoutParams layoutParams3 = (LayoutParams) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !layoutParams3.f755c) {
                int i20 = paddingLeft + layoutParams3.leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i21 = i7 - (measuredHeight4 / 2);
                childAt4.layout(i20, i21, i20 + measuredWidth4, measuredHeight4 + i21);
                paddingLeft = measuredWidth4 + layoutParams3.rightMargin + max + i20;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3;
        boolean z;
        int i4;
        int i5;
        boolean z2;
        int i6;
        boolean z3;
        C0163g gVar;
        boolean z4 = this.f751w;
        boolean z5 = View.MeasureSpec.getMode(i) == 1073741824;
        this.f751w = z5;
        if (z4 != z5) {
            this.f752x = 0;
        }
        int size = View.MeasureSpec.getSize(i);
        if (!(!this.f751w || (gVar = this.f744p) == null || size == this.f752x)) {
            this.f752x = size;
            gVar.mo818x(true);
        }
        int childCount = getChildCount();
        if (!this.f751w || childCount <= 0) {
            int i7 = i2;
            for (int i8 = 0; i8 < childCount; i8++) {
                LayoutParams layoutParams = (LayoutParams) getChildAt(i8).getLayoutParams();
                layoutParams.rightMargin = 0;
                layoutParams.leftMargin = 0;
            }
            super.onMeasure(i, i2);
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        int size2 = View.MeasureSpec.getSize(i);
        int size3 = View.MeasureSpec.getSize(i2);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, paddingBottom, -2);
        int i9 = size2 - paddingRight;
        int i10 = this.f753y;
        int i11 = i9 / i10;
        int i12 = i9 % i10;
        if (i11 == 0) {
            setMeasuredDimension(i9, 0);
            return;
        }
        int i13 = (i12 / i11) + i10;
        int childCount2 = getChildCount();
        int i14 = 0;
        int i15 = 0;
        int i16 = 0;
        int i17 = 0;
        int i18 = 0;
        boolean z6 = false;
        long j = 0;
        while (i18 < childCount2) {
            View childAt = getChildAt(i18);
            int i19 = size3;
            int i20 = i9;
            if (childAt.getVisibility() != 8) {
                boolean z7 = childAt instanceof ActionMenuItemView;
                int i21 = i14 + 1;
                if (z7) {
                    int i22 = this.f754z;
                    i6 = i21;
                    z3 = false;
                    childAt.setPadding(i22, 0, i22, 0);
                } else {
                    i6 = i21;
                    z3 = false;
                }
                LayoutParams layoutParams2 = (LayoutParams) childAt.getLayoutParams();
                layoutParams2.f760h = z3;
                layoutParams2.f757e = z3 ? 1 : 0;
                layoutParams2.f756d = z3;
                layoutParams2.f758f = z3;
                layoutParams2.leftMargin = z3;
                layoutParams2.rightMargin = z3;
                layoutParams2.f759g = z7 && ((ActionMenuItemView) childAt).mo610d();
                int G = m920G(childAt, i13, layoutParams2.f755c ? 1 : i11, childMeasureSpec, paddingBottom);
                i16 = Math.max(i16, G);
                if (layoutParams2.f758f) {
                    i17++;
                }
                if (layoutParams2.f755c) {
                    z6 = true;
                }
                i11 -= G;
                i15 = Math.max(i15, childAt.getMeasuredHeight());
                if (G == 1) {
                    j |= (long) (1 << i18);
                }
                i14 = i6;
            }
            i18++;
            size3 = i19;
            i9 = i20;
        }
        int i23 = i9;
        int i24 = size3;
        boolean z8 = z6 && i14 == 2;
        boolean z9 = false;
        while (true) {
            if (i17 <= 0 || i11 <= 0) {
                i3 = i15;
                z = z9;
            } else {
                int i25 = C4291a.C4299e.API_PRIORITY_OTHER;
                int i26 = 0;
                int i27 = 0;
                long j2 = 0;
                while (i26 < childCount2) {
                    int i28 = i15;
                    LayoutParams layoutParams3 = (LayoutParams) getChildAt(i26).getLayoutParams();
                    boolean z10 = z9;
                    if (layoutParams3.f758f) {
                        int i29 = layoutParams3.f756d;
                        if (i29 < i25) {
                            j2 = 1 << i26;
                            i25 = i29;
                            i27 = 1;
                        } else if (i29 == i25) {
                            i27++;
                            j2 |= 1 << i26;
                        }
                    }
                    i26++;
                    z9 = z10;
                    i15 = i28;
                }
                i3 = i15;
                z = z9;
                j |= j2;
                if (i27 > i11) {
                    break;
                }
                int i30 = i25 + 1;
                int i31 = 0;
                while (i31 < childCount2) {
                    View childAt2 = getChildAt(i31);
                    LayoutParams layoutParams4 = (LayoutParams) childAt2.getLayoutParams();
                    int i32 = i17;
                    long j3 = (long) (1 << i31);
                    if ((j2 & j3) == 0) {
                        if (layoutParams4.f756d == i30) {
                            j |= j3;
                        }
                        z2 = z8;
                    } else {
                        if (!z8 || !layoutParams4.f759g || i11 != 1) {
                            z2 = z8;
                        } else {
                            int i33 = this.f754z;
                            z2 = z8;
                            childAt2.setPadding(i33 + i13, 0, i33, 0);
                        }
                        layoutParams4.f756d++;
                        layoutParams4.f760h = true;
                        i11--;
                    }
                    i31++;
                    i17 = i32;
                    z8 = z2;
                }
                i15 = i3;
                z9 = true;
            }
        }
        i3 = i15;
        z = z9;
        boolean z11 = !z6 && i14 == 1;
        if (i11 > 0 && j != 0 && (i11 < i14 - 1 || z11 || i16 > 1)) {
            float bitCount = (float) Long.bitCount(j);
            if (!z11) {
                if ((j & 1) != 0 && !((LayoutParams) getChildAt(0).getLayoutParams()).f759g) {
                    bitCount -= 0.5f;
                }
                int i34 = childCount2 - 1;
                if ((j & ((long) (1 << i34))) != 0 && !((LayoutParams) getChildAt(i34).getLayoutParams()).f759g) {
                    bitCount -= 0.5f;
                }
            }
            int i35 = bitCount > 0.0f ? (int) (((float) (i11 * i13)) / bitCount) : 0;
            for (int i36 = 0; i36 < childCount2; i36++) {
                if ((j & ((long) (1 << i36))) != 0) {
                    View childAt3 = getChildAt(i36);
                    LayoutParams layoutParams5 = (LayoutParams) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        layoutParams5.f757e = i35;
                        layoutParams5.f760h = true;
                        if (i36 == 0 && !layoutParams5.f759g) {
                            layoutParams5.leftMargin = (-i35) / 2;
                        }
                    } else if (layoutParams5.f755c) {
                        layoutParams5.f757e = i35;
                        layoutParams5.f760h = true;
                        layoutParams5.rightMargin = (-i35) / 2;
                    } else {
                        if (i36 != 0) {
                            layoutParams5.leftMargin = i35 / 2;
                        }
                        if (i36 != childCount2 - 1) {
                            layoutParams5.rightMargin = i35 / 2;
                        }
                    }
                    z = true;
                }
            }
        }
        if (z) {
            for (int i37 = 0; i37 < childCount2; i37++) {
                View childAt4 = getChildAt(i37);
                LayoutParams layoutParams6 = (LayoutParams) childAt4.getLayoutParams();
                if (layoutParams6.f760h) {
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((layoutParams6.f756d * i13) + layoutParams6.f757e, 1073741824), childMeasureSpec);
                }
            }
        }
        if (mode != 1073741824) {
            i5 = i23;
            i4 = i3;
        } else {
            i4 = i24;
            i5 = i23;
        }
        setMeasuredDimension(i5, i4);
    }

    /* renamed from: x */
    public void mo1137x() {
        ActionMenuPresenter actionMenuPresenter = this.f748t;
        if (actionMenuPresenter != null) {
            actionMenuPresenter.mo1102y();
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: y */
    public LayoutParams mo1130j() {
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        layoutParams.f865b = 16;
        return layoutParams;
    }

    /* access modifiers changed from: protected */
    /* renamed from: z */
    public LayoutParams mo1132l(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams == null) {
            return mo1130j();
        }
        LayoutParams layoutParams2 = layoutParams instanceof LayoutParams ? new LayoutParams((LayoutParams) layoutParams) : new LayoutParams(layoutParams);
        if (layoutParams2.f865b <= 0) {
            layoutParams2.f865b = 16;
        }
        return layoutParams2;
    }
}
