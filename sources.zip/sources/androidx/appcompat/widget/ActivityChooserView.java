package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.C0183p;
import com.vidio.android.p195tv.R;
import java.util.Objects;
import p098d.p099a.C4568b;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.p131w.C4791b;

public class ActivityChooserView extends ViewGroup {

    /* renamed from: a */
    final C0211f f762a;

    /* renamed from: b */
    private final C0212g f763b;

    /* renamed from: c */
    private final View f764c;

    /* renamed from: d */
    private final Drawable f765d;

    /* renamed from: e */
    final FrameLayout f766e;

    /* renamed from: f */
    private final ImageView f767f;

    /* renamed from: g */
    final FrameLayout f768g;

    /* renamed from: h */
    private final ImageView f769h;

    /* renamed from: i */
    private final int f770i;

    /* renamed from: j */
    final DataSetObserver f771j;

    /* renamed from: k */
    private final ViewTreeObserver.OnGlobalLayoutListener f772k;

    /* renamed from: l */
    private ListPopupWindow f773l;

    /* renamed from: m */
    int f774m;

    /* renamed from: n */
    private boolean f775n;

    public static class InnerLayout extends LinearLayout {

        /* renamed from: a */
        private static final int[] f776a = {16842964};

        public InnerLayout(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            C0259e0 u = C0259e0.m1180u(context, attributeSet, f776a);
            setBackgroundDrawable(u.mo1596g(0));
            u.mo1609w();
        }
    }

    /* renamed from: androidx.appcompat.widget.ActivityChooserView$a */
    class C0206a extends DataSetObserver {
        C0206a() {
        }

        public void onChanged() {
            super.onChanged();
            ActivityChooserView.this.f762a.notifyDataSetChanged();
        }

        public void onInvalidated() {
            super.onInvalidated();
            ActivityChooserView.this.f762a.notifyDataSetInvalidated();
        }
    }

    /* renamed from: androidx.appcompat.widget.ActivityChooserView$b */
    class C0207b implements ViewTreeObserver.OnGlobalLayoutListener {
        C0207b() {
        }

        public void onGlobalLayout() {
            if (!ActivityChooserView.this.mo1142c()) {
                return;
            }
            if (!ActivityChooserView.this.isShown()) {
                ActivityChooserView.this.mo1141b().dismiss();
                return;
            }
            ActivityChooserView.this.mo1141b().show();
            Objects.requireNonNull(ActivityChooserView.this);
        }
    }

    /* renamed from: androidx.appcompat.widget.ActivityChooserView$c */
    class C0208c extends View.AccessibilityDelegate {
        C0208c(ActivityChooserView activityChooserView) {
        }

        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo);
            C4791b.m17409w0(accessibilityNodeInfo).mo21930P(true);
        }
    }

    /* renamed from: androidx.appcompat.widget.ActivityChooserView$d */
    class C0209d extends C0289r {
        C0209d(View view) {
            super(view);
        }

        /* renamed from: b */
        public C0183p mo621b() {
            return ActivityChooserView.this.mo1141b();
        }

        /* access modifiers changed from: protected */
        /* renamed from: c */
        public boolean mo622c() {
            ActivityChooserView.this.mo1143d();
            return true;
        }

        /* access modifiers changed from: protected */
        /* renamed from: d */
        public boolean mo1111d() {
            ActivityChooserView.this.mo1140a();
            return true;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActivityChooserView$e */
    class C0210e extends DataSetObserver {
        C0210e() {
        }

        public void onChanged() {
            super.onChanged();
            Objects.requireNonNull(ActivityChooserView.this.f762a);
            throw null;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActivityChooserView$f */
    private class C0211f extends BaseAdapter {

        /* renamed from: a */
        private int f781a = 4;

        /* renamed from: b */
        private boolean f782b;

        /* renamed from: c */
        private boolean f783c;

        C0211f() {
        }

        /* renamed from: a */
        public boolean mo1154a() {
            return this.f782b;
        }

        public int getCount() {
            throw null;
        }

        public Object getItem(int i) {
            if (!this.f783c) {
                boolean z = this.f782b;
                throw null;
            }
            throw null;
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public int getItemViewType(int i) {
            if (!this.f783c) {
                return 0;
            }
            throw null;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            if (!this.f783c) {
                if (view == null || view.getId() != R.id.list_item) {
                    view = LayoutInflater.from(ActivityChooserView.this.getContext()).inflate(R.layout.abc_activity_chooser_view_list_item, viewGroup, false);
                }
                ActivityChooserView.this.getContext().getPackageManager();
                ImageView imageView = (ImageView) view.findViewById(R.id.icon);
                if (!this.f783c) {
                    throw null;
                }
                throw null;
            }
            throw null;
        }

        public int getViewTypeCount() {
            return 3;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActivityChooserView$g */
    private class C0212g implements AdapterView.OnItemClickListener, View.OnClickListener, View.OnLongClickListener, PopupWindow.OnDismissListener {
        C0212g() {
        }

        public void onClick(View view) {
            ActivityChooserView activityChooserView = ActivityChooserView.this;
            if (view == activityChooserView.f768g) {
                activityChooserView.mo1140a();
                Objects.requireNonNull(ActivityChooserView.this.f762a);
                throw null;
            } else if (view == activityChooserView.f766e) {
                activityChooserView.mo1144e(activityChooserView.f774m);
                throw null;
            } else {
                throw new IllegalArgumentException();
            }
        }

        public void onDismiss() {
            Objects.requireNonNull(ActivityChooserView.this);
            Objects.requireNonNull(ActivityChooserView.this);
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            ((C0211f) adapterView.getAdapter()).getItemViewType(i);
            ActivityChooserView.this.mo1140a();
            ActivityChooserView activityChooserView = ActivityChooserView.this;
            Objects.requireNonNull(activityChooserView);
            activityChooserView.f762a.mo1154a();
            Objects.requireNonNull(ActivityChooserView.this.f762a);
            throw null;
        }

        public boolean onLongClick(View view) {
            ActivityChooserView activityChooserView = ActivityChooserView.this;
            if (view == activityChooserView.f768g) {
                Objects.requireNonNull(activityChooserView.f762a);
                throw null;
            }
            throw new IllegalArgumentException();
        }
    }

    public ActivityChooserView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ActivityChooserView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f771j = new C0206a();
        this.f772k = new C0207b();
        this.f774m = 4;
        int[] iArr = C4568b.f16457e;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i, 0);
        C4761m.m17309r(this, context, iArr, attributeSet, obtainStyledAttributes, i, 0);
        this.f774m = obtainStyledAttributes.getInt(1, 4);
        Drawable drawable = obtainStyledAttributes.getDrawable(0);
        obtainStyledAttributes.recycle();
        LayoutInflater.from(getContext()).inflate(R.layout.abc_activity_chooser_view, this, true);
        C0212g gVar = new C0212g();
        this.f763b = gVar;
        View findViewById = findViewById(R.id.activity_chooser_view_content);
        this.f764c = findViewById;
        this.f765d = findViewById.getBackground();
        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.default_activity_button);
        this.f768g = frameLayout;
        frameLayout.setOnClickListener(gVar);
        frameLayout.setOnLongClickListener(gVar);
        this.f769h = (ImageView) frameLayout.findViewById(R.id.image);
        FrameLayout frameLayout2 = (FrameLayout) findViewById(R.id.expand_activities_button);
        frameLayout2.setOnClickListener(gVar);
        frameLayout2.setAccessibilityDelegate(new C0208c(this));
        frameLayout2.setOnTouchListener(new C0209d(frameLayout2));
        this.f766e = frameLayout2;
        ImageView imageView = (ImageView) frameLayout2.findViewById(R.id.image);
        this.f767f = imageView;
        imageView.setImageDrawable(drawable);
        C0211f fVar = new C0211f();
        this.f762a = fVar;
        fVar.registerDataSetObserver(new C0210e());
        Resources resources = context.getResources();
        this.f770i = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
    }

    /* renamed from: a */
    public boolean mo1140a() {
        if (!mo1142c()) {
            return true;
        }
        mo1141b().dismiss();
        ViewTreeObserver viewTreeObserver = getViewTreeObserver();
        if (!viewTreeObserver.isAlive()) {
            return true;
        }
        viewTreeObserver.removeGlobalOnLayoutListener(this.f772k);
        return true;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public ListPopupWindow mo1141b() {
        if (this.f773l == null) {
            ListPopupWindow listPopupWindow = new ListPopupWindow(getContext(), (AttributeSet) null, R.attr.listPopupWindowStyle);
            this.f773l = listPopupWindow;
            listPopupWindow.mo1304o(this.f762a);
            this.f773l.mo1409w(this);
            this.f773l.mo1391C(true);
            this.f773l.mo1393E(this.f763b);
            ListPopupWindow listPopupWindow2 = this.f773l;
            listPopupWindow2.f871C.setOnDismissListener(this.f763b);
        }
        return this.f773l;
    }

    /* renamed from: c */
    public boolean mo1142c() {
        return mo1141b().mo710a();
    }

    /* renamed from: d */
    public boolean mo1143d() {
        if (mo1142c() || !this.f775n) {
            return false;
        }
        mo1144e(this.f774m);
        throw null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo1144e(int i) {
        Objects.requireNonNull(this.f762a);
        throw new IllegalStateException("No data model. Did you call #setDataModel?");
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Objects.requireNonNull(this.f762a);
        this.f775n = true;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Objects.requireNonNull(this.f762a);
        ViewTreeObserver viewTreeObserver = getViewTreeObserver();
        if (viewTreeObserver.isAlive()) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f772k);
        }
        if (mo1142c()) {
            mo1140a();
        }
        this.f775n = false;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.f764c.layout(0, 0, i3 - i, i4 - i2);
        if (!mo1142c()) {
            mo1140a();
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        View view = this.f764c;
        if (this.f768g.getVisibility() != 0) {
            i2 = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(i2), 1073741824);
        }
        measureChild(view, i, i2);
        setMeasuredDimension(view.getMeasuredWidth(), view.getMeasuredHeight());
    }
}
