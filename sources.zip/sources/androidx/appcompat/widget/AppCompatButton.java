package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import androidx.core.widget.C0501b;
import androidx.core.widget.C0502c;
import androidx.core.widget.C0505f;
import com.vidio.android.p195tv.R;

public class AppCompatButton extends Button implements C0501b, C0505f {
    private final C0253c mBackgroundTintHelper;
    private final C0273k mTextHelper;

    public AppCompatButton(Context context) {
        this(context, (AttributeSet) null);
    }

    public AppCompatButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.buttonStyle);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        C0252b0.m1152a(context);
        C0306z.m1392a(this, getContext());
        C0253c cVar = new C0253c(this);
        this.mBackgroundTintHelper = cVar;
        cVar.mo1574d(attributeSet, i);
        C0273k kVar = new C0273k(this);
        this.mTextHelper = kVar;
        kVar.mo1670m(attributeSet, i);
        kVar.mo1660b();
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            cVar.mo1571a();
        }
        C0273k kVar = this.mTextHelper;
        if (kVar != null) {
            kVar.mo1660b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (C0501b.f2326S) {
            return super.getAutoSizeMaxTextSize();
        }
        C0273k kVar = this.mTextHelper;
        if (kVar != null) {
            return kVar.mo1662e();
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (C0501b.f2326S) {
            return super.getAutoSizeMinTextSize();
        }
        C0273k kVar = this.mTextHelper;
        if (kVar != null) {
            return kVar.mo1663f();
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (C0501b.f2326S) {
            return super.getAutoSizeStepGranularity();
        }
        C0273k kVar = this.mTextHelper;
        if (kVar != null) {
            return kVar.mo1664g();
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (C0501b.f2326S) {
            return super.getAutoSizeTextAvailableSizes();
        }
        C0273k kVar = this.mTextHelper;
        return kVar != null ? kVar.mo1665h() : new int[0];
    }

    public int getAutoSizeTextType() {
        if (C0501b.f2326S) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        C0273k kVar = this.mTextHelper;
        if (kVar != null) {
            return kVar.mo1666i();
        }
        return 0;
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            return cVar.mo1572b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            return cVar.mo1573c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.mTextHelper.mo1667j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.mTextHelper.mo1668k();
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        C0273k kVar = this.mTextHelper;
        if (kVar != null) {
            kVar.mo1672o();
        }
    }

    /* access modifiers changed from: protected */
    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        C0273k kVar = this.mTextHelper;
        if (kVar != null && !C0501b.f2326S && kVar.mo1669l()) {
            this.mTextHelper.mo1661c();
        }
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) throws IllegalArgumentException {
        if (C0501b.f2326S) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        C0273k kVar = this.mTextHelper;
        if (kVar != null) {
            kVar.mo1675r(i, i2, i3, i4);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) throws IllegalArgumentException {
        if (C0501b.f2326S) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        C0273k kVar = this.mTextHelper;
        if (kVar != null) {
            kVar.mo1676s(iArr, i);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (C0501b.f2326S) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        C0273k kVar = this.mTextHelper;
        if (kVar != null) {
            kVar.mo1677t(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            cVar.mo1575e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            cVar.mo1576f(i);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C0502c.m2298h(this, callback));
    }

    public void setSupportAllCaps(boolean z) {
        C0273k kVar = this.mTextHelper;
        if (kVar != null) {
            kVar.mo1674q(z);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            cVar.mo1578h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            cVar.mo1579i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.mTextHelper.mo1678u(colorStateList);
        this.mTextHelper.mo1660b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.mTextHelper.mo1679v(mode);
        this.mTextHelper.mo1660b();
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C0273k kVar = this.mTextHelper;
        if (kVar != null) {
            kVar.mo1673p(context, i);
        }
    }

    public void setTextSize(int i, float f) {
        if (C0501b.f2326S) {
            super.setTextSize(i, f);
            return;
        }
        C0273k kVar = this.mTextHelper;
        if (kVar != null) {
            kVar.mo1680w(i, f);
        }
    }
}
