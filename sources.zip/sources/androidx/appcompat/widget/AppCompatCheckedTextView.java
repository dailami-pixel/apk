package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import androidx.core.widget.C0502c;
import p098d.p099a.p100c.p101a.C4569a;

public class AppCompatCheckedTextView extends CheckedTextView {

    /* renamed from: a */
    private static final int[] f792a = {16843016};

    /* renamed from: b */
    private final C0273k f793b;

    public AppCompatCheckedTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16843720);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatCheckedTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        C0252b0.m1152a(context);
        C0306z.m1392a(this, getContext());
        C0273k kVar = new C0273k(this);
        this.f793b = kVar;
        kVar.mo1670m(attributeSet, i);
        kVar.mo1660b();
        C0259e0 v = C0259e0.m1181v(getContext(), attributeSet, f792a, i, 0);
        setCheckMarkDrawable(v.mo1596g(0));
        v.mo1609w();
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0273k kVar = this.f793b;
        if (kVar != null) {
            kVar.mo1660b();
        }
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        C0266h0.m1245a(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    public void setCheckMarkDrawable(int i) {
        setCheckMarkDrawable(C4569a.m16431b(getContext(), i));
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C0502c.m2298h(this, callback));
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C0273k kVar = this.f793b;
        if (kVar != null) {
            kVar.mo1673p(context, i);
        }
    }
}
