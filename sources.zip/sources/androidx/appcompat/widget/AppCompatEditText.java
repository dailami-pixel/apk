package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import androidx.core.widget.C0502c;
import com.vidio.android.p195tv.R;

public class AppCompatEditText extends EditText {

    /* renamed from: a */
    private final C0253c f794a;

    /* renamed from: b */
    private final C0273k f795b;

    /* renamed from: c */
    private final C0271j f796c;

    public AppCompatEditText(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.editTextStyle);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatEditText(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        C0252b0.m1152a(context);
        C0306z.m1392a(this, getContext());
        C0253c cVar = new C0253c(this);
        this.f794a = cVar;
        cVar.mo1574d(attributeSet, i);
        C0273k kVar = new C0273k(this);
        this.f795b = kVar;
        kVar.mo1670m(attributeSet, i);
        kVar.mo1660b();
        this.f796c = new C0271j(this);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0253c cVar = this.f794a;
        if (cVar != null) {
            cVar.mo1571a();
        }
        C0273k kVar = this.f795b;
        if (kVar != null) {
            kVar.mo1660b();
        }
    }

    public Editable getText() {
        return Build.VERSION.SDK_INT >= 28 ? super.getText() : super.getEditableText();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r2.f796c;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.textclassifier.TextClassifier getTextClassifier() {
        /*
            r2 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 28
            if (r0 >= r1) goto L_0x0010
            androidx.appcompat.widget.j r0 = r2.f796c
            if (r0 != 0) goto L_0x000b
            goto L_0x0010
        L_0x000b:
            android.view.textclassifier.TextClassifier r0 = r0.mo1656a()
            return r0
        L_0x0010:
            android.view.textclassifier.TextClassifier r0 = super.getTextClassifier()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.AppCompatEditText.getTextClassifier():android.view.textclassifier.TextClassifier");
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        C0266h0.m1245a(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0253c cVar = this.f794a;
        if (cVar != null) {
            cVar.mo1575e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0253c cVar = this.f794a;
        if (cVar != null) {
            cVar.mo1576f(i);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C0502c.m2298h(this, callback));
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C0273k kVar = this.f795b;
        if (kVar != null) {
            kVar.mo1673p(context, i);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        C0271j jVar;
        if (Build.VERSION.SDK_INT >= 28 || (jVar = this.f796c) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            jVar.mo1657b(textClassifier);
        }
    }
}
