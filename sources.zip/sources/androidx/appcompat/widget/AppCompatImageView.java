package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;

public class AppCompatImageView extends ImageView {
    private final C0253c mBackgroundTintHelper;
    private final C0260f mImageHelper;

    public AppCompatImageView(Context context) {
        this(context, (AttributeSet) null);
    }

    public AppCompatImageView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        C0252b0.m1152a(context);
        C0306z.m1392a(this, getContext());
        C0253c cVar = new C0253c(this);
        this.mBackgroundTintHelper = cVar;
        cVar.mo1574d(attributeSet, i);
        C0260f fVar = new C0260f(this);
        this.mImageHelper = fVar;
        fVar.mo1614e(attributeSet, i);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            cVar.mo1571a();
        }
        C0260f fVar = this.mImageHelper;
        if (fVar != null) {
            fVar.mo1610a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            return cVar.mo1572b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            return cVar.mo1573c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        C0260f fVar = this.mImageHelper;
        if (fVar != null) {
            return fVar.mo1611b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        C0260f fVar = this.mImageHelper;
        if (fVar != null) {
            return fVar.mo1612c();
        }
        return null;
    }

    public boolean hasOverlappingRendering() {
        return this.mImageHelper.mo1613d() && super.hasOverlappingRendering();
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            cVar.mo1575e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            cVar.mo1576f(i);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        C0260f fVar = this.mImageHelper;
        if (fVar != null) {
            fVar.mo1610a();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        C0260f fVar = this.mImageHelper;
        if (fVar != null) {
            fVar.mo1610a();
        }
    }

    public void setImageResource(int i) {
        C0260f fVar = this.mImageHelper;
        if (fVar != null) {
            fVar.mo1615f(i);
        }
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        C0260f fVar = this.mImageHelper;
        if (fVar != null) {
            fVar.mo1610a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            cVar.mo1578h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0253c cVar = this.mBackgroundTintHelper;
        if (cVar != null) {
            cVar.mo1579i(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        C0260f fVar = this.mImageHelper;
        if (fVar != null) {
            fVar.mo1616g(colorStateList);
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        C0260f fVar = this.mImageHelper;
        if (fVar != null) {
            fVar.mo1617h(mode);
        }
    }
}
