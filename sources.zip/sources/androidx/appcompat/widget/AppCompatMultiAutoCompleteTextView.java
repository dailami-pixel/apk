package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.MultiAutoCompleteTextView;
import com.vidio.android.p195tv.R;
import p098d.p099a.p100c.p101a.C4569a;

public class AppCompatMultiAutoCompleteTextView extends MultiAutoCompleteTextView {

    /* renamed from: a */
    private static final int[] f799a = {16843126};

    /* renamed from: b */
    private final C0253c f800b;

    /* renamed from: c */
    private final C0273k f801c;

    public AppCompatMultiAutoCompleteTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.autoCompleteTextViewStyle);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatMultiAutoCompleteTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        C0252b0.m1152a(context);
        C0306z.m1392a(this, getContext());
        C0259e0 v = C0259e0.m1181v(getContext(), attributeSet, f799a, i, 0);
        if (v.mo1608s(0)) {
            setDropDownBackgroundDrawable(v.mo1596g(0));
        }
        v.mo1609w();
        C0253c cVar = new C0253c(this);
        this.f800b = cVar;
        cVar.mo1574d(attributeSet, i);
        C0273k kVar = new C0273k(this);
        this.f801c = kVar;
        kVar.mo1670m(attributeSet, i);
        kVar.mo1660b();
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0253c cVar = this.f800b;
        if (cVar != null) {
            cVar.mo1571a();
        }
        C0273k kVar = this.f801c;
        if (kVar != null) {
            kVar.mo1660b();
        }
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        C0266h0.m1245a(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0253c cVar = this.f800b;
        if (cVar != null) {
            cVar.mo1575e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0253c cVar = this.f800b;
        if (cVar != null) {
            cVar.mo1576f(i);
        }
    }

    public void setDropDownBackgroundResource(int i) {
        setDropDownBackgroundDrawable(C4569a.m16431b(getContext(), i));
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C0273k kVar = this.f801c;
        if (kVar != null) {
            kVar.mo1673p(context, i);
        }
    }
}
