package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.PopupWindow;
import androidx.core.widget.C0502c;
import p098d.p099a.C4568b;

class AppCompatPopupWindow extends PopupWindow {
    public AppCompatPopupWindow(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        m958a(context, attributeSet, i, 0);
    }

    public AppCompatPopupWindow(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        m958a(context, attributeSet, i, i2);
    }

    /* renamed from: a */
    private void m958a(Context context, AttributeSet attributeSet, int i, int i2) {
        C0259e0 v = C0259e0.m1181v(context, attributeSet, C4568b.f16472t, i, i2);
        if (v.mo1608s(2)) {
            C0502c.m2295e(this, v.mo1590a(2, false));
        }
        setBackgroundDrawable(v.mo1596g(0));
        v.mo1609w();
    }

    public void showAsDropDown(View view, int i, int i2) {
        super.showAsDropDown(view, i, i2);
    }

    public void showAsDropDown(View view, int i, int i2, int i3) {
        super.showAsDropDown(view, i, i2, i3);
    }

    public void update(View view, int i, int i2, int i3, int i4) {
        super.update(view, i, i2, i3, i4);
    }
}
