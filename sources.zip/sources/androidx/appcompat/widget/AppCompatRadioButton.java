package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.RadioButton;
import com.vidio.android.p195tv.R;
import p098d.p099a.p100c.p101a.C4569a;

public class AppCompatRadioButton extends RadioButton {

    /* renamed from: a */
    private final C0255d f802a;

    /* renamed from: b */
    private final C0253c f803b;

    /* renamed from: c */
    private final C0273k f804c;

    public AppCompatRadioButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.radioButtonStyle);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatRadioButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        C0252b0.m1152a(context);
        C0306z.m1392a(this, getContext());
        C0255d dVar = new C0255d(this);
        this.f802a = dVar;
        dVar.mo1581b(attributeSet, i);
        C0253c cVar = new C0253c(this);
        this.f803b = cVar;
        cVar.mo1574d(attributeSet, i);
        C0273k kVar = new C0273k(this);
        this.f804c = kVar;
        kVar.mo1670m(attributeSet, i);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0253c cVar = this.f803b;
        if (cVar != null) {
            cVar.mo1571a();
        }
        C0273k kVar = this.f804c;
        if (kVar != null) {
            kVar.mo1660b();
        }
    }

    public int getCompoundPaddingLeft() {
        int compoundPaddingLeft = super.getCompoundPaddingLeft();
        C0255d dVar = this.f802a;
        return compoundPaddingLeft;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0253c cVar = this.f803b;
        if (cVar != null) {
            cVar.mo1575e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0253c cVar = this.f803b;
        if (cVar != null) {
            cVar.mo1576f(i);
        }
    }

    public void setButtonDrawable(int i) {
        setButtonDrawable(C4569a.m16431b(getContext(), i));
    }

    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        C0255d dVar = this.f802a;
        if (dVar != null) {
            dVar.mo1582c();
        }
    }
}
