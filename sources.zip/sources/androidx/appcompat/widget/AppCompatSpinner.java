package androidx.appcompat.widget;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.appcompat.app.C0128f;
import com.vidio.android.p195tv.R;
import p098d.p099a.p100c.p101a.C4569a;
import p098d.p120g.p130j.C4761m;

public class AppCompatSpinner extends Spinner {

    /* renamed from: a */
    private static final int[] f807a = {16843505};

    /* renamed from: b */
    private final C0253c f808b;

    /* renamed from: c */
    private final Context f809c;

    /* renamed from: d */
    private C0289r f810d;

    /* renamed from: e */
    private SpinnerAdapter f811e;

    /* renamed from: f */
    private final boolean f812f;

    /* renamed from: g */
    private C0221e f813g;

    /* renamed from: h */
    int f814h;

    /* renamed from: i */
    final Rect f815i;

    static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0213a();

        /* renamed from: a */
        boolean f816a;

        /* renamed from: androidx.appcompat.widget.AppCompatSpinner$SavedState$a */
        class C0213a implements Parcelable.Creator<SavedState> {
            C0213a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public Object[] newArray(int i) {
                return new SavedState[i];
            }
        }

        SavedState(Parcel parcel) {
            super(parcel);
            this.f816a = parcel.readByte() != 0;
        }

        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeByte(this.f816a ? (byte) 1 : 0);
        }
    }

    /* renamed from: androidx.appcompat.widget.AppCompatSpinner$a */
    class C0214a implements ViewTreeObserver.OnGlobalLayoutListener {
        C0214a() {
        }

        public void onGlobalLayout() {
            if (!AppCompatSpinner.this.mo1263b().mo1292a()) {
                AppCompatSpinner.this.mo1264c();
            }
            ViewTreeObserver viewTreeObserver = AppCompatSpinner.this.getViewTreeObserver();
            if (viewTreeObserver != null) {
                viewTreeObserver.removeOnGlobalLayoutListener(this);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.AppCompatSpinner$b */
    class C0215b implements C0221e, DialogInterface.OnClickListener {

        /* renamed from: a */
        C0128f f818a;

        /* renamed from: b */
        private ListAdapter f819b;

        /* renamed from: c */
        private CharSequence f820c;

        C0215b() {
        }

        /* renamed from: a */
        public boolean mo1292a() {
            C0128f fVar = this.f818a;
            if (fVar != null) {
                return fVar.isShowing();
            }
            return false;
        }

        /* renamed from: b */
        public int mo1293b() {
            return 0;
        }

        /* renamed from: d */
        public void mo1294d(int i) {
            Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
        }

        public void dismiss() {
            C0128f fVar = this.f818a;
            if (fVar != null) {
                fVar.dismiss();
                this.f818a = null;
            }
        }

        /* renamed from: e */
        public CharSequence mo1296e() {
            return this.f820c;
        }

        /* renamed from: g */
        public Drawable mo1297g() {
            return null;
        }

        /* renamed from: h */
        public void mo1298h(CharSequence charSequence) {
            this.f820c = charSequence;
        }

        /* renamed from: i */
        public void mo1299i(Drawable drawable) {
            Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
        }

        /* renamed from: k */
        public void mo1300k(int i) {
            Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
        }

        /* renamed from: l */
        public void mo1301l(int i) {
            Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
        }

        /* renamed from: m */
        public void mo1302m(int i, int i2) {
            if (this.f819b != null) {
                C0128f.C0129a aVar = new C0128f.C0129a(AppCompatSpinner.this.getPopupContext());
                CharSequence charSequence = this.f820c;
                if (charSequence != null) {
                    aVar.mo554h(charSequence);
                }
                aVar.mo553g(this.f819b, AppCompatSpinner.this.getSelectedItemPosition(), this);
                C0128f a = aVar.mo547a();
                this.f818a = a;
                ListView a2 = a.mo542a();
                a2.setTextDirection(i);
                a2.setTextAlignment(i2);
                this.f818a.show();
            }
        }

        /* renamed from: n */
        public int mo1303n() {
            return 0;
        }

        /* renamed from: o */
        public void mo1304o(ListAdapter listAdapter) {
            this.f819b = listAdapter;
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            AppCompatSpinner.this.setSelection(i);
            if (AppCompatSpinner.this.getOnItemClickListener() != null) {
                AppCompatSpinner.this.performItemClick((View) null, i, this.f819b.getItemId(i));
            }
            C0128f fVar = this.f818a;
            if (fVar != null) {
                fVar.dismiss();
                this.f818a = null;
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.AppCompatSpinner$c */
    private static class C0216c implements ListAdapter, SpinnerAdapter {

        /* renamed from: a */
        private SpinnerAdapter f822a;

        /* renamed from: b */
        private ListAdapter f823b;

        public C0216c(SpinnerAdapter spinnerAdapter, Resources.Theme theme) {
            this.f822a = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                this.f823b = (ListAdapter) spinnerAdapter;
            }
            if (theme == null) {
                return;
            }
            if (Build.VERSION.SDK_INT >= 23 && (spinnerAdapter instanceof ThemedSpinnerAdapter)) {
                ThemedSpinnerAdapter themedSpinnerAdapter = (ThemedSpinnerAdapter) spinnerAdapter;
                if (themedSpinnerAdapter.getDropDownViewTheme() != theme) {
                    themedSpinnerAdapter.setDropDownViewTheme(theme);
                }
            } else if (spinnerAdapter instanceof C0250a0) {
                C0250a0 a0Var = (C0250a0) spinnerAdapter;
                if (a0Var.getDropDownViewTheme() == null) {
                    a0Var.setDropDownViewTheme(theme);
                }
            }
        }

        public boolean areAllItemsEnabled() {
            ListAdapter listAdapter = this.f823b;
            if (listAdapter != null) {
                return listAdapter.areAllItemsEnabled();
            }
            return true;
        }

        public int getCount() {
            SpinnerAdapter spinnerAdapter = this.f822a;
            if (spinnerAdapter == null) {
                return 0;
            }
            return spinnerAdapter.getCount();
        }

        public View getDropDownView(int i, View view, ViewGroup viewGroup) {
            SpinnerAdapter spinnerAdapter = this.f822a;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getDropDownView(i, view, viewGroup);
        }

        public Object getItem(int i) {
            SpinnerAdapter spinnerAdapter = this.f822a;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getItem(i);
        }

        public long getItemId(int i) {
            SpinnerAdapter spinnerAdapter = this.f822a;
            if (spinnerAdapter == null) {
                return -1;
            }
            return spinnerAdapter.getItemId(i);
        }

        public int getItemViewType(int i) {
            return 0;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            SpinnerAdapter spinnerAdapter = this.f822a;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getDropDownView(i, view, viewGroup);
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            SpinnerAdapter spinnerAdapter = this.f822a;
            return spinnerAdapter != null && spinnerAdapter.hasStableIds();
        }

        public boolean isEmpty() {
            return getCount() == 0;
        }

        public boolean isEnabled(int i) {
            ListAdapter listAdapter = this.f823b;
            if (listAdapter != null) {
                return listAdapter.isEnabled(i);
            }
            return true;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.f822a;
            if (spinnerAdapter != null) {
                spinnerAdapter.registerDataSetObserver(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.f822a;
            if (spinnerAdapter != null) {
                spinnerAdapter.unregisterDataSetObserver(dataSetObserver);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.AppCompatSpinner$d */
    class C0217d extends ListPopupWindow implements C0221e {

        /* renamed from: D */
        private CharSequence f824D;

        /* renamed from: E */
        ListAdapter f825E;

        /* renamed from: F */
        private final Rect f826F = new Rect();

        /* renamed from: G */
        private int f827G;

        /* renamed from: androidx.appcompat.widget.AppCompatSpinner$d$a */
        class C0218a implements AdapterView.OnItemClickListener {
            C0218a(AppCompatSpinner appCompatSpinner) {
            }

            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                AppCompatSpinner.this.setSelection(i);
                if (AppCompatSpinner.this.getOnItemClickListener() != null) {
                    C0217d dVar = C0217d.this;
                    AppCompatSpinner.this.performItemClick(view, i, dVar.f825E.getItemId(i));
                }
                C0217d.this.dismiss();
            }
        }

        /* renamed from: androidx.appcompat.widget.AppCompatSpinner$d$b */
        class C0219b implements ViewTreeObserver.OnGlobalLayoutListener {
            C0219b() {
            }

            public void onGlobalLayout() {
                C0217d dVar = C0217d.this;
                if (!dVar.mo1320I(AppCompatSpinner.this)) {
                    C0217d.this.dismiss();
                    return;
                }
                C0217d.this.mo1319H();
                C0217d.this.show();
            }
        }

        /* renamed from: androidx.appcompat.widget.AppCompatSpinner$d$c */
        class C0220c implements PopupWindow.OnDismissListener {

            /* renamed from: a */
            final /* synthetic */ ViewTreeObserver.OnGlobalLayoutListener f831a;

            C0220c(ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener) {
                this.f831a = onGlobalLayoutListener;
            }

            public void onDismiss() {
                ViewTreeObserver viewTreeObserver = AppCompatSpinner.this.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    viewTreeObserver.removeGlobalOnLayoutListener(this.f831a);
                }
            }
        }

        public C0217d(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i);
            mo1409w(AppCompatSpinner.this);
            mo1391C(true);
            mo1395G(0);
            mo1393E(new C0218a(AppCompatSpinner.this));
        }

        /* access modifiers changed from: package-private */
        /* JADX WARNING: Removed duplicated region for block: B:21:0x008d  */
        /* JADX WARNING: Removed duplicated region for block: B:22:0x0098  */
        /* renamed from: H */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void mo1319H() {
            /*
                r8 = this;
                android.graphics.drawable.Drawable r0 = r8.mo1398g()
                r1 = 0
                if (r0 == 0) goto L_0x0026
                androidx.appcompat.widget.AppCompatSpinner r1 = androidx.appcompat.widget.AppCompatSpinner.this
                android.graphics.Rect r1 = r1.f815i
                r0.getPadding(r1)
                androidx.appcompat.widget.AppCompatSpinner r0 = androidx.appcompat.widget.AppCompatSpinner.this
                boolean r0 = androidx.appcompat.widget.C0280l0.m1310b(r0)
                if (r0 == 0) goto L_0x001d
                androidx.appcompat.widget.AppCompatSpinner r0 = androidx.appcompat.widget.AppCompatSpinner.this
                android.graphics.Rect r0 = r0.f815i
                int r0 = r0.right
                goto L_0x0024
            L_0x001d:
                androidx.appcompat.widget.AppCompatSpinner r0 = androidx.appcompat.widget.AppCompatSpinner.this
                android.graphics.Rect r0 = r0.f815i
                int r0 = r0.left
                int r0 = -r0
            L_0x0024:
                r1 = r0
                goto L_0x002e
            L_0x0026:
                androidx.appcompat.widget.AppCompatSpinner r0 = androidx.appcompat.widget.AppCompatSpinner.this
                android.graphics.Rect r0 = r0.f815i
                r0.right = r1
                r0.left = r1
            L_0x002e:
                androidx.appcompat.widget.AppCompatSpinner r0 = androidx.appcompat.widget.AppCompatSpinner.this
                int r0 = r0.getPaddingLeft()
                androidx.appcompat.widget.AppCompatSpinner r2 = androidx.appcompat.widget.AppCompatSpinner.this
                int r2 = r2.getPaddingRight()
                androidx.appcompat.widget.AppCompatSpinner r3 = androidx.appcompat.widget.AppCompatSpinner.this
                int r3 = r3.getWidth()
                androidx.appcompat.widget.AppCompatSpinner r4 = androidx.appcompat.widget.AppCompatSpinner.this
                int r5 = r4.f814h
                r6 = -2
                if (r5 != r6) goto L_0x0078
                android.widget.ListAdapter r5 = r8.f825E
                android.widget.SpinnerAdapter r5 = (android.widget.SpinnerAdapter) r5
                android.graphics.drawable.Drawable r6 = r8.mo1398g()
                int r4 = r4.mo1262a(r5, r6)
                androidx.appcompat.widget.AppCompatSpinner r5 = androidx.appcompat.widget.AppCompatSpinner.this
                android.content.Context r5 = r5.getContext()
                android.content.res.Resources r5 = r5.getResources()
                android.util.DisplayMetrics r5 = r5.getDisplayMetrics()
                int r5 = r5.widthPixels
                androidx.appcompat.widget.AppCompatSpinner r6 = androidx.appcompat.widget.AppCompatSpinner.this
                android.graphics.Rect r6 = r6.f815i
                int r7 = r6.left
                int r5 = r5 - r7
                int r6 = r6.right
                int r5 = r5 - r6
                if (r4 <= r5) goto L_0x0070
                r4 = r5
            L_0x0070:
                int r5 = r3 - r0
                int r5 = r5 - r2
                int r4 = java.lang.Math.max(r4, r5)
                goto L_0x007e
            L_0x0078:
                r4 = -1
                if (r5 != r4) goto L_0x0082
                int r4 = r3 - r0
                int r4 = r4 - r2
            L_0x007e:
                r8.mo1411y(r4)
                goto L_0x0085
            L_0x0082:
                r8.mo1411y(r5)
            L_0x0085:
                androidx.appcompat.widget.AppCompatSpinner r4 = androidx.appcompat.widget.AppCompatSpinner.this
                boolean r4 = androidx.appcompat.widget.C0280l0.m1310b(r4)
                if (r4 == 0) goto L_0x0098
                int r3 = r3 - r2
                int r0 = r8.mo1407u()
                int r3 = r3 - r0
                int r0 = r8.f827G
                int r3 = r3 - r0
                int r3 = r3 + r1
                goto L_0x009d
            L_0x0098:
                int r2 = r8.f827G
                int r0 = r0 + r2
                int r3 = r0 + r1
            L_0x009d:
                r8.mo1397d(r3)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.AppCompatSpinner.C0217d.mo1319H():void");
        }

        /* access modifiers changed from: package-private */
        /* renamed from: I */
        public boolean mo1320I(View view) {
            int i = C4761m.f17241f;
            return view.isAttachedToWindow() && view.getGlobalVisibleRect(this.f826F);
        }

        /* renamed from: e */
        public CharSequence mo1296e() {
            return this.f824D;
        }

        /* renamed from: h */
        public void mo1298h(CharSequence charSequence) {
            this.f824D = charSequence;
        }

        /* renamed from: l */
        public void mo1301l(int i) {
            this.f827G = i;
        }

        /* renamed from: m */
        public void mo1302m(int i, int i2) {
            ViewTreeObserver viewTreeObserver;
            boolean a = mo710a();
            mo1319H();
            this.f871C.setInputMethodMode(2);
            show();
            C0285p pVar = this.f874f;
            pVar.setChoiceMode(1);
            pVar.setTextDirection(i);
            pVar.setTextAlignment(i2);
            int selectedItemPosition = AppCompatSpinner.this.getSelectedItemPosition();
            C0285p pVar2 = this.f874f;
            if (mo710a() && pVar2 != null) {
                pVar2.mo1700c(false);
                pVar2.setSelection(selectedItemPosition);
                if (pVar2.getChoiceMode() != 0) {
                    pVar2.setItemChecked(selectedItemPosition, true);
                }
            }
            if (!a && (viewTreeObserver = AppCompatSpinner.this.getViewTreeObserver()) != null) {
                C0219b bVar = new C0219b();
                viewTreeObserver.addOnGlobalLayoutListener(bVar);
                this.f871C.setOnDismissListener(new C0220c(bVar));
            }
        }

        /* renamed from: o */
        public void mo1304o(ListAdapter listAdapter) {
            super.mo1304o(listAdapter);
            this.f825E = listAdapter;
        }
    }

    /* renamed from: androidx.appcompat.widget.AppCompatSpinner$e */
    interface C0221e {
        /* renamed from: a */
        boolean mo1292a();

        /* renamed from: b */
        int mo1293b();

        /* renamed from: d */
        void mo1294d(int i);

        void dismiss();

        /* renamed from: e */
        CharSequence mo1296e();

        /* renamed from: g */
        Drawable mo1297g();

        /* renamed from: h */
        void mo1298h(CharSequence charSequence);

        /* renamed from: i */
        void mo1299i(Drawable drawable);

        /* renamed from: k */
        void mo1300k(int i);

        /* renamed from: l */
        void mo1301l(int i);

        /* renamed from: m */
        void mo1302m(int i, int i2);

        /* renamed from: n */
        int mo1303n();

        /* renamed from: o */
        void mo1304o(ListAdapter listAdapter);
    }

    public AppCompatSpinner(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.spinnerStyle);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0056, code lost:
        if (r4 != null) goto L_0x0058;
     */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00d1  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public AppCompatSpinner(android.content.Context r10, android.util.AttributeSet r11, int r12) {
        /*
            r9 = this;
            r9.<init>(r10, r11, r12)
            android.graphics.Rect r0 = new android.graphics.Rect
            r0.<init>()
            r9.f815i = r0
            android.content.Context r0 = r9.getContext()
            androidx.appcompat.widget.C0306z.m1392a(r9, r0)
            int[] r0 = p098d.p099a.C4568b.f16475w
            r1 = 0
            androidx.appcompat.widget.e0 r0 = androidx.appcompat.widget.C0259e0.m1181v(r10, r11, r0, r12, r1)
            androidx.appcompat.widget.c r2 = new androidx.appcompat.widget.c
            r2.<init>(r9)
            r9.f808b = r2
            r2 = 4
            int r2 = r0.mo1603n(r2, r1)
            if (r2 == 0) goto L_0x002e
            d.a.g.d r3 = new d.a.g.d
            r3.<init>((android.content.Context) r10, (int) r2)
            r9.f809c = r3
            goto L_0x0030
        L_0x002e:
            r9.f809c = r10
        L_0x0030:
            r2 = 0
            r3 = -1
            int[] r4 = f807a     // Catch:{ Exception -> 0x004c, all -> 0x0049 }
            android.content.res.TypedArray r4 = r10.obtainStyledAttributes(r11, r4, r12, r1)     // Catch:{ Exception -> 0x004c, all -> 0x0049 }
            boolean r5 = r4.hasValue(r1)     // Catch:{ Exception -> 0x0047 }
            if (r5 == 0) goto L_0x0058
            int r3 = r4.getInt(r1, r1)     // Catch:{ Exception -> 0x0047 }
            goto L_0x0058
        L_0x0043:
            r10 = move-exception
            r2 = r4
            goto L_0x00cf
        L_0x0047:
            r5 = move-exception
            goto L_0x004f
        L_0x0049:
            r10 = move-exception
            goto L_0x00cf
        L_0x004c:
            r4 = move-exception
            r5 = r4
            r4 = r2
        L_0x004f:
            java.lang.String r6 = "AppCompatSpinner"
            java.lang.String r7 = "Could not read android:spinnerMode"
            android.util.Log.i(r6, r7, r5)     // Catch:{ all -> 0x0043 }
            if (r4 == 0) goto L_0x005b
        L_0x0058:
            r4.recycle()
        L_0x005b:
            r4 = 2
            r5 = 1
            if (r3 == 0) goto L_0x0096
            if (r3 == r5) goto L_0x0062
            goto L_0x00a4
        L_0x0062:
            androidx.appcompat.widget.AppCompatSpinner$d r3 = new androidx.appcompat.widget.AppCompatSpinner$d
            android.content.Context r6 = r9.f809c
            r3.<init>(r6, r11, r12)
            android.content.Context r6 = r9.f809c
            int[] r7 = p098d.p099a.C4568b.f16475w
            androidx.appcompat.widget.e0 r6 = androidx.appcompat.widget.C0259e0.m1181v(r6, r11, r7, r12, r1)
            r7 = 3
            r8 = -2
            int r7 = r6.mo1602m(r7, r8)
            r9.f814h = r7
            android.graphics.drawable.Drawable r7 = r6.mo1596g(r5)
            android.widget.PopupWindow r8 = r3.f871C
            r8.setBackgroundDrawable(r7)
            java.lang.String r4 = r0.mo1604o(r4)
            r3.mo1298h(r4)
            r6.mo1609w()
            r9.f813g = r3
            androidx.appcompat.widget.i r4 = new androidx.appcompat.widget.i
            r4.<init>(r9, r9, r3)
            r9.f810d = r4
            goto L_0x00a4
        L_0x0096:
            androidx.appcompat.widget.AppCompatSpinner$b r3 = new androidx.appcompat.widget.AppCompatSpinner$b
            r3.<init>()
            r9.f813g = r3
            java.lang.String r4 = r0.mo1604o(r4)
            r3.mo1298h(r4)
        L_0x00a4:
            java.lang.CharSequence[] r1 = r0.mo1606q(r1)
            if (r1 == 0) goto L_0x00bb
            android.widget.ArrayAdapter r3 = new android.widget.ArrayAdapter
            r4 = 17367048(0x1090008, float:2.5162948E-38)
            r3.<init>(r10, r4, r1)
            r10 = 2131558747(0x7f0d015b, float:1.8742819E38)
            r3.setDropDownViewResource(r10)
            r9.setAdapter((android.widget.SpinnerAdapter) r3)
        L_0x00bb:
            r0.mo1609w()
            r9.f812f = r5
            android.widget.SpinnerAdapter r10 = r9.f811e
            if (r10 == 0) goto L_0x00c9
            r9.setAdapter((android.widget.SpinnerAdapter) r10)
            r9.f811e = r2
        L_0x00c9:
            androidx.appcompat.widget.c r10 = r9.f808b
            r10.mo1574d(r11, r12)
            return
        L_0x00cf:
            if (r2 == 0) goto L_0x00d4
            r2.recycle()
        L_0x00d4:
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.AppCompatSpinner.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public int mo1262a(SpinnerAdapter spinnerAdapter, Drawable drawable) {
        int i = 0;
        if (spinnerAdapter == null) {
            return 0;
        }
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int max = Math.max(0, getSelectedItemPosition());
        int min = Math.min(spinnerAdapter.getCount(), max + 15);
        View view = null;
        int i2 = 0;
        for (int max2 = Math.max(0, max - (15 - (min - max))); max2 < min; max2++) {
            int itemViewType = spinnerAdapter.getItemViewType(max2);
            if (itemViewType != i) {
                view = null;
                i = itemViewType;
            }
            view = spinnerAdapter.getView(max2, view, this);
            if (view.getLayoutParams() == null) {
                view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            }
            view.measure(makeMeasureSpec, makeMeasureSpec2);
            i2 = Math.max(i2, view.getMeasuredWidth());
        }
        if (drawable == null) {
            return i2;
        }
        drawable.getPadding(this.f815i);
        Rect rect = this.f815i;
        return i2 + rect.left + rect.right;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public final C0221e mo1263b() {
        return this.f813g;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo1264c() {
        this.f813g.mo1302m(getTextDirection(), getTextAlignment());
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0253c cVar = this.f808b;
        if (cVar != null) {
            cVar.mo1571a();
        }
    }

    public int getDropDownHorizontalOffset() {
        C0221e eVar = this.f813g;
        return eVar != null ? eVar.mo1293b() : super.getDropDownHorizontalOffset();
    }

    public int getDropDownVerticalOffset() {
        C0221e eVar = this.f813g;
        return eVar != null ? eVar.mo1303n() : super.getDropDownVerticalOffset();
    }

    public int getDropDownWidth() {
        return this.f813g != null ? this.f814h : super.getDropDownWidth();
    }

    public Drawable getPopupBackground() {
        C0221e eVar = this.f813g;
        return eVar != null ? eVar.mo1297g() : super.getPopupBackground();
    }

    public Context getPopupContext() {
        return this.f809c;
    }

    public CharSequence getPrompt() {
        C0221e eVar = this.f813g;
        return eVar != null ? eVar.mo1296e() : super.getPrompt();
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0221e eVar = this.f813g;
        if (eVar != null && eVar.mo1292a()) {
            this.f813g.dismiss();
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f813g != null && View.MeasureSpec.getMode(i) == Integer.MIN_VALUE) {
            setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), mo1262a(getAdapter(), getBackground())), View.MeasureSpec.getSize(i)), getMeasuredHeight());
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        ViewTreeObserver viewTreeObserver;
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        if (savedState.f816a && (viewTreeObserver = getViewTreeObserver()) != null) {
            viewTreeObserver.addOnGlobalLayoutListener(new C0214a());
        }
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        C0221e eVar = this.f813g;
        savedState.f816a = eVar != null && eVar.mo1292a();
        return savedState;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        C0289r rVar = this.f810d;
        if (rVar == null || !rVar.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public boolean performClick() {
        C0221e eVar = this.f813g;
        if (eVar == null) {
            return super.performClick();
        }
        if (eVar.mo1292a()) {
            return true;
        }
        mo1264c();
        return true;
    }

    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        if (!this.f812f) {
            this.f811e = spinnerAdapter;
            return;
        }
        super.setAdapter(spinnerAdapter);
        if (this.f813g != null) {
            Context context = this.f809c;
            if (context == null) {
                context = getContext();
            }
            this.f813g.mo1304o(new C0216c(spinnerAdapter, context.getTheme()));
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0253c cVar = this.f808b;
        if (cVar != null) {
            cVar.mo1575e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0253c cVar = this.f808b;
        if (cVar != null) {
            cVar.mo1576f(i);
        }
    }

    public void setDropDownHorizontalOffset(int i) {
        C0221e eVar = this.f813g;
        if (eVar != null) {
            eVar.mo1301l(i);
            this.f813g.mo1294d(i);
            return;
        }
        super.setDropDownHorizontalOffset(i);
    }

    public void setDropDownVerticalOffset(int i) {
        C0221e eVar = this.f813g;
        if (eVar != null) {
            eVar.mo1300k(i);
        } else {
            super.setDropDownVerticalOffset(i);
        }
    }

    public void setDropDownWidth(int i) {
        if (this.f813g != null) {
            this.f814h = i;
        } else {
            super.setDropDownWidth(i);
        }
    }

    public void setPopupBackgroundDrawable(Drawable drawable) {
        C0221e eVar = this.f813g;
        if (eVar != null) {
            eVar.mo1299i(drawable);
        } else {
            super.setPopupBackgroundDrawable(drawable);
        }
    }

    public void setPopupBackgroundResource(int i) {
        setPopupBackgroundDrawable(C4569a.m16431b(getPopupContext(), i));
    }

    public void setPrompt(CharSequence charSequence) {
        C0221e eVar = this.f813g;
        if (eVar != null) {
            eVar.mo1298h(charSequence);
        } else {
            super.setPrompt(charSequence);
        }
    }
}
