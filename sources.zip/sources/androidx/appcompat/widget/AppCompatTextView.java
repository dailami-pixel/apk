package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.core.widget.C0501b;
import androidx.core.widget.C0502c;
import androidx.core.widget.C0505f;
import p098d.p099a.p100c.p101a.C4569a;
import p098d.p120g.p121c.C4696e;

public class AppCompatTextView extends TextView implements C0505f, C0501b {

    /* renamed from: a */
    private final C0253c f833a;

    /* renamed from: b */
    private final C0273k f834b;

    /* renamed from: c */
    private final C0271j f835c;

    public AppCompatTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        C0252b0.m1152a(context);
        C0306z.m1392a(this, getContext());
        C0253c cVar = new C0253c(this);
        this.f833a = cVar;
        cVar.mo1574d(attributeSet, i);
        C0273k kVar = new C0273k(this);
        this.f834b = kVar;
        kVar.mo1670m(attributeSet, i);
        kVar.mo1660b();
        this.f835c = new C0271j(this);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0253c cVar = this.f833a;
        if (cVar != null) {
            cVar.mo1571a();
        }
        C0273k kVar = this.f834b;
        if (kVar != null) {
            kVar.mo1660b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (C0501b.f2326S) {
            return super.getAutoSizeMaxTextSize();
        }
        C0273k kVar = this.f834b;
        if (kVar != null) {
            return kVar.mo1662e();
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (C0501b.f2326S) {
            return super.getAutoSizeMinTextSize();
        }
        C0273k kVar = this.f834b;
        if (kVar != null) {
            return kVar.mo1663f();
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (C0501b.f2326S) {
            return super.getAutoSizeStepGranularity();
        }
        C0273k kVar = this.f834b;
        if (kVar != null) {
            return kVar.mo1664g();
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (C0501b.f2326S) {
            return super.getAutoSizeTextAvailableSizes();
        }
        C0273k kVar = this.f834b;
        return kVar != null ? kVar.mo1665h() : new int[0];
    }

    public int getAutoSizeTextType() {
        if (C0501b.f2326S) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        C0273k kVar = this.f834b;
        if (kVar != null) {
            return kVar.mo1666i();
        }
        return 0;
    }

    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public CharSequence getText() {
        return super.getText();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r2.f835c;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.textclassifier.TextClassifier getTextClassifier() {
        /*
            r2 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 28
            if (r0 >= r1) goto L_0x0010
            androidx.appcompat.widget.j r0 = r2.f835c
            if (r0 != 0) goto L_0x000b
            goto L_0x0010
        L_0x000b:
            android.view.textclassifier.TextClassifier r0 = r0.mo1656a()
            return r0
        L_0x0010:
            android.view.textclassifier.TextClassifier r0 = super.getTextClassifier()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.AppCompatTextView.getTextClassifier():android.view.textclassifier.TextClassifier");
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        C0266h0.m1245a(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        C0273k kVar = this.f834b;
        if (kVar != null) {
            kVar.mo1672o();
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
    }

    /* access modifiers changed from: protected */
    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        C0273k kVar = this.f834b;
        if (kVar != null && !C0501b.f2326S && kVar.mo1669l()) {
            this.f834b.mo1661c();
        }
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) throws IllegalArgumentException {
        if (C0501b.f2326S) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        C0273k kVar = this.f834b;
        if (kVar != null) {
            kVar.mo1675r(i, i2, i3, i4);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) throws IllegalArgumentException {
        if (C0501b.f2326S) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        C0273k kVar = this.f834b;
        if (kVar != null) {
            kVar.mo1676s(iArr, i);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (C0501b.f2326S) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        C0273k kVar = this.f834b;
        if (kVar != null) {
            kVar.mo1677t(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0253c cVar = this.f833a;
        if (cVar != null) {
            cVar.mo1575e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0253c cVar = this.f833a;
        if (cVar != null) {
            cVar.mo1576f(i);
        }
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C0273k kVar = this.f834b;
        if (kVar != null) {
            kVar.mo1660b();
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C0273k kVar = this.f834b;
        if (kVar != null) {
            kVar.mo1660b();
        }
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable b = i != 0 ? C4569a.m16431b(context, i) : null;
        Drawable b2 = i2 != 0 ? C4569a.m16431b(context, i2) : null;
        Drawable b3 = i3 != 0 ? C4569a.m16431b(context, i3) : null;
        if (i4 != 0) {
            drawable = C4569a.m16431b(context, i4);
        }
        setCompoundDrawablesRelativeWithIntrinsicBounds(b, b2, b3, drawable);
        C0273k kVar = this.f834b;
        if (kVar != null) {
            kVar.mo1660b();
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable b = i != 0 ? C4569a.m16431b(context, i) : null;
        Drawable b2 = i2 != 0 ? C4569a.m16431b(context, i2) : null;
        Drawable b3 = i3 != 0 ? C4569a.m16431b(context, i3) : null;
        if (i4 != 0) {
            drawable = C4569a.m16431b(context, i4);
        }
        setCompoundDrawablesWithIntrinsicBounds(b, b2, b3, drawable);
        C0273k kVar = this.f834b;
        if (kVar != null) {
            kVar.mo1660b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C0502c.m2298h(this, callback));
    }

    public void setFirstBaselineToTopHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setFirstBaselineToTopHeight(i);
        } else {
            C0502c.m2292b(this, i);
        }
    }

    public void setLastBaselineToBottomHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setLastBaselineToBottomHeight(i);
        } else {
            C0502c.m2293c(this, i);
        }
    }

    public void setLineHeight(int i) {
        C0502c.m2294d(this, i);
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f834b.mo1678u(colorStateList);
        this.f834b.mo1660b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f834b.mo1679v(mode);
        this.f834b.mo1660b();
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C0273k kVar = this.f834b;
        if (kVar != null) {
            kVar.mo1673p(context, i);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        C0271j jVar;
        if (Build.VERSION.SDK_INT >= 28 || (jVar = this.f835c) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            jVar.mo1657b(textClassifier);
        }
    }

    public void setTextSize(int i, float f) {
        if (C0501b.f2326S) {
            super.setTextSize(i, f);
            return;
        }
        C0273k kVar = this.f834b;
        if (kVar != null) {
            kVar.mo1680w(i, f);
        }
    }

    public void setTypeface(Typeface typeface, int i) {
        Typeface typeface2;
        if (typeface == null || i <= 0) {
            typeface2 = null;
        } else {
            Context context = getContext();
            int i2 = C4696e.f17112c;
            if (context != null) {
                typeface2 = Typeface.create(typeface, i);
            } else {
                throw new IllegalArgumentException("Context cannot be null");
            }
        }
        if (typeface2 != null) {
            typeface = typeface2;
        }
        super.setTypeface(typeface, i);
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C0273k kVar = this.f834b;
        if (kVar != null) {
            kVar.mo1660b();
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C0273k kVar = this.f834b;
        if (kVar != null) {
            kVar.mo1660b();
        }
    }
}
