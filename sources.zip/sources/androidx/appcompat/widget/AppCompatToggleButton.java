package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ToggleButton;

public class AppCompatToggleButton extends ToggleButton {

    /* renamed from: a */
    private final C0273k f836a;

    public AppCompatToggleButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842827);
    }

    public AppCompatToggleButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        C0306z.m1392a(this, getContext());
        C0273k kVar = new C0273k(this);
        this.f836a = kVar;
        kVar.mo1670m(attributeSet, i);
    }
}
