package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import com.vidio.android.p195tv.R;
import p098d.p099a.C4568b;
import p098d.p120g.p130j.C4774r;
import p098d.p120g.p130j.C4777s;

/* renamed from: androidx.appcompat.widget.a */
abstract class C0248a extends ViewGroup {

    /* renamed from: a */
    protected final C0249a f1054a;

    /* renamed from: b */
    protected final Context f1055b;

    /* renamed from: c */
    protected ActionMenuView f1056c;

    /* renamed from: d */
    protected ActionMenuPresenter f1057d;

    /* renamed from: e */
    protected int f1058e;

    /* renamed from: f */
    protected C4774r f1059f;

    /* renamed from: g */
    private boolean f1060g;

    /* renamed from: h */
    private boolean f1061h;

    /* renamed from: androidx.appcompat.widget.a$a */
    protected class C0249a implements C4777s {

        /* renamed from: a */
        private boolean f1062a = false;

        /* renamed from: b */
        int f1063b;

        protected C0249a() {
        }

        /* renamed from: a */
        public void mo1563a(View view) {
            this.f1062a = true;
        }

        /* renamed from: b */
        public void mo515b(View view) {
            if (!this.f1062a) {
                C0248a aVar = C0248a.this;
                aVar.f1059f = null;
                C0248a.super.setVisibility(this.f1063b);
            }
        }

        /* renamed from: c */
        public void mo559c(View view) {
            C0248a.super.setVisibility(0);
            this.f1062a = false;
        }
    }

    C0248a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    C0248a(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1054a = new C0249a();
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(R.attr.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.f1055b = context;
        } else {
            this.f1055b = new ContextThemeWrapper(context, typedValue.resourceId);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public int mo1557c(View view, int i, int i2, int i3) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i, RecyclerView.UNDEFINED_DURATION), i2);
        return Math.max(0, (i - view.getMeasuredWidth()) - i3);
    }

    /* access modifiers changed from: protected */
    /* renamed from: d */
    public int mo1558d(View view, int i, int i2, int i3, boolean z) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i4 = ((i3 - measuredHeight) / 2) + i2;
        if (z) {
            view.layout(i - measuredWidth, i4, i, measuredHeight + i4);
        } else {
            view.layout(i, i4, i + measuredWidth, measuredHeight + i4);
        }
        return z ? -measuredWidth : measuredWidth;
    }

    /* access modifiers changed from: protected */
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes((AttributeSet) null, C4568b.f16453a, R.attr.actionBarStyle, 0);
        ((ActionBarContextView) this).f1058e = obtainStyledAttributes.getLayoutDimension(13, 0);
        obtainStyledAttributes.recycle();
        ActionMenuPresenter actionMenuPresenter = this.f1057d;
        if (actionMenuPresenter != null) {
            actionMenuPresenter.mo1097B();
        }
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f1061h = false;
        }
        if (!this.f1061h) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f1061h = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f1061h = false;
        }
        return true;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1060g = false;
        }
        if (!this.f1060g) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f1060g = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f1060g = false;
        }
        return true;
    }

    public void setVisibility(int i) {
        if (i != getVisibility()) {
            C4774r rVar = this.f1059f;
            if (rVar != null) {
                rVar.mo21875b();
            }
            super.setVisibility(i);
        }
    }
}
