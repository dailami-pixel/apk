package androidx.appcompat.widget;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;

/* renamed from: androidx.appcompat.widget.b */
class C0251b extends Drawable {

    /* renamed from: a */
    final ActionBarContainer f1065a;

    public C0251b(ActionBarContainer actionBarContainer) {
        this.f1065a = actionBarContainer;
    }

    public void draw(Canvas canvas) {
        ActionBarContainer actionBarContainer = this.f1065a;
        if (actionBarContainer.f669h) {
            Drawable drawable = actionBarContainer.f668g;
            if (drawable != null) {
                drawable.draw(canvas);
                return;
            }
            return;
        }
        Drawable drawable2 = actionBarContainer.f666e;
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        ActionBarContainer actionBarContainer2 = this.f1065a;
        Drawable drawable3 = actionBarContainer2.f667f;
        if (drawable3 != null && actionBarContainer2.f670i) {
            drawable3.draw(canvas);
        }
    }

    public int getOpacity() {
        return 0;
    }

    public void getOutline(Outline outline) {
        Drawable drawable;
        ActionBarContainer actionBarContainer = this.f1065a;
        if (actionBarContainer.f669h) {
            drawable = actionBarContainer.f668g;
            if (drawable == null) {
                return;
            }
        } else {
            drawable = actionBarContainer.f666e;
            if (drawable == null) {
                return;
            }
        }
        drawable.getOutline(outline);
    }

    public void setAlpha(int i) {
    }

    public void setColorFilter(ColorFilter colorFilter) {
    }
}
