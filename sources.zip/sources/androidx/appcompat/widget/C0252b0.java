package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;

/* renamed from: androidx.appcompat.widget.b0 */
public class C0252b0 extends ContextWrapper {

    /* renamed from: a */
    private static final Object f1066a = new Object();

    /* renamed from: a */
    public static Context m1152a(Context context) {
        if (!(context instanceof C0252b0) && !(context.getResources() instanceof C0256d0)) {
            context.getResources();
            int i = C0275k0.f1170a;
        }
        return context;
    }
}
