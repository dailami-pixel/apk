package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import p098d.p120g.p130j.C4761m;

/* renamed from: androidx.appcompat.widget.c */
class C0253c {

    /* renamed from: a */
    private final View f1067a;

    /* renamed from: b */
    private final C0257e f1068b;

    /* renamed from: c */
    private int f1069c = -1;

    /* renamed from: d */
    private C0254c0 f1070d;

    /* renamed from: e */
    private C0254c0 f1071e;

    /* renamed from: f */
    private C0254c0 f1072f;

    C0253c(View view) {
        this.f1067a = view;
        this.f1068b = C0257e.m1166b();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo1571a() {
        Drawable background = this.f1067a.getBackground();
        if (background != null) {
            int i = Build.VERSION.SDK_INT;
            boolean z = true;
            if (i <= 21 ? i == 21 : this.f1070d != null) {
                if (this.f1072f == null) {
                    this.f1072f = new C0254c0();
                }
                C0254c0 c0Var = this.f1072f;
                c0Var.f1073a = null;
                c0Var.f1076d = false;
                c0Var.f1074b = null;
                c0Var.f1075c = false;
                View view = this.f1067a;
                int i2 = C4761m.f17241f;
                ColorStateList backgroundTintList = view.getBackgroundTintList();
                if (backgroundTintList != null) {
                    c0Var.f1076d = true;
                    c0Var.f1073a = backgroundTintList;
                }
                PorterDuff.Mode backgroundTintMode = this.f1067a.getBackgroundTintMode();
                if (backgroundTintMode != null) {
                    c0Var.f1075c = true;
                    c0Var.f1074b = backgroundTintMode;
                }
                if (c0Var.f1076d || c0Var.f1075c) {
                    int[] drawableState = this.f1067a.getDrawableState();
                    int i3 = C0257e.f1085c;
                    C0296v.m1377n(background, c0Var, drawableState);
                } else {
                    z = false;
                }
                if (z) {
                    return;
                }
            }
            C0254c0 c0Var2 = this.f1071e;
            if (c0Var2 != null) {
                int[] drawableState2 = this.f1067a.getDrawableState();
                int i4 = C0257e.f1085c;
                C0296v.m1377n(background, c0Var2, drawableState2);
                return;
            }
            C0254c0 c0Var3 = this.f1070d;
            if (c0Var3 != null) {
                int[] drawableState3 = this.f1067a.getDrawableState();
                int i5 = C0257e.f1085c;
                C0296v.m1377n(background, c0Var3, drawableState3);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public ColorStateList mo1572b() {
        C0254c0 c0Var = this.f1071e;
        if (c0Var != null) {
            return c0Var.f1073a;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public PorterDuff.Mode mo1573c() {
        C0254c0 c0Var = this.f1071e;
        if (c0Var != null) {
            return c0Var.f1074b;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0071 A[Catch:{ all -> 0x00bd }] */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1574d(android.util.AttributeSet r10, int r11) {
        /*
            r9 = this;
            android.view.View r0 = r9.f1067a
            android.content.Context r0 = r0.getContext()
            int[] r3 = p098d.p099a.C4568b.f16451B
            r8 = 0
            androidx.appcompat.widget.e0 r0 = androidx.appcompat.widget.C0259e0.m1181v(r0, r10, r3, r11, r8)
            android.view.View r1 = r9.f1067a
            android.content.Context r2 = r1.getContext()
            android.content.res.TypedArray r5 = r0.mo1607r()
            r7 = 0
            r4 = r10
            r6 = r11
            p098d.p120g.p130j.C4761m.m17309r(r1, r2, r3, r4, r5, r6, r7)
            boolean r10 = r0.mo1608s(r8)     // Catch:{ all -> 0x00bd }
            r11 = -1
            if (r10 == 0) goto L_0x003d
            int r10 = r0.mo1603n(r8, r11)     // Catch:{ all -> 0x00bd }
            r9.f1069c = r10     // Catch:{ all -> 0x00bd }
            androidx.appcompat.widget.e r10 = r9.f1068b     // Catch:{ all -> 0x00bd }
            android.view.View r1 = r9.f1067a     // Catch:{ all -> 0x00bd }
            android.content.Context r1 = r1.getContext()     // Catch:{ all -> 0x00bd }
            int r2 = r9.f1069c     // Catch:{ all -> 0x00bd }
            android.content.res.ColorStateList r10 = r10.mo1585f(r1, r2)     // Catch:{ all -> 0x00bd }
            if (r10 == 0) goto L_0x003d
            r9.mo1577g(r10)     // Catch:{ all -> 0x00bd }
        L_0x003d:
            r10 = 1
            boolean r1 = r0.mo1608s(r10)     // Catch:{ all -> 0x00bd }
            r2 = 21
            if (r1 == 0) goto L_0x007b
            android.view.View r1 = r9.f1067a     // Catch:{ all -> 0x00bd }
            android.content.res.ColorStateList r3 = r0.mo1592c(r10)     // Catch:{ all -> 0x00bd }
            int r4 = android.os.Build.VERSION.SDK_INT     // Catch:{ all -> 0x00bd }
            r1.setBackgroundTintList(r3)     // Catch:{ all -> 0x00bd }
            if (r4 != r2) goto L_0x007b
            android.graphics.drawable.Drawable r3 = r1.getBackground()     // Catch:{ all -> 0x00bd }
            android.content.res.ColorStateList r4 = r1.getBackgroundTintList()     // Catch:{ all -> 0x00bd }
            if (r4 != 0) goto L_0x0066
            android.graphics.PorterDuff$Mode r4 = r1.getBackgroundTintMode()     // Catch:{ all -> 0x00bd }
            if (r4 == 0) goto L_0x0064
            goto L_0x0066
        L_0x0064:
            r4 = 0
            goto L_0x0067
        L_0x0066:
            r4 = 1
        L_0x0067:
            if (r3 == 0) goto L_0x007b
            if (r4 == 0) goto L_0x007b
            boolean r4 = r3.isStateful()     // Catch:{ all -> 0x00bd }
            if (r4 == 0) goto L_0x0078
            int[] r4 = r1.getDrawableState()     // Catch:{ all -> 0x00bd }
            r3.setState(r4)     // Catch:{ all -> 0x00bd }
        L_0x0078:
            r1.setBackground(r3)     // Catch:{ all -> 0x00bd }
        L_0x007b:
            r1 = 2
            boolean r3 = r0.mo1608s(r1)     // Catch:{ all -> 0x00bd }
            if (r3 == 0) goto L_0x00b9
            android.view.View r3 = r9.f1067a     // Catch:{ all -> 0x00bd }
            int r11 = r0.mo1600k(r1, r11)     // Catch:{ all -> 0x00bd }
            r1 = 0
            android.graphics.PorterDuff$Mode r11 = androidx.appcompat.widget.C0284o.m1347d(r11, r1)     // Catch:{ all -> 0x00bd }
            int r1 = android.os.Build.VERSION.SDK_INT     // Catch:{ all -> 0x00bd }
            r3.setBackgroundTintMode(r11)     // Catch:{ all -> 0x00bd }
            if (r1 != r2) goto L_0x00b9
            android.graphics.drawable.Drawable r11 = r3.getBackground()     // Catch:{ all -> 0x00bd }
            android.content.res.ColorStateList r1 = r3.getBackgroundTintList()     // Catch:{ all -> 0x00bd }
            if (r1 != 0) goto L_0x00a4
            android.graphics.PorterDuff$Mode r1 = r3.getBackgroundTintMode()     // Catch:{ all -> 0x00bd }
            if (r1 == 0) goto L_0x00a5
        L_0x00a4:
            r8 = 1
        L_0x00a5:
            if (r11 == 0) goto L_0x00b9
            if (r8 == 0) goto L_0x00b9
            boolean r10 = r11.isStateful()     // Catch:{ all -> 0x00bd }
            if (r10 == 0) goto L_0x00b6
            int[] r10 = r3.getDrawableState()     // Catch:{ all -> 0x00bd }
            r11.setState(r10)     // Catch:{ all -> 0x00bd }
        L_0x00b6:
            r3.setBackground(r11)     // Catch:{ all -> 0x00bd }
        L_0x00b9:
            r0.mo1609w()
            return
        L_0x00bd:
            r10 = move-exception
            r0.mo1609w()
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0253c.mo1574d(android.util.AttributeSet, int):void");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo1575e() {
        this.f1069c = -1;
        mo1577g((ColorStateList) null);
        mo1571a();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public void mo1576f(int i) {
        this.f1069c = i;
        C0257e eVar = this.f1068b;
        mo1577g(eVar != null ? eVar.mo1585f(this.f1067a.getContext(), i) : null);
        mo1571a();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public void mo1577g(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f1070d == null) {
                this.f1070d = new C0254c0();
            }
            C0254c0 c0Var = this.f1070d;
            c0Var.f1073a = colorStateList;
            c0Var.f1076d = true;
        } else {
            this.f1070d = null;
        }
        mo1571a();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public void mo1578h(ColorStateList colorStateList) {
        if (this.f1071e == null) {
            this.f1071e = new C0254c0();
        }
        C0254c0 c0Var = this.f1071e;
        c0Var.f1073a = colorStateList;
        c0Var.f1076d = true;
        mo1571a();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public void mo1579i(PorterDuff.Mode mode) {
        if (this.f1071e == null) {
            this.f1071e = new C0254c0();
        }
        C0254c0 c0Var = this.f1071e;
        c0Var.f1074b = mode;
        c0Var.f1075c = true;
        mo1571a();
    }
}
