package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* renamed from: androidx.appcompat.widget.c0 */
public class C0254c0 {

    /* renamed from: a */
    public ColorStateList f1073a;

    /* renamed from: b */
    public PorterDuff.Mode f1074b;

    /* renamed from: c */
    public boolean f1075c;

    /* renamed from: d */
    public boolean f1076d;
}
