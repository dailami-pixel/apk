package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.widget.CompoundButton;
import androidx.core.graphics.drawable.C0487a;
import androidx.core.widget.C0502c;

/* renamed from: androidx.appcompat.widget.d */
class C0255d {

    /* renamed from: a */
    private final CompoundButton f1077a;

    /* renamed from: b */
    private ColorStateList f1078b = null;

    /* renamed from: c */
    private PorterDuff.Mode f1079c = null;

    /* renamed from: d */
    private boolean f1080d = false;

    /* renamed from: e */
    private boolean f1081e = false;

    /* renamed from: f */
    private boolean f1082f;

    C0255d(CompoundButton compoundButton) {
        this.f1077a = compoundButton;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo1580a() {
        Drawable a = C0502c.m2291a(this.f1077a);
        if (a == null) {
            return;
        }
        if (this.f1080d || this.f1081e) {
            Drawable mutate = C0487a.m2226h(a).mutate();
            if (this.f1080d) {
                mutate.setTintList(this.f1078b);
            }
            if (this.f1081e) {
                mutate.setTintMode(this.f1079c);
            }
            if (mutate.isStateful()) {
                mutate.setState(this.f1077a.getDrawableState());
            }
            this.f1077a.setButtonDrawable(mutate);
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x003b A[SYNTHETIC, Splitter:B:11:0x003b] */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x005b A[Catch:{ all -> 0x007e }] */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x006b A[Catch:{ all -> 0x007e }] */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1581b(android.util.AttributeSet r10, int r11) {
        /*
            r9 = this;
            android.widget.CompoundButton r0 = r9.f1077a
            android.content.Context r0 = r0.getContext()
            int[] r3 = p098d.p099a.C4568b.f16465m
            r8 = 0
            androidx.appcompat.widget.e0 r0 = androidx.appcompat.widget.C0259e0.m1181v(r0, r10, r3, r11, r8)
            android.widget.CompoundButton r1 = r9.f1077a
            android.content.Context r2 = r1.getContext()
            android.content.res.TypedArray r5 = r0.mo1607r()
            r7 = 0
            r4 = r10
            r6 = r11
            p098d.p120g.p130j.C4761m.m17309r(r1, r2, r3, r4, r5, r6, r7)
            r10 = 1
            boolean r11 = r0.mo1608s(r10)     // Catch:{ all -> 0x007e }
            if (r11 == 0) goto L_0x0038
            int r11 = r0.mo1603n(r10, r8)     // Catch:{ all -> 0x007e }
            if (r11 == 0) goto L_0x0038
            android.widget.CompoundButton r1 = r9.f1077a     // Catch:{ NotFoundException -> 0x0038 }
            android.content.Context r2 = r1.getContext()     // Catch:{ NotFoundException -> 0x0038 }
            android.graphics.drawable.Drawable r11 = p098d.p099a.p100c.p101a.C4569a.m16431b(r2, r11)     // Catch:{ NotFoundException -> 0x0038 }
            r1.setButtonDrawable(r11)     // Catch:{ NotFoundException -> 0x0038 }
            goto L_0x0039
        L_0x0038:
            r10 = 0
        L_0x0039:
            if (r10 != 0) goto L_0x0054
            boolean r10 = r0.mo1608s(r8)     // Catch:{ all -> 0x007e }
            if (r10 == 0) goto L_0x0054
            int r10 = r0.mo1603n(r8, r8)     // Catch:{ all -> 0x007e }
            if (r10 == 0) goto L_0x0054
            android.widget.CompoundButton r11 = r9.f1077a     // Catch:{ all -> 0x007e }
            android.content.Context r1 = r11.getContext()     // Catch:{ all -> 0x007e }
            android.graphics.drawable.Drawable r10 = p098d.p099a.p100c.p101a.C4569a.m16431b(r1, r10)     // Catch:{ all -> 0x007e }
            r11.setButtonDrawable(r10)     // Catch:{ all -> 0x007e }
        L_0x0054:
            r10 = 2
            boolean r11 = r0.mo1608s(r10)     // Catch:{ all -> 0x007e }
            if (r11 == 0) goto L_0x0064
            android.widget.CompoundButton r11 = r9.f1077a     // Catch:{ all -> 0x007e }
            android.content.res.ColorStateList r10 = r0.mo1592c(r10)     // Catch:{ all -> 0x007e }
            r11.setButtonTintList(r10)     // Catch:{ all -> 0x007e }
        L_0x0064:
            r10 = 3
            boolean r11 = r0.mo1608s(r10)     // Catch:{ all -> 0x007e }
            if (r11 == 0) goto L_0x007a
            android.widget.CompoundButton r11 = r9.f1077a     // Catch:{ all -> 0x007e }
            r1 = -1
            int r10 = r0.mo1600k(r10, r1)     // Catch:{ all -> 0x007e }
            r1 = 0
            android.graphics.PorterDuff$Mode r10 = androidx.appcompat.widget.C0284o.m1347d(r10, r1)     // Catch:{ all -> 0x007e }
            r11.setButtonTintMode(r10)     // Catch:{ all -> 0x007e }
        L_0x007a:
            r0.mo1609w()
            return
        L_0x007e:
            r10 = move-exception
            r0.mo1609w()
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0255d.mo1581b(android.util.AttributeSet, int):void");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo1582c() {
        if (this.f1082f) {
            this.f1082f = false;
            return;
        }
        this.f1082f = true;
        mo1580a();
    }
}
