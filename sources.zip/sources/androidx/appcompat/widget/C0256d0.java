package androidx.appcompat.widget;

/* renamed from: androidx.appcompat.widget.d0 */
class C0256d0 extends C0303w {
}
