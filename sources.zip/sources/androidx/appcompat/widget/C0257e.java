package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import androidx.appcompat.widget.C0296v;
import com.vidio.android.p195tv.R;
import p098d.p099a.p100c.p101a.C4569a;
import p098d.p120g.p121c.C4693b;

/* renamed from: androidx.appcompat.widget.e */
public final class C0257e {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public static final PorterDuff.Mode f1083a = PorterDuff.Mode.SRC_IN;

    /* renamed from: b */
    private static C0257e f1084b;

    /* renamed from: c */
    public static final /* synthetic */ int f1085c = 0;

    /* renamed from: d */
    private C0296v f1086d;

    /* renamed from: androidx.appcompat.widget.e$a */
    class C0258a implements C0296v.C0301e {

        /* renamed from: a */
        private final int[] f1087a = {R.drawable.abc_textfield_search_default_mtrl_alpha, R.drawable.abc_textfield_default_mtrl_alpha, R.drawable.abc_ab_share_pack_mtrl_alpha};

        /* renamed from: b */
        private final int[] f1088b = {R.drawable.abc_ic_commit_search_api_mtrl_alpha, R.drawable.abc_seekbar_tick_mark_material, R.drawable.abc_ic_menu_share_mtrl_alpha, R.drawable.abc_ic_menu_copy_mtrl_am_alpha, R.drawable.abc_ic_menu_cut_mtrl_alpha, R.drawable.abc_ic_menu_selectall_mtrl_alpha, R.drawable.abc_ic_menu_paste_mtrl_am_alpha};

        /* renamed from: c */
        private final int[] f1089c = {R.drawable.abc_textfield_activated_mtrl_alpha, R.drawable.abc_textfield_search_activated_mtrl_alpha, R.drawable.abc_cab_background_top_mtrl_alpha, R.drawable.abc_text_cursor_material, R.drawable.abc_text_select_handle_left_mtrl_dark, R.drawable.abc_text_select_handle_middle_mtrl_dark, R.drawable.abc_text_select_handle_right_mtrl_dark, R.drawable.abc_text_select_handle_left_mtrl_light, R.drawable.abc_text_select_handle_middle_mtrl_light, R.drawable.abc_text_select_handle_right_mtrl_light};

        /* renamed from: d */
        private final int[] f1090d = {R.drawable.abc_popup_background_mtrl_mult, R.drawable.abc_cab_background_internal_bg, R.drawable.abc_menu_hardkey_panel_mtrl_mult};

        /* renamed from: e */
        private final int[] f1091e = {R.drawable.abc_tab_indicator_material, R.drawable.abc_textfield_search_material};

        /* renamed from: f */
        private final int[] f1092f = {R.drawable.abc_btn_check_material, R.drawable.abc_btn_radio_material, R.drawable.abc_btn_check_material_anim, R.drawable.abc_btn_radio_material_anim};

        C0258a() {
        }

        /* renamed from: a */
        private boolean m1173a(int[] iArr, int i) {
            for (int i2 : iArr) {
                if (i2 == i) {
                    return true;
                }
            }
            return false;
        }

        /* renamed from: b */
        private ColorStateList m1174b(Context context, int i) {
            int c = C0306z.m1394c(context, R.attr.colorControlHighlight);
            int b = C0306z.m1393b(context, R.attr.colorButtonNormal);
            return new ColorStateList(new int[][]{C0306z.f1243b, C0306z.f1245d, C0306z.f1244c, C0306z.f1247f}, new int[]{b, C4693b.m17136e(c, i), C4693b.m17136e(c, i), i});
        }

        /* renamed from: d */
        private void m1175d(Drawable drawable, int i, PorterDuff.Mode mode) {
            if (C0284o.m1344a(drawable)) {
                drawable = drawable.mutate();
            }
            if (mode == null) {
                mode = C0257e.f1083a;
            }
            drawable.setColorFilter(C0257e.m1167e(i, mode));
        }

        /* renamed from: c */
        public ColorStateList mo1587c(Context context, int i) {
            if (i == R.drawable.abc_edit_text_material) {
                return C4569a.m16430a(context, R.color.abc_tint_edittext);
            }
            if (i == R.drawable.abc_switch_track_mtrl_alpha) {
                return C4569a.m16430a(context, R.color.abc_tint_switch_track);
            }
            if (i == R.drawable.abc_switch_thumb_material) {
                int[][] iArr = new int[3][];
                int[] iArr2 = new int[3];
                ColorStateList d = C0306z.m1395d(context, R.attr.colorSwitchThumbNormal);
                if (d == null || !d.isStateful()) {
                    iArr[0] = C0306z.f1243b;
                    iArr2[0] = C0306z.m1393b(context, R.attr.colorSwitchThumbNormal);
                    iArr[1] = C0306z.f1246e;
                    iArr2[1] = C0306z.m1394c(context, R.attr.colorControlActivated);
                    iArr[2] = C0306z.f1247f;
                    iArr2[2] = C0306z.m1394c(context, R.attr.colorSwitchThumbNormal);
                } else {
                    iArr[0] = C0306z.f1243b;
                    iArr2[0] = d.getColorForState(iArr[0], 0);
                    iArr[1] = C0306z.f1246e;
                    iArr2[1] = C0306z.m1394c(context, R.attr.colorControlActivated);
                    iArr[2] = C0306z.f1247f;
                    iArr2[2] = d.getDefaultColor();
                }
                return new ColorStateList(iArr, iArr2);
            } else if (i == R.drawable.abc_btn_default_mtrl_shape) {
                return m1174b(context, C0306z.m1394c(context, R.attr.colorButtonNormal));
            } else {
                if (i == R.drawable.abc_btn_borderless_material) {
                    return m1174b(context, 0);
                }
                if (i == R.drawable.abc_btn_colored_material) {
                    return m1174b(context, C0306z.m1394c(context, R.attr.colorAccent));
                }
                if (i == R.drawable.abc_spinner_mtrl_am_alpha || i == R.drawable.abc_spinner_textfield_background_material) {
                    return C4569a.m16430a(context, R.color.abc_tint_spinner);
                }
                if (m1173a(this.f1088b, i)) {
                    return C0306z.m1395d(context, R.attr.colorControlNormal);
                }
                if (m1173a(this.f1091e, i)) {
                    return C4569a.m16430a(context, R.color.abc_tint_default);
                }
                if (m1173a(this.f1092f, i)) {
                    return C4569a.m16430a(context, R.color.abc_tint_btn_checkable);
                }
                if (i == R.drawable.abc_seekbar_thumb_material) {
                    return C4569a.m16430a(context, R.color.abc_tint_seek_thumb);
                }
                return null;
            }
        }

        /* renamed from: e */
        public boolean mo1588e(Context context, int i, Drawable drawable) {
            LayerDrawable layerDrawable;
            Drawable findDrawableByLayerId;
            int c;
            if (i == R.drawable.abc_seekbar_track_material) {
                layerDrawable = (LayerDrawable) drawable;
                m1175d(layerDrawable.findDrawableByLayerId(16908288), C0306z.m1394c(context, R.attr.colorControlNormal), C0257e.f1083a);
                findDrawableByLayerId = layerDrawable.findDrawableByLayerId(16908303);
                c = C0306z.m1394c(context, R.attr.colorControlNormal);
            } else if (i != R.drawable.abc_ratingbar_material && i != R.drawable.abc_ratingbar_indicator_material && i != R.drawable.abc_ratingbar_small_material) {
                return false;
            } else {
                layerDrawable = (LayerDrawable) drawable;
                m1175d(layerDrawable.findDrawableByLayerId(16908288), C0306z.m1393b(context, R.attr.colorControlNormal), C0257e.f1083a);
                findDrawableByLayerId = layerDrawable.findDrawableByLayerId(16908303);
                c = C0306z.m1394c(context, R.attr.colorControlActivated);
            }
            m1175d(findDrawableByLayerId, c, C0257e.f1083a);
            m1175d(layerDrawable.findDrawableByLayerId(16908301), C0306z.m1394c(context, R.attr.colorControlActivated), C0257e.f1083a);
            return true;
        }

        /* JADX WARNING: Removed duplicated region for block: B:18:0x004a  */
        /* JADX WARNING: Removed duplicated region for block: B:25:0x0065 A[RETURN] */
        /* renamed from: f */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo1589f(android.content.Context r7, int r8, android.graphics.drawable.Drawable r9) {
            /*
                r6 = this;
                android.graphics.PorterDuff$Mode r0 = androidx.appcompat.widget.C0257e.f1083a
                int[] r1 = r6.f1087a
                boolean r1 = r6.m1173a(r1, r8)
                r2 = 16842801(0x1010031, float:2.3693695E-38)
                r3 = -1
                r4 = 0
                r5 = 1
                if (r1 == 0) goto L_0x0018
                r2 = 2130968793(0x7f0400d9, float:1.754625E38)
            L_0x0015:
                r8 = -1
            L_0x0016:
                r1 = 1
                goto L_0x0048
            L_0x0018:
                int[] r1 = r6.f1089c
                boolean r1 = r6.m1173a(r1, r8)
                if (r1 == 0) goto L_0x0024
                r2 = 2130968791(0x7f0400d7, float:1.7546246E38)
                goto L_0x0015
            L_0x0024:
                int[] r1 = r6.f1090d
                boolean r1 = r6.m1173a(r1, r8)
                if (r1 == 0) goto L_0x002f
                android.graphics.PorterDuff$Mode r0 = android.graphics.PorterDuff.Mode.MULTIPLY
                goto L_0x0015
            L_0x002f:
                r1 = 2131230841(0x7f080079, float:1.8077746E38)
                if (r8 != r1) goto L_0x003f
                r2 = 16842800(0x1010030, float:2.3693693E-38)
                r8 = 1109603123(0x42233333, float:40.8)
                int r8 = java.lang.Math.round(r8)
                goto L_0x0016
            L_0x003f:
                r1 = 2131230817(0x7f080061, float:1.8077697E38)
                if (r8 != r1) goto L_0x0045
                goto L_0x0015
            L_0x0045:
                r8 = -1
                r1 = 0
                r2 = 0
            L_0x0048:
                if (r1 == 0) goto L_0x0065
                boolean r1 = androidx.appcompat.widget.C0284o.m1344a(r9)
                if (r1 == 0) goto L_0x0054
                android.graphics.drawable.Drawable r9 = r9.mutate()
            L_0x0054:
                int r7 = androidx.appcompat.widget.C0306z.m1394c(r7, r2)
                android.graphics.PorterDuffColorFilter r7 = androidx.appcompat.widget.C0257e.m1167e(r7, r0)
                r9.setColorFilter(r7)
                if (r8 == r3) goto L_0x0064
                r9.setAlpha(r8)
            L_0x0064:
                return r5
            L_0x0065:
                return r4
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0257e.C0258a.mo1589f(android.content.Context, int, android.graphics.drawable.Drawable):boolean");
        }
    }

    /* renamed from: b */
    public static synchronized C0257e m1166b() {
        C0257e eVar;
        synchronized (C0257e.class) {
            if (f1084b == null) {
                m1168h();
            }
            eVar = f1084b;
        }
        return eVar;
    }

    /* renamed from: e */
    public static synchronized PorterDuffColorFilter m1167e(int i, PorterDuff.Mode mode) {
        PorterDuffColorFilter h;
        synchronized (C0257e.class) {
            h = C0296v.m1374h(i, mode);
        }
        return h;
    }

    /* renamed from: h */
    public static synchronized void m1168h() {
        synchronized (C0257e.class) {
            if (f1084b == null) {
                C0257e eVar = new C0257e();
                f1084b = eVar;
                eVar.f1086d = C0296v.m1372d();
                f1084b.f1086d.mo1737l(new C0258a());
            }
        }
    }

    /* renamed from: c */
    public synchronized Drawable mo1583c(Context context, int i) {
        return this.f1086d.mo1733f(context, i);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public synchronized Drawable mo1584d(Context context, int i, boolean z) {
        return this.f1086d.mo1734g(context, i, z);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public synchronized ColorStateList mo1585f(Context context, int i) {
        return this.f1086d.mo1735i(context, i);
    }

    /* renamed from: g */
    public synchronized void mo1586g(Context context) {
        this.f1086d.mo1736k(context);
    }
}
