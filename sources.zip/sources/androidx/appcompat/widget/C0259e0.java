package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import androidx.core.content.p005b.C0476a;
import androidx.core.content.p005b.C0483h;

/* renamed from: androidx.appcompat.widget.e0 */
public class C0259e0 {

    /* renamed from: a */
    private final Context f1093a;

    /* renamed from: b */
    private final TypedArray f1094b;

    /* renamed from: c */
    private TypedValue f1095c;

    private C0259e0(Context context, TypedArray typedArray) {
        this.f1093a = context;
        this.f1094b = typedArray;
    }

    /* renamed from: t */
    public static C0259e0 m1179t(Context context, int i, int[] iArr) {
        return new C0259e0(context, context.obtainStyledAttributes(i, iArr));
    }

    /* renamed from: u */
    public static C0259e0 m1180u(Context context, AttributeSet attributeSet, int[] iArr) {
        return new C0259e0(context, context.obtainStyledAttributes(attributeSet, iArr));
    }

    /* renamed from: v */
    public static C0259e0 m1181v(Context context, AttributeSet attributeSet, int[] iArr, int i, int i2) {
        return new C0259e0(context, context.obtainStyledAttributes(attributeSet, iArr, i, i2));
    }

    /* renamed from: a */
    public boolean mo1590a(int i, boolean z) {
        return this.f1094b.getBoolean(i, z);
    }

    /* renamed from: b */
    public int mo1591b(int i, int i2) {
        return this.f1094b.getColor(i, i2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0011, code lost:
        r0 = p098d.p099a.p100c.p101a.C4569a.m16430a(r2.f1093a, (r0 = r2.f1094b.getResourceId(r3, 0)));
     */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.content.res.ColorStateList mo1592c(int r3) {
        /*
            r2 = this;
            android.content.res.TypedArray r0 = r2.f1094b
            boolean r0 = r0.hasValue(r3)
            if (r0 == 0) goto L_0x001a
            android.content.res.TypedArray r0 = r2.f1094b
            r1 = 0
            int r0 = r0.getResourceId(r3, r1)
            if (r0 == 0) goto L_0x001a
            android.content.Context r1 = r2.f1093a
            android.content.res.ColorStateList r0 = p098d.p099a.p100c.p101a.C4569a.m16430a(r1, r0)
            if (r0 == 0) goto L_0x001a
            return r0
        L_0x001a:
            android.content.res.TypedArray r0 = r2.f1094b
            android.content.res.ColorStateList r3 = r0.getColorStateList(r3)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0259e0.mo1592c(int):android.content.res.ColorStateList");
    }

    /* renamed from: d */
    public float mo1593d(int i, float f) {
        return this.f1094b.getDimension(i, f);
    }

    /* renamed from: e */
    public int mo1594e(int i, int i2) {
        return this.f1094b.getDimensionPixelOffset(i, i2);
    }

    /* renamed from: f */
    public int mo1595f(int i, int i2) {
        return this.f1094b.getDimensionPixelSize(i, i2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0008, code lost:
        r0 = r2.f1094b.getResourceId(r3, 0);
     */
    /* renamed from: g */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.graphics.drawable.Drawable mo1596g(int r3) {
        /*
            r2 = this;
            android.content.res.TypedArray r0 = r2.f1094b
            boolean r0 = r0.hasValue(r3)
            if (r0 == 0) goto L_0x0018
            android.content.res.TypedArray r0 = r2.f1094b
            r1 = 0
            int r0 = r0.getResourceId(r3, r1)
            if (r0 == 0) goto L_0x0018
            android.content.Context r3 = r2.f1093a
            android.graphics.drawable.Drawable r3 = p098d.p099a.p100c.p101a.C4569a.m16431b(r3, r0)
            return r3
        L_0x0018:
            android.content.res.TypedArray r0 = r2.f1094b
            android.graphics.drawable.Drawable r3 = r0.getDrawable(r3)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0259e0.mo1596g(int):android.graphics.drawable.Drawable");
    }

    /* renamed from: h */
    public Drawable mo1597h(int i) {
        int resourceId;
        if (!this.f1094b.hasValue(i) || (resourceId = this.f1094b.getResourceId(i, 0)) == 0) {
            return null;
        }
        return C0257e.m1166b().mo1584d(this.f1093a, resourceId, true);
    }

    /* renamed from: i */
    public float mo1598i(int i, float f) {
        return this.f1094b.getFloat(i, f);
    }

    /* renamed from: j */
    public Typeface mo1599j(int i, int i2, C0483h hVar) {
        int resourceId = this.f1094b.getResourceId(i, 0);
        if (resourceId == 0) {
            return null;
        }
        if (this.f1095c == null) {
            this.f1095c = new TypedValue();
        }
        return C0476a.m2167e(this.f1093a, resourceId, this.f1095c, i2, hVar);
    }

    /* renamed from: k */
    public int mo1600k(int i, int i2) {
        return this.f1094b.getInt(i, i2);
    }

    /* renamed from: l */
    public int mo1601l(int i, int i2) {
        return this.f1094b.getInteger(i, i2);
    }

    /* renamed from: m */
    public int mo1602m(int i, int i2) {
        return this.f1094b.getLayoutDimension(i, i2);
    }

    /* renamed from: n */
    public int mo1603n(int i, int i2) {
        return this.f1094b.getResourceId(i, i2);
    }

    /* renamed from: o */
    public String mo1604o(int i) {
        return this.f1094b.getString(i);
    }

    /* renamed from: p */
    public CharSequence mo1605p(int i) {
        return this.f1094b.getText(i);
    }

    /* renamed from: q */
    public CharSequence[] mo1606q(int i) {
        return this.f1094b.getTextArray(i);
    }

    /* renamed from: r */
    public TypedArray mo1607r() {
        return this.f1094b;
    }

    /* renamed from: s */
    public boolean mo1608s(int i) {
        return this.f1094b.hasValue(i);
    }

    /* renamed from: w */
    public void mo1609w() {
        this.f1094b.recycle();
    }
}
