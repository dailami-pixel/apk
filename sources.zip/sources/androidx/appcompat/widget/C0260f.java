package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ImageView;
import p098d.p099a.C4568b;
import p098d.p099a.p100c.p101a.C4569a;
import p098d.p120g.p130j.C4761m;

/* renamed from: androidx.appcompat.widget.f */
public class C0260f {

    /* renamed from: a */
    private final ImageView f1096a;

    /* renamed from: b */
    private C0254c0 f1097b;

    /* renamed from: c */
    private C0254c0 f1098c;

    public C0260f(ImageView imageView) {
        this.f1096a = imageView;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo1610a() {
        Drawable drawable = this.f1096a.getDrawable();
        if (drawable != null) {
            C0284o.m1345b(drawable);
        }
        if (drawable != null) {
            int i = Build.VERSION.SDK_INT;
            boolean z = true;
            if (i <= 21 && i == 21) {
                if (this.f1098c == null) {
                    this.f1098c = new C0254c0();
                }
                C0254c0 c0Var = this.f1098c;
                c0Var.f1073a = null;
                c0Var.f1076d = false;
                c0Var.f1074b = null;
                c0Var.f1075c = false;
                ColorStateList imageTintList = this.f1096a.getImageTintList();
                if (imageTintList != null) {
                    c0Var.f1076d = true;
                    c0Var.f1073a = imageTintList;
                }
                PorterDuff.Mode imageTintMode = this.f1096a.getImageTintMode();
                if (imageTintMode != null) {
                    c0Var.f1075c = true;
                    c0Var.f1074b = imageTintMode;
                }
                if (c0Var.f1076d || c0Var.f1075c) {
                    int[] drawableState = this.f1096a.getDrawableState();
                    int i2 = C0257e.f1085c;
                    C0296v.m1377n(drawable, c0Var, drawableState);
                } else {
                    z = false;
                }
                if (z) {
                    return;
                }
            }
            C0254c0 c0Var2 = this.f1097b;
            if (c0Var2 != null) {
                int[] drawableState2 = this.f1096a.getDrawableState();
                int i3 = C0257e.f1085c;
                C0296v.m1377n(drawable, c0Var2, drawableState2);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public ColorStateList mo1611b() {
        C0254c0 c0Var = this.f1097b;
        if (c0Var != null) {
            return c0Var.f1073a;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public PorterDuff.Mode mo1612c() {
        C0254c0 c0Var = this.f1097b;
        if (c0Var != null) {
            return c0Var.f1074b;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public boolean mo1613d() {
        return !(this.f1096a.getBackground() instanceof RippleDrawable);
    }

    /* renamed from: e */
    public void mo1614e(AttributeSet attributeSet, int i) {
        Drawable drawable;
        Drawable drawable2;
        int n;
        Context context = this.f1096a.getContext();
        int[] iArr = C4568b.f16459g;
        C0259e0 v = C0259e0.m1181v(context, attributeSet, iArr, i, 0);
        ImageView imageView = this.f1096a;
        C4761m.m17309r(imageView, imageView.getContext(), iArr, attributeSet, v.mo1607r(), i, 0);
        try {
            Drawable drawable3 = this.f1096a.getDrawable();
            if (!(drawable3 != null || (n = v.mo1603n(1, -1)) == -1 || (drawable3 = C4569a.m16431b(this.f1096a.getContext(), n)) == null)) {
                this.f1096a.setImageDrawable(drawable3);
            }
            if (drawable3 != null) {
                C0284o.m1345b(drawable3);
            }
            if (v.mo1608s(2)) {
                ImageView imageView2 = this.f1096a;
                ColorStateList c = v.mo1592c(2);
                int i2 = Build.VERSION.SDK_INT;
                imageView2.setImageTintList(c);
                if (!(i2 != 21 || (drawable2 = imageView2.getDrawable()) == null || imageView2.getImageTintList() == null)) {
                    if (drawable2.isStateful()) {
                        drawable2.setState(imageView2.getDrawableState());
                    }
                    imageView2.setImageDrawable(drawable2);
                }
            }
            if (v.mo1608s(3)) {
                ImageView imageView3 = this.f1096a;
                PorterDuff.Mode d = C0284o.m1347d(v.mo1600k(3, -1), (PorterDuff.Mode) null);
                int i3 = Build.VERSION.SDK_INT;
                imageView3.setImageTintMode(d);
                if (!(i3 != 21 || (drawable = imageView3.getDrawable()) == null || imageView3.getImageTintList() == null)) {
                    if (drawable.isStateful()) {
                        drawable.setState(imageView3.getDrawableState());
                    }
                    imageView3.setImageDrawable(drawable);
                }
            }
        } finally {
            v.mo1609w();
        }
    }

    /* renamed from: f */
    public void mo1615f(int i) {
        if (i != 0) {
            Drawable b = C4569a.m16431b(this.f1096a.getContext(), i);
            if (b != null) {
                C0284o.m1345b(b);
            }
            this.f1096a.setImageDrawable(b);
        } else {
            this.f1096a.setImageDrawable((Drawable) null);
        }
        mo1610a();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public void mo1616g(ColorStateList colorStateList) {
        if (this.f1097b == null) {
            this.f1097b = new C0254c0();
        }
        C0254c0 c0Var = this.f1097b;
        c0Var.f1073a = colorStateList;
        c0Var.f1076d = true;
        mo1610a();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public void mo1617h(PorterDuff.Mode mode) {
        if (this.f1097b == null) {
            this.f1097b = new C0254c0();
        }
        C0254c0 c0Var = this.f1097b;
        c0Var.f1074b = mode;
        c0Var.f1075c = true;
        mo1610a();
    }
}
