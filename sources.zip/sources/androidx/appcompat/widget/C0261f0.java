package androidx.appcompat.widget;

import android.view.View;
import android.view.Window;
import androidx.appcompat.view.menu.C0151a;

/* renamed from: androidx.appcompat.widget.f0 */
class C0261f0 implements View.OnClickListener {

    /* renamed from: a */
    final C0151a f1099a;

    /* renamed from: b */
    final /* synthetic */ C0263g0 f1100b;

    C0261f0(C0263g0 g0Var) {
        this.f1100b = g0Var;
        this.f1099a = new C0151a(g0Var.f1104a.getContext(), 0, 16908332, 0, g0Var.f1112i);
    }

    public void onClick(View view) {
        C0263g0 g0Var = this.f1100b;
        Window.Callback callback = g0Var.f1115l;
        if (callback != null && g0Var.f1116m) {
            callback.onMenuItemSelected(0, this.f1099a);
        }
    }
}
