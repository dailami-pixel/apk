package androidx.appcompat.widget;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.util.AttributeSet;
import android.widget.ProgressBar;
import androidx.core.graphics.drawable.C0489c;

/* renamed from: androidx.appcompat.widget.g */
class C0262g {

    /* renamed from: a */
    private static final int[] f1101a = {16843067, 16843068};

    /* renamed from: b */
    private final ProgressBar f1102b;

    /* renamed from: c */
    private Bitmap f1103c;

    C0262g(ProgressBar progressBar) {
        this.f1102b = progressBar;
    }

    /* renamed from: c */
    private Drawable m1210c(Drawable drawable, boolean z) {
        if (drawable instanceof C0489c) {
            C0489c cVar = (C0489c) drawable;
            Drawable b = cVar.mo2328b();
            if (b != null) {
                cVar.mo2327a(m1210c(b, z));
            }
        } else if (drawable instanceof LayerDrawable) {
            LayerDrawable layerDrawable = (LayerDrawable) drawable;
            int numberOfLayers = layerDrawable.getNumberOfLayers();
            Drawable[] drawableArr = new Drawable[numberOfLayers];
            for (int i = 0; i < numberOfLayers; i++) {
                int id = layerDrawable.getId(i);
                drawableArr[i] = m1210c(layerDrawable.getDrawable(i), id == 16908301 || id == 16908303);
            }
            LayerDrawable layerDrawable2 = new LayerDrawable(drawableArr);
            for (int i2 = 0; i2 < numberOfLayers; i2++) {
                layerDrawable2.setId(i2, layerDrawable.getId(i2));
            }
            return layerDrawable2;
        } else if (drawable instanceof BitmapDrawable) {
            BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
            Bitmap bitmap = bitmapDrawable.getBitmap();
            if (this.f1103c == null) {
                this.f1103c = bitmap;
            }
            ShapeDrawable shapeDrawable = new ShapeDrawable(new RoundRectShape(new float[]{5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f}, (RectF) null, (float[]) null));
            shapeDrawable.getPaint().setShader(new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP));
            shapeDrawable.getPaint().setColorFilter(bitmapDrawable.getPaint().getColorFilter());
            return z ? new ClipDrawable(shapeDrawable, 3, 1) : shapeDrawable;
        }
        return drawable;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public Bitmap mo1619a() {
        return this.f1103c;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo1620b(AttributeSet attributeSet, int i) {
        C0259e0 v = C0259e0.m1181v(this.f1102b.getContext(), attributeSet, f1101a, i, 0);
        Drawable h = v.mo1597h(0);
        if (h != null) {
            ProgressBar progressBar = this.f1102b;
            if (h instanceof AnimationDrawable) {
                AnimationDrawable animationDrawable = (AnimationDrawable) h;
                int numberOfFrames = animationDrawable.getNumberOfFrames();
                AnimationDrawable animationDrawable2 = new AnimationDrawable();
                animationDrawable2.setOneShot(animationDrawable.isOneShot());
                for (int i2 = 0; i2 < numberOfFrames; i2++) {
                    Drawable c = m1210c(animationDrawable.getFrame(i2), true);
                    c.setLevel(10000);
                    animationDrawable2.addFrame(c, animationDrawable.getDuration(i2));
                }
                animationDrawable2.setLevel(10000);
                h = animationDrawable2;
            }
            progressBar.setIndeterminateDrawable(h);
        }
        Drawable h2 = v.mo1597h(1);
        if (h2 != null) {
            this.f1102b.setProgressDrawable(m1210c(h2, false));
        }
        v.mo1609w();
    }
}
