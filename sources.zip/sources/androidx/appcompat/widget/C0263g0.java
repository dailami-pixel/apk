package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.C0163g;
import androidx.appcompat.view.menu.C0178m;
import com.vidio.android.p195tv.R;
import p098d.p099a.C4568b;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.C4774r;
import p098d.p120g.p130j.C4778t;

/* renamed from: androidx.appcompat.widget.g0 */
public class C0263g0 implements C0283n {

    /* renamed from: a */
    Toolbar f1104a;

    /* renamed from: b */
    private int f1105b;

    /* renamed from: c */
    private View f1106c;

    /* renamed from: d */
    private View f1107d;

    /* renamed from: e */
    private Drawable f1108e;

    /* renamed from: f */
    private Drawable f1109f;

    /* renamed from: g */
    private Drawable f1110g;

    /* renamed from: h */
    private boolean f1111h;

    /* renamed from: i */
    CharSequence f1112i;

    /* renamed from: j */
    private CharSequence f1113j;

    /* renamed from: k */
    private CharSequence f1114k;

    /* renamed from: l */
    Window.Callback f1115l;

    /* renamed from: m */
    boolean f1116m;

    /* renamed from: n */
    private ActionMenuPresenter f1117n;

    /* renamed from: o */
    private int f1118o = 0;

    /* renamed from: p */
    private Drawable f1119p;

    /* renamed from: androidx.appcompat.widget.g0$a */
    class C0264a extends C4778t {

        /* renamed from: a */
        private boolean f1120a = false;

        /* renamed from: b */
        final /* synthetic */ int f1121b;

        C0264a(int i) {
            this.f1121b = i;
        }

        /* renamed from: a */
        public void mo1563a(View view) {
            this.f1120a = true;
        }

        /* renamed from: b */
        public void mo515b(View view) {
            if (!this.f1120a) {
                C0263g0.this.f1104a.setVisibility(this.f1121b);
            }
        }

        /* renamed from: c */
        public void mo559c(View view) {
            C0263g0.this.f1104a.setVisibility(0);
        }
    }

    public C0263g0(Toolbar toolbar, boolean z) {
        Drawable drawable;
        this.f1104a = toolbar;
        this.f1112i = toolbar.mo1541v();
        this.f1113j = toolbar.mo1540u();
        this.f1111h = this.f1112i != null;
        this.f1110g = toolbar.mo1539t();
        String str = null;
        C0259e0 v = C0259e0.m1181v(toolbar.getContext(), (AttributeSet) null, C4568b.f16453a, R.attr.actionBarStyle, 0);
        int i = 15;
        this.f1119p = v.mo1596g(15);
        if (z) {
            CharSequence p = v.mo1605p(27);
            if (!TextUtils.isEmpty(p)) {
                this.f1111h = true;
                this.f1112i = p;
                if ((this.f1105b & 8) != 0) {
                    this.f1104a.mo1514W(p);
                }
            }
            CharSequence p2 = v.mo1605p(25);
            if (!TextUtils.isEmpty(p2)) {
                this.f1113j = p2;
                if ((this.f1105b & 8) != 0) {
                    this.f1104a.mo1512U(p2);
                }
            }
            Drawable g = v.mo1596g(20);
            if (g != null) {
                this.f1109f = g;
                m1215x();
            }
            Drawable g2 = v.mo1596g(17);
            if (g2 != null) {
                this.f1108e = g2;
                m1215x();
            }
            if (this.f1110g == null && (drawable = this.f1119p) != null) {
                this.f1110g = drawable;
                m1214w();
            }
            mo1635m(v.mo1600k(10, 0));
            int n = v.mo1603n(9, 0);
            if (n != 0) {
                View inflate = LayoutInflater.from(this.f1104a.getContext()).inflate(n, this.f1104a, false);
                View view = this.f1107d;
                if (!(view == null || (this.f1105b & 16) == 0)) {
                    this.f1104a.removeView(view);
                }
                this.f1107d = inflate;
                if (!(inflate == null || (this.f1105b & 16) == 0)) {
                    this.f1104a.addView(inflate);
                }
                mo1635m(this.f1105b | 16);
            }
            int m = v.mo1602m(13, 0);
            if (m > 0) {
                ViewGroup.LayoutParams layoutParams = this.f1104a.getLayoutParams();
                layoutParams.height = m;
                this.f1104a.setLayoutParams(layoutParams);
            }
            int e = v.mo1594e(7, -1);
            int e2 = v.mo1594e(3, -1);
            if (e >= 0 || e2 >= 0) {
                this.f1104a.mo1505N(Math.max(e, 0), Math.max(e2, 0));
            }
            int n2 = v.mo1603n(28, 0);
            if (n2 != 0) {
                Toolbar toolbar2 = this.f1104a;
                toolbar2.mo1515X(toolbar2.getContext(), n2);
            }
            int n3 = v.mo1603n(26, 0);
            if (n3 != 0) {
                Toolbar toolbar3 = this.f1104a;
                toolbar3.mo1513V(toolbar3.getContext(), n3);
            }
            int n4 = v.mo1603n(22, 0);
            if (n4 != 0) {
                this.f1104a.mo1511T(n4);
            }
        } else {
            if (this.f1104a.mo1539t() != null) {
                this.f1119p = this.f1104a.mo1539t();
            } else {
                i = 11;
            }
            this.f1105b = i;
        }
        v.mo1609w();
        if (R.string.abc_action_bar_up_description != this.f1118o) {
            this.f1118o = R.string.abc_action_bar_up_description;
            if (TextUtils.isEmpty(this.f1104a.mo1538s())) {
                int i2 = this.f1118o;
                this.f1114k = i2 != 0 ? this.f1104a.getContext().getString(i2) : str;
                m1213v();
            }
        }
        this.f1114k = this.f1104a.mo1538s();
        this.f1104a.mo1510S(new C0261f0(this));
    }

    /* renamed from: v */
    private void m1213v() {
        if ((this.f1105b & 4) == 0) {
            return;
        }
        if (TextUtils.isEmpty(this.f1114k)) {
            Toolbar toolbar = this.f1104a;
            int i = this.f1118o;
            toolbar.mo1508Q(i != 0 ? toolbar.getContext().getText(i) : null);
            return;
        }
        this.f1104a.mo1508Q(this.f1114k);
    }

    /* renamed from: w */
    private void m1214w() {
        Drawable drawable;
        Toolbar toolbar;
        if ((this.f1105b & 4) != 0) {
            toolbar = this.f1104a;
            drawable = this.f1110g;
            if (drawable == null) {
                drawable = this.f1119p;
            }
        } else {
            toolbar = this.f1104a;
            drawable = null;
        }
        toolbar.mo1509R(drawable);
    }

    /* renamed from: x */
    private void m1215x() {
        Drawable drawable;
        int i = this.f1105b;
        if ((i & 2) == 0) {
            drawable = null;
        } else if ((i & 1) == 0 || (drawable = this.f1109f) == null) {
            drawable = this.f1108e;
        }
        this.f1104a.mo1506O(drawable);
    }

    /* renamed from: a */
    public void mo1621a(Menu menu, C0178m.C0179a aVar) {
        if (this.f1117n == null) {
            ActionMenuPresenter actionMenuPresenter = new ActionMenuPresenter(this.f1104a.getContext());
            this.f1117n = actionMenuPresenter;
            actionMenuPresenter.mo703p(R.id.action_menu_presenter);
        }
        this.f1117n.mo695g(aVar);
        this.f1104a.mo1507P((C0163g) menu, this.f1117n);
    }

    /* renamed from: b */
    public void mo1622b(CharSequence charSequence) {
        if (!this.f1111h) {
            this.f1112i = charSequence;
            if ((this.f1105b & 8) != 0) {
                this.f1104a.mo1514W(charSequence);
            }
        }
    }

    /* renamed from: c */
    public boolean mo1623c() {
        return this.f1104a.mo1502G();
    }

    public void collapseActionView() {
        this.f1104a.mo1520f();
    }

    /* renamed from: d */
    public void mo1625d() {
        this.f1116m = true;
    }

    /* renamed from: e */
    public boolean mo1626e() {
        return this.f1104a.mo1519e();
    }

    /* renamed from: f */
    public void mo1627f(Window.Callback callback) {
        this.f1115l = callback;
    }

    /* renamed from: g */
    public boolean mo1628g() {
        return this.f1104a.mo1501F();
    }

    public Context getContext() {
        return this.f1104a.getContext();
    }

    /* renamed from: h */
    public boolean mo1630h() {
        return this.f1104a.mo1500D();
    }

    /* renamed from: i */
    public boolean mo1631i() {
        return this.f1104a.mo1516Z();
    }

    /* renamed from: j */
    public void mo1632j() {
        this.f1104a.mo1521g();
    }

    /* renamed from: k */
    public void mo1633k(C0305y yVar) {
        Toolbar toolbar;
        View view = this.f1106c;
        if (view != null && view.getParent() == (toolbar = this.f1104a)) {
            toolbar.removeView(this.f1106c);
        }
        this.f1106c = null;
    }

    /* renamed from: l */
    public boolean mo1634l() {
        return this.f1104a.mo1499C();
    }

    /* renamed from: m */
    public void mo1635m(int i) {
        View view;
        CharSequence charSequence;
        Toolbar toolbar;
        int i2 = this.f1105b ^ i;
        this.f1105b = i;
        if (i2 != 0) {
            if ((i2 & 4) != 0) {
                if ((i & 4) != 0) {
                    m1213v();
                }
                m1214w();
            }
            if ((i2 & 3) != 0) {
                m1215x();
            }
            if ((i2 & 8) != 0) {
                if ((i & 8) != 0) {
                    this.f1104a.mo1514W(this.f1112i);
                    toolbar = this.f1104a;
                    charSequence = this.f1113j;
                } else {
                    charSequence = null;
                    this.f1104a.mo1514W((CharSequence) null);
                    toolbar = this.f1104a;
                }
                toolbar.mo1512U(charSequence);
            }
            if ((i2 & 16) != 0 && (view = this.f1107d) != null) {
                if ((i & 16) != 0) {
                    this.f1104a.addView(view);
                } else {
                    this.f1104a.removeView(view);
                }
            }
        }
    }

    /* renamed from: n */
    public int mo1636n() {
        return 0;
    }

    /* renamed from: o */
    public C4774r mo1637o(int i, long j) {
        C4774r a = C4761m.m17292a(this.f1104a);
        a.mo21874a(i == 0 ? 1.0f : 0.0f);
        a.mo21877d(j);
        a.mo21879f(new C0264a(i));
        return a;
    }

    /* renamed from: p */
    public ViewGroup mo1638p() {
        return this.f1104a;
    }

    /* renamed from: q */
    public void mo1639q(boolean z) {
    }

    /* renamed from: r */
    public int mo1640r() {
        return this.f1105b;
    }

    /* renamed from: s */
    public void mo1641s() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    public void setVisibility(int i) {
        this.f1104a.setVisibility(i);
    }

    /* renamed from: t */
    public void mo1643t() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    /* renamed from: u */
    public void mo1644u(boolean z) {
        this.f1104a.mo1504M(z);
    }
}
