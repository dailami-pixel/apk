package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;
import androidx.core.graphics.drawable.C0487a;
import p098d.p099a.C4568b;
import p098d.p120g.p130j.C4761m;

/* renamed from: androidx.appcompat.widget.h */
class C0265h extends C0262g {

    /* renamed from: d */
    private final SeekBar f1123d;

    /* renamed from: e */
    private Drawable f1124e;

    /* renamed from: f */
    private ColorStateList f1125f = null;

    /* renamed from: g */
    private PorterDuff.Mode f1126g = null;

    /* renamed from: h */
    private boolean f1127h = false;

    /* renamed from: i */
    private boolean f1128i = false;

    C0265h(SeekBar seekBar) {
        super(seekBar);
        this.f1123d = seekBar;
    }

    /* renamed from: d */
    private void m1240d() {
        Drawable drawable = this.f1124e;
        if (drawable == null) {
            return;
        }
        if (this.f1127h || this.f1128i) {
            Drawable h = C0487a.m2226h(drawable.mutate());
            this.f1124e = h;
            if (this.f1127h) {
                h.setTintList(this.f1125f);
            }
            if (this.f1128i) {
                this.f1124e.setTintMode(this.f1126g);
            }
            if (this.f1124e.isStateful()) {
                this.f1124e.setState(this.f1123d.getDrawableState());
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo1620b(AttributeSet attributeSet, int i) {
        super.mo1620b(attributeSet, i);
        Context context = this.f1123d.getContext();
        int[] iArr = C4568b.f16460h;
        C0259e0 v = C0259e0.m1181v(context, attributeSet, iArr, i, 0);
        SeekBar seekBar = this.f1123d;
        C4761m.m17309r(seekBar, seekBar.getContext(), iArr, attributeSet, v.mo1607r(), i, 0);
        Drawable h = v.mo1597h(0);
        if (h != null) {
            this.f1123d.setThumb(h);
        }
        Drawable g = v.mo1596g(1);
        Drawable drawable = this.f1124e;
        if (drawable != null) {
            drawable.setCallback((Drawable.Callback) null);
        }
        this.f1124e = g;
        if (g != null) {
            g.setCallback(this.f1123d);
            SeekBar seekBar2 = this.f1123d;
            int i2 = C4761m.f17241f;
            C0487a.m2221c(g, seekBar2.getLayoutDirection());
            if (g.isStateful()) {
                g.setState(this.f1123d.getDrawableState());
            }
            m1240d();
        }
        this.f1123d.invalidate();
        if (v.mo1608s(3)) {
            this.f1126g = C0284o.m1347d(v.mo1600k(3, -1), this.f1126g);
            this.f1128i = true;
        }
        if (v.mo1608s(2)) {
            this.f1125f = v.mo1592c(2);
            this.f1127h = true;
        }
        v.mo1609w();
        m1240d();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo1645e(Canvas canvas) {
        if (this.f1124e != null) {
            int max = this.f1123d.getMax();
            int i = 1;
            if (max > 1) {
                int intrinsicWidth = this.f1124e.getIntrinsicWidth();
                int intrinsicHeight = this.f1124e.getIntrinsicHeight();
                int i2 = intrinsicWidth >= 0 ? intrinsicWidth / 2 : 1;
                if (intrinsicHeight >= 0) {
                    i = intrinsicHeight / 2;
                }
                this.f1124e.setBounds(-i2, -i, i2, i);
                float width = ((float) ((this.f1123d.getWidth() - this.f1123d.getPaddingLeft()) - this.f1123d.getPaddingRight())) / ((float) max);
                int save = canvas.save();
                canvas.translate((float) this.f1123d.getPaddingLeft(), (float) (this.f1123d.getHeight() / 2));
                for (int i3 = 0; i3 <= max; i3++) {
                    this.f1124e.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(save);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public void mo1646f() {
        Drawable drawable = this.f1124e;
        if (drawable != null && drawable.isStateful() && drawable.setState(this.f1123d.getDrawableState())) {
            this.f1123d.invalidateDrawable(drawable);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public void mo1647g() {
        Drawable drawable = this.f1124e;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }
}
