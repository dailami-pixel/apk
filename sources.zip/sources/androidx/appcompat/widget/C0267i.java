package androidx.appcompat.widget;

import android.view.View;
import androidx.appcompat.view.menu.C0183p;
import androidx.appcompat.widget.AppCompatSpinner;

/* renamed from: androidx.appcompat.widget.i */
class C0267i extends C0289r {

    /* renamed from: j */
    final /* synthetic */ AppCompatSpinner.C0217d f1129j;

    /* renamed from: k */
    final /* synthetic */ AppCompatSpinner f1130k;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    C0267i(AppCompatSpinner appCompatSpinner, View view, AppCompatSpinner.C0217d dVar) {
        super(view);
        this.f1130k = appCompatSpinner;
        this.f1129j = dVar;
    }

    /* renamed from: b */
    public C0183p mo621b() {
        return this.f1129j;
    }

    /* renamed from: c */
    public boolean mo622c() {
        if (this.f1130k.mo1263b().mo1292a()) {
            return true;
        }
        this.f1130k.mo1264c();
        return true;
    }
}
