package androidx.appcompat.widget;

import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import com.google.android.exoplayer2.p053c1.p056c.C3179b;
import com.google.android.gms.common.api.C4291a;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.C4773q;

/* renamed from: androidx.appcompat.widget.i0 */
class C0268i0 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {

    /* renamed from: a */
    private static C0268i0 f1131a;

    /* renamed from: b */
    private static C0268i0 f1132b;

    /* renamed from: c */
    private final View f1133c;

    /* renamed from: d */
    private final CharSequence f1134d;

    /* renamed from: e */
    private final int f1135e;

    /* renamed from: f */
    private final Runnable f1136f = new C0269a();

    /* renamed from: g */
    private final Runnable f1137g = new C0270b();

    /* renamed from: h */
    private int f1138h;

    /* renamed from: i */
    private int f1139i;

    /* renamed from: j */
    private C0272j0 f1140j;

    /* renamed from: k */
    private boolean f1141k;

    /* renamed from: androidx.appcompat.widget.i0$a */
    class C0269a implements Runnable {
        C0269a() {
        }

        public void run() {
            C0268i0.this.mo1649e(false);
        }
    }

    /* renamed from: androidx.appcompat.widget.i0$b */
    class C0270b implements Runnable {
        C0270b() {
        }

        public void run() {
            C0268i0.this.mo1648b();
        }
    }

    private C0268i0(View view, CharSequence charSequence) {
        this.f1133c = view;
        this.f1134d = charSequence;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(view.getContext());
        int i = C4773q.f17253b;
        this.f1135e = Build.VERSION.SDK_INT >= 28 ? viewConfiguration.getScaledHoverSlop() : viewConfiguration.getScaledTouchSlop() / 2;
        m1249a();
        view.setOnLongClickListener(this);
        view.setOnHoverListener(this);
    }

    /* renamed from: a */
    private void m1249a() {
        this.f1138h = C4291a.C4299e.API_PRIORITY_OTHER;
        this.f1139i = C4291a.C4299e.API_PRIORITY_OTHER;
    }

    /* renamed from: c */
    private static void m1250c(C0268i0 i0Var) {
        C0268i0 i0Var2 = f1131a;
        if (i0Var2 != null) {
            i0Var2.f1133c.removeCallbacks(i0Var2.f1136f);
        }
        f1131a = i0Var;
        if (i0Var != null) {
            i0Var.f1133c.postDelayed(i0Var.f1136f, (long) ViewConfiguration.getLongPressTimeout());
        }
    }

    /* renamed from: d */
    public static void m1251d(View view, CharSequence charSequence) {
        C0268i0 i0Var = f1131a;
        if (i0Var != null && i0Var.f1133c == view) {
            m1250c((C0268i0) null);
        }
        if (TextUtils.isEmpty(charSequence)) {
            C0268i0 i0Var2 = f1132b;
            if (i0Var2 != null && i0Var2.f1133c == view) {
                i0Var2.mo1648b();
            }
            view.setOnLongClickListener((View.OnLongClickListener) null);
            view.setLongClickable(false);
            view.setOnHoverListener((View.OnHoverListener) null);
            return;
        }
        new C0268i0(view, charSequence);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo1648b() {
        if (f1132b == this) {
            f1132b = null;
            C0272j0 j0Var = this.f1140j;
            if (j0Var != null) {
                j0Var.mo1658a();
                this.f1140j = null;
                m1249a();
                this.f1133c.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (f1131a == this) {
            m1250c((C0268i0) null);
        }
        this.f1133c.removeCallbacks(this.f1137g);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo1649e(boolean z) {
        long j;
        View view = this.f1133c;
        int i = C4761m.f17241f;
        if (view.isAttachedToWindow()) {
            m1250c((C0268i0) null);
            C0268i0 i0Var = f1132b;
            if (i0Var != null) {
                i0Var.mo1648b();
            }
            f1132b = this;
            this.f1141k = z;
            C0272j0 j0Var = new C0272j0(this.f1133c.getContext());
            this.f1140j = j0Var;
            j0Var.mo1659b(this.f1133c, this.f1138h, this.f1139i, this.f1141k, this.f1134d);
            this.f1133c.addOnAttachStateChangeListener(this);
            if (this.f1141k) {
                j = 2500;
            } else {
                j = ((this.f1133c.getWindowSystemUiVisibility() & 1) == 1 ? C3179b.MAX_POSITION_FOR_SEEK_TO_PREVIOUS : 15000) - ((long) ViewConfiguration.getLongPressTimeout());
            }
            this.f1133c.removeCallbacks(this.f1137g);
            this.f1133c.postDelayed(this.f1137g, j);
        }
    }

    public boolean onHover(View view, MotionEvent motionEvent) {
        boolean z;
        if (this.f1140j != null && this.f1141k) {
            return false;
        }
        AccessibilityManager accessibilityManager = (AccessibilityManager) this.f1133c.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action != 7) {
            if (action == 10) {
                m1249a();
                mo1648b();
            }
        } else if (this.f1133c.isEnabled() && this.f1140j == null) {
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            if (Math.abs(x - this.f1138h) > this.f1135e || Math.abs(y - this.f1139i) > this.f1135e) {
                this.f1138h = x;
                this.f1139i = y;
                z = true;
            } else {
                z = false;
            }
            if (z) {
                m1250c(this);
            }
        }
        return false;
    }

    public boolean onLongClick(View view) {
        this.f1138h = view.getWidth() / 2;
        this.f1139i = view.getHeight() / 2;
        mo1649e(true);
        return true;
    }

    public void onViewAttachedToWindow(View view) {
    }

    public void onViewDetachedFromWindow(View view) {
        mo1648b();
    }
}
