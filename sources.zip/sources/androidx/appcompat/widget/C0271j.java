package androidx.appcompat.widget;

import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;

/* renamed from: androidx.appcompat.widget.j */
final class C0271j {

    /* renamed from: a */
    private TextView f1144a;

    /* renamed from: b */
    private TextClassifier f1145b;

    C0271j(TextView textView) {
        this.f1144a = textView;
    }

    /* renamed from: a */
    public TextClassifier mo1656a() {
        TextClassifier textClassifier = this.f1145b;
        if (textClassifier != null) {
            return textClassifier;
        }
        TextClassificationManager textClassificationManager = (TextClassificationManager) this.f1144a.getContext().getSystemService(TextClassificationManager.class);
        return textClassificationManager != null ? textClassificationManager.getTextClassifier() : TextClassifier.NO_OP;
    }

    /* renamed from: b */
    public void mo1657b(TextClassifier textClassifier) {
        this.f1145b = textClassifier;
    }
}
