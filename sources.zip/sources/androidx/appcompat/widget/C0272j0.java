package androidx.appcompat.widget;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import com.vidio.android.p195tv.R;

/* renamed from: androidx.appcompat.widget.j0 */
class C0272j0 {

    /* renamed from: a */
    private final Context f1146a;

    /* renamed from: b */
    private final View f1147b;

    /* renamed from: c */
    private final TextView f1148c;

    /* renamed from: d */
    private final WindowManager.LayoutParams f1149d;

    /* renamed from: e */
    private final Rect f1150e = new Rect();

    /* renamed from: f */
    private final int[] f1151f = new int[2];

    /* renamed from: g */
    private final int[] f1152g = new int[2];

    C0272j0(Context context) {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.f1149d = layoutParams;
        this.f1146a = context;
        View inflate = LayoutInflater.from(context).inflate(R.layout.abc_tooltip, (ViewGroup) null);
        this.f1147b = inflate;
        this.f1148c = (TextView) inflate.findViewById(R.id.message);
        layoutParams.setTitle(C0272j0.class.getSimpleName());
        layoutParams.packageName = context.getPackageName();
        layoutParams.type = 1002;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.format = -3;
        layoutParams.windowAnimations = 2131820550;
        layoutParams.flags = 24;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo1658a() {
        if (this.f1147b.getParent() != null) {
            ((WindowManager) this.f1146a.getSystemService("window")).removeView(this.f1147b);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo1659b(View view, int i, int i2, boolean z, CharSequence charSequence) {
        int i3;
        int i4;
        if (this.f1147b.getParent() != null) {
            mo1658a();
        }
        this.f1148c.setText(charSequence);
        WindowManager.LayoutParams layoutParams = this.f1149d;
        layoutParams.token = view.getApplicationWindowToken();
        int dimensionPixelOffset = this.f1146a.getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_threshold);
        if (view.getWidth() < dimensionPixelOffset) {
            i = view.getWidth() / 2;
        }
        if (view.getHeight() >= dimensionPixelOffset) {
            int dimensionPixelOffset2 = this.f1146a.getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_extra_offset);
            i4 = i2 + dimensionPixelOffset2;
            i3 = i2 - dimensionPixelOffset2;
        } else {
            i4 = view.getHeight();
            i3 = 0;
        }
        layoutParams.gravity = 49;
        int dimensionPixelOffset3 = this.f1146a.getResources().getDimensionPixelOffset(z ? R.dimen.tooltip_y_offset_touch : R.dimen.tooltip_y_offset_non_touch);
        View rootView = view.getRootView();
        ViewGroup.LayoutParams layoutParams2 = rootView.getLayoutParams();
        if (!(layoutParams2 instanceof WindowManager.LayoutParams) || ((WindowManager.LayoutParams) layoutParams2).type != 2) {
            Context context = view.getContext();
            while (true) {
                if (!(context instanceof ContextWrapper)) {
                    break;
                } else if (context instanceof Activity) {
                    rootView = ((Activity) context).getWindow().getDecorView();
                    break;
                } else {
                    context = ((ContextWrapper) context).getBaseContext();
                }
            }
        }
        if (rootView == null) {
            Log.e("TooltipPopup", "Cannot find app view");
        } else {
            rootView.getWindowVisibleDisplayFrame(this.f1150e);
            Rect rect = this.f1150e;
            if (rect.left < 0 && rect.top < 0) {
                Resources resources = this.f1146a.getResources();
                int identifier = resources.getIdentifier("status_bar_height", "dimen", "android");
                int dimensionPixelSize = identifier != 0 ? resources.getDimensionPixelSize(identifier) : 0;
                DisplayMetrics displayMetrics = resources.getDisplayMetrics();
                this.f1150e.set(0, dimensionPixelSize, displayMetrics.widthPixels, displayMetrics.heightPixels);
            }
            rootView.getLocationOnScreen(this.f1152g);
            view.getLocationOnScreen(this.f1151f);
            int[] iArr = this.f1151f;
            int i5 = iArr[0];
            int[] iArr2 = this.f1152g;
            iArr[0] = i5 - iArr2[0];
            iArr[1] = iArr[1] - iArr2[1];
            layoutParams.x = (iArr[0] + i) - (rootView.getWidth() / 2);
            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
            this.f1147b.measure(makeMeasureSpec, makeMeasureSpec);
            int measuredHeight = this.f1147b.getMeasuredHeight();
            int[] iArr3 = this.f1151f;
            int i6 = ((iArr3[1] + i3) - dimensionPixelOffset3) - measuredHeight;
            int i7 = iArr3[1] + i4 + dimensionPixelOffset3;
            if (!z ? measuredHeight + i7 > this.f1150e.height() : i6 >= 0) {
                layoutParams.y = i6;
            } else {
                layoutParams.y = i7;
            }
        }
        ((WindowManager) this.f1146a.getSystemService("window")).addView(this.f1147b, this.f1149d);
    }
}
