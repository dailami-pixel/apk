package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.widget.TextView;
import androidx.core.content.p005b.C0483h;
import androidx.core.widget.C0501b;
import java.lang.ref.WeakReference;
import p098d.p099a.C4568b;

/* renamed from: androidx.appcompat.widget.k */
class C0273k {

    /* renamed from: a */
    private final TextView f1153a;

    /* renamed from: b */
    private C0254c0 f1154b;

    /* renamed from: c */
    private C0254c0 f1155c;

    /* renamed from: d */
    private C0254c0 f1156d;

    /* renamed from: e */
    private C0254c0 f1157e;

    /* renamed from: f */
    private C0254c0 f1158f;

    /* renamed from: g */
    private C0254c0 f1159g;

    /* renamed from: h */
    private C0254c0 f1160h;

    /* renamed from: i */
    private final C0276l f1161i;

    /* renamed from: j */
    private int f1162j = 0;

    /* renamed from: k */
    private int f1163k = -1;

    /* renamed from: l */
    private Typeface f1164l;

    /* renamed from: m */
    private boolean f1165m;

    /* renamed from: androidx.appcompat.widget.k$a */
    class C0274a extends C0483h {

        /* renamed from: a */
        final /* synthetic */ int f1166a;

        /* renamed from: b */
        final /* synthetic */ int f1167b;

        /* renamed from: c */
        final /* synthetic */ WeakReference f1168c;

        C0274a(int i, int i2, WeakReference weakReference) {
            this.f1166a = i;
            this.f1167b = i2;
            this.f1168c = weakReference;
        }

        /* renamed from: c */
        public void mo1681c(int i) {
        }

        /* renamed from: d */
        public void mo1682d(Typeface typeface) {
            int i;
            if (Build.VERSION.SDK_INT >= 28 && (i = this.f1166a) != -1) {
                typeface = Typeface.create(typeface, i, (this.f1167b & 2) != 0);
            }
            C0273k.this.mo1671n(this.f1168c, typeface);
        }
    }

    C0273k(TextView textView) {
        this.f1153a = textView;
        this.f1161i = new C0276l(textView);
    }

    /* renamed from: a */
    private void m1258a(Drawable drawable, C0254c0 c0Var) {
        if (drawable != null && c0Var != null) {
            int[] drawableState = this.f1153a.getDrawableState();
            int i = C0257e.f1085c;
            C0296v.m1377n(drawable, c0Var, drawableState);
        }
    }

    /* renamed from: d */
    private static C0254c0 m1259d(Context context, C0257e eVar, int i) {
        ColorStateList f = eVar.mo1585f(context, i);
        if (f == null) {
            return null;
        }
        C0254c0 c0Var = new C0254c0();
        c0Var.f1076d = true;
        c0Var.f1073a = f;
        return c0Var;
    }

    /* renamed from: x */
    private void m1260x(Context context, C0259e0 e0Var) {
        String o;
        Typeface typeface;
        Typeface typeface2;
        this.f1162j = e0Var.mo1600k(2, this.f1162j);
        int i = Build.VERSION.SDK_INT;
        boolean z = false;
        if (i >= 28) {
            int k = e0Var.mo1600k(11, -1);
            this.f1163k = k;
            if (k != -1) {
                this.f1162j = (this.f1162j & 2) | 0;
            }
        }
        int i2 = 10;
        if (e0Var.mo1608s(10) || e0Var.mo1608s(12)) {
            this.f1164l = null;
            if (e0Var.mo1608s(12)) {
                i2 = 12;
            }
            int i3 = this.f1163k;
            int i4 = this.f1162j;
            if (!context.isRestricted()) {
                try {
                    Typeface j = e0Var.mo1599j(i2, this.f1162j, new C0274a(i3, i4, new WeakReference(this.f1153a)));
                    if (j != null) {
                        if (i >= 28 && this.f1163k != -1) {
                            j = Typeface.create(Typeface.create(j, 0), this.f1163k, (this.f1162j & 2) != 0);
                        }
                        this.f1164l = j;
                    }
                    this.f1165m = this.f1164l == null;
                } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
                }
            }
            if (this.f1164l == null && (o = e0Var.mo1604o(i2)) != null) {
                if (Build.VERSION.SDK_INT < 28 || this.f1163k == -1) {
                    typeface = Typeface.create(o, this.f1162j);
                } else {
                    Typeface create = Typeface.create(o, 0);
                    int i5 = this.f1163k;
                    if ((this.f1162j & 2) != 0) {
                        z = true;
                    }
                    typeface = Typeface.create(create, i5, z);
                }
                this.f1164l = typeface;
            }
        } else if (e0Var.mo1608s(1)) {
            this.f1165m = false;
            int k2 = e0Var.mo1600k(1, 1);
            if (k2 == 1) {
                typeface2 = Typeface.SANS_SERIF;
            } else if (k2 == 2) {
                typeface2 = Typeface.SERIF;
            } else if (k2 == 3) {
                typeface2 = Typeface.MONOSPACE;
            } else {
                return;
            }
            this.f1164l = typeface2;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo1660b() {
        if (!(this.f1154b == null && this.f1155c == null && this.f1156d == null && this.f1157e == null)) {
            Drawable[] compoundDrawables = this.f1153a.getCompoundDrawables();
            m1258a(compoundDrawables[0], this.f1154b);
            m1258a(compoundDrawables[1], this.f1155c);
            m1258a(compoundDrawables[2], this.f1156d);
            m1258a(compoundDrawables[3], this.f1157e);
        }
        if (this.f1158f != null || this.f1159g != null) {
            Drawable[] compoundDrawablesRelative = this.f1153a.getCompoundDrawablesRelative();
            m1258a(compoundDrawablesRelative[0], this.f1158f);
            m1258a(compoundDrawablesRelative[2], this.f1159g);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo1661c() {
        this.f1161i.mo1683a();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public int mo1662e() {
        return this.f1161i.mo1684d();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public int mo1663f() {
        return this.f1161i.mo1685e();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public int mo1664g() {
        return this.f1161i.mo1686f();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public int[] mo1665h() {
        return this.f1161i.mo1687g();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public int mo1666i() {
        return this.f1161i.mo1688h();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j */
    public ColorStateList mo1667j() {
        C0254c0 c0Var = this.f1160h;
        if (c0Var != null) {
            return c0Var.f1073a;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k */
    public PorterDuff.Mode mo1668k() {
        C0254c0 c0Var = this.f1160h;
        if (c0Var != null) {
            return c0Var.f1074b;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l */
    public boolean mo1669l() {
        return this.f1161i.mo1689k();
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00fc  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0103  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0111  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0116  */
    /* renamed from: m */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1670m(android.util.AttributeSet r26, int r27) {
        /*
            r25 = this;
            r0 = r25
            r8 = r26
            r9 = r27
            android.widget.TextView r1 = r0.f1153a
            android.content.Context r10 = r1.getContext()
            androidx.appcompat.widget.e r11 = androidx.appcompat.widget.C0257e.m1166b()
            int[] r3 = p098d.p099a.C4568b.f16461i
            r12 = 0
            androidx.appcompat.widget.e0 r13 = androidx.appcompat.widget.C0259e0.m1181v(r10, r8, r3, r9, r12)
            android.widget.TextView r1 = r0.f1153a
            android.content.Context r2 = r1.getContext()
            android.content.res.TypedArray r5 = r13.mo1607r()
            r7 = 0
            r4 = r26
            r6 = r27
            p098d.p120g.p130j.C4761m.m17309r(r1, r2, r3, r4, r5, r6, r7)
            r1 = -1
            int r2 = r13.mo1603n(r12, r1)
            r3 = 3
            boolean r4 = r13.mo1608s(r3)
            if (r4 == 0) goto L_0x003f
            int r4 = r13.mo1603n(r3, r12)
            androidx.appcompat.widget.c0 r4 = m1259d(r10, r11, r4)
            r0.f1154b = r4
        L_0x003f:
            r4 = 1
            boolean r5 = r13.mo1608s(r4)
            if (r5 == 0) goto L_0x0050
            int r5 = r13.mo1603n(r4, r12)
            androidx.appcompat.widget.c0 r5 = m1259d(r10, r11, r5)
            r0.f1155c = r5
        L_0x0050:
            r5 = 4
            boolean r6 = r13.mo1608s(r5)
            if (r6 == 0) goto L_0x0061
            int r6 = r13.mo1603n(r5, r12)
            androidx.appcompat.widget.c0 r6 = m1259d(r10, r11, r6)
            r0.f1156d = r6
        L_0x0061:
            r6 = 2
            boolean r7 = r13.mo1608s(r6)
            if (r7 == 0) goto L_0x0072
            int r7 = r13.mo1603n(r6, r12)
            androidx.appcompat.widget.c0 r7 = m1259d(r10, r11, r7)
            r0.f1157e = r7
        L_0x0072:
            int r7 = android.os.Build.VERSION.SDK_INT
            r14 = 5
            boolean r15 = r13.mo1608s(r14)
            if (r15 == 0) goto L_0x0085
            int r15 = r13.mo1603n(r14, r12)
            androidx.appcompat.widget.c0 r15 = m1259d(r10, r11, r15)
            r0.f1158f = r15
        L_0x0085:
            r15 = 6
            boolean r16 = r13.mo1608s(r15)
            if (r16 == 0) goto L_0x0096
            int r4 = r13.mo1603n(r15, r12)
            androidx.appcompat.widget.c0 r4 = m1259d(r10, r11, r4)
            r0.f1159g = r4
        L_0x0096:
            r13.mo1609w()
            android.widget.TextView r4 = r0.f1153a
            android.text.method.TransformationMethod r4 = r4.getTransformationMethod()
            boolean r4 = r4 instanceof android.text.method.PasswordTransformationMethod
            r6 = 23
            r13 = 14
            if (r2 == r1) goto L_0x011c
            int[] r15 = p098d.p099a.C4568b.f16477y
            androidx.appcompat.widget.e0 r2 = androidx.appcompat.widget.C0259e0.m1179t(r10, r2, r15)
            if (r4 != 0) goto L_0x00bc
            boolean r15 = r2.mo1608s(r13)
            if (r15 == 0) goto L_0x00bc
            boolean r15 = r2.mo1590a(r13, r12)
            r19 = 1
            goto L_0x00bf
        L_0x00bc:
            r15 = 0
            r19 = 0
        L_0x00bf:
            r0.m1260x(r10, r2)
            if (r7 >= r6) goto L_0x00ee
            boolean r20 = r2.mo1608s(r3)
            if (r20 == 0) goto L_0x00cf
            android.content.res.ColorStateList r20 = r2.mo1592c(r3)
            goto L_0x00d1
        L_0x00cf:
            r20 = 0
        L_0x00d1:
            boolean r21 = r2.mo1608s(r5)
            if (r21 == 0) goto L_0x00dc
            android.content.res.ColorStateList r21 = r2.mo1592c(r5)
            goto L_0x00de
        L_0x00dc:
            r21 = 0
        L_0x00de:
            boolean r22 = r2.mo1608s(r14)
            if (r22 == 0) goto L_0x00eb
            android.content.res.ColorStateList r22 = r2.mo1592c(r14)
            r1 = 15
            goto L_0x00f6
        L_0x00eb:
            r1 = 15
            goto L_0x00f4
        L_0x00ee:
            r1 = 15
            r20 = 0
            r21 = 0
        L_0x00f4:
            r22 = 0
        L_0x00f6:
            boolean r18 = r2.mo1608s(r1)
            if (r18 == 0) goto L_0x0103
            java.lang.String r23 = r2.mo1604o(r1)
            r1 = 26
            goto L_0x0107
        L_0x0103:
            r1 = 26
            r23 = 0
        L_0x0107:
            if (r7 < r1) goto L_0x0116
            r1 = 13
            boolean r17 = r2.mo1608s(r1)
            if (r17 == 0) goto L_0x0116
            java.lang.String r24 = r2.mo1604o(r1)
            goto L_0x0118
        L_0x0116:
            r24 = 0
        L_0x0118:
            r2.mo1609w()
            goto L_0x0129
        L_0x011c:
            r15 = 0
            r19 = 0
            r20 = 0
            r21 = 0
            r22 = 0
            r23 = 0
            r24 = 0
        L_0x0129:
            int[] r1 = p098d.p099a.C4568b.f16477y
            androidx.appcompat.widget.e0 r1 = androidx.appcompat.widget.C0259e0.m1181v(r10, r8, r1, r9, r12)
            if (r4 != 0) goto L_0x013d
            boolean r2 = r1.mo1608s(r13)
            if (r2 == 0) goto L_0x013d
            boolean r15 = r1.mo1590a(r13, r12)
            r19 = 1
        L_0x013d:
            if (r7 >= r6) goto L_0x015d
            boolean r2 = r1.mo1608s(r3)
            if (r2 == 0) goto L_0x0149
            android.content.res.ColorStateList r20 = r1.mo1592c(r3)
        L_0x0149:
            boolean r2 = r1.mo1608s(r5)
            if (r2 == 0) goto L_0x0153
            android.content.res.ColorStateList r21 = r1.mo1592c(r5)
        L_0x0153:
            boolean r2 = r1.mo1608s(r14)
            if (r2 == 0) goto L_0x015d
            android.content.res.ColorStateList r22 = r1.mo1592c(r14)
        L_0x015d:
            r2 = r20
            r5 = r21
            r6 = r22
            r14 = 15
            boolean r18 = r1.mo1608s(r14)
            if (r18 == 0) goto L_0x016f
            java.lang.String r23 = r1.mo1604o(r14)
        L_0x016f:
            r14 = r23
            r13 = 26
            if (r7 < r13) goto L_0x0181
            r13 = 13
            boolean r17 = r1.mo1608s(r13)
            if (r17 == 0) goto L_0x0181
            java.lang.String r24 = r1.mo1604o(r13)
        L_0x0181:
            r13 = r24
            r3 = 28
            if (r7 < r3) goto L_0x019d
            boolean r3 = r1.mo1608s(r12)
            if (r3 == 0) goto L_0x019d
            r3 = -1
            int r20 = r1.mo1595f(r12, r3)
            if (r20 != 0) goto L_0x019d
            android.widget.TextView r3 = r0.f1153a
            r20 = r11
            r11 = 0
            r3.setTextSize(r12, r11)
            goto L_0x019f
        L_0x019d:
            r20 = r11
        L_0x019f:
            r0.m1260x(r10, r1)
            r1.mo1609w()
            if (r2 == 0) goto L_0x01ac
            android.widget.TextView r1 = r0.f1153a
            r1.setTextColor(r2)
        L_0x01ac:
            if (r5 == 0) goto L_0x01b3
            android.widget.TextView r1 = r0.f1153a
            r1.setHintTextColor(r5)
        L_0x01b3:
            if (r6 == 0) goto L_0x01ba
            android.widget.TextView r1 = r0.f1153a
            r1.setLinkTextColor(r6)
        L_0x01ba:
            if (r4 != 0) goto L_0x01c3
            if (r19 == 0) goto L_0x01c3
            android.widget.TextView r1 = r0.f1153a
            r1.setAllCaps(r15)
        L_0x01c3:
            android.graphics.Typeface r1 = r0.f1164l
            if (r1 == 0) goto L_0x01d9
            int r2 = r0.f1163k
            r3 = -1
            if (r2 != r3) goto L_0x01d4
            android.widget.TextView r2 = r0.f1153a
            int r3 = r0.f1162j
            r2.setTypeface(r1, r3)
            goto L_0x01d9
        L_0x01d4:
            android.widget.TextView r2 = r0.f1153a
            r2.setTypeface(r1)
        L_0x01d9:
            if (r13 == 0) goto L_0x01e0
            android.widget.TextView r1 = r0.f1153a
            r1.setFontVariationSettings(r13)
        L_0x01e0:
            r1 = 24
            if (r14 == 0) goto L_0x0203
            if (r7 < r1) goto L_0x01f0
            android.widget.TextView r2 = r0.f1153a
            android.os.LocaleList r3 = android.os.LocaleList.forLanguageTags(r14)
            r2.setTextLocales(r3)
            goto L_0x0203
        L_0x01f0:
            r2 = 44
            int r2 = r14.indexOf(r2)
            java.lang.String r2 = r14.substring(r12, r2)
            android.widget.TextView r3 = r0.f1153a
            java.util.Locale r2 = java.util.Locale.forLanguageTag(r2)
            r3.setTextLocale(r2)
        L_0x0203:
            androidx.appcompat.widget.l r2 = r0.f1161i
            r2.mo1690l(r8, r9)
            boolean r2 = androidx.core.widget.C0501b.f2326S
            if (r2 == 0) goto L_0x0247
            androidx.appcompat.widget.l r2 = r0.f1161i
            int r2 = r2.mo1688h()
            if (r2 == 0) goto L_0x0247
            androidx.appcompat.widget.l r2 = r0.f1161i
            int[] r2 = r2.mo1687g()
            int r3 = r2.length
            if (r3 <= 0) goto L_0x0247
            android.widget.TextView r3 = r0.f1153a
            int r3 = r3.getAutoSizeStepGranularity()
            float r3 = (float) r3
            r4 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 == 0) goto L_0x0242
            android.widget.TextView r2 = r0.f1153a
            androidx.appcompat.widget.l r3 = r0.f1161i
            int r3 = r3.mo1685e()
            androidx.appcompat.widget.l r4 = r0.f1161i
            int r4 = r4.mo1684d()
            androidx.appcompat.widget.l r5 = r0.f1161i
            int r5 = r5.mo1686f()
            r2.setAutoSizeTextTypeUniformWithConfiguration(r3, r4, r5, r12)
            goto L_0x0247
        L_0x0242:
            android.widget.TextView r3 = r0.f1153a
            r3.setAutoSizeTextTypeUniformWithPresetSizes(r2, r12)
        L_0x0247:
            int[] r2 = p098d.p099a.C4568b.f16462j
            androidx.appcompat.widget.e0 r2 = androidx.appcompat.widget.C0259e0.m1180u(r10, r8, r2)
            r3 = 8
            r4 = -1
            int r3 = r2.mo1603n(r3, r4)
            r5 = r20
            if (r3 == r4) goto L_0x025d
            android.graphics.drawable.Drawable r3 = r5.mo1583c(r10, r3)
            goto L_0x025e
        L_0x025d:
            r3 = 0
        L_0x025e:
            r6 = 13
            int r6 = r2.mo1603n(r6, r4)
            if (r6 == r4) goto L_0x026b
            android.graphics.drawable.Drawable r6 = r5.mo1583c(r10, r6)
            goto L_0x026c
        L_0x026b:
            r6 = 0
        L_0x026c:
            r8 = 9
            int r8 = r2.mo1603n(r8, r4)
            if (r8 == r4) goto L_0x0279
            android.graphics.drawable.Drawable r8 = r5.mo1583c(r10, r8)
            goto L_0x027a
        L_0x0279:
            r8 = 0
        L_0x027a:
            r9 = 6
            int r9 = r2.mo1603n(r9, r4)
            if (r9 == r4) goto L_0x0286
            android.graphics.drawable.Drawable r9 = r5.mo1583c(r10, r9)
            goto L_0x0287
        L_0x0286:
            r9 = 0
        L_0x0287:
            r11 = 10
            int r11 = r2.mo1603n(r11, r4)
            if (r11 == r4) goto L_0x0294
            android.graphics.drawable.Drawable r11 = r5.mo1583c(r10, r11)
            goto L_0x0295
        L_0x0294:
            r11 = 0
        L_0x0295:
            r13 = 7
            int r13 = r2.mo1603n(r13, r4)
            if (r13 == r4) goto L_0x02a1
            android.graphics.drawable.Drawable r4 = r5.mo1583c(r10, r13)
            goto L_0x02a2
        L_0x02a1:
            r4 = 0
        L_0x02a2:
            if (r11 != 0) goto L_0x02f9
            if (r4 == 0) goto L_0x02a7
            goto L_0x02f9
        L_0x02a7:
            if (r3 != 0) goto L_0x02af
            if (r6 != 0) goto L_0x02af
            if (r8 != 0) goto L_0x02af
            if (r9 == 0) goto L_0x031b
        L_0x02af:
            android.widget.TextView r4 = r0.f1153a
            android.graphics.drawable.Drawable[] r4 = r4.getCompoundDrawablesRelative()
            r5 = r4[r12]
            if (r5 != 0) goto L_0x02e2
            r5 = 2
            r10 = r4[r5]
            if (r10 == 0) goto L_0x02bf
            goto L_0x02e2
        L_0x02bf:
            android.widget.TextView r4 = r0.f1153a
            android.graphics.drawable.Drawable[] r4 = r4.getCompoundDrawables()
            android.widget.TextView r5 = r0.f1153a
            if (r3 == 0) goto L_0x02ca
            goto L_0x02cc
        L_0x02ca:
            r3 = r4[r12]
        L_0x02cc:
            if (r6 == 0) goto L_0x02cf
            goto L_0x02d2
        L_0x02cf:
            r6 = 1
            r6 = r4[r6]
        L_0x02d2:
            if (r8 == 0) goto L_0x02d5
            goto L_0x02d8
        L_0x02d5:
            r8 = 2
            r8 = r4[r8]
        L_0x02d8:
            if (r9 == 0) goto L_0x02db
            goto L_0x02de
        L_0x02db:
            r9 = 3
            r9 = r4[r9]
        L_0x02de:
            r5.setCompoundDrawablesWithIntrinsicBounds(r3, r6, r8, r9)
            goto L_0x031b
        L_0x02e2:
            android.widget.TextView r3 = r0.f1153a
            r5 = r4[r12]
            if (r6 == 0) goto L_0x02e9
            goto L_0x02ec
        L_0x02e9:
            r6 = 1
            r6 = r4[r6]
        L_0x02ec:
            r8 = 2
            r8 = r4[r8]
            if (r9 == 0) goto L_0x02f2
            goto L_0x02f5
        L_0x02f2:
            r9 = 3
            r9 = r4[r9]
        L_0x02f5:
            r3.setCompoundDrawablesRelativeWithIntrinsicBounds(r5, r6, r8, r9)
            goto L_0x031b
        L_0x02f9:
            android.widget.TextView r3 = r0.f1153a
            android.graphics.drawable.Drawable[] r3 = r3.getCompoundDrawablesRelative()
            android.widget.TextView r5 = r0.f1153a
            if (r11 == 0) goto L_0x0304
            goto L_0x0306
        L_0x0304:
            r11 = r3[r12]
        L_0x0306:
            if (r6 == 0) goto L_0x0309
            goto L_0x030c
        L_0x0309:
            r6 = 1
            r6 = r3[r6]
        L_0x030c:
            if (r4 == 0) goto L_0x030f
            goto L_0x0312
        L_0x030f:
            r4 = 2
            r4 = r3[r4]
        L_0x0312:
            if (r9 == 0) goto L_0x0315
            goto L_0x0318
        L_0x0315:
            r8 = 3
            r9 = r3[r8]
        L_0x0318:
            r5.setCompoundDrawablesRelativeWithIntrinsicBounds(r11, r6, r4, r9)
        L_0x031b:
            r3 = 11
            boolean r4 = r2.mo1608s(r3)
            if (r4 == 0) goto L_0x033b
            android.content.res.ColorStateList r3 = r2.mo1592c(r3)
            android.widget.TextView r4 = r0.f1153a
            java.util.Objects.requireNonNull(r4)
            if (r7 < r1) goto L_0x0332
            r4.setCompoundDrawableTintList(r3)
            goto L_0x033b
        L_0x0332:
            boolean r5 = r4 instanceof androidx.core.widget.C0505f
            if (r5 == 0) goto L_0x033b
            androidx.core.widget.f r4 = (androidx.core.widget.C0505f) r4
            r4.setSupportCompoundDrawablesTintList(r3)
        L_0x033b:
            r3 = 12
            boolean r4 = r2.mo1608s(r3)
            if (r4 == 0) goto L_0x0361
            r4 = -1
            int r3 = r2.mo1600k(r3, r4)
            r4 = 0
            android.graphics.PorterDuff$Mode r3 = androidx.appcompat.widget.C0284o.m1347d(r3, r4)
            android.widget.TextView r4 = r0.f1153a
            java.util.Objects.requireNonNull(r4)
            if (r7 < r1) goto L_0x0358
            r4.setCompoundDrawableTintMode(r3)
            goto L_0x0361
        L_0x0358:
            boolean r1 = r4 instanceof androidx.core.widget.C0505f
            if (r1 == 0) goto L_0x0361
            androidx.core.widget.f r4 = (androidx.core.widget.C0505f) r4
            r4.setSupportCompoundDrawablesTintMode(r3)
        L_0x0361:
            r1 = 14
            r3 = -1
            int r1 = r2.mo1595f(r1, r3)
            r4 = 17
            int r4 = r2.mo1595f(r4, r3)
            r5 = 18
            int r5 = r2.mo1595f(r5, r3)
            r2.mo1609w()
            if (r1 == r3) goto L_0x037e
            android.widget.TextView r2 = r0.f1153a
            androidx.core.widget.C0502c.m2292b(r2, r1)
        L_0x037e:
            if (r4 == r3) goto L_0x0385
            android.widget.TextView r1 = r0.f1153a
            androidx.core.widget.C0502c.m2293c(r1, r4)
        L_0x0385:
            if (r5 == r3) goto L_0x038c
            android.widget.TextView r1 = r0.f1153a
            androidx.core.widget.C0502c.m2294d(r1, r5)
        L_0x038c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0273k.mo1670m(android.util.AttributeSet, int):void");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n */
    public void mo1671n(WeakReference<TextView> weakReference, Typeface typeface) {
        if (this.f1165m) {
            this.f1164l = typeface;
            TextView textView = (TextView) weakReference.get();
            if (textView != null) {
                textView.setTypeface(typeface, this.f1162j);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: o */
    public void mo1672o() {
        if (!C0501b.f2326S) {
            this.f1161i.mo1683a();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p */
    public void mo1673p(Context context, int i) {
        String o;
        ColorStateList c;
        C0259e0 t = C0259e0.m1179t(context, i, C4568b.f16477y);
        if (t.mo1608s(14)) {
            this.f1153a.setAllCaps(t.mo1590a(14, false));
        }
        int i2 = Build.VERSION.SDK_INT;
        if (i2 < 23 && t.mo1608s(3) && (c = t.mo1592c(3)) != null) {
            this.f1153a.setTextColor(c);
        }
        if (t.mo1608s(0) && t.mo1595f(0, -1) == 0) {
            this.f1153a.setTextSize(0, 0.0f);
        }
        m1260x(context, t);
        if (i2 >= 26 && t.mo1608s(13) && (o = t.mo1604o(13)) != null) {
            this.f1153a.setFontVariationSettings(o);
        }
        t.mo1609w();
        Typeface typeface = this.f1164l;
        if (typeface != null) {
            this.f1153a.setTypeface(typeface, this.f1162j);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q */
    public void mo1674q(boolean z) {
        this.f1153a.setAllCaps(z);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: r */
    public void mo1675r(int i, int i2, int i3, int i4) throws IllegalArgumentException {
        this.f1161i.mo1691m(i, i2, i3, i4);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: s */
    public void mo1676s(int[] iArr, int i) throws IllegalArgumentException {
        this.f1161i.mo1692n(iArr, i);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: t */
    public void mo1677t(int i) {
        this.f1161i.mo1693o(i);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: u */
    public void mo1678u(ColorStateList colorStateList) {
        if (this.f1160h == null) {
            this.f1160h = new C0254c0();
        }
        C0254c0 c0Var = this.f1160h;
        c0Var.f1073a = colorStateList;
        c0Var.f1076d = colorStateList != null;
        this.f1154b = c0Var;
        this.f1155c = c0Var;
        this.f1156d = c0Var;
        this.f1157e = c0Var;
        this.f1158f = c0Var;
        this.f1159g = c0Var;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: v */
    public void mo1679v(PorterDuff.Mode mode) {
        if (this.f1160h == null) {
            this.f1160h = new C0254c0();
        }
        C0254c0 c0Var = this.f1160h;
        c0Var.f1074b = mode;
        c0Var.f1075c = mode != null;
        this.f1154b = c0Var;
        this.f1155c = c0Var;
        this.f1156d = c0Var;
        this.f1157e = c0Var;
        this.f1158f = c0Var;
        this.f1159g = c0Var;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: w */
    public void mo1680w(int i, float f) {
        if (!C0501b.f2326S && !mo1669l()) {
            this.f1161i.mo1694p(i, f);
        }
    }
}
