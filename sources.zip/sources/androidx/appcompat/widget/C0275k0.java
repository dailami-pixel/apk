package androidx.appcompat.widget;

import android.content.res.Resources;

/* renamed from: androidx.appcompat.widget.k0 */
public class C0275k0 extends Resources {

    /* renamed from: a */
    public static final /* synthetic */ int f1170a = 0;
}
