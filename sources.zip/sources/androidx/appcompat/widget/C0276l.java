package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.os.Build;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.widget.TextView;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;
import p098d.p099a.C4568b;
import p098d.p120g.p130j.C4761m;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.appcompat.widget.l */
class C0276l {

    /* renamed from: a */
    private static final RectF f1171a = new RectF();

    /* renamed from: b */
    private static ConcurrentHashMap<String, Method> f1172b = new ConcurrentHashMap<>();

    /* renamed from: c */
    private static ConcurrentHashMap<String, Field> f1173c = new ConcurrentHashMap<>();

    /* renamed from: d */
    private int f1174d = 0;

    /* renamed from: e */
    private boolean f1175e = false;

    /* renamed from: f */
    private float f1176f = -1.0f;

    /* renamed from: g */
    private float f1177g = -1.0f;

    /* renamed from: h */
    private float f1178h = -1.0f;

    /* renamed from: i */
    private int[] f1179i = new int[0];

    /* renamed from: j */
    private boolean f1180j = false;

    /* renamed from: k */
    private TextPaint f1181k;

    /* renamed from: l */
    private final TextView f1182l;

    /* renamed from: m */
    private final Context f1183m;

    /* renamed from: n */
    private final C0279c f1184n;

    /* renamed from: androidx.appcompat.widget.l$a */
    private static class C0277a extends C0279c {
        C0277a() {
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo1695a(StaticLayout.Builder builder, TextView textView) {
            builder.setTextDirection((TextDirectionHeuristic) C0276l.m1287j(textView, "getTextDirectionHeuristic", TextDirectionHeuristics.FIRSTSTRONG_LTR));
        }
    }

    /* renamed from: androidx.appcompat.widget.l$b */
    private static class C0278b extends C0277a {
        C0278b() {
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo1695a(StaticLayout.Builder builder, TextView textView) {
            builder.setTextDirection(textView.getTextDirectionHeuristic());
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public boolean mo1696b(TextView textView) {
            return textView.isHorizontallyScrollable();
        }
    }

    /* renamed from: androidx.appcompat.widget.l$c */
    private static class C0279c {
        C0279c() {
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo1695a(StaticLayout.Builder builder, TextView textView) {
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public boolean mo1696b(TextView textView) {
            return ((Boolean) C0276l.m1287j(textView, "getHorizontallyScrolling", Boolean.FALSE)).booleanValue();
        }
    }

    C0276l(TextView textView) {
        this.f1182l = textView;
        this.f1183m = textView.getContext();
        int i = Build.VERSION.SDK_INT;
        this.f1184n = i >= 29 ? new C0278b() : i >= 23 ? new C0277a() : new C0279c();
    }

    /* renamed from: b */
    private int[] m1284b(int[] iArr) {
        if (r0 == 0) {
            return iArr;
        }
        Arrays.sort(iArr);
        ArrayList arrayList = new ArrayList();
        for (int i : iArr) {
            if (i > 0 && Collections.binarySearch(arrayList, Integer.valueOf(i)) < 0) {
                arrayList.add(Integer.valueOf(i));
            }
        }
        if (r0 == arrayList.size()) {
            return iArr;
        }
        int size = arrayList.size();
        int[] iArr2 = new int[size];
        for (int i2 = 0; i2 < size; i2++) {
            iArr2[i2] = ((Integer) arrayList.get(i2)).intValue();
        }
        return iArr2;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0104, code lost:
        if (r7.getLineEnd(r7.getLineCount() - 1) != r8.length()) goto L_0x0115;
     */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x011a  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0125  */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private int m1285c(android.graphics.RectF r21) {
        /*
            r20 = this;
            r0 = r20
            r1 = r21
            int[] r2 = r0.f1179i
            int r2 = r2.length
            if (r2 == 0) goto L_0x0131
            r3 = 1
            int r2 = r2 - r3
            r4 = 0
            r5 = 1
            r6 = 0
        L_0x000e:
            if (r5 > r2) goto L_0x012c
            int r6 = r5 + r2
            int r6 = r6 / 2
            int[] r7 = r0.f1179i
            r7 = r7[r6]
            android.widget.TextView r8 = r0.f1182l
            java.lang.CharSequence r8 = r8.getText()
            android.widget.TextView r9 = r0.f1182l
            android.text.method.TransformationMethod r9 = r9.getTransformationMethod()
            if (r9 == 0) goto L_0x002f
            android.widget.TextView r10 = r0.f1182l
            java.lang.CharSequence r9 = r9.getTransformation(r8, r10)
            if (r9 == 0) goto L_0x002f
            r8 = r9
        L_0x002f:
            int r9 = android.os.Build.VERSION.SDK_INT
            android.widget.TextView r10 = r0.f1182l
            int r15 = r10.getMaxLines()
            android.text.TextPaint r10 = r0.f1181k
            if (r10 != 0) goto L_0x0043
            android.text.TextPaint r10 = new android.text.TextPaint
            r10.<init>()
            r0.f1181k = r10
            goto L_0x0046
        L_0x0043:
            r10.reset()
        L_0x0046:
            android.text.TextPaint r10 = r0.f1181k
            android.widget.TextView r11 = r0.f1182l
            android.text.TextPaint r11 = r11.getPaint()
            r10.set(r11)
            android.text.TextPaint r10 = r0.f1181k
            float r7 = (float) r7
            r10.setTextSize(r7)
            android.widget.TextView r7 = r0.f1182l
            android.text.Layout$Alignment r10 = android.text.Layout.Alignment.ALIGN_NORMAL
            java.lang.String r11 = "getLayoutAlignment"
            java.lang.Object r7 = m1287j(r7, r11, r10)
            r14 = r7
            android.text.Layout$Alignment r14 = (android.text.Layout.Alignment) r14
            float r7 = r1.right
            int r13 = java.lang.Math.round(r7)
            r7 = 23
            r12 = -1
            if (r9 < r7) goto L_0x00cb
            int r7 = r8.length()
            android.text.TextPaint r9 = r0.f1181k
            android.text.StaticLayout$Builder r7 = android.text.StaticLayout.Builder.obtain(r8, r4, r7, r9, r13)
            android.text.StaticLayout$Builder r9 = r7.setAlignment(r14)
            android.widget.TextView r10 = r0.f1182l
            float r10 = r10.getLineSpacingExtra()
            android.widget.TextView r11 = r0.f1182l
            float r11 = r11.getLineSpacingMultiplier()
            android.text.StaticLayout$Builder r9 = r9.setLineSpacing(r10, r11)
            android.widget.TextView r10 = r0.f1182l
            boolean r10 = r10.getIncludeFontPadding()
            android.text.StaticLayout$Builder r9 = r9.setIncludePad(r10)
            android.widget.TextView r10 = r0.f1182l
            int r10 = r10.getBreakStrategy()
            android.text.StaticLayout$Builder r9 = r9.setBreakStrategy(r10)
            android.widget.TextView r10 = r0.f1182l
            int r10 = r10.getHyphenationFrequency()
            android.text.StaticLayout$Builder r9 = r9.setHyphenationFrequency(r10)
            if (r15 != r12) goto L_0x00b1
            r10 = 2147483647(0x7fffffff, float:NaN)
            goto L_0x00b2
        L_0x00b1:
            r10 = r15
        L_0x00b2:
            r9.setMaxLines(r10)
            androidx.appcompat.widget.l$c r9 = r0.f1184n     // Catch:{ ClassCastException -> 0x00bd }
            android.widget.TextView r10 = r0.f1182l     // Catch:{ ClassCastException -> 0x00bd }
            r9.mo1695a(r7, r10)     // Catch:{ ClassCastException -> 0x00bd }
            goto L_0x00c4
        L_0x00bd:
            java.lang.String r9 = "ACTVAutoSizeHelper"
            java.lang.String r10 = "Failed to obtain TextDirectionHeuristic, auto size may be incorrect"
            android.util.Log.w(r9, r10)
        L_0x00c4:
            android.text.StaticLayout r7 = r7.build()
            r3 = r15
            r4 = -1
            goto L_0x00ee
        L_0x00cb:
            android.widget.TextView r7 = r0.f1182l
            float r7 = r7.getLineSpacingMultiplier()
            android.widget.TextView r9 = r0.f1182l
            float r16 = r9.getLineSpacingExtra()
            android.widget.TextView r9 = r0.f1182l
            boolean r17 = r9.getIncludeFontPadding()
            android.text.StaticLayout r9 = new android.text.StaticLayout
            android.text.TextPaint r11 = r0.f1181k
            r10 = r9
            r18 = r11
            r11 = r8
            r4 = -1
            r12 = r18
            r3 = r15
            r15 = r7
            r10.<init>(r11, r12, r13, r14, r15, r16, r17)
            r7 = r9
        L_0x00ee:
            if (r3 == r4) goto L_0x0109
            int r4 = r7.getLineCount()
            if (r4 > r3) goto L_0x0107
            int r3 = r7.getLineCount()
            r4 = 1
            int r3 = r3 - r4
            int r3 = r7.getLineEnd(r3)
            int r8 = r8.length()
            if (r3 == r8) goto L_0x010a
            goto L_0x0115
        L_0x0107:
            r4 = 1
            goto L_0x0115
        L_0x0109:
            r4 = 1
        L_0x010a:
            int r3 = r7.getHeight()
            float r3 = (float) r3
            float r7 = r1.bottom
            int r3 = (r3 > r7 ? 1 : (r3 == r7 ? 0 : -1))
            if (r3 <= 0) goto L_0x0117
        L_0x0115:
            r3 = 0
            goto L_0x0118
        L_0x0117:
            r3 = 1
        L_0x0118:
            if (r3 == 0) goto L_0x0125
            int r6 = r6 + 1
            r3 = 1
            r4 = 0
            r19 = r6
            r6 = r5
            r5 = r19
            goto L_0x000e
        L_0x0125:
            int r6 = r6 + -1
            r2 = r6
            r3 = 1
            r4 = 0
            goto L_0x000e
        L_0x012c:
            int[] r1 = r0.f1179i
            r1 = r1[r6]
            return r1
        L_0x0131:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r2 = "No available text sizes to choose from."
            r1.<init>(r2)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0276l.m1285c(android.graphics.RectF):int");
    }

    /* renamed from: i */
    private static Method m1286i(String str) {
        try {
            Method method = f1172b.get(str);
            if (method == null && (method = TextView.class.getDeclaredMethod(str, new Class[0])) != null) {
                method.setAccessible(true);
                f1172b.put(str, method);
            }
            return method;
        } catch (Exception e) {
            Log.w("ACTVAutoSizeHelper", "Failed to retrieve TextView#" + str + "() method", e);
            return null;
        }
    }

    /* renamed from: j */
    static <T> T m1287j(Object obj, String str, T t) {
        try {
            return m1286i(str).invoke(obj, new Object[0]);
        } catch (Exception e) {
            Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#" + str + "() method", e);
            return t;
        }
    }

    /* renamed from: q */
    private boolean m1288q() {
        if (!m1290s() || this.f1174d != 1) {
            this.f1175e = false;
        } else {
            if (!this.f1180j || this.f1179i.length == 0) {
                int floor = ((int) Math.floor((double) ((this.f1178h - this.f1177g) / this.f1176f))) + 1;
                int[] iArr = new int[floor];
                for (int i = 0; i < floor; i++) {
                    iArr[i] = Math.round((((float) i) * this.f1176f) + this.f1177g);
                }
                this.f1179i = m1284b(iArr);
            }
            this.f1175e = true;
        }
        return this.f1175e;
    }

    /* renamed from: r */
    private boolean m1289r() {
        int[] iArr = this.f1179i;
        int length = iArr.length;
        boolean z = length > 0;
        this.f1180j = z;
        if (z) {
            this.f1174d = 1;
            this.f1177g = (float) iArr[0];
            this.f1178h = (float) iArr[length - 1];
            this.f1176f = -1.0f;
        }
        return z;
    }

    /* renamed from: s */
    private boolean m1290s() {
        return !(this.f1182l instanceof AppCompatEditText);
    }

    /* renamed from: t */
    private void m1291t(float f, float f2, float f3) throws IllegalArgumentException {
        if (f <= 0.0f) {
            throw new IllegalArgumentException("Minimum auto-size text size (" + f + "px) is less or equal to (0px)");
        } else if (f2 <= f) {
            throw new IllegalArgumentException("Maximum auto-size text size (" + f2 + "px) is less or equal to minimum auto-size text size (" + f + "px)");
        } else if (f3 > 0.0f) {
            this.f1174d = 1;
            this.f1177g = f;
            this.f1178h = f2;
            this.f1176f = f3;
            this.f1180j = false;
        } else {
            throw new IllegalArgumentException("The auto-size step granularity (" + f3 + "px) is less or equal to (0px)");
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo1683a() {
        if (m1290s() && this.f1174d != 0) {
            if (this.f1175e) {
                if (this.f1182l.getMeasuredHeight() > 0 && this.f1182l.getMeasuredWidth() > 0) {
                    int measuredWidth = this.f1184n.mo1696b(this.f1182l) ? 1048576 : (this.f1182l.getMeasuredWidth() - this.f1182l.getTotalPaddingLeft()) - this.f1182l.getTotalPaddingRight();
                    int height = (this.f1182l.getHeight() - this.f1182l.getCompoundPaddingBottom()) - this.f1182l.getCompoundPaddingTop();
                    if (measuredWidth > 0 && height > 0) {
                        RectF rectF = f1171a;
                        synchronized (rectF) {
                            rectF.setEmpty();
                            rectF.right = (float) measuredWidth;
                            rectF.bottom = (float) height;
                            float c = (float) m1285c(rectF);
                            if (c != this.f1182l.getTextSize()) {
                                mo1694p(0, c);
                            }
                        }
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
            this.f1175e = true;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public int mo1684d() {
        return Math.round(this.f1178h);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public int mo1685e() {
        return Math.round(this.f1177g);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public int mo1686f() {
        return Math.round(this.f1176f);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public int[] mo1687g() {
        return this.f1179i;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public int mo1688h() {
        return this.f1174d;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k */
    public boolean mo1689k() {
        return m1290s() && this.f1174d != 0;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l */
    public void mo1690l(AttributeSet attributeSet, int i) {
        int resourceId;
        Context context = this.f1183m;
        int[] iArr = C4568b.f16462j;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i, 0);
        TextView textView = this.f1182l;
        C4761m.m17309r(textView, textView.getContext(), iArr, attributeSet, obtainStyledAttributes, i, 0);
        if (obtainStyledAttributes.hasValue(5)) {
            this.f1174d = obtainStyledAttributes.getInt(5, 0);
        }
        float dimension = obtainStyledAttributes.hasValue(4) ? obtainStyledAttributes.getDimension(4, -1.0f) : -1.0f;
        float dimension2 = obtainStyledAttributes.hasValue(2) ? obtainStyledAttributes.getDimension(2, -1.0f) : -1.0f;
        float dimension3 = obtainStyledAttributes.hasValue(1) ? obtainStyledAttributes.getDimension(1, -1.0f) : -1.0f;
        if (obtainStyledAttributes.hasValue(3) && (resourceId = obtainStyledAttributes.getResourceId(3, 0)) > 0) {
            TypedArray obtainTypedArray = obtainStyledAttributes.getResources().obtainTypedArray(resourceId);
            int length = obtainTypedArray.length();
            int[] iArr2 = new int[length];
            if (length > 0) {
                for (int i2 = 0; i2 < length; i2++) {
                    iArr2[i2] = obtainTypedArray.getDimensionPixelSize(i2, -1);
                }
                this.f1179i = m1284b(iArr2);
                m1289r();
            }
            obtainTypedArray.recycle();
        }
        obtainStyledAttributes.recycle();
        if (!m1290s()) {
            this.f1174d = 0;
        } else if (this.f1174d == 1) {
            if (!this.f1180j) {
                DisplayMetrics displayMetrics = this.f1183m.getResources().getDisplayMetrics();
                if (dimension2 == -1.0f) {
                    dimension2 = TypedValue.applyDimension(2, 12.0f, displayMetrics);
                }
                if (dimension3 == -1.0f) {
                    dimension3 = TypedValue.applyDimension(2, 112.0f, displayMetrics);
                }
                if (dimension == -1.0f) {
                    dimension = 1.0f;
                }
                m1291t(dimension2, dimension3, dimension);
            }
            m1288q();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: m */
    public void mo1691m(int i, int i2, int i3, int i4) throws IllegalArgumentException {
        if (m1290s()) {
            DisplayMetrics displayMetrics = this.f1183m.getResources().getDisplayMetrics();
            m1291t(TypedValue.applyDimension(i4, (float) i, displayMetrics), TypedValue.applyDimension(i4, (float) i2, displayMetrics), TypedValue.applyDimension(i4, (float) i3, displayMetrics));
            if (m1288q()) {
                mo1683a();
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n */
    public void mo1692n(int[] iArr, int i) throws IllegalArgumentException {
        if (m1290s()) {
            int length = iArr.length;
            if (length > 0) {
                int[] iArr2 = new int[length];
                if (i == 0) {
                    iArr2 = Arrays.copyOf(iArr, length);
                } else {
                    DisplayMetrics displayMetrics = this.f1183m.getResources().getDisplayMetrics();
                    for (int i2 = 0; i2 < length; i2++) {
                        iArr2[i2] = Math.round(TypedValue.applyDimension(i, (float) iArr[i2], displayMetrics));
                    }
                }
                this.f1179i = m1284b(iArr2);
                if (!m1289r()) {
                    StringBuilder P = C4924a.m17863P("None of the preset sizes is valid: ");
                    P.append(Arrays.toString(iArr));
                    throw new IllegalArgumentException(P.toString());
                }
            } else {
                this.f1180j = false;
            }
            if (m1288q()) {
                mo1683a();
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: o */
    public void mo1693o(int i) {
        if (!m1290s()) {
            return;
        }
        if (i == 0) {
            this.f1174d = 0;
            this.f1177g = -1.0f;
            this.f1178h = -1.0f;
            this.f1176f = -1.0f;
            this.f1179i = new int[0];
            this.f1175e = false;
        } else if (i == 1) {
            DisplayMetrics displayMetrics = this.f1183m.getResources().getDisplayMetrics();
            m1291t(TypedValue.applyDimension(2, 12.0f, displayMetrics), TypedValue.applyDimension(2, 112.0f, displayMetrics), 1.0f);
            if (m1288q()) {
                mo1683a();
            }
        } else {
            throw new IllegalArgumentException(C4924a.m17900o("Unknown auto-size text type: ", i));
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p */
    public void mo1694p(int i, float f) {
        Context context = this.f1183m;
        float applyDimension = TypedValue.applyDimension(i, f, (context == null ? Resources.getSystem() : context.getResources()).getDisplayMetrics());
        if (applyDimension != this.f1182l.getPaint().getTextSize()) {
            this.f1182l.getPaint().setTextSize(applyDimension);
            boolean isInLayout = this.f1182l.isInLayout();
            if (this.f1182l.getLayout() != null) {
                this.f1175e = false;
                try {
                    Method i2 = m1286i("nullLayouts");
                    if (i2 != null) {
                        i2.invoke(this.f1182l, new Object[0]);
                    }
                } catch (Exception e) {
                    Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#nullLayouts() method", e);
                }
                if (!isInLayout) {
                    this.f1182l.requestLayout();
                } else {
                    this.f1182l.forceLayout();
                }
                this.f1182l.invalidate();
            }
        }
    }
}
