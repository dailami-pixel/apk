package androidx.appcompat.widget;

import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import java.lang.reflect.Method;
import p098d.p120g.p130j.C4761m;

/* renamed from: androidx.appcompat.widget.l0 */
public class C0280l0 {

    /* renamed from: a */
    private static Method f1185a;

    /* renamed from: b */
    public static final /* synthetic */ int f1186b = 0;

    static {
        try {
            Method declaredMethod = View.class.getDeclaredMethod("computeFitSystemWindows", new Class[]{Rect.class, Rect.class});
            f1185a = declaredMethod;
            if (!declaredMethod.isAccessible()) {
                f1185a.setAccessible(true);
            }
        } catch (NoSuchMethodException unused) {
            Log.d("ViewUtils", "Could not find method computeFitSystemWindows. Oh well.");
        }
    }

    /* renamed from: a */
    public static void m1309a(View view, Rect rect, Rect rect2) {
        Method method = f1185a;
        if (method != null) {
            try {
                method.invoke(view, new Object[]{rect, rect2});
            } catch (Exception e) {
                Log.d("ViewUtils", "Could not invoke computeFitSystemWindows", e);
            }
        }
    }

    /* renamed from: b */
    public static boolean m1310b(View view) {
        int i = C4761m.f17241f;
        return view.getLayoutDirection() == 1;
    }
}
