package androidx.appcompat.widget;

import android.view.Menu;
import android.view.Window;
import androidx.appcompat.view.menu.C0178m;

/* renamed from: androidx.appcompat.widget.m */
public interface C0281m {
    /* renamed from: a */
    void mo1046a(Menu menu, C0178m.C0179a aVar);

    /* renamed from: b */
    void mo1047b(CharSequence charSequence);

    /* renamed from: c */
    boolean mo1048c();

    /* renamed from: d */
    void mo1050d();

    /* renamed from: e */
    boolean mo1052e();

    /* renamed from: f */
    void mo1053f(Window.Callback callback);

    /* renamed from: g */
    boolean mo1055g();

    /* renamed from: h */
    boolean mo1060h();

    /* renamed from: i */
    boolean mo1061i();

    /* renamed from: j */
    void mo1062j(int i);

    /* renamed from: k */
    void mo1063k();
}
