package androidx.appcompat.widget;

/* renamed from: androidx.appcompat.widget.m0 */
public interface C0282m0 {
    /* renamed from: a */
    CharSequence mo1697a();
}
