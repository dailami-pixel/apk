package androidx.appcompat.widget;

import android.content.Context;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.C0178m;
import p098d.p120g.p130j.C4774r;

/* renamed from: androidx.appcompat.widget.n */
public interface C0283n {
    /* renamed from: a */
    void mo1621a(Menu menu, C0178m.C0179a aVar);

    /* renamed from: b */
    void mo1622b(CharSequence charSequence);

    /* renamed from: c */
    boolean mo1623c();

    void collapseActionView();

    /* renamed from: d */
    void mo1625d();

    /* renamed from: e */
    boolean mo1626e();

    /* renamed from: f */
    void mo1627f(Window.Callback callback);

    /* renamed from: g */
    boolean mo1628g();

    Context getContext();

    /* renamed from: h */
    boolean mo1630h();

    /* renamed from: i */
    boolean mo1631i();

    /* renamed from: j */
    void mo1632j();

    /* renamed from: k */
    void mo1633k(C0305y yVar);

    /* renamed from: l */
    boolean mo1634l();

    /* renamed from: m */
    void mo1635m(int i);

    /* renamed from: n */
    int mo1636n();

    /* renamed from: o */
    C4774r mo1637o(int i, long j);

    /* renamed from: p */
    ViewGroup mo1638p();

    /* renamed from: q */
    void mo1639q(boolean z);

    /* renamed from: r */
    int mo1640r();

    /* renamed from: s */
    void mo1641s();

    void setVisibility(int i);

    /* renamed from: t */
    void mo1643t();

    /* renamed from: u */
    void mo1644u(boolean z);
}
