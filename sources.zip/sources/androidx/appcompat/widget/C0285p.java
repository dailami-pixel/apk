package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.core.widget.C0503d;
import com.vidio.android.p195tv.R;
import java.lang.reflect.Field;
import p098d.p099a.p102d.p103a.C4583c;

/* renamed from: androidx.appcompat.widget.p */
class C0285p extends ListView {

    /* renamed from: a */
    private final Rect f1191a = new Rect();

    /* renamed from: b */
    private int f1192b = 0;

    /* renamed from: c */
    private int f1193c = 0;

    /* renamed from: d */
    private int f1194d = 0;

    /* renamed from: e */
    private int f1195e = 0;

    /* renamed from: f */
    private int f1196f;

    /* renamed from: g */
    private Field f1197g;

    /* renamed from: h */
    private C0286a f1198h;

    /* renamed from: i */
    private boolean f1199i;

    /* renamed from: j */
    private boolean f1200j;

    /* renamed from: k */
    private boolean f1201k;

    /* renamed from: l */
    private C0503d f1202l;

    /* renamed from: m */
    C0287b f1203m;

    /* renamed from: androidx.appcompat.widget.p$a */
    private static class C0286a extends C4583c {

        /* renamed from: b */
        private boolean f1204b = true;

        C0286a(Drawable drawable) {
            super(drawable);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo1711b(boolean z) {
            this.f1204b = z;
        }

        public void draw(Canvas canvas) {
            if (this.f1204b) {
                super.draw(canvas);
            }
        }

        public void setHotspot(float f, float f2) {
            if (this.f1204b) {
                super.setHotspot(f, f2);
            }
        }

        public void setHotspotBounds(int i, int i2, int i3, int i4) {
            if (this.f1204b) {
                super.setHotspotBounds(i, i2, i3, i4);
            }
        }

        public boolean setState(int[] iArr) {
            if (this.f1204b) {
                return super.setState(iArr);
            }
            return false;
        }

        public boolean setVisible(boolean z, boolean z2) {
            if (this.f1204b) {
                return super.setVisible(z, z2);
            }
            return false;
        }
    }

    /* renamed from: androidx.appcompat.widget.p$b */
    private class C0287b implements Runnable {
        C0287b() {
        }

        public void run() {
            C0285p pVar = C0285p.this;
            pVar.f1203m = null;
            pVar.drawableStateChanged();
        }
    }

    C0285p(Context context, boolean z) {
        super(context, (AttributeSet) null, R.attr.dropDownListViewStyle);
        this.f1200j = z;
        setCacheColorHint(0);
        try {
            Field declaredField = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
            this.f1197g = declaredField;
            declaredField.setAccessible(true);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: d */
    private void m1348d() {
        Drawable selector = getSelector();
        if (selector != null && this.f1201k && isPressed()) {
            selector.setState(getDrawableState());
        }
    }

    /* renamed from: a */
    public int mo1698a(int i, int i2, int i3, int i4, int i5) {
        int listPaddingTop = getListPaddingTop();
        int listPaddingBottom = getListPaddingBottom();
        int dividerHeight = getDividerHeight();
        Drawable divider = getDivider();
        ListAdapter adapter = getAdapter();
        int i6 = listPaddingTop + listPaddingBottom;
        if (adapter == null) {
            return i6;
        }
        if (dividerHeight <= 0 || divider == null) {
            dividerHeight = 0;
        }
        int count = adapter.getCount();
        View view = null;
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        while (i7 < count) {
            int itemViewType = adapter.getItemViewType(i7);
            if (itemViewType != i8) {
                view = null;
                i8 = itemViewType;
            }
            view = adapter.getView(i7, view, this);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams == null) {
                layoutParams = generateDefaultLayoutParams();
                view.setLayoutParams(layoutParams);
            }
            int i10 = layoutParams.height;
            view.measure(i, i10 > 0 ? View.MeasureSpec.makeMeasureSpec(i10, 1073741824) : View.MeasureSpec.makeMeasureSpec(0, 0));
            view.forceLayout();
            if (i7 > 0) {
                i6 += dividerHeight;
            }
            i6 += view.getMeasuredHeight();
            if (i6 >= i4) {
                return (i5 < 0 || i7 <= i5 || i9 <= 0 || i6 == i4) ? i4 : i9;
            }
            if (i5 >= 0 && i7 >= i5) {
                i9 = i6;
            }
            i7++;
        }
        return i6;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0010, code lost:
        if (r3 != 3) goto L_0x0012;
     */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x0022  */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x0142  */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x0147  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x015e  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo1699b(android.view.MotionEvent r17, int r18) {
        /*
            r16 = this;
            r1 = r16
            r2 = r17
            int r3 = r17.getActionMasked()
            r4 = 1
            r5 = 0
            if (r3 == r4) goto L_0x001a
            r0 = 2
            if (r3 == r0) goto L_0x0018
            r0 = 3
            if (r3 == r0) goto L_0x0016
        L_0x0012:
            r0 = 1
        L_0x0013:
            r4 = 0
            goto L_0x0129
        L_0x0016:
            r0 = 0
            goto L_0x0013
        L_0x0018:
            r0 = 1
            goto L_0x001b
        L_0x001a:
            r0 = 0
        L_0x001b:
            int r6 = r17.findPointerIndex(r18)
            if (r6 >= 0) goto L_0x0022
            goto L_0x0016
        L_0x0022:
            float r7 = r2.getX(r6)
            int r7 = (int) r7
            float r6 = r2.getY(r6)
            int r6 = (int) r6
            int r8 = r1.pointToPosition(r7, r6)
            r9 = -1
            if (r8 != r9) goto L_0x0035
            goto L_0x0129
        L_0x0035:
            int r0 = r16.getFirstVisiblePosition()
            int r0 = r8 - r0
            android.view.View r10 = r1.getChildAt(r0)
            float r7 = (float) r7
            float r6 = (float) r6
            r1.f1201k = r4
            r1.drawableHotspotChanged(r7, r6)
            boolean r0 = r16.isPressed()
            if (r0 != 0) goto L_0x004f
            r1.setPressed(r4)
        L_0x004f:
            r16.layoutChildren()
            int r0 = r1.f1196f
            if (r0 == r9) goto L_0x006c
            int r11 = r16.getFirstVisiblePosition()
            int r0 = r0 - r11
            android.view.View r0 = r1.getChildAt(r0)
            if (r0 == 0) goto L_0x006c
            if (r0 == r10) goto L_0x006c
            boolean r11 = r0.isPressed()
            if (r11 == 0) goto L_0x006c
            r0.setPressed(r5)
        L_0x006c:
            r1.f1196f = r8
            int r0 = r10.getLeft()
            float r0 = (float) r0
            float r0 = r7 - r0
            int r11 = r10.getTop()
            float r11 = (float) r11
            float r11 = r6 - r11
            r10.drawableHotspotChanged(r0, r11)
            boolean r0 = r10.isPressed()
            if (r0 != 0) goto L_0x0088
            r10.setPressed(r4)
        L_0x0088:
            android.graphics.drawable.Drawable r11 = r16.getSelector()
            if (r11 == 0) goto L_0x0092
            if (r8 == r9) goto L_0x0092
            r12 = 1
            goto L_0x0093
        L_0x0092:
            r12 = 0
        L_0x0093:
            if (r12 == 0) goto L_0x0098
            r11.setVisible(r5, r5)
        L_0x0098:
            android.graphics.Rect r0 = r1.f1191a
            int r13 = r10.getLeft()
            int r14 = r10.getTop()
            int r15 = r10.getRight()
            int r4 = r10.getBottom()
            r0.set(r13, r14, r15, r4)
            int r4 = r0.left
            int r13 = r1.f1192b
            int r4 = r4 - r13
            r0.left = r4
            int r4 = r0.top
            int r13 = r1.f1193c
            int r4 = r4 - r13
            r0.top = r4
            int r4 = r0.right
            int r13 = r1.f1194d
            int r4 = r4 + r13
            r0.right = r4
            int r4 = r0.bottom
            int r13 = r1.f1195e
            int r4 = r4 + r13
            r0.bottom = r4
            java.lang.reflect.Field r0 = r1.f1197g     // Catch:{ IllegalAccessException -> 0x00e9 }
            boolean r0 = r0.getBoolean(r1)     // Catch:{ IllegalAccessException -> 0x00e9 }
            boolean r4 = r10.isEnabled()     // Catch:{ IllegalAccessException -> 0x00e9 }
            if (r4 == r0) goto L_0x00ed
            java.lang.reflect.Field r4 = r1.f1197g     // Catch:{ IllegalAccessException -> 0x00e9 }
            if (r0 != 0) goto L_0x00db
            r0 = 1
            goto L_0x00dc
        L_0x00db:
            r0 = 0
        L_0x00dc:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)     // Catch:{ IllegalAccessException -> 0x00e9 }
            r4.set(r1, r0)     // Catch:{ IllegalAccessException -> 0x00e9 }
            if (r8 == r9) goto L_0x00ed
            r16.refreshDrawableState()     // Catch:{ IllegalAccessException -> 0x00e9 }
            goto L_0x00ed
        L_0x00e9:
            r0 = move-exception
            r0.printStackTrace()
        L_0x00ed:
            if (r12 == 0) goto L_0x0108
            android.graphics.Rect r0 = r1.f1191a
            float r4 = r0.exactCenterX()
            float r0 = r0.exactCenterY()
            int r12 = r16.getVisibility()
            if (r12 != 0) goto L_0x0101
            r12 = 1
            goto L_0x0102
        L_0x0101:
            r12 = 0
        L_0x0102:
            r11.setVisible(r12, r5)
            r11.setHotspot(r4, r0)
        L_0x0108:
            android.graphics.drawable.Drawable r0 = r16.getSelector()
            if (r0 == 0) goto L_0x0113
            if (r8 == r9) goto L_0x0113
            r0.setHotspot(r7, r6)
        L_0x0113:
            androidx.appcompat.widget.p$a r0 = r1.f1198h
            if (r0 == 0) goto L_0x011a
            r0.mo1711b(r5)
        L_0x011a:
            r16.refreshDrawableState()
            r4 = 1
            if (r3 != r4) goto L_0x0012
            long r3 = r1.getItemIdAtPosition(r8)
            r1.performItemClick(r10, r8, r3)
            goto L_0x0012
        L_0x0129:
            if (r0 == 0) goto L_0x012d
            if (r4 == 0) goto L_0x0145
        L_0x012d:
            r1.f1201k = r5
            r1.setPressed(r5)
            r16.drawableStateChanged()
            int r3 = r1.f1196f
            int r4 = r16.getFirstVisiblePosition()
            int r3 = r3 - r4
            android.view.View r3 = r1.getChildAt(r3)
            if (r3 == 0) goto L_0x0145
            r3.setPressed(r5)
        L_0x0145:
            if (r0 == 0) goto L_0x015e
            androidx.core.widget.d r3 = r1.f1202l
            if (r3 != 0) goto L_0x0152
            androidx.core.widget.d r3 = new androidx.core.widget.d
            r3.<init>(r1)
            r1.f1202l = r3
        L_0x0152:
            androidx.core.widget.d r3 = r1.f1202l
            r4 = 1
            r3.mo2448f(r4)
            androidx.core.widget.d r3 = r1.f1202l
            r3.onTouch(r1, r2)
            goto L_0x0165
        L_0x015e:
            androidx.core.widget.d r2 = r1.f1202l
            if (r2 == 0) goto L_0x0165
            r2.mo2448f(r5)
        L_0x0165:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0285p.mo1699b(android.view.MotionEvent, int):boolean");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo1700c(boolean z) {
        this.f1199i = z;
    }

    /* access modifiers changed from: protected */
    public void dispatchDraw(Canvas canvas) {
        Drawable selector;
        if (!this.f1191a.isEmpty() && (selector = getSelector()) != null) {
            selector.setBounds(this.f1191a);
            selector.draw(canvas);
        }
        super.dispatchDraw(canvas);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        if (this.f1203m == null) {
            super.drawableStateChanged();
            C0286a aVar = this.f1198h;
            if (aVar != null) {
                aVar.mo1711b(true);
            }
            m1348d();
        }
    }

    public boolean hasFocus() {
        return this.f1200j || super.hasFocus();
    }

    public boolean hasWindowFocus() {
        return this.f1200j || super.hasWindowFocus();
    }

    public boolean isFocused() {
        return this.f1200j || super.isFocused();
    }

    public boolean isInTouchMode() {
        return (this.f1200j && this.f1199i) || super.isInTouchMode();
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        this.f1203m = null;
        super.onDetachedFromWindow();
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        if (Build.VERSION.SDK_INT < 26) {
            return super.onHoverEvent(motionEvent);
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 10 && this.f1203m == null) {
            C0287b bVar = new C0287b();
            this.f1203m = bVar;
            post(bVar);
        }
        boolean onHoverEvent = super.onHoverEvent(motionEvent);
        if (actionMasked == 9 || actionMasked == 7) {
            int pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
            if (!(pointToPosition == -1 || pointToPosition == getSelectedItemPosition())) {
                View childAt = getChildAt(pointToPosition - getFirstVisiblePosition());
                if (childAt.isEnabled()) {
                    setSelectionFromTop(pointToPosition, childAt.getTop() - getTop());
                }
                m1348d();
            }
        } else {
            setSelection(-1);
        }
        return onHoverEvent;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f1196f = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        C0287b bVar = this.f1203m;
        if (bVar != null) {
            C0285p pVar = C0285p.this;
            pVar.f1203m = null;
            pVar.removeCallbacks(bVar);
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setSelector(Drawable drawable) {
        C0286a aVar = drawable != null ? new C0286a(drawable) : null;
        this.f1198h = aVar;
        super.setSelector(aVar);
        Rect rect = new Rect();
        if (drawable != null) {
            drawable.getPadding(rect);
        }
        this.f1192b = rect.left;
        this.f1193c = rect.top;
        this.f1194d = rect.right;
        this.f1195e = rect.bottom;
    }
}
