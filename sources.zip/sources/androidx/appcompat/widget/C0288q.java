package androidx.appcompat.widget;

import android.graphics.Rect;

/* renamed from: androidx.appcompat.widget.q */
public interface C0288q {
    /* renamed from: a */
    void mo1718a(Rect rect);
}
