package androidx.appcompat.widget;

import android.view.View;
import android.widget.AdapterView;

/* renamed from: androidx.appcompat.widget.s */
class C0292s implements AdapterView.OnItemSelectedListener {

    /* renamed from: a */
    final /* synthetic */ ListPopupWindow f1217a;

    C0292s(ListPopupWindow listPopupWindow) {
        this.f1217a = listPopupWindow;
    }

    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        C0285p pVar;
        if (i != -1 && (pVar = this.f1217a.f874f) != null) {
            pVar.mo1700c(false);
        }
    }

    public void onNothingSelected(AdapterView<?> adapterView) {
    }
}
