package androidx.appcompat.widget;

import android.view.MenuItem;
import androidx.appcompat.view.menu.C0163g;

/* renamed from: androidx.appcompat.widget.t */
public interface C0293t {
    /* renamed from: c */
    void mo730c(C0163g gVar, MenuItem menuItem);

    /* renamed from: f */
    void mo731f(C0163g gVar, MenuItem menuItem);
}
