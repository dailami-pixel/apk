package androidx.appcompat.widget;

import android.content.Context;
import android.os.Build;
import android.transition.Transition;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.C0162f;
import androidx.appcompat.view.menu.C0163g;
import androidx.appcompat.view.menu.C0167i;
import androidx.appcompat.view.menu.ListMenuItemView;
import java.lang.reflect.Method;

/* renamed from: androidx.appcompat.widget.u */
public class C0294u extends ListPopupWindow implements C0293t {

    /* renamed from: D */
    private static Method f1218D;

    /* renamed from: E */
    private C0293t f1219E;

    /* renamed from: androidx.appcompat.widget.u$a */
    public static class C0295a extends C0285p {

        /* renamed from: n */
        final int f1220n;

        /* renamed from: o */
        final int f1221o;

        /* renamed from: p */
        private C0293t f1222p;

        /* renamed from: q */
        private MenuItem f1223q;

        public C0295a(Context context, boolean z) {
            super(context, z);
            if (1 == context.getResources().getConfiguration().getLayoutDirection()) {
                this.f1220n = 21;
                this.f1221o = 22;
                return;
            }
            this.f1220n = 22;
            this.f1221o = 21;
        }

        /* renamed from: e */
        public void mo1731e(C0293t tVar) {
            this.f1222p = tVar;
        }

        public boolean onHoverEvent(MotionEvent motionEvent) {
            int i;
            int pointToPosition;
            int i2;
            if (this.f1222p != null) {
                ListAdapter adapter = getAdapter();
                if (adapter instanceof HeaderViewListAdapter) {
                    HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
                    i = headerViewListAdapter.getHeadersCount();
                    adapter = headerViewListAdapter.getWrappedAdapter();
                } else {
                    i = 0;
                }
                C0162f fVar = (C0162f) adapter;
                C0167i iVar = null;
                if (motionEvent.getAction() != 10 && (pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY())) != -1 && (i2 = pointToPosition - i) >= 0 && i2 < fVar.getCount()) {
                    iVar = fVar.getItem(i2);
                }
                MenuItem menuItem = this.f1223q;
                if (menuItem != iVar) {
                    C0163g b = fVar.mo745b();
                    if (menuItem != null) {
                        this.f1222p.mo731f(b, menuItem);
                    }
                    this.f1223q = iVar;
                    if (iVar != null) {
                        this.f1222p.mo730c(b, iVar);
                    }
                }
            }
            return super.onHoverEvent(motionEvent);
        }

        public boolean onKeyDown(int i, KeyEvent keyEvent) {
            ListMenuItemView listMenuItemView = (ListMenuItemView) getSelectedView();
            if (listMenuItemView != null && i == this.f1220n) {
                if (listMenuItemView.isEnabled() && listMenuItemView.mo608b().hasSubMenu()) {
                    performItemClick(listMenuItemView, getSelectedItemPosition(), getSelectedItemId());
                }
                return true;
            } else if (listMenuItemView == null || i != this.f1221o) {
                return super.onKeyDown(i, keyEvent);
            } else {
                setSelection(-1);
                ((C0162f) getAdapter()).mo745b().mo785e(false);
                return true;
            }
        }
    }

    static {
        try {
            if (Build.VERSION.SDK_INT <= 28) {
                f1218D = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[]{Boolean.TYPE});
            }
        } catch (NoSuchMethodException unused) {
            Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
        }
    }

    public C0294u(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, (AttributeSet) null, i, i2);
    }

    /* renamed from: H */
    public void mo1727H(Object obj) {
        if (Build.VERSION.SDK_INT >= 23) {
            this.f871C.setEnterTransition((Transition) null);
        }
    }

    /* renamed from: I */
    public void mo1728I(Object obj) {
        if (Build.VERSION.SDK_INT >= 23) {
            this.f871C.setExitTransition((Transition) null);
        }
    }

    /* renamed from: J */
    public void mo1729J(C0293t tVar) {
        this.f1219E = tVar;
    }

    /* renamed from: K */
    public void mo1730K(boolean z) {
        if (Build.VERSION.SDK_INT <= 28) {
            Method method = f1218D;
            if (method != null) {
                try {
                    method.invoke(this.f871C, new Object[]{Boolean.valueOf(z)});
                } catch (Exception unused) {
                    Log.i("MenuPopupWindow", "Could not invoke setTouchModal() on PopupWindow. Oh well.");
                }
            }
        } else {
            this.f871C.setTouchModal(z);
        }
    }

    /* renamed from: c */
    public void mo730c(C0163g gVar, MenuItem menuItem) {
        C0293t tVar = this.f1219E;
        if (tVar != null) {
            tVar.mo730c(gVar, menuItem);
        }
    }

    /* renamed from: f */
    public void mo731f(C0163g gVar, MenuItem menuItem) {
        C0293t tVar = this.f1219E;
        if (tVar != null) {
            tVar.mo731f(gVar, menuItem);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p */
    public C0285p mo1402p(Context context, boolean z) {
        C0295a aVar = new C0295a(context, z);
        aVar.mo1731e(this);
        return aVar;
    }
}
