package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import androidx.appcompat.widget.C0257e;
import androidx.core.graphics.drawable.C0487a;
import com.vidio.android.p195tv.R;
import java.lang.ref.WeakReference;
import java.util.Objects;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import p098d.p099a.p102d.p103a.C4571a;
import p098d.p112d.C4623g;
import p098d.p112d.C4624h;
import p098d.p112d.C4631j;
import p098d.p112d.C4632k;
import p098d.p161u.p162a.p163a.C4905b;
import p098d.p161u.p162a.p163a.C4913g;

/* renamed from: androidx.appcompat.widget.v */
public final class C0296v {

    /* renamed from: a */
    private static final PorterDuff.Mode f1224a = PorterDuff.Mode.SRC_IN;

    /* renamed from: b */
    private static C0296v f1225b;

    /* renamed from: c */
    private static final C0299c f1226c = new C0299c(6);

    /* renamed from: d */
    private WeakHashMap<Context, C4632k<ColorStateList>> f1227d;

    /* renamed from: e */
    private C4631j<String, C0300d> f1228e;

    /* renamed from: f */
    private C4632k<String> f1229f;

    /* renamed from: g */
    private final WeakHashMap<Context, C4623g<WeakReference<Drawable.ConstantState>>> f1230g = new WeakHashMap<>(0);

    /* renamed from: h */
    private TypedValue f1231h;

    /* renamed from: i */
    private boolean f1232i;

    /* renamed from: j */
    private C0301e f1233j;

    /* renamed from: androidx.appcompat.widget.v$a */
    static class C0297a implements C0300d {
        C0297a() {
        }

        /* renamed from: a */
        public Drawable mo1738a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return C4571a.m16432i(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e) {
                Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", e);
                return null;
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.v$b */
    private static class C0298b implements C0300d {
        C0298b() {
        }

        /* renamed from: a */
        public Drawable mo1738a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return C4905b.m17824a(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e) {
                Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", e);
                return null;
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.v$c */
    private static class C0299c extends C4624h<Integer, PorterDuffColorFilter> {
        public C0299c(int i) {
            super(i);
        }
    }

    /* renamed from: androidx.appcompat.widget.v$d */
    private interface C0300d {
        /* renamed from: a */
        Drawable mo1738a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme);
    }

    /* renamed from: androidx.appcompat.widget.v$e */
    interface C0301e {
    }

    /* renamed from: androidx.appcompat.widget.v$f */
    private static class C0302f implements C0300d {
        C0302f() {
        }

        /* renamed from: a */
        public Drawable mo1738a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return C4913g.m17832a(context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e) {
                Log.e("VdcInflateDelegate", "Exception while inflating <vector>", e);
                return null;
            }
        }
    }

    /* renamed from: a */
    private void m1369a(String str, C0300d dVar) {
        if (this.f1228e == null) {
            this.f1228e = new C4631j<>();
        }
        this.f1228e.put(str, dVar);
    }

    /* renamed from: b */
    private synchronized boolean m1370b(Context context, long j, Drawable drawable) {
        boolean z;
        Drawable.ConstantState constantState = drawable.getConstantState();
        if (constantState != null) {
            C4623g gVar = this.f1230g.get(context);
            if (gVar == null) {
                gVar = new C4623g(10);
                this.f1230g.put(context, gVar);
            }
            gVar.mo21366j(j, new WeakReference(constantState));
            z = true;
        } else {
            z = false;
        }
        return z;
    }

    /* renamed from: c */
    private Drawable m1371c(Context context, int i) {
        if (this.f1231h == null) {
            this.f1231h = new TypedValue();
        }
        TypedValue typedValue = this.f1231h;
        context.getResources().getValue(i, typedValue, true);
        long j = (((long) typedValue.assetCookie) << 32) | ((long) typedValue.data);
        Drawable e = m1373e(context, j);
        if (e != null) {
            return e;
        }
        C0301e eVar = this.f1233j;
        LayerDrawable layerDrawable = null;
        if (eVar != null) {
            C0257e.C0258a aVar = (C0257e.C0258a) eVar;
            if (i == R.drawable.abc_cab_background_top_material) {
                layerDrawable = new LayerDrawable(new Drawable[]{mo1733f(context, R.drawable.abc_cab_background_internal_bg), mo1733f(context, R.drawable.abc_cab_background_top_mtrl_alpha)});
            }
        }
        if (layerDrawable != null) {
            layerDrawable.setChangingConfigurations(typedValue.changingConfigurations);
            m1370b(context, j, layerDrawable);
        }
        return layerDrawable;
    }

    /* renamed from: d */
    public static synchronized C0296v m1372d() {
        C0296v vVar;
        synchronized (C0296v.class) {
            if (f1225b == null) {
                C0296v vVar2 = new C0296v();
                f1225b = vVar2;
                if (Build.VERSION.SDK_INT < 24) {
                    vVar2.m1369a("vector", new C0302f());
                    vVar2.m1369a("animated-vector", new C0298b());
                    vVar2.m1369a("animated-selector", new C0297a());
                }
            }
            vVar = f1225b;
        }
        return vVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x002c, code lost:
        return null;
     */
    /* renamed from: e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private synchronized android.graphics.drawable.Drawable m1373e(android.content.Context r4, long r5) {
        /*
            r3 = this;
            monitor-enter(r3)
            java.util.WeakHashMap<android.content.Context, d.d.g<java.lang.ref.WeakReference<android.graphics.drawable.Drawable$ConstantState>>> r0 = r3.f1230g     // Catch:{ all -> 0x002d }
            java.lang.Object r0 = r0.get(r4)     // Catch:{ all -> 0x002d }
            d.d.g r0 = (p098d.p112d.C4623g) r0     // Catch:{ all -> 0x002d }
            r1 = 0
            if (r0 != 0) goto L_0x000e
            monitor-exit(r3)
            return r1
        L_0x000e:
            java.lang.Object r2 = r0.mo21363g(r5, r1)     // Catch:{ all -> 0x002d }
            java.lang.ref.WeakReference r2 = (java.lang.ref.WeakReference) r2     // Catch:{ all -> 0x002d }
            if (r2 == 0) goto L_0x002b
            java.lang.Object r2 = r2.get()     // Catch:{ all -> 0x002d }
            android.graphics.drawable.Drawable$ConstantState r2 = (android.graphics.drawable.Drawable.ConstantState) r2     // Catch:{ all -> 0x002d }
            if (r2 == 0) goto L_0x0028
            android.content.res.Resources r4 = r4.getResources()     // Catch:{ all -> 0x002d }
            android.graphics.drawable.Drawable r4 = r2.newDrawable(r4)     // Catch:{ all -> 0x002d }
            monitor-exit(r3)
            return r4
        L_0x0028:
            r0.mo21367k(r5)     // Catch:{ all -> 0x002d }
        L_0x002b:
            monitor-exit(r3)
            return r1
        L_0x002d:
            r4 = move-exception
            monitor-exit(r3)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0296v.m1373e(android.content.Context, long):android.graphics.drawable.Drawable");
    }

    /* renamed from: h */
    public static synchronized PorterDuffColorFilter m1374h(int i, PorterDuff.Mode mode) {
        PorterDuffColorFilter porterDuffColorFilter;
        synchronized (C0296v.class) {
            C0299c cVar = f1226c;
            Objects.requireNonNull(cVar);
            int i2 = (i + 31) * 31;
            porterDuffColorFilter = (PorterDuffColorFilter) cVar.get(Integer.valueOf(mode.hashCode() + i2));
            if (porterDuffColorFilter == null) {
                porterDuffColorFilter = new PorterDuffColorFilter(i, mode);
                Objects.requireNonNull(cVar);
                PorterDuffColorFilter porterDuffColorFilter2 = (PorterDuffColorFilter) cVar.put(Integer.valueOf(mode.hashCode() + i2), porterDuffColorFilter);
            }
        }
        return porterDuffColorFilter;
    }

    /* JADX WARNING: Removed duplicated region for block: B:30:0x0079 A[Catch:{ Exception -> 0x00a7 }] */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x009f A[Catch:{ Exception -> 0x00a7 }] */
    /* renamed from: j */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private android.graphics.drawable.Drawable m1375j(android.content.Context r11, int r12) {
        /*
            r10 = this;
            d.d.j<java.lang.String, androidx.appcompat.widget.v$d> r0 = r10.f1228e
            r1 = 0
            if (r0 == 0) goto L_0x00b7
            boolean r0 = r0.isEmpty()
            if (r0 != 0) goto L_0x00b7
            d.d.k<java.lang.String> r0 = r10.f1229f
            java.lang.String r2 = "appcompat_skip_skip"
            if (r0 == 0) goto L_0x0028
            java.lang.Object r0 = r0.mo21472e(r12, r1)
            java.lang.String r0 = (java.lang.String) r0
            boolean r3 = r2.equals(r0)
            if (r3 != 0) goto L_0x0027
            if (r0 == 0) goto L_0x002f
            d.d.j<java.lang.String, androidx.appcompat.widget.v$d> r3 = r10.f1228e
            java.lang.Object r0 = r3.getOrDefault(r0, r1)
            if (r0 != 0) goto L_0x002f
        L_0x0027:
            return r1
        L_0x0028:
            d.d.k r0 = new d.d.k
            r0.<init>()
            r10.f1229f = r0
        L_0x002f:
            android.util.TypedValue r0 = r10.f1231h
            if (r0 != 0) goto L_0x003a
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            r10.f1231h = r0
        L_0x003a:
            android.util.TypedValue r0 = r10.f1231h
            android.content.res.Resources r1 = r11.getResources()
            r3 = 1
            r1.getValue(r12, r0, r3)
            int r4 = r0.assetCookie
            long r4 = (long) r4
            r6 = 32
            long r4 = r4 << r6
            int r6 = r0.data
            long r6 = (long) r6
            long r4 = r4 | r6
            android.graphics.drawable.Drawable r6 = r10.m1373e(r11, r4)
            if (r6 == 0) goto L_0x0055
            return r6
        L_0x0055:
            java.lang.CharSequence r7 = r0.string
            if (r7 == 0) goto L_0x00af
            java.lang.String r7 = r7.toString()
            java.lang.String r8 = ".xml"
            boolean r7 = r7.endsWith(r8)
            if (r7 == 0) goto L_0x00af
            android.content.res.XmlResourceParser r1 = r1.getXml(r12)     // Catch:{ Exception -> 0x00a7 }
            android.util.AttributeSet r7 = android.util.Xml.asAttributeSet(r1)     // Catch:{ Exception -> 0x00a7 }
        L_0x006d:
            int r8 = r1.next()     // Catch:{ Exception -> 0x00a7 }
            r9 = 2
            if (r8 == r9) goto L_0x0077
            if (r8 == r3) goto L_0x0077
            goto L_0x006d
        L_0x0077:
            if (r8 != r9) goto L_0x009f
            java.lang.String r3 = r1.getName()     // Catch:{ Exception -> 0x00a7 }
            d.d.k<java.lang.String> r8 = r10.f1229f     // Catch:{ Exception -> 0x00a7 }
            r8.mo21467a(r12, r3)     // Catch:{ Exception -> 0x00a7 }
            d.d.j<java.lang.String, androidx.appcompat.widget.v$d> r8 = r10.f1228e     // Catch:{ Exception -> 0x00a7 }
            java.lang.Object r3 = r8.get(r3)     // Catch:{ Exception -> 0x00a7 }
            androidx.appcompat.widget.v$d r3 = (androidx.appcompat.widget.C0296v.C0300d) r3     // Catch:{ Exception -> 0x00a7 }
            if (r3 == 0) goto L_0x0094
            android.content.res.Resources$Theme r8 = r11.getTheme()     // Catch:{ Exception -> 0x00a7 }
            android.graphics.drawable.Drawable r6 = r3.mo1738a(r11, r1, r7, r8)     // Catch:{ Exception -> 0x00a7 }
        L_0x0094:
            if (r6 == 0) goto L_0x00af
            int r0 = r0.changingConfigurations     // Catch:{ Exception -> 0x00a7 }
            r6.setChangingConfigurations(r0)     // Catch:{ Exception -> 0x00a7 }
            r10.m1370b(r11, r4, r6)     // Catch:{ Exception -> 0x00a7 }
            goto L_0x00af
        L_0x009f:
            org.xmlpull.v1.XmlPullParserException r11 = new org.xmlpull.v1.XmlPullParserException     // Catch:{ Exception -> 0x00a7 }
            java.lang.String r0 = "No start tag found"
            r11.<init>(r0)     // Catch:{ Exception -> 0x00a7 }
            throw r11     // Catch:{ Exception -> 0x00a7 }
        L_0x00a7:
            r11 = move-exception
            java.lang.String r0 = "ResourceManagerInternal"
            java.lang.String r1 = "Exception while inflating drawable"
            android.util.Log.e(r0, r1, r11)
        L_0x00af:
            if (r6 != 0) goto L_0x00b6
            d.d.k<java.lang.String> r11 = r10.f1229f
            r11.mo21467a(r12, r2)
        L_0x00b6:
            return r6
        L_0x00b7:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0296v.m1375j(android.content.Context, int):android.graphics.drawable.Drawable");
    }

    /* renamed from: m */
    private Drawable m1376m(Context context, int i, boolean z, Drawable drawable) {
        ColorStateList i2 = mo1735i(context, i);
        PorterDuff.Mode mode = null;
        if (i2 != null) {
            if (C0284o.m1344a(drawable)) {
                drawable = drawable.mutate();
            }
            Drawable h = C0487a.m2226h(drawable);
            h.setTintList(i2);
            C0301e eVar = this.f1233j;
            if (eVar != null) {
                C0257e.C0258a aVar = (C0257e.C0258a) eVar;
                if (i == R.drawable.abc_switch_thumb_material) {
                    mode = PorterDuff.Mode.MULTIPLY;
                }
            }
            if (mode == null) {
                return h;
            }
            h.setTintMode(mode);
            return h;
        }
        C0301e eVar2 = this.f1233j;
        if (eVar2 != null && ((C0257e.C0258a) eVar2).mo1588e(context, i, drawable)) {
            return drawable;
        }
        C0301e eVar3 = this.f1233j;
        if ((eVar3 != null && ((C0257e.C0258a) eVar3).mo1589f(context, i, drawable)) || !z) {
            return drawable;
        }
        return null;
    }

    /* renamed from: n */
    static void m1377n(Drawable drawable, C0254c0 c0Var, int[] iArr) {
        if (!C0284o.m1344a(drawable) || drawable.mutate() == drawable) {
            boolean z = c0Var.f1076d;
            if (z || c0Var.f1075c) {
                PorterDuffColorFilter porterDuffColorFilter = null;
                ColorStateList colorStateList = z ? c0Var.f1073a : null;
                PorterDuff.Mode mode = c0Var.f1075c ? c0Var.f1074b : f1224a;
                if (!(colorStateList == null || mode == null)) {
                    porterDuffColorFilter = m1374h(colorStateList.getColorForState(iArr, 0), mode);
                }
                drawable.setColorFilter(porterDuffColorFilter);
            } else {
                drawable.clearColorFilter();
            }
            if (Build.VERSION.SDK_INT <= 23) {
                drawable.invalidateSelf();
                return;
            }
            return;
        }
        Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
    }

    /* renamed from: f */
    public synchronized Drawable mo1733f(Context context, int i) {
        return mo1734g(context, i, false);
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0029, code lost:
        if (r0 != false) goto L_0x002b;
     */
    /* renamed from: g */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized android.graphics.drawable.Drawable mo1734g(android.content.Context r5, int r6, boolean r7) {
        /*
            r4 = this;
            monitor-enter(r4)
            boolean r0 = r4.f1232i     // Catch:{ all -> 0x004a }
            if (r0 == 0) goto L_0x0006
            goto L_0x002b
        L_0x0006:
            r0 = 1
            r4.f1232i = r0     // Catch:{ all -> 0x004a }
            r1 = 2131230883(0x7f0800a3, float:1.8077831E38)
            android.graphics.drawable.Drawable r1 = r4.mo1733f(r5, r1)     // Catch:{ all -> 0x004a }
            r2 = 0
            if (r1 == 0) goto L_0x004c
            boolean r3 = r1 instanceof p098d.p161u.p162a.p163a.C4913g     // Catch:{ all -> 0x004a }
            if (r3 != 0) goto L_0x0029
            java.lang.String r3 = "android.graphics.drawable.VectorDrawable"
            java.lang.Class r1 = r1.getClass()     // Catch:{ all -> 0x004a }
            java.lang.String r1 = r1.getName()     // Catch:{ all -> 0x004a }
            boolean r1 = r3.equals(r1)     // Catch:{ all -> 0x004a }
            if (r1 == 0) goto L_0x0028
            goto L_0x0029
        L_0x0028:
            r0 = 0
        L_0x0029:
            if (r0 == 0) goto L_0x004c
        L_0x002b:
            android.graphics.drawable.Drawable r0 = r4.m1375j(r5, r6)     // Catch:{ all -> 0x004a }
            if (r0 != 0) goto L_0x0035
            android.graphics.drawable.Drawable r0 = r4.m1371c(r5, r6)     // Catch:{ all -> 0x004a }
        L_0x0035:
            if (r0 != 0) goto L_0x003d
            int r0 = androidx.core.content.C0474a.f2214b     // Catch:{ all -> 0x004a }
            android.graphics.drawable.Drawable r0 = r5.getDrawable(r6)     // Catch:{ all -> 0x004a }
        L_0x003d:
            if (r0 == 0) goto L_0x0043
            android.graphics.drawable.Drawable r0 = r4.m1376m(r5, r6, r7, r0)     // Catch:{ all -> 0x004a }
        L_0x0043:
            if (r0 == 0) goto L_0x0048
            androidx.appcompat.widget.C0284o.m1345b(r0)     // Catch:{ all -> 0x004a }
        L_0x0048:
            monitor-exit(r4)
            return r0
        L_0x004a:
            r5 = move-exception
            goto L_0x0056
        L_0x004c:
            r4.f1232i = r2     // Catch:{ all -> 0x004a }
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException     // Catch:{ all -> 0x004a }
            java.lang.String r6 = "This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat."
            r5.<init>(r6)     // Catch:{ all -> 0x004a }
            throw r5     // Catch:{ all -> 0x004a }
        L_0x0056:
            monitor-exit(r4)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0296v.mo1734g(android.content.Context, int, boolean):android.graphics.drawable.Drawable");
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0006, code lost:
        r0 = r0.get(r4);
     */
    /* renamed from: i */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized android.content.res.ColorStateList mo1735i(android.content.Context r4, int r5) {
        /*
            r3 = this;
            monitor-enter(r3)
            java.util.WeakHashMap<android.content.Context, d.d.k<android.content.res.ColorStateList>> r0 = r3.f1227d     // Catch:{ all -> 0x0049 }
            r1 = 0
            if (r0 == 0) goto L_0x0015
            java.lang.Object r0 = r0.get(r4)     // Catch:{ all -> 0x0049 }
            d.d.k r0 = (p098d.p112d.C4632k) r0     // Catch:{ all -> 0x0049 }
            if (r0 == 0) goto L_0x0015
            java.lang.Object r0 = r0.mo21472e(r5, r1)     // Catch:{ all -> 0x0049 }
            android.content.res.ColorStateList r0 = (android.content.res.ColorStateList) r0     // Catch:{ all -> 0x0049 }
            goto L_0x0016
        L_0x0015:
            r0 = r1
        L_0x0016:
            if (r0 != 0) goto L_0x004b
            androidx.appcompat.widget.v$e r0 = r3.f1233j     // Catch:{ all -> 0x0049 }
            if (r0 != 0) goto L_0x001d
            goto L_0x0023
        L_0x001d:
            androidx.appcompat.widget.e$a r0 = (androidx.appcompat.widget.C0257e.C0258a) r0     // Catch:{ all -> 0x0049 }
            android.content.res.ColorStateList r1 = r0.mo1587c(r4, r5)     // Catch:{ all -> 0x0049 }
        L_0x0023:
            if (r1 == 0) goto L_0x0047
            java.util.WeakHashMap<android.content.Context, d.d.k<android.content.res.ColorStateList>> r0 = r3.f1227d     // Catch:{ all -> 0x0049 }
            if (r0 != 0) goto L_0x0030
            java.util.WeakHashMap r0 = new java.util.WeakHashMap     // Catch:{ all -> 0x0049 }
            r0.<init>()     // Catch:{ all -> 0x0049 }
            r3.f1227d = r0     // Catch:{ all -> 0x0049 }
        L_0x0030:
            java.util.WeakHashMap<android.content.Context, d.d.k<android.content.res.ColorStateList>> r0 = r3.f1227d     // Catch:{ all -> 0x0049 }
            java.lang.Object r0 = r0.get(r4)     // Catch:{ all -> 0x0049 }
            d.d.k r0 = (p098d.p112d.C4632k) r0     // Catch:{ all -> 0x0049 }
            if (r0 != 0) goto L_0x0044
            d.d.k r0 = new d.d.k     // Catch:{ all -> 0x0049 }
            r0.<init>()     // Catch:{ all -> 0x0049 }
            java.util.WeakHashMap<android.content.Context, d.d.k<android.content.res.ColorStateList>> r2 = r3.f1227d     // Catch:{ all -> 0x0049 }
            r2.put(r4, r0)     // Catch:{ all -> 0x0049 }
        L_0x0044:
            r0.mo21467a(r5, r1)     // Catch:{ all -> 0x0049 }
        L_0x0047:
            r0 = r1
            goto L_0x004b
        L_0x0049:
            r4 = move-exception
            goto L_0x004d
        L_0x004b:
            monitor-exit(r3)
            return r0
        L_0x004d:
            monitor-exit(r3)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0296v.mo1735i(android.content.Context, int):android.content.res.ColorStateList");
    }

    /* renamed from: k */
    public synchronized void mo1736k(Context context) {
        C4623g gVar = this.f1230g.get(context);
        if (gVar != null) {
            gVar.mo21358b();
        }
    }

    /* renamed from: l */
    public synchronized void mo1737l(C0301e eVar) {
        this.f1233j = eVar;
    }
}
