package androidx.appcompat.widget;

import android.content.res.Resources;

/* renamed from: androidx.appcompat.widget.w */
class C0303w extends Resources {
}
