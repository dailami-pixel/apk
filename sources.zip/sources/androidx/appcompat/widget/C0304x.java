package androidx.appcompat.widget;

import androidx.recyclerview.widget.RecyclerView;

/* renamed from: androidx.appcompat.widget.x */
class C0304x {

    /* renamed from: a */
    private int f1234a = 0;

    /* renamed from: b */
    private int f1235b = 0;

    /* renamed from: c */
    private int f1236c = RecyclerView.UNDEFINED_DURATION;

    /* renamed from: d */
    private int f1237d = RecyclerView.UNDEFINED_DURATION;

    /* renamed from: e */
    private int f1238e = 0;

    /* renamed from: f */
    private int f1239f = 0;

    /* renamed from: g */
    private boolean f1240g = false;

    /* renamed from: h */
    private boolean f1241h = false;

    C0304x() {
    }

    /* renamed from: a */
    public int mo1739a() {
        return this.f1240g ? this.f1234a : this.f1235b;
    }

    /* renamed from: b */
    public int mo1740b() {
        return this.f1240g ? this.f1235b : this.f1234a;
    }

    /* renamed from: c */
    public void mo1741c(int i, int i2) {
        this.f1241h = false;
        if (i != Integer.MIN_VALUE) {
            this.f1238e = i;
            this.f1234a = i;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f1239f = i2;
            this.f1235b = i2;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x001a, code lost:
        if (r2 != Integer.MIN_VALUE) goto L_0x0031;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0028, code lost:
        if (r2 != Integer.MIN_VALUE) goto L_0x0031;
     */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1742d(boolean r2) {
        /*
            r1 = this;
            boolean r0 = r1.f1240g
            if (r2 != r0) goto L_0x0005
            return
        L_0x0005:
            r1.f1240g = r2
            boolean r0 = r1.f1241h
            if (r0 == 0) goto L_0x002b
            r0 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r2 == 0) goto L_0x001d
            int r2 = r1.f1237d
            if (r2 == r0) goto L_0x0014
            goto L_0x0016
        L_0x0014:
            int r2 = r1.f1238e
        L_0x0016:
            r1.f1234a = r2
            int r2 = r1.f1236c
            if (r2 == r0) goto L_0x002f
            goto L_0x0031
        L_0x001d:
            int r2 = r1.f1236c
            if (r2 == r0) goto L_0x0022
            goto L_0x0024
        L_0x0022:
            int r2 = r1.f1238e
        L_0x0024:
            r1.f1234a = r2
            int r2 = r1.f1237d
            if (r2 == r0) goto L_0x002f
            goto L_0x0031
        L_0x002b:
            int r2 = r1.f1238e
            r1.f1234a = r2
        L_0x002f:
            int r2 = r1.f1239f
        L_0x0031:
            r1.f1235b = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0304x.mo1742d(boolean):void");
    }

    /* renamed from: e */
    public void mo1743e(int i, int i2) {
        this.f1236c = i;
        this.f1237d = i2;
        this.f1241h = true;
        if (this.f1240g) {
            if (i2 != Integer.MIN_VALUE) {
                this.f1234a = i2;
            }
            if (i != Integer.MIN_VALUE) {
                this.f1235b = i;
                return;
            }
            return;
        }
        if (i != Integer.MIN_VALUE) {
            this.f1234a = i;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f1235b = i2;
        }
    }
}
