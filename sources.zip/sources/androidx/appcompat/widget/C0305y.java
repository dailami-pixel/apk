package androidx.appcompat.widget;

import android.widget.AdapterView;
import android.widget.HorizontalScrollView;

/* renamed from: androidx.appcompat.widget.y */
public class C0305y extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
}
