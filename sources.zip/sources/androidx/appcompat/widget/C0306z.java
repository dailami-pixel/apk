package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import p098d.p099a.C4568b;
import p098d.p120g.p121c.C4693b;

/* renamed from: androidx.appcompat.widget.z */
public class C0306z {

    /* renamed from: a */
    private static final ThreadLocal<TypedValue> f1242a = new ThreadLocal<>();

    /* renamed from: b */
    static final int[] f1243b = {-16842910};

    /* renamed from: c */
    static final int[] f1244c = {16842908};

    /* renamed from: d */
    static final int[] f1245d = {16842919};

    /* renamed from: e */
    static final int[] f1246e = {16842912};

    /* renamed from: f */
    static final int[] f1247f = new int[0];

    /* renamed from: g */
    private static final int[] f1248g = new int[1];

    /* renamed from: a */
    public static void m1392a(View view, Context context) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(C4568b.f16463k);
        try {
            if (!obtainStyledAttributes.hasValue(115)) {
                Log.e("ThemeUtils", "View " + view.getClass() + " is an AppCompat widget that can only be used with a Theme.AppCompat theme (or descendant).");
            }
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    /* renamed from: b */
    public static int m1393b(Context context, int i) {
        ColorStateList d = m1395d(context, i);
        if (d != null && d.isStateful()) {
            return d.getColorForState(f1243b, d.getDefaultColor());
        }
        ThreadLocal<TypedValue> threadLocal = f1242a;
        TypedValue typedValue = threadLocal.get();
        if (typedValue == null) {
            typedValue = new TypedValue();
            threadLocal.set(typedValue);
        }
        context.getTheme().resolveAttribute(16842803, typedValue, true);
        float f = typedValue.getFloat();
        int c = m1394c(context, i);
        return C4693b.m17139h(c, Math.round(((float) Color.alpha(c)) * f));
    }

    /* renamed from: c */
    public static int m1394c(Context context, int i) {
        int[] iArr = f1248g;
        iArr[0] = i;
        C0259e0 u = C0259e0.m1180u(context, (AttributeSet) null, iArr);
        try {
            return u.mo1591b(0, 0);
        } finally {
            u.mo1609w();
        }
    }

    /* renamed from: d */
    public static ColorStateList m1395d(Context context, int i) {
        int[] iArr = f1248g;
        iArr[0] = i;
        C0259e0 u = C0259e0.m1180u(context, (AttributeSet) null, iArr);
        try {
            return u.mo1592c(0);
        } finally {
            u.mo1609w();
        }
    }
}
