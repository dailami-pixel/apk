package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import p098d.p099a.C4568b;
import p098d.p120g.p130j.C4761m;

public class LinearLayoutCompat extends ViewGroup {

    /* renamed from: a */
    private boolean f849a;

    /* renamed from: b */
    private int f850b;

    /* renamed from: c */
    private int f851c;

    /* renamed from: d */
    private int f852d;

    /* renamed from: e */
    private int f853e;

    /* renamed from: f */
    private int f854f;

    /* renamed from: g */
    private float f855g;

    /* renamed from: h */
    private boolean f856h;

    /* renamed from: i */
    private int[] f857i;

    /* renamed from: j */
    private int[] f858j;

    /* renamed from: k */
    private Drawable f859k;

    /* renamed from: l */
    private int f860l;

    /* renamed from: m */
    private int f861m;

    /* renamed from: n */
    private int f862n;

    /* renamed from: o */
    private int f863o;

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {

        /* renamed from: a */
        public float f864a;

        /* renamed from: b */
        public int f865b;

        public LayoutParams(int i, int i2) {
            super(i, i2);
            this.f865b = -1;
            this.f864a = 0.0f;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f865b = -1;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4568b.f16467o);
            this.f864a = obtainStyledAttributes.getFloat(3, 0.0f);
            this.f865b = obtainStyledAttributes.getInt(0, -1);
            obtainStyledAttributes.recycle();
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f865b = -1;
        }
    }

    public LinearLayoutCompat(Context context) {
        this(context, (AttributeSet) null);
    }

    public LinearLayoutCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public LinearLayoutCompat(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        boolean z = true;
        this.f849a = true;
        this.f850b = -1;
        this.f851c = 0;
        this.f853e = 8388659;
        int[] iArr = C4568b.f16466n;
        C0259e0 v = C0259e0.m1181v(context, attributeSet, iArr, i, 0);
        C4761m.m17309r(this, context, iArr, attributeSet, v.mo1607r(), i, 0);
        int k = v.mo1600k(1, -1);
        if (k >= 0 && this.f852d != k) {
            this.f852d = k;
            requestLayout();
        }
        int k2 = v.mo1600k(0, -1);
        if (k2 >= 0 && this.f853e != k2) {
            k2 = (8388615 & k2) == 0 ? k2 | 8388611 : k2;
            this.f853e = (k2 & 112) == 0 ? k2 | 48 : k2;
            requestLayout();
        }
        boolean a = v.mo1590a(2, true);
        if (!a) {
            this.f849a = a;
        }
        this.f855g = v.mo1598i(4, -1.0f);
        this.f850b = v.mo1600k(3, -1);
        this.f856h = v.mo1590a(7, false);
        Drawable g = v.mo1596g(5);
        if (g != this.f859k) {
            this.f859k = g;
            if (g != null) {
                this.f860l = g.getIntrinsicWidth();
                this.f861m = g.getIntrinsicHeight();
            } else {
                this.f860l = 0;
                this.f861m = 0;
            }
            setWillNotDraw(g != null ? false : z);
            requestLayout();
        }
        this.f862n = v.mo1600k(8, 0);
        this.f863o = v.mo1595f(6, 0);
        v.mo1609w();
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public int getBaseline() {
        int i;
        if (this.f850b < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i2 = this.f850b;
        if (childCount > i2) {
            View childAt = getChildAt(i2);
            int baseline = childAt.getBaseline();
            if (baseline != -1) {
                int i3 = this.f851c;
                if (this.f852d == 1 && (i = this.f853e & 112) != 48) {
                    if (i == 16) {
                        i3 += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.f854f) / 2;
                    } else if (i == 80) {
                        i3 = ((getBottom() - getTop()) - getPaddingBottom()) - this.f854f;
                    }
                }
                return i3 + ((LayoutParams) childAt.getLayoutParams()).topMargin + baseline;
            } else if (this.f850b == 0) {
                return -1;
            } else {
                throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
            }
        } else {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public void mo1372h(Canvas canvas, int i) {
        this.f859k.setBounds(getPaddingLeft() + this.f863o, i, (getWidth() - getPaddingRight()) - this.f863o, this.f861m + i);
        this.f859k.draw(canvas);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public void mo1373i(Canvas canvas, int i) {
        this.f859k.setBounds(i, getPaddingTop() + this.f863o, this.f860l + i, (getHeight() - getPaddingBottom()) - this.f863o);
        this.f859k.draw(canvas);
    }

    /* access modifiers changed from: protected */
    /* renamed from: j */
    public LayoutParams generateDefaultLayoutParams() {
        int i = this.f852d;
        if (i == 0) {
            return new LayoutParams(-2, -2);
        }
        if (i == 1) {
            return new LayoutParams(-1, -2);
        }
        return null;
    }

    /* renamed from: k */
    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    /* access modifiers changed from: protected */
    /* renamed from: l */
    public LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: m */
    public int mo1374m() {
        return 0;
    }

    /* renamed from: n */
    public Drawable mo1375n() {
        return this.f859k;
    }

    /* renamed from: o */
    public int mo1376o() {
        return this.f860l;
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        int i;
        int i2;
        int i3;
        if (this.f859k != null) {
            int i4 = 0;
            if (this.f852d == 1) {
                int childCount = getChildCount();
                while (i4 < childCount) {
                    View childAt = getChildAt(i4);
                    if (!(childAt == null || childAt.getVisibility() == 8 || !mo1383s(i4))) {
                        mo1372h(canvas, (childAt.getTop() - ((LayoutParams) childAt.getLayoutParams()).topMargin) - this.f861m);
                    }
                    i4++;
                }
                if (mo1383s(childCount)) {
                    View childAt2 = getChildAt(childCount - 1);
                    mo1372h(canvas, childAt2 == null ? (getHeight() - getPaddingBottom()) - this.f861m : childAt2.getBottom() + ((LayoutParams) childAt2.getLayoutParams()).bottomMargin);
                    return;
                }
                return;
            }
            int childCount2 = getChildCount();
            boolean b = C0280l0.m1310b(this);
            while (i4 < childCount2) {
                View childAt3 = getChildAt(i4);
                if (!(childAt3 == null || childAt3.getVisibility() == 8 || !mo1383s(i4))) {
                    LayoutParams layoutParams = (LayoutParams) childAt3.getLayoutParams();
                    mo1373i(canvas, b ? childAt3.getRight() + layoutParams.rightMargin : (childAt3.getLeft() - layoutParams.leftMargin) - this.f860l);
                }
                i4++;
            }
            if (mo1383s(childCount2)) {
                View childAt4 = getChildAt(childCount2 - 1);
                if (childAt4 != null) {
                    LayoutParams layoutParams2 = (LayoutParams) childAt4.getLayoutParams();
                    if (b) {
                        i3 = childAt4.getLeft();
                        i2 = layoutParams2.leftMargin;
                    } else {
                        i = childAt4.getRight() + layoutParams2.rightMargin;
                        mo1373i(canvas, i);
                    }
                } else if (b) {
                    i = getPaddingLeft();
                    mo1373i(canvas, i);
                } else {
                    i3 = getWidth();
                    i2 = getPaddingRight();
                }
                i = (i3 - i2) - this.f860l;
                mo1373i(canvas, i);
            }
        }
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x009d  */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x016a  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x0174  */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x01a4  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x01b6  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r24, int r25, int r26, int r27, int r28) {
        /*
            r23 = this;
            r0 = r23
            int r1 = r0.f852d
            r2 = 80
            r3 = 16
            r4 = 8
            r5 = 5
            r6 = 8388615(0x800007, float:1.1754953E-38)
            r8 = 2
            r9 = 1
            if (r1 != r9) goto L_0x00c3
            int r1 = r23.getPaddingLeft()
            int r10 = r27 - r25
            int r11 = r23.getPaddingRight()
            int r11 = r10 - r11
            int r10 = r10 - r1
            int r12 = r23.getPaddingRight()
            int r10 = r10 - r12
            int r12 = r23.getChildCount()
            int r13 = r0.f853e
            r14 = r13 & 112(0x70, float:1.57E-43)
            r6 = r6 & r13
            if (r14 == r3) goto L_0x0042
            if (r14 == r2) goto L_0x0036
            int r2 = r23.getPaddingTop()
            goto L_0x004d
        L_0x0036:
            int r2 = r23.getPaddingTop()
            int r2 = r2 + r28
            int r2 = r2 - r26
            int r3 = r0.f854f
            int r2 = r2 - r3
            goto L_0x004d
        L_0x0042:
            int r2 = r23.getPaddingTop()
            int r3 = r28 - r26
            int r13 = r0.f854f
            int r3 = r3 - r13
            int r3 = r3 / r8
            int r2 = r2 + r3
        L_0x004d:
            r7 = 0
        L_0x004e:
            if (r7 >= r12) goto L_0x01e6
            android.view.View r3 = r0.getChildAt(r7)
            if (r3 != 0) goto L_0x005c
            int r3 = r23.mo1386u()
            int r2 = r2 + r3
            goto L_0x00bd
        L_0x005c:
            int r13 = r3.getVisibility()
            if (r13 == r4) goto L_0x00bd
            int r13 = r3.getMeasuredWidth()
            int r14 = r3.getMeasuredHeight()
            android.view.ViewGroup$LayoutParams r15 = r3.getLayoutParams()
            androidx.appcompat.widget.LinearLayoutCompat$LayoutParams r15 = (androidx.appcompat.widget.LinearLayoutCompat.LayoutParams) r15
            int r4 = r15.f865b
            if (r4 >= 0) goto L_0x0075
            r4 = r6
        L_0x0075:
            int r16 = p098d.p120g.p130j.C4761m.f17241f
            int r8 = r23.getLayoutDirection()
            int r4 = android.view.Gravity.getAbsoluteGravity(r4, r8)
            r4 = r4 & 7
            if (r4 == r9) goto L_0x008c
            if (r4 == r5) goto L_0x0089
            int r4 = r15.leftMargin
            int r4 = r4 + r1
            goto L_0x0097
        L_0x0089:
            int r4 = r11 - r13
            goto L_0x0094
        L_0x008c:
            int r4 = r10 - r13
            r8 = 2
            int r4 = r4 / r8
            int r4 = r4 + r1
            int r8 = r15.leftMargin
            int r4 = r4 + r8
        L_0x0094:
            int r8 = r15.rightMargin
            int r4 = r4 - r8
        L_0x0097:
            boolean r8 = r0.mo1383s(r7)
            if (r8 == 0) goto L_0x00a0
            int r8 = r0.f861m
            int r2 = r2 + r8
        L_0x00a0:
            int r8 = r15.topMargin
            int r2 = r2 + r8
            int r8 = r23.mo1381q()
            int r8 = r8 + r2
            int r13 = r13 + r4
            int r5 = r14 + r8
            r3.layout(r4, r8, r13, r5)
            int r3 = r15.bottomMargin
            int r14 = r14 + r3
            int r3 = r23.mo1382r()
            int r14 = r14 + r3
            int r14 = r14 + r2
            int r2 = r23.mo1374m()
            int r7 = r7 + r2
            r2 = r14
        L_0x00bd:
            int r7 = r7 + r9
            r4 = 8
            r5 = 5
            r8 = 2
            goto L_0x004e
        L_0x00c3:
            boolean r1 = androidx.appcompat.widget.C0280l0.m1310b(r23)
            int r4 = r23.getPaddingTop()
            int r5 = r28 - r26
            int r8 = r23.getPaddingBottom()
            int r8 = r5 - r8
            int r5 = r5 - r4
            int r10 = r23.getPaddingBottom()
            int r5 = r5 - r10
            int r10 = r23.getChildCount()
            int r11 = r0.f853e
            r6 = r6 & r11
            r11 = r11 & 112(0x70, float:1.57E-43)
            boolean r12 = r0.f849a
            int[] r13 = r0.f857i
            int[] r14 = r0.f858j
            int r15 = p098d.p120g.p130j.C4761m.f17241f
            int r15 = r23.getLayoutDirection()
            int r6 = android.view.Gravity.getAbsoluteGravity(r6, r15)
            if (r6 == r9) goto L_0x0108
            r15 = 5
            if (r6 == r15) goto L_0x00fc
            int r6 = r23.getPaddingLeft()
            goto L_0x0114
        L_0x00fc:
            int r6 = r23.getPaddingLeft()
            int r6 = r6 + r27
            int r6 = r6 - r25
            int r15 = r0.f854f
            int r6 = r6 - r15
            goto L_0x0114
        L_0x0108:
            int r6 = r23.getPaddingLeft()
            int r15 = r27 - r25
            int r7 = r0.f854f
            int r15 = r15 - r7
            r7 = 2
            int r15 = r15 / r7
            int r6 = r6 + r15
        L_0x0114:
            if (r1 == 0) goto L_0x011d
            int r1 = r10 + -1
            r16 = r1
            r1 = 0
            r15 = -1
            goto L_0x0121
        L_0x011d:
            r1 = 0
            r15 = 1
            r16 = 0
        L_0x0121:
            if (r1 >= r10) goto L_0x01e6
            int r17 = r15 * r1
            int r9 = r17 + r16
            android.view.View r2 = r0.getChildAt(r9)
            if (r2 != 0) goto L_0x013b
            int r2 = r23.mo1386u()
            int r6 = r6 + r2
        L_0x0132:
            r26 = r10
            r28 = r11
            r20 = r12
        L_0x0138:
            r2 = 1
            goto L_0x01d8
        L_0x013b:
            int r3 = r2.getVisibility()
            r7 = 8
            if (r3 == r7) goto L_0x0132
            int r3 = r2.getMeasuredWidth()
            int r19 = r2.getMeasuredHeight()
            android.view.ViewGroup$LayoutParams r20 = r2.getLayoutParams()
            r7 = r20
            androidx.appcompat.widget.LinearLayoutCompat$LayoutParams r7 = (androidx.appcompat.widget.LinearLayoutCompat.LayoutParams) r7
            r26 = r10
            if (r12 == 0) goto L_0x0163
            int r10 = r7.height
            r28 = r11
            r11 = -1
            if (r10 == r11) goto L_0x0165
            int r11 = r2.getBaseline()
            goto L_0x0166
        L_0x0163:
            r28 = r11
        L_0x0165:
            r11 = -1
        L_0x0166:
            int r10 = r7.f865b
            if (r10 >= 0) goto L_0x016c
            r10 = r28
        L_0x016c:
            r10 = r10 & 112(0x70, float:1.57E-43)
            r20 = r12
            r12 = 16
            if (r10 == r12) goto L_0x01a4
            r12 = 48
            if (r10 == r12) goto L_0x0195
            r12 = 80
            if (r10 == r12) goto L_0x017f
            r10 = r4
            r12 = -1
            goto L_0x01b0
        L_0x017f:
            int r10 = r8 - r19
            int r12 = r7.bottomMargin
            int r10 = r10 - r12
            r12 = -1
            if (r11 == r12) goto L_0x01b0
            int r21 = r2.getMeasuredHeight()
            int r21 = r21 - r11
            r11 = 2
            r22 = r14[r11]
            int r22 = r22 - r21
            int r10 = r10 - r22
            goto L_0x01b0
        L_0x0195:
            r12 = -1
            int r10 = r7.topMargin
            int r10 = r10 + r4
            if (r11 == r12) goto L_0x01b0
            r18 = 1
            r21 = r13[r18]
            int r21 = r21 - r11
            int r10 = r21 + r10
            goto L_0x01b0
        L_0x01a4:
            r12 = -1
            int r10 = r5 - r19
            r11 = 2
            int r10 = r10 / r11
            int r10 = r10 + r4
            int r11 = r7.topMargin
            int r10 = r10 + r11
            int r11 = r7.bottomMargin
            int r10 = r10 - r11
        L_0x01b0:
            boolean r9 = r0.mo1383s(r9)
            if (r9 == 0) goto L_0x01b9
            int r9 = r0.f860l
            int r6 = r6 + r9
        L_0x01b9:
            int r9 = r7.leftMargin
            int r6 = r6 + r9
            int r9 = r23.mo1381q()
            int r9 = r9 + r6
            int r11 = r3 + r9
            int r12 = r19 + r10
            r2.layout(r9, r10, r11, r12)
            int r2 = r7.rightMargin
            int r3 = r3 + r2
            int r2 = r23.mo1382r()
            int r3 = r3 + r2
            int r6 = r6 + r3
            int r2 = r23.mo1374m()
            int r1 = r1 + r2
            goto L_0x0138
        L_0x01d8:
            int r1 = r1 + r2
            r10 = r26
            r11 = r28
            r12 = r20
            r2 = 80
            r3 = 16
            r9 = 1
            goto L_0x0121
        L_0x01e6:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.LinearLayoutCompat.onLayout(boolean, int, int, int, int):void");
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:128:0x02c7, code lost:
        if (r13 < 0) goto L_0x02c9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:322:0x0759, code lost:
        if (r7 < 0) goto L_0x075b;
     */
    /* JADX WARNING: Removed duplicated region for block: B:139:0x0303  */
    /* JADX WARNING: Removed duplicated region for block: B:144:0x030e  */
    /* JADX WARNING: Removed duplicated region for block: B:145:0x0310  */
    /* JADX WARNING: Removed duplicated region for block: B:205:0x04ac  */
    /* JADX WARNING: Removed duplicated region for block: B:206:0x04b1  */
    /* JADX WARNING: Removed duplicated region for block: B:209:0x04d9  */
    /* JADX WARNING: Removed duplicated region for block: B:210:0x04de  */
    /* JADX WARNING: Removed duplicated region for block: B:213:0x04e8  */
    /* JADX WARNING: Removed duplicated region for block: B:214:0x04f7  */
    /* JADX WARNING: Removed duplicated region for block: B:216:0x050c  */
    /* JADX WARNING: Removed duplicated region for block: B:221:0x051b  */
    /* JADX WARNING: Removed duplicated region for block: B:222:0x051f  */
    /* JADX WARNING: Removed duplicated region for block: B:227:0x053b  */
    /* JADX WARNING: Removed duplicated region for block: B:231:0x0562  */
    /* JADX WARNING: Removed duplicated region for block: B:236:0x056f  */
    /* JADX WARNING: Removed duplicated region for block: B:237:0x0571  */
    /* JADX WARNING: Removed duplicated region for block: B:240:0x0579  */
    /* JADX WARNING: Removed duplicated region for block: B:243:0x0584  */
    /* JADX WARNING: Removed duplicated region for block: B:271:0x061f  */
    /* JADX WARNING: Removed duplicated region for block: B:306:0x06e5  */
    /* JADX WARNING: Removed duplicated region for block: B:309:0x0702  */
    /* JADX WARNING: Removed duplicated region for block: B:348:0x07ea  */
    /* JADX WARNING: Removed duplicated region for block: B:352:0x080e  */
    /* JADX WARNING: Removed duplicated region for block: B:362:0x084d  */
    /* JADX WARNING: Removed duplicated region for block: B:365:0x0856  */
    /* JADX WARNING: Removed duplicated region for block: B:373:0x08af  */
    /* JADX WARNING: Removed duplicated region for block: B:421:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r39, int r40) {
        /*
            r38 = this;
            r6 = r38
            r7 = r39
            r8 = r40
            int r0 = r6.f852d
            r10 = -2
            r11 = -2147483648(0xffffffff80000000, float:-0.0)
            r12 = 8
            r13 = 0
            r15 = 1073741824(0x40000000, float:2.0)
            r5 = 1
            r4 = 0
            if (r0 != r5) goto L_0x03a3
            r6.f854f = r4
            int r3 = r38.getChildCount()
            int r2 = android.view.View.MeasureSpec.getMode(r39)
            int r1 = android.view.View.MeasureSpec.getMode(r40)
            int r0 = r6.f850b
            boolean r9 = r6.f856h
            r14 = 0
            r17 = 0
            r18 = 0
            r19 = 0
            r20 = 0
            r21 = 0
            r22 = 0
            r23 = 0
            r24 = 1
            r25 = 0
        L_0x0039:
            if (r14 >= r3) goto L_0x0186
            android.view.View r26 = r6.getChildAt(r14)
            if (r26 != 0) goto L_0x004c
            int r4 = r6.f854f
            int r26 = r38.mo1386u()
            int r4 = r4 + r26
            r6.f854f = r4
            goto L_0x0057
        L_0x004c:
            int r4 = r26.getVisibility()
            if (r4 != r12) goto L_0x0063
            int r4 = r38.mo1374m()
            int r14 = r14 + r4
        L_0x0057:
            r10 = r0
            r29 = r1
            r0 = r2
            r31 = r3
            r4 = r20
            r27 = 1
            goto L_0x0170
        L_0x0063:
            boolean r4 = r6.mo1383s(r14)
            if (r4 == 0) goto L_0x0070
            int r4 = r6.f854f
            int r5 = r6.f861m
            int r4 = r4 + r5
            r6.f854f = r4
        L_0x0070:
            android.view.ViewGroup$LayoutParams r4 = r26.getLayoutParams()
            r5 = r4
            androidx.appcompat.widget.LinearLayoutCompat$LayoutParams r5 = (androidx.appcompat.widget.LinearLayoutCompat.LayoutParams) r5
            float r4 = r5.f864a
            float r21 = r21 + r4
            if (r1 != r15) goto L_0x009f
            int r12 = r5.height
            if (r12 != 0) goto L_0x009f
            int r12 = (r4 > r13 ? 1 : (r4 == r13 ? 0 : -1))
            if (r12 <= 0) goto L_0x009f
            int r4 = r6.f854f
            int r12 = r5.topMargin
            int r12 = r12 + r4
            int r15 = r5.bottomMargin
            int r12 = r12 + r15
            int r4 = java.lang.Math.max(r4, r12)
            r6.f854f = r4
            r10 = r0
            r29 = r1
            r30 = r2
            r31 = r3
            r13 = r5
            r5 = 1
            r27 = 1
            goto L_0x00f5
        L_0x009f:
            int r12 = r5.height
            if (r12 != 0) goto L_0x00ab
            int r4 = (r4 > r13 ? 1 : (r4 == r13 ? 0 : -1))
            if (r4 <= 0) goto L_0x00ab
            r5.height = r10
            r12 = 0
            goto L_0x00ad
        L_0x00ab:
            r12 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x00ad:
            r4 = 0
            int r15 = (r21 > r13 ? 1 : (r21 == r13 ? 0 : -1))
            if (r15 != 0) goto L_0x00b6
            int r15 = r6.f854f
            r10 = r0
            goto L_0x00b8
        L_0x00b6:
            r10 = r0
            r15 = 0
        L_0x00b8:
            r0 = r38
            r29 = r1
            r1 = r26
            r30 = r2
            r2 = r39
            r31 = r3
            r3 = r4
            r4 = r40
            r13 = r5
            r27 = 1
            r5 = r15
            r0.mo1385t(r1, r2, r3, r4, r5)
            if (r12 == r11) goto L_0x00d2
            r13.height = r12
        L_0x00d2:
            int r0 = r26.getMeasuredHeight()
            int r1 = r6.f854f
            int r2 = r1 + r0
            int r3 = r13.topMargin
            int r2 = r2 + r3
            int r3 = r13.bottomMargin
            int r2 = r2 + r3
            int r3 = r38.mo1382r()
            int r2 = r2 + r3
            int r1 = java.lang.Math.max(r1, r2)
            r6.f854f = r1
            r4 = r18
            if (r9 == 0) goto L_0x00f3
            int r18 = java.lang.Math.max(r0, r4)
        L_0x00f3:
            r5 = r22
        L_0x00f5:
            if (r10 < 0) goto L_0x00ff
            int r0 = r14 + 1
            if (r10 != r0) goto L_0x00ff
            int r0 = r6.f854f
            r6.f851c = r0
        L_0x00ff:
            if (r14 >= r10) goto L_0x0111
            float r0 = r13.f864a
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 > 0) goto L_0x0109
            goto L_0x0111
        L_0x0109:
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            java.lang.String r1 = "A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex."
            r0.<init>(r1)
            throw r0
        L_0x0111:
            r0 = r30
            r1 = 1073741824(0x40000000, float:2.0)
            if (r0 == r1) goto L_0x0120
            int r1 = r13.width
            r2 = -1
            if (r1 != r2) goto L_0x0120
            r1 = 1
            r25 = 1
            goto L_0x0121
        L_0x0120:
            r1 = 0
        L_0x0121:
            int r2 = r13.leftMargin
            int r3 = r13.rightMargin
            int r2 = r2 + r3
            int r3 = r26.getMeasuredWidth()
            int r3 = r3 + r2
            r12 = r20
            int r4 = java.lang.Math.max(r12, r3)
            int r12 = r26.getMeasuredState()
            r15 = r23
            int r12 = android.view.View.combineMeasuredStates(r15, r12)
            if (r24 == 0) goto L_0x0144
            int r15 = r13.width
            r11 = -1
            if (r15 != r11) goto L_0x0144
            r11 = 1
            goto L_0x0145
        L_0x0144:
            r11 = 0
        L_0x0145:
            float r13 = r13.f864a
            r15 = 0
            int r13 = (r13 > r15 ? 1 : (r13 == r15 ? 0 : -1))
            if (r13 <= 0) goto L_0x0157
            if (r1 == 0) goto L_0x014f
            goto L_0x0150
        L_0x014f:
            r2 = r3
        L_0x0150:
            r13 = r17
            int r17 = java.lang.Math.max(r13, r2)
            goto L_0x0165
        L_0x0157:
            r13 = r17
            if (r1 == 0) goto L_0x015c
            goto L_0x015d
        L_0x015c:
            r2 = r3
        L_0x015d:
            r1 = r19
            int r19 = java.lang.Math.max(r1, r2)
            r17 = r13
        L_0x0165:
            int r1 = r38.mo1374m()
            int r14 = r14 + r1
            r22 = r5
            r24 = r11
            r23 = r12
        L_0x0170:
            int r14 = r14 + 1
            r2 = r0
            r20 = r4
            r0 = r10
            r1 = r29
            r3 = r31
            r4 = 0
            r5 = 1
            r10 = -2
            r11 = -2147483648(0xffffffff80000000, float:-0.0)
            r12 = 8
            r13 = 0
            r15 = 1073741824(0x40000000, float:2.0)
            goto L_0x0039
        L_0x0186:
            r29 = r1
            r0 = r2
            r31 = r3
            r13 = r17
            r4 = r18
            r1 = r19
            r12 = r20
            r15 = r23
            r27 = 1
            int r2 = r6.f854f
            r10 = r31
            if (r2 <= 0) goto L_0x01aa
            boolean r2 = r6.mo1383s(r10)
            if (r2 == 0) goto L_0x01aa
            int r2 = r6.f854f
            int r3 = r6.f861m
            int r2 = r2 + r3
            r6.f854f = r2
        L_0x01aa:
            r2 = r29
            if (r9 == 0) goto L_0x01f9
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r2 == r3) goto L_0x01b4
            if (r2 != 0) goto L_0x01f9
        L_0x01b4:
            r11 = 0
            r6.f854f = r11
            r3 = 0
        L_0x01b8:
            if (r3 >= r10) goto L_0x01f9
            android.view.View r5 = r6.getChildAt(r3)
            if (r5 != 0) goto L_0x01ca
            int r5 = r6.f854f
            int r14 = r38.mo1386u()
            int r5 = r5 + r14
        L_0x01c7:
            r6.f854f = r5
            goto L_0x01f5
        L_0x01ca:
            int r14 = r5.getVisibility()
            r11 = 8
            if (r14 != r11) goto L_0x01d8
            int r5 = r38.mo1374m()
            int r3 = r3 + r5
            goto L_0x01f5
        L_0x01d8:
            android.view.ViewGroup$LayoutParams r5 = r5.getLayoutParams()
            androidx.appcompat.widget.LinearLayoutCompat$LayoutParams r5 = (androidx.appcompat.widget.LinearLayoutCompat.LayoutParams) r5
            int r11 = r6.f854f
            int r18 = r11 + r4
            int r14 = r5.topMargin
            int r18 = r18 + r14
            int r5 = r5.bottomMargin
            int r18 = r18 + r5
            int r5 = r38.mo1382r()
            int r5 = r18 + r5
            int r5 = java.lang.Math.max(r11, r5)
            goto L_0x01c7
        L_0x01f5:
            int r3 = r3 + 1
            r11 = 0
            goto L_0x01b8
        L_0x01f9:
            int r3 = r6.f854f
            int r5 = r38.getPaddingTop()
            int r11 = r38.getPaddingBottom()
            int r11 = r11 + r5
            int r11 = r11 + r3
            r6.f854f = r11
            int r3 = r38.getSuggestedMinimumHeight()
            int r3 = java.lang.Math.max(r11, r3)
            r5 = 0
            int r3 = android.view.View.resolveSizeAndState(r3, r8, r5)
            r5 = 16777215(0xffffff, float:2.3509886E-38)
            r5 = r5 & r3
            int r11 = r6.f854f
            int r5 = r5 - r11
            if (r22 != 0) goto L_0x0266
            if (r5 == 0) goto L_0x0225
            r11 = 0
            int r14 = (r21 > r11 ? 1 : (r21 == r11 ? 0 : -1))
            if (r14 <= 0) goto L_0x0225
            goto L_0x0266
        L_0x0225:
            int r1 = java.lang.Math.max(r1, r13)
            if (r9 == 0) goto L_0x0262
            r5 = 1073741824(0x40000000, float:2.0)
            if (r2 == r5) goto L_0x0262
            r2 = 0
        L_0x0230:
            if (r2 >= r10) goto L_0x0262
            android.view.View r5 = r6.getChildAt(r2)
            if (r5 == 0) goto L_0x025f
            int r9 = r5.getVisibility()
            r11 = 8
            if (r9 != r11) goto L_0x0241
            goto L_0x025f
        L_0x0241:
            android.view.ViewGroup$LayoutParams r9 = r5.getLayoutParams()
            androidx.appcompat.widget.LinearLayoutCompat$LayoutParams r9 = (androidx.appcompat.widget.LinearLayoutCompat.LayoutParams) r9
            float r9 = r9.f864a
            r11 = 0
            int r9 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1))
            if (r9 <= 0) goto L_0x025f
            int r9 = r5.getMeasuredWidth()
            r11 = 1073741824(0x40000000, float:2.0)
            int r9 = android.view.View.MeasureSpec.makeMeasureSpec(r9, r11)
            int r13 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r11)
            r5.measure(r9, r13)
        L_0x025f:
            int r2 = r2 + 1
            goto L_0x0230
        L_0x0262:
            r20 = r12
            goto L_0x0343
        L_0x0266:
            float r4 = r6.f855g
            r9 = 0
            int r11 = (r4 > r9 ? 1 : (r4 == r9 ? 0 : -1))
            if (r11 <= 0) goto L_0x026f
            r21 = r4
        L_0x026f:
            r4 = 0
            r6.f854f = r4
            r4 = 0
        L_0x0273:
            if (r4 >= r10) goto L_0x0333
            android.view.View r9 = r6.getChildAt(r4)
            int r11 = r9.getVisibility()
            r13 = 8
            if (r11 != r13) goto L_0x0285
            r29 = r2
            goto L_0x032d
        L_0x0285:
            android.view.ViewGroup$LayoutParams r11 = r9.getLayoutParams()
            androidx.appcompat.widget.LinearLayoutCompat$LayoutParams r11 = (androidx.appcompat.widget.LinearLayoutCompat.LayoutParams) r11
            float r13 = r11.f864a
            r14 = 0
            int r16 = (r13 > r14 ? 1 : (r13 == r14 ? 0 : -1))
            if (r16 <= 0) goto L_0x02df
            float r14 = (float) r5
            float r14 = r14 * r13
            float r14 = r14 / r21
            int r14 = (int) r14
            float r21 = r21 - r13
            int r5 = r5 - r14
            int r13 = r38.getPaddingLeft()
            int r16 = r38.getPaddingRight()
            int r16 = r16 + r13
            int r13 = r11.leftMargin
            int r16 = r16 + r13
            int r13 = r11.rightMargin
            int r13 = r16 + r13
            r16 = r5
            int r5 = r11.width
            int r5 = android.view.ViewGroup.getChildMeasureSpec(r7, r13, r5)
            int r13 = r11.height
            if (r13 != 0) goto L_0x02c2
            r13 = 1073741824(0x40000000, float:2.0)
            if (r2 == r13) goto L_0x02be
            goto L_0x02c2
        L_0x02be:
            if (r14 <= 0) goto L_0x02c9
            r13 = r14
            goto L_0x02ca
        L_0x02c2:
            int r13 = r9.getMeasuredHeight()
            int r13 = r13 + r14
            if (r13 >= 0) goto L_0x02ca
        L_0x02c9:
            r13 = 0
        L_0x02ca:
            r14 = 1073741824(0x40000000, float:2.0)
            int r13 = android.view.View.MeasureSpec.makeMeasureSpec(r13, r14)
            r9.measure(r5, r13)
            int r5 = r9.getMeasuredState()
            r5 = r5 & -256(0xffffffffffffff00, float:NaN)
            int r15 = android.view.View.combineMeasuredStates(r15, r5)
            r5 = r16
        L_0x02df:
            int r13 = r11.leftMargin
            int r14 = r11.rightMargin
            int r13 = r13 + r14
            int r14 = r9.getMeasuredWidth()
            int r14 = r14 + r13
            int r12 = java.lang.Math.max(r12, r14)
            r29 = r2
            r2 = 1073741824(0x40000000, float:2.0)
            if (r0 == r2) goto L_0x02fc
            int r2 = r11.width
            r16 = r5
            r5 = -1
            if (r2 != r5) goto L_0x02ff
            r2 = 1
            goto L_0x0300
        L_0x02fc:
            r16 = r5
            r5 = -1
        L_0x02ff:
            r2 = 0
        L_0x0300:
            if (r2 == 0) goto L_0x0303
            goto L_0x0304
        L_0x0303:
            r13 = r14
        L_0x0304:
            int r1 = java.lang.Math.max(r1, r13)
            if (r24 == 0) goto L_0x0310
            int r2 = r11.width
            if (r2 != r5) goto L_0x0310
            r5 = 1
            goto L_0x0311
        L_0x0310:
            r5 = 0
        L_0x0311:
            int r2 = r6.f854f
            int r9 = r9.getMeasuredHeight()
            int r9 = r9 + r2
            int r13 = r11.topMargin
            int r9 = r9 + r13
            int r11 = r11.bottomMargin
            int r9 = r9 + r11
            int r11 = r38.mo1382r()
            int r9 = r9 + r11
            int r2 = java.lang.Math.max(r2, r9)
            r6.f854f = r2
            r24 = r5
            r5 = r16
        L_0x032d:
            int r4 = r4 + 1
            r2 = r29
            goto L_0x0273
        L_0x0333:
            int r2 = r6.f854f
            int r4 = r38.getPaddingTop()
            int r5 = r38.getPaddingBottom()
            int r5 = r5 + r4
            int r5 = r5 + r2
            r6.f854f = r5
            goto L_0x0262
        L_0x0343:
            if (r24 != 0) goto L_0x034a
            r2 = 1073741824(0x40000000, float:2.0)
            if (r0 == r2) goto L_0x034a
            goto L_0x034c
        L_0x034a:
            r1 = r20
        L_0x034c:
            int r0 = r38.getPaddingLeft()
            int r2 = r38.getPaddingRight()
            int r2 = r2 + r0
            int r2 = r2 + r1
            int r0 = r38.getSuggestedMinimumWidth()
            int r0 = java.lang.Math.max(r2, r0)
            int r0 = android.view.View.resolveSizeAndState(r0, r7, r15)
            r6.setMeasuredDimension(r0, r3)
            if (r25 == 0) goto L_0x08ef
            int r0 = r38.getMeasuredWidth()
            r1 = 1073741824(0x40000000, float:2.0)
            int r7 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r1)
            r9 = 0
        L_0x0372:
            if (r9 >= r10) goto L_0x08ef
            android.view.View r1 = r6.getChildAt(r9)
            int r0 = r1.getVisibility()
            r2 = 8
            if (r0 == r2) goto L_0x03a0
            android.view.ViewGroup$LayoutParams r0 = r1.getLayoutParams()
            r11 = r0
            androidx.appcompat.widget.LinearLayoutCompat$LayoutParams r11 = (androidx.appcompat.widget.LinearLayoutCompat.LayoutParams) r11
            int r0 = r11.width
            r2 = -1
            if (r0 != r2) goto L_0x03a0
            int r12 = r11.height
            int r0 = r1.getMeasuredHeight()
            r11.height = r0
            r3 = 0
            r5 = 0
            r0 = r38
            r2 = r7
            r4 = r40
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
            r11.height = r12
        L_0x03a0:
            int r9 = r9 + 1
            goto L_0x0372
        L_0x03a3:
            r27 = 1
            r0 = 0
            r6.f854f = r0
            int r9 = r38.getChildCount()
            int r10 = android.view.View.MeasureSpec.getMode(r39)
            int r11 = android.view.View.MeasureSpec.getMode(r40)
            int[] r0 = r6.f857i
            r12 = 4
            if (r0 == 0) goto L_0x03bd
            int[] r0 = r6.f858j
            if (r0 != 0) goto L_0x03c5
        L_0x03bd:
            int[] r0 = new int[r12]
            r6.f857i = r0
            int[] r0 = new int[r12]
            r6.f858j = r0
        L_0x03c5:
            int[] r13 = r6.f857i
            int[] r14 = r6.f858j
            r15 = 3
            r0 = -1
            r13[r15] = r0
            r17 = 2
            r13[r17] = r0
            r13[r27] = r0
            r1 = 0
            r13[r1] = r0
            r14[r15] = r0
            r14[r17] = r0
            r14[r27] = r0
            r14[r1] = r0
            boolean r5 = r6.f849a
            boolean r4 = r6.f856h
            r0 = 1073741824(0x40000000, float:2.0)
            if (r10 != r0) goto L_0x03e9
            r18 = 1
            goto L_0x03eb
        L_0x03e9:
            r18 = 0
        L_0x03eb:
            r0 = 0
            r1 = 0
            r2 = 0
            r3 = 0
            r8 = 0
            r12 = 0
            r15 = 0
            r22 = 0
            r23 = 1
            r24 = 0
        L_0x03f8:
            if (r3 >= r9) goto L_0x05ad
            android.view.View r7 = r6.getChildAt(r3)
            if (r7 != 0) goto L_0x040f
            int r7 = r6.f854f
            int r25 = r38.mo1386u()
            int r7 = r7 + r25
            r6.f854f = r7
            r25 = r0
            r26 = r2
            goto L_0x0420
        L_0x040f:
            r25 = r0
            int r0 = r7.getVisibility()
            r26 = r2
            r2 = 8
            if (r0 != r2) goto L_0x042a
            int r0 = r38.mo1374m()
            int r3 = r3 + r0
        L_0x0420:
            r30 = r5
            r0 = r25
            r2 = r26
            r26 = r4
            goto L_0x05a3
        L_0x042a:
            boolean r0 = r6.mo1383s(r3)
            if (r0 == 0) goto L_0x0437
            int r0 = r6.f854f
            int r2 = r6.f860l
            int r0 = r0 + r2
            r6.f854f = r0
        L_0x0437:
            android.view.ViewGroup$LayoutParams r0 = r7.getLayoutParams()
            r2 = r0
            androidx.appcompat.widget.LinearLayoutCompat$LayoutParams r2 = (androidx.appcompat.widget.LinearLayoutCompat.LayoutParams) r2
            float r0 = r2.f864a
            float r29 = r1 + r0
            r1 = 1073741824(0x40000000, float:2.0)
            if (r10 != r1) goto L_0x0495
            int r1 = r2.width
            if (r1 != 0) goto L_0x0495
            r1 = 0
            int r30 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r30 <= 0) goto L_0x0495
            if (r18 == 0) goto L_0x045e
            int r0 = r6.f854f
            int r1 = r2.leftMargin
            r30 = r3
            int r3 = r2.rightMargin
            int r1 = r1 + r3
            int r1 = r1 + r0
            r6.f854f = r1
            goto L_0x046e
        L_0x045e:
            r30 = r3
            int r0 = r6.f854f
            int r1 = r2.leftMargin
            int r1 = r1 + r0
            int r3 = r2.rightMargin
            int r1 = r1 + r3
            int r0 = java.lang.Math.max(r0, r1)
            r6.f854f = r0
        L_0x046e:
            if (r5 == 0) goto L_0x0485
            r0 = 0
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r0)
            r7.measure(r1, r1)
            r1 = r2
            r33 = r25
            r34 = r26
            r25 = r30
            r26 = r4
            r30 = r5
            goto L_0x0510
        L_0x0485:
            r1 = r2
            r33 = r25
            r34 = r26
            r25 = r30
            r0 = 1073741824(0x40000000, float:2.0)
            r26 = r4
            r30 = r5
            r5 = 1
            goto L_0x0514
        L_0x0495:
            r30 = r3
            int r1 = r2.width
            if (r1 != 0) goto L_0x04a5
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L_0x04a6
            r0 = -2
            r2.width = r0
            r3 = 0
            goto L_0x04a8
        L_0x04a5:
            r1 = 0
        L_0x04a6:
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x04a8:
            int r0 = (r29 > r1 ? 1 : (r29 == r1 ? 0 : -1))
            if (r0 != 0) goto L_0x04b1
            int r0 = r6.f854f
            r31 = r0
            goto L_0x04b3
        L_0x04b1:
            r31 = 0
        L_0x04b3:
            r32 = 0
            r1 = r25
            r0 = r38
            r33 = r1
            r1 = r7
            r35 = r2
            r34 = r26
            r2 = r39
            r36 = r3
            r25 = r30
            r3 = r31
            r26 = r4
            r4 = r40
            r30 = r5
            r5 = r32
            r0.mo1385t(r1, r2, r3, r4, r5)
            r0 = r36
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r0 == r1) goto L_0x04de
            r1 = r35
            r1.width = r0
            goto L_0x04e0
        L_0x04de:
            r1 = r35
        L_0x04e0:
            int r0 = r7.getMeasuredWidth()
            int r2 = r6.f854f
            if (r18 == 0) goto L_0x04f7
            int r3 = r1.leftMargin
            int r3 = r3 + r0
            int r4 = r1.rightMargin
            int r3 = r3 + r4
            int r4 = r38.mo1382r()
            int r3 = r3 + r4
            int r3 = r3 + r2
            r6.f854f = r3
            goto L_0x050a
        L_0x04f7:
            int r3 = r2 + r0
            int r4 = r1.leftMargin
            int r3 = r3 + r4
            int r4 = r1.rightMargin
            int r3 = r3 + r4
            int r4 = r38.mo1382r()
            int r3 = r3 + r4
            int r2 = java.lang.Math.max(r2, r3)
            r6.f854f = r2
        L_0x050a:
            if (r26 == 0) goto L_0x0510
            int r8 = java.lang.Math.max(r0, r8)
        L_0x0510:
            r5 = r22
            r0 = 1073741824(0x40000000, float:2.0)
        L_0x0514:
            if (r11 == r0) goto L_0x051f
            int r0 = r1.height
            r2 = -1
            if (r0 != r2) goto L_0x051f
            r0 = 1
            r24 = 1
            goto L_0x0520
        L_0x051f:
            r0 = 0
        L_0x0520:
            int r2 = r1.topMargin
            int r3 = r1.bottomMargin
            int r2 = r2 + r3
            int r3 = r7.getMeasuredHeight()
            int r3 = r3 + r2
            int r4 = r7.getMeasuredState()
            int r4 = android.view.View.combineMeasuredStates(r12, r4)
            if (r30 == 0) goto L_0x0562
            int r7 = r7.getBaseline()
            r12 = -1
            if (r7 == r12) goto L_0x0562
            int r12 = r1.f865b
            if (r12 >= 0) goto L_0x0541
            int r12 = r6.f853e
        L_0x0541:
            r12 = r12 & 112(0x70, float:1.57E-43)
            r21 = 4
            int r12 = r12 >> 4
            r22 = -2
            r12 = r12 & -2
            int r12 = r12 >> 1
            r22 = r2
            r2 = r13[r12]
            int r2 = java.lang.Math.max(r2, r7)
            r13[r12] = r2
            r2 = r14[r12]
            int r7 = r3 - r7
            int r2 = java.lang.Math.max(r2, r7)
            r14[r12] = r2
            goto L_0x0564
        L_0x0562:
            r22 = r2
        L_0x0564:
            int r2 = java.lang.Math.max(r15, r3)
            if (r23 == 0) goto L_0x0571
            int r7 = r1.height
            r12 = -1
            if (r7 != r12) goto L_0x0571
            r7 = 1
            goto L_0x0572
        L_0x0571:
            r7 = 0
        L_0x0572:
            float r1 = r1.f864a
            r12 = 0
            int r1 = (r1 > r12 ? 1 : (r1 == r12 ? 0 : -1))
            if (r1 <= 0) goto L_0x0584
            if (r0 == 0) goto L_0x057d
            r3 = r22
        L_0x057d:
            r1 = r33
            int r0 = java.lang.Math.max(r1, r3)
            goto L_0x0593
        L_0x0584:
            r1 = r33
            if (r0 == 0) goto L_0x058a
            r3 = r22
        L_0x058a:
            r0 = r34
            int r0 = java.lang.Math.max(r0, r3)
            r34 = r0
            r0 = r1
        L_0x0593:
            int r1 = r38.mo1374m()
            int r3 = r25 + r1
            r15 = r2
            r12 = r4
            r22 = r5
            r23 = r7
            r1 = r29
            r2 = r34
        L_0x05a3:
            int r3 = r3 + 1
            r7 = r39
            r4 = r26
            r5 = r30
            goto L_0x03f8
        L_0x05ad:
            r26 = r4
            r30 = r5
            r37 = r2
            r2 = r0
            r0 = r37
            int r3 = r6.f854f
            if (r3 <= 0) goto L_0x05c7
            boolean r3 = r6.mo1383s(r9)
            if (r3 == 0) goto L_0x05c7
            int r3 = r6.f854f
            int r4 = r6.f860l
            int r3 = r3 + r4
            r6.f854f = r3
        L_0x05c7:
            r3 = r13[r27]
            r4 = -1
            if (r3 != r4) goto L_0x05de
            r3 = 0
            r5 = r13[r3]
            if (r5 != r4) goto L_0x05de
            r3 = r13[r17]
            if (r3 != r4) goto L_0x05de
            r3 = 3
            r5 = r13[r3]
            if (r5 == r4) goto L_0x05db
            goto L_0x05df
        L_0x05db:
            r25 = r12
            goto L_0x0611
        L_0x05de:
            r3 = 3
        L_0x05df:
            r4 = r13[r3]
            r5 = 0
            r7 = r13[r5]
            r5 = r13[r27]
            r3 = r13[r17]
            int r3 = java.lang.Math.max(r5, r3)
            int r3 = java.lang.Math.max(r7, r3)
            int r3 = java.lang.Math.max(r4, r3)
            r4 = 3
            r5 = r14[r4]
            r4 = 0
            r7 = r14[r4]
            r4 = r14[r27]
            r25 = r12
            r12 = r14[r17]
            int r4 = java.lang.Math.max(r4, r12)
            int r4 = java.lang.Math.max(r7, r4)
            int r4 = java.lang.Math.max(r5, r4)
            int r4 = r4 + r3
            int r15 = java.lang.Math.max(r15, r4)
        L_0x0611:
            if (r26 == 0) goto L_0x066a
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r10 == r3) goto L_0x0619
            if (r10 != 0) goto L_0x066a
        L_0x0619:
            r3 = 0
            r6.f854f = r3
            r4 = 0
        L_0x061d:
            if (r4 >= r9) goto L_0x066a
            android.view.View r3 = r6.getChildAt(r4)
            if (r3 != 0) goto L_0x062d
            int r3 = r6.f854f
            int r5 = r38.mo1386u()
            int r3 = r3 + r5
            goto L_0x0665
        L_0x062d:
            int r5 = r3.getVisibility()
            r7 = 8
            if (r5 != r7) goto L_0x063b
            int r3 = r38.mo1374m()
            int r4 = r4 + r3
            goto L_0x0667
        L_0x063b:
            android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
            androidx.appcompat.widget.LinearLayoutCompat$LayoutParams r3 = (androidx.appcompat.widget.LinearLayoutCompat.LayoutParams) r3
            int r5 = r6.f854f
            if (r18 == 0) goto L_0x0654
            int r7 = r3.leftMargin
            int r7 = r7 + r8
            int r3 = r3.rightMargin
            int r7 = r7 + r3
            int r3 = r38.mo1382r()
            int r7 = r7 + r3
            int r7 = r7 + r5
            r6.f854f = r7
            goto L_0x0667
        L_0x0654:
            int r7 = r5 + r8
            int r12 = r3.leftMargin
            int r7 = r7 + r12
            int r3 = r3.rightMargin
            int r7 = r7 + r3
            int r3 = r38.mo1382r()
            int r7 = r7 + r3
            int r3 = java.lang.Math.max(r5, r7)
        L_0x0665:
            r6.f854f = r3
        L_0x0667:
            int r4 = r4 + 1
            goto L_0x061d
        L_0x066a:
            int r3 = r6.f854f
            int r4 = r38.getPaddingLeft()
            int r5 = r38.getPaddingRight()
            int r5 = r5 + r4
            int r5 = r5 + r3
            r6.f854f = r5
            int r3 = r38.getSuggestedMinimumWidth()
            int r3 = java.lang.Math.max(r5, r3)
            r7 = r39
            r4 = 0
            int r3 = android.view.View.resolveSizeAndState(r3, r7, r4)
            r4 = 16777215(0xffffff, float:2.3509886E-38)
            r4 = r4 & r3
            int r5 = r6.f854f
            int r4 = r4 - r5
            if (r22 != 0) goto L_0x06de
            if (r4 == 0) goto L_0x0698
            r12 = 0
            int r16 = (r1 > r12 ? 1 : (r1 == r12 ? 0 : -1))
            if (r16 <= 0) goto L_0x0698
            goto L_0x06de
        L_0x0698:
            int r0 = java.lang.Math.max(r0, r2)
            if (r26 == 0) goto L_0x06d5
            r1 = 1073741824(0x40000000, float:2.0)
            if (r10 == r1) goto L_0x06d5
            r4 = 0
        L_0x06a3:
            if (r4 >= r9) goto L_0x06d5
            android.view.View r1 = r6.getChildAt(r4)
            if (r1 == 0) goto L_0x06d2
            int r2 = r1.getVisibility()
            r10 = 8
            if (r2 != r10) goto L_0x06b4
            goto L_0x06d2
        L_0x06b4:
            android.view.ViewGroup$LayoutParams r2 = r1.getLayoutParams()
            androidx.appcompat.widget.LinearLayoutCompat$LayoutParams r2 = (androidx.appcompat.widget.LinearLayoutCompat.LayoutParams) r2
            float r2 = r2.f864a
            r10 = 0
            int r2 = (r2 > r10 ? 1 : (r2 == r10 ? 0 : -1))
            if (r2 <= 0) goto L_0x06d2
            r2 = 1073741824(0x40000000, float:2.0)
            int r10 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r2)
            int r12 = r1.getMeasuredHeight()
            int r12 = android.view.View.MeasureSpec.makeMeasureSpec(r12, r2)
            r1.measure(r10, r12)
        L_0x06d2:
            int r4 = r4 + 1
            goto L_0x06a3
        L_0x06d5:
            r8 = r40
            r22 = r9
            r12 = r25
        L_0x06db:
            r5 = 0
            goto L_0x0886
        L_0x06de:
            float r2 = r6.f855g
            r8 = 0
            int r12 = (r2 > r8 ? 1 : (r2 == r8 ? 0 : -1))
            if (r12 <= 0) goto L_0x06e6
            r1 = r2
        L_0x06e6:
            r2 = 3
            r8 = -1
            r13[r2] = r8
            r13[r17] = r8
            r13[r27] = r8
            r12 = 0
            r13[r12] = r8
            r14[r2] = r8
            r14[r17] = r8
            r14[r27] = r8
            r14[r12] = r8
            r6.f854f = r12
            r8 = r4
            r12 = r25
            r2 = -1
            r4 = 0
        L_0x0700:
            if (r4 >= r9) goto L_0x082d
            android.view.View r15 = r6.getChildAt(r4)
            if (r15 == 0) goto L_0x0819
            int r5 = r15.getVisibility()
            r7 = 8
            if (r5 != r7) goto L_0x0712
            goto L_0x0819
        L_0x0712:
            android.view.ViewGroup$LayoutParams r5 = r15.getLayoutParams()
            androidx.appcompat.widget.LinearLayoutCompat$LayoutParams r5 = (androidx.appcompat.widget.LinearLayoutCompat.LayoutParams) r5
            float r7 = r5.f864a
            r20 = 0
            int r22 = (r7 > r20 ? 1 : (r7 == r20 ? 0 : -1))
            if (r22 <= 0) goto L_0x0775
            r22 = r9
            float r9 = (float) r8
            float r9 = r9 * r7
            float r9 = r9 / r1
            int r9 = (int) r9
            float r1 = r1 - r7
            int r8 = r8 - r9
            int r7 = r38.getPaddingTop()
            int r25 = r38.getPaddingBottom()
            int r25 = r25 + r7
            int r7 = r5.topMargin
            int r25 = r25 + r7
            int r7 = r5.bottomMargin
            int r7 = r25 + r7
            r25 = r1
            int r1 = r5.height
            r26 = r8
            r8 = r40
            int r1 = android.view.ViewGroup.getChildMeasureSpec(r8, r7, r1)
            int r7 = r5.width
            if (r7 != 0) goto L_0x0754
            r7 = 1073741824(0x40000000, float:2.0)
            if (r10 == r7) goto L_0x0750
            goto L_0x0754
        L_0x0750:
            if (r9 <= 0) goto L_0x075b
            r7 = r9
            goto L_0x075c
        L_0x0754:
            int r7 = r15.getMeasuredWidth()
            int r7 = r7 + r9
            if (r7 >= 0) goto L_0x075c
        L_0x075b:
            r7 = 0
        L_0x075c:
            r9 = 1073741824(0x40000000, float:2.0)
            int r7 = android.view.View.MeasureSpec.makeMeasureSpec(r7, r9)
            r15.measure(r7, r1)
            int r1 = r15.getMeasuredState()
            r7 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r1 = r1 & r7
            int r12 = android.view.View.combineMeasuredStates(r12, r1)
            r1 = r25
            r7 = r26
            goto L_0x077a
        L_0x0775:
            r7 = r8
            r22 = r9
            r8 = r40
        L_0x077a:
            if (r18 == 0) goto L_0x0799
            int r9 = r6.f854f
            int r25 = r15.getMeasuredWidth()
            r26 = r1
            int r1 = r5.leftMargin
            int r25 = r25 + r1
            int r1 = r5.rightMargin
            int r25 = r25 + r1
            int r1 = r38.mo1382r()
            int r25 = r25 + r1
            int r1 = r25 + r9
            r6.f854f = r1
            r25 = r7
            goto L_0x07b5
        L_0x0799:
            r26 = r1
            int r1 = r6.f854f
            int r9 = r15.getMeasuredWidth()
            int r9 = r9 + r1
            r25 = r7
            int r7 = r5.leftMargin
            int r9 = r9 + r7
            int r7 = r5.rightMargin
            int r9 = r9 + r7
            int r7 = r38.mo1382r()
            int r9 = r9 + r7
            int r1 = java.lang.Math.max(r1, r9)
            r6.f854f = r1
        L_0x07b5:
            r1 = 1073741824(0x40000000, float:2.0)
            if (r11 == r1) goto L_0x07c0
            int r1 = r5.height
            r7 = -1
            if (r1 != r7) goto L_0x07c0
            r1 = 1
            goto L_0x07c1
        L_0x07c0:
            r1 = 0
        L_0x07c1:
            int r7 = r5.topMargin
            int r9 = r5.bottomMargin
            int r7 = r7 + r9
            int r9 = r15.getMeasuredHeight()
            int r9 = r9 + r7
            int r2 = java.lang.Math.max(r2, r9)
            if (r1 == 0) goto L_0x07d2
            goto L_0x07d3
        L_0x07d2:
            r7 = r9
        L_0x07d3:
            int r0 = java.lang.Math.max(r0, r7)
            if (r23 == 0) goto L_0x07e0
            int r1 = r5.height
            r7 = -1
            if (r1 != r7) goto L_0x07e1
            r1 = 1
            goto L_0x07e2
        L_0x07e0:
            r7 = -1
        L_0x07e1:
            r1 = 0
        L_0x07e2:
            if (r30 == 0) goto L_0x080e
            int r15 = r15.getBaseline()
            if (r15 == r7) goto L_0x080e
            int r5 = r5.f865b
            if (r5 >= 0) goto L_0x07f0
            int r5 = r6.f853e
        L_0x07f0:
            r5 = r5 & 112(0x70, float:1.57E-43)
            r21 = 4
            int r5 = r5 >> 4
            r28 = -2
            r5 = r5 & -2
            int r5 = r5 >> 1
            r7 = r13[r5]
            int r7 = java.lang.Math.max(r7, r15)
            r13[r5] = r7
            r7 = r14[r5]
            int r9 = r9 - r15
            int r7 = java.lang.Math.max(r7, r9)
            r14[r5] = r7
            goto L_0x0812
        L_0x080e:
            r21 = 4
            r28 = -2
        L_0x0812:
            r23 = r1
            r7 = r25
            r1 = r26
            goto L_0x0824
        L_0x0819:
            r7 = r8
            r22 = r9
            r20 = 0
            r21 = 4
            r28 = -2
            r8 = r40
        L_0x0824:
            int r4 = r4 + 1
            r8 = r7
            r9 = r22
            r7 = r39
            goto L_0x0700
        L_0x082d:
            r8 = r40
            r22 = r9
            int r1 = r6.f854f
            int r4 = r38.getPaddingLeft()
            int r5 = r38.getPaddingRight()
            int r5 = r5 + r4
            int r5 = r5 + r1
            r6.f854f = r5
            r1 = r13[r27]
            r4 = -1
            if (r1 != r4) goto L_0x0856
            r1 = 0
            r5 = r13[r1]
            if (r5 != r4) goto L_0x0856
            r1 = r13[r17]
            if (r1 != r4) goto L_0x0856
            r1 = 3
            r5 = r13[r1]
            if (r5 == r4) goto L_0x0853
            goto L_0x0857
        L_0x0853:
            r15 = r2
            goto L_0x06db
        L_0x0856:
            r1 = 3
        L_0x0857:
            r4 = r13[r1]
            r5 = 0
            r7 = r13[r5]
            r9 = r13[r27]
            r10 = r13[r17]
            int r9 = java.lang.Math.max(r9, r10)
            int r7 = java.lang.Math.max(r7, r9)
            int r4 = java.lang.Math.max(r4, r7)
            r1 = r14[r1]
            r7 = r14[r5]
            r9 = r14[r27]
            r10 = r14[r17]
            int r9 = java.lang.Math.max(r9, r10)
            int r7 = java.lang.Math.max(r7, r9)
            int r1 = java.lang.Math.max(r1, r7)
            int r1 = r1 + r4
            int r1 = java.lang.Math.max(r2, r1)
            r15 = r1
        L_0x0886:
            if (r23 != 0) goto L_0x088d
            r1 = 1073741824(0x40000000, float:2.0)
            if (r11 == r1) goto L_0x088d
            goto L_0x088e
        L_0x088d:
            r0 = r15
        L_0x088e:
            int r1 = r38.getPaddingTop()
            int r2 = r38.getPaddingBottom()
            int r2 = r2 + r1
            int r2 = r2 + r0
            int r0 = r38.getSuggestedMinimumHeight()
            int r0 = java.lang.Math.max(r2, r0)
            r1 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r1 = r1 & r12
            r1 = r1 | r3
            int r2 = r12 << 16
            int r0 = android.view.View.resolveSizeAndState(r0, r8, r2)
            r6.setMeasuredDimension(r1, r0)
            if (r24 == 0) goto L_0x08ef
            int r0 = r38.getMeasuredHeight()
            r1 = 1073741824(0x40000000, float:2.0)
            int r7 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r1)
            r9 = r22
            r8 = 0
        L_0x08bc:
            if (r8 >= r9) goto L_0x08ef
            android.view.View r1 = r6.getChildAt(r8)
            int r0 = r1.getVisibility()
            r10 = 8
            if (r0 == r10) goto L_0x08eb
            android.view.ViewGroup$LayoutParams r0 = r1.getLayoutParams()
            r11 = r0
            androidx.appcompat.widget.LinearLayoutCompat$LayoutParams r11 = (androidx.appcompat.widget.LinearLayoutCompat.LayoutParams) r11
            int r0 = r11.height
            r12 = -1
            if (r0 != r12) goto L_0x08ec
            int r13 = r11.width
            int r0 = r1.getMeasuredWidth()
            r11.width = r0
            r3 = 0
            r5 = 0
            r0 = r38
            r2 = r39
            r4 = r7
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
            r11.width = r13
            goto L_0x08ec
        L_0x08eb:
            r12 = -1
        L_0x08ec:
            int r8 = r8 + 1
            goto L_0x08bc
        L_0x08ef:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.LinearLayoutCompat.onMeasure(int, int):void");
    }

    /* renamed from: p */
    public int mo1380p() {
        return this.f853e;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q */
    public int mo1381q() {
        return 0;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: r */
    public int mo1382r() {
        return 0;
    }

    /* access modifiers changed from: protected */
    /* renamed from: s */
    public boolean mo1383s(int i) {
        if (i == 0) {
            return (this.f862n & 1) != 0;
        }
        if (i == getChildCount()) {
            return (this.f862n & 4) != 0;
        }
        if ((this.f862n & 2) == 0) {
            return false;
        }
        for (int i2 = i - 1; i2 >= 0; i2--) {
            if (getChildAt(i2).getVisibility() != 8) {
                return true;
            }
        }
        return false;
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: t */
    public void mo1385t(View view, int i, int i2, int i3, int i4) {
        measureChildWithMargins(view, i, i2, i3, i4);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: u */
    public int mo1386u() {
        return 0;
    }

    /* renamed from: v */
    public void mo1387v(boolean z) {
        this.f849a = z;
    }

    /* renamed from: w */
    public void mo1388w(int i) {
        if (this.f852d != i) {
            this.f852d = i;
            requestLayout();
        }
    }
}
