package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.C0183p;
import androidx.core.widget.C0502c;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.common.api.C4291a;
import com.vidio.android.p195tv.R;
import java.lang.reflect.Method;
import p098d.p099a.C4568b;
import p098d.p120g.p130j.C4761m;

public class ListPopupWindow implements C0183p {

    /* renamed from: a */
    private static Method f866a;

    /* renamed from: b */
    private static Method f867b;

    /* renamed from: c */
    private static Method f868c;

    /* renamed from: A */
    private Rect f869A;

    /* renamed from: B */
    private boolean f870B;

    /* renamed from: C */
    PopupWindow f871C;

    /* renamed from: d */
    private Context f872d;

    /* renamed from: e */
    private ListAdapter f873e;

    /* renamed from: f */
    C0285p f874f;

    /* renamed from: g */
    private int f875g;

    /* renamed from: h */
    private int f876h;

    /* renamed from: i */
    private int f877i;

    /* renamed from: j */
    private int f878j;

    /* renamed from: k */
    private int f879k;

    /* renamed from: l */
    private boolean f880l;

    /* renamed from: m */
    private boolean f881m;

    /* renamed from: n */
    private boolean f882n;

    /* renamed from: o */
    private int f883o;

    /* renamed from: p */
    int f884p;

    /* renamed from: q */
    private int f885q;

    /* renamed from: r */
    private DataSetObserver f886r;

    /* renamed from: s */
    private View f887s;

    /* renamed from: t */
    private AdapterView.OnItemClickListener f888t;

    /* renamed from: u */
    final C0227e f889u;

    /* renamed from: v */
    private final C0226d f890v;

    /* renamed from: w */
    private final C0225c f891w;

    /* renamed from: x */
    private final C0223a f892x;

    /* renamed from: y */
    final Handler f893y;

    /* renamed from: z */
    private final Rect f894z;

    /* renamed from: androidx.appcompat.widget.ListPopupWindow$a */
    private class C0223a implements Runnable {
        C0223a() {
        }

        public void run() {
            C0285p pVar = ListPopupWindow.this.f874f;
            if (pVar != null) {
                pVar.mo1700c(true);
                pVar.requestLayout();
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.ListPopupWindow$b */
    private class C0224b extends DataSetObserver {
        C0224b() {
        }

        public void onChanged() {
            if (ListPopupWindow.this.mo710a()) {
                ListPopupWindow.this.show();
            }
        }

        public void onInvalidated() {
            ListPopupWindow.this.dismiss();
        }
    }

    /* renamed from: androidx.appcompat.widget.ListPopupWindow$c */
    private class C0225c implements AbsListView.OnScrollListener {
        C0225c() {
        }

        public void onScroll(AbsListView absListView, int i, int i2, int i3) {
        }

        public void onScrollStateChanged(AbsListView absListView, int i) {
            boolean z = true;
            if (i == 1) {
                if (ListPopupWindow.this.f871C.getInputMethodMode() != 2) {
                    z = false;
                }
                if (!z && ListPopupWindow.this.f871C.getContentView() != null) {
                    ListPopupWindow listPopupWindow = ListPopupWindow.this;
                    listPopupWindow.f893y.removeCallbacks(listPopupWindow.f889u);
                    ListPopupWindow.this.f889u.run();
                }
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.ListPopupWindow$d */
    private class C0226d implements View.OnTouchListener {
        C0226d() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            PopupWindow popupWindow;
            int action = motionEvent.getAction();
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            if (action == 0 && (popupWindow = ListPopupWindow.this.f871C) != null && popupWindow.isShowing() && x >= 0 && x < ListPopupWindow.this.f871C.getWidth() && y >= 0 && y < ListPopupWindow.this.f871C.getHeight()) {
                ListPopupWindow listPopupWindow = ListPopupWindow.this;
                listPopupWindow.f893y.postDelayed(listPopupWindow.f889u, 250);
                return false;
            } else if (action != 1) {
                return false;
            } else {
                ListPopupWindow listPopupWindow2 = ListPopupWindow.this;
                listPopupWindow2.f893y.removeCallbacks(listPopupWindow2.f889u);
                return false;
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.ListPopupWindow$e */
    private class C0227e implements Runnable {
        C0227e() {
        }

        public void run() {
            C0285p pVar = ListPopupWindow.this.f874f;
            if (pVar != null) {
                int i = C4761m.f17241f;
                if (pVar.isAttachedToWindow() && ListPopupWindow.this.f874f.getCount() > ListPopupWindow.this.f874f.getChildCount()) {
                    int childCount = ListPopupWindow.this.f874f.getChildCount();
                    ListPopupWindow listPopupWindow = ListPopupWindow.this;
                    if (childCount <= listPopupWindow.f884p) {
                        listPopupWindow.f871C.setInputMethodMode(2);
                        ListPopupWindow.this.show();
                    }
                }
            }
        }
    }

    static {
        if (Build.VERSION.SDK_INT <= 28) {
            Class<PopupWindow> cls = PopupWindow.class;
            try {
                f866a = cls.getDeclaredMethod("setClipToScreenEnabled", new Class[]{Boolean.TYPE});
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                f868c = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[]{Rect.class});
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
        if (Build.VERSION.SDK_INT <= 23) {
            Class<PopupWindow> cls2 = PopupWindow.class;
            try {
                f867b = cls2.getDeclaredMethod("getMaxAvailableHeight", new Class[]{View.class, Integer.TYPE, Boolean.TYPE});
            } catch (NoSuchMethodException unused3) {
                Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
            }
        }
    }

    public ListPopupWindow(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.listPopupWindowStyle);
    }

    public ListPopupWindow(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public ListPopupWindow(Context context, AttributeSet attributeSet, int i, int i2) {
        this.f875g = -2;
        this.f876h = -2;
        this.f879k = 1002;
        this.f883o = 0;
        this.f884p = C4291a.C4299e.API_PRIORITY_OTHER;
        this.f885q = 0;
        this.f889u = new C0227e();
        this.f890v = new C0226d();
        this.f891w = new C0225c();
        this.f892x = new C0223a();
        this.f894z = new Rect();
        this.f872d = context;
        this.f893y = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4568b.f16468p, i, i2);
        this.f877i = obtainStyledAttributes.getDimensionPixelOffset(0, 0);
        int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(1, 0);
        this.f878j = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.f880l = true;
        }
        obtainStyledAttributes.recycle();
        AppCompatPopupWindow appCompatPopupWindow = new AppCompatPopupWindow(context, attributeSet, i, i2);
        this.f871C = appCompatPopupWindow;
        appCompatPopupWindow.setInputMethodMode(1);
    }

    /* renamed from: A */
    public void mo1389A(Rect rect) {
        this.f869A = rect != null ? new Rect(rect) : null;
    }

    /* renamed from: B */
    public void mo1390B(int i) {
        this.f871C.setInputMethodMode(i);
    }

    /* renamed from: C */
    public void mo1391C(boolean z) {
        this.f870B = z;
        this.f871C.setFocusable(z);
    }

    /* renamed from: D */
    public void mo1392D(PopupWindow.OnDismissListener onDismissListener) {
        this.f871C.setOnDismissListener(onDismissListener);
    }

    /* renamed from: E */
    public void mo1393E(AdapterView.OnItemClickListener onItemClickListener) {
        this.f888t = onItemClickListener;
    }

    /* renamed from: F */
    public void mo1394F(boolean z) {
        this.f882n = true;
        this.f881m = z;
    }

    /* renamed from: G */
    public void mo1395G(int i) {
        this.f885q = i;
    }

    /* renamed from: a */
    public boolean mo710a() {
        return this.f871C.isShowing();
    }

    /* renamed from: b */
    public int mo1396b() {
        return this.f877i;
    }

    /* renamed from: d */
    public void mo1397d(int i) {
        this.f877i = i;
    }

    public void dismiss() {
        this.f871C.dismiss();
        this.f871C.setContentView((View) null);
        this.f874f = null;
        this.f893y.removeCallbacks(this.f889u);
    }

    /* renamed from: g */
    public Drawable mo1398g() {
        return this.f871C.getBackground();
    }

    /* renamed from: i */
    public void mo1399i(Drawable drawable) {
        this.f871C.setBackgroundDrawable(drawable);
    }

    /* renamed from: j */
    public ListView mo714j() {
        return this.f874f;
    }

    /* renamed from: k */
    public void mo1400k(int i) {
        this.f878j = i;
        this.f880l = true;
    }

    /* renamed from: n */
    public int mo1401n() {
        if (!this.f880l) {
            return 0;
        }
        return this.f878j;
    }

    /* renamed from: o */
    public void mo1304o(ListAdapter listAdapter) {
        DataSetObserver dataSetObserver = this.f886r;
        if (dataSetObserver == null) {
            this.f886r = new C0224b();
        } else {
            ListAdapter listAdapter2 = this.f873e;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.f873e = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.f886r);
        }
        C0285p pVar = this.f874f;
        if (pVar != null) {
            pVar.setAdapter(this.f873e);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p */
    public C0285p mo1402p(Context context, boolean z) {
        return new C0285p(context, z);
    }

    /* renamed from: q */
    public Object mo1403q() {
        if (!mo710a()) {
            return null;
        }
        return this.f874f.getSelectedItem();
    }

    /* renamed from: r */
    public long mo1404r() {
        if (!mo710a()) {
            return Long.MIN_VALUE;
        }
        return this.f874f.getSelectedItemId();
    }

    /* renamed from: s */
    public int mo1405s() {
        if (!mo710a()) {
            return -1;
        }
        return this.f874f.getSelectedItemPosition();
    }

    public void show() {
        int i;
        int i2;
        int i3;
        C0285p pVar;
        int i4;
        if (this.f874f == null) {
            C0285p p = mo1402p(this.f872d, !this.f870B);
            this.f874f = p;
            p.setAdapter(this.f873e);
            this.f874f.setOnItemClickListener(this.f888t);
            this.f874f.setFocusable(true);
            this.f874f.setFocusableInTouchMode(true);
            this.f874f.setOnItemSelectedListener(new C0292s(this));
            this.f874f.setOnScrollListener(this.f891w);
            this.f871C.setContentView(this.f874f);
        } else {
            ViewGroup viewGroup = (ViewGroup) this.f871C.getContentView();
        }
        Drawable background = this.f871C.getBackground();
        int i5 = 0;
        if (background != null) {
            background.getPadding(this.f894z);
            Rect rect = this.f894z;
            int i6 = rect.top;
            i = rect.bottom + i6;
            if (!this.f880l) {
                this.f878j = -i6;
            }
        } else {
            this.f894z.setEmpty();
            i = 0;
        }
        boolean z = this.f871C.getInputMethodMode() == 2;
        View view = this.f887s;
        int i7 = this.f878j;
        if (Build.VERSION.SDK_INT <= 23) {
            Method method = f867b;
            if (method != null) {
                try {
                    i2 = ((Integer) method.invoke(this.f871C, new Object[]{view, Integer.valueOf(i7), Boolean.valueOf(z)})).intValue();
                } catch (Exception unused) {
                    Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
                }
            }
            i2 = this.f871C.getMaxAvailableHeight(view, i7);
        } else {
            i2 = this.f871C.getMaxAvailableHeight(view, i7, z);
        }
        if (this.f875g == -1) {
            i3 = i2 + i;
        } else {
            int i8 = this.f876h;
            if (i8 != -2) {
                i4 = 1073741824;
                if (i8 == -1) {
                    int i9 = this.f872d.getResources().getDisplayMetrics().widthPixels;
                    Rect rect2 = this.f894z;
                    i8 = i9 - (rect2.left + rect2.right);
                }
            } else {
                int i10 = this.f872d.getResources().getDisplayMetrics().widthPixels;
                Rect rect3 = this.f894z;
                i8 = i10 - (rect3.left + rect3.right);
                i4 = RecyclerView.UNDEFINED_DURATION;
            }
            int a = this.f874f.mo1698a(View.MeasureSpec.makeMeasureSpec(i8, i4), 0, -1, i2 + 0, -1);
            i3 = a + (a > 0 ? this.f874f.getPaddingBottom() + this.f874f.getPaddingTop() + i + 0 : 0);
        }
        boolean z2 = this.f871C.getInputMethodMode() == 2;
        C0502c.m2297g(this.f871C, this.f879k);
        if (this.f871C.isShowing()) {
            View view2 = this.f887s;
            int i11 = C4761m.f17241f;
            if (view2.isAttachedToWindow()) {
                int i12 = this.f876h;
                if (i12 == -1) {
                    i12 = -1;
                } else if (i12 == -2) {
                    i12 = this.f887s.getWidth();
                }
                int i13 = this.f875g;
                if (i13 == -1) {
                    if (!z2) {
                        i3 = -1;
                    }
                    if (z2) {
                        this.f871C.setWidth(this.f876h == -1 ? -1 : 0);
                        this.f871C.setHeight(0);
                    } else {
                        PopupWindow popupWindow = this.f871C;
                        if (this.f876h == -1) {
                            i5 = -1;
                        }
                        popupWindow.setWidth(i5);
                        this.f871C.setHeight(-1);
                    }
                } else if (i13 != -2) {
                    i3 = i13;
                }
                this.f871C.setOutsideTouchable(true);
                this.f871C.update(this.f887s, this.f877i, this.f878j, i12 < 0 ? -1 : i12, i3 < 0 ? -1 : i3);
                return;
            }
            return;
        }
        int i14 = this.f876h;
        if (i14 == -1) {
            i14 = -1;
        } else if (i14 == -2) {
            i14 = this.f887s.getWidth();
        }
        int i15 = this.f875g;
        if (i15 == -1) {
            i3 = -1;
        } else if (i15 != -2) {
            i3 = i15;
        }
        this.f871C.setWidth(i14);
        this.f871C.setHeight(i3);
        if (Build.VERSION.SDK_INT <= 28) {
            Method method2 = f866a;
            if (method2 != null) {
                try {
                    method2.invoke(this.f871C, new Object[]{Boolean.TRUE});
                } catch (Exception unused2) {
                    Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
                }
            }
        } else {
            this.f871C.setIsClippedToScreen(true);
        }
        this.f871C.setOutsideTouchable(true);
        this.f871C.setTouchInterceptor(this.f890v);
        if (this.f882n) {
            C0502c.m2295e(this.f871C, this.f881m);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method3 = f868c;
            if (method3 != null) {
                try {
                    method3.invoke(this.f871C, new Object[]{this.f869A});
                } catch (Exception e) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e);
                }
            }
        } else {
            this.f871C.setEpicenterBounds(this.f869A);
        }
        this.f871C.showAsDropDown(this.f887s, this.f877i, this.f878j, this.f883o);
        this.f874f.setSelection(-1);
        if ((!this.f870B || this.f874f.isInTouchMode()) && (pVar = this.f874f) != null) {
            pVar.mo1700c(true);
            pVar.requestLayout();
        }
        if (!this.f870B) {
            this.f893y.post(this.f892x);
        }
    }

    /* renamed from: t */
    public View mo1406t() {
        if (!mo710a()) {
            return null;
        }
        return this.f874f.getSelectedView();
    }

    /* renamed from: u */
    public int mo1407u() {
        return this.f876h;
    }

    /* renamed from: v */
    public boolean mo1408v() {
        return this.f870B;
    }

    /* renamed from: w */
    public void mo1409w(View view) {
        this.f887s = view;
    }

    /* renamed from: x */
    public void mo1410x(int i) {
        this.f871C.setAnimationStyle(i);
    }

    /* renamed from: y */
    public void mo1411y(int i) {
        Drawable background = this.f871C.getBackground();
        if (background != null) {
            background.getPadding(this.f894z);
            Rect rect = this.f894z;
            this.f876h = rect.left + rect.right + i;
            return;
        }
        this.f876h = i;
    }

    /* renamed from: z */
    public void mo1412z(int i) {
        this.f883o = i;
    }
}
