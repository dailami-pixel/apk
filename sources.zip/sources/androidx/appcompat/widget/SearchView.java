package androidx.appcompat.widget;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.customview.view.AbsSavedState;
import com.appsflyer.oaid.BuildConfig;
import com.vidio.android.p195tv.R;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.WeakHashMap;
import p098d.p099a.C4568b;
import p098d.p099a.p106g.C4591c;
import p098d.p120g.p130j.C4761m;
import p165e.p166a.p167a.p168a.C4924a;

public class SearchView extends LinearLayoutCompat implements C4591c {

    /* renamed from: p */
    static final C0240k f900p = (Build.VERSION.SDK_INT < 29 ? new C0240k() : null);

    /* renamed from: A */
    private Rect f901A;

    /* renamed from: B */
    private Rect f902B;

    /* renamed from: C */
    private int[] f903C;

    /* renamed from: D */
    private int[] f904D;

    /* renamed from: E */
    private final ImageView f905E;

    /* renamed from: F */
    private final Drawable f906F;

    /* renamed from: G */
    private final Intent f907G;

    /* renamed from: H */
    private final Intent f908H;

    /* renamed from: I */
    private final CharSequence f909I;

    /* renamed from: J */
    private boolean f910J;

    /* renamed from: K */
    private boolean f911K;

    /* renamed from: L */
    private CharSequence f912L;

    /* renamed from: M */
    private boolean f913M;

    /* renamed from: N */
    private int f914N;

    /* renamed from: O */
    private CharSequence f915O;

    /* renamed from: P */
    private CharSequence f916P;

    /* renamed from: Q */
    private boolean f917Q;

    /* renamed from: R */
    private int f918R;

    /* renamed from: a0 */
    private final Runnable f919a0;

    /* renamed from: b0 */
    private Runnable f920b0;

    /* renamed from: c0 */
    private final View.OnClickListener f921c0;

    /* renamed from: d0 */
    View.OnKeyListener f922d0;

    /* renamed from: e0 */
    private final TextView.OnEditorActionListener f923e0;

    /* renamed from: f0 */
    private final AdapterView.OnItemClickListener f924f0;

    /* renamed from: g0 */
    private final AdapterView.OnItemSelectedListener f925g0;

    /* renamed from: h0 */
    private TextWatcher f926h0;

    /* renamed from: q */
    final SearchAutoComplete f927q;

    /* renamed from: r */
    private final View f928r;

    /* renamed from: s */
    private final View f929s;

    /* renamed from: t */
    private final View f930t;

    /* renamed from: u */
    final ImageView f931u;

    /* renamed from: v */
    final ImageView f932v;

    /* renamed from: w */
    final ImageView f933w;

    /* renamed from: x */
    final ImageView f934x;

    /* renamed from: y */
    private final View f935y;

    /* renamed from: z */
    private C0241l f936z;

    static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0228a();

        /* renamed from: c */
        boolean f937c;

        /* renamed from: androidx.appcompat.widget.SearchView$SavedState$a */
        class C0228a implements Parcelable.ClassLoaderCreator<SavedState> {
            C0228a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new SavedState[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f937c = ((Boolean) parcel.readValue((ClassLoader) null)).booleanValue();
        }

        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder P = C4924a.m17863P("SearchView.SavedState{");
            P.append(Integer.toHexString(System.identityHashCode(this)));
            P.append(" isIconified=");
            P.append(this.f937c);
            P.append("}");
            return P.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeValue(Boolean.valueOf(this.f937c));
        }
    }

    public static class SearchAutoComplete extends AppCompatAutoCompleteTextView {

        /* renamed from: d */
        private int f938d;

        /* renamed from: e */
        private SearchView f939e;

        /* renamed from: f */
        private boolean f940f;

        /* renamed from: g */
        final Runnable f941g;

        /* renamed from: androidx.appcompat.widget.SearchView$SearchAutoComplete$a */
        class C0229a implements Runnable {
            C0229a() {
            }

            public void run() {
                SearchAutoComplete.this.mo1443d();
            }
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, R.attr.autoCompleteTextViewStyle);
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i);
            this.f941g = new C0229a();
            this.f938d = getThreshold();
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo1440a() {
            if (Build.VERSION.SDK_INT >= 29) {
                setInputMethodMode(1);
                if (enoughToFilter()) {
                    showDropDown();
                    return;
                }
                return;
            }
            SearchView.f900p.mo1468c(this);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo1441b(boolean z) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            if (!z) {
                this.f940f = false;
                removeCallbacks(this.f941g);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else if (inputMethodManager.isActive(this)) {
                this.f940f = false;
                removeCallbacks(this.f941g);
                inputMethodManager.showSoftInput(this, 0);
            } else {
                this.f940f = true;
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: c */
        public void mo1442c(SearchView searchView) {
            this.f939e = searchView;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: d */
        public void mo1443d() {
            if (this.f940f) {
                ((InputMethodManager) getContext().getSystemService("input_method")).showSoftInput(this, 0);
                this.f940f = false;
            }
        }

        public boolean enoughToFilter() {
            return this.f938d <= 0 || super.enoughToFilter();
        }

        public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f940f) {
                removeCallbacks(this.f941g);
                post(this.f941g);
            }
            return onCreateInputConnection;
        }

        /* access modifiers changed from: protected */
        public void onFinishInflate() {
            super.onFinishInflate();
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            Configuration configuration = getResources().getConfiguration();
            int i = configuration.screenWidthDp;
            int i2 = configuration.screenHeightDp;
            setMinWidth((int) TypedValue.applyDimension(1, (float) ((i < 960 || i2 < 720 || configuration.orientation != 2) ? (i >= 600 || (i >= 640 && i2 >= 480)) ? 192 : 160 : 256), displayMetrics));
        }

        /* access modifiers changed from: protected */
        public void onFocusChanged(boolean z, int i, Rect rect) {
            super.onFocusChanged(z, i, rect);
            this.f939e.mo1424E();
        }

        public boolean onKeyPreIme(int i, KeyEvent keyEvent) {
            if (i == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                } else if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f939e.clearFocus();
                        mo1441b(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i, keyEvent);
        }

        public void onWindowFocusChanged(boolean z) {
            super.onWindowFocusChanged(z);
            if (z && this.f939e.hasFocus() && getVisibility() == 0) {
                boolean z2 = true;
                this.f940f = true;
                Context context = getContext();
                C0240k kVar = SearchView.f900p;
                if (context.getResources().getConfiguration().orientation != 2) {
                    z2 = false;
                }
                if (z2) {
                    mo1440a();
                }
            }
        }

        public void performCompletion() {
        }

        /* access modifiers changed from: protected */
        public void replaceText(CharSequence charSequence) {
        }

        public void setThreshold(int i) {
            super.setThreshold(i);
            this.f938d = i;
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$a */
    class C0230a implements TextWatcher {
        C0230a() {
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            SearchView.this.mo1423D(charSequence);
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$b */
    class C0231b implements Runnable {
        C0231b() {
        }

        public void run() {
            SearchView.this.mo1425G();
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$c */
    class C0232c implements Runnable {
        C0232c() {
        }

        public void run() {
            Objects.requireNonNull(SearchView.this);
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$d */
    class C0233d implements View.OnFocusChangeListener {
        C0233d() {
        }

        public void onFocusChange(View view, boolean z) {
            Objects.requireNonNull(SearchView.this);
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$e */
    class C0234e implements View.OnLayoutChangeListener {
        C0234e() {
        }

        public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
            SearchView.this.mo1432x();
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$f */
    class C0235f implements View.OnClickListener {
        C0235f() {
        }

        public void onClick(View view) {
            SearchView searchView = SearchView.this;
            if (view == searchView.f931u) {
                searchView.mo1421B();
            } else if (view == searchView.f933w) {
                searchView.mo1434z();
            } else if (view == searchView.f932v) {
                searchView.mo1422C();
            } else if (view == searchView.f934x) {
                Objects.requireNonNull(searchView);
            } else if (view == searchView.f927q) {
                searchView.mo1433y();
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$g */
    class C0236g implements View.OnKeyListener {
        C0236g() {
        }

        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            Objects.requireNonNull(SearchView.this);
            return false;
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$h */
    class C0237h implements TextView.OnEditorActionListener {
        C0237h() {
        }

        public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            SearchView.this.mo1422C();
            return true;
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$i */
    class C0238i implements AdapterView.OnItemClickListener {
        C0238i() {
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            SearchView.this.mo1420A(i);
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$j */
    class C0239j implements AdapterView.OnItemSelectedListener {
        C0239j() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            SearchView.this.f927q.getText();
            throw null;
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$k */
    private static class C0240k {

        /* renamed from: a */
        private Method f953a = null;

        /* renamed from: b */
        private Method f954b = null;

        /* renamed from: c */
        private Method f955c = null;

        C0240k() {
            m1066d();
            try {
                Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
                this.f953a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
                this.f954b = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            Class<AutoCompleteTextView> cls = AutoCompleteTextView.class;
            try {
                Method method = cls.getMethod("ensureImeVisible", new Class[]{Boolean.TYPE});
                this.f955c = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
        }

        /* renamed from: d */
        private static void m1066d() {
            if (Build.VERSION.SDK_INT >= 29) {
                throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo1466a(AutoCompleteTextView autoCompleteTextView) {
            m1066d();
            Method method = this.f954b;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, new Object[0]);
                } catch (Exception unused) {
                }
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo1467b(AutoCompleteTextView autoCompleteTextView) {
            m1066d();
            Method method = this.f953a;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, new Object[0]);
                } catch (Exception unused) {
                }
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: c */
        public void mo1468c(AutoCompleteTextView autoCompleteTextView) {
            m1066d();
            Method method = this.f955c;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, new Object[]{Boolean.TRUE});
                } catch (Exception unused) {
                }
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$l */
    private static class C0241l extends TouchDelegate {

        /* renamed from: a */
        private final View f956a;

        /* renamed from: b */
        private final Rect f957b = new Rect();

        /* renamed from: c */
        private final Rect f958c = new Rect();

        /* renamed from: d */
        private final Rect f959d = new Rect();

        /* renamed from: e */
        private final int f960e;

        /* renamed from: f */
        private boolean f961f;

        public C0241l(Rect rect, Rect rect2, View view) {
            super(rect, view);
            this.f960e = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
            mo1469a(rect, rect2);
            this.f956a = view;
        }

        /* renamed from: a */
        public void mo1469a(Rect rect, Rect rect2) {
            this.f957b.set(rect);
            this.f959d.set(rect);
            Rect rect3 = this.f959d;
            int i = this.f960e;
            rect3.inset(-i, -i);
            this.f958c.set(rect2);
        }

        /* JADX WARNING: Removed duplicated region for block: B:19:0x0041  */
        /* JADX WARNING: Removed duplicated region for block: B:26:? A[RETURN, SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean onTouchEvent(android.view.MotionEvent r8) {
            /*
                r7 = this;
                float r0 = r8.getX()
                int r0 = (int) r0
                float r1 = r8.getY()
                int r1 = (int) r1
                int r2 = r8.getAction()
                r3 = 2
                r4 = 1
                r5 = 0
                if (r2 == 0) goto L_0x0032
                if (r2 == r4) goto L_0x0020
                if (r2 == r3) goto L_0x0020
                r6 = 3
                if (r2 == r6) goto L_0x001b
                goto L_0x003d
            L_0x001b:
                boolean r2 = r7.f961f
                r7.f961f = r5
                goto L_0x002f
            L_0x0020:
                boolean r2 = r7.f961f
                if (r2 == 0) goto L_0x002f
                android.graphics.Rect r6 = r7.f959d
                boolean r6 = r6.contains(r0, r1)
                if (r6 != 0) goto L_0x002f
                r4 = r2
                r2 = 0
                goto L_0x003f
            L_0x002f:
                r4 = r2
            L_0x0030:
                r2 = 1
                goto L_0x003f
            L_0x0032:
                android.graphics.Rect r2 = r7.f957b
                boolean r2 = r2.contains(r0, r1)
                if (r2 == 0) goto L_0x003d
                r7.f961f = r4
                goto L_0x0030
            L_0x003d:
                r2 = 1
                r4 = 0
            L_0x003f:
                if (r4 == 0) goto L_0x006e
                if (r2 == 0) goto L_0x005b
                android.graphics.Rect r2 = r7.f958c
                boolean r2 = r2.contains(r0, r1)
                if (r2 != 0) goto L_0x005b
                android.view.View r0 = r7.f956a
                int r0 = r0.getWidth()
                int r0 = r0 / r3
                float r0 = (float) r0
                android.view.View r1 = r7.f956a
                int r1 = r1.getHeight()
                int r1 = r1 / r3
                goto L_0x0064
            L_0x005b:
                android.graphics.Rect r2 = r7.f958c
                int r3 = r2.left
                int r0 = r0 - r3
                float r0 = (float) r0
                int r2 = r2.top
                int r1 = r1 - r2
            L_0x0064:
                float r1 = (float) r1
                r8.setLocation(r0, r1)
                android.view.View r0 = r7.f956a
                boolean r5 = r0.dispatchTouchEvent(r8)
            L_0x006e:
                return r5
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.C0241l.onTouchEvent(android.view.MotionEvent):boolean");
        }
    }

    public SearchView(Context context) {
        this(context, (AttributeSet) null);
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.searchViewStyle);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public SearchView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f901A = new Rect();
        this.f902B = new Rect();
        this.f903C = new int[2];
        this.f904D = new int[2];
        this.f919a0 = new C0231b();
        this.f920b0 = new C0232c();
        new WeakHashMap();
        C0235f fVar = new C0235f();
        this.f921c0 = fVar;
        this.f922d0 = new C0236g();
        C0237h hVar = new C0237h();
        this.f923e0 = hVar;
        C0238i iVar = new C0238i();
        this.f924f0 = iVar;
        C0239j jVar = new C0239j();
        this.f925g0 = jVar;
        this.f926h0 = new C0230a();
        C0259e0 v = C0259e0.m1181v(context, attributeSet, C4568b.f16474v, i, 0);
        LayoutInflater.from(context).inflate(v.mo1603n(9, R.layout.abc_search_view), this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(R.id.search_src_text);
        this.f927q = searchAutoComplete;
        searchAutoComplete.mo1442c(this);
        this.f928r = findViewById(R.id.search_edit_frame);
        View findViewById = findViewById(R.id.search_plate);
        this.f929s = findViewById;
        View findViewById2 = findViewById(R.id.submit_area);
        this.f930t = findViewById2;
        ImageView imageView = (ImageView) findViewById(R.id.search_button);
        this.f931u = imageView;
        ImageView imageView2 = (ImageView) findViewById(R.id.search_go_btn);
        this.f932v = imageView2;
        ImageView imageView3 = (ImageView) findViewById(R.id.search_close_btn);
        this.f933w = imageView3;
        ImageView imageView4 = (ImageView) findViewById(R.id.search_voice_btn);
        this.f934x = imageView4;
        ImageView imageView5 = (ImageView) findViewById(R.id.search_mag_icon);
        this.f905E = imageView5;
        Drawable g = v.mo1596g(10);
        int i2 = C4761m.f17241f;
        findViewById.setBackground(g);
        findViewById2.setBackground(v.mo1596g(14));
        imageView.setImageDrawable(v.mo1596g(13));
        imageView2.setImageDrawable(v.mo1596g(7));
        imageView3.setImageDrawable(v.mo1596g(4));
        imageView4.setImageDrawable(v.mo1596g(16));
        imageView5.setImageDrawable(v.mo1596g(13));
        this.f906F = v.mo1596g(12);
        C0266h0.m1246b(imageView, getResources().getString(R.string.abc_searchview_description_search));
        v.mo1603n(15, R.layout.abc_search_dropdown_item_icons_2line);
        v.mo1603n(5, 0);
        imageView.setOnClickListener(fVar);
        imageView3.setOnClickListener(fVar);
        imageView2.setOnClickListener(fVar);
        imageView4.setOnClickListener(fVar);
        searchAutoComplete.setOnClickListener(fVar);
        searchAutoComplete.addTextChangedListener(this.f926h0);
        searchAutoComplete.setOnEditorActionListener(hVar);
        searchAutoComplete.setOnItemClickListener(iVar);
        searchAutoComplete.setOnItemSelectedListener(jVar);
        searchAutoComplete.setOnKeyListener(this.f922d0);
        searchAutoComplete.setOnFocusChangeListener(new C0233d());
        boolean a = v.mo1590a(8, true);
        if (this.f910J != a) {
            this.f910J = a;
            m1050I(a);
            m1049H();
        }
        int f = v.mo1595f(1, -1);
        if (f != -1) {
            this.f914N = f;
            requestLayout();
        }
        this.f909I = v.mo1605p(6);
        this.f912L = v.mo1605p(11);
        int k = v.mo1600k(3, -1);
        if (k != -1) {
            searchAutoComplete.setImeOptions(k);
        }
        int k2 = v.mo1600k(2, -1);
        if (k2 != -1) {
            searchAutoComplete.setInputType(k2);
        }
        setFocusable(v.mo1590a(0, true));
        v.mo1609w();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.f907G = intent;
        intent.addFlags(268435456);
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.f908H = intent2;
        intent2.addFlags(268435456);
        View findViewById3 = findViewById(searchAutoComplete.getDropDownAnchor());
        this.f935y = findViewById3;
        if (findViewById3 != null) {
            findViewById3.addOnLayoutChangeListener(new C0234e());
        }
        m1050I(this.f910J);
        m1049H();
    }

    /* renamed from: F */
    private void m1048F() {
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.f927q.getText());
        int i = 0;
        if (!z2 && (!this.f910J || this.f917Q)) {
            z = false;
        }
        ImageView imageView = this.f933w;
        if (!z) {
            i = 8;
        }
        imageView.setVisibility(i);
        Drawable drawable = this.f933w.getDrawable();
        if (drawable != null) {
            drawable.setState(z2 ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    /* renamed from: H */
    private void m1049H() {
        SpannableStringBuilder spannableStringBuilder = this.f912L;
        if (spannableStringBuilder == null) {
            spannableStringBuilder = this.f909I;
        }
        SearchAutoComplete searchAutoComplete = this.f927q;
        if (spannableStringBuilder == null) {
            spannableStringBuilder = BuildConfig.FLAVOR;
        }
        if (this.f910J && this.f906F != null) {
            int textSize = (int) (((double) searchAutoComplete.getTextSize()) * 1.25d);
            this.f906F.setBounds(0, 0, textSize, textSize);
            SpannableStringBuilder spannableStringBuilder2 = new SpannableStringBuilder("   ");
            spannableStringBuilder2.setSpan(new ImageSpan(this.f906F), 1, 2, 33);
            spannableStringBuilder2.append(spannableStringBuilder);
            spannableStringBuilder = spannableStringBuilder2;
        }
        searchAutoComplete.setHint(spannableStringBuilder);
    }

    /* renamed from: I */
    private void m1050I(boolean z) {
        this.f911K = z;
        int i = 0;
        int i2 = z ? 0 : 8;
        TextUtils.isEmpty(this.f927q.getText());
        this.f931u.setVisibility(i2);
        this.f932v.setVisibility(8);
        this.f928r.setVisibility(z ? 8 : 0);
        if (this.f905E.getDrawable() == null || this.f910J) {
            i = 8;
        }
        this.f905E.setVisibility(i);
        m1048F();
        this.f934x.setVisibility(8);
        this.f930t.setVisibility(8);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: A */
    public boolean mo1420A(int i) {
        throw null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: B */
    public void mo1421B() {
        m1050I(false);
        this.f927q.requestFocus();
        this.f927q.mo1441b(true);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: C */
    public void mo1422C() {
        Editable text = this.f927q.getText();
        if (text != null && TextUtils.getTrimmedLength(text) > 0) {
            this.f927q.mo1441b(false);
            this.f927q.dismissDropDown();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: D */
    public void mo1423D(CharSequence charSequence) {
        Editable text = this.f927q.getText();
        this.f916P = text;
        TextUtils.isEmpty(text);
        this.f932v.setVisibility(8);
        this.f934x.setVisibility(8);
        m1048F();
        this.f930t.setVisibility(8);
        this.f915O = charSequence.toString();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: E */
    public void mo1424E() {
        m1050I(this.f911K);
        post(this.f919a0);
        if (this.f927q.hasFocus()) {
            mo1433y();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: G */
    public void mo1425G() {
        int[] iArr = this.f927q.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.f929s.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.f930t.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    public void clearFocus() {
        this.f913M = true;
        super.clearFocus();
        this.f927q.clearFocus();
        this.f927q.mo1441b(false);
        this.f913M = false;
    }

    /* renamed from: d */
    public void mo942d() {
        if (!this.f917Q) {
            this.f917Q = true;
            int imeOptions = this.f927q.getImeOptions();
            this.f918R = imeOptions;
            this.f927q.setImeOptions(imeOptions | 33554432);
            this.f927q.setText(BuildConfig.FLAVOR);
            m1050I(false);
            this.f927q.requestFocus();
            this.f927q.mo1441b(true);
        }
    }

    /* renamed from: g */
    public void mo943g() {
        this.f927q.setText(BuildConfig.FLAVOR);
        SearchAutoComplete searchAutoComplete = this.f927q;
        searchAutoComplete.setSelection(searchAutoComplete.length());
        this.f916P = BuildConfig.FLAVOR;
        clearFocus();
        m1050I(true);
        this.f927q.setImeOptions(this.f918R);
        this.f917Q = false;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        removeCallbacks(this.f919a0);
        post(this.f920b0);
        super.onDetachedFromWindow();
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (z) {
            SearchAutoComplete searchAutoComplete = this.f927q;
            Rect rect = this.f901A;
            searchAutoComplete.getLocationInWindow(this.f903C);
            getLocationInWindow(this.f904D);
            int[] iArr = this.f903C;
            int i5 = iArr[1];
            int[] iArr2 = this.f904D;
            int i6 = i5 - iArr2[1];
            int i7 = iArr[0] - iArr2[0];
            rect.set(i7, i6, searchAutoComplete.getWidth() + i7, searchAutoComplete.getHeight() + i6);
            Rect rect2 = this.f902B;
            Rect rect3 = this.f901A;
            rect2.set(rect3.left, 0, rect3.right, i4 - i2);
            C0241l lVar = this.f936z;
            if (lVar == null) {
                C0241l lVar2 = new C0241l(this.f902B, this.f901A, this.f927q);
                this.f936z = lVar2;
                setTouchDelegate(lVar2);
                return;
            }
            lVar.mo1469a(this.f902B, this.f901A);
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0020, code lost:
        if (r0 <= 0) goto L_0x004a;
     */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0057  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0067  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r5, int r6) {
        /*
            r4 = this;
            boolean r0 = r4.f911K
            if (r0 == 0) goto L_0x0008
            super.onMeasure(r5, r6)
            return
        L_0x0008:
            int r0 = android.view.View.MeasureSpec.getMode(r5)
            int r5 = android.view.View.MeasureSpec.getSize(r5)
            r1 = 2131165239(0x7f070037, float:1.794469E38)
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = 1073741824(0x40000000, float:2.0)
            if (r0 == r2) goto L_0x0035
            if (r0 == 0) goto L_0x0023
            if (r0 == r3) goto L_0x001e
            goto L_0x004a
        L_0x001e:
            int r0 = r4.f914N
            if (r0 <= 0) goto L_0x004a
            goto L_0x0046
        L_0x0023:
            int r5 = r4.f914N
            if (r5 <= 0) goto L_0x0028
            goto L_0x004a
        L_0x0028:
            android.content.Context r5 = r4.getContext()
            android.content.res.Resources r5 = r5.getResources()
            int r5 = r5.getDimensionPixelSize(r1)
            goto L_0x004a
        L_0x0035:
            int r0 = r4.f914N
            if (r0 <= 0) goto L_0x003a
            goto L_0x0046
        L_0x003a:
            android.content.Context r0 = r4.getContext()
            android.content.res.Resources r0 = r0.getResources()
            int r0 = r0.getDimensionPixelSize(r1)
        L_0x0046:
            int r5 = java.lang.Math.min(r0, r5)
        L_0x004a:
            int r0 = android.view.View.MeasureSpec.getMode(r6)
            int r6 = android.view.View.MeasureSpec.getSize(r6)
            r1 = 2131165238(0x7f070036, float:1.7944687E38)
            if (r0 == r2) goto L_0x0067
            if (r0 == 0) goto L_0x005a
            goto L_0x0077
        L_0x005a:
            android.content.Context r6 = r4.getContext()
            android.content.res.Resources r6 = r6.getResources()
            int r6 = r6.getDimensionPixelSize(r1)
            goto L_0x0077
        L_0x0067:
            android.content.Context r0 = r4.getContext()
            android.content.res.Resources r0 = r0.getResources()
            int r0 = r0.getDimensionPixelSize(r1)
            int r6 = java.lang.Math.min(r0, r6)
        L_0x0077:
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r3)
            int r6 = android.view.View.MeasureSpec.makeMeasureSpec(r6, r3)
            super.onMeasure(r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.onMeasure(int, int):void");
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.mo2467a());
        m1050I(savedState.f937c);
        requestLayout();
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.f937c = this.f911K;
        return savedState;
    }

    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        post(this.f919a0);
    }

    public boolean requestFocus(int i, Rect rect) {
        if (this.f913M || !isFocusable()) {
            return false;
        }
        if (this.f911K) {
            return super.requestFocus(i, rect);
        }
        boolean requestFocus = this.f927q.requestFocus(i, rect);
        if (requestFocus) {
            m1050I(false);
        }
        return requestFocus;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: x */
    public void mo1432x() {
        if (this.f935y.getWidth() > 1) {
            Resources resources = getContext().getResources();
            int paddingLeft = this.f929s.getPaddingLeft();
            Rect rect = new Rect();
            boolean b = C0280l0.m1310b(this);
            int dimensionPixelSize = this.f910J ? resources.getDimensionPixelSize(R.dimen.abc_dropdownitem_text_padding_left) + resources.getDimensionPixelSize(R.dimen.abc_dropdownitem_icon_width) : 0;
            this.f927q.getDropDownBackground().getPadding(rect);
            this.f927q.setDropDownHorizontalOffset(b ? -rect.left : paddingLeft - (rect.left + dimensionPixelSize));
            this.f927q.setDropDownWidth((((this.f935y.getWidth() + rect.left) + rect.right) + dimensionPixelSize) - paddingLeft);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: y */
    public void mo1433y() {
        if (Build.VERSION.SDK_INT >= 29) {
            this.f927q.refreshAutoCompleteResults();
            return;
        }
        C0240k kVar = f900p;
        kVar.mo1467b(this.f927q);
        kVar.mo1466a(this.f927q);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: z */
    public void mo1434z() {
        if (!TextUtils.isEmpty(this.f927q.getText())) {
            this.f927q.setText(BuildConfig.FLAVOR);
            this.f927q.requestFocus();
            this.f927q.mo1441b(true);
        } else if (this.f910J) {
            clearFocus();
            m1050I(true);
        }
    }
}
