package androidx.appcompat.widget;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Property;
import android.view.ActionMode;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import androidx.core.graphics.drawable.C0487a;
import androidx.core.widget.C0502c;
import com.vidio.android.p195tv.R;
import p098d.p099a.C4568b;
import p098d.p099a.p105f.C4587a;
import p098d.p120g.p130j.C4761m;

public class SwitchCompat extends CompoundButton {

    /* renamed from: a */
    private static final Property<SwitchCompat, Float> f962a = new C0242a(Float.class, "thumbPos");

    /* renamed from: b */
    private static final int[] f963b = {16842912};

    /* renamed from: A */
    private int f964A;

    /* renamed from: B */
    private int f965B;

    /* renamed from: C */
    private int f966C;

    /* renamed from: D */
    private int f967D;

    /* renamed from: E */
    private int f968E;

    /* renamed from: F */
    private int f969F;

    /* renamed from: G */
    private int f970G;

    /* renamed from: H */
    private final TextPaint f971H;

    /* renamed from: I */
    private ColorStateList f972I;

    /* renamed from: J */
    private Layout f973J;

    /* renamed from: K */
    private Layout f974K;

    /* renamed from: L */
    private TransformationMethod f975L;

    /* renamed from: M */
    ObjectAnimator f976M;

    /* renamed from: N */
    private final C0273k f977N;

    /* renamed from: O */
    private final Rect f978O;

    /* renamed from: c */
    private Drawable f979c;

    /* renamed from: d */
    private ColorStateList f980d;

    /* renamed from: e */
    private PorterDuff.Mode f981e;

    /* renamed from: f */
    private boolean f982f;

    /* renamed from: g */
    private boolean f983g;

    /* renamed from: h */
    private Drawable f984h;

    /* renamed from: i */
    private ColorStateList f985i;

    /* renamed from: j */
    private PorterDuff.Mode f986j;

    /* renamed from: k */
    private boolean f987k;

    /* renamed from: l */
    private boolean f988l;

    /* renamed from: m */
    private int f989m;

    /* renamed from: n */
    private int f990n;

    /* renamed from: o */
    private int f991o;

    /* renamed from: p */
    private boolean f992p;

    /* renamed from: q */
    private CharSequence f993q;

    /* renamed from: r */
    private CharSequence f994r;

    /* renamed from: s */
    private boolean f995s;

    /* renamed from: t */
    private int f996t;

    /* renamed from: u */
    private int f997u;

    /* renamed from: v */
    private float f998v;

    /* renamed from: w */
    private float f999w;

    /* renamed from: x */
    private VelocityTracker f1000x;

    /* renamed from: y */
    private int f1001y;

    /* renamed from: z */
    float f1002z;

    /* renamed from: androidx.appcompat.widget.SwitchCompat$a */
    class C0242a extends Property<SwitchCompat, Float> {
        C0242a(Class cls, String str) {
            super(cls, str);
        }

        public Object get(Object obj) {
            return Float.valueOf(((SwitchCompat) obj).f1002z);
        }

        public void set(Object obj, Object obj2) {
            SwitchCompat switchCompat = (SwitchCompat) obj;
            switchCompat.f1002z = ((Float) obj2).floatValue();
            switchCompat.invalidate();
        }
    }

    public SwitchCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.switchStyle);
    }

    public SwitchCompat(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Typeface typeface;
        C4587a aVar = null;
        this.f980d = null;
        this.f981e = null;
        this.f982f = false;
        this.f983g = false;
        this.f985i = null;
        this.f986j = null;
        this.f987k = false;
        this.f988l = false;
        this.f1000x = VelocityTracker.obtain();
        this.f978O = new Rect();
        C0306z.m1392a(this, getContext());
        boolean z = true;
        TextPaint textPaint = new TextPaint(1);
        this.f971H = textPaint;
        textPaint.density = getResources().getDisplayMetrics().density;
        int[] iArr = C4568b.f16476x;
        C0259e0 v = C0259e0.m1181v(context, attributeSet, iArr, i, 0);
        C4761m.m17309r(this, context, iArr, attributeSet, v.mo1607r(), i, 0);
        Drawable g = v.mo1596g(2);
        this.f979c = g;
        if (g != null) {
            g.setCallback(this);
        }
        Drawable g2 = v.mo1596g(11);
        this.f984h = g2;
        if (g2 != null) {
            g2.setCallback(this);
        }
        this.f993q = v.mo1605p(0);
        this.f994r = v.mo1605p(1);
        this.f995s = v.mo1590a(3, true);
        this.f989m = v.mo1595f(8, 0);
        this.f990n = v.mo1595f(5, 0);
        this.f991o = v.mo1595f(6, 0);
        this.f992p = v.mo1590a(4, false);
        ColorStateList c = v.mo1592c(9);
        if (c != null) {
            this.f980d = c;
            this.f982f = true;
        }
        PorterDuff.Mode d = C0284o.m1347d(v.mo1600k(10, -1), (PorterDuff.Mode) null);
        if (this.f981e != d) {
            this.f981e = d;
            this.f983g = true;
        }
        if (this.f982f || this.f983g) {
            m1071a();
        }
        ColorStateList c2 = v.mo1592c(12);
        if (c2 != null) {
            this.f985i = c2;
            this.f987k = true;
        }
        PorterDuff.Mode d2 = C0284o.m1347d(v.mo1600k(13, -1), (PorterDuff.Mode) null);
        if (this.f986j != d2) {
            this.f986j = d2;
            this.f988l = true;
        }
        if (this.f987k || this.f988l) {
            m1072b();
        }
        int n = v.mo1603n(7, 0);
        if (n != 0) {
            C0259e0 t = C0259e0.m1179t(context, n, C4568b.f16477y);
            ColorStateList c3 = t.mo1592c(3);
            this.f972I = c3 == null ? getTextColors() : c3;
            int f = t.mo1595f(0, 0);
            if (f != 0) {
                float f2 = (float) f;
                if (f2 != textPaint.getTextSize()) {
                    textPaint.setTextSize(f2);
                    requestLayout();
                }
            }
            int k = t.mo1600k(1, -1);
            int k2 = t.mo1600k(2, -1);
            if (k != 1) {
                typeface = k != 2 ? k != 3 ? null : Typeface.MONOSPACE : Typeface.SERIF;
            } else {
                typeface = Typeface.SANS_SERIF;
            }
            float f3 = 0.0f;
            if (k2 > 0) {
                Typeface defaultFromStyle = typeface == null ? Typeface.defaultFromStyle(k2) : Typeface.create(typeface, k2);
                mo1478h(defaultFromStyle);
                int i2 = (~(defaultFromStyle != null ? defaultFromStyle.getStyle() : 0)) & k2;
                textPaint.setFakeBoldText((i2 & 1) == 0 ? false : z);
                textPaint.setTextSkewX((i2 & 2) != 0 ? -0.25f : f3);
            } else {
                textPaint.setFakeBoldText(false);
                textPaint.setTextSkewX(0.0f);
                mo1478h(typeface);
            }
            this.f975L = t.mo1590a(14, false) ? new C4587a(getContext()) : aVar;
            t.mo1609w();
        }
        C0273k kVar = new C0273k(this);
        this.f977N = kVar;
        kVar.mo1670m(attributeSet, i);
        v.mo1609w();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f997u = viewConfiguration.getScaledTouchSlop();
        this.f1001y = viewConfiguration.getScaledMinimumFlingVelocity();
        refreshDrawableState();
        setChecked(isChecked());
    }

    /* renamed from: a */
    private void m1071a() {
        Drawable drawable = this.f979c;
        if (drawable == null) {
            return;
        }
        if (this.f982f || this.f983g) {
            Drawable mutate = C0487a.m2226h(drawable).mutate();
            this.f979c = mutate;
            if (this.f982f) {
                mutate.setTintList(this.f980d);
            }
            if (this.f983g) {
                this.f979c.setTintMode(this.f981e);
            }
            if (this.f979c.isStateful()) {
                this.f979c.setState(getDrawableState());
            }
        }
    }

    /* renamed from: b */
    private void m1072b() {
        Drawable drawable = this.f984h;
        if (drawable == null) {
            return;
        }
        if (this.f987k || this.f988l) {
            Drawable mutate = C0487a.m2226h(drawable).mutate();
            this.f984h = mutate;
            if (this.f987k) {
                mutate.setTintList(this.f985i);
            }
            if (this.f988l) {
                this.f984h.setTintMode(this.f986j);
            }
            if (this.f984h.isStateful()) {
                this.f984h.setState(getDrawableState());
            }
        }
    }

    /* renamed from: c */
    private int m1073c() {
        return (int) (((C0280l0.m1310b(this) ? 1.0f - this.f1002z : this.f1002z) * ((float) m1074d())) + 0.5f);
    }

    /* renamed from: d */
    private int m1074d() {
        Drawable drawable = this.f984h;
        if (drawable == null) {
            return 0;
        }
        Rect rect = this.f978O;
        drawable.getPadding(rect);
        Drawable drawable2 = this.f979c;
        Rect c = drawable2 != null ? C0284o.m1346c(drawable2) : C0284o.f1189c;
        return ((((this.f964A - this.f966C) - rect.left) - rect.right) - c.left) - c.right;
    }

    /* renamed from: g */
    private Layout m1075g(CharSequence charSequence) {
        TransformationMethod transformationMethod = this.f975L;
        if (transformationMethod != null) {
            charSequence = transformationMethod.getTransformation(charSequence, this);
        }
        CharSequence charSequence2 = charSequence;
        TextPaint textPaint = this.f971H;
        return new StaticLayout(charSequence2, textPaint, charSequence2 != null ? (int) Math.ceil((double) Layout.getDesiredWidth(charSequence2, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
    }

    public void draw(Canvas canvas) {
        int i;
        int i2;
        Rect rect = this.f978O;
        int i3 = this.f967D;
        int i4 = this.f968E;
        int i5 = this.f969F;
        int i6 = this.f970G;
        int c = m1073c() + i3;
        Drawable drawable = this.f979c;
        Rect c2 = drawable != null ? C0284o.m1346c(drawable) : C0284o.f1189c;
        Drawable drawable2 = this.f984h;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            int i7 = rect.left;
            c += i7;
            if (c2 != null) {
                int i8 = c2.left;
                if (i8 > i7) {
                    i3 += i8 - i7;
                }
                int i9 = c2.top;
                int i10 = rect.top;
                i = i9 > i10 ? (i9 - i10) + i4 : i4;
                int i11 = c2.right;
                int i12 = rect.right;
                if (i11 > i12) {
                    i5 -= i11 - i12;
                }
                int i13 = c2.bottom;
                int i14 = rect.bottom;
                if (i13 > i14) {
                    i2 = i6 - (i13 - i14);
                    this.f984h.setBounds(i3, i, i5, i2);
                }
            } else {
                i = i4;
            }
            i2 = i6;
            this.f984h.setBounds(i3, i, i5, i2);
        }
        Drawable drawable3 = this.f979c;
        if (drawable3 != null) {
            drawable3.getPadding(rect);
            int i15 = c - rect.left;
            int i16 = c + this.f966C + rect.right;
            this.f979c.setBounds(i15, i4, i16, i6);
            Drawable background = getBackground();
            if (background != null) {
                background.setHotspotBounds(i15, i4, i16, i6);
            }
        }
        super.draw(canvas);
    }

    public void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        Drawable drawable = this.f979c;
        if (drawable != null) {
            drawable.setHotspot(f, f2);
        }
        Drawable drawable2 = this.f984h;
        if (drawable2 != null) {
            drawable2.setHotspot(f, f2);
        }
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f979c;
        boolean z = false;
        if (drawable != null && drawable.isStateful()) {
            z = false | drawable.setState(drawableState);
        }
        Drawable drawable2 = this.f984h;
        if (drawable2 != null && drawable2.isStateful()) {
            z |= drawable2.setState(drawableState);
        }
        if (z) {
            invalidate();
        }
    }

    /* renamed from: e */
    public ColorStateList mo1474e() {
        return this.f980d;
    }

    /* renamed from: f */
    public ColorStateList mo1475f() {
        return this.f985i;
    }

    public int getCompoundPaddingLeft() {
        if (!C0280l0.m1310b(this)) {
            return super.getCompoundPaddingLeft();
        }
        int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.f964A;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingLeft + this.f991o : compoundPaddingLeft;
    }

    public int getCompoundPaddingRight() {
        if (C0280l0.m1310b(this)) {
            return super.getCompoundPaddingRight();
        }
        int compoundPaddingRight = super.getCompoundPaddingRight() + this.f964A;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingRight + this.f991o : compoundPaddingRight;
    }

    /* renamed from: h */
    public void mo1478h(Typeface typeface) {
        if ((this.f971H.getTypeface() != null && !this.f971H.getTypeface().equals(typeface)) || (this.f971H.getTypeface() == null && typeface != null)) {
            this.f971H.setTypeface(typeface);
            requestLayout();
            invalidate();
        }
    }

    /* renamed from: i */
    public void mo1479i(CharSequence charSequence) {
        this.f994r = charSequence;
        requestLayout();
    }

    /* renamed from: j */
    public void mo1480j(CharSequence charSequence) {
        this.f993q = charSequence;
        requestLayout();
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f979c;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f984h;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.f976M;
        if (objectAnimator != null && objectAnimator.isStarted()) {
            this.f976M.end();
            this.f976M = null;
        }
    }

    /* renamed from: k */
    public void mo1482k(ColorStateList colorStateList) {
        this.f980d = colorStateList;
        this.f982f = true;
        m1071a();
    }

    /* renamed from: l */
    public void mo1483l(ColorStateList colorStateList) {
        this.f985i = colorStateList;
        this.f987k = true;
        m1072b();
    }

    /* access modifiers changed from: protected */
    public int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        if (isChecked()) {
            CompoundButton.mergeDrawableStates(onCreateDrawableState, f963b);
        }
        return onCreateDrawableState;
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        int i;
        super.onDraw(canvas);
        Rect rect = this.f978O;
        Drawable drawable = this.f984h;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i2 = this.f968E;
        int i3 = this.f970G;
        int i4 = i2 + rect.top;
        int i5 = i3 - rect.bottom;
        Drawable drawable2 = this.f979c;
        if (drawable != null) {
            if (!this.f992p || drawable2 == null) {
                drawable.draw(canvas);
            } else {
                Rect c = C0284o.m1346c(drawable2);
                drawable2.copyBounds(rect);
                rect.left += c.left;
                rect.right -= c.right;
                int save = canvas.save();
                canvas.clipRect(rect, Region.Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(save);
            }
        }
        int save2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        Layout layout = (this.f1002z > 0.5f ? 1 : (this.f1002z == 0.5f ? 0 : -1)) > 0 ? this.f973J : this.f974K;
        if (layout != null) {
            int[] drawableState = getDrawableState();
            ColorStateList colorStateList = this.f972I;
            if (colorStateList != null) {
                this.f971H.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            this.f971H.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                i = bounds.left + bounds.right;
            } else {
                i = getWidth();
            }
            canvas.translate((float) ((i / 2) - (layout.getWidth() / 2)), (float) (((i4 + i5) / 2) - (layout.getHeight() / 2)));
            layout.draw(canvas);
        }
        canvas.restoreToCount(save2);
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
        CharSequence charSequence = isChecked() ? this.f993q : this.f994r;
        if (!TextUtils.isEmpty(charSequence)) {
            CharSequence text = accessibilityNodeInfo.getText();
            if (TextUtils.isEmpty(text)) {
                accessibilityNodeInfo.setText(charSequence);
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append(text);
            sb.append(' ');
            sb.append(charSequence);
            accessibilityNodeInfo.setText(sb);
        }
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        super.onLayout(z, i, i2, i3, i4);
        int i10 = 0;
        if (this.f979c != null) {
            Rect rect = this.f978O;
            Drawable drawable = this.f984h;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect c = C0284o.m1346c(this.f979c);
            i5 = Math.max(0, c.left - rect.left);
            i10 = Math.max(0, c.right - rect.right);
        } else {
            i5 = 0;
        }
        if (C0280l0.m1310b(this)) {
            i7 = getPaddingLeft() + i5;
            i6 = ((this.f964A + i7) - i5) - i10;
        } else {
            i6 = (getWidth() - getPaddingRight()) - i10;
            i7 = (i6 - this.f964A) + i5 + i10;
        }
        int gravity = getGravity() & 112;
        if (gravity == 16) {
            int paddingTop = getPaddingTop();
            int i11 = this.f965B;
            int height = (((getHeight() + paddingTop) - getPaddingBottom()) / 2) - (i11 / 2);
            int i12 = height;
            i8 = i11 + height;
            i9 = i12;
        } else if (gravity != 80) {
            i9 = getPaddingTop();
            i8 = this.f965B + i9;
        } else {
            i8 = getHeight() - getPaddingBottom();
            i9 = i8 - this.f965B;
        }
        this.f967D = i7;
        this.f968E = i9;
        this.f970G = i8;
        this.f969F = i6;
    }

    public void onMeasure(int i, int i2) {
        int i3;
        int i4;
        int i5;
        if (this.f995s) {
            if (this.f973J == null) {
                this.f973J = m1075g(this.f993q);
            }
            if (this.f974K == null) {
                this.f974K = m1075g(this.f994r);
            }
        }
        Rect rect = this.f978O;
        Drawable drawable = this.f979c;
        int i6 = 0;
        if (drawable != null) {
            drawable.getPadding(rect);
            i4 = (this.f979c.getIntrinsicWidth() - rect.left) - rect.right;
            i3 = this.f979c.getIntrinsicHeight();
        } else {
            i4 = 0;
            i3 = 0;
        }
        if (this.f995s) {
            i5 = (this.f989m * 2) + Math.max(this.f973J.getWidth(), this.f974K.getWidth());
        } else {
            i5 = 0;
        }
        this.f966C = Math.max(i5, i4);
        Drawable drawable2 = this.f984h;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            i6 = this.f984h.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        int i7 = rect.left;
        int i8 = rect.right;
        Drawable drawable3 = this.f979c;
        if (drawable3 != null) {
            Rect c = C0284o.m1346c(drawable3);
            i7 = Math.max(i7, c.left);
            i8 = Math.max(i8, c.right);
        }
        int max = Math.max(this.f990n, (this.f966C * 2) + i7 + i8);
        int max2 = Math.max(i6, i3);
        this.f964A = max;
        this.f965B = max2;
        super.onMeasure(i, i2);
        if (getMeasuredHeight() < max2) {
            setMeasuredDimension(getMeasuredWidthAndState(), max2);
        }
    }

    public void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        CharSequence charSequence = isChecked() ? this.f993q : this.f994r;
        if (charSequence != null) {
            accessibilityEvent.getText().add(charSequence);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0014, code lost:
        if (r0 != 3) goto L_0x0159;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r11) {
        /*
            r10 = this;
            android.view.VelocityTracker r0 = r10.f1000x
            r0.addMovement(r11)
            int r0 = r11.getActionMasked()
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x0106
            r3 = 3
            r4 = 0
            r5 = 2
            if (r0 == r2) goto L_0x0095
            if (r0 == r5) goto L_0x0018
            if (r0 == r3) goto L_0x0095
            goto L_0x0159
        L_0x0018:
            int r0 = r10.f996t
            if (r0 == r2) goto L_0x0061
            if (r0 == r5) goto L_0x0020
            goto L_0x0159
        L_0x0020:
            float r11 = r11.getX()
            int r0 = r10.m1074d()
            float r1 = r10.f998v
            float r1 = r11 - r1
            r3 = 1065353216(0x3f800000, float:1.0)
            if (r0 == 0) goto L_0x0033
            float r0 = (float) r0
            float r1 = r1 / r0
            goto L_0x003e
        L_0x0033:
            int r0 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r0 <= 0) goto L_0x003a
            r1 = 1065353216(0x3f800000, float:1.0)
            goto L_0x003e
        L_0x003a:
            r0 = -1082130432(0xffffffffbf800000, float:-1.0)
            r1 = -1082130432(0xffffffffbf800000, float:-1.0)
        L_0x003e:
            boolean r0 = androidx.appcompat.widget.C0280l0.m1310b(r10)
            if (r0 == 0) goto L_0x0045
            float r1 = -r1
        L_0x0045:
            float r0 = r10.f1002z
            float r1 = r1 + r0
            int r5 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r5 >= 0) goto L_0x004d
            goto L_0x0055
        L_0x004d:
            int r4 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r4 <= 0) goto L_0x0054
            r4 = 1065353216(0x3f800000, float:1.0)
            goto L_0x0055
        L_0x0054:
            r4 = r1
        L_0x0055:
            int r0 = (r4 > r0 ? 1 : (r4 == r0 ? 0 : -1))
            if (r0 == 0) goto L_0x0060
            r10.f998v = r11
            r10.f1002z = r4
            r10.invalidate()
        L_0x0060:
            return r2
        L_0x0061:
            float r0 = r11.getX()
            float r1 = r11.getY()
            float r3 = r10.f998v
            float r3 = r0 - r3
            float r3 = java.lang.Math.abs(r3)
            int r4 = r10.f997u
            float r4 = (float) r4
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 > 0) goto L_0x0087
            float r3 = r10.f999w
            float r3 = r1 - r3
            float r3 = java.lang.Math.abs(r3)
            int r4 = r10.f997u
            float r4 = (float) r4
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L_0x0159
        L_0x0087:
            r10.f996t = r5
            android.view.ViewParent r11 = r10.getParent()
            r11.requestDisallowInterceptTouchEvent(r2)
            r10.f998v = r0
            r10.f999w = r1
            return r2
        L_0x0095:
            int r0 = r10.f996t
            if (r0 != r5) goto L_0x00fe
            r10.f996t = r1
            int r0 = r11.getAction()
            if (r0 != r2) goto L_0x00a9
            boolean r0 = r10.isEnabled()
            if (r0 == 0) goto L_0x00a9
            r0 = 1
            goto L_0x00aa
        L_0x00a9:
            r0 = 0
        L_0x00aa:
            boolean r5 = r10.isChecked()
            if (r0 == 0) goto L_0x00e4
            android.view.VelocityTracker r0 = r10.f1000x
            r6 = 1000(0x3e8, float:1.401E-42)
            r0.computeCurrentVelocity(r6)
            android.view.VelocityTracker r0 = r10.f1000x
            float r0 = r0.getXVelocity()
            float r6 = java.lang.Math.abs(r0)
            int r7 = r10.f1001y
            float r7 = (float) r7
            int r6 = (r6 > r7 ? 1 : (r6 == r7 ? 0 : -1))
            if (r6 <= 0) goto L_0x00d8
            boolean r6 = androidx.appcompat.widget.C0280l0.m1310b(r10)
            if (r6 == 0) goto L_0x00d3
            int r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
            if (r0 >= 0) goto L_0x00e2
            goto L_0x00e0
        L_0x00d3:
            int r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
            if (r0 <= 0) goto L_0x00e2
            goto L_0x00e0
        L_0x00d8:
            float r0 = r10.f1002z
            r4 = 1056964608(0x3f000000, float:0.5)
            int r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
            if (r0 <= 0) goto L_0x00e2
        L_0x00e0:
            r0 = 1
            goto L_0x00e5
        L_0x00e2:
            r0 = 0
            goto L_0x00e5
        L_0x00e4:
            r0 = r5
        L_0x00e5:
            if (r0 == r5) goto L_0x00ea
            r10.playSoundEffect(r1)
        L_0x00ea:
            r10.setChecked(r0)
            android.view.MotionEvent r0 = android.view.MotionEvent.obtain(r11)
            r0.setAction(r3)
            super.onTouchEvent(r0)
            r0.recycle()
            super.onTouchEvent(r11)
            return r2
        L_0x00fe:
            r10.f996t = r1
            android.view.VelocityTracker r0 = r10.f1000x
            r0.clear()
            goto L_0x0159
        L_0x0106:
            float r0 = r11.getX()
            float r3 = r11.getY()
            boolean r4 = r10.isEnabled()
            if (r4 == 0) goto L_0x0159
            android.graphics.drawable.Drawable r4 = r10.f979c
            if (r4 != 0) goto L_0x0119
            goto L_0x0151
        L_0x0119:
            int r4 = r10.m1073c()
            android.graphics.drawable.Drawable r5 = r10.f979c
            android.graphics.Rect r6 = r10.f978O
            r5.getPadding(r6)
            int r5 = r10.f968E
            int r6 = r10.f997u
            int r5 = r5 - r6
            int r7 = r10.f967D
            int r7 = r7 + r4
            int r7 = r7 - r6
            int r4 = r10.f966C
            int r4 = r4 + r7
            android.graphics.Rect r8 = r10.f978O
            int r9 = r8.left
            int r4 = r4 + r9
            int r8 = r8.right
            int r4 = r4 + r8
            int r4 = r4 + r6
            int r8 = r10.f970G
            int r8 = r8 + r6
            float r6 = (float) r7
            int r6 = (r0 > r6 ? 1 : (r0 == r6 ? 0 : -1))
            if (r6 <= 0) goto L_0x0151
            float r4 = (float) r4
            int r4 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
            if (r4 >= 0) goto L_0x0151
            float r4 = (float) r5
            int r4 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r4 <= 0) goto L_0x0151
            float r4 = (float) r8
            int r4 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r4 >= 0) goto L_0x0151
            r1 = 1
        L_0x0151:
            if (r1 == 0) goto L_0x0159
            r10.f996t = r2
            r10.f998v = r0
            r10.f999w = r3
        L_0x0159:
            boolean r11 = super.onTouchEvent(r11)
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SwitchCompat.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void setChecked(boolean z) {
        super.setChecked(z);
        boolean isChecked = isChecked();
        float f = 1.0f;
        if (getWindowToken() != null) {
            int i = C4761m.f17241f;
            if (isLaidOut()) {
                if (!isChecked) {
                    f = 0.0f;
                }
                ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, f962a, new float[]{f});
                this.f976M = ofFloat;
                ofFloat.setDuration(250);
                this.f976M.setAutoCancel(true);
                this.f976M.start();
                return;
            }
        }
        ObjectAnimator objectAnimator = this.f976M;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
        if (!isChecked) {
            f = 0.0f;
        }
        this.f1002z = f;
        invalidate();
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C0502c.m2298h(this, callback));
    }

    public void toggle() {
        setChecked(!isChecked());
    }

    /* access modifiers changed from: protected */
    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f979c || drawable == this.f984h;
    }
}
