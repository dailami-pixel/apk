package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.view.menu.C0163g;
import androidx.appcompat.view.menu.C0167i;
import androidx.appcompat.view.menu.C0178m;
import androidx.appcompat.view.menu.C0187r;
import androidx.appcompat.widget.ActionMenuView;
import androidx.customview.view.AbsSavedState;
import androidx.recyclerview.widget.RecyclerView;
import com.vidio.android.p195tv.R;
import java.util.ArrayList;
import java.util.List;
import p098d.p099a.C4568b;
import p098d.p099a.p106g.C4591c;
import p098d.p099a.p106g.C4596g;
import p098d.p120g.p130j.C4761m;

public class Toolbar extends ViewGroup {

    /* renamed from: A */
    private ColorStateList f1003A;

    /* renamed from: B */
    private boolean f1004B;

    /* renamed from: C */
    private boolean f1005C;

    /* renamed from: D */
    private final ArrayList<View> f1006D;

    /* renamed from: E */
    private final ArrayList<View> f1007E;

    /* renamed from: F */
    private final int[] f1008F;

    /* renamed from: G */
    private final ActionMenuView.C0205d f1009G;

    /* renamed from: H */
    private C0263g0 f1010H;

    /* renamed from: I */
    private ActionMenuPresenter f1011I;

    /* renamed from: J */
    private C0247d f1012J;

    /* renamed from: K */
    private boolean f1013K;

    /* renamed from: L */
    private final Runnable f1014L;

    /* renamed from: a */
    private ActionMenuView f1015a;

    /* renamed from: b */
    private TextView f1016b;

    /* renamed from: c */
    private TextView f1017c;

    /* renamed from: d */
    private ImageButton f1018d;

    /* renamed from: e */
    private ImageView f1019e;

    /* renamed from: f */
    private Drawable f1020f;

    /* renamed from: g */
    private CharSequence f1021g;

    /* renamed from: h */
    ImageButton f1022h;

    /* renamed from: i */
    View f1023i;

    /* renamed from: j */
    private Context f1024j;

    /* renamed from: k */
    private int f1025k;

    /* renamed from: l */
    private int f1026l;

    /* renamed from: m */
    private int f1027m;

    /* renamed from: n */
    int f1028n;

    /* renamed from: o */
    private int f1029o;

    /* renamed from: p */
    private int f1030p;

    /* renamed from: q */
    private int f1031q;

    /* renamed from: r */
    private int f1032r;

    /* renamed from: s */
    private int f1033s;

    /* renamed from: t */
    private C0304x f1034t;

    /* renamed from: u */
    private int f1035u;

    /* renamed from: v */
    private int f1036v;

    /* renamed from: w */
    private int f1037w;

    /* renamed from: x */
    private CharSequence f1038x;

    /* renamed from: y */
    private CharSequence f1039y;

    /* renamed from: z */
    private ColorStateList f1040z;

    public static class LayoutParams extends ActionBar.LayoutParams {

        /* renamed from: b */
        int f1041b = 0;

        public LayoutParams(int i, int i2) {
            super(i, i2);
            this.f211a = 8388627;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super((ViewGroup.LayoutParams) marginLayoutParams);
            this.leftMargin = marginLayoutParams.leftMargin;
            this.topMargin = marginLayoutParams.topMargin;
            this.rightMargin = marginLayoutParams.rightMargin;
            this.bottomMargin = marginLayoutParams.bottomMargin;
        }

        public LayoutParams(ActionBar.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(LayoutParams layoutParams) {
            super((ActionBar.LayoutParams) layoutParams);
            this.f1041b = layoutParams.f1041b;
        }
    }

    public static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0243a();

        /* renamed from: c */
        int f1042c;

        /* renamed from: d */
        boolean f1043d;

        /* renamed from: androidx.appcompat.widget.Toolbar$SavedState$a */
        class C0243a implements Parcelable.ClassLoaderCreator<SavedState> {
            C0243a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new SavedState[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f1042c = parcel.readInt();
            this.f1043d = parcel.readInt() != 0;
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f1042c);
            parcel.writeInt(this.f1043d ? 1 : 0);
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$a */
    class C0244a implements ActionMenuView.C0205d {
        C0244a() {
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$b */
    class C0245b implements Runnable {
        C0245b() {
        }

        public void run() {
            Toolbar.this.mo1516Z();
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$c */
    class C0246c implements View.OnClickListener {
        C0246c() {
        }

        public void onClick(View view) {
            Toolbar.this.mo1520f();
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$d */
    private class C0247d implements C0178m {

        /* renamed from: a */
        C0163g f1047a;

        /* renamed from: b */
        C0167i f1048b;

        C0247d() {
        }

        /* renamed from: b */
        public void mo691b(C0163g gVar, boolean z) {
        }

        /* renamed from: c */
        public void mo692c(boolean z) {
            if (this.f1048b != null) {
                C0163g gVar = this.f1047a;
                boolean z2 = false;
                if (gVar != null) {
                    int size = gVar.size();
                    int i = 0;
                    while (true) {
                        if (i >= size) {
                            break;
                        } else if (this.f1047a.getItem(i) == this.f1048b) {
                            z2 = true;
                            break;
                        } else {
                            i++;
                        }
                    }
                }
                if (!z2) {
                    mo693e(this.f1047a, this.f1048b);
                }
            }
        }

        /* renamed from: d */
        public boolean mo711d() {
            return false;
        }

        /* renamed from: e */
        public boolean mo693e(C0163g gVar, C0167i iVar) {
            View view = Toolbar.this.f1023i;
            if (view instanceof C4591c) {
                ((C4591c) view).mo943g();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.f1023i);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.f1022h);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.f1023i = null;
            toolbar3.mo1517b();
            this.f1048b = null;
            Toolbar.this.requestLayout();
            iVar.mo853p(false);
            return true;
        }

        /* renamed from: f */
        public boolean mo694f(C0163g gVar, C0167i iVar) {
            Toolbar.this.mo1525h();
            ViewParent parent = Toolbar.this.f1022h.getParent();
            Toolbar toolbar = Toolbar.this;
            if (parent != toolbar) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(toolbar.f1022h);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.f1022h);
            }
            Toolbar.this.f1023i = iVar.getActionView();
            this.f1048b = iVar;
            ViewParent parent2 = Toolbar.this.f1023i.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (parent2 != toolbar3) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(toolbar3.f1023i);
                }
                LayoutParams l = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                l.f211a = 8388611 | (toolbar4.f1028n & 112);
                l.f1041b = 2;
                toolbar4.f1023i.setLayoutParams(l);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.f1023i);
            }
            Toolbar.this.mo1503L();
            Toolbar.this.requestLayout();
            iVar.mo853p(true);
            View view = Toolbar.this.f1023i;
            if (view instanceof C4591c) {
                ((C4591c) view).mo942d();
            }
            return true;
        }

        public int getId() {
            return 0;
        }

        /* renamed from: h */
        public void mo697h(Context context, C0163g gVar) {
            C0167i iVar;
            C0163g gVar2 = this.f1047a;
            if (!(gVar2 == null || (iVar = this.f1048b) == null)) {
                gVar2.mo786f(iVar);
            }
            this.f1047a = gVar;
        }

        /* renamed from: i */
        public void mo713i(Parcelable parcelable) {
        }

        /* renamed from: k */
        public boolean mo699k(C0187r rVar) {
            return false;
        }

        /* renamed from: l */
        public Parcelable mo715l() {
            return null;
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.toolbarStyle);
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1037w = 8388627;
        this.f1006D = new ArrayList<>();
        this.f1007E = new ArrayList<>();
        this.f1008F = new int[2];
        this.f1009G = new C0244a();
        this.f1014L = new C0245b();
        Context context2 = getContext();
        int[] iArr = C4568b.f16478z;
        C0259e0 v = C0259e0.m1181v(context2, attributeSet, iArr, i, 0);
        C4761m.m17309r(this, context, iArr, attributeSet, v.mo1607r(), i, 0);
        this.f1026l = v.mo1603n(28, 0);
        this.f1027m = v.mo1603n(19, 0);
        this.f1037w = v.mo1601l(0, this.f1037w);
        this.f1028n = v.mo1601l(2, 48);
        int e = v.mo1594e(22, 0);
        e = v.mo1608s(27) ? v.mo1594e(27, e) : e;
        this.f1033s = e;
        this.f1032r = e;
        this.f1031q = e;
        this.f1030p = e;
        int e2 = v.mo1594e(25, -1);
        if (e2 >= 0) {
            this.f1030p = e2;
        }
        int e3 = v.mo1594e(24, -1);
        if (e3 >= 0) {
            this.f1031q = e3;
        }
        int e4 = v.mo1594e(26, -1);
        if (e4 >= 0) {
            this.f1032r = e4;
        }
        int e5 = v.mo1594e(23, -1);
        if (e5 >= 0) {
            this.f1033s = e5;
        }
        this.f1029o = v.mo1595f(13, -1);
        int e6 = v.mo1594e(9, RecyclerView.UNDEFINED_DURATION);
        int e7 = v.mo1594e(5, RecyclerView.UNDEFINED_DURATION);
        int f = v.mo1595f(7, 0);
        int f2 = v.mo1595f(8, 0);
        m1092i();
        this.f1034t.mo1741c(f, f2);
        if (!(e6 == Integer.MIN_VALUE && e7 == Integer.MIN_VALUE)) {
            this.f1034t.mo1743e(e6, e7);
        }
        this.f1035u = v.mo1594e(10, RecyclerView.UNDEFINED_DURATION);
        this.f1036v = v.mo1594e(6, RecyclerView.UNDEFINED_DURATION);
        this.f1020f = v.mo1596g(4);
        this.f1021g = v.mo1605p(3);
        CharSequence p = v.mo1605p(21);
        if (!TextUtils.isEmpty(p)) {
            mo1514W(p);
        }
        CharSequence p2 = v.mo1605p(18);
        if (!TextUtils.isEmpty(p2)) {
            mo1512U(p2);
        }
        this.f1024j = getContext();
        mo1511T(v.mo1603n(17, 0));
        Drawable g = v.mo1596g(16);
        if (g != null) {
            mo1509R(g);
        }
        CharSequence p3 = v.mo1605p(15);
        if (!TextUtils.isEmpty(p3)) {
            mo1508Q(p3);
        }
        Drawable g2 = v.mo1596g(11);
        if (g2 != null) {
            mo1506O(g2);
        }
        CharSequence p4 = v.mo1605p(12);
        if (!TextUtils.isEmpty(p4)) {
            if (!TextUtils.isEmpty(p4) && this.f1019e == null) {
                this.f1019e = new AppCompatImageView(getContext());
            }
            ImageView imageView = this.f1019e;
            if (imageView != null) {
                imageView.setContentDescription(p4);
            }
        }
        if (v.mo1608s(29)) {
            ColorStateList c = v.mo1592c(29);
            this.f1040z = c;
            TextView textView = this.f1016b;
            if (textView != null) {
                textView.setTextColor(c);
            }
        }
        if (v.mo1608s(20)) {
            ColorStateList c2 = v.mo1592c(20);
            this.f1003A = c2;
            TextView textView2 = this.f1017c;
            if (textView2 != null) {
                textView2.setTextColor(c2);
            }
        }
        if (v.mo1608s(14)) {
            int n = v.mo1603n(14, 0);
            C4596g gVar = new C4596g(getContext());
            m1093j();
            if (this.f1015a.mo1118H() == null) {
                C0163g gVar2 = (C0163g) this.f1015a.mo1112A();
                if (this.f1012J == null) {
                    this.f1012J = new C0247d();
                }
                this.f1015a.mo1119I(true);
                gVar2.mo780c(this.f1012J, this.f1024j);
            }
            gVar.inflate(n, this.f1015a.mo1112A());
        }
        v.mo1609w();
    }

    /* renamed from: A */
    private int m1083A(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    /* renamed from: E */
    private boolean m1084E(View view) {
        return view.getParent() == this || this.f1007E.contains(view);
    }

    /* renamed from: H */
    private int m1085H(View view, int i, int[] iArr, int i2) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int i3 = layoutParams.leftMargin - iArr[0];
        int max = Math.max(0, i3) + i;
        iArr[0] = Math.max(0, -i3);
        int o = m1096o(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, o, max + measuredWidth, view.getMeasuredHeight() + o);
        return measuredWidth + layoutParams.rightMargin + max;
    }

    /* renamed from: I */
    private int m1086I(View view, int i, int[] iArr, int i2) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int i3 = layoutParams.rightMargin - iArr[1];
        int max = i - Math.max(0, i3);
        iArr[1] = Math.max(0, -i3);
        int o = m1096o(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, o, max, view.getMeasuredHeight() + o);
        return max - (measuredWidth + layoutParams.leftMargin);
    }

    /* renamed from: J */
    private int m1087J(View view, int i, int i2, int i3, int i4, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i5 = marginLayoutParams.leftMargin - iArr[0];
        int i6 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i6) + Math.max(0, i5);
        iArr[0] = Math.max(0, -i5);
        iArr[1] = Math.max(0, -i6);
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + max + i2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i3, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i4, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    /* renamed from: K */
    private void m1088K(View view, int i, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i3, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i4, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i5 >= 0) {
            if (mode != 0) {
                i5 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i5);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    /* renamed from: Y */
    private boolean m1089Y(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    /* renamed from: c */
    private void m1090c(List<View> list, int i) {
        int i2 = C4761m.f17241f;
        boolean z = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i, getLayoutDirection());
        list.clear();
        if (z) {
            for (int i3 = childCount - 1; i3 >= 0; i3--) {
                View childAt = getChildAt(i3);
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (layoutParams.f1041b == 0 && m1089Y(childAt) && m1095n(layoutParams.f211a) == absoluteGravity) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i4 = 0; i4 < childCount; i4++) {
            View childAt2 = getChildAt(i4);
            LayoutParams layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
            if (layoutParams2.f1041b == 0 && m1089Y(childAt2) && m1095n(layoutParams2.f211a) == absoluteGravity) {
                list.add(childAt2);
            }
        }
    }

    /* renamed from: d */
    private void m1091d(View view, boolean z) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        LayoutParams l = layoutParams == null ? generateDefaultLayoutParams() : !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : (LayoutParams) layoutParams;
        l.f1041b = 1;
        if (!z || this.f1023i == null) {
            addView(view, l);
            return;
        }
        view.setLayoutParams(l);
        this.f1007E.add(view);
    }

    /* renamed from: i */
    private void m1092i() {
        if (this.f1034t == null) {
            this.f1034t = new C0304x();
        }
    }

    /* renamed from: j */
    private void m1093j() {
        if (this.f1015a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), (AttributeSet) null);
            this.f1015a = actionMenuView;
            actionMenuView.mo1122L(this.f1025k);
            ActionMenuView actionMenuView2 = this.f1015a;
            actionMenuView2.f743A = this.f1009G;
            actionMenuView2.mo1120J((C0178m.C0179a) null, (C0163g.C0164a) null);
            LayoutParams l = generateDefaultLayoutParams();
            l.f211a = 8388613 | (this.f1028n & 112);
            this.f1015a.setLayoutParams(l);
            m1091d(this.f1015a, false);
        }
    }

    /* renamed from: k */
    private void m1094k() {
        if (this.f1018d == null) {
            this.f1018d = new AppCompatImageButton(getContext(), (AttributeSet) null, R.attr.toolbarNavigationButtonStyle);
            LayoutParams l = generateDefaultLayoutParams();
            l.f211a = 8388611 | (this.f1028n & 112);
            this.f1018d.setLayoutParams(l);
        }
    }

    /* renamed from: n */
    private int m1095n(int i) {
        int i2 = C4761m.f17241f;
        int layoutDirection = getLayoutDirection();
        int absoluteGravity = Gravity.getAbsoluteGravity(i, layoutDirection) & 7;
        if (absoluteGravity == 1 || absoluteGravity == 3 || absoluteGravity == 5) {
            return absoluteGravity;
        }
        return layoutDirection == 1 ? 5 : 3;
    }

    /* renamed from: o */
    private int m1096o(View view, int i) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i2 = i > 0 ? (measuredHeight - i) / 2 : 0;
        int i3 = layoutParams.f211a & 112;
        if (!(i3 == 16 || i3 == 48 || i3 == 80)) {
            i3 = this.f1037w & 112;
        }
        if (i3 == 48) {
            return getPaddingTop() - i2;
        }
        if (i3 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - layoutParams.bottomMargin) - i2;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i4 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i5 = layoutParams.topMargin;
        if (i4 < i5) {
            i4 = i5;
        } else {
            int i6 = (((height - paddingBottom) - measuredHeight) - i4) - paddingTop;
            int i7 = layoutParams.bottomMargin;
            if (i6 < i7) {
                i4 = Math.max(0, i4 - (i7 - i6));
            }
        }
        return paddingTop + i4;
    }

    /* renamed from: r */
    private int m1097r(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
    }

    /* renamed from: B */
    public C0283n mo1498B() {
        if (this.f1010H == null) {
            this.f1010H = new C0263g0(this, true);
        }
        return this.f1010H;
    }

    /* renamed from: C */
    public boolean mo1499C() {
        C0247d dVar = this.f1012J;
        return (dVar == null || dVar.f1048b == null) ? false : true;
    }

    /* renamed from: D */
    public boolean mo1500D() {
        ActionMenuView actionMenuView = this.f1015a;
        return actionMenuView != null && actionMenuView.mo1114C();
    }

    /* renamed from: F */
    public boolean mo1501F() {
        ActionMenuView actionMenuView = this.f1015a;
        return actionMenuView != null && actionMenuView.mo1115D();
    }

    /* renamed from: G */
    public boolean mo1502G() {
        ActionMenuView actionMenuView = this.f1015a;
        return actionMenuView != null && actionMenuView.mo1116E();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: L */
    public void mo1503L() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            if (!(((LayoutParams) childAt.getLayoutParams()).f1041b == 2 || childAt == this.f1015a)) {
                removeViewAt(childCount);
                this.f1007E.add(childAt);
            }
        }
    }

    /* renamed from: M */
    public void mo1504M(boolean z) {
        this.f1013K = z;
        requestLayout();
    }

    /* renamed from: N */
    public void mo1505N(int i, int i2) {
        m1092i();
        this.f1034t.mo1743e(i, i2);
    }

    /* renamed from: O */
    public void mo1506O(Drawable drawable) {
        if (drawable != null) {
            if (this.f1019e == null) {
                this.f1019e = new AppCompatImageView(getContext());
            }
            if (!m1084E(this.f1019e)) {
                m1091d(this.f1019e, true);
            }
        } else {
            ImageView imageView = this.f1019e;
            if (imageView != null && m1084E(imageView)) {
                removeView(this.f1019e);
                this.f1007E.remove(this.f1019e);
            }
        }
        ImageView imageView2 = this.f1019e;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    /* renamed from: P */
    public void mo1507P(C0163g gVar, ActionMenuPresenter actionMenuPresenter) {
        C0167i iVar;
        if (gVar != null || this.f1015a != null) {
            m1093j();
            C0163g H = this.f1015a.mo1118H();
            if (H != gVar) {
                if (H != null) {
                    H.mo753B(this.f1011I);
                    H.mo753B(this.f1012J);
                }
                if (this.f1012J == null) {
                    this.f1012J = new C0247d();
                }
                actionMenuPresenter.mo1098C(true);
                if (gVar != null) {
                    gVar.mo780c(actionMenuPresenter, this.f1024j);
                    gVar.mo780c(this.f1012J, this.f1024j);
                } else {
                    actionMenuPresenter.mo697h(this.f1024j, (C0163g) null);
                    C0247d dVar = this.f1012J;
                    C0163g gVar2 = dVar.f1047a;
                    if (!(gVar2 == null || (iVar = dVar.f1048b) == null)) {
                        gVar2.mo786f(iVar);
                    }
                    dVar.f1047a = null;
                    actionMenuPresenter.mo692c(true);
                    this.f1012J.mo692c(true);
                }
                this.f1015a.mo1122L(this.f1025k);
                this.f1015a.mo1123M(actionMenuPresenter);
                this.f1011I = actionMenuPresenter;
            }
        }
    }

    /* renamed from: Q */
    public void mo1508Q(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            m1094k();
        }
        ImageButton imageButton = this.f1018d;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    /* renamed from: R */
    public void mo1509R(Drawable drawable) {
        if (drawable != null) {
            m1094k();
            if (!m1084E(this.f1018d)) {
                m1091d(this.f1018d, true);
            }
        } else {
            ImageButton imageButton = this.f1018d;
            if (imageButton != null && m1084E(imageButton)) {
                removeView(this.f1018d);
                this.f1007E.remove(this.f1018d);
            }
        }
        ImageButton imageButton2 = this.f1018d;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(drawable);
        }
    }

    /* renamed from: S */
    public void mo1510S(View.OnClickListener onClickListener) {
        m1094k();
        this.f1018d.setOnClickListener(onClickListener);
    }

    /* renamed from: T */
    public void mo1511T(int i) {
        if (this.f1025k != i) {
            this.f1025k = i;
            if (i == 0) {
                this.f1024j = getContext();
            } else {
                this.f1024j = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    /* renamed from: U */
    public void mo1512U(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f1017c == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context, (AttributeSet) null);
                this.f1017c = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.f1017c.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.f1027m;
                if (i != 0) {
                    this.f1017c.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.f1003A;
                if (colorStateList != null) {
                    this.f1017c.setTextColor(colorStateList);
                }
            }
            if (!m1084E(this.f1017c)) {
                m1091d(this.f1017c, true);
            }
        } else {
            TextView textView = this.f1017c;
            if (textView != null && m1084E(textView)) {
                removeView(this.f1017c);
                this.f1007E.remove(this.f1017c);
            }
        }
        TextView textView2 = this.f1017c;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.f1039y = charSequence;
    }

    /* renamed from: V */
    public void mo1513V(Context context, int i) {
        this.f1027m = i;
        TextView textView = this.f1017c;
        if (textView != null) {
            textView.setTextAppearance(context, i);
        }
    }

    /* renamed from: W */
    public void mo1514W(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f1016b == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context, (AttributeSet) null);
                this.f1016b = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.f1016b.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.f1026l;
                if (i != 0) {
                    this.f1016b.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.f1040z;
                if (colorStateList != null) {
                    this.f1016b.setTextColor(colorStateList);
                }
            }
            if (!m1084E(this.f1016b)) {
                m1091d(this.f1016b, true);
            }
        } else {
            TextView textView = this.f1016b;
            if (textView != null && m1084E(textView)) {
                removeView(this.f1016b);
                this.f1007E.remove(this.f1016b);
            }
        }
        TextView textView2 = this.f1016b;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.f1038x = charSequence;
    }

    /* renamed from: X */
    public void mo1515X(Context context, int i) {
        this.f1026l = i;
        TextView textView = this.f1016b;
        if (textView != null) {
            textView.setTextAppearance(context, i);
        }
    }

    /* renamed from: Z */
    public boolean mo1516Z() {
        ActionMenuView actionMenuView = this.f1015a;
        return actionMenuView != null && actionMenuView.mo1124N();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo1517b() {
        for (int size = this.f1007E.size() - 1; size >= 0; size--) {
            addView(this.f1007E.get(size));
        }
        this.f1007E.clear();
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof LayoutParams);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r1.f1015a;
     */
    /* renamed from: e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo1519e() {
        /*
            r1 = this;
            int r0 = r1.getVisibility()
            if (r0 != 0) goto L_0x0012
            androidx.appcompat.widget.ActionMenuView r0 = r1.f1015a
            if (r0 == 0) goto L_0x0012
            boolean r0 = r0.mo1117F()
            if (r0 == 0) goto L_0x0012
            r0 = 1
            goto L_0x0013
        L_0x0012:
            r0 = 0
        L_0x0013:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.mo1519e():boolean");
    }

    /* renamed from: f */
    public void mo1520f() {
        C0247d dVar = this.f1012J;
        C0167i iVar = dVar == null ? null : dVar.f1048b;
        if (iVar != null) {
            iVar.collapseActionView();
        }
    }

    /* renamed from: g */
    public void mo1521g() {
        ActionMenuView actionMenuView = this.f1015a;
        if (actionMenuView != null) {
            actionMenuView.mo1137x();
        }
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public void mo1525h() {
        if (this.f1022h == null) {
            AppCompatImageButton appCompatImageButton = new AppCompatImageButton(getContext(), (AttributeSet) null, R.attr.toolbarNavigationButtonStyle);
            this.f1022h = appCompatImageButton;
            appCompatImageButton.setImageDrawable(this.f1020f);
            this.f1022h.setContentDescription(this.f1021g);
            LayoutParams l = generateDefaultLayoutParams();
            l.f211a = 8388611 | (this.f1028n & 112);
            l.f1041b = 2;
            this.f1022h.setLayoutParams(l);
            this.f1022h.setOnClickListener(new C0246c());
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: l */
    public LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-2, -2);
    }

    /* access modifiers changed from: protected */
    /* renamed from: m */
    public LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams ? new LayoutParams((LayoutParams) layoutParams) : layoutParams instanceof ActionBar.LayoutParams ? new LayoutParams((ActionBar.LayoutParams) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams) : new LayoutParams(layoutParams);
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f1014L);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f1005C = false;
        }
        if (!this.f1005C) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f1005C = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f1005C = false;
        }
        return true;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:100:0x0233  */
    /* JADX WARNING: Removed duplicated region for block: B:115:0x02ad A[LOOP:0: B:114:0x02ab->B:115:0x02ad, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:118:0x02cf A[LOOP:1: B:117:0x02cd->B:118:0x02cf, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x02f3 A[LOOP:2: B:120:0x02f1->B:121:0x02f3, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:124:0x0334  */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x0344 A[LOOP:3: B:128:0x0342->B:129:0x0344, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x005f  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0074  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0087  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x008c  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0096  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x009b  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00c6  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00db  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x00f6  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x010e  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0111  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x0129  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x0138  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x013b  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x013f  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x0142  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x0175  */
    /* JADX WARNING: Removed duplicated region for block: B:85:0x01b3  */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x01c4  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r20, int r21, int r22, int r23, int r24) {
        /*
            r19 = this;
            r0 = r19
            int r1 = p098d.p120g.p130j.C4761m.f17241f
            int r1 = r19.getLayoutDirection()
            r2 = 1
            r3 = 0
            if (r1 != r2) goto L_0x000e
            r1 = 1
            goto L_0x000f
        L_0x000e:
            r1 = 0
        L_0x000f:
            int r4 = r19.getWidth()
            int r5 = r19.getHeight()
            int r6 = r19.getPaddingLeft()
            int r7 = r19.getPaddingRight()
            int r8 = r19.getPaddingTop()
            int r9 = r19.getPaddingBottom()
            int r10 = r4 - r7
            int[] r11 = r0.f1008F
            r11[r2] = r3
            r11[r3] = r3
            int r12 = r19.getMinimumHeight()
            if (r12 < 0) goto L_0x003c
            int r13 = r24 - r22
            int r12 = java.lang.Math.min(r12, r13)
            goto L_0x003d
        L_0x003c:
            r12 = 0
        L_0x003d:
            android.widget.ImageButton r13 = r0.f1018d
            boolean r13 = r0.m1089Y(r13)
            if (r13 == 0) goto L_0x0055
            android.widget.ImageButton r13 = r0.f1018d
            if (r1 == 0) goto L_0x0050
            int r13 = r0.m1086I(r13, r10, r11, r12)
            r14 = r13
            r13 = r6
            goto L_0x0057
        L_0x0050:
            int r13 = r0.m1085H(r13, r6, r11, r12)
            goto L_0x0056
        L_0x0055:
            r13 = r6
        L_0x0056:
            r14 = r10
        L_0x0057:
            android.widget.ImageButton r15 = r0.f1022h
            boolean r15 = r0.m1089Y(r15)
            if (r15 == 0) goto L_0x006c
            android.widget.ImageButton r15 = r0.f1022h
            if (r1 == 0) goto L_0x0068
            int r14 = r0.m1086I(r15, r14, r11, r12)
            goto L_0x006c
        L_0x0068:
            int r13 = r0.m1085H(r15, r13, r11, r12)
        L_0x006c:
            androidx.appcompat.widget.ActionMenuView r15 = r0.f1015a
            boolean r15 = r0.m1089Y(r15)
            if (r15 == 0) goto L_0x0081
            androidx.appcompat.widget.ActionMenuView r15 = r0.f1015a
            if (r1 == 0) goto L_0x007d
            int r13 = r0.m1085H(r15, r13, r11, r12)
            goto L_0x0081
        L_0x007d:
            int r14 = r0.m1086I(r15, r14, r11, r12)
        L_0x0081:
            int r15 = r19.getLayoutDirection()
            if (r15 != r2) goto L_0x008c
            int r15 = r19.mo1536p()
            goto L_0x0090
        L_0x008c:
            int r15 = r19.mo1537q()
        L_0x0090:
            int r3 = r19.getLayoutDirection()
            if (r3 != r2) goto L_0x009b
            int r3 = r19.mo1537q()
            goto L_0x009f
        L_0x009b:
            int r3 = r19.mo1536p()
        L_0x009f:
            int r2 = r15 - r13
            r23 = r7
            r7 = 0
            int r2 = java.lang.Math.max(r7, r2)
            r11[r7] = r2
            int r2 = r10 - r14
            int r2 = r3 - r2
            int r2 = java.lang.Math.max(r7, r2)
            r7 = 1
            r11[r7] = r2
            int r2 = java.lang.Math.max(r13, r15)
            int r10 = r10 - r3
            int r3 = java.lang.Math.min(r14, r10)
            android.view.View r7 = r0.f1023i
            boolean r7 = r0.m1089Y(r7)
            if (r7 == 0) goto L_0x00d3
            android.view.View r7 = r0.f1023i
            if (r1 == 0) goto L_0x00cf
            int r3 = r0.m1086I(r7, r3, r11, r12)
            goto L_0x00d3
        L_0x00cf:
            int r2 = r0.m1085H(r7, r2, r11, r12)
        L_0x00d3:
            android.widget.ImageView r7 = r0.f1019e
            boolean r7 = r0.m1089Y(r7)
            if (r7 == 0) goto L_0x00e8
            android.widget.ImageView r7 = r0.f1019e
            if (r1 == 0) goto L_0x00e4
            int r3 = r0.m1086I(r7, r3, r11, r12)
            goto L_0x00e8
        L_0x00e4:
            int r2 = r0.m1085H(r7, r2, r11, r12)
        L_0x00e8:
            android.widget.TextView r7 = r0.f1016b
            boolean r7 = r0.m1089Y(r7)
            android.widget.TextView r10 = r0.f1017c
            boolean r10 = r0.m1089Y(r10)
            if (r7 == 0) goto L_0x010e
            android.widget.TextView r13 = r0.f1016b
            android.view.ViewGroup$LayoutParams r13 = r13.getLayoutParams()
            androidx.appcompat.widget.Toolbar$LayoutParams r13 = (androidx.appcompat.widget.Toolbar.LayoutParams) r13
            int r14 = r13.topMargin
            android.widget.TextView r15 = r0.f1016b
            int r15 = r15.getMeasuredHeight()
            int r15 = r15 + r14
            int r13 = r13.bottomMargin
            int r15 = r15 + r13
            r13 = 0
            int r14 = r15 + 0
            goto L_0x010f
        L_0x010e:
            r14 = 0
        L_0x010f:
            if (r10 == 0) goto L_0x0129
            android.widget.TextView r13 = r0.f1017c
            android.view.ViewGroup$LayoutParams r13 = r13.getLayoutParams()
            androidx.appcompat.widget.Toolbar$LayoutParams r13 = (androidx.appcompat.widget.Toolbar.LayoutParams) r13
            int r15 = r13.topMargin
            r16 = r4
            android.widget.TextView r4 = r0.f1017c
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r15
            int r13 = r13.bottomMargin
            int r4 = r4 + r13
            int r14 = r14 + r4
            goto L_0x012b
        L_0x0129:
            r16 = r4
        L_0x012b:
            if (r7 != 0) goto L_0x0136
            if (r10 == 0) goto L_0x0130
            goto L_0x0136
        L_0x0130:
            r17 = r6
            r22 = r12
            goto L_0x029d
        L_0x0136:
            if (r7 == 0) goto L_0x013b
            android.widget.TextView r4 = r0.f1016b
            goto L_0x013d
        L_0x013b:
            android.widget.TextView r4 = r0.f1017c
        L_0x013d:
            if (r10 == 0) goto L_0x0142
            android.widget.TextView r13 = r0.f1017c
            goto L_0x0144
        L_0x0142:
            android.widget.TextView r13 = r0.f1016b
        L_0x0144:
            android.view.ViewGroup$LayoutParams r4 = r4.getLayoutParams()
            androidx.appcompat.widget.Toolbar$LayoutParams r4 = (androidx.appcompat.widget.Toolbar.LayoutParams) r4
            android.view.ViewGroup$LayoutParams r13 = r13.getLayoutParams()
            androidx.appcompat.widget.Toolbar$LayoutParams r13 = (androidx.appcompat.widget.Toolbar.LayoutParams) r13
            if (r7 == 0) goto L_0x015a
            android.widget.TextView r15 = r0.f1016b
            int r15 = r15.getMeasuredWidth()
            if (r15 > 0) goto L_0x0164
        L_0x015a:
            if (r10 == 0) goto L_0x0168
            android.widget.TextView r15 = r0.f1017c
            int r15 = r15.getMeasuredWidth()
            if (r15 <= 0) goto L_0x0168
        L_0x0164:
            r17 = r6
            r15 = 1
            goto L_0x016b
        L_0x0168:
            r17 = r6
            r15 = 0
        L_0x016b:
            int r6 = r0.f1037w
            r6 = r6 & 112(0x70, float:1.57E-43)
            r22 = r12
            r12 = 48
            if (r6 == r12) goto L_0x01b3
            r12 = 80
            if (r6 == r12) goto L_0x01a5
            int r6 = r5 - r8
            int r6 = r6 - r9
            int r6 = r6 - r14
            int r6 = r6 / 2
            int r12 = r4.topMargin
            r24 = r2
            int r2 = r0.f1032r
            r18 = r10
            int r10 = r12 + r2
            if (r6 >= r10) goto L_0x018e
            int r6 = r12 + r2
            goto L_0x01a3
        L_0x018e:
            int r5 = r5 - r9
            int r5 = r5 - r14
            int r5 = r5 - r6
            int r5 = r5 - r8
            int r2 = r4.bottomMargin
            int r4 = r0.f1033s
            int r2 = r2 + r4
            if (r5 >= r2) goto L_0x01a3
            int r2 = r13.bottomMargin
            int r2 = r2 + r4
            int r2 = r2 - r5
            int r6 = r6 - r2
            r2 = 0
            int r6 = java.lang.Math.max(r2, r6)
        L_0x01a3:
            int r8 = r8 + r6
            goto L_0x01c2
        L_0x01a5:
            r24 = r2
            r18 = r10
            int r5 = r5 - r9
            int r2 = r13.bottomMargin
            int r5 = r5 - r2
            int r2 = r0.f1033s
            int r5 = r5 - r2
            int r8 = r5 - r14
            goto L_0x01c2
        L_0x01b3:
            r24 = r2
            r18 = r10
            int r2 = r19.getPaddingTop()
            int r4 = r4.topMargin
            int r2 = r2 + r4
            int r4 = r0.f1032r
            int r8 = r2 + r4
        L_0x01c2:
            if (r1 == 0) goto L_0x0233
            if (r15 == 0) goto L_0x01c9
            int r1 = r0.f1030p
            goto L_0x01ca
        L_0x01c9:
            r1 = 0
        L_0x01ca:
            r2 = 1
            r4 = r11[r2]
            int r1 = r1 - r4
            r4 = 0
            int r5 = java.lang.Math.max(r4, r1)
            int r3 = r3 - r5
            int r1 = -r1
            int r1 = java.lang.Math.max(r4, r1)
            r11[r2] = r1
            if (r7 == 0) goto L_0x0201
            android.widget.TextView r1 = r0.f1016b
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$LayoutParams r1 = (androidx.appcompat.widget.Toolbar.LayoutParams) r1
            android.widget.TextView r2 = r0.f1016b
            int r2 = r2.getMeasuredWidth()
            int r2 = r3 - r2
            android.widget.TextView r4 = r0.f1016b
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            android.widget.TextView r5 = r0.f1016b
            r5.layout(r2, r8, r3, r4)
            int r5 = r0.f1031q
            int r2 = r2 - r5
            int r1 = r1.bottomMargin
            int r8 = r4 + r1
            goto L_0x0202
        L_0x0201:
            r2 = r3
        L_0x0202:
            if (r18 == 0) goto L_0x0228
            android.widget.TextView r1 = r0.f1017c
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$LayoutParams r1 = (androidx.appcompat.widget.Toolbar.LayoutParams) r1
            int r1 = r1.topMargin
            int r8 = r8 + r1
            android.widget.TextView r1 = r0.f1017c
            int r1 = r1.getMeasuredWidth()
            int r1 = r3 - r1
            android.widget.TextView r4 = r0.f1017c
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            android.widget.TextView r5 = r0.f1017c
            r5.layout(r1, r8, r3, r4)
            int r1 = r0.f1031q
            int r1 = r3 - r1
            goto L_0x0229
        L_0x0228:
            r1 = r3
        L_0x0229:
            if (r15 == 0) goto L_0x0230
            int r1 = java.lang.Math.min(r2, r1)
            r3 = r1
        L_0x0230:
            r2 = r24
            goto L_0x029d
        L_0x0233:
            if (r15 == 0) goto L_0x0238
            int r1 = r0.f1030p
            goto L_0x0239
        L_0x0238:
            r1 = 0
        L_0x0239:
            r2 = 0
            r4 = r11[r2]
            int r1 = r1 - r4
            int r4 = java.lang.Math.max(r2, r1)
            int r4 = r4 + r24
            int r1 = -r1
            int r1 = java.lang.Math.max(r2, r1)
            r11[r2] = r1
            if (r7 == 0) goto L_0x026f
            android.widget.TextView r1 = r0.f1016b
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$LayoutParams r1 = (androidx.appcompat.widget.Toolbar.LayoutParams) r1
            android.widget.TextView r2 = r0.f1016b
            int r2 = r2.getMeasuredWidth()
            int r2 = r2 + r4
            android.widget.TextView r5 = r0.f1016b
            int r5 = r5.getMeasuredHeight()
            int r5 = r5 + r8
            android.widget.TextView r6 = r0.f1016b
            r6.layout(r4, r8, r2, r5)
            int r6 = r0.f1031q
            int r2 = r2 + r6
            int r1 = r1.bottomMargin
            int r8 = r5 + r1
            goto L_0x0270
        L_0x026f:
            r2 = r4
        L_0x0270:
            if (r18 == 0) goto L_0x0294
            android.widget.TextView r1 = r0.f1017c
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$LayoutParams r1 = (androidx.appcompat.widget.Toolbar.LayoutParams) r1
            int r1 = r1.topMargin
            int r8 = r8 + r1
            android.widget.TextView r1 = r0.f1017c
            int r1 = r1.getMeasuredWidth()
            int r1 = r1 + r4
            android.widget.TextView r5 = r0.f1017c
            int r5 = r5.getMeasuredHeight()
            int r5 = r5 + r8
            android.widget.TextView r6 = r0.f1017c
            r6.layout(r4, r8, r1, r5)
            int r5 = r0.f1031q
            int r1 = r1 + r5
            goto L_0x0295
        L_0x0294:
            r1 = r4
        L_0x0295:
            if (r15 == 0) goto L_0x029c
            int r2 = java.lang.Math.max(r2, r1)
            goto L_0x029d
        L_0x029c:
            r2 = r4
        L_0x029d:
            java.util.ArrayList<android.view.View> r1 = r0.f1006D
            r4 = 3
            r0.m1090c(r1, r4)
            java.util.ArrayList<android.view.View> r1 = r0.f1006D
            int r1 = r1.size()
            r4 = r2
            r2 = 0
        L_0x02ab:
            if (r2 >= r1) goto L_0x02be
            java.util.ArrayList<android.view.View> r5 = r0.f1006D
            java.lang.Object r5 = r5.get(r2)
            android.view.View r5 = (android.view.View) r5
            r12 = r22
            int r4 = r0.m1085H(r5, r4, r11, r12)
            int r2 = r2 + 1
            goto L_0x02ab
        L_0x02be:
            r12 = r22
            java.util.ArrayList<android.view.View> r1 = r0.f1006D
            r2 = 5
            r0.m1090c(r1, r2)
            java.util.ArrayList<android.view.View> r1 = r0.f1006D
            int r1 = r1.size()
            r2 = 0
        L_0x02cd:
            if (r2 >= r1) goto L_0x02de
            java.util.ArrayList<android.view.View> r5 = r0.f1006D
            java.lang.Object r5 = r5.get(r2)
            android.view.View r5 = (android.view.View) r5
            int r3 = r0.m1086I(r5, r3, r11, r12)
            int r2 = r2 + 1
            goto L_0x02cd
        L_0x02de:
            java.util.ArrayList<android.view.View> r1 = r0.f1006D
            r2 = 1
            r0.m1090c(r1, r2)
            java.util.ArrayList<android.view.View> r1 = r0.f1006D
            r5 = 0
            r6 = r11[r5]
            r2 = r11[r2]
            int r5 = r1.size()
            r7 = 0
            r8 = 0
        L_0x02f1:
            if (r7 >= r5) goto L_0x0324
            java.lang.Object r9 = r1.get(r7)
            android.view.View r9 = (android.view.View) r9
            android.view.ViewGroup$LayoutParams r10 = r9.getLayoutParams()
            androidx.appcompat.widget.Toolbar$LayoutParams r10 = (androidx.appcompat.widget.Toolbar.LayoutParams) r10
            int r13 = r10.leftMargin
            int r13 = r13 - r6
            int r6 = r10.rightMargin
            int r6 = r6 - r2
            r2 = 0
            int r10 = java.lang.Math.max(r2, r13)
            int r14 = java.lang.Math.max(r2, r6)
            int r13 = -r13
            int r13 = java.lang.Math.max(r2, r13)
            int r6 = -r6
            int r6 = java.lang.Math.max(r2, r6)
            int r9 = r9.getMeasuredWidth()
            int r9 = r9 + r10
            int r9 = r9 + r14
            int r8 = r8 + r9
            int r7 = r7 + 1
            r2 = r6
            r6 = r13
            goto L_0x02f1
        L_0x0324:
            r2 = 0
            int r1 = r16 - r17
            int r1 = r1 - r23
            int r1 = r1 / 2
            int r1 = r1 + r17
            int r5 = r8 / 2
            int r1 = r1 - r5
            int r8 = r8 + r1
            if (r1 >= r4) goto L_0x0334
            goto L_0x033b
        L_0x0334:
            if (r8 <= r3) goto L_0x033a
            int r8 = r8 - r3
            int r4 = r1 - r8
            goto L_0x033b
        L_0x033a:
            r4 = r1
        L_0x033b:
            java.util.ArrayList<android.view.View> r1 = r0.f1006D
            int r1 = r1.size()
            r3 = 0
        L_0x0342:
            if (r3 >= r1) goto L_0x0353
            java.util.ArrayList<android.view.View> r2 = r0.f1006D
            java.lang.Object r2 = r2.get(r3)
            android.view.View r2 = (android.view.View) r2
            int r4 = r0.m1085H(r2, r4, r11, r12)
            int r3 = r3 + 1
            goto L_0x0342
        L_0x0353:
            java.util.ArrayList<android.view.View> r1 = r0.f1006D
            r1.clear()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        char c;
        char c2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int[] iArr = this.f1008F;
        boolean z = true;
        int i10 = 0;
        if (C0280l0.m1310b(this)) {
            c2 = 1;
            c = 0;
        } else {
            c2 = 0;
            c = 1;
        }
        if (m1089Y(this.f1018d)) {
            m1088K(this.f1018d, i, 0, i2, 0, this.f1029o);
            i5 = this.f1018d.getMeasuredWidth() + m1097r(this.f1018d);
            i4 = Math.max(0, this.f1018d.getMeasuredHeight() + m1083A(this.f1018d));
            i3 = View.combineMeasuredStates(0, this.f1018d.getMeasuredState());
        } else {
            i5 = 0;
            i4 = 0;
            i3 = 0;
        }
        if (m1089Y(this.f1022h)) {
            m1088K(this.f1022h, i, 0, i2, 0, this.f1029o);
            i5 = this.f1022h.getMeasuredWidth() + m1097r(this.f1022h);
            i4 = Math.max(i4, this.f1022h.getMeasuredHeight() + m1083A(this.f1022h));
            i3 = View.combineMeasuredStates(i3, this.f1022h.getMeasuredState());
        }
        int q = mo1537q();
        int max = Math.max(q, i5) + 0;
        iArr[c2] = Math.max(0, q - i5);
        if (m1089Y(this.f1015a)) {
            m1088K(this.f1015a, i, max, i2, 0, this.f1029o);
            i6 = this.f1015a.getMeasuredWidth() + m1097r(this.f1015a);
            i4 = Math.max(i4, this.f1015a.getMeasuredHeight() + m1083A(this.f1015a));
            i3 = View.combineMeasuredStates(i3, this.f1015a.getMeasuredState());
        } else {
            i6 = 0;
        }
        int p = mo1536p();
        int max2 = Math.max(p, i6) + max;
        iArr[c] = Math.max(0, p - i6);
        if (m1089Y(this.f1023i)) {
            max2 += m1087J(this.f1023i, i, max2, i2, 0, iArr);
            i4 = Math.max(i4, this.f1023i.getMeasuredHeight() + m1083A(this.f1023i));
            i3 = View.combineMeasuredStates(i3, this.f1023i.getMeasuredState());
        }
        if (m1089Y(this.f1019e)) {
            max2 += m1087J(this.f1019e, i, max2, i2, 0, iArr);
            i4 = Math.max(i4, this.f1019e.getMeasuredHeight() + m1083A(this.f1019e));
            i3 = View.combineMeasuredStates(i3, this.f1019e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if (((LayoutParams) childAt.getLayoutParams()).f1041b == 0 && m1089Y(childAt)) {
                View view = childAt;
                max2 += m1087J(childAt, i, max2, i2, 0, iArr);
                View view2 = view;
                i4 = Math.max(i4, view.getMeasuredHeight() + m1083A(view2));
                i3 = View.combineMeasuredStates(i3, view2.getMeasuredState());
            }
        }
        int i12 = this.f1032r + this.f1033s;
        int i13 = this.f1030p + this.f1031q;
        if (m1089Y(this.f1016b)) {
            m1087J(this.f1016b, i, max2 + i13, i2, i12, iArr);
            int measuredWidth = this.f1016b.getMeasuredWidth() + m1097r(this.f1016b);
            i7 = this.f1016b.getMeasuredHeight() + m1083A(this.f1016b);
            i9 = View.combineMeasuredStates(i3, this.f1016b.getMeasuredState());
            i8 = measuredWidth;
        } else {
            i9 = i3;
            i8 = 0;
            i7 = 0;
        }
        if (m1089Y(this.f1017c)) {
            int i14 = i7 + i12;
            i8 = Math.max(i8, m1087J(this.f1017c, i, max2 + i13, i2, i14, iArr));
            i7 = this.f1017c.getMeasuredHeight() + m1083A(this.f1017c) + i7;
            i9 = View.combineMeasuredStates(i9, this.f1017c.getMeasuredState());
        } else {
            int i15 = i9;
        }
        int max3 = Math.max(i4, i7);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop() + max3;
        int resolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight + max2 + i8, getSuggestedMinimumWidth()), i, -16777216 & i9);
        int resolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i2, i9 << 16);
        if (this.f1013K) {
            int childCount2 = getChildCount();
            int i16 = 0;
            while (true) {
                if (i16 >= childCount2) {
                    break;
                }
                View childAt2 = getChildAt(i16);
                if (m1089Y(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                    break;
                }
                i16++;
            }
        }
        z = false;
        if (!z) {
            i10 = resolveSizeAndState2;
        }
        setMeasuredDimension(resolveSizeAndState, i10);
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem findItem;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.mo2467a());
        ActionMenuView actionMenuView = this.f1015a;
        C0163g H = actionMenuView != null ? actionMenuView.mo1118H() : null;
        int i = savedState.f1042c;
        if (!(i == 0 || this.f1012J == null || H == null || (findItem = H.findItem(i)) == null)) {
            findItem.expandActionView();
        }
        if (savedState.f1043d) {
            removeCallbacks(this.f1014L);
            post(this.f1014L);
        }
    }

    public void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        m1092i();
        C0304x xVar = this.f1034t;
        boolean z = true;
        if (i != 1) {
            z = false;
        }
        xVar.mo1742d(z);
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        C0167i iVar;
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        C0247d dVar = this.f1012J;
        if (!(dVar == null || (iVar = dVar.f1048b) == null)) {
            savedState.f1042c = iVar.getItemId();
        }
        ActionMenuView actionMenuView = this.f1015a;
        savedState.f1043d = actionMenuView != null && actionMenuView.mo1116E();
        return savedState;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1004B = false;
        }
        if (!this.f1004B) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f1004B = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f1004B = false;
        }
        return true;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0005, code lost:
        r0 = r0.mo1118H();
     */
    /* renamed from: p */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int mo1536p() {
        /*
            r3 = this;
            androidx.appcompat.widget.ActionMenuView r0 = r3.f1015a
            r1 = 0
            if (r0 == 0) goto L_0x0013
            androidx.appcompat.view.menu.g r0 = r0.mo1118H()
            if (r0 == 0) goto L_0x0013
            boolean r0 = r0.hasVisibleItems()
            if (r0 == 0) goto L_0x0013
            r0 = 1
            goto L_0x0014
        L_0x0013:
            r0 = 0
        L_0x0014:
            if (r0 == 0) goto L_0x002b
            androidx.appcompat.widget.x r0 = r3.f1034t
            if (r0 == 0) goto L_0x001f
            int r0 = r0.mo1739a()
            goto L_0x0020
        L_0x001f:
            r0 = 0
        L_0x0020:
            int r2 = r3.f1036v
            int r1 = java.lang.Math.max(r2, r1)
            int r0 = java.lang.Math.max(r0, r1)
            goto L_0x0034
        L_0x002b:
            androidx.appcompat.widget.x r0 = r3.f1034t
            if (r0 == 0) goto L_0x0033
            int r1 = r0.mo1739a()
        L_0x0033:
            r0 = r1
        L_0x0034:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.mo1536p():int");
    }

    /* renamed from: q */
    public int mo1537q() {
        int i = 0;
        if (mo1539t() != null) {
            C0304x xVar = this.f1034t;
            return Math.max(xVar != null ? xVar.mo1740b() : 0, Math.max(this.f1035u, 0));
        }
        C0304x xVar2 = this.f1034t;
        if (xVar2 != null) {
            i = xVar2.mo1740b();
        }
        return i;
    }

    /* renamed from: s */
    public CharSequence mo1538s() {
        ImageButton imageButton = this.f1018d;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    /* renamed from: t */
    public Drawable mo1539t() {
        ImageButton imageButton = this.f1018d;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    /* renamed from: u */
    public CharSequence mo1540u() {
        return this.f1039y;
    }

    /* renamed from: v */
    public CharSequence mo1541v() {
        return this.f1038x;
    }

    /* renamed from: w */
    public int mo1542w() {
        return this.f1033s;
    }

    /* renamed from: x */
    public int mo1543x() {
        return this.f1031q;
    }

    /* renamed from: y */
    public int mo1544y() {
        return this.f1030p;
    }

    /* renamed from: z */
    public int mo1545z() {
        return this.f1032r;
    }
}
