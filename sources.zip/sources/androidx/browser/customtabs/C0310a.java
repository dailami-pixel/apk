package androidx.browser.customtabs;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;

/* renamed from: androidx.browser.customtabs.a */
public final class C0310a {

    /* renamed from: a */
    public final Intent f1257a;

    /* renamed from: androidx.browser.customtabs.a$a */
    public static final class C0311a {

        /* renamed from: a */
        private final Intent f1258a;

        /* renamed from: b */
        private boolean f1259b = true;

        public C0311a() {
            Intent intent = new Intent("android.intent.action.VIEW");
            this.f1258a = intent;
            Bundle bundle = new Bundle();
            bundle.putBinder("android.support.customtabs.extra.SESSION", (IBinder) null);
            intent.putExtras(bundle);
        }

        /* renamed from: a */
        public C0310a mo1766a() {
            this.f1258a.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", this.f1259b);
            return new C0310a(this.f1258a, (Bundle) null);
        }
    }

    C0310a(Intent intent, Bundle bundle) {
        this.f1257a = intent;
    }
}
