package androidx.browser.customtabs;

import android.os.IBinder;
import p010c.p011a.p012a.C1431a;

/* renamed from: androidx.browser.customtabs.b */
public class C0312b {

    /* renamed from: a */
    final C1431a f1260a;

    C0312b(C1431a aVar) {
        this.f1260a = aVar;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public IBinder mo1767a() {
        return this.f1260a.asBinder();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0312b)) {
            return false;
        }
        return ((C0312b) obj).mo1767a().equals(this.f1260a.asBinder());
    }

    public int hashCode() {
        return mo1767a().hashCode();
    }
}
