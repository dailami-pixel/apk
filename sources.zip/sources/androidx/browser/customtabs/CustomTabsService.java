package androidx.browser.customtabs;

import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import p010c.p011a.p012a.C1431a;
import p010c.p011a.p012a.C1434b;
import p098d.p112d.C4616a;

public abstract class CustomTabsService extends Service {

    /* renamed from: a */
    final Map<IBinder, IBinder.DeathRecipient> f1251a = new C4616a();

    /* renamed from: b */
    private C1434b.C1435a f1252b = new C0307a();

    /* renamed from: androidx.browser.customtabs.CustomTabsService$a */
    class C0307a extends C1434b.C1435a {

        /* renamed from: androidx.browser.customtabs.CustomTabsService$a$a */
        class C0308a implements IBinder.DeathRecipient {

            /* renamed from: a */
            final /* synthetic */ C0312b f1254a;

            C0308a(C0312b bVar) {
                this.f1254a = bVar;
            }

            public void binderDied() {
                CustomTabsService customTabsService = CustomTabsService.this;
                C0312b bVar = this.f1254a;
                Objects.requireNonNull(customTabsService);
                try {
                    synchronized (customTabsService.f1251a) {
                        IBinder a = bVar.mo1767a();
                        a.unlinkToDeath(customTabsService.f1251a.get(a), 0);
                        customTabsService.f1251a.remove(a);
                    }
                } catch (NoSuchElementException unused) {
                }
            }
        }

        C0307a() {
        }

        /* renamed from: E */
        public Bundle mo1754E(String str, Bundle bundle) {
            return CustomTabsService.this.mo1745a(str, bundle);
        }

        /* renamed from: T */
        public boolean mo1755T(long j) {
            return CustomTabsService.this.mo1752h(j);
        }

        /* renamed from: g0 */
        public int mo1756g0(C1431a aVar, String str, Bundle bundle) {
            return CustomTabsService.this.mo1748d(new C0312b(aVar), str, bundle);
        }

        /* renamed from: j0 */
        public boolean mo1757j0(C1431a aVar) {
            C0312b bVar = new C0312b(aVar);
            try {
                C0308a aVar2 = new C0308a(bVar);
                synchronized (CustomTabsService.this.f1251a) {
                    aVar.asBinder().linkToDeath(aVar2, 0);
                    CustomTabsService.this.f1251a.put(aVar.asBinder(), aVar2);
                }
                return CustomTabsService.this.mo1747c(bVar);
            } catch (RemoteException unused) {
                return false;
            }
        }

        /* renamed from: l */
        public boolean mo1758l(C1431a aVar, Uri uri, Bundle bundle, List<Bundle> list) {
            return CustomTabsService.this.mo1746b(new C0312b(aVar), uri, bundle, list);
        }

        /* renamed from: m */
        public boolean mo1759m(C1431a aVar, int i, Uri uri, Bundle bundle) {
            return CustomTabsService.this.mo1751g(new C0312b(aVar), i, uri, bundle);
        }

        /* renamed from: r0 */
        public boolean mo1760r0(C1431a aVar, Bundle bundle) {
            return CustomTabsService.this.mo1750f(new C0312b(aVar), bundle);
        }

        /* renamed from: v0 */
        public boolean mo1761v0(C1431a aVar, Uri uri) {
            return CustomTabsService.this.mo1749e(new C0312b(aVar), uri);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract Bundle mo1745a(String str, Bundle bundle);

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract boolean mo1746b(C0312b bVar, Uri uri, Bundle bundle, List<Bundle> list);

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public abstract boolean mo1747c(C0312b bVar);

    /* access modifiers changed from: protected */
    /* renamed from: d */
    public abstract int mo1748d(C0312b bVar, String str, Bundle bundle);

    /* access modifiers changed from: protected */
    /* renamed from: e */
    public abstract boolean mo1749e(C0312b bVar, Uri uri);

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public abstract boolean mo1750f(C0312b bVar, Bundle bundle);

    /* access modifiers changed from: protected */
    /* renamed from: g */
    public abstract boolean mo1751g(C0312b bVar, int i, Uri uri, Bundle bundle);

    /* access modifiers changed from: protected */
    /* renamed from: h */
    public abstract boolean mo1752h(long j);

    public IBinder onBind(Intent intent) {
        return this.f1252b;
    }
}
