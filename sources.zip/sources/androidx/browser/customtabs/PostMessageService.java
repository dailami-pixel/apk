package androidx.browser.customtabs;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import p010c.p011a.p012a.C1431a;
import p010c.p011a.p012a.C1436c;

public class PostMessageService extends Service {

    /* renamed from: a */
    private C1436c.C1437a f1256a = new C0309a(this);

    /* renamed from: androidx.browser.customtabs.PostMessageService$a */
    class C0309a extends C1436c.C1437a {
        C0309a(PostMessageService postMessageService) {
        }

        /* renamed from: N */
        public void mo1764N(C1431a aVar, Bundle bundle) throws RemoteException {
            aVar.mo5796G0(bundle);
        }

        /* renamed from: W */
        public void mo1765W(C1431a aVar, String str, Bundle bundle) throws RemoteException {
            aVar.mo5795F0(str, bundle);
        }
    }

    public IBinder onBind(Intent intent) {
        return this.f1256a;
    }
}
