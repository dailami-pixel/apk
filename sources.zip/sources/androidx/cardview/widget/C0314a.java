package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import androidx.cardview.widget.CardView;

/* renamed from: androidx.cardview.widget.a */
class C0314a implements C0316c {
    C0314a() {
    }

    /* renamed from: b */
    private C0317d m1432b(C0315b bVar) {
        return (C0317d) ((CardView.C0313a) bVar).mo1786a();
    }

    /* renamed from: a */
    public ColorStateList mo1790a(C0315b bVar) {
        return m1432b(bVar).mo1795b();
    }

    /* renamed from: c */
    public float mo1791c(C0315b bVar) {
        return m1432b(bVar).mo1796c();
    }

    /* renamed from: d */
    public float mo1792d(C0315b bVar) {
        return m1432b(bVar).mo1797d();
    }

    /* renamed from: e */
    public void mo1793e(C0315b bVar, Context context, ColorStateList colorStateList, float f, float f2, float f3) {
        CardView.C0313a aVar = (CardView.C0313a) bVar;
        aVar.mo1788c(new C0317d(colorStateList, f));
        CardView cardView = CardView.this;
        cardView.setClipToOutline(true);
        cardView.setElevation(f2);
        m1432b(aVar).mo1799e(f3, CardView.this.mo1784u(), aVar.mo1787b());
        mo1794f(aVar);
    }

    /* renamed from: f */
    public void mo1794f(C0315b bVar) {
        CardView.C0313a aVar = (CardView.C0313a) bVar;
        if (!CardView.this.mo1784u()) {
            aVar.mo1789d(0, 0, 0, 0);
            return;
        }
        float c = m1432b(bVar).mo1796c();
        float d = m1432b(bVar).mo1797d();
        int ceil = (int) Math.ceil((double) C0318e.m1444a(c, d, aVar.mo1787b()));
        int ceil2 = (int) Math.ceil((double) C0318e.m1445b(c, d, aVar.mo1787b()));
        aVar.mo1789d(ceil, ceil2, ceil, ceil2);
    }
}
