package androidx.cardview.widget;

/* renamed from: androidx.cardview.widget.b */
interface C0315b {
}
