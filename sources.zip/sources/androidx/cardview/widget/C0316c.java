package androidx.cardview.widget;

/* renamed from: androidx.cardview.widget.c */
interface C0316c {
}
