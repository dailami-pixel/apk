package androidx.cardview.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/* renamed from: androidx.cardview.widget.d */
class C0317d extends Drawable {

    /* renamed from: a */
    private float f1272a;

    /* renamed from: b */
    private final Paint f1273b;

    /* renamed from: c */
    private final RectF f1274c;

    /* renamed from: d */
    private final Rect f1275d;

    /* renamed from: e */
    private float f1276e;

    /* renamed from: f */
    private boolean f1277f = false;

    /* renamed from: g */
    private boolean f1278g = true;

    /* renamed from: h */
    private ColorStateList f1279h;

    /* renamed from: i */
    private PorterDuffColorFilter f1280i;

    /* renamed from: j */
    private ColorStateList f1281j;

    /* renamed from: k */
    private PorterDuff.Mode f1282k = PorterDuff.Mode.SRC_IN;

    C0317d(ColorStateList colorStateList, float f) {
        this.f1272a = f;
        Paint paint = new Paint(5);
        this.f1273b = paint;
        colorStateList = colorStateList == null ? ColorStateList.valueOf(0) : colorStateList;
        this.f1279h = colorStateList;
        paint.setColor(colorStateList.getColorForState(getState(), this.f1279h.getDefaultColor()));
        this.f1274c = new RectF();
        this.f1275d = new Rect();
    }

    /* renamed from: a */
    private PorterDuffColorFilter m1438a(ColorStateList colorStateList, PorterDuff.Mode mode) {
        if (colorStateList == null || mode == null) {
            return null;
        }
        return new PorterDuffColorFilter(colorStateList.getColorForState(getState(), 0), mode);
    }

    /* renamed from: f */
    private void m1439f(Rect rect) {
        if (rect == null) {
            rect = getBounds();
        }
        this.f1274c.set((float) rect.left, (float) rect.top, (float) rect.right, (float) rect.bottom);
        this.f1275d.set(rect);
        if (this.f1277f) {
            float b = C0318e.m1445b(this.f1276e, this.f1272a, this.f1278g);
            this.f1275d.inset((int) Math.ceil((double) C0318e.m1444a(this.f1276e, this.f1272a, this.f1278g)), (int) Math.ceil((double) b));
            this.f1274c.set(this.f1275d);
        }
    }

    /* renamed from: b */
    public ColorStateList mo1795b() {
        return this.f1279h;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public float mo1796c() {
        return this.f1276e;
    }

    /* renamed from: d */
    public float mo1797d() {
        return this.f1272a;
    }

    public void draw(Canvas canvas) {
        boolean z;
        Paint paint = this.f1273b;
        if (this.f1280i == null || paint.getColorFilter() != null) {
            z = false;
        } else {
            paint.setColorFilter(this.f1280i);
            z = true;
        }
        RectF rectF = this.f1274c;
        float f = this.f1272a;
        canvas.drawRoundRect(rectF, f, f, paint);
        if (z) {
            paint.setColorFilter((ColorFilter) null);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo1799e(float f, boolean z, boolean z2) {
        if (f != this.f1276e || this.f1277f != z || this.f1278g != z2) {
            this.f1276e = f;
            this.f1277f = z;
            this.f1278g = z2;
            m1439f((Rect) null);
            invalidateSelf();
        }
    }

    public int getOpacity() {
        return -3;
    }

    public void getOutline(Outline outline) {
        outline.setRoundRect(this.f1275d, this.f1272a);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:4:0x000a, code lost:
        r0 = r1.f1279h;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean isStateful() {
        /*
            r1 = this;
            android.content.res.ColorStateList r0 = r1.f1281j
            if (r0 == 0) goto L_0x000a
            boolean r0 = r0.isStateful()
            if (r0 != 0) goto L_0x001a
        L_0x000a:
            android.content.res.ColorStateList r0 = r1.f1279h
            if (r0 == 0) goto L_0x0014
            boolean r0 = r0.isStateful()
            if (r0 != 0) goto L_0x001a
        L_0x0014:
            boolean r0 = super.isStateful()
            if (r0 == 0) goto L_0x001c
        L_0x001a:
            r0 = 1
            goto L_0x001d
        L_0x001c:
            r0 = 0
        L_0x001d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.cardview.widget.C0317d.isStateful():boolean");
    }

    /* access modifiers changed from: protected */
    public void onBoundsChange(Rect rect) {
        super.onBoundsChange(rect);
        m1439f(rect);
    }

    /* access modifiers changed from: protected */
    public boolean onStateChange(int[] iArr) {
        PorterDuff.Mode mode;
        ColorStateList colorStateList = this.f1279h;
        int colorForState = colorStateList.getColorForState(iArr, colorStateList.getDefaultColor());
        boolean z = colorForState != this.f1273b.getColor();
        if (z) {
            this.f1273b.setColor(colorForState);
        }
        ColorStateList colorStateList2 = this.f1281j;
        if (colorStateList2 == null || (mode = this.f1282k) == null) {
            return z;
        }
        this.f1280i = m1438a(colorStateList2, mode);
        return true;
    }

    public void setAlpha(int i) {
        this.f1273b.setAlpha(i);
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f1273b.setColorFilter(colorFilter);
    }

    public void setTintList(ColorStateList colorStateList) {
        this.f1281j = colorStateList;
        this.f1280i = m1438a(colorStateList, this.f1282k);
        invalidateSelf();
    }

    public void setTintMode(PorterDuff.Mode mode) {
        this.f1282k = mode;
        this.f1280i = m1438a(this.f1281j, mode);
        invalidateSelf();
    }
}
