package androidx.cardview.widget;

import android.graphics.drawable.Drawable;

/* renamed from: androidx.cardview.widget.e */
class C0318e extends Drawable {

    /* renamed from: a */
    private static final double f1283a = Math.cos(Math.toRadians(45.0d));

    /* renamed from: a */
    static float m1444a(float f, float f2, boolean z) {
        if (!z) {
            return f;
        }
        return (float) (((1.0d - f1283a) * ((double) f2)) + ((double) f));
    }

    /* renamed from: b */
    static float m1445b(float f, float f2, boolean z) {
        float f3 = f * 1.5f;
        if (!z) {
            return f3;
        }
        return (float) (((1.0d - f1283a) * ((double) f2)) + ((double) f3));
    }
}
