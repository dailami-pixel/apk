package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import com.vidio.android.p195tv.R;
import p098d.p111c.C4615a;

public class CardView extends FrameLayout {

    /* renamed from: a */
    private static final int[] f1261a = {16842801};

    /* renamed from: b */
    private static final C0316c f1262b = new C0314a();

    /* renamed from: c */
    private boolean f1263c;

    /* renamed from: d */
    private boolean f1264d;

    /* renamed from: e */
    int f1265e;

    /* renamed from: f */
    int f1266f;

    /* renamed from: g */
    final Rect f1267g;

    /* renamed from: h */
    final Rect f1268h;

    /* renamed from: i */
    private final C0315b f1269i;

    /* renamed from: androidx.cardview.widget.CardView$a */
    class C0313a implements C0315b {

        /* renamed from: a */
        private Drawable f1270a;

        C0313a() {
        }

        /* renamed from: a */
        public Drawable mo1786a() {
            return this.f1270a;
        }

        /* renamed from: b */
        public boolean mo1787b() {
            return CardView.this.mo1778s();
        }

        /* renamed from: c */
        public void mo1788c(Drawable drawable) {
            this.f1270a = drawable;
            CardView.this.setBackgroundDrawable(drawable);
        }

        /* renamed from: d */
        public void mo1789d(int i, int i2, int i3, int i4) {
            CardView.this.f1268h.set(i, i2, i3, i4);
            CardView cardView = CardView.this;
            Rect rect = cardView.f1267g;
            CardView.super.setPadding(i + rect.left, i2 + rect.top, i3 + rect.right, i4 + rect.bottom);
        }
    }

    public CardView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.cardViewStyle);
    }

    public CardView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Resources resources;
        int i2;
        ColorStateList valueOf;
        Rect rect = new Rect();
        this.f1267g = rect;
        this.f1268h = new Rect();
        C0313a aVar = new C0313a();
        this.f1269i = aVar;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4615a.f16648a, i, R.style.CardView);
        if (obtainStyledAttributes.hasValue(2)) {
            valueOf = obtainStyledAttributes.getColorStateList(2);
        } else {
            TypedArray obtainStyledAttributes2 = getContext().obtainStyledAttributes(f1261a);
            int color = obtainStyledAttributes2.getColor(0, 0);
            obtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            if (fArr[2] > 0.5f) {
                resources = getResources();
                i2 = R.color.cardview_light_background;
            } else {
                resources = getResources();
                i2 = R.color.cardview_dark_background;
            }
            valueOf = ColorStateList.valueOf(resources.getColor(i2));
        }
        ColorStateList colorStateList = valueOf;
        float dimension = obtainStyledAttributes.getDimension(3, 0.0f);
        float dimension2 = obtainStyledAttributes.getDimension(4, 0.0f);
        float dimension3 = obtainStyledAttributes.getDimension(5, 0.0f);
        this.f1263c = obtainStyledAttributes.getBoolean(7, false);
        this.f1264d = obtainStyledAttributes.getBoolean(6, true);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(8, 0);
        rect.left = obtainStyledAttributes.getDimensionPixelSize(10, dimensionPixelSize);
        rect.top = obtainStyledAttributes.getDimensionPixelSize(12, dimensionPixelSize);
        rect.right = obtainStyledAttributes.getDimensionPixelSize(11, dimensionPixelSize);
        rect.bottom = obtainStyledAttributes.getDimensionPixelSize(9, dimensionPixelSize);
        float f = dimension2 > dimension3 ? dimension2 : dimension3;
        this.f1265e = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        this.f1266f = obtainStyledAttributes.getDimensionPixelSize(1, 0);
        obtainStyledAttributes.recycle();
        ((C0314a) f1262b).mo1793e(aVar, context, colorStateList, dimension, dimension2, f);
    }

    /* renamed from: l */
    public ColorStateList mo1770l() {
        return ((C0314a) f1262b).mo1790a(this.f1269i);
    }

    /* renamed from: m */
    public float mo1771m() {
        return CardView.this.getElevation();
    }

    /* renamed from: n */
    public int mo1772n() {
        return this.f1267g.bottom;
    }

    /* renamed from: o */
    public int mo1773o() {
        return this.f1267g.left;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
    }

    /* renamed from: p */
    public int mo1775p() {
        return this.f1267g.right;
    }

    /* renamed from: q */
    public int mo1776q() {
        return this.f1267g.top;
    }

    /* renamed from: r */
    public float mo1777r() {
        return ((C0314a) f1262b).mo1791c(this.f1269i);
    }

    /* renamed from: s */
    public boolean mo1778s() {
        return this.f1264d;
    }

    public void setMinimumHeight(int i) {
        this.f1266f = i;
        super.setMinimumHeight(i);
    }

    public void setMinimumWidth(int i) {
        this.f1265e = i;
        super.setMinimumWidth(i);
    }

    public void setPadding(int i, int i2, int i3, int i4) {
    }

    public void setPaddingRelative(int i, int i2, int i3, int i4) {
    }

    /* renamed from: t */
    public float mo1783t() {
        return ((C0314a) f1262b).mo1792d(this.f1269i);
    }

    /* renamed from: u */
    public boolean mo1784u() {
        return this.f1263c;
    }

    /* renamed from: v */
    public void mo1785v(int i, int i2, int i3, int i4) {
        this.f1267g.set(i, i2, i3, i4);
        ((C0314a) f1262b).mo1794f(this.f1269i);
    }
}
