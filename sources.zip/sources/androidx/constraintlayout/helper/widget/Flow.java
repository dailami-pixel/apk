package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import androidx.constraintlayout.widget.C0411c;
import androidx.constraintlayout.widget.C0418e;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.VirtualLayout;
import p098d.p113e.p116b.p117i.C4662e;
import p098d.p113e.p116b.p117i.C4665g;
import p098d.p113e.p116b.p117i.C4669j;
import p098d.p113e.p116b.p117i.C4671l;

public class Flow extends VirtualLayout {

    /* renamed from: j */
    private C4665g f1284j;

    public Flow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public Flow(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* access modifiers changed from: protected */
    /* renamed from: l */
    public void mo1809l(AttributeSet attributeSet) {
        super.mo1809l(attributeSet);
        this.f1284j = new C4665g();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C0418e.f1992b);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 0) {
                    this.f1284j.mo21684u1(obtainStyledAttributes.getInt(index, 0));
                } else if (index == 1) {
                    this.f1284j.mo21714E0(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == 11) {
                    this.f1284j.mo21719J0(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == 12) {
                    this.f1284j.mo21716G0(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == 2) {
                    this.f1284j.mo21717H0(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == 3) {
                    this.f1284j.mo21720K0(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == 4) {
                    this.f1284j.mo21718I0(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == 5) {
                    this.f1284j.mo21715F0(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == 37) {
                    this.f1284j.mo21690z1(obtainStyledAttributes.getInt(index, 0));
                } else if (index == 27) {
                    this.f1284j.mo21678o1(obtainStyledAttributes.getInt(index, 0));
                } else if (index == 36) {
                    this.f1284j.mo21688y1(obtainStyledAttributes.getInt(index, 0));
                } else if (index == 21) {
                    this.f1284j.mo21672i1(obtainStyledAttributes.getInt(index, 0));
                } else if (index == 29) {
                    this.f1284j.mo21680q1(obtainStyledAttributes.getInt(index, 0));
                } else if (index == 23) {
                    this.f1284j.mo21674k1(obtainStyledAttributes.getInt(index, 0));
                } else if (index == 31) {
                    this.f1284j.mo21682s1(obtainStyledAttributes.getInt(index, 0));
                } else if (index == 25) {
                    this.f1284j.mo21676m1(obtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == 20) {
                    this.f1284j.mo21671h1(obtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == 28) {
                    this.f1284j.mo21679p1(obtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == 22) {
                    this.f1284j.mo21673j1(obtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == 30) {
                    this.f1284j.mo21681r1(obtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == 34) {
                    this.f1284j.mo21686w1(obtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == 24) {
                    this.f1284j.mo21675l1(obtainStyledAttributes.getInt(index, 2));
                } else if (index == 33) {
                    this.f1284j.mo21685v1(obtainStyledAttributes.getInt(index, 2));
                } else if (index == 26) {
                    this.f1284j.mo21677n1(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == 35) {
                    this.f1284j.mo21687x1(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == 32) {
                    this.f1284j.mo21683t1(obtainStyledAttributes.getInt(index, -1));
                }
            }
        }
        this.f1755d = this.f1284j;
        mo2012v();
    }

    /* renamed from: m */
    public void mo1810m(C0411c.C0412a aVar, C4669j jVar, ConstraintLayout.LayoutParams layoutParams, SparseArray<C4662e> sparseArray) {
        super.mo1810m(aVar, jVar, layoutParams, sparseArray);
        if (jVar instanceof C4665g) {
            C4665g gVar = (C4665g) jVar;
            int i = layoutParams.f1793R;
            if (i != -1) {
                gVar.mo21684u1(i);
            }
        }
    }

    /* renamed from: n */
    public void mo1811n(C4662e eVar, boolean z) {
        this.f1284j.mo21721s0(z);
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        mo1813w(this.f1284j, i, i2);
    }

    /* renamed from: w */
    public void mo1813w(C4671l lVar, int i, int i2) {
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int size2 = View.MeasureSpec.getSize(i2);
        if (lVar != null) {
            lVar.mo21689z0(mode, size, mode2, size2);
            setMeasuredDimension(lVar.mo21723u0(), lVar.mo21722t0());
            return;
        }
        setMeasuredDimension(0, 0);
    }
}
