package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.widget.C0418e;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import p098d.p113e.p116b.p117i.C4662e;

public class Layer extends ConstraintHelper {

    /* renamed from: h */
    private float f1285h = Float.NaN;

    /* renamed from: i */
    private float f1286i = Float.NaN;

    /* renamed from: j */
    private float f1287j = Float.NaN;

    /* renamed from: k */
    ConstraintLayout f1288k;

    /* renamed from: l */
    private float f1289l = 1.0f;

    /* renamed from: m */
    private float f1290m = 1.0f;

    /* renamed from: n */
    protected float f1291n = Float.NaN;

    /* renamed from: o */
    protected float f1292o = Float.NaN;

    /* renamed from: p */
    protected float f1293p = Float.NaN;

    /* renamed from: q */
    protected float f1294q = Float.NaN;

    /* renamed from: r */
    protected float f1295r = Float.NaN;

    /* renamed from: s */
    protected float f1296s = Float.NaN;

    /* renamed from: t */
    boolean f1297t = true;

    /* renamed from: u */
    View[] f1298u = null;

    /* renamed from: v */
    private float f1299v = 0.0f;

    /* renamed from: w */
    private float f1300w = 0.0f;

    /* renamed from: x */
    private boolean f1301x;

    /* renamed from: y */
    private boolean f1302y;

    public Layer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public Layer(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* renamed from: x */
    private void m1450x() {
        int i;
        if (this.f1288k != null && (i = this.f1753b) != 0) {
            View[] viewArr = this.f1298u;
            if (viewArr == null || viewArr.length != i) {
                this.f1298u = new View[i];
            }
            for (int i2 = 0; i2 < this.f1753b; i2++) {
                this.f1298u[i2] = this.f1288k.mo2023j(this.f1752a[i2]);
            }
        }
    }

    /* renamed from: y */
    private void m1451y() {
        if (this.f1288k != null) {
            if (this.f1298u == null) {
                m1450x();
            }
            mo1826w();
            double radians = Math.toRadians((double) this.f1287j);
            float sin = (float) Math.sin(radians);
            float cos = (float) Math.cos(radians);
            float f = this.f1289l;
            float f2 = f * cos;
            float f3 = this.f1290m;
            float f4 = (-f3) * sin;
            float f5 = f * sin;
            float f6 = f3 * cos;
            for (int i = 0; i < this.f1753b; i++) {
                View view = this.f1298u[i];
                int left = view.getLeft();
                int top = view.getTop();
                float right = ((float) ((view.getRight() + left) / 2)) - this.f1291n;
                float bottom = ((float) ((view.getBottom() + top) / 2)) - this.f1292o;
                view.setTranslationX((((f4 * bottom) + (f2 * right)) - right) + this.f1299v);
                view.setTranslationY((((f6 * bottom) + (right * f5)) - bottom) + this.f1300w);
                view.setScaleY(this.f1290m);
                view.setScaleX(this.f1289l);
                view.setRotation(this.f1287j);
            }
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: l */
    public void mo1809l(AttributeSet attributeSet) {
        super.mo1809l(attributeSet);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C0418e.f1992b);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 6) {
                    this.f1301x = true;
                } else if (index == 13) {
                    this.f1302y = true;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f1288k = (ConstraintLayout) getParent();
        if (this.f1301x || this.f1302y) {
            int visibility = getVisibility();
            float elevation = getElevation();
            for (int i = 0; i < this.f1753b; i++) {
                View j = this.f1288k.mo2023j(this.f1752a[i]);
                if (j != null) {
                    if (this.f1301x) {
                        j.setVisibility(visibility);
                    }
                    if (this.f1302y && elevation > 0.0f) {
                        j.setTranslationZ(j.getTranslationZ() + elevation);
                    }
                }
            }
        }
    }

    /* renamed from: q */
    public void mo1815q(ConstraintLayout constraintLayout) {
        m1450x();
        this.f1291n = Float.NaN;
        this.f1292o = Float.NaN;
        C4662e a = ((ConstraintLayout.LayoutParams) getLayoutParams()).mo2034a();
        a.mo21641n0(0);
        a.mo21619Y(0);
        mo1826w();
        layout(((int) this.f1295r) - getPaddingLeft(), ((int) this.f1296s) - getPaddingTop(), getPaddingRight() + ((int) this.f1293p), getPaddingBottom() + ((int) this.f1294q));
        if (!Float.isNaN(this.f1287j)) {
            m1451y();
        }
    }

    /* renamed from: s */
    public void mo1816s(ConstraintLayout constraintLayout) {
        this.f1288k = constraintLayout;
        float rotation = getRotation();
        if (rotation != 0.0f || !Float.isNaN(this.f1287j)) {
            this.f1287j = rotation;
        }
    }

    public void setElevation(float f) {
        super.setElevation(f);
        mo2003g();
    }

    public void setPivotX(float f) {
        this.f1285h = f;
        m1451y();
    }

    public void setPivotY(float f) {
        this.f1286i = f;
        m1451y();
    }

    public void setRotation(float f) {
        this.f1287j = f;
        m1451y();
    }

    public void setScaleX(float f) {
        this.f1289l = f;
        m1451y();
    }

    public void setScaleY(float f) {
        this.f1290m = f;
        m1451y();
    }

    public void setTranslationX(float f) {
        this.f1299v = f;
        m1451y();
    }

    public void setTranslationY(float f) {
        this.f1300w = f;
        m1451y();
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        mo2003g();
    }

    /* access modifiers changed from: protected */
    /* renamed from: w */
    public void mo1826w() {
        if (this.f1288k != null) {
            if (!this.f1297t && !Float.isNaN(this.f1291n) && !Float.isNaN(this.f1292o)) {
                return;
            }
            if (Float.isNaN(this.f1285h) || Float.isNaN(this.f1286i)) {
                View[] k = mo2005k(this.f1288k);
                int left = k[0].getLeft();
                int top = k[0].getTop();
                int right = k[0].getRight();
                int bottom = k[0].getBottom();
                for (int i = 0; i < this.f1753b; i++) {
                    View view = k[i];
                    left = Math.min(left, view.getLeft());
                    top = Math.min(top, view.getTop());
                    right = Math.max(right, view.getRight());
                    bottom = Math.max(bottom, view.getBottom());
                }
                this.f1293p = (float) right;
                this.f1294q = (float) bottom;
                this.f1295r = (float) left;
                this.f1296s = (float) top;
                this.f1291n = Float.isNaN(this.f1285h) ? (float) ((left + right) / 2) : this.f1285h;
                this.f1292o = Float.isNaN(this.f1286i) ? (float) ((top + bottom) / 2) : this.f1286i;
                return;
            }
            this.f1292o = this.f1286i;
            this.f1291n = this.f1285h;
        }
    }
}
