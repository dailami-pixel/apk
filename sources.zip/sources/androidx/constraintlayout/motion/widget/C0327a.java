package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.util.AttributeSet;
import androidx.constraintlayout.widget.C0407a;
import java.util.HashMap;
import java.util.HashSet;

/* renamed from: androidx.constraintlayout.motion.widget.a */
public abstract class C0327a {

    /* renamed from: a */
    int f1398a = -1;

    /* renamed from: b */
    int f1399b = -1;

    /* renamed from: c */
    String f1400c = null;

    /* renamed from: d */
    HashMap<String, C0407a> f1401d;

    /* renamed from: a */
    public abstract void mo1877a(HashMap<String, C0367q> hashMap);

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public abstract void mo1878b(HashSet<String> hashSet);

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public abstract void mo1879c(Context context, AttributeSet attributeSet);

    /* renamed from: d */
    public void mo1880d(HashMap<String, Integer> hashMap) {
    }
}
