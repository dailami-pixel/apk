package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import androidx.constraintlayout.widget.C0418e;
import java.util.HashMap;
import java.util.HashSet;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.constraintlayout.motion.widget.b */
public class C0328b extends C0327a {
    /* access modifiers changed from: private */

    /* renamed from: e */
    public int f1402e = -1;
    /* access modifiers changed from: private */

    /* renamed from: f */
    public float f1403f = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: g */
    public float f1404g = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: h */
    public float f1405h = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: i */
    public float f1406i = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: j */
    public float f1407j = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: k */
    public float f1408k = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: l */
    public float f1409l = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: m */
    public float f1410m = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: n */
    public float f1411n = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: o */
    public float f1412o = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: p */
    public float f1413p = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: q */
    public float f1414q = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: r */
    public float f1415r = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: s */
    public float f1416s = Float.NaN;

    /* renamed from: androidx.constraintlayout.motion.widget.b$a */
    private static class C0329a {

        /* renamed from: a */
        private static SparseIntArray f1417a;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1417a = sparseIntArray;
            sparseIntArray.append(0, 1);
            f1417a.append(11, 2);
            f1417a.append(7, 4);
            f1417a.append(8, 5);
            f1417a.append(9, 6);
            f1417a.append(1, 19);
            f1417a.append(2, 20);
            f1417a.append(5, 7);
            f1417a.append(17, 8);
            f1417a.append(16, 9);
            f1417a.append(15, 10);
            f1417a.append(13, 12);
            f1417a.append(12, 13);
            f1417a.append(6, 14);
            f1417a.append(3, 15);
            f1417a.append(4, 16);
            f1417a.append(10, 17);
            f1417a.append(14, 18);
        }

        /* renamed from: a */
        public static void m1570a(C0328b bVar, TypedArray typedArray) {
            int indexCount = typedArray.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArray.getIndex(i);
                switch (f1417a.get(index)) {
                    case 1:
                        float unused = bVar.f1403f = typedArray.getFloat(index, bVar.f1403f);
                        break;
                    case 2:
                        float unused2 = bVar.f1404g = typedArray.getDimension(index, bVar.f1404g);
                        break;
                    case 4:
                        float unused3 = bVar.f1405h = typedArray.getFloat(index, bVar.f1405h);
                        break;
                    case 5:
                        float unused4 = bVar.f1406i = typedArray.getFloat(index, bVar.f1406i);
                        break;
                    case 6:
                        float unused5 = bVar.f1407j = typedArray.getFloat(index, bVar.f1407j);
                        break;
                    case 7:
                        float unused6 = bVar.f1411n = typedArray.getFloat(index, bVar.f1411n);
                        break;
                    case 8:
                        float unused7 = bVar.f1410m = typedArray.getFloat(index, bVar.f1410m);
                        break;
                    case 9:
                        typedArray.getString(index);
                        break;
                    case 10:
                        if (!MotionLayout.f1305r) {
                            if (typedArray.peekValue(index).type != 3) {
                                bVar.f1399b = typedArray.getResourceId(index, bVar.f1399b);
                                break;
                            }
                        } else {
                            int resourceId = typedArray.getResourceId(index, bVar.f1399b);
                            bVar.f1399b = resourceId;
                            if (resourceId != -1) {
                                break;
                            }
                        }
                        bVar.f1400c = typedArray.getString(index);
                        break;
                    case 12:
                        bVar.f1398a = typedArray.getInt(index, bVar.f1398a);
                        break;
                    case 13:
                        int unused8 = bVar.f1402e = typedArray.getInteger(index, bVar.f1402e);
                        break;
                    case 14:
                        float unused9 = bVar.f1412o = typedArray.getFloat(index, bVar.f1412o);
                        break;
                    case 15:
                        float unused10 = bVar.f1413p = typedArray.getDimension(index, bVar.f1413p);
                        break;
                    case 16:
                        float unused11 = bVar.f1414q = typedArray.getDimension(index, bVar.f1414q);
                        break;
                    case 17:
                        float unused12 = bVar.f1415r = typedArray.getDimension(index, bVar.f1415r);
                        break;
                    case 18:
                        float unused13 = bVar.f1416s = typedArray.getFloat(index, bVar.f1416s);
                        break;
                    case 19:
                        float unused14 = bVar.f1408k = typedArray.getDimension(index, bVar.f1408k);
                        break;
                    case 20:
                        float unused15 = bVar.f1409l = typedArray.getDimension(index, bVar.f1409l);
                        break;
                    default:
                        StringBuilder P = C4924a.m17863P("unused attribute 0x");
                        P.append(Integer.toHexString(index));
                        P.append("   ");
                        P.append(f1417a.get(index));
                        Log.e("KeyAttribute", P.toString());
                        break;
                }
            }
        }
    }

    public C0328b() {
        this.f1401d = new HashMap<>();
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x009e, code lost:
        if (r1.equals("scaleY") == false) goto L_0x00ee;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:96:0x01ca, code lost:
        r2.mo1955c(r1, r3);
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1877a(java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.C0367q> r6) {
        /*
            r5 = this;
            java.util.Set r0 = r6.keySet()
            java.util.Iterator r0 = r0.iterator()
        L_0x0008:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x01cf
            java.lang.Object r1 = r0.next()
            java.lang.String r1 = (java.lang.String) r1
            java.lang.Object r2 = r6.get(r1)
            androidx.constraintlayout.motion.widget.q r2 = (androidx.constraintlayout.motion.widget.C0367q) r2
            java.lang.String r3 = "CUSTOM"
            boolean r3 = r1.startsWith(r3)
            r4 = 7
            if (r3 == 0) goto L_0x003b
            java.lang.String r1 = r1.substring(r4)
            java.util.HashMap<java.lang.String, androidx.constraintlayout.widget.a> r3 = r5.f1401d
            java.lang.Object r1 = r3.get(r1)
            androidx.constraintlayout.widget.a r1 = (androidx.constraintlayout.widget.C0407a) r1
            if (r1 == 0) goto L_0x0008
            androidx.constraintlayout.motion.widget.q$b r2 = (androidx.constraintlayout.motion.widget.C0367q.C0369b) r2
            int r3 = r5.f1398a
            android.util.SparseArray<androidx.constraintlayout.widget.a> r2 = r2.f1659f
            r2.append(r3, r1)
            goto L_0x0008
        L_0x003b:
            int r3 = r1.hashCode()
            switch(r3) {
                case -1249320806: goto L_0x00e3;
                case -1249320805: goto L_0x00d8;
                case -1225497657: goto L_0x00cd;
                case -1225497656: goto L_0x00c2;
                case -1225497655: goto L_0x00b7;
                case -1001078227: goto L_0x00ac;
                case -908189618: goto L_0x00a1;
                case -908189617: goto L_0x0098;
                case -760884510: goto L_0x008a;
                case -760884509: goto L_0x007c;
                case -40300674: goto L_0x006e;
                case -4379043: goto L_0x0060;
                case 37232917: goto L_0x0052;
                case 92909918: goto L_0x0044;
                default: goto L_0x0042;
            }
        L_0x0042:
            goto L_0x00ee
        L_0x0044:
            java.lang.String r3 = "alpha"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x004e
            goto L_0x00ee
        L_0x004e:
            r4 = 13
            goto L_0x00ef
        L_0x0052:
            java.lang.String r3 = "transitionPathRotate"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x005c
            goto L_0x00ee
        L_0x005c:
            r4 = 12
            goto L_0x00ef
        L_0x0060:
            java.lang.String r3 = "elevation"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x006a
            goto L_0x00ee
        L_0x006a:
            r4 = 11
            goto L_0x00ef
        L_0x006e:
            java.lang.String r3 = "rotation"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x0078
            goto L_0x00ee
        L_0x0078:
            r4 = 10
            goto L_0x00ef
        L_0x007c:
            java.lang.String r3 = "transformPivotY"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x0086
            goto L_0x00ee
        L_0x0086:
            r4 = 9
            goto L_0x00ef
        L_0x008a:
            java.lang.String r3 = "transformPivotX"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x0094
            goto L_0x00ee
        L_0x0094:
            r4 = 8
            goto L_0x00ef
        L_0x0098:
            java.lang.String r3 = "scaleY"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x00ef
            goto L_0x00ee
        L_0x00a1:
            java.lang.String r3 = "scaleX"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x00aa
            goto L_0x00ee
        L_0x00aa:
            r4 = 6
            goto L_0x00ef
        L_0x00ac:
            java.lang.String r3 = "progress"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x00b5
            goto L_0x00ee
        L_0x00b5:
            r4 = 5
            goto L_0x00ef
        L_0x00b7:
            java.lang.String r3 = "translationZ"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x00c0
            goto L_0x00ee
        L_0x00c0:
            r4 = 4
            goto L_0x00ef
        L_0x00c2:
            java.lang.String r3 = "translationY"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x00cb
            goto L_0x00ee
        L_0x00cb:
            r4 = 3
            goto L_0x00ef
        L_0x00cd:
            java.lang.String r3 = "translationX"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x00d6
            goto L_0x00ee
        L_0x00d6:
            r4 = 2
            goto L_0x00ef
        L_0x00d8:
            java.lang.String r3 = "rotationY"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x00e1
            goto L_0x00ee
        L_0x00e1:
            r4 = 1
            goto L_0x00ef
        L_0x00e3:
            java.lang.String r3 = "rotationX"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x00ec
            goto L_0x00ee
        L_0x00ec:
            r4 = 0
            goto L_0x00ef
        L_0x00ee:
            r4 = -1
        L_0x00ef:
            switch(r4) {
                case 0: goto L_0x01be;
                case 1: goto L_0x01b1;
                case 2: goto L_0x01a4;
                case 3: goto L_0x0197;
                case 4: goto L_0x018a;
                case 5: goto L_0x017d;
                case 6: goto L_0x0170;
                case 7: goto L_0x0163;
                case 8: goto L_0x0155;
                case 9: goto L_0x0147;
                case 10: goto L_0x0139;
                case 11: goto L_0x012b;
                case 12: goto L_0x011d;
                case 13: goto L_0x010f;
                default: goto L_0x00f2;
            }
        L_0x00f2:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "UNKNOWN addValues \""
            r2.append(r3)
            r2.append(r1)
            java.lang.String r1 = "\""
            r2.append(r1)
            java.lang.String r1 = r2.toString()
            java.lang.String r2 = "KeyAttributes"
            android.util.Log.v(r2, r1)
            goto L_0x0008
        L_0x010f:
            float r1 = r5.f1403f
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1403f
            goto L_0x01ca
        L_0x011d:
            float r1 = r5.f1410m
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1410m
            goto L_0x01ca
        L_0x012b:
            float r1 = r5.f1404g
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1404g
            goto L_0x01ca
        L_0x0139:
            float r1 = r5.f1405h
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1405h
            goto L_0x01ca
        L_0x0147:
            float r1 = r5.f1407j
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1409l
            goto L_0x01ca
        L_0x0155:
            float r1 = r5.f1406i
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1408k
            goto L_0x01ca
        L_0x0163:
            float r1 = r5.f1412o
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1412o
            goto L_0x01ca
        L_0x0170:
            float r1 = r5.f1411n
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1411n
            goto L_0x01ca
        L_0x017d:
            float r1 = r5.f1416s
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1416s
            goto L_0x01ca
        L_0x018a:
            float r1 = r5.f1415r
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1415r
            goto L_0x01ca
        L_0x0197:
            float r1 = r5.f1414q
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1414q
            goto L_0x01ca
        L_0x01a4:
            float r1 = r5.f1413p
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1413p
            goto L_0x01ca
        L_0x01b1:
            float r1 = r5.f1407j
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1407j
            goto L_0x01ca
        L_0x01be:
            float r1 = r5.f1406i
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r5.f1398a
            float r3 = r5.f1406i
        L_0x01ca:
            r2.mo1955c(r1, r3)
            goto L_0x0008
        L_0x01cf:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.C0328b.mo1877a(java.util.HashMap):void");
    }

    /* renamed from: b */
    public void mo1878b(HashSet<String> hashSet) {
        if (!Float.isNaN(this.f1403f)) {
            hashSet.add("alpha");
        }
        if (!Float.isNaN(this.f1404g)) {
            hashSet.add("elevation");
        }
        if (!Float.isNaN(this.f1405h)) {
            hashSet.add("rotation");
        }
        if (!Float.isNaN(this.f1406i)) {
            hashSet.add("rotationX");
        }
        if (!Float.isNaN(this.f1407j)) {
            hashSet.add("rotationY");
        }
        if (!Float.isNaN(this.f1408k)) {
            hashSet.add("transformPivotX");
        }
        if (!Float.isNaN(this.f1409l)) {
            hashSet.add("transformPivotY");
        }
        if (!Float.isNaN(this.f1413p)) {
            hashSet.add("translationX");
        }
        if (!Float.isNaN(this.f1414q)) {
            hashSet.add("translationY");
        }
        if (!Float.isNaN(this.f1415r)) {
            hashSet.add("translationZ");
        }
        if (!Float.isNaN(this.f1410m)) {
            hashSet.add("transitionPathRotate");
        }
        if (!Float.isNaN(this.f1411n)) {
            hashSet.add("scaleX");
        }
        if (!Float.isNaN(this.f1411n)) {
            hashSet.add("scaleY");
        }
        if (!Float.isNaN(this.f1416s)) {
            hashSet.add("progress");
        }
        if (this.f1401d.size() > 0) {
            for (String str : this.f1401d.keySet()) {
                hashSet.add("CUSTOM," + str);
            }
        }
    }

    /* renamed from: c */
    public void mo1879c(Context context, AttributeSet attributeSet) {
        C0329a.m1570a(this, context.obtainStyledAttributes(attributeSet, C0418e.f1997g));
    }

    /* renamed from: d */
    public void mo1880d(HashMap<String, Integer> hashMap) {
        if (this.f1402e != -1) {
            if (!Float.isNaN(this.f1403f)) {
                hashMap.put("alpha", Integer.valueOf(this.f1402e));
            }
            if (!Float.isNaN(this.f1404g)) {
                hashMap.put("elevation", Integer.valueOf(this.f1402e));
            }
            if (!Float.isNaN(this.f1405h)) {
                hashMap.put("rotation", Integer.valueOf(this.f1402e));
            }
            if (!Float.isNaN(this.f1406i)) {
                hashMap.put("rotationX", Integer.valueOf(this.f1402e));
            }
            if (!Float.isNaN(this.f1407j)) {
                hashMap.put("rotationY", Integer.valueOf(this.f1402e));
            }
            if (!Float.isNaN(this.f1408k)) {
                hashMap.put("transformPivotX", Integer.valueOf(this.f1402e));
            }
            if (!Float.isNaN(this.f1409l)) {
                hashMap.put("transformPivotY", Integer.valueOf(this.f1402e));
            }
            if (!Float.isNaN(this.f1413p)) {
                hashMap.put("translationX", Integer.valueOf(this.f1402e));
            }
            if (!Float.isNaN(this.f1414q)) {
                hashMap.put("translationY", Integer.valueOf(this.f1402e));
            }
            if (!Float.isNaN(this.f1415r)) {
                hashMap.put("translationZ", Integer.valueOf(this.f1402e));
            }
            if (!Float.isNaN(this.f1410m)) {
                hashMap.put("transitionPathRotate", Integer.valueOf(this.f1402e));
            }
            if (!Float.isNaN(this.f1411n)) {
                hashMap.put("scaleX", Integer.valueOf(this.f1402e));
            }
            if (!Float.isNaN(this.f1412o)) {
                hashMap.put("scaleY", Integer.valueOf(this.f1402e));
            }
            if (!Float.isNaN(this.f1416s)) {
                hashMap.put("progress", Integer.valueOf(this.f1402e));
            }
            if (this.f1401d.size() > 0) {
                for (String v : this.f1401d.keySet()) {
                    hashMap.put(C4924a.m17907v("CUSTOM,", v), Integer.valueOf(this.f1402e));
                }
            }
        }
    }
}
