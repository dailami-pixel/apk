package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import androidx.constraintlayout.widget.C0418e;
import java.util.HashMap;
import java.util.HashSet;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.constraintlayout.motion.widget.d */
public class C0331d extends C0327a {
    /* access modifiers changed from: private */

    /* renamed from: e */
    public int f1419e = 0;
    /* access modifiers changed from: private */

    /* renamed from: f */
    public int f1420f = -1;
    /* access modifiers changed from: private */

    /* renamed from: g */
    public float f1421g = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: h */
    public float f1422h = 0.0f;
    /* access modifiers changed from: private */

    /* renamed from: i */
    public float f1423i = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: j */
    public int f1424j = -1;
    /* access modifiers changed from: private */

    /* renamed from: k */
    public float f1425k = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: l */
    public float f1426l = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: m */
    public float f1427m = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: n */
    public float f1428n = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: o */
    public float f1429o = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: p */
    public float f1430p = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: q */
    public float f1431q = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: r */
    public float f1432r = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: s */
    public float f1433s = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: t */
    public float f1434t = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: u */
    public float f1435u = Float.NaN;

    /* renamed from: androidx.constraintlayout.motion.widget.d$a */
    private static class C0332a {

        /* renamed from: a */
        private static SparseIntArray f1436a;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1436a = sparseIntArray;
            sparseIntArray.append(13, 1);
            f1436a.append(11, 2);
            f1436a.append(14, 3);
            f1436a.append(10, 4);
            f1436a.append(18, 5);
            f1436a.append(17, 6);
            f1436a.append(16, 7);
            f1436a.append(19, 8);
            f1436a.append(0, 9);
            f1436a.append(9, 10);
            f1436a.append(5, 11);
            f1436a.append(6, 12);
            f1436a.append(7, 13);
            f1436a.append(15, 14);
            f1436a.append(3, 15);
            f1436a.append(4, 16);
            f1436a.append(1, 17);
            f1436a.append(2, 18);
            f1436a.append(8, 19);
            f1436a.append(12, 20);
        }

        /* renamed from: a */
        static void m1609a(C0331d dVar, TypedArray typedArray) {
            int indexCount = typedArray.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArray.getIndex(i);
                switch (f1436a.get(index)) {
                    case 1:
                        if (!MotionLayout.f1305r) {
                            if (typedArray.peekValue(index).type != 3) {
                                dVar.f1399b = typedArray.getResourceId(index, dVar.f1399b);
                                break;
                            }
                        } else {
                            int resourceId = typedArray.getResourceId(index, dVar.f1399b);
                            dVar.f1399b = resourceId;
                            if (resourceId != -1) {
                                break;
                            }
                        }
                        dVar.f1400c = typedArray.getString(index);
                        break;
                    case 2:
                        dVar.f1398a = typedArray.getInt(index, dVar.f1398a);
                        break;
                    case 3:
                        typedArray.getString(index);
                        break;
                    case 4:
                        int unused = dVar.f1419e = typedArray.getInteger(index, dVar.f1419e);
                        break;
                    case 5:
                        int unused2 = dVar.f1420f = typedArray.getInt(index, dVar.f1420f);
                        break;
                    case 6:
                        float unused3 = dVar.f1421g = typedArray.getFloat(index, dVar.f1421g);
                        break;
                    case 7:
                        float unused4 = dVar.f1422h = typedArray.peekValue(index).type == 5 ? typedArray.getDimension(index, dVar.f1422h) : typedArray.getFloat(index, dVar.f1422h);
                        break;
                    case 8:
                        int unused5 = dVar.f1424j = typedArray.getInt(index, dVar.f1424j);
                        break;
                    case 9:
                        float unused6 = dVar.f1425k = typedArray.getFloat(index, dVar.f1425k);
                        break;
                    case 10:
                        float unused7 = dVar.f1426l = typedArray.getDimension(index, dVar.f1426l);
                        break;
                    case 11:
                        float unused8 = dVar.f1427m = typedArray.getFloat(index, dVar.f1427m);
                        break;
                    case 12:
                        float unused9 = dVar.f1429o = typedArray.getFloat(index, dVar.f1429o);
                        break;
                    case 13:
                        float unused10 = dVar.f1430p = typedArray.getFloat(index, dVar.f1430p);
                        break;
                    case 14:
                        float unused11 = dVar.f1428n = typedArray.getFloat(index, dVar.f1428n);
                        break;
                    case 15:
                        float unused12 = dVar.f1431q = typedArray.getFloat(index, dVar.f1431q);
                        break;
                    case 16:
                        float unused13 = dVar.f1432r = typedArray.getFloat(index, dVar.f1432r);
                        break;
                    case 17:
                        float unused14 = dVar.f1433s = typedArray.getDimension(index, dVar.f1433s);
                        break;
                    case 18:
                        float unused15 = dVar.f1434t = typedArray.getDimension(index, dVar.f1434t);
                        break;
                    case 19:
                        float unused16 = dVar.f1435u = typedArray.getDimension(index, dVar.f1435u);
                        break;
                    case 20:
                        float unused17 = dVar.f1423i = typedArray.getFloat(index, dVar.f1423i);
                        break;
                    default:
                        StringBuilder P = C4924a.m17863P("unused attribute 0x");
                        P.append(Integer.toHexString(index));
                        P.append("   ");
                        P.append(f1436a.get(index));
                        Log.e("KeyCycle", P.toString());
                        break;
                }
            }
        }
    }

    public C0331d() {
        this.f1401d = new HashMap<>();
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x00a0, code lost:
        if (r1.equals("scaleY") == false) goto L_0x00f0;
     */
    /* renamed from: M */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1881M(java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.C0333e> r14) {
        /*
            r13 = this;
            java.util.Set r0 = r14.keySet()
            java.util.Iterator r0 = r0.iterator()
        L_0x0008:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0152
            java.lang.Object r1 = r0.next()
            java.lang.String r1 = (java.lang.String) r1
            java.lang.String r2 = "CUSTOM"
            boolean r2 = r1.startsWith(r2)
            r3 = 7
            r4 = 2
            if (r2 == 0) goto L_0x004b
            java.lang.String r2 = r1.substring(r3)
            java.util.HashMap<java.lang.String, androidx.constraintlayout.widget.a> r5 = r13.f1401d
            java.lang.Object r2 = r5.get(r2)
            r12 = r2
            androidx.constraintlayout.widget.a r12 = (androidx.constraintlayout.widget.C0407a) r12
            if (r12 == 0) goto L_0x004b
            int r2 = r12.mo2054b()
            if (r2 != r4) goto L_0x004b
            java.lang.Object r2 = r14.get(r1)
            r5 = r2
            androidx.constraintlayout.motion.widget.e r5 = (androidx.constraintlayout.motion.widget.C0333e) r5
            int r6 = r13.f1398a
            int r7 = r13.f1420f
            int r8 = r13.f1424j
            float r9 = r13.f1421g
            float r10 = r13.f1422h
            float r11 = r12.mo2055c()
            r5.mo1885d(r6, r7, r8, r9, r10, r11, r12)
        L_0x004b:
            int r2 = r1.hashCode()
            switch(r2) {
                case -1249320806: goto L_0x00e5;
                case -1249320805: goto L_0x00da;
                case -1225497657: goto L_0x00cf;
                case -1225497656: goto L_0x00c4;
                case -1225497655: goto L_0x00b9;
                case -1001078227: goto L_0x00ae;
                case -908189618: goto L_0x00a3;
                case -908189617: goto L_0x009a;
                case -40300674: goto L_0x008c;
                case -4379043: goto L_0x007e;
                case 37232917: goto L_0x0070;
                case 92909918: goto L_0x0062;
                case 156108012: goto L_0x0054;
                default: goto L_0x0052;
            }
        L_0x0052:
            goto L_0x00f0
        L_0x0054:
            java.lang.String r2 = "waveOffset"
            boolean r2 = r1.equals(r2)
            if (r2 != 0) goto L_0x005e
            goto L_0x00f0
        L_0x005e:
            r3 = 12
            goto L_0x00f1
        L_0x0062:
            java.lang.String r2 = "alpha"
            boolean r2 = r1.equals(r2)
            if (r2 != 0) goto L_0x006c
            goto L_0x00f0
        L_0x006c:
            r3 = 11
            goto L_0x00f1
        L_0x0070:
            java.lang.String r2 = "transitionPathRotate"
            boolean r2 = r1.equals(r2)
            if (r2 != 0) goto L_0x007a
            goto L_0x00f0
        L_0x007a:
            r3 = 10
            goto L_0x00f1
        L_0x007e:
            java.lang.String r2 = "elevation"
            boolean r2 = r1.equals(r2)
            if (r2 != 0) goto L_0x0088
            goto L_0x00f0
        L_0x0088:
            r3 = 9
            goto L_0x00f1
        L_0x008c:
            java.lang.String r2 = "rotation"
            boolean r2 = r1.equals(r2)
            if (r2 != 0) goto L_0x0096
            goto L_0x00f0
        L_0x0096:
            r3 = 8
            goto L_0x00f1
        L_0x009a:
            java.lang.String r2 = "scaleY"
            boolean r2 = r1.equals(r2)
            if (r2 != 0) goto L_0x00f1
            goto L_0x00f0
        L_0x00a3:
            java.lang.String r2 = "scaleX"
            boolean r2 = r1.equals(r2)
            if (r2 != 0) goto L_0x00ac
            goto L_0x00f0
        L_0x00ac:
            r3 = 6
            goto L_0x00f1
        L_0x00ae:
            java.lang.String r2 = "progress"
            boolean r2 = r1.equals(r2)
            if (r2 != 0) goto L_0x00b7
            goto L_0x00f0
        L_0x00b7:
            r3 = 5
            goto L_0x00f1
        L_0x00b9:
            java.lang.String r2 = "translationZ"
            boolean r2 = r1.equals(r2)
            if (r2 != 0) goto L_0x00c2
            goto L_0x00f0
        L_0x00c2:
            r3 = 4
            goto L_0x00f1
        L_0x00c4:
            java.lang.String r2 = "translationY"
            boolean r2 = r1.equals(r2)
            if (r2 != 0) goto L_0x00cd
            goto L_0x00f0
        L_0x00cd:
            r3 = 3
            goto L_0x00f1
        L_0x00cf:
            java.lang.String r2 = "translationX"
            boolean r2 = r1.equals(r2)
            if (r2 != 0) goto L_0x00d8
            goto L_0x00f0
        L_0x00d8:
            r3 = 2
            goto L_0x00f1
        L_0x00da:
            java.lang.String r2 = "rotationY"
            boolean r2 = r1.equals(r2)
            if (r2 != 0) goto L_0x00e3
            goto L_0x00f0
        L_0x00e3:
            r3 = 1
            goto L_0x00f1
        L_0x00e5:
            java.lang.String r2 = "rotationX"
            boolean r2 = r1.equals(r2)
            if (r2 != 0) goto L_0x00ee
            goto L_0x00f0
        L_0x00ee:
            r3 = 0
            goto L_0x00f1
        L_0x00f0:
            r3 = -1
        L_0x00f1:
            switch(r3) {
                case 0: goto L_0x0133;
                case 1: goto L_0x0130;
                case 2: goto L_0x012d;
                case 3: goto L_0x012a;
                case 4: goto L_0x0127;
                case 5: goto L_0x0124;
                case 6: goto L_0x0121;
                case 7: goto L_0x011e;
                case 8: goto L_0x011b;
                case 9: goto L_0x0118;
                case 10: goto L_0x0115;
                case 11: goto L_0x0112;
                case 12: goto L_0x010f;
                default: goto L_0x00f4;
            }
        L_0x00f4:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "  UNKNOWN  "
            r2.append(r3)
            r2.append(r1)
            java.lang.String r2 = r2.toString()
            java.lang.String r3 = "WARNING! KeyCycle"
            android.util.Log.v(r3, r2)
            r2 = 2143289344(0x7fc00000, float:NaN)
            r9 = 2143289344(0x7fc00000, float:NaN)
            goto L_0x0136
        L_0x010f:
            float r2 = r13.f1422h
            goto L_0x0135
        L_0x0112:
            float r2 = r13.f1425k
            goto L_0x0135
        L_0x0115:
            float r2 = r13.f1428n
            goto L_0x0135
        L_0x0118:
            float r2 = r13.f1426l
            goto L_0x0135
        L_0x011b:
            float r2 = r13.f1427m
            goto L_0x0135
        L_0x011e:
            float r2 = r13.f1432r
            goto L_0x0135
        L_0x0121:
            float r2 = r13.f1431q
            goto L_0x0135
        L_0x0124:
            float r2 = r13.f1423i
            goto L_0x0135
        L_0x0127:
            float r2 = r13.f1435u
            goto L_0x0135
        L_0x012a:
            float r2 = r13.f1434t
            goto L_0x0135
        L_0x012d:
            float r2 = r13.f1433s
            goto L_0x0135
        L_0x0130:
            float r2 = r13.f1430p
            goto L_0x0135
        L_0x0133:
            float r2 = r13.f1429o
        L_0x0135:
            r9 = r2
        L_0x0136:
            boolean r2 = java.lang.Float.isNaN(r9)
            if (r2 != 0) goto L_0x0008
            java.lang.Object r1 = r14.get(r1)
            r3 = r1
            androidx.constraintlayout.motion.widget.e r3 = (androidx.constraintlayout.motion.widget.C0333e) r3
            int r4 = r13.f1398a
            int r5 = r13.f1420f
            int r6 = r13.f1424j
            float r7 = r13.f1421g
            float r8 = r13.f1422h
            r3.mo1884c(r4, r5, r6, r7, r8, r9)
            goto L_0x0008
        L_0x0152:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.C0331d.mo1881M(java.util.HashMap):void");
    }

    /* renamed from: a */
    public void mo1877a(HashMap<String, C0367q> hashMap) {
        float f;
        int i;
        StringBuilder P = C4924a.m17863P("add ");
        P.append(hashMap.size());
        P.append(" values");
        String sb = P.toString();
        StackTraceElement[] stackTrace = new Throwable().getStackTrace();
        int min = Math.min(2, stackTrace.length - 1);
        String str = " ";
        for (int i2 = 1; i2 <= min; i2++) {
            StackTraceElement stackTraceElement = stackTrace[i2];
            StringBuilder P2 = C4924a.m17863P(".(");
            P2.append(stackTrace[i2].getFileName());
            P2.append(":");
            P2.append(stackTrace[i2].getLineNumber());
            P2.append(") ");
            P2.append(stackTrace[i2].getMethodName());
            String sb2 = P2.toString();
            str = C4924a.m17907v(str, " ");
            Log.v("KeyCycle", sb + str + sb2 + str);
        }
        for (String next : hashMap.keySet()) {
            C0367q qVar = hashMap.get(next);
            next.hashCode();
            next.hashCode();
            char c = 65535;
            switch (next.hashCode()) {
                case -1249320806:
                    if (next.equals("rotationX")) {
                        c = 0;
                        break;
                    }
                    break;
                case -1249320805:
                    if (next.equals("rotationY")) {
                        c = 1;
                        break;
                    }
                    break;
                case -1225497657:
                    if (next.equals("translationX")) {
                        c = 2;
                        break;
                    }
                    break;
                case -1225497656:
                    if (next.equals("translationY")) {
                        c = 3;
                        break;
                    }
                    break;
                case -1225497655:
                    if (next.equals("translationZ")) {
                        c = 4;
                        break;
                    }
                    break;
                case -1001078227:
                    if (next.equals("progress")) {
                        c = 5;
                        break;
                    }
                    break;
                case -908189618:
                    if (next.equals("scaleX")) {
                        c = 6;
                        break;
                    }
                    break;
                case -908189617:
                    if (next.equals("scaleY")) {
                        c = 7;
                        break;
                    }
                    break;
                case -40300674:
                    if (next.equals("rotation")) {
                        c = 8;
                        break;
                    }
                    break;
                case -4379043:
                    if (next.equals("elevation")) {
                        c = 9;
                        break;
                    }
                    break;
                case 37232917:
                    if (next.equals("transitionPathRotate")) {
                        c = 10;
                        break;
                    }
                    break;
                case 92909918:
                    if (next.equals("alpha")) {
                        c = 11;
                        break;
                    }
                    break;
                case 156108012:
                    if (next.equals("waveOffset")) {
                        c = 12;
                        break;
                    }
                    break;
            }
            switch (c) {
                case 0:
                    i = this.f1398a;
                    f = this.f1429o;
                    break;
                case 1:
                    i = this.f1398a;
                    f = this.f1430p;
                    break;
                case 2:
                    i = this.f1398a;
                    f = this.f1433s;
                    break;
                case 3:
                    i = this.f1398a;
                    f = this.f1434t;
                    break;
                case 4:
                    i = this.f1398a;
                    f = this.f1435u;
                    break;
                case 5:
                    i = this.f1398a;
                    f = this.f1423i;
                    break;
                case 6:
                    i = this.f1398a;
                    f = this.f1431q;
                    break;
                case 7:
                    i = this.f1398a;
                    f = this.f1432r;
                    break;
                case 8:
                    i = this.f1398a;
                    f = this.f1427m;
                    break;
                case 9:
                    i = this.f1398a;
                    f = this.f1426l;
                    break;
                case 10:
                    i = this.f1398a;
                    f = this.f1428n;
                    break;
                case 11:
                    i = this.f1398a;
                    f = this.f1425k;
                    break;
                case 12:
                    i = this.f1398a;
                    f = this.f1422h;
                    break;
                default:
                    Log.v("WARNING KeyCycle", "  UNKNOWN  " + next);
                    continue;
            }
            qVar.mo1955c(i, f);
        }
    }

    /* renamed from: b */
    public void mo1878b(HashSet<String> hashSet) {
        if (!Float.isNaN(this.f1425k)) {
            hashSet.add("alpha");
        }
        if (!Float.isNaN(this.f1426l)) {
            hashSet.add("elevation");
        }
        if (!Float.isNaN(this.f1427m)) {
            hashSet.add("rotation");
        }
        if (!Float.isNaN(this.f1429o)) {
            hashSet.add("rotationX");
        }
        if (!Float.isNaN(this.f1430p)) {
            hashSet.add("rotationY");
        }
        if (!Float.isNaN(this.f1431q)) {
            hashSet.add("scaleX");
        }
        if (!Float.isNaN(this.f1432r)) {
            hashSet.add("scaleY");
        }
        if (!Float.isNaN(this.f1428n)) {
            hashSet.add("transitionPathRotate");
        }
        if (!Float.isNaN(this.f1433s)) {
            hashSet.add("translationX");
        }
        if (!Float.isNaN(this.f1434t)) {
            hashSet.add("translationY");
        }
        if (!Float.isNaN(this.f1435u)) {
            hashSet.add("translationZ");
        }
        if (this.f1401d.size() > 0) {
            for (String str : this.f1401d.keySet()) {
                hashSet.add("CUSTOM," + str);
            }
        }
    }

    /* renamed from: c */
    public void mo1879c(Context context, AttributeSet attributeSet) {
        C0332a.m1609a(this, context.obtainStyledAttributes(attributeSet, C0418e.f1998h));
    }
}
