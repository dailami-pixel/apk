package androidx.constraintlayout.motion.widget;

import android.util.Log;
import android.view.View;
import androidx.constraintlayout.widget.C0407a;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import p098d.p113e.p114a.p115a.C4635b;
import p098d.p113e.p114a.p115a.C4641f;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.constraintlayout.motion.widget.e */
public abstract class C0333e {

    /* renamed from: a */
    private C0337d f1437a;

    /* renamed from: b */
    protected C0407a f1438b;

    /* renamed from: c */
    private String f1439c;

    /* renamed from: d */
    private int f1440d = 0;

    /* renamed from: e */
    public int f1441e = 0;

    /* renamed from: f */
    ArrayList<C0349p> f1442f = new ArrayList<>();

    /* renamed from: androidx.constraintlayout.motion.widget.e$a */
    class C0334a implements Comparator<C0349p> {
        C0334a(C0333e eVar) {
        }

        public int compare(Object obj, Object obj2) {
            return Integer.compare(((C0349p) obj).f1453a, ((C0349p) obj2).f1453a);
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$b */
    static class C0335b extends C0333e {
        C0335b() {
        }

        /* renamed from: e */
        public void mo1886e(View view, float f) {
            view.setAlpha(mo1882a(f));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$c */
    static class C0336c extends C0333e {

        /* renamed from: g */
        float[] f1443g = new float[1];

        C0336c() {
        }

        /* renamed from: e */
        public void mo1886e(View view, float f) {
            this.f1443g[0] = mo1882a(f);
            this.f1438b.mo2058h(view, this.f1443g);
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$d */
    static class C0337d {

        /* renamed from: a */
        C4641f f1444a = new C4641f();

        /* renamed from: b */
        float[] f1445b;

        /* renamed from: c */
        double[] f1446c;

        /* renamed from: d */
        float[] f1447d;

        /* renamed from: e */
        float[] f1448e;

        /* renamed from: f */
        C4635b f1449f;

        /* renamed from: g */
        double[] f1450g;

        /* renamed from: h */
        double[] f1451h;

        C0337d(int i, int i2, int i3) {
            new HashMap();
            this.f1444a.mo21501g(i);
            this.f1445b = new float[i3];
            this.f1446c = new double[i3];
            this.f1447d = new float[i3];
            this.f1448e = new float[i3];
            float[] fArr = new float[i3];
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$e */
    static class C0338e extends C0333e {
        C0338e() {
        }

        /* renamed from: e */
        public void mo1886e(View view, float f) {
            view.setElevation(mo1882a(f));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$f */
    static class C0339f extends C0333e {
        C0339f() {
        }

        /* renamed from: e */
        public void mo1886e(View view, float f) {
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$g */
    static class C0340g extends C0333e {

        /* renamed from: g */
        boolean f1452g = false;

        C0340g() {
        }

        /* renamed from: e */
        public void mo1886e(View view, float f) {
            if (view instanceof MotionLayout) {
                ((MotionLayout) view).mo1844h0(mo1882a(f));
            } else if (!this.f1452g) {
                Method method = null;
                try {
                    method = view.getClass().getMethod("setProgress", new Class[]{Float.TYPE});
                } catch (NoSuchMethodException unused) {
                    this.f1452g = true;
                }
                if (method != null) {
                    try {
                        method.invoke(view, new Object[]{Float.valueOf(mo1882a(f))});
                    } catch (IllegalAccessException | InvocationTargetException e) {
                        Log.e("KeyCycleOscillator", "unable to setProgress", e);
                    }
                }
            }
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$h */
    static class C0341h extends C0333e {
        C0341h() {
        }

        /* renamed from: e */
        public void mo1886e(View view, float f) {
            view.setRotation(mo1882a(f));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$i */
    static class C0342i extends C0333e {
        C0342i() {
        }

        /* renamed from: e */
        public void mo1886e(View view, float f) {
            view.setRotationX(mo1882a(f));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$j */
    static class C0343j extends C0333e {
        C0343j() {
        }

        /* renamed from: e */
        public void mo1886e(View view, float f) {
            view.setRotationY(mo1882a(f));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$k */
    static class C0344k extends C0333e {
        C0344k() {
        }

        /* renamed from: e */
        public void mo1886e(View view, float f) {
            view.setScaleX(mo1882a(f));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$l */
    static class C0345l extends C0333e {
        C0345l() {
        }

        /* renamed from: e */
        public void mo1886e(View view, float f) {
            view.setScaleY(mo1882a(f));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$m */
    static class C0346m extends C0333e {
        C0346m() {
        }

        /* renamed from: e */
        public void mo1886e(View view, float f) {
            view.setTranslationX(mo1882a(f));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$n */
    static class C0347n extends C0333e {
        C0347n() {
        }

        /* renamed from: e */
        public void mo1886e(View view, float f) {
            view.setTranslationY(mo1882a(f));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$o */
    static class C0348o extends C0333e {
        C0348o() {
        }

        /* renamed from: e */
        public void mo1886e(View view, float f) {
            view.setTranslationZ(mo1882a(f));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.e$p */
    static class C0349p {

        /* renamed from: a */
        int f1453a;

        /* renamed from: b */
        float f1454b;

        /* renamed from: c */
        float f1455c;

        /* renamed from: d */
        float f1456d;

        public C0349p(int i, float f, float f2, float f3) {
            this.f1453a = i;
            this.f1454b = f3;
            this.f1455c = f2;
            this.f1456d = f;
        }
    }

    /* renamed from: a */
    public float mo1882a(float f) {
        C0337d dVar = this.f1437a;
        C4635b bVar = dVar.f1449f;
        if (bVar != null) {
            bVar.mo21480d((double) f, dVar.f1450g);
        } else {
            double[] dArr = dVar.f1450g;
            dArr[0] = (double) dVar.f1448e[0];
            dArr[1] = (double) dVar.f1445b[0];
        }
        return (float) ((dVar.f1444a.mo21499e((double) f) * dVar.f1450g[1]) + dVar.f1450g[0]);
    }

    /* renamed from: b */
    public float mo1883b(float f) {
        C0337d dVar = this.f1437a;
        C4635b bVar = dVar.f1449f;
        if (bVar != null) {
            double d = (double) f;
            bVar.mo21483g(d, dVar.f1451h);
            dVar.f1449f.mo21480d(d, dVar.f1450g);
        } else {
            double[] dArr = dVar.f1451h;
            dArr[0] = 0.0d;
            dArr[1] = 0.0d;
        }
        double d2 = (double) f;
        double e = dVar.f1444a.mo21499e(d2);
        double d3 = dVar.f1444a.mo21498d(d2);
        double[] dArr2 = dVar.f1451h;
        double d4 = dArr2[0];
        return (float) ((d3 * dVar.f1450g[1]) + (e * dArr2[1]) + d4);
    }

    /* renamed from: c */
    public void mo1884c(int i, int i2, int i3, float f, float f2, float f3) {
        this.f1442f.add(new C0349p(i, f, f2, f3));
        if (i3 != -1) {
            this.f1441e = i3;
        }
        this.f1440d = i2;
    }

    /* renamed from: d */
    public void mo1885d(int i, int i2, int i3, float f, float f2, float f3, C0407a aVar) {
        this.f1442f.add(new C0349p(i, f, f2, f3));
        if (i3 != -1) {
            this.f1441e = i3;
        }
        this.f1440d = i2;
        this.f1438b = aVar;
    }

    /* renamed from: e */
    public abstract void mo1886e(View view, float f);

    /* renamed from: f */
    public void mo1887f(String str) {
        this.f1439c = str;
    }

    /* renamed from: g */
    public void mo1888g(float f) {
        int i;
        C4635b bVar;
        Class<double> cls = double.class;
        int size = this.f1442f.size();
        if (size != 0) {
            Collections.sort(this.f1442f, new C0334a(this));
            double[] dArr = new double[size];
            int[] iArr = new int[2];
            char c = 1;
            iArr[1] = 2;
            char c2 = 0;
            iArr[0] = size;
            double[][] dArr2 = (double[][]) Array.newInstance(cls, iArr);
            this.f1437a = new C0337d(this.f1440d, this.f1441e, size);
            Iterator<C0349p> it = this.f1442f.iterator();
            int i2 = 0;
            while (it.hasNext()) {
                C0349p next = it.next();
                float f2 = next.f1456d;
                dArr[i2] = ((double) f2) * 0.01d;
                double[] dArr3 = dArr2[i2];
                float f3 = next.f1454b;
                dArr3[c2] = (double) f3;
                double[] dArr4 = dArr2[i2];
                float f4 = next.f1455c;
                dArr4[c] = (double) f4;
                C0337d dVar = this.f1437a;
                dVar.f1446c[i2] = ((double) next.f1453a) / 100.0d;
                dVar.f1447d[i2] = f2;
                dVar.f1448e[i2] = f4;
                dVar.f1445b[i2] = f3;
                i2++;
                c = 1;
                c2 = 0;
            }
            C0337d dVar2 = this.f1437a;
            int length = dVar2.f1446c.length;
            int[] iArr2 = new int[2];
            iArr2[1] = 2;
            iArr2[0] = length;
            double[][] dArr5 = (double[][]) Array.newInstance(cls, iArr2);
            float[] fArr = dVar2.f1445b;
            dVar2.f1450g = new double[(fArr.length + 1)];
            dVar2.f1451h = new double[(fArr.length + 1)];
            if (dVar2.f1446c[0] > 0.0d) {
                dVar2.f1444a.mo21495a(0.0d, dVar2.f1447d[0]);
            }
            double[] dArr6 = dVar2.f1446c;
            int length2 = dArr6.length - 1;
            if (dArr6[length2] < 1.0d) {
                dVar2.f1444a.mo21495a(1.0d, dVar2.f1447d[length2]);
            }
            for (int i3 = 0; i3 < dArr5.length; i3++) {
                dArr5[i3][0] = (double) dVar2.f1448e[i3];
                int i4 = 0;
                while (true) {
                    float[] fArr2 = dVar2.f1445b;
                    if (i4 >= fArr2.length) {
                        break;
                    }
                    dArr5[i4][1] = (double) fArr2[i4];
                    i4++;
                }
                dVar2.f1444a.mo21495a(dVar2.f1446c[i3], dVar2.f1447d[i3]);
            }
            dVar2.f1444a.mo21500f();
            double[] dArr7 = dVar2.f1446c;
            if (dArr7.length > 1) {
                i = 0;
                bVar = C4635b.m16690a(0, dArr7, dArr5);
            } else {
                i = 0;
                bVar = null;
            }
            dVar2.f1449f = bVar;
            C4635b.m16690a(i, dArr, dArr2);
        }
    }

    public String toString() {
        String str = this.f1439c;
        DecimalFormat decimalFormat = new DecimalFormat("##.##");
        Iterator<C0349p> it = this.f1442f.iterator();
        while (it.hasNext()) {
            C0349p next = it.next();
            StringBuilder T = C4924a.m17867T(str, "[");
            T.append(next.f1453a);
            T.append(" , ");
            T.append(decimalFormat.format((double) next.f1454b));
            T.append("] ");
            str = T.toString();
        }
        return str;
    }
}
