package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.util.Log;
import android.util.Xml;
import androidx.constraintlayout.widget.C0407a;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* renamed from: androidx.constraintlayout.motion.widget.f */
public class C0350f {

    /* renamed from: a */
    static HashMap<String, Constructor<? extends C0327a>> f1457a;

    /* renamed from: b */
    private HashMap<Integer, ArrayList<C0327a>> f1458b = new HashMap<>();

    static {
        HashMap<String, Constructor<? extends C0327a>> hashMap = new HashMap<>();
        f1457a = hashMap;
        try {
            hashMap.put("KeyAttribute", C0328b.class.getConstructor(new Class[0]));
            f1457a.put("KeyPosition", C0351g.class.getConstructor(new Class[0]));
            f1457a.put("KeyCycle", C0331d.class.getConstructor(new Class[0]));
            f1457a.put("KeyTimeCycle", C0354i.class.getConstructor(new Class[0]));
            f1457a.put("KeyTrigger", C0356j.class.getConstructor(new Class[0]));
        } catch (NoSuchMethodException e) {
            Log.e("KeyFrames", "unable to load", e);
        }
    }

    public C0350f(Context context, XmlPullParser xmlPullParser) {
        HashMap<String, C0407a> hashMap;
        C0327a aVar;
        Exception e;
        try {
            int eventType = xmlPullParser.getEventType();
            C0327a aVar2 = null;
            while (eventType != 1) {
                if (eventType == 2) {
                    String name = xmlPullParser.getName();
                    if (f1457a.containsKey(name)) {
                        try {
                            aVar = (C0327a) f1457a.get(name).newInstance(new Object[0]);
                            try {
                                aVar.mo1879c(context, Xml.asAttributeSet(xmlPullParser));
                                m1630b(aVar);
                            } catch (Exception e2) {
                                e = e2;
                            }
                        } catch (Exception e3) {
                            C0327a aVar3 = aVar2;
                            e = e3;
                            aVar = aVar3;
                            Log.e("KeyFrames", "unable to create ", e);
                            aVar2 = aVar;
                            eventType = xmlPullParser.next();
                        }
                        aVar2 = aVar;
                    } else if (!(!name.equalsIgnoreCase("CustomAttribute") || aVar2 == null || (hashMap = aVar2.f1401d) == null)) {
                        C0407a.m1934f(context, xmlPullParser, hashMap);
                    }
                } else if (eventType == 3) {
                    if ("KeyFrameSet".equals(xmlPullParser.getName())) {
                        return;
                    }
                }
                eventType = xmlPullParser.next();
            }
        } catch (XmlPullParserException e4) {
            e4.printStackTrace();
        } catch (IOException e5) {
            e5.printStackTrace();
        }
    }

    /* renamed from: b */
    private void m1630b(C0327a aVar) {
        if (!this.f1458b.containsKey(Integer.valueOf(aVar.f1399b))) {
            this.f1458b.put(Integer.valueOf(aVar.f1399b), new ArrayList());
        }
        this.f1458b.get(Integer.valueOf(aVar.f1399b)).add(aVar);
    }

    /* renamed from: a */
    public void mo1891a(C0359l lVar) {
        ArrayList arrayList = this.f1458b.get(Integer.valueOf(lVar.f1525b));
        if (arrayList != null) {
            lVar.mo1900b(arrayList);
        }
        ArrayList arrayList2 = this.f1458b.get(-1);
        if (arrayList2 != null) {
            Iterator it = arrayList2.iterator();
            while (it.hasNext()) {
                C0327a aVar = (C0327a) it.next();
                String str = ((ConstraintLayout.LayoutParams) lVar.f1524a.getLayoutParams()).f1796U;
                String str2 = aVar.f1400c;
                if ((str2 == null || str == null) ? false : str.matches(str2)) {
                    lVar.mo1899a(aVar);
                }
            }
        }
    }
}
