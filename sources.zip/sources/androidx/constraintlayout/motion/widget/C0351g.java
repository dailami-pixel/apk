package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import androidx.constraintlayout.widget.C0418e;
import java.util.HashMap;
import p098d.p113e.p114a.p115a.C4637c;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.constraintlayout.motion.widget.g */
public class C0351g extends C0353h {

    /* renamed from: f */
    String f1459f = null;

    /* renamed from: g */
    int f1460g = -1;

    /* renamed from: h */
    int f1461h = 0;

    /* renamed from: i */
    float f1462i = Float.NaN;

    /* renamed from: j */
    float f1463j = Float.NaN;

    /* renamed from: k */
    float f1464k = Float.NaN;

    /* renamed from: l */
    float f1465l = Float.NaN;

    /* renamed from: m */
    int f1466m = 0;

    /* renamed from: androidx.constraintlayout.motion.widget.g$a */
    private static class C0352a {

        /* renamed from: a */
        private static SparseIntArray f1467a;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1467a = sparseIntArray;
            sparseIntArray.append(4, 1);
            f1467a.append(2, 2);
            f1467a.append(11, 3);
            f1467a.append(0, 4);
            f1467a.append(1, 5);
            f1467a.append(8, 6);
            f1467a.append(9, 7);
            f1467a.append(3, 9);
            f1467a.append(10, 8);
            f1467a.append(7, 11);
            f1467a.append(6, 12);
            f1467a.append(5, 10);
        }

        /* renamed from: a */
        static void m1634a(C0351g gVar, TypedArray typedArray) {
            float f;
            int indexCount = typedArray.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArray.getIndex(i);
                switch (f1467a.get(index)) {
                    case 1:
                        if (MotionLayout.f1305r) {
                            int resourceId = typedArray.getResourceId(index, gVar.f1399b);
                            gVar.f1399b = resourceId;
                            if (resourceId != -1) {
                                break;
                            }
                        } else if (typedArray.peekValue(index).type != 3) {
                            gVar.f1399b = typedArray.getResourceId(index, gVar.f1399b);
                            continue;
                        }
                        gVar.f1400c = typedArray.getString(index);
                        break;
                    case 2:
                        gVar.f1398a = typedArray.getInt(index, gVar.f1398a);
                        continue;
                    case 3:
                        gVar.f1459f = typedArray.peekValue(index).type == 3 ? typedArray.getString(index) : C4637c.f16727b[typedArray.getInteger(index, 0)];
                        continue;
                    case 4:
                        gVar.f1468e = typedArray.getInteger(index, gVar.f1468e);
                        continue;
                    case 5:
                        gVar.f1461h = typedArray.getInt(index, gVar.f1461h);
                        continue;
                    case 6:
                        gVar.f1464k = typedArray.getFloat(index, gVar.f1464k);
                        continue;
                    case 7:
                        gVar.f1465l = typedArray.getFloat(index, gVar.f1465l);
                        continue;
                    case 8:
                        f = typedArray.getFloat(index, gVar.f1463j);
                        gVar.f1462i = f;
                        break;
                    case 9:
                        gVar.f1466m = typedArray.getInt(index, gVar.f1466m);
                        continue;
                    case 10:
                        gVar.f1460g = typedArray.getInt(index, gVar.f1460g);
                        continue;
                    case 11:
                        gVar.f1462i = typedArray.getFloat(index, gVar.f1462i);
                        continue;
                    case 12:
                        f = typedArray.getFloat(index, gVar.f1463j);
                        break;
                    default:
                        StringBuilder P = C4924a.m17863P("unused attribute 0x");
                        P.append(Integer.toHexString(index));
                        P.append("   ");
                        P.append(f1467a.get(index));
                        Log.e("KeyPosition", P.toString());
                        continue;
                }
                gVar.f1463j = f;
            }
            if (gVar.f1398a == -1) {
                Log.e("KeyPosition", "no frame position");
            }
        }
    }

    /* renamed from: a */
    public void mo1877a(HashMap<String, C0367q> hashMap) {
    }

    /* renamed from: c */
    public void mo1879c(Context context, AttributeSet attributeSet) {
        C0352a.m1634a(this, context.obtainStyledAttributes(attributeSet, C0418e.f1999i));
    }
}
