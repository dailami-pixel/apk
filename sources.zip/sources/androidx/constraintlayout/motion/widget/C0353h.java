package androidx.constraintlayout.motion.widget;

import java.util.HashSet;

/* renamed from: androidx.constraintlayout.motion.widget.h */
abstract class C0353h extends C0327a {

    /* renamed from: e */
    int f1468e = -1;

    C0353h() {
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo1878b(HashSet<String> hashSet) {
    }
}
