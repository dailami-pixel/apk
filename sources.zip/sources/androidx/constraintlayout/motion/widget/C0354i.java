package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import androidx.constraintlayout.widget.C0418e;
import java.util.HashMap;
import java.util.HashSet;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.constraintlayout.motion.widget.i */
public class C0354i extends C0327a {
    /* access modifiers changed from: private */

    /* renamed from: e */
    public int f1469e = -1;
    /* access modifiers changed from: private */

    /* renamed from: f */
    public float f1470f = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: g */
    public float f1471g = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: h */
    public float f1472h = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: i */
    public float f1473i = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: j */
    public float f1474j = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: k */
    public float f1475k = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: l */
    public float f1476l = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: m */
    public float f1477m = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: n */
    public float f1478n = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: o */
    public float f1479o = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: p */
    public float f1480p = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: q */
    public float f1481q = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: r */
    public int f1482r = 0;
    /* access modifiers changed from: private */

    /* renamed from: s */
    public float f1483s = Float.NaN;
    /* access modifiers changed from: private */

    /* renamed from: t */
    public float f1484t = 0.0f;

    /* renamed from: androidx.constraintlayout.motion.widget.i$a */
    private static class C0355a {

        /* renamed from: a */
        private static SparseIntArray f1485a;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1485a = sparseIntArray;
            sparseIntArray.append(0, 1);
            f1485a.append(9, 2);
            f1485a.append(5, 4);
            f1485a.append(6, 5);
            f1485a.append(7, 6);
            f1485a.append(3, 7);
            f1485a.append(15, 8);
            f1485a.append(14, 9);
            f1485a.append(13, 10);
            f1485a.append(11, 12);
            f1485a.append(10, 13);
            f1485a.append(4, 14);
            f1485a.append(1, 15);
            f1485a.append(2, 16);
            f1485a.append(8, 17);
            f1485a.append(12, 18);
            f1485a.append(18, 20);
            f1485a.append(17, 21);
            f1485a.append(19, 19);
        }

        /* renamed from: a */
        public static void m1673a(C0354i iVar, TypedArray typedArray) {
            int indexCount = typedArray.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArray.getIndex(i);
                switch (f1485a.get(index)) {
                    case 1:
                        float unused = iVar.f1470f = typedArray.getFloat(index, iVar.f1470f);
                        break;
                    case 2:
                        float unused2 = iVar.f1471g = typedArray.getDimension(index, iVar.f1471g);
                        break;
                    case 4:
                        float unused3 = iVar.f1472h = typedArray.getFloat(index, iVar.f1472h);
                        break;
                    case 5:
                        float unused4 = iVar.f1473i = typedArray.getFloat(index, iVar.f1473i);
                        break;
                    case 6:
                        float unused5 = iVar.f1474j = typedArray.getFloat(index, iVar.f1474j);
                        break;
                    case 7:
                        float unused6 = iVar.f1476l = typedArray.getFloat(index, iVar.f1476l);
                        break;
                    case 8:
                        float unused7 = iVar.f1475k = typedArray.getFloat(index, iVar.f1475k);
                        break;
                    case 9:
                        typedArray.getString(index);
                        break;
                    case 10:
                        if (!MotionLayout.f1305r) {
                            if (typedArray.peekValue(index).type != 3) {
                                iVar.f1399b = typedArray.getResourceId(index, iVar.f1399b);
                                break;
                            }
                        } else {
                            int resourceId = typedArray.getResourceId(index, iVar.f1399b);
                            iVar.f1399b = resourceId;
                            if (resourceId != -1) {
                                break;
                            }
                        }
                        iVar.f1400c = typedArray.getString(index);
                        break;
                    case 12:
                        iVar.f1398a = typedArray.getInt(index, iVar.f1398a);
                        break;
                    case 13:
                        int unused8 = iVar.f1469e = typedArray.getInteger(index, iVar.f1469e);
                        break;
                    case 14:
                        float unused9 = iVar.f1477m = typedArray.getFloat(index, iVar.f1477m);
                        break;
                    case 15:
                        float unused10 = iVar.f1478n = typedArray.getDimension(index, iVar.f1478n);
                        break;
                    case 16:
                        float unused11 = iVar.f1479o = typedArray.getDimension(index, iVar.f1479o);
                        break;
                    case 17:
                        float unused12 = iVar.f1480p = typedArray.getDimension(index, iVar.f1480p);
                        break;
                    case 18:
                        float unused13 = iVar.f1481q = typedArray.getFloat(index, iVar.f1481q);
                        break;
                    case 19:
                        int unused14 = iVar.f1482r = typedArray.getInt(index, iVar.f1482r);
                        break;
                    case 20:
                        float unused15 = iVar.f1483s = typedArray.getFloat(index, iVar.f1483s);
                        break;
                    case 21:
                        float unused16 = iVar.f1484t = typedArray.peekValue(index).type == 5 ? typedArray.getDimension(index, iVar.f1484t) : typedArray.getFloat(index, iVar.f1484t);
                        break;
                    default:
                        StringBuilder P = C4924a.m17863P("unused attribute 0x");
                        P.append(Integer.toHexString(index));
                        P.append("   ");
                        P.append(f1485a.get(index));
                        Log.e("KeyTimeCycle", P.toString());
                        break;
                }
            }
        }
    }

    public C0354i() {
        this.f1401d = new HashMap<>();
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x009c, code lost:
        if (r1.equals("scaleY") == false) goto L_0x0060;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x0118, code lost:
        r3.mo1962c(r4, r5, r11.f1483s, r11.f1482r, r11.f1484t);
     */
    /* renamed from: K */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1892K(java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.C0383r> r12) {
        /*
            r11 = this;
            java.util.Set r0 = r12.keySet()
            java.util.Iterator r0 = r0.iterator()
        L_0x0008:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x01b4
            java.lang.Object r1 = r0.next()
            java.lang.String r1 = (java.lang.String) r1
            java.lang.Object r2 = r12.get(r1)
            r3 = r2
            androidx.constraintlayout.motion.widget.r r3 = (androidx.constraintlayout.motion.widget.C0383r) r3
            java.lang.String r2 = "CUSTOM"
            boolean r2 = r1.startsWith(r2)
            r4 = 7
            r5 = 2
            r6 = 1
            r7 = 0
            if (r2 == 0) goto L_0x0058
            java.lang.String r1 = r1.substring(r4)
            java.util.HashMap<java.lang.String, androidx.constraintlayout.widget.a> r2 = r11.f1401d
            java.lang.Object r1 = r2.get(r1)
            androidx.constraintlayout.widget.a r1 = (androidx.constraintlayout.widget.C0407a) r1
            if (r1 == 0) goto L_0x0008
            androidx.constraintlayout.motion.widget.r$b r3 = (androidx.constraintlayout.motion.widget.C0383r.C0385b) r3
            int r2 = r11.f1398a
            float r4 = r11.f1483s
            int r8 = r11.f1482r
            float r9 = r11.f1484t
            android.util.SparseArray<androidx.constraintlayout.widget.a> r10 = r3.f1672k
            r10.append(r2, r1)
            android.util.SparseArray<float[]> r1 = r3.f1673l
            float[] r5 = new float[r5]
            r5[r7] = r4
            r5[r6] = r9
            r1.append(r2, r5)
            int r1 = r3.f1663b
            int r1 = java.lang.Math.max(r1, r8)
            r3.f1663b = r1
            goto L_0x0008
        L_0x0058:
            r2 = -1
            int r8 = r1.hashCode()
            switch(r8) {
                case -1249320806: goto L_0x00e1;
                case -1249320805: goto L_0x00d6;
                case -1225497657: goto L_0x00cb;
                case -1225497656: goto L_0x00c0;
                case -1225497655: goto L_0x00b5;
                case -1001078227: goto L_0x00aa;
                case -908189618: goto L_0x009f;
                case -908189617: goto L_0x0096;
                case -40300674: goto L_0x008a;
                case -4379043: goto L_0x007d;
                case 37232917: goto L_0x0070;
                case 92909918: goto L_0x0063;
                default: goto L_0x0060;
            }
        L_0x0060:
            r4 = -1
            goto L_0x00ec
        L_0x0063:
            java.lang.String r4 = "alpha"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x006c
            goto L_0x0060
        L_0x006c:
            r4 = 11
            goto L_0x00ec
        L_0x0070:
            java.lang.String r4 = "transitionPathRotate"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x0079
            goto L_0x0060
        L_0x0079:
            r4 = 10
            goto L_0x00ec
        L_0x007d:
            java.lang.String r4 = "elevation"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x0086
            goto L_0x0060
        L_0x0086:
            r4 = 9
            goto L_0x00ec
        L_0x008a:
            java.lang.String r4 = "rotation"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x0093
            goto L_0x0060
        L_0x0093:
            r4 = 8
            goto L_0x00ec
        L_0x0096:
            java.lang.String r5 = "scaleY"
            boolean r5 = r1.equals(r5)
            if (r5 != 0) goto L_0x00ec
            goto L_0x0060
        L_0x009f:
            java.lang.String r4 = "scaleX"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x00a8
            goto L_0x0060
        L_0x00a8:
            r4 = 6
            goto L_0x00ec
        L_0x00aa:
            java.lang.String r4 = "progress"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x00b3
            goto L_0x0060
        L_0x00b3:
            r4 = 5
            goto L_0x00ec
        L_0x00b5:
            java.lang.String r4 = "translationZ"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x00be
            goto L_0x0060
        L_0x00be:
            r4 = 4
            goto L_0x00ec
        L_0x00c0:
            java.lang.String r4 = "translationY"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x00c9
            goto L_0x0060
        L_0x00c9:
            r4 = 3
            goto L_0x00ec
        L_0x00cb:
            java.lang.String r4 = "translationX"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x00d4
            goto L_0x0060
        L_0x00d4:
            r4 = 2
            goto L_0x00ec
        L_0x00d6:
            java.lang.String r4 = "rotationY"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x00df
            goto L_0x0060
        L_0x00df:
            r4 = 1
            goto L_0x00ec
        L_0x00e1:
            java.lang.String r4 = "rotationX"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x00eb
            goto L_0x0060
        L_0x00eb:
            r4 = 0
        L_0x00ec:
            switch(r4) {
                case 0: goto L_0x01a6;
                case 1: goto L_0x0198;
                case 2: goto L_0x018b;
                case 3: goto L_0x017e;
                case 4: goto L_0x0171;
                case 5: goto L_0x0164;
                case 6: goto L_0x0157;
                case 7: goto L_0x014a;
                case 8: goto L_0x013d;
                case 9: goto L_0x0130;
                case 10: goto L_0x0123;
                case 11: goto L_0x010c;
                default: goto L_0x00ef;
            }
        L_0x00ef:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "UNKNOWN addValues \""
            r2.append(r3)
            r2.append(r1)
            java.lang.String r1 = "\""
            r2.append(r1)
            java.lang.String r1 = r2.toString()
            java.lang.String r2 = "KeyTimeCycles"
            android.util.Log.e(r2, r1)
            goto L_0x0008
        L_0x010c:
            float r1 = r11.f1470f
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r4 = r11.f1398a
            float r5 = r11.f1470f
        L_0x0118:
            float r6 = r11.f1483s
            int r7 = r11.f1482r
            float r8 = r11.f1484t
            r3.mo1962c(r4, r5, r6, r7, r8)
            goto L_0x0008
        L_0x0123:
            float r1 = r11.f1475k
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r4 = r11.f1398a
            float r5 = r11.f1475k
            goto L_0x0118
        L_0x0130:
            float r1 = r11.f1471g
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r4 = r11.f1398a
            float r5 = r11.f1471g
            goto L_0x0118
        L_0x013d:
            float r1 = r11.f1472h
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r4 = r11.f1398a
            float r5 = r11.f1472h
            goto L_0x0118
        L_0x014a:
            float r1 = r11.f1477m
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r4 = r11.f1398a
            float r5 = r11.f1477m
            goto L_0x0118
        L_0x0157:
            float r1 = r11.f1476l
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r4 = r11.f1398a
            float r5 = r11.f1476l
            goto L_0x0118
        L_0x0164:
            float r1 = r11.f1481q
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r4 = r11.f1398a
            float r5 = r11.f1481q
            goto L_0x0118
        L_0x0171:
            float r1 = r11.f1480p
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r4 = r11.f1398a
            float r5 = r11.f1480p
            goto L_0x0118
        L_0x017e:
            float r1 = r11.f1479o
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r4 = r11.f1398a
            float r5 = r11.f1479o
            goto L_0x0118
        L_0x018b:
            float r1 = r11.f1478n
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r4 = r11.f1398a
            float r5 = r11.f1478n
            goto L_0x0118
        L_0x0198:
            float r1 = r11.f1474j
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r4 = r11.f1398a
            float r5 = r11.f1474j
            goto L_0x0118
        L_0x01a6:
            float r1 = r11.f1473i
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r4 = r11.f1398a
            float r5 = r11.f1473i
            goto L_0x0118
        L_0x01b4:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.C0354i.mo1892K(java.util.HashMap):void");
    }

    /* renamed from: a */
    public void mo1877a(HashMap<String, C0367q> hashMap) {
        throw new IllegalArgumentException(" KeyTimeCycles do not support SplineSet");
    }

    /* renamed from: b */
    public void mo1878b(HashSet<String> hashSet) {
        if (!Float.isNaN(this.f1470f)) {
            hashSet.add("alpha");
        }
        if (!Float.isNaN(this.f1471g)) {
            hashSet.add("elevation");
        }
        if (!Float.isNaN(this.f1472h)) {
            hashSet.add("rotation");
        }
        if (!Float.isNaN(this.f1473i)) {
            hashSet.add("rotationX");
        }
        if (!Float.isNaN(this.f1474j)) {
            hashSet.add("rotationY");
        }
        if (!Float.isNaN(this.f1478n)) {
            hashSet.add("translationX");
        }
        if (!Float.isNaN(this.f1479o)) {
            hashSet.add("translationY");
        }
        if (!Float.isNaN(this.f1480p)) {
            hashSet.add("translationZ");
        }
        if (!Float.isNaN(this.f1475k)) {
            hashSet.add("transitionPathRotate");
        }
        if (!Float.isNaN(this.f1476l)) {
            hashSet.add("scaleX");
        }
        if (!Float.isNaN(this.f1477m)) {
            hashSet.add("scaleY");
        }
        if (!Float.isNaN(this.f1481q)) {
            hashSet.add("progress");
        }
        if (this.f1401d.size() > 0) {
            for (String str : this.f1401d.keySet()) {
                hashSet.add("CUSTOM," + str);
            }
        }
    }

    /* renamed from: c */
    public void mo1879c(Context context, AttributeSet attributeSet) {
        C0355a.m1673a(this, context.obtainStyledAttributes(attributeSet, C0418e.f2000j));
    }

    /* renamed from: d */
    public void mo1880d(HashMap<String, Integer> hashMap) {
        if (this.f1469e != -1) {
            if (!Float.isNaN(this.f1470f)) {
                hashMap.put("alpha", Integer.valueOf(this.f1469e));
            }
            if (!Float.isNaN(this.f1471g)) {
                hashMap.put("elevation", Integer.valueOf(this.f1469e));
            }
            if (!Float.isNaN(this.f1472h)) {
                hashMap.put("rotation", Integer.valueOf(this.f1469e));
            }
            if (!Float.isNaN(this.f1473i)) {
                hashMap.put("rotationX", Integer.valueOf(this.f1469e));
            }
            if (!Float.isNaN(this.f1474j)) {
                hashMap.put("rotationY", Integer.valueOf(this.f1469e));
            }
            if (!Float.isNaN(this.f1478n)) {
                hashMap.put("translationX", Integer.valueOf(this.f1469e));
            }
            if (!Float.isNaN(this.f1479o)) {
                hashMap.put("translationY", Integer.valueOf(this.f1469e));
            }
            if (!Float.isNaN(this.f1480p)) {
                hashMap.put("translationZ", Integer.valueOf(this.f1469e));
            }
            if (!Float.isNaN(this.f1475k)) {
                hashMap.put("transitionPathRotate", Integer.valueOf(this.f1469e));
            }
            if (!Float.isNaN(this.f1476l)) {
                hashMap.put("scaleX", Integer.valueOf(this.f1469e));
            }
            if (!Float.isNaN(this.f1476l)) {
                hashMap.put("scaleY", Integer.valueOf(this.f1469e));
            }
            if (!Float.isNaN(this.f1481q)) {
                hashMap.put("progress", Integer.valueOf(this.f1469e));
            }
            if (this.f1401d.size() > 0) {
                for (String v : this.f1401d.keySet()) {
                    hashMap.put(C4924a.m17907v("CUSTOM,", v), Integer.valueOf(this.f1469e));
                }
            }
        }
    }
}
