package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import androidx.constraintlayout.widget.C0418e;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.constraintlayout.motion.widget.j */
public class C0356j extends C0327a {
    /* access modifiers changed from: private */

    /* renamed from: e */
    public String f1486e = null;
    /* access modifiers changed from: private */

    /* renamed from: f */
    public int f1487f = -1;
    /* access modifiers changed from: private */

    /* renamed from: g */
    public String f1488g = null;
    /* access modifiers changed from: private */

    /* renamed from: h */
    public String f1489h = null;
    /* access modifiers changed from: private */

    /* renamed from: i */
    public int f1490i = -1;
    /* access modifiers changed from: private */

    /* renamed from: j */
    public int f1491j = -1;

    /* renamed from: k */
    private View f1492k = null;

    /* renamed from: l */
    float f1493l = 0.1f;

    /* renamed from: m */
    private boolean f1494m = true;

    /* renamed from: n */
    private boolean f1495n = true;

    /* renamed from: o */
    private boolean f1496o = true;
    /* access modifiers changed from: private */

    /* renamed from: p */
    public float f1497p = Float.NaN;

    /* renamed from: q */
    private Method f1498q;

    /* renamed from: r */
    private Method f1499r;

    /* renamed from: s */
    private Method f1500s;

    /* renamed from: t */
    private float f1501t;
    /* access modifiers changed from: private */

    /* renamed from: u */
    public boolean f1502u = false;

    /* renamed from: v */
    RectF f1503v = new RectF();

    /* renamed from: w */
    RectF f1504w = new RectF();

    /* renamed from: androidx.constraintlayout.motion.widget.j$a */
    private static class C0357a {

        /* renamed from: a */
        private static SparseIntArray f1505a;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1505a = sparseIntArray;
            sparseIntArray.append(0, 8);
            f1505a.append(4, 4);
            f1505a.append(5, 1);
            f1505a.append(6, 2);
            f1505a.append(1, 7);
            f1505a.append(7, 6);
            f1505a.append(9, 5);
            f1505a.append(3, 9);
            f1505a.append(2, 10);
            f1505a.append(8, 11);
        }

        /* renamed from: a */
        public static void m1691a(C0356j jVar, TypedArray typedArray) {
            int indexCount = typedArray.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArray.getIndex(i);
                switch (f1505a.get(index)) {
                    case 1:
                        String unused = jVar.f1488g = typedArray.getString(index);
                        continue;
                    case 2:
                        String unused2 = jVar.f1489h = typedArray.getString(index);
                        continue;
                    case 4:
                        String unused3 = jVar.f1486e = typedArray.getString(index);
                        continue;
                    case 5:
                        jVar.f1493l = typedArray.getFloat(index, jVar.f1493l);
                        continue;
                    case 6:
                        int unused4 = jVar.f1490i = typedArray.getResourceId(index, jVar.f1490i);
                        continue;
                    case 7:
                        if (!MotionLayout.f1305r) {
                            if (typedArray.peekValue(index).type != 3) {
                                jVar.f1399b = typedArray.getResourceId(index, jVar.f1399b);
                                break;
                            }
                        } else {
                            int resourceId = typedArray.getResourceId(index, jVar.f1399b);
                            jVar.f1399b = resourceId;
                            if (resourceId != -1) {
                                continue;
                            }
                        }
                        jVar.f1400c = typedArray.getString(index);
                        break;
                    case 8:
                        int integer = typedArray.getInteger(index, jVar.f1398a);
                        jVar.f1398a = integer;
                        float unused5 = jVar.f1497p = (((float) integer) + 0.5f) / 100.0f;
                        continue;
                    case 9:
                        int unused6 = jVar.f1491j = typedArray.getResourceId(index, jVar.f1491j);
                        continue;
                    case 10:
                        boolean unused7 = jVar.f1502u = typedArray.getBoolean(index, jVar.f1502u);
                        continue;
                    case 11:
                        int unused8 = jVar.f1487f = typedArray.getResourceId(index, jVar.f1487f);
                        break;
                }
                StringBuilder P = C4924a.m17863P("unused attribute 0x");
                P.append(Integer.toHexString(index));
                P.append("   ");
                P.append(f1505a.get(index));
                Log.e("KeyTrigger", P.toString());
            }
        }
    }

    public C0356j() {
        this.f1401d = new HashMap<>();
    }

    /* renamed from: r */
    private void m1686r(RectF rectF, View view, boolean z) {
        rectF.top = (float) view.getTop();
        rectF.bottom = (float) view.getBottom();
        rectF.left = (float) view.getLeft();
        rectF.right = (float) view.getRight();
        if (z) {
            view.getMatrix().mapRect(rectF);
        }
    }

    /* renamed from: a */
    public void mo1877a(HashMap<String, C0367q> hashMap) {
    }

    /* renamed from: b */
    public void mo1878b(HashSet<String> hashSet) {
    }

    /* renamed from: c */
    public void mo1879c(Context context, AttributeSet attributeSet) {
        C0357a.m1691a(this, context.obtainStyledAttributes(attributeSet, C0418e.f2001k));
    }

    /* JADX WARNING: Removed duplicated region for block: B:109:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x008c  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00a1  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00b6  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x00ce  */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x00f8  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x0118 A[SYNTHETIC, Splitter:B:73:0x0118] */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x0189 A[SYNTHETIC, Splitter:B:86:0x0189] */
    /* JADX WARNING: Removed duplicated region for block: B:97:0x01f6  */
    /* renamed from: q */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1893q(float r11, android.view.View r12) {
        /*
            r10 = this;
            int r0 = r10.f1491j
            r1 = 1
            r2 = 0
            r3 = -1
            if (r0 == r3) goto L_0x0061
            android.view.View r0 = r10.f1492k
            if (r0 != 0) goto L_0x0019
            android.view.ViewParent r0 = r12.getParent()
            android.view.ViewGroup r0 = (android.view.ViewGroup) r0
            int r4 = r10.f1491j
            android.view.View r0 = r0.findViewById(r4)
            r10.f1492k = r0
        L_0x0019:
            android.graphics.RectF r0 = r10.f1503v
            android.view.View r4 = r10.f1492k
            boolean r5 = r10.f1502u
            r10.m1686r(r0, r4, r5)
            android.graphics.RectF r0 = r10.f1504w
            boolean r4 = r10.f1502u
            r10.m1686r(r0, r12, r4)
            android.graphics.RectF r0 = r10.f1503v
            android.graphics.RectF r4 = r10.f1504w
            boolean r0 = r0.intersect(r4)
            if (r0 == 0) goto L_0x004a
            boolean r0 = r10.f1494m
            if (r0 == 0) goto L_0x003b
            r10.f1494m = r2
            r0 = 1
            goto L_0x003c
        L_0x003b:
            r0 = 0
        L_0x003c:
            boolean r4 = r10.f1496o
            if (r4 == 0) goto L_0x0044
            r10.f1496o = r2
            r4 = 1
            goto L_0x0045
        L_0x0044:
            r4 = 0
        L_0x0045:
            r10.f1495n = r1
            r1 = 0
            goto L_0x00e0
        L_0x004a:
            boolean r0 = r10.f1494m
            if (r0 != 0) goto L_0x0052
            r10.f1494m = r1
            r0 = 1
            goto L_0x0053
        L_0x0052:
            r0 = 0
        L_0x0053:
            boolean r4 = r10.f1495n
            if (r4 == 0) goto L_0x005b
            r10.f1495n = r2
            r4 = 1
            goto L_0x005c
        L_0x005b:
            r4 = 0
        L_0x005c:
            r10.f1496o = r1
            r1 = r4
            goto L_0x00df
        L_0x0061:
            boolean r0 = r10.f1494m
            r4 = 0
            if (r0 == 0) goto L_0x0077
            float r0 = r10.f1497p
            float r5 = r11 - r0
            float r6 = r10.f1501t
            float r6 = r6 - r0
            float r6 = r6 * r5
            int r0 = (r6 > r4 ? 1 : (r6 == r4 ? 0 : -1))
            if (r0 >= 0) goto L_0x0087
            r10.f1494m = r2
            r0 = 1
            goto L_0x0088
        L_0x0077:
            float r0 = r10.f1497p
            float r0 = r11 - r0
            float r0 = java.lang.Math.abs(r0)
            float r5 = r10.f1493l
            int r0 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
            if (r0 <= 0) goto L_0x0087
            r10.f1494m = r1
        L_0x0087:
            r0 = 0
        L_0x0088:
            boolean r5 = r10.f1495n
            if (r5 == 0) goto L_0x00a1
            float r5 = r10.f1497p
            float r6 = r11 - r5
            float r7 = r10.f1501t
            float r7 = r7 - r5
            float r7 = r7 * r6
            int r5 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r5 >= 0) goto L_0x00b1
            int r5 = (r6 > r4 ? 1 : (r6 == r4 ? 0 : -1))
            if (r5 >= 0) goto L_0x00b1
            r10.f1495n = r2
            r5 = 1
            goto L_0x00b2
        L_0x00a1:
            float r5 = r10.f1497p
            float r5 = r11 - r5
            float r5 = java.lang.Math.abs(r5)
            float r6 = r10.f1493l
            int r5 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1))
            if (r5 <= 0) goto L_0x00b1
            r10.f1495n = r1
        L_0x00b1:
            r5 = 0
        L_0x00b2:
            boolean r6 = r10.f1496o
            if (r6 == 0) goto L_0x00ce
            float r6 = r10.f1497p
            float r7 = r11 - r6
            float r8 = r10.f1501t
            float r8 = r8 - r6
            float r8 = r8 * r7
            int r6 = (r8 > r4 ? 1 : (r8 == r4 ? 0 : -1))
            if (r6 >= 0) goto L_0x00ca
            int r4 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r4 <= 0) goto L_0x00ca
            r10.f1496o = r2
            goto L_0x00cb
        L_0x00ca:
            r1 = 0
        L_0x00cb:
            r4 = r1
            r1 = r5
            goto L_0x00e0
        L_0x00ce:
            float r4 = r10.f1497p
            float r4 = r11 - r4
            float r4 = java.lang.Math.abs(r4)
            float r6 = r10.f1493l
            int r4 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r4 <= 0) goto L_0x00de
            r10.f1496o = r1
        L_0x00de:
            r1 = r5
        L_0x00df:
            r4 = 0
        L_0x00e0:
            r10.f1501t = r11
            if (r1 != 0) goto L_0x00e8
            if (r0 != 0) goto L_0x00e8
            if (r4 == 0) goto L_0x00f3
        L_0x00e8:
            android.view.ViewParent r5 = r12.getParent()
            androidx.constraintlayout.motion.widget.MotionLayout r5 = (androidx.constraintlayout.motion.widget.MotionLayout) r5
            int r6 = r10.f1490i
            r5.mo1836W(r6, r4, r11)
        L_0x00f3:
            int r11 = r10.f1487f
            if (r11 != r3) goto L_0x00f8
            goto L_0x0104
        L_0x00f8:
            android.view.ViewParent r11 = r12.getParent()
            androidx.constraintlayout.motion.widget.MotionLayout r11 = (androidx.constraintlayout.motion.widget.MotionLayout) r11
            int r12 = r10.f1487f
            android.view.View r12 = r11.findViewById(r12)
        L_0x0104:
            java.lang.String r11 = "Could not find method \""
            java.lang.String r3 = "Exception in call \""
            java.lang.String r5 = " "
            java.lang.String r6 = "\"on class "
            java.lang.String r7 = "KeyTrigger"
            if (r1 == 0) goto L_0x017f
            java.lang.String r1 = r10.f1488g
            if (r1 == 0) goto L_0x017f
            java.lang.reflect.Method r1 = r10.f1499r
            if (r1 != 0) goto L_0x014f
            java.lang.Class r1 = r12.getClass()     // Catch:{ NoSuchMethodException -> 0x0127 }
            java.lang.String r8 = r10.f1488g     // Catch:{ NoSuchMethodException -> 0x0127 }
            java.lang.Class[] r9 = new java.lang.Class[r2]     // Catch:{ NoSuchMethodException -> 0x0127 }
            java.lang.reflect.Method r1 = r1.getMethod(r8, r9)     // Catch:{ NoSuchMethodException -> 0x0127 }
            r10.f1499r = r1     // Catch:{ NoSuchMethodException -> 0x0127 }
            goto L_0x014f
        L_0x0127:
            java.lang.StringBuilder r1 = p165e.p166a.p167a.p168a.C4924a.m17863P(r11)
            java.lang.String r8 = r10.f1488g
            r1.append(r8)
            r1.append(r6)
            java.lang.Class r8 = r12.getClass()
            java.lang.String r8 = r8.getSimpleName()
            r1.append(r8)
            r1.append(r5)
            java.lang.String r8 = p098d.p099a.C4567a.m16428c(r12)
            r1.append(r8)
            java.lang.String r1 = r1.toString()
            android.util.Log.e(r7, r1)
        L_0x014f:
            java.lang.reflect.Method r1 = r10.f1499r     // Catch:{ Exception -> 0x0157 }
            java.lang.Object[] r8 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x0157 }
            r1.invoke(r12, r8)     // Catch:{ Exception -> 0x0157 }
            goto L_0x017f
        L_0x0157:
            java.lang.StringBuilder r1 = p165e.p166a.p167a.p168a.C4924a.m17863P(r3)
            java.lang.String r8 = r10.f1488g
            r1.append(r8)
            r1.append(r6)
            java.lang.Class r8 = r12.getClass()
            java.lang.String r8 = r8.getSimpleName()
            r1.append(r8)
            r1.append(r5)
            java.lang.String r8 = p098d.p099a.C4567a.m16428c(r12)
            r1.append(r8)
            java.lang.String r1 = r1.toString()
            android.util.Log.e(r7, r1)
        L_0x017f:
            if (r4 == 0) goto L_0x01f0
            java.lang.String r1 = r10.f1489h
            if (r1 == 0) goto L_0x01f0
            java.lang.reflect.Method r1 = r10.f1500s
            if (r1 != 0) goto L_0x01c0
            java.lang.Class r1 = r12.getClass()     // Catch:{ NoSuchMethodException -> 0x0198 }
            java.lang.String r4 = r10.f1489h     // Catch:{ NoSuchMethodException -> 0x0198 }
            java.lang.Class[] r8 = new java.lang.Class[r2]     // Catch:{ NoSuchMethodException -> 0x0198 }
            java.lang.reflect.Method r1 = r1.getMethod(r4, r8)     // Catch:{ NoSuchMethodException -> 0x0198 }
            r10.f1500s = r1     // Catch:{ NoSuchMethodException -> 0x0198 }
            goto L_0x01c0
        L_0x0198:
            java.lang.StringBuilder r1 = p165e.p166a.p167a.p168a.C4924a.m17863P(r11)
            java.lang.String r4 = r10.f1489h
            r1.append(r4)
            r1.append(r6)
            java.lang.Class r4 = r12.getClass()
            java.lang.String r4 = r4.getSimpleName()
            r1.append(r4)
            r1.append(r5)
            java.lang.String r4 = p098d.p099a.C4567a.m16428c(r12)
            r1.append(r4)
            java.lang.String r1 = r1.toString()
            android.util.Log.e(r7, r1)
        L_0x01c0:
            java.lang.reflect.Method r1 = r10.f1500s     // Catch:{ Exception -> 0x01c8 }
            java.lang.Object[] r4 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x01c8 }
            r1.invoke(r12, r4)     // Catch:{ Exception -> 0x01c8 }
            goto L_0x01f0
        L_0x01c8:
            java.lang.StringBuilder r1 = p165e.p166a.p167a.p168a.C4924a.m17863P(r3)
            java.lang.String r4 = r10.f1489h
            r1.append(r4)
            r1.append(r6)
            java.lang.Class r4 = r12.getClass()
            java.lang.String r4 = r4.getSimpleName()
            r1.append(r4)
            r1.append(r5)
            java.lang.String r4 = p098d.p099a.C4567a.m16428c(r12)
            r1.append(r4)
            java.lang.String r1 = r1.toString()
            android.util.Log.e(r7, r1)
        L_0x01f0:
            if (r0 == 0) goto L_0x0261
            java.lang.String r0 = r10.f1486e
            if (r0 == 0) goto L_0x0261
            java.lang.reflect.Method r0 = r10.f1498q
            if (r0 != 0) goto L_0x0231
            java.lang.Class r0 = r12.getClass()     // Catch:{ NoSuchMethodException -> 0x0209 }
            java.lang.String r1 = r10.f1486e     // Catch:{ NoSuchMethodException -> 0x0209 }
            java.lang.Class[] r4 = new java.lang.Class[r2]     // Catch:{ NoSuchMethodException -> 0x0209 }
            java.lang.reflect.Method r0 = r0.getMethod(r1, r4)     // Catch:{ NoSuchMethodException -> 0x0209 }
            r10.f1498q = r0     // Catch:{ NoSuchMethodException -> 0x0209 }
            goto L_0x0231
        L_0x0209:
            java.lang.StringBuilder r11 = p165e.p166a.p167a.p168a.C4924a.m17863P(r11)
            java.lang.String r0 = r10.f1486e
            r11.append(r0)
            r11.append(r6)
            java.lang.Class r0 = r12.getClass()
            java.lang.String r0 = r0.getSimpleName()
            r11.append(r0)
            r11.append(r5)
            java.lang.String r0 = p098d.p099a.C4567a.m16428c(r12)
            r11.append(r0)
            java.lang.String r11 = r11.toString()
            android.util.Log.e(r7, r11)
        L_0x0231:
            java.lang.reflect.Method r11 = r10.f1498q     // Catch:{ Exception -> 0x0239 }
            java.lang.Object[] r0 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x0239 }
            r11.invoke(r12, r0)     // Catch:{ Exception -> 0x0239 }
            goto L_0x0261
        L_0x0239:
            java.lang.StringBuilder r11 = p165e.p166a.p167a.p168a.C4924a.m17863P(r3)
            java.lang.String r0 = r10.f1486e
            r11.append(r0)
            r11.append(r6)
            java.lang.Class r0 = r12.getClass()
            java.lang.String r0 = r0.getSimpleName()
            r11.append(r0)
            r11.append(r5)
            java.lang.String r12 = p098d.p099a.C4567a.m16428c(r12)
            r11.append(r12)
            java.lang.String r11 = r11.toString()
            android.util.Log.e(r7, r11)
        L_0x0261:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.C0356j.mo1893q(float, android.view.View):void");
    }
}
