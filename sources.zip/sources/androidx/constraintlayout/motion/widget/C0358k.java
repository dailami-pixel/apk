package androidx.constraintlayout.motion.widget;

import android.view.View;
import androidx.constraintlayout.widget.C0407a;
import androidx.constraintlayout.widget.C0411c;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Objects;
import p098d.p113e.p114a.p115a.C4637c;
import p098d.p113e.p116b.p117i.C4662e;

/* renamed from: androidx.constraintlayout.motion.widget.k */
class C0358k implements Comparable<C0358k> {

    /* renamed from: a */
    private float f1506a = 1.0f;

    /* renamed from: b */
    int f1507b = 0;

    /* renamed from: c */
    int f1508c;

    /* renamed from: d */
    private float f1509d = 0.0f;

    /* renamed from: e */
    private float f1510e = 0.0f;

    /* renamed from: f */
    private float f1511f = 0.0f;

    /* renamed from: g */
    public float f1512g = 0.0f;

    /* renamed from: h */
    private float f1513h = 1.0f;

    /* renamed from: i */
    private float f1514i = 1.0f;

    /* renamed from: j */
    private float f1515j = Float.NaN;

    /* renamed from: k */
    private float f1516k = Float.NaN;

    /* renamed from: l */
    private float f1517l = 0.0f;

    /* renamed from: m */
    private float f1518m = 0.0f;

    /* renamed from: n */
    private float f1519n = 0.0f;

    /* renamed from: o */
    private float f1520o = Float.NaN;

    /* renamed from: p */
    private float f1521p = Float.NaN;

    /* renamed from: q */
    LinkedHashMap<String, C0407a> f1522q = new LinkedHashMap<>();

    /* renamed from: b */
    private boolean m1692b(float f, float f2) {
        return (Float.isNaN(f) || Float.isNaN(f2)) ? Float.isNaN(f) != Float.isNaN(f2) : Math.abs(f - f2) > 1.0E-6f;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:80:0x016f, code lost:
        r2.mo1955c(r9, r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:99:0x01bb, code lost:
        r2.mo1955c(r9, r6);
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1894a(java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.C0367q> r8, int r9) {
        /*
            r7 = this;
            java.util.Set r0 = r8.keySet()
            java.util.Iterator r0 = r0.iterator()
        L_0x0008:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x020e
            java.lang.Object r1 = r0.next()
            java.lang.String r1 = (java.lang.String) r1
            java.lang.Object r2 = r8.get(r1)
            androidx.constraintlayout.motion.widget.q r2 = (androidx.constraintlayout.motion.widget.C0367q) r2
            r1.hashCode()
            r3 = -1
            int r4 = r1.hashCode()
            r5 = 1
            switch(r4) {
                case -1249320806: goto L_0x00c9;
                case -1249320805: goto L_0x00be;
                case -1225497657: goto L_0x00b3;
                case -1225497656: goto L_0x00a8;
                case -1225497655: goto L_0x009d;
                case -1001078227: goto L_0x0092;
                case -908189618: goto L_0x0087;
                case -908189617: goto L_0x007c;
                case -760884510: goto L_0x006e;
                case -760884509: goto L_0x0060;
                case -40300674: goto L_0x0052;
                case -4379043: goto L_0x0044;
                case 37232917: goto L_0x0036;
                case 92909918: goto L_0x0028;
                default: goto L_0x0026;
            }
        L_0x0026:
            goto L_0x00d3
        L_0x0028:
            java.lang.String r4 = "alpha"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x0032
            goto L_0x00d3
        L_0x0032:
            r3 = 13
            goto L_0x00d3
        L_0x0036:
            java.lang.String r4 = "transitionPathRotate"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x0040
            goto L_0x00d3
        L_0x0040:
            r3 = 12
            goto L_0x00d3
        L_0x0044:
            java.lang.String r4 = "elevation"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x004e
            goto L_0x00d3
        L_0x004e:
            r3 = 11
            goto L_0x00d3
        L_0x0052:
            java.lang.String r4 = "rotation"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x005c
            goto L_0x00d3
        L_0x005c:
            r3 = 10
            goto L_0x00d3
        L_0x0060:
            java.lang.String r4 = "transformPivotY"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x006a
            goto L_0x00d3
        L_0x006a:
            r3 = 9
            goto L_0x00d3
        L_0x006e:
            java.lang.String r4 = "transformPivotX"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x0078
            goto L_0x00d3
        L_0x0078:
            r3 = 8
            goto L_0x00d3
        L_0x007c:
            java.lang.String r4 = "scaleY"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x0085
            goto L_0x00d3
        L_0x0085:
            r3 = 7
            goto L_0x00d3
        L_0x0087:
            java.lang.String r4 = "scaleX"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x0090
            goto L_0x00d3
        L_0x0090:
            r3 = 6
            goto L_0x00d3
        L_0x0092:
            java.lang.String r4 = "progress"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x009b
            goto L_0x00d3
        L_0x009b:
            r3 = 5
            goto L_0x00d3
        L_0x009d:
            java.lang.String r4 = "translationZ"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x00a6
            goto L_0x00d3
        L_0x00a6:
            r3 = 4
            goto L_0x00d3
        L_0x00a8:
            java.lang.String r4 = "translationY"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x00b1
            goto L_0x00d3
        L_0x00b1:
            r3 = 3
            goto L_0x00d3
        L_0x00b3:
            java.lang.String r4 = "translationX"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x00bc
            goto L_0x00d3
        L_0x00bc:
            r3 = 2
            goto L_0x00d3
        L_0x00be:
            java.lang.String r4 = "rotationY"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x00c7
            goto L_0x00d3
        L_0x00c7:
            r3 = 1
            goto L_0x00d3
        L_0x00c9:
            java.lang.String r4 = "rotationX"
            boolean r4 = r1.equals(r4)
            if (r4 != 0) goto L_0x00d2
            goto L_0x00d3
        L_0x00d2:
            r3 = 0
        L_0x00d3:
            r4 = 1065353216(0x3f800000, float:1.0)
            r6 = 0
            switch(r3) {
                case 0: goto L_0x01b0;
                case 1: goto L_0x01a4;
                case 2: goto L_0x0198;
                case 3: goto L_0x018c;
                case 4: goto L_0x0180;
                case 5: goto L_0x0174;
                case 6: goto L_0x0164;
                case 7: goto L_0x0158;
                case 8: goto L_0x014a;
                case 9: goto L_0x013c;
                case 10: goto L_0x012e;
                case 11: goto L_0x0120;
                case 12: goto L_0x0112;
                case 13: goto L_0x0106;
                default: goto L_0x00d9;
            }
        L_0x00d9:
            java.lang.String r3 = "CUSTOM"
            boolean r3 = r1.startsWith(r3)
            if (r3 == 0) goto L_0x01f6
            java.lang.String r3 = ","
            java.lang.String[] r3 = r1.split(r3)
            r3 = r3[r5]
            java.util.LinkedHashMap<java.lang.String, androidx.constraintlayout.widget.a> r4 = r7.f1522q
            boolean r4 = r4.containsKey(r3)
            if (r4 == 0) goto L_0x01e4
            java.util.LinkedHashMap<java.lang.String, androidx.constraintlayout.widget.a> r4 = r7.f1522q
            java.lang.Object r3 = r4.get(r3)
            androidx.constraintlayout.widget.a r3 = (androidx.constraintlayout.widget.C0407a) r3
            boolean r4 = r2 instanceof androidx.constraintlayout.motion.widget.C0367q.C0369b
            if (r4 == 0) goto L_0x01c0
            androidx.constraintlayout.motion.widget.q$b r2 = (androidx.constraintlayout.motion.widget.C0367q.C0369b) r2
            android.util.SparseArray<androidx.constraintlayout.widget.a> r1 = r2.f1659f
            r1.append(r9, r3)
            goto L_0x0008
        L_0x0106:
            float r1 = r7.f1506a
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x010f
            goto L_0x016f
        L_0x010f:
            float r4 = r7.f1506a
            goto L_0x016f
        L_0x0112:
            float r1 = r7.f1520o
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x011c
            goto L_0x01bb
        L_0x011c:
            float r6 = r7.f1520o
            goto L_0x01bb
        L_0x0120:
            float r1 = r7.f1509d
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x012a
            goto L_0x01bb
        L_0x012a:
            float r6 = r7.f1509d
            goto L_0x01bb
        L_0x012e:
            float r1 = r7.f1510e
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x0138
            goto L_0x01bb
        L_0x0138:
            float r6 = r7.f1510e
            goto L_0x01bb
        L_0x013c:
            float r1 = r7.f1516k
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x0146
            goto L_0x01bb
        L_0x0146:
            float r6 = r7.f1516k
            goto L_0x01bb
        L_0x014a:
            float r1 = r7.f1515j
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x0154
            goto L_0x01bb
        L_0x0154:
            float r6 = r7.f1515j
            goto L_0x01bb
        L_0x0158:
            float r1 = r7.f1514i
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x0161
            goto L_0x016f
        L_0x0161:
            float r4 = r7.f1514i
            goto L_0x016f
        L_0x0164:
            float r1 = r7.f1513h
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x016d
            goto L_0x016f
        L_0x016d:
            float r4 = r7.f1513h
        L_0x016f:
            r2.mo1955c(r9, r4)
            goto L_0x0008
        L_0x0174:
            float r1 = r7.f1521p
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x017d
            goto L_0x01bb
        L_0x017d:
            float r6 = r7.f1521p
            goto L_0x01bb
        L_0x0180:
            float r1 = r7.f1519n
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x0189
            goto L_0x01bb
        L_0x0189:
            float r6 = r7.f1519n
            goto L_0x01bb
        L_0x018c:
            float r1 = r7.f1518m
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x0195
            goto L_0x01bb
        L_0x0195:
            float r6 = r7.f1518m
            goto L_0x01bb
        L_0x0198:
            float r1 = r7.f1517l
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x01a1
            goto L_0x01bb
        L_0x01a1:
            float r6 = r7.f1517l
            goto L_0x01bb
        L_0x01a4:
            float r1 = r7.f1512g
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x01ad
            goto L_0x01bb
        L_0x01ad:
            float r6 = r7.f1512g
            goto L_0x01bb
        L_0x01b0:
            float r1 = r7.f1511f
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x01b9
            goto L_0x01bb
        L_0x01b9:
            float r6 = r7.f1511f
        L_0x01bb:
            r2.mo1955c(r9, r6)
            goto L_0x0008
        L_0x01c0:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            r4.append(r1)
            java.lang.String r1 = " splineSet not a CustomSet frame = "
            r4.append(r1)
            r4.append(r9)
            java.lang.String r1 = ", value"
            r4.append(r1)
            float r1 = r3.mo2055c()
            r4.append(r1)
            r4.append(r2)
            java.lang.String r1 = r4.toString()
            goto L_0x0207
        L_0x01e4:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "UNKNOWN customName "
            r1.append(r2)
            r1.append(r3)
            java.lang.String r1 = r1.toString()
            goto L_0x0207
        L_0x01f6:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "UNKNOWN spline "
            r2.append(r3)
            r2.append(r1)
            java.lang.String r1 = r2.toString()
        L_0x0207:
            java.lang.String r2 = "MotionPaths"
            android.util.Log.e(r2, r1)
            goto L_0x0008
        L_0x020e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.C0358k.mo1894a(java.util.HashMap, int):void");
    }

    public int compareTo(Object obj) {
        Objects.requireNonNull((C0358k) obj);
        return Float.compare(0.0f, 0.0f);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public void mo1896f(C0358k kVar, HashSet<String> hashSet) {
        if (m1692b(this.f1506a, kVar.f1506a)) {
            hashSet.add("alpha");
        }
        if (m1692b(this.f1509d, kVar.f1509d)) {
            hashSet.add("elevation");
        }
        int i = this.f1508c;
        int i2 = kVar.f1508c;
        if (i != i2 && this.f1507b == 0 && (i == 0 || i2 == 0)) {
            hashSet.add("alpha");
        }
        if (m1692b(this.f1510e, kVar.f1510e)) {
            hashSet.add("rotation");
        }
        if (!Float.isNaN(this.f1520o) || !Float.isNaN(kVar.f1520o)) {
            hashSet.add("transitionPathRotate");
        }
        if (!Float.isNaN(this.f1521p) || !Float.isNaN(kVar.f1521p)) {
            hashSet.add("progress");
        }
        if (m1692b(this.f1511f, kVar.f1511f)) {
            hashSet.add("rotationX");
        }
        if (m1692b(this.f1512g, kVar.f1512g)) {
            hashSet.add("rotationY");
        }
        if (m1692b(this.f1515j, kVar.f1515j)) {
            hashSet.add("transformPivotX");
        }
        if (m1692b(this.f1516k, kVar.f1516k)) {
            hashSet.add("transformPivotY");
        }
        if (m1692b(this.f1513h, kVar.f1513h)) {
            hashSet.add("scaleX");
        }
        if (m1692b(this.f1514i, kVar.f1514i)) {
            hashSet.add("scaleY");
        }
        if (m1692b(this.f1517l, kVar.f1517l)) {
            hashSet.add("translationX");
        }
        if (m1692b(this.f1518m, kVar.f1518m)) {
            hashSet.add("translationY");
        }
        if (m1692b(this.f1519n, kVar.f1519n)) {
            hashSet.add("translationZ");
        }
    }

    /* renamed from: j */
    public void mo1897j(View view) {
        view.getX();
        view.getY();
        view.getWidth();
        view.getHeight();
        this.f1508c = view.getVisibility();
        this.f1506a = view.getVisibility() != 0 ? 0.0f : view.getAlpha();
        this.f1509d = view.getElevation();
        this.f1510e = view.getRotation();
        this.f1511f = view.getRotationX();
        this.f1512g = view.getRotationY();
        this.f1513h = view.getScaleX();
        this.f1514i = view.getScaleY();
        this.f1515j = view.getPivotX();
        this.f1516k = view.getPivotY();
        this.f1517l = view.getTranslationX();
        this.f1518m = view.getTranslationY();
        this.f1519n = view.getTranslationZ();
    }

    /* renamed from: n */
    public void mo1898n(C4662e eVar, C0411c cVar, int i) {
        eVar.mo21605J();
        eVar.mo21606K();
        C0411c.C0412a o = cVar.mo2073o(i);
        C0411c.C0415d dVar = o.f1896b;
        int i2 = dVar.f1974c;
        this.f1507b = i2;
        int i3 = dVar.f1973b;
        this.f1508c = i3;
        this.f1506a = (i3 == 0 || i2 != 0) ? dVar.f1975d : 0.0f;
        C0411c.C0416e eVar2 = o.f1899e;
        boolean z = eVar2.f1989m;
        this.f1509d = eVar2.f1990n;
        this.f1510e = eVar2.f1979c;
        this.f1511f = eVar2.f1980d;
        this.f1512g = eVar2.f1981e;
        this.f1513h = eVar2.f1982f;
        this.f1514i = eVar2.f1983g;
        this.f1515j = eVar2.f1984h;
        this.f1516k = eVar2.f1985i;
        this.f1517l = eVar2.f1986j;
        this.f1518m = eVar2.f1987k;
        this.f1519n = eVar2.f1988l;
        C4637c.m16704c(o.f1897c.f1967d);
        this.f1520o = o.f1897c.f1971h;
        this.f1521p = o.f1896b.f1976e;
        for (String next : o.f1900f.keySet()) {
            C0407a aVar = o.f1900f.get(next);
            if (aVar.mo2054b() != 5) {
                this.f1522q.put(next, aVar);
            }
        }
    }
}
