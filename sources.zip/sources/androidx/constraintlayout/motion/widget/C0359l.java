package androidx.constraintlayout.motion.widget;

import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.C0411c;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import p098d.p113e.p114a.p115a.C4635b;
import p098d.p113e.p114a.p115a.C4637c;
import p098d.p113e.p114a.p115a.C4643h;
import p098d.p113e.p116b.p117i.C4662e;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.constraintlayout.motion.widget.l */
public class C0359l {

    /* renamed from: A */
    private int f1523A = -1;

    /* renamed from: a */
    View f1524a;

    /* renamed from: b */
    int f1525b;

    /* renamed from: c */
    private int f1526c = -1;

    /* renamed from: d */
    private C0362o f1527d = new C0362o();

    /* renamed from: e */
    private C0362o f1528e = new C0362o();

    /* renamed from: f */
    private C0358k f1529f = new C0358k();

    /* renamed from: g */
    private C0358k f1530g = new C0358k();

    /* renamed from: h */
    private C4635b[] f1531h;

    /* renamed from: i */
    private C4635b f1532i;

    /* renamed from: j */
    float f1533j = Float.NaN;

    /* renamed from: k */
    float f1534k = 0.0f;

    /* renamed from: l */
    float f1535l = 1.0f;

    /* renamed from: m */
    private int[] f1536m;

    /* renamed from: n */
    private double[] f1537n;

    /* renamed from: o */
    private double[] f1538o;

    /* renamed from: p */
    private String[] f1539p;

    /* renamed from: q */
    private int[] f1540q;

    /* renamed from: r */
    private int f1541r = 4;

    /* renamed from: s */
    private float[] f1542s = new float[4];

    /* renamed from: t */
    private ArrayList<C0362o> f1543t = new ArrayList<>();

    /* renamed from: u */
    private float[] f1544u = new float[1];

    /* renamed from: v */
    private ArrayList<C0327a> f1545v = new ArrayList<>();

    /* renamed from: w */
    private HashMap<String, C0383r> f1546w;

    /* renamed from: x */
    private HashMap<String, C0367q> f1547x;

    /* renamed from: y */
    private HashMap<String, C0333e> f1548y;

    /* renamed from: z */
    private C0356j[] f1549z;

    C0359l(View view) {
        this.f1524a = view;
        this.f1525b = view.getId();
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.LayoutParams) {
            String str = ((ConstraintLayout.LayoutParams) layoutParams).f1796U;
        }
    }

    /* renamed from: f */
    private float m1697f(float f, float[] fArr) {
        float f2 = 0.0f;
        float f3 = 1.0f;
        if (fArr != null) {
            fArr[0] = 1.0f;
        } else {
            float f4 = this.f1535l;
            if (((double) f4) != 1.0d) {
                float f5 = this.f1534k;
                if (f < f5) {
                    f = 0.0f;
                }
                if (f > f5 && ((double) f) < 1.0d) {
                    f = (f - f5) * f4;
                }
            }
        }
        C4637c cVar = this.f1527d.f1601b;
        float f6 = Float.NaN;
        Iterator<C0362o> it = this.f1543t.iterator();
        while (it.hasNext()) {
            C0362o next = it.next();
            C4637c cVar2 = next.f1601b;
            if (cVar2 != null) {
                float f7 = next.f1603d;
                if (f7 < f) {
                    cVar = cVar2;
                    f2 = f7;
                } else if (Float.isNaN(f6)) {
                    f6 = next.f1603d;
                }
            }
        }
        if (cVar != null) {
            if (!Float.isNaN(f6)) {
                f3 = f6;
            }
            float f8 = f3 - f2;
            double d = (double) ((f - f2) / f8);
            f = (((float) cVar.mo21492a(d)) * f8) + f2;
            if (fArr != null) {
                fArr[0] = (float) cVar.mo21493b(d);
            }
        }
        return f;
    }

    /* renamed from: n */
    private void m1698n(C0362o oVar) {
        oVar.mo1921n((float) ((int) this.f1524a.getX()), (float) ((int) this.f1524a.getY()), (float) this.f1524a.getWidth(), (float) this.f1524a.getHeight());
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo1899a(C0327a aVar) {
        this.f1545v.add(aVar);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo1900b(ArrayList<C0327a> arrayList) {
        this.f1545v.addAll(arrayList);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public int mo1901c(float[] fArr, int[] iArr) {
        if (fArr == null) {
            return 0;
        }
        double[] h = this.f1531h[0].mo21484h();
        if (iArr != null) {
            Iterator<C0362o> it = this.f1543t.iterator();
            int i = 0;
            while (it.hasNext()) {
                iArr[i] = it.next().f1612m;
                i++;
            }
        }
        int i2 = 0;
        for (double d : h) {
            this.f1531h[0].mo21480d(d, this.f1537n);
            this.f1527d.mo1920j(this.f1536m, this.f1537n, fArr, i2);
            i2 += 2;
        }
        return i2 / 2;
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x007c  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00a0  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00c6  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x00db  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x00e5  */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x00f7  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x0103  */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1902d(float[] r22, int r23) {
        /*
            r21 = this;
            r0 = r21
            r1 = r22
            r2 = r23
            int r3 = r2 + -1
            float r3 = (float) r3
            r4 = 1065353216(0x3f800000, float:1.0)
            float r3 = r4 / r3
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.q> r5 = r0.f1547x
            java.lang.String r6 = "translationX"
            r7 = 0
            if (r5 != 0) goto L_0x0016
            r5 = r7
            goto L_0x001c
        L_0x0016:
            java.lang.Object r5 = r5.get(r6)
            androidx.constraintlayout.motion.widget.q r5 = (androidx.constraintlayout.motion.widget.C0367q) r5
        L_0x001c:
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.q> r8 = r0.f1547x
            java.lang.String r9 = "translationY"
            if (r8 != 0) goto L_0x0024
            r8 = r7
            goto L_0x002a
        L_0x0024:
            java.lang.Object r8 = r8.get(r9)
            androidx.constraintlayout.motion.widget.q r8 = (androidx.constraintlayout.motion.widget.C0367q) r8
        L_0x002a:
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.e> r10 = r0.f1548y
            if (r10 != 0) goto L_0x0030
            r6 = r7
            goto L_0x0036
        L_0x0030:
            java.lang.Object r6 = r10.get(r6)
            androidx.constraintlayout.motion.widget.e r6 = (androidx.constraintlayout.motion.widget.C0333e) r6
        L_0x0036:
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.e> r10 = r0.f1548y
            if (r10 != 0) goto L_0x003b
            goto L_0x0041
        L_0x003b:
            java.lang.Object r7 = r10.get(r9)
            androidx.constraintlayout.motion.widget.e r7 = (androidx.constraintlayout.motion.widget.C0333e) r7
        L_0x0041:
            r10 = 0
        L_0x0042:
            if (r10 >= r2) goto L_0x0118
            float r11 = (float) r10
            float r11 = r11 * r3
            float r12 = r0.f1535l
            int r14 = (r12 > r4 ? 1 : (r12 == r4 ? 0 : -1))
            if (r14 == 0) goto L_0x0065
            float r14 = r0.f1534k
            int r15 = (r11 > r14 ? 1 : (r11 == r14 ? 0 : -1))
            if (r15 >= 0) goto L_0x0054
            r11 = 0
        L_0x0054:
            int r15 = (r11 > r14 ? 1 : (r11 == r14 ? 0 : -1))
            if (r15 <= 0) goto L_0x0065
            r16 = r5
            double r4 = (double) r11
            r17 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            int r19 = (r4 > r17 ? 1 : (r4 == r17 ? 0 : -1))
            if (r19 >= 0) goto L_0x0067
            float r11 = r11 - r14
            float r11 = r11 * r12
            goto L_0x0067
        L_0x0065:
            r16 = r5
        L_0x0067:
            double r4 = (double) r11
            androidx.constraintlayout.motion.widget.o r12 = r0.f1527d
            d.e.a.a.c r12 = r12.f1601b
            r14 = 2143289344(0x7fc00000, float:NaN)
            java.util.ArrayList<androidx.constraintlayout.motion.widget.o> r13 = r0.f1543t
            java.util.Iterator r13 = r13.iterator()
            r17 = 0
        L_0x0076:
            boolean r18 = r13.hasNext()
            if (r18 == 0) goto L_0x009e
            java.lang.Object r18 = r13.next()
            r15 = r18
            androidx.constraintlayout.motion.widget.o r15 = (androidx.constraintlayout.motion.widget.C0362o) r15
            d.e.a.a.c r9 = r15.f1601b
            if (r9 == 0) goto L_0x009b
            float r2 = r15.f1603d
            int r20 = (r2 > r11 ? 1 : (r2 == r11 ? 0 : -1))
            if (r20 >= 0) goto L_0x0092
            r17 = r2
            r12 = r9
            goto L_0x009b
        L_0x0092:
            boolean r2 = java.lang.Float.isNaN(r14)
            if (r2 == 0) goto L_0x009b
            float r2 = r15.f1603d
            r14 = r2
        L_0x009b:
            r2 = r23
            goto L_0x0076
        L_0x009e:
            if (r12 == 0) goto L_0x00b8
            boolean r2 = java.lang.Float.isNaN(r14)
            if (r2 == 0) goto L_0x00a8
            r14 = 1065353216(0x3f800000, float:1.0)
        L_0x00a8:
            float r2 = r11 - r17
            float r14 = r14 - r17
            float r2 = r2 / r14
            double r4 = (double) r2
            double r4 = r12.mo21492a(r4)
            float r2 = (float) r4
            float r2 = r2 * r14
            float r2 = r2 + r17
            double r4 = (double) r2
        L_0x00b8:
            d.e.a.a.b[] r2 = r0.f1531h
            r9 = 0
            r2 = r2[r9]
            double[] r12 = r0.f1537n
            r2.mo21480d(r4, r12)
            d.e.a.a.b r2 = r0.f1532i
            if (r2 == 0) goto L_0x00ce
            double[] r12 = r0.f1537n
            int r13 = r12.length
            if (r13 <= 0) goto L_0x00ce
            r2.mo21480d(r4, r12)
        L_0x00ce:
            androidx.constraintlayout.motion.widget.o r2 = r0.f1527d
            int[] r4 = r0.f1536m
            double[] r5 = r0.f1537n
            int r12 = r10 * 2
            r2.mo1920j(r4, r5, r1, r12)
            if (r6 == 0) goto L_0x00e5
            r2 = r1[r12]
            float r4 = r6.mo1882a(r11)
            float r4 = r4 + r2
            r1[r12] = r4
            goto L_0x00f3
        L_0x00e5:
            if (r16 == 0) goto L_0x00f3
            r2 = r1[r12]
            r5 = r16
            float r4 = r5.mo1953a(r11)
            float r4 = r4 + r2
            r1[r12] = r4
            goto L_0x00f5
        L_0x00f3:
            r5 = r16
        L_0x00f5:
            if (r7 == 0) goto L_0x0103
            int r12 = r12 + 1
            r2 = r1[r12]
            float r4 = r7.mo1882a(r11)
            float r4 = r4 + r2
            r1[r12] = r4
            goto L_0x0110
        L_0x0103:
            if (r8 == 0) goto L_0x0110
            int r12 = r12 + 1
            r2 = r1[r12]
            float r4 = r8.mo1953a(r11)
            float r4 = r4 + r2
            r1[r12] = r4
        L_0x0110:
            int r10 = r10 + 1
            r2 = r23
            r4 = 1065353216(0x3f800000, float:1.0)
            goto L_0x0042
        L_0x0118:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.C0359l.mo1902d(float[], int):void");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo1903e(float f, float[] fArr, int i) {
        this.f1531h[0].mo21480d((double) m1697f(f, (float[]) null), this.f1537n);
        C0362o oVar = this.f1527d;
        int[] iArr = this.f1536m;
        double[] dArr = this.f1537n;
        float f2 = oVar.f1605f;
        float f3 = oVar.f1606g;
        float f4 = oVar.f1607h;
        float f5 = oVar.f1608i;
        for (int i2 = 0; i2 < iArr.length; i2++) {
            float f6 = (float) dArr[i2];
            int i3 = iArr[i2];
            if (i3 == 1) {
                f2 = f6;
            } else if (i3 == 2) {
                f3 = f6;
            } else if (i3 == 3) {
                f4 = f6;
            } else if (i3 == 4) {
                f5 = f6;
            }
        }
        float f7 = f4 + f2;
        float f8 = f5 + f3;
        Float.isNaN(Float.NaN);
        Float.isNaN(Float.NaN);
        float f9 = f2 + 0.0f;
        float f10 = f3 + 0.0f;
        float f11 = f7 + 0.0f;
        float f12 = f8 + 0.0f;
        int i4 = i + 1;
        fArr[i] = f9;
        int i5 = i4 + 1;
        fArr[i4] = f10;
        int i6 = i5 + 1;
        fArr[i5] = f11;
        int i7 = i6 + 1;
        fArr[i6] = f10;
        int i8 = i7 + 1;
        fArr[i7] = f11;
        int i9 = i8 + 1;
        fArr[i8] = f12;
        fArr[i9] = f9;
        fArr[i9 + 1] = f12;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public void mo1904g(float f, float f2, float f3, float[] fArr) {
        double[] dArr;
        float f4 = m1697f(f, this.f1544u);
        C4635b[] bVarArr = this.f1531h;
        int i = 0;
        if (bVarArr != null) {
            double d = (double) f4;
            bVarArr[0].mo21483g(d, this.f1538o);
            this.f1531h[0].mo21480d(d, this.f1537n);
            float f5 = this.f1544u[0];
            while (true) {
                dArr = this.f1538o;
                if (i >= dArr.length) {
                    break;
                }
                dArr[i] = dArr[i] * ((double) f5);
                i++;
            }
            C4635b bVar = this.f1532i;
            if (bVar != null) {
                double[] dArr2 = this.f1537n;
                if (dArr2.length > 0) {
                    bVar.mo21480d(d, dArr2);
                    this.f1532i.mo21483g(d, this.f1538o);
                    this.f1527d.mo1922o(f2, f3, fArr, this.f1536m, this.f1538o, this.f1537n);
                    return;
                }
                return;
            }
            this.f1527d.mo1922o(f2, f3, fArr, this.f1536m, dArr, this.f1537n);
            return;
        }
        C0362o oVar = this.f1528e;
        float f6 = oVar.f1605f;
        C0362o oVar2 = this.f1527d;
        float f7 = f6 - oVar2.f1605f;
        float f8 = oVar.f1606g - oVar2.f1606g;
        fArr[0] = (((oVar.f1607h - oVar2.f1607h) + f7) * f2) + ((1.0f - f2) * f7);
        fArr[1] = (((oVar.f1608i - oVar2.f1608i) + f8) * f3) + ((1.0f - f3) * f8);
    }

    /* renamed from: h */
    public int mo1905h() {
        int i = this.f1527d.f1602c;
        Iterator<C0362o> it = this.f1543t.iterator();
        while (it.hasNext()) {
            i = Math.max(i, it.next().f1602c);
        }
        return Math.max(i, this.f1528e.f1602c);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public float mo1906i() {
        return this.f1528e.f1605f;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j */
    public float mo1907j() {
        return this.f1528e.f1606g;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k */
    public C0362o mo1908k(int i) {
        return this.f1543t.get(i);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l */
    public void mo1909l(float f, int i, int i2, float f2, float f3, float[] fArr) {
        float f4 = m1697f(f, this.f1544u);
        HashMap<String, C0367q> hashMap = this.f1547x;
        C0333e eVar = null;
        C0367q qVar = hashMap == null ? null : hashMap.get("translationX");
        HashMap<String, C0367q> hashMap2 = this.f1547x;
        C0367q qVar2 = hashMap2 == null ? null : hashMap2.get("translationY");
        HashMap<String, C0367q> hashMap3 = this.f1547x;
        C0367q qVar3 = hashMap3 == null ? null : hashMap3.get("rotation");
        HashMap<String, C0367q> hashMap4 = this.f1547x;
        C0367q qVar4 = hashMap4 == null ? null : hashMap4.get("scaleX");
        HashMap<String, C0367q> hashMap5 = this.f1547x;
        C0367q qVar5 = hashMap5 == null ? null : hashMap5.get("scaleY");
        HashMap<String, C0333e> hashMap6 = this.f1548y;
        C0333e eVar2 = hashMap6 == null ? null : hashMap6.get("translationX");
        HashMap<String, C0333e> hashMap7 = this.f1548y;
        C0333e eVar3 = hashMap7 == null ? null : hashMap7.get("translationY");
        HashMap<String, C0333e> hashMap8 = this.f1548y;
        C0333e eVar4 = hashMap8 == null ? null : hashMap8.get("rotation");
        HashMap<String, C0333e> hashMap9 = this.f1548y;
        C0333e eVar5 = hashMap9 == null ? null : hashMap9.get("scaleX");
        HashMap<String, C0333e> hashMap10 = this.f1548y;
        if (hashMap10 != null) {
            eVar = hashMap10.get("scaleY");
        }
        C4643h hVar = new C4643h();
        hVar.mo21507b();
        hVar.mo21509d(qVar3, f4);
        hVar.mo21513h(qVar, qVar2, f4);
        hVar.mo21511f(qVar4, qVar5, f4);
        hVar.mo21508c(eVar4, f4);
        hVar.mo21512g(eVar2, eVar3, f4);
        hVar.mo21510e(eVar5, eVar, f4);
        C4635b bVar = this.f1532i;
        if (bVar != null) {
            double[] dArr = this.f1537n;
            if (dArr.length > 0) {
                double d = (double) f4;
                bVar.mo21480d(d, dArr);
                this.f1532i.mo21483g(d, this.f1538o);
                this.f1527d.mo1922o(f2, f3, fArr, this.f1536m, this.f1538o, this.f1537n);
            }
            hVar.mo21506a(f2, f3, i, i2, fArr);
            return;
        }
        int i3 = 0;
        if (this.f1531h != null) {
            double f5 = (double) m1697f(f4, this.f1544u);
            this.f1531h[0].mo21483g(f5, this.f1538o);
            this.f1531h[0].mo21480d(f5, this.f1537n);
            float f6 = this.f1544u[0];
            while (true) {
                double[] dArr2 = this.f1538o;
                if (i3 < dArr2.length) {
                    dArr2[i3] = dArr2[i3] * ((double) f6);
                    i3++;
                } else {
                    float f7 = f2;
                    float f8 = f3;
                    this.f1527d.mo1922o(f7, f8, fArr, this.f1536m, dArr2, this.f1537n);
                    hVar.mo21506a(f7, f8, i, i2, fArr);
                    return;
                }
            }
        } else {
            C0362o oVar = this.f1528e;
            float f9 = oVar.f1605f;
            C0362o oVar2 = this.f1527d;
            float f10 = f9 - oVar2.f1605f;
            float f11 = oVar.f1606g - oVar2.f1606g;
            fArr[0] = (((oVar.f1607h - oVar2.f1607h) + f10) * f2) + ((1.0f - f2) * f10);
            fArr[1] = (((oVar.f1608i - oVar2.f1608i) + f11) * f3) + ((1.0f - f3) * f11);
            hVar.mo21507b();
            hVar.mo21509d(qVar3, f4);
            hVar.mo21513h(qVar, qVar2, f4);
            hVar.mo21511f(qVar4, qVar5, f4);
            hVar.mo21508c(eVar4, f4);
            hVar.mo21512g(eVar2, eVar3, f4);
            hVar.mo21510e(eVar5, eVar, f4);
            hVar.mo21506a(f2, f3, i, i2, fArr);
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:108:0x0263  */
    /* JADX WARNING: Removed duplicated region for block: B:147:0x023c A[EDGE_INSN: B:147:0x023c->B:94:0x023c ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x0198  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x019a  */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x019d  */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x01b1  */
    /* JADX WARNING: Removed duplicated region for block: B:88:0x01ee  */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x0215  */
    /* JADX WARNING: Removed duplicated region for block: B:93:0x021d A[LOOP:5: B:91:0x0218->B:93:0x021d, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:96:0x0242  */
    /* renamed from: m */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo1910m(android.view.View r24, float r25, long r26, androidx.constraintlayout.motion.widget.C0330c r28) {
        /*
            r23 = this;
            r0 = r23
            r7 = r24
            r1 = 0
            r2 = r25
            float r8 = r0.m1697f(r2, r1)
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.q> r2 = r0.f1547x
            if (r2 == 0) goto L_0x0027
            java.util.Collection r2 = r2.values()
            java.util.Iterator r2 = r2.iterator()
        L_0x0017:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x0027
            java.lang.Object r3 = r2.next()
            androidx.constraintlayout.motion.widget.q r3 = (androidx.constraintlayout.motion.widget.C0367q) r3
            r3.mo1956d(r7, r8)
            goto L_0x0017
        L_0x0027:
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.r> r2 = r0.f1546w
            r9 = 0
            if (r2 == 0) goto L_0x0058
            java.util.Collection r2 = r2.values()
            java.util.Iterator r10 = r2.iterator()
            r2 = 0
            r11 = r1
            r12 = 0
        L_0x0037:
            boolean r1 = r10.hasNext()
            if (r1 == 0) goto L_0x005a
            java.lang.Object r1 = r10.next()
            androidx.constraintlayout.motion.widget.r r1 = (androidx.constraintlayout.motion.widget.C0383r) r1
            boolean r2 = r1 instanceof androidx.constraintlayout.motion.widget.C0383r.C0387d
            if (r2 == 0) goto L_0x004b
            r11 = r1
            androidx.constraintlayout.motion.widget.r$d r11 = (androidx.constraintlayout.motion.widget.C0383r.C0387d) r11
            goto L_0x0037
        L_0x004b:
            r2 = r24
            r3 = r8
            r4 = r26
            r6 = r28
            boolean r1 = r1.mo1963d(r2, r3, r4, r6)
            r12 = r12 | r1
            goto L_0x0037
        L_0x0058:
            r12 = 0
            r11 = r1
        L_0x005a:
            d.e.a.a.b[] r1 = r0.f1531h
            if (r1 == 0) goto L_0x0277
            r1 = r1[r9]
            double r13 = (double) r8
            double[] r2 = r0.f1537n
            r1.mo21480d(r13, r2)
            d.e.a.a.b[] r1 = r0.f1531h
            r1 = r1[r9]
            double[] r2 = r0.f1538o
            r1.mo21483g(r13, r2)
            d.e.a.a.b r1 = r0.f1532i
            if (r1 == 0) goto L_0x0082
            double[] r2 = r0.f1537n
            int r3 = r2.length
            if (r3 <= 0) goto L_0x0082
            r1.mo21480d(r13, r2)
            d.e.a.a.b r1 = r0.f1532i
            double[] r2 = r0.f1538o
            r1.mo21483g(r13, r2)
        L_0x0082:
            androidx.constraintlayout.motion.widget.o r1 = r0.f1527d
            int[] r2 = r0.f1536m
            double[] r3 = r0.f1537n
            double[] r4 = r0.f1538o
            float r5 = r1.f1605f
            float r6 = r1.f1606g
            float r9 = r1.f1607h
            float r10 = r1.f1608i
            int r15 = r2.length
            if (r15 == 0) goto L_0x00b1
            double[] r15 = r1.f1613n
            int r15 = r15.length
            r25 = r5
            int r5 = r2.length
            int r5 = r5 + -1
            r5 = r2[r5]
            if (r15 > r5) goto L_0x00b3
            int r5 = r2.length
            int r5 = r5 + -1
            r5 = r2[r5]
            int r5 = r5 + 1
            double[] r15 = new double[r5]
            r1.f1613n = r15
            double[] r5 = new double[r5]
            r1.f1614o = r5
            goto L_0x00b3
        L_0x00b1:
            r25 = r5
        L_0x00b3:
            double[] r5 = r1.f1613n
            r15 = r9
            r16 = r10
            r9 = 9221120237041090560(0x7ff8000000000000, double:NaN)
            java.util.Arrays.fill(r5, r9)
            r5 = 0
        L_0x00be:
            int r9 = r2.length
            if (r5 >= r9) goto L_0x00d4
            double[] r9 = r1.f1613n
            r10 = r2[r5]
            r17 = r3[r5]
            r9[r10] = r17
            double[] r9 = r1.f1614o
            r10 = r2[r5]
            r17 = r4[r5]
            r9[r10] = r17
            int r5 = r5 + 1
            goto L_0x00be
        L_0x00d4:
            r2 = 0
            r3 = 2143289344(0x7fc00000, float:NaN)
            r4 = 0
            r5 = 0
            r9 = 0
            r10 = 0
            r9 = r6
            r17 = r16
            r10 = 0
            r16 = 0
            r6 = r25
            r25 = r12
        L_0x00e5:
            double[] r12 = r1.f1613n
            r18 = r8
            int r8 = r12.length
            if (r2 >= r8) goto L_0x013d
            r19 = r12[r2]
            boolean r8 = java.lang.Double.isNaN(r19)
            if (r8 == 0) goto L_0x00f6
            r8 = r11
            goto L_0x0137
        L_0x00f6:
            r19 = 0
            double[] r8 = r1.f1613n
            r21 = r8[r2]
            boolean r8 = java.lang.Double.isNaN(r21)
            if (r8 == 0) goto L_0x0103
            goto L_0x0109
        L_0x0103:
            double[] r8 = r1.f1613n
            r21 = r8[r2]
            double r19 = r21 + r19
        L_0x0109:
            r8 = r11
            r11 = r19
            float r11 = (float) r11
            double[] r12 = r1.f1614o
            r19 = r11
            r11 = r12[r2]
            float r11 = (float) r11
            r12 = 1
            if (r2 == r12) goto L_0x0134
            r12 = 2
            if (r2 == r12) goto L_0x0130
            r12 = 3
            if (r2 == r12) goto L_0x012c
            r12 = 4
            if (r2 == r12) goto L_0x0127
            r11 = 5
            if (r2 == r11) goto L_0x0124
            goto L_0x0137
        L_0x0124:
            r3 = r19
            goto L_0x0137
        L_0x0127:
            r16 = r11
            r17 = r19
            goto L_0x0137
        L_0x012c:
            r5 = r11
            r15 = r19
            goto L_0x0137
        L_0x0130:
            r10 = r11
            r9 = r19
            goto L_0x0137
        L_0x0134:
            r4 = r11
            r6 = r19
        L_0x0137:
            int r2 = r2 + 1
            r11 = r8
            r8 = r18
            goto L_0x00e5
        L_0x013d:
            r8 = r11
            boolean r1 = java.lang.Float.isNaN(r3)
            if (r1 == 0) goto L_0x0154
            r1 = 2143289344(0x7fc00000, float:NaN)
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0151
            r1 = 2143289344(0x7fc00000, float:NaN)
            r19 = r13
            goto L_0x0179
        L_0x0151:
            r19 = r13
            goto L_0x017c
        L_0x0154:
            r1 = 2143289344(0x7fc00000, float:NaN)
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x015e
            r1 = 0
            goto L_0x0160
        L_0x015e:
            r1 = 2143289344(0x7fc00000, float:NaN)
        L_0x0160:
            r2 = 1073741824(0x40000000, float:2.0)
            float r5 = r5 / r2
            float r5 = r5 + r4
            float r16 = r16 / r2
            float r2 = r16 + r10
            double r10 = (double) r1
            double r3 = (double) r3
            double r1 = (double) r2
            r19 = r13
            double r12 = (double) r5
            double r1 = java.lang.Math.atan2(r1, r12)
            double r1 = java.lang.Math.toDegrees(r1)
            double r1 = r1 + r3
            double r1 = r1 + r10
            float r1 = (float) r1
        L_0x0179:
            r7.setRotation(r1)
        L_0x017c:
            r1 = 1056964608(0x3f000000, float:0.5)
            float r6 = r6 + r1
            int r2 = (int) r6
            float r9 = r9 + r1
            int r1 = (int) r9
            float r6 = r6 + r15
            int r3 = (int) r6
            float r9 = r9 + r17
            int r4 = (int) r9
            int r5 = r3 - r2
            int r6 = r4 - r1
            int r9 = r24.getMeasuredWidth()
            if (r5 != r9) goto L_0x019a
            int r9 = r24.getMeasuredHeight()
            if (r6 == r9) goto L_0x0198
            goto L_0x019a
        L_0x0198:
            r9 = 0
            goto L_0x019b
        L_0x019a:
            r9 = 1
        L_0x019b:
            if (r9 == 0) goto L_0x01aa
            r9 = 1073741824(0x40000000, float:2.0)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r9)
            int r6 = android.view.View.MeasureSpec.makeMeasureSpec(r6, r9)
            r7.measure(r5, r6)
        L_0x01aa:
            r7.layout(r2, r1, r3, r4)
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.q> r1 = r0.f1547x
            if (r1 == 0) goto L_0x01ea
            java.util.Collection r1 = r1.values()
            java.util.Iterator r1 = r1.iterator()
        L_0x01b9:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x01ea
            java.lang.Object r2 = r1.next()
            androidx.constraintlayout.motion.widget.q r2 = (androidx.constraintlayout.motion.widget.C0367q) r2
            boolean r3 = r2 instanceof androidx.constraintlayout.motion.widget.C0367q.C0371d
            if (r3 == 0) goto L_0x01b9
            androidx.constraintlayout.motion.widget.q$d r2 = (androidx.constraintlayout.motion.widget.C0367q.C0371d) r2
            double[] r3 = r0.f1538o
            r4 = 0
            r5 = r3[r4]
            r9 = 1
            r9 = r3[r9]
            d.e.a.a.b r2 = r2.f1654a
            r11 = r19
            double r2 = r2.mo21479c(r11, r4)
            float r2 = (float) r2
            double r3 = java.lang.Math.atan2(r9, r5)
            double r3 = java.lang.Math.toDegrees(r3)
            float r3 = (float) r3
            float r2 = r2 + r3
            r7.setRotation(r2)
            goto L_0x01b9
        L_0x01ea:
            r11 = r19
            if (r8 == 0) goto L_0x0215
            double[] r1 = r0.f1538o
            r2 = 0
            r9 = r1[r2]
            r2 = 1
            r13 = r1[r2]
            r1 = r8
            r2 = r18
            r3 = r26
            r5 = r24
            r6 = r28
            float r1 = r1.mo1961b(r2, r3, r5, r6)
            double r2 = java.lang.Math.atan2(r13, r9)
            double r2 = java.lang.Math.toDegrees(r2)
            float r2 = (float) r2
            float r1 = r1 + r2
            r7.setRotation(r1)
            boolean r1 = r8.f1669h
            r1 = r1 | r25
            goto L_0x0217
        L_0x0215:
            r1 = r25
        L_0x0217:
            r2 = 1
        L_0x0218:
            d.e.a.a.b[] r3 = r0.f1531h
            int r4 = r3.length
            if (r2 >= r4) goto L_0x023c
            r3 = r3[r2]
            float[] r4 = r0.f1542s
            r3.mo21481e(r11, r4)
            androidx.constraintlayout.motion.widget.o r3 = r0.f1527d
            java.util.LinkedHashMap<java.lang.String, androidx.constraintlayout.widget.a> r3 = r3.f1611l
            java.lang.String[] r4 = r0.f1539p
            int r5 = r2 + -1
            r4 = r4[r5]
            java.lang.Object r3 = r3.get(r4)
            androidx.constraintlayout.widget.a r3 = (androidx.constraintlayout.widget.C0407a) r3
            float[] r4 = r0.f1542s
            r3.mo2058h(r7, r4)
            int r2 = r2 + 1
            goto L_0x0218
        L_0x023c:
            androidx.constraintlayout.motion.widget.k r2 = r0.f1529f
            int r3 = r2.f1507b
            if (r3 != 0) goto L_0x025f
            r3 = 0
            int r3 = (r18 > r3 ? 1 : (r18 == r3 ? 0 : -1))
            if (r3 > 0) goto L_0x0248
            goto L_0x0250
        L_0x0248:
            r3 = 1065353216(0x3f800000, float:1.0)
            int r3 = (r18 > r3 ? 1 : (r18 == r3 ? 0 : -1))
            if (r3 < 0) goto L_0x0253
            androidx.constraintlayout.motion.widget.k r2 = r0.f1530g
        L_0x0250:
            int r2 = r2.f1508c
            goto L_0x025c
        L_0x0253:
            androidx.constraintlayout.motion.widget.k r3 = r0.f1530g
            int r3 = r3.f1508c
            int r2 = r2.f1508c
            if (r3 == r2) goto L_0x025f
            r2 = 0
        L_0x025c:
            r7.setVisibility(r2)
        L_0x025f:
            androidx.constraintlayout.motion.widget.j[] r2 = r0.f1549z
            if (r2 == 0) goto L_0x0273
            r2 = 0
        L_0x0264:
            androidx.constraintlayout.motion.widget.j[] r3 = r0.f1549z
            int r4 = r3.length
            if (r2 >= r4) goto L_0x0273
            r3 = r3[r2]
            r4 = r18
            r3.mo1893q(r4, r7)
            int r2 = r2 + 1
            goto L_0x0264
        L_0x0273:
            r4 = r18
            r12 = r1
            goto L_0x02c6
        L_0x0277:
            r4 = r8
            r25 = r12
            androidx.constraintlayout.motion.widget.o r1 = r0.f1527d
            float r2 = r1.f1605f
            androidx.constraintlayout.motion.widget.o r3 = r0.f1528e
            float r5 = r3.f1605f
            float r2 = p165e.p166a.p167a.p168a.C4924a.m17874a(r5, r2, r4, r2)
            float r5 = r1.f1606g
            float r6 = r3.f1606g
            float r5 = p165e.p166a.p167a.p168a.C4924a.m17874a(r6, r5, r4, r5)
            float r6 = r1.f1607h
            float r8 = r3.f1607h
            float r9 = p165e.p166a.p167a.p168a.C4924a.m17874a(r8, r6, r4, r6)
            float r1 = r1.f1608i
            float r3 = r3.f1608i
            float r10 = p165e.p166a.p167a.p168a.C4924a.m17874a(r3, r1, r4, r1)
            r11 = 1056964608(0x3f000000, float:0.5)
            float r2 = r2 + r11
            int r12 = (int) r2
            float r5 = r5 + r11
            int r11 = (int) r5
            float r2 = r2 + r9
            int r2 = (int) r2
            float r5 = r5 + r10
            int r5 = (int) r5
            int r9 = r2 - r12
            int r10 = r5 - r11
            int r6 = (r8 > r6 ? 1 : (r8 == r6 ? 0 : -1))
            if (r6 != 0) goto L_0x02b4
            int r1 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1))
            if (r1 == 0) goto L_0x02c1
        L_0x02b4:
            r1 = 1073741824(0x40000000, float:2.0)
            int r3 = android.view.View.MeasureSpec.makeMeasureSpec(r9, r1)
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r10, r1)
            r7.measure(r3, r1)
        L_0x02c1:
            r7.layout(r12, r11, r2, r5)
            r12 = r25
        L_0x02c6:
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.e> r1 = r0.f1548y
            if (r1 == 0) goto L_0x0302
            java.util.Collection r1 = r1.values()
            java.util.Iterator r1 = r1.iterator()
        L_0x02d2:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x0302
            java.lang.Object r2 = r1.next()
            androidx.constraintlayout.motion.widget.e r2 = (androidx.constraintlayout.motion.widget.C0333e) r2
            boolean r3 = r2 instanceof androidx.constraintlayout.motion.widget.C0333e.C0339f
            if (r3 == 0) goto L_0x02fe
            androidx.constraintlayout.motion.widget.e$f r2 = (androidx.constraintlayout.motion.widget.C0333e.C0339f) r2
            double[] r3 = r0.f1538o
            r5 = 0
            r5 = r3[r5]
            r8 = 1
            r8 = r3[r8]
            float r2 = r2.mo1882a(r4)
            double r5 = java.lang.Math.atan2(r8, r5)
            double r5 = java.lang.Math.toDegrees(r5)
            float r3 = (float) r5
            float r2 = r2 + r3
            r7.setRotation(r2)
            goto L_0x02d2
        L_0x02fe:
            r2.mo1886e(r7, r4)
            goto L_0x02d2
        L_0x0302:
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.C0359l.mo1910m(android.view.View, float, long, androidx.constraintlayout.motion.widget.c):boolean");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: o */
    public void mo1911o(C4662e eVar, C0411c cVar) {
        C0362o oVar = this.f1528e;
        oVar.f1603d = 1.0f;
        oVar.f1604e = 1.0f;
        m1698n(oVar);
        this.f1528e.mo1921n((float) eVar.mo21605J(), (float) eVar.mo21606K(), (float) eVar.mo21604I(), (float) eVar.mo21651t());
        this.f1528e.mo1917a(cVar.mo2073o(this.f1525b));
        this.f1530g.mo1898n(eVar, cVar, this.f1525b);
    }

    /* renamed from: p */
    public void mo1912p(int i) {
        this.f1523A = i;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q */
    public void mo1913q(View view) {
        C0362o oVar = this.f1527d;
        oVar.f1603d = 0.0f;
        oVar.f1604e = 0.0f;
        oVar.mo1921n(view.getX(), view.getY(), (float) view.getWidth(), (float) view.getHeight());
        this.f1529f.mo1897j(view);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: r */
    public void mo1914r(C4662e eVar, C0411c cVar) {
        C0362o oVar = this.f1527d;
        oVar.f1603d = 0.0f;
        oVar.f1604e = 0.0f;
        m1698n(oVar);
        this.f1527d.mo1921n((float) eVar.mo21605J(), (float) eVar.mo21606K(), (float) eVar.mo21604I(), (float) eVar.mo21651t());
        C0411c.C0412a o = cVar.mo2073o(this.f1525b);
        this.f1527d.mo1917a(o);
        this.f1533j = o.f1897c.f1970g;
        this.f1529f.mo1898n(eVar, cVar, this.f1525b);
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:338:0x07f6, code lost:
        r4 = r28;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:365:0x08d5, code lost:
        r11 = r29;
        r5 = r16;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:370:0x08f4, code lost:
        r10 = r19;
        r9 = r20;
        r8 = r22;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:382:0x094c, code lost:
        r11 = r29;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:387:0x0969, code lost:
        r12 = 65535;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:388:0x096a, code lost:
        switch(r12) {
            case 0: goto L_0x09bd;
            case 1: goto L_0x09b7;
            case 2: goto L_0x09b1;
            case 3: goto L_0x09ab;
            case 4: goto L_0x09a5;
            case 5: goto L_0x099f;
            case 6: goto L_0x0999;
            case 7: goto L_0x0993;
            case 8: goto L_0x098d;
            case 9: goto L_0x0987;
            case 10: goto L_0x0981;
            case 11: goto L_0x097b;
            case 12: goto L_0x0975;
            case 13: goto L_0x096f;
            default: goto L_0x096d;
        };
     */
    /* JADX WARNING: Code restructure failed: missing block: B:389:0x096d, code lost:
        r12 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:390:0x096f, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0335b();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:391:0x0975, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0335b();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:392:0x097b, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0339f();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:393:0x0981, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0338e();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:394:0x0987, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0341h();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:395:0x098d, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0335b();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:396:0x0993, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0345l();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:397:0x0999, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0344k();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:398:0x099f, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0340g();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:399:0x09a5, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0348o();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:400:0x09ab, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0347n();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:401:0x09b1, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0346m();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:402:0x09b7, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0343j();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:403:0x09bd, code lost:
        r12 = new androidx.constraintlayout.motion.widget.C0333e.C0342i();
     */
    /* renamed from: s */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1915s(int r28, int r29, long r30) {
        /*
            r27 = this;
            r0 = r27
            java.util.HashSet r1 = new java.util.HashSet
            r1.<init>()
            java.util.HashSet r1 = new java.util.HashSet
            r1.<init>()
            java.util.HashSet r2 = new java.util.HashSet
            r2.<init>()
            java.util.HashSet r3 = new java.util.HashSet
            r3.<init>()
            java.util.HashMap r4 = new java.util.HashMap
            r4.<init>()
            int r5 = r0.f1523A
            r6 = -1
            if (r5 == r6) goto L_0x0024
            androidx.constraintlayout.motion.widget.o r7 = r0.f1527d
            r7.f1610k = r5
        L_0x0024:
            androidx.constraintlayout.motion.widget.k r5 = r0.f1529f
            androidx.constraintlayout.motion.widget.k r7 = r0.f1530g
            r5.mo1896f(r7, r2)
            java.util.ArrayList<androidx.constraintlayout.motion.widget.a> r5 = r0.f1545v
            if (r5 == 0) goto L_0x00ac
            java.util.Iterator r5 = r5.iterator()
            r7 = 0
        L_0x0034:
            boolean r8 = r5.hasNext()
            if (r8 == 0) goto L_0x00ad
            java.lang.Object r8 = r5.next()
            androidx.constraintlayout.motion.widget.a r8 = (androidx.constraintlayout.motion.widget.C0327a) r8
            boolean r9 = r8 instanceof androidx.constraintlayout.motion.widget.C0351g
            if (r9 == 0) goto L_0x0084
            androidx.constraintlayout.motion.widget.g r8 = (androidx.constraintlayout.motion.widget.C0351g) r8
            androidx.constraintlayout.motion.widget.o r9 = new androidx.constraintlayout.motion.widget.o
            androidx.constraintlayout.motion.widget.o r14 = r0.f1527d
            androidx.constraintlayout.motion.widget.o r15 = r0.f1528e
            r10 = r9
            r11 = r28
            r12 = r29
            r13 = r8
            r10.<init>(r11, r12, r13, r14, r15)
            java.util.ArrayList<androidx.constraintlayout.motion.widget.o> r10 = r0.f1543t
            int r10 = java.util.Collections.binarySearch(r10, r9)
            if (r10 != 0) goto L_0x0076
            java.lang.String r11 = " KeyPath positon \""
            java.lang.StringBuilder r11 = p165e.p166a.p167a.p168a.C4924a.m17863P(r11)
            float r12 = r9.f1604e
            r11.append(r12)
            java.lang.String r12 = "\" outside of range"
            r11.append(r12)
            java.lang.String r11 = r11.toString()
            java.lang.String r12 = "MotionController"
            android.util.Log.e(r12, r11)
        L_0x0076:
            java.util.ArrayList<androidx.constraintlayout.motion.widget.o> r11 = r0.f1543t
            int r10 = -r10
            int r10 = r10 + r6
            r11.add(r10, r9)
            int r8 = r8.f1468e
            if (r8 == r6) goto L_0x0034
            r0.f1526c = r8
            goto L_0x0034
        L_0x0084:
            boolean r9 = r8 instanceof androidx.constraintlayout.motion.widget.C0331d
            if (r9 == 0) goto L_0x008c
            r8.mo1878b(r3)
            goto L_0x0034
        L_0x008c:
            boolean r9 = r8 instanceof androidx.constraintlayout.motion.widget.C0354i
            if (r9 == 0) goto L_0x0094
            r8.mo1878b(r1)
            goto L_0x0034
        L_0x0094:
            boolean r9 = r8 instanceof androidx.constraintlayout.motion.widget.C0356j
            if (r9 == 0) goto L_0x00a5
            if (r7 != 0) goto L_0x009f
            java.util.ArrayList r7 = new java.util.ArrayList
            r7.<init>()
        L_0x009f:
            androidx.constraintlayout.motion.widget.j r8 = (androidx.constraintlayout.motion.widget.C0356j) r8
            r7.add(r8)
            goto L_0x0034
        L_0x00a5:
            r8.mo1880d(r4)
            r8.mo1878b(r2)
            goto L_0x0034
        L_0x00ac:
            r7 = 0
        L_0x00ad:
            r5 = 0
            if (r7 == 0) goto L_0x00ba
            androidx.constraintlayout.motion.widget.j[] r5 = new androidx.constraintlayout.motion.widget.C0356j[r5]
            java.lang.Object[] r5 = r7.toArray(r5)
            androidx.constraintlayout.motion.widget.j[] r5 = (androidx.constraintlayout.motion.widget.C0356j[]) r5
            r0.f1549z = r5
        L_0x00ba:
            boolean r5 = r2.isEmpty()
            java.lang.String r6 = "scaleY"
            java.lang.String r7 = "scaleX"
            java.lang.String r8 = "progress"
            java.lang.String r9 = "translationZ"
            java.lang.String r10 = "translationY"
            java.lang.String r11 = "translationX"
            java.lang.String r12 = "rotationY"
            java.lang.String r13 = "rotationX"
            java.lang.String r14 = "CUSTOM,"
            r16 = 4
            r17 = 3
            if (r5 != 0) goto L_0x02ed
            java.util.HashMap r5 = new java.util.HashMap
            r5.<init>()
            r0.f1547x = r5
            java.util.Iterator r5 = r2.iterator()
        L_0x00e1:
            boolean r18 = r5.hasNext()
            if (r18 == 0) goto L_0x0284
            java.lang.Object r18 = r5.next()
            r15 = r18
            java.lang.String r15 = (java.lang.String) r15
            boolean r18 = r15.startsWith(r14)
            if (r18 == 0) goto L_0x0142
            r29 = r5
            android.util.SparseArray r5 = new android.util.SparseArray
            r5.<init>()
            r18 = r3
            java.lang.String r3 = ","
            java.lang.String[] r3 = r15.split(r3)
            r19 = 1
            r3 = r3[r19]
            r19 = r2
            java.util.ArrayList<androidx.constraintlayout.motion.widget.a> r2 = r0.f1545v
            java.util.Iterator r2 = r2.iterator()
        L_0x0110:
            boolean r20 = r2.hasNext()
            if (r20 == 0) goto L_0x0139
            java.lang.Object r20 = r2.next()
            r21 = r2
            r2 = r20
            androidx.constraintlayout.motion.widget.a r2 = (androidx.constraintlayout.motion.widget.C0327a) r2
            r20 = r14
            java.util.HashMap<java.lang.String, androidx.constraintlayout.widget.a> r14 = r2.f1401d
            if (r14 != 0) goto L_0x0127
            goto L_0x0134
        L_0x0127:
            java.lang.Object r14 = r14.get(r3)
            androidx.constraintlayout.widget.a r14 = (androidx.constraintlayout.widget.C0407a) r14
            if (r14 == 0) goto L_0x0134
            int r2 = r2.f1398a
            r5.append(r2, r14)
        L_0x0134:
            r14 = r20
            r2 = r21
            goto L_0x0110
        L_0x0139:
            r20 = r14
            androidx.constraintlayout.motion.widget.q$b r2 = new androidx.constraintlayout.motion.widget.q$b
            r2.<init>(r15, r5)
            goto L_0x026f
        L_0x0142:
            r19 = r2
            r18 = r3
            r29 = r5
            r20 = r14
            int r2 = r15.hashCode()
            switch(r2) {
                case -1249320806: goto L_0x0200;
                case -1249320805: goto L_0x01f7;
                case -1225497657: goto L_0x01ee;
                case -1225497656: goto L_0x01e5;
                case -1225497655: goto L_0x01dc;
                case -1001078227: goto L_0x01d3;
                case -908189618: goto L_0x01ca;
                case -908189617: goto L_0x01c1;
                case -797520672: goto L_0x01b5;
                case -760884510: goto L_0x01a7;
                case -760884509: goto L_0x0199;
                case -40300674: goto L_0x018b;
                case -4379043: goto L_0x017d;
                case 37232917: goto L_0x016f;
                case 92909918: goto L_0x0161;
                case 156108012: goto L_0x0153;
                default: goto L_0x0151;
            }
        L_0x0151:
            goto L_0x0209
        L_0x0153:
            java.lang.String r2 = "waveOffset"
            boolean r2 = r15.equals(r2)
            if (r2 != 0) goto L_0x015d
            goto L_0x0209
        L_0x015d:
            r2 = 15
            goto L_0x020a
        L_0x0161:
            java.lang.String r2 = "alpha"
            boolean r2 = r15.equals(r2)
            if (r2 != 0) goto L_0x016b
            goto L_0x0209
        L_0x016b:
            r2 = 14
            goto L_0x020a
        L_0x016f:
            java.lang.String r2 = "transitionPathRotate"
            boolean r2 = r15.equals(r2)
            if (r2 != 0) goto L_0x0179
            goto L_0x0209
        L_0x0179:
            r2 = 13
            goto L_0x020a
        L_0x017d:
            java.lang.String r2 = "elevation"
            boolean r2 = r15.equals(r2)
            if (r2 != 0) goto L_0x0187
            goto L_0x0209
        L_0x0187:
            r2 = 12
            goto L_0x020a
        L_0x018b:
            java.lang.String r2 = "rotation"
            boolean r2 = r15.equals(r2)
            if (r2 != 0) goto L_0x0195
            goto L_0x0209
        L_0x0195:
            r2 = 11
            goto L_0x020a
        L_0x0199:
            java.lang.String r2 = "transformPivotY"
            boolean r2 = r15.equals(r2)
            if (r2 != 0) goto L_0x01a3
            goto L_0x0209
        L_0x01a3:
            r2 = 10
            goto L_0x020a
        L_0x01a7:
            java.lang.String r2 = "transformPivotX"
            boolean r2 = r15.equals(r2)
            if (r2 != 0) goto L_0x01b1
            goto L_0x0209
        L_0x01b1:
            r2 = 9
            goto L_0x020a
        L_0x01b5:
            java.lang.String r2 = "waveVariesBy"
            boolean r2 = r15.equals(r2)
            if (r2 != 0) goto L_0x01be
            goto L_0x0209
        L_0x01be:
            r2 = 8
            goto L_0x020a
        L_0x01c1:
            boolean r2 = r15.equals(r6)
            if (r2 != 0) goto L_0x01c8
            goto L_0x0209
        L_0x01c8:
            r2 = 7
            goto L_0x020a
        L_0x01ca:
            boolean r2 = r15.equals(r7)
            if (r2 != 0) goto L_0x01d1
            goto L_0x0209
        L_0x01d1:
            r2 = 6
            goto L_0x020a
        L_0x01d3:
            boolean r2 = r15.equals(r8)
            if (r2 != 0) goto L_0x01da
            goto L_0x0209
        L_0x01da:
            r2 = 5
            goto L_0x020a
        L_0x01dc:
            boolean r2 = r15.equals(r9)
            if (r2 != 0) goto L_0x01e3
            goto L_0x0209
        L_0x01e3:
            r2 = 4
            goto L_0x020a
        L_0x01e5:
            boolean r2 = r15.equals(r10)
            if (r2 != 0) goto L_0x01ec
            goto L_0x0209
        L_0x01ec:
            r2 = 3
            goto L_0x020a
        L_0x01ee:
            boolean r2 = r15.equals(r11)
            if (r2 != 0) goto L_0x01f5
            goto L_0x0209
        L_0x01f5:
            r2 = 2
            goto L_0x020a
        L_0x01f7:
            boolean r2 = r15.equals(r12)
            if (r2 != 0) goto L_0x01fe
            goto L_0x0209
        L_0x01fe:
            r2 = 1
            goto L_0x020a
        L_0x0200:
            boolean r2 = r15.equals(r13)
            if (r2 != 0) goto L_0x0207
            goto L_0x0209
        L_0x0207:
            r2 = 0
            goto L_0x020a
        L_0x0209:
            r2 = -1
        L_0x020a:
            switch(r2) {
                case 0: goto L_0x026a;
                case 1: goto L_0x0264;
                case 2: goto L_0x025e;
                case 3: goto L_0x0258;
                case 4: goto L_0x0252;
                case 5: goto L_0x024c;
                case 6: goto L_0x0246;
                case 7: goto L_0x0240;
                case 8: goto L_0x023a;
                case 9: goto L_0x0234;
                case 10: goto L_0x022e;
                case 11: goto L_0x0228;
                case 12: goto L_0x0222;
                case 13: goto L_0x021c;
                case 14: goto L_0x0216;
                case 15: goto L_0x0210;
                default: goto L_0x020d;
            }
        L_0x020d:
            r2 = 0
            goto L_0x026f
        L_0x0210:
            androidx.constraintlayout.motion.widget.q$a r2 = new androidx.constraintlayout.motion.widget.q$a
            r2.<init>()
            goto L_0x026f
        L_0x0216:
            androidx.constraintlayout.motion.widget.q$a r2 = new androidx.constraintlayout.motion.widget.q$a
            r2.<init>()
            goto L_0x026f
        L_0x021c:
            androidx.constraintlayout.motion.widget.q$d r2 = new androidx.constraintlayout.motion.widget.q$d
            r2.<init>()
            goto L_0x026f
        L_0x0222:
            androidx.constraintlayout.motion.widget.q$c r2 = new androidx.constraintlayout.motion.widget.q$c
            r2.<init>()
            goto L_0x026f
        L_0x0228:
            androidx.constraintlayout.motion.widget.q$h r2 = new androidx.constraintlayout.motion.widget.q$h
            r2.<init>()
            goto L_0x026f
        L_0x022e:
            androidx.constraintlayout.motion.widget.q$f r2 = new androidx.constraintlayout.motion.widget.q$f
            r2.<init>()
            goto L_0x026f
        L_0x0234:
            androidx.constraintlayout.motion.widget.q$e r2 = new androidx.constraintlayout.motion.widget.q$e
            r2.<init>()
            goto L_0x026f
        L_0x023a:
            androidx.constraintlayout.motion.widget.q$a r2 = new androidx.constraintlayout.motion.widget.q$a
            r2.<init>()
            goto L_0x026f
        L_0x0240:
            androidx.constraintlayout.motion.widget.q$l r2 = new androidx.constraintlayout.motion.widget.q$l
            r2.<init>()
            goto L_0x026f
        L_0x0246:
            androidx.constraintlayout.motion.widget.q$k r2 = new androidx.constraintlayout.motion.widget.q$k
            r2.<init>()
            goto L_0x026f
        L_0x024c:
            androidx.constraintlayout.motion.widget.q$g r2 = new androidx.constraintlayout.motion.widget.q$g
            r2.<init>()
            goto L_0x026f
        L_0x0252:
            androidx.constraintlayout.motion.widget.q$o r2 = new androidx.constraintlayout.motion.widget.q$o
            r2.<init>()
            goto L_0x026f
        L_0x0258:
            androidx.constraintlayout.motion.widget.q$n r2 = new androidx.constraintlayout.motion.widget.q$n
            r2.<init>()
            goto L_0x026f
        L_0x025e:
            androidx.constraintlayout.motion.widget.q$m r2 = new androidx.constraintlayout.motion.widget.q$m
            r2.<init>()
            goto L_0x026f
        L_0x0264:
            androidx.constraintlayout.motion.widget.q$j r2 = new androidx.constraintlayout.motion.widget.q$j
            r2.<init>()
            goto L_0x026f
        L_0x026a:
            androidx.constraintlayout.motion.widget.q$i r2 = new androidx.constraintlayout.motion.widget.q$i
            r2.<init>()
        L_0x026f:
            if (r2 != 0) goto L_0x0272
            goto L_0x027a
        L_0x0272:
            r2.mo1957e(r15)
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.q> r3 = r0.f1547x
            r3.put(r15, r2)
        L_0x027a:
            r5 = r29
            r3 = r18
            r2 = r19
            r14 = r20
            goto L_0x00e1
        L_0x0284:
            r19 = r2
            r18 = r3
            r20 = r14
            java.util.ArrayList<androidx.constraintlayout.motion.widget.a> r2 = r0.f1545v
            if (r2 == 0) goto L_0x02a8
            java.util.Iterator r2 = r2.iterator()
        L_0x0292:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x02a8
            java.lang.Object r3 = r2.next()
            androidx.constraintlayout.motion.widget.a r3 = (androidx.constraintlayout.motion.widget.C0327a) r3
            boolean r5 = r3 instanceof androidx.constraintlayout.motion.widget.C0328b
            if (r5 == 0) goto L_0x0292
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.q> r5 = r0.f1547x
            r3.mo1877a(r5)
            goto L_0x0292
        L_0x02a8:
            androidx.constraintlayout.motion.widget.k r2 = r0.f1529f
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.q> r3 = r0.f1547x
            r5 = 0
            r2.mo1894a(r3, r5)
            androidx.constraintlayout.motion.widget.k r2 = r0.f1530g
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.q> r3 = r0.f1547x
            r5 = 100
            r2.mo1894a(r3, r5)
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.q> r2 = r0.f1547x
            java.util.Set r2 = r2.keySet()
            java.util.Iterator r2 = r2.iterator()
        L_0x02c3:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x02f3
            java.lang.Object r3 = r2.next()
            java.lang.String r3 = (java.lang.String) r3
            boolean r5 = r4.containsKey(r3)
            if (r5 == 0) goto L_0x02e0
            java.lang.Object r5 = r4.get(r3)
            java.lang.Integer r5 = (java.lang.Integer) r5
            int r5 = r5.intValue()
            goto L_0x02e1
        L_0x02e0:
            r5 = 0
        L_0x02e1:
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.q> r14 = r0.f1547x
            java.lang.Object r3 = r14.get(r3)
            androidx.constraintlayout.motion.widget.q r3 = (androidx.constraintlayout.motion.widget.C0367q) r3
            r3.mo1958f(r5)
            goto L_0x02c3
        L_0x02ed:
            r19 = r2
            r18 = r3
            r20 = r14
        L_0x02f3:
            boolean r2 = r1.isEmpty()
            if (r2 != 0) goto L_0x04b0
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.r> r2 = r0.f1546w
            if (r2 != 0) goto L_0x0304
            java.util.HashMap r2 = new java.util.HashMap
            r2.<init>()
            r0.f1546w = r2
        L_0x0304:
            java.util.Iterator r1 = r1.iterator()
        L_0x0308:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x045a
            java.lang.Object r2 = r1.next()
            java.lang.String r2 = (java.lang.String) r2
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.r> r3 = r0.f1546w
            boolean r3 = r3.containsKey(r2)
            if (r3 == 0) goto L_0x031d
            goto L_0x0308
        L_0x031d:
            r3 = r20
            boolean r5 = r2.startsWith(r3)
            if (r5 == 0) goto L_0x036d
            android.util.SparseArray r5 = new android.util.SparseArray
            r5.<init>()
            java.lang.String r14 = ","
            java.lang.String[] r14 = r2.split(r14)
            r15 = 1
            r14 = r14[r15]
            java.util.ArrayList<androidx.constraintlayout.motion.widget.a> r15 = r0.f1545v
            java.util.Iterator r15 = r15.iterator()
        L_0x0339:
            boolean r20 = r15.hasNext()
            if (r20 == 0) goto L_0x0362
            java.lang.Object r20 = r15.next()
            r29 = r1
            r1 = r20
            androidx.constraintlayout.motion.widget.a r1 = (androidx.constraintlayout.motion.widget.C0327a) r1
            r20 = r15
            java.util.HashMap<java.lang.String, androidx.constraintlayout.widget.a> r15 = r1.f1401d
            if (r15 != 0) goto L_0x0350
            goto L_0x035d
        L_0x0350:
            java.lang.Object r15 = r15.get(r14)
            androidx.constraintlayout.widget.a r15 = (androidx.constraintlayout.widget.C0407a) r15
            if (r15 == 0) goto L_0x035d
            int r1 = r1.f1398a
            r5.append(r1, r15)
        L_0x035d:
            r1 = r29
            r15 = r20
            goto L_0x0339
        L_0x0362:
            r29 = r1
            androidx.constraintlayout.motion.widget.r$b r1 = new androidx.constraintlayout.motion.widget.r$b
            r1.<init>(r2, r5)
            r14 = r30
            goto L_0x0449
        L_0x036d:
            r29 = r1
            int r1 = r2.hashCode()
            switch(r1) {
                case -1249320806: goto L_0x03ed;
                case -1249320805: goto L_0x03e4;
                case -1225497657: goto L_0x03db;
                case -1225497656: goto L_0x03d2;
                case -1225497655: goto L_0x03c9;
                case -1001078227: goto L_0x03c0;
                case -908189618: goto L_0x03b7;
                case -908189617: goto L_0x03ae;
                case -40300674: goto L_0x03a2;
                case -4379043: goto L_0x0394;
                case 37232917: goto L_0x0386;
                case 92909918: goto L_0x0378;
                default: goto L_0x0376;
            }
        L_0x0376:
            goto L_0x03f6
        L_0x0378:
            java.lang.String r1 = "alpha"
            boolean r1 = r2.equals(r1)
            if (r1 != 0) goto L_0x0382
            goto L_0x03f6
        L_0x0382:
            r1 = 11
            goto L_0x03f7
        L_0x0386:
            java.lang.String r1 = "transitionPathRotate"
            boolean r1 = r2.equals(r1)
            if (r1 != 0) goto L_0x0390
            goto L_0x03f6
        L_0x0390:
            r1 = 10
            goto L_0x03f7
        L_0x0394:
            java.lang.String r1 = "elevation"
            boolean r1 = r2.equals(r1)
            if (r1 != 0) goto L_0x039e
            goto L_0x03f6
        L_0x039e:
            r1 = 9
            goto L_0x03f7
        L_0x03a2:
            java.lang.String r1 = "rotation"
            boolean r1 = r2.equals(r1)
            if (r1 != 0) goto L_0x03ab
            goto L_0x03f6
        L_0x03ab:
            r1 = 8
            goto L_0x03f7
        L_0x03ae:
            boolean r1 = r2.equals(r6)
            if (r1 != 0) goto L_0x03b5
            goto L_0x03f6
        L_0x03b5:
            r1 = 7
            goto L_0x03f7
        L_0x03b7:
            boolean r1 = r2.equals(r7)
            if (r1 != 0) goto L_0x03be
            goto L_0x03f6
        L_0x03be:
            r1 = 6
            goto L_0x03f7
        L_0x03c0:
            boolean r1 = r2.equals(r8)
            if (r1 != 0) goto L_0x03c7
            goto L_0x03f6
        L_0x03c7:
            r1 = 5
            goto L_0x03f7
        L_0x03c9:
            boolean r1 = r2.equals(r9)
            if (r1 != 0) goto L_0x03d0
            goto L_0x03f6
        L_0x03d0:
            r1 = 4
            goto L_0x03f7
        L_0x03d2:
            boolean r1 = r2.equals(r10)
            if (r1 != 0) goto L_0x03d9
            goto L_0x03f6
        L_0x03d9:
            r1 = 3
            goto L_0x03f7
        L_0x03db:
            boolean r1 = r2.equals(r11)
            if (r1 != 0) goto L_0x03e2
            goto L_0x03f6
        L_0x03e2:
            r1 = 2
            goto L_0x03f7
        L_0x03e4:
            boolean r1 = r2.equals(r12)
            if (r1 != 0) goto L_0x03eb
            goto L_0x03f6
        L_0x03eb:
            r1 = 1
            goto L_0x03f7
        L_0x03ed:
            boolean r1 = r2.equals(r13)
            if (r1 != 0) goto L_0x03f4
            goto L_0x03f6
        L_0x03f4:
            r1 = 0
            goto L_0x03f7
        L_0x03f6:
            r1 = -1
        L_0x03f7:
            switch(r1) {
                case 0: goto L_0x0440;
                case 1: goto L_0x043a;
                case 2: goto L_0x0434;
                case 3: goto L_0x042e;
                case 4: goto L_0x0428;
                case 5: goto L_0x0422;
                case 6: goto L_0x041c;
                case 7: goto L_0x0416;
                case 8: goto L_0x0410;
                case 9: goto L_0x040a;
                case 10: goto L_0x0404;
                case 11: goto L_0x03fe;
                default: goto L_0x03fa;
            }
        L_0x03fa:
            r14 = r30
            r1 = 0
            goto L_0x0449
        L_0x03fe:
            androidx.constraintlayout.motion.widget.r$a r1 = new androidx.constraintlayout.motion.widget.r$a
            r1.<init>()
            goto L_0x0445
        L_0x0404:
            androidx.constraintlayout.motion.widget.r$d r1 = new androidx.constraintlayout.motion.widget.r$d
            r1.<init>()
            goto L_0x0445
        L_0x040a:
            androidx.constraintlayout.motion.widget.r$c r1 = new androidx.constraintlayout.motion.widget.r$c
            r1.<init>()
            goto L_0x0445
        L_0x0410:
            androidx.constraintlayout.motion.widget.r$f r1 = new androidx.constraintlayout.motion.widget.r$f
            r1.<init>()
            goto L_0x0445
        L_0x0416:
            androidx.constraintlayout.motion.widget.r$j r1 = new androidx.constraintlayout.motion.widget.r$j
            r1.<init>()
            goto L_0x0445
        L_0x041c:
            androidx.constraintlayout.motion.widget.r$i r1 = new androidx.constraintlayout.motion.widget.r$i
            r1.<init>()
            goto L_0x0445
        L_0x0422:
            androidx.constraintlayout.motion.widget.r$e r1 = new androidx.constraintlayout.motion.widget.r$e
            r1.<init>()
            goto L_0x0445
        L_0x0428:
            androidx.constraintlayout.motion.widget.r$m r1 = new androidx.constraintlayout.motion.widget.r$m
            r1.<init>()
            goto L_0x0445
        L_0x042e:
            androidx.constraintlayout.motion.widget.r$l r1 = new androidx.constraintlayout.motion.widget.r$l
            r1.<init>()
            goto L_0x0445
        L_0x0434:
            androidx.constraintlayout.motion.widget.r$k r1 = new androidx.constraintlayout.motion.widget.r$k
            r1.<init>()
            goto L_0x0445
        L_0x043a:
            androidx.constraintlayout.motion.widget.r$h r1 = new androidx.constraintlayout.motion.widget.r$h
            r1.<init>()
            goto L_0x0445
        L_0x0440:
            androidx.constraintlayout.motion.widget.r$g r1 = new androidx.constraintlayout.motion.widget.r$g
            r1.<init>()
        L_0x0445:
            r14 = r30
            r1.f1670i = r14
        L_0x0449:
            if (r1 != 0) goto L_0x044c
            goto L_0x0454
        L_0x044c:
            r1.mo1964e(r2)
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.r> r5 = r0.f1546w
            r5.put(r2, r1)
        L_0x0454:
            r1 = r29
            r20 = r3
            goto L_0x0308
        L_0x045a:
            r3 = r20
            java.util.ArrayList<androidx.constraintlayout.motion.widget.a> r1 = r0.f1545v
            if (r1 == 0) goto L_0x047c
            java.util.Iterator r1 = r1.iterator()
        L_0x0464:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x047c
            java.lang.Object r2 = r1.next()
            androidx.constraintlayout.motion.widget.a r2 = (androidx.constraintlayout.motion.widget.C0327a) r2
            boolean r5 = r2 instanceof androidx.constraintlayout.motion.widget.C0354i
            if (r5 == 0) goto L_0x0464
            androidx.constraintlayout.motion.widget.i r2 = (androidx.constraintlayout.motion.widget.C0354i) r2
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.r> r5 = r0.f1546w
            r2.mo1892K(r5)
            goto L_0x0464
        L_0x047c:
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.r> r1 = r0.f1546w
            java.util.Set r1 = r1.keySet()
            java.util.Iterator r1 = r1.iterator()
        L_0x0486:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x04b2
            java.lang.Object r2 = r1.next()
            java.lang.String r2 = (java.lang.String) r2
            boolean r5 = r4.containsKey(r2)
            if (r5 == 0) goto L_0x04a3
            java.lang.Object r5 = r4.get(r2)
            java.lang.Integer r5 = (java.lang.Integer) r5
            int r5 = r5.intValue()
            goto L_0x04a4
        L_0x04a3:
            r5 = 0
        L_0x04a4:
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.r> r14 = r0.f1546w
            java.lang.Object r2 = r14.get(r2)
            androidx.constraintlayout.motion.widget.r r2 = (androidx.constraintlayout.motion.widget.C0383r) r2
            r2.mo1965f(r5)
            goto L_0x0486
        L_0x04b0:
            r3 = r20
        L_0x04b2:
            java.util.ArrayList<androidx.constraintlayout.motion.widget.o> r1 = r0.f1543t
            int r1 = r1.size()
            int r1 = r1 + 2
            androidx.constraintlayout.motion.widget.o[] r2 = new androidx.constraintlayout.motion.widget.C0362o[r1]
            androidx.constraintlayout.motion.widget.o r4 = r0.f1527d
            r5 = 0
            r2[r5] = r4
            int r4 = r1 + -1
            androidx.constraintlayout.motion.widget.o r14 = r0.f1528e
            r2[r4] = r14
            java.util.ArrayList<androidx.constraintlayout.motion.widget.o> r4 = r0.f1543t
            int r4 = r4.size()
            if (r4 <= 0) goto L_0x04d6
            int r4 = r0.f1526c
            r14 = -1
            if (r4 != r14) goto L_0x04d6
            r0.f1526c = r5
        L_0x04d6:
            java.util.ArrayList<androidx.constraintlayout.motion.widget.o> r4 = r0.f1543t
            java.util.Iterator r4 = r4.iterator()
            r5 = 1
        L_0x04dd:
            boolean r14 = r4.hasNext()
            if (r14 == 0) goto L_0x04ef
            java.lang.Object r14 = r4.next()
            androidx.constraintlayout.motion.widget.o r14 = (androidx.constraintlayout.motion.widget.C0362o) r14
            int r15 = r5 + 1
            r2[r5] = r14
            r5 = r15
            goto L_0x04dd
        L_0x04ef:
            java.util.HashSet r4 = new java.util.HashSet
            r4.<init>()
            androidx.constraintlayout.motion.widget.o r5 = r0.f1528e
            java.util.LinkedHashMap<java.lang.String, androidx.constraintlayout.widget.a> r5 = r5.f1611l
            java.util.Set r5 = r5.keySet()
            java.util.Iterator r5 = r5.iterator()
        L_0x0500:
            boolean r14 = r5.hasNext()
            if (r14 == 0) goto L_0x053c
            java.lang.Object r14 = r5.next()
            java.lang.String r14 = (java.lang.String) r14
            androidx.constraintlayout.motion.widget.o r15 = r0.f1527d
            java.util.LinkedHashMap<java.lang.String, androidx.constraintlayout.widget.a> r15 = r15.f1611l
            boolean r15 = r15.containsKey(r14)
            if (r15 == 0) goto L_0x0533
            java.lang.StringBuilder r15 = new java.lang.StringBuilder
            r15.<init>()
            r15.append(r3)
            r15.append(r14)
            java.lang.String r15 = r15.toString()
            r20 = r3
            r3 = r19
            boolean r15 = r3.contains(r15)
            if (r15 != 0) goto L_0x0537
            r4.add(r14)
            goto L_0x0537
        L_0x0533:
            r20 = r3
            r3 = r19
        L_0x0537:
            r19 = r3
            r3 = r20
            goto L_0x0500
        L_0x053c:
            r3 = 0
            java.lang.String[] r3 = new java.lang.String[r3]
            java.lang.Object[] r3 = r4.toArray(r3)
            java.lang.String[] r3 = (java.lang.String[]) r3
            r0.f1539p = r3
            int r3 = r3.length
            int[] r3 = new int[r3]
            r0.f1540q = r3
            r3 = 0
        L_0x054d:
            java.lang.String[] r4 = r0.f1539p
            int r5 = r4.length
            if (r3 >= r5) goto L_0x0582
            r4 = r4[r3]
            int[] r5 = r0.f1540q
            r14 = 0
            r5[r3] = r14
            r5 = 0
        L_0x055a:
            if (r5 >= r1) goto L_0x057f
            r14 = r2[r5]
            java.util.LinkedHashMap<java.lang.String, androidx.constraintlayout.widget.a> r14 = r14.f1611l
            boolean r14 = r14.containsKey(r4)
            if (r14 == 0) goto L_0x057c
            int[] r14 = r0.f1540q
            r15 = r14[r3]
            r5 = r2[r5]
            java.util.LinkedHashMap<java.lang.String, androidx.constraintlayout.widget.a> r5 = r5.f1611l
            java.lang.Object r4 = r5.get(r4)
            androidx.constraintlayout.widget.a r4 = (androidx.constraintlayout.widget.C0407a) r4
            int r4 = r4.mo2057e()
            int r4 = r4 + r15
            r14[r3] = r4
            goto L_0x057f
        L_0x057c:
            int r5 = r5 + 1
            goto L_0x055a
        L_0x057f:
            int r3 = r3 + 1
            goto L_0x054d
        L_0x0582:
            r3 = 0
            r3 = r2[r3]
            int r3 = r3.f1610k
            r5 = -1
            if (r3 == r5) goto L_0x058c
            r3 = 1
            goto L_0x058d
        L_0x058c:
            r3 = 0
        L_0x058d:
            int r4 = r4.length
            int r4 = r4 + 18
            boolean[] r5 = new boolean[r4]
            r14 = 1
        L_0x0593:
            if (r14 >= r1) goto L_0x05a5
            r15 = r2[r14]
            int r19 = r14 + -1
            r29 = r13
            r13 = r2[r19]
            r15.mo1919f(r13, r5, r3)
            int r14 = r14 + 1
            r13 = r29
            goto L_0x0593
        L_0x05a5:
            r29 = r13
            r3 = 0
            r13 = 1
        L_0x05a9:
            if (r13 >= r4) goto L_0x05b4
            boolean r14 = r5[r13]
            if (r14 == 0) goto L_0x05b1
            int r3 = r3 + 1
        L_0x05b1:
            int r13 = r13 + 1
            goto L_0x05a9
        L_0x05b4:
            int[] r3 = new int[r3]
            r0.f1536m = r3
            int r13 = r3.length
            double[] r13 = new double[r13]
            r0.f1537n = r13
            int r3 = r3.length
            double[] r3 = new double[r3]
            r0.f1538o = r3
            r3 = 0
            r13 = 1
        L_0x05c4:
            if (r13 >= r4) goto L_0x05d4
            boolean r14 = r5[r13]
            if (r14 == 0) goto L_0x05d1
            int[] r14 = r0.f1536m
            int r15 = r3 + 1
            r14[r3] = r13
            r3 = r15
        L_0x05d1:
            int r13 = r13 + 1
            goto L_0x05c4
        L_0x05d4:
            int[] r3 = r0.f1536m
            int r3 = r3.length
            r4 = 2
            int[] r4 = new int[r4]
            r5 = 1
            r4[r5] = r3
            r3 = 0
            r4[r3] = r1
            java.lang.Class<double> r3 = double.class
            java.lang.Object r3 = java.lang.reflect.Array.newInstance(r3, r4)
            double[][] r3 = (double[][]) r3
            double[] r4 = new double[r1]
            r5 = 0
        L_0x05eb:
            if (r5 >= r1) goto L_0x064f
            r13 = r2[r5]
            r14 = r3[r5]
            int[] r15 = r0.f1536m
            r19 = r12
            r12 = 6
            float[] r12 = new float[r12]
            r20 = r11
            float r11 = r13.f1604e
            r21 = 0
            r12[r21] = r11
            float r11 = r13.f1605f
            r21 = 1
            r12[r21] = r11
            float r11 = r13.f1606g
            r21 = 2
            r12[r21] = r11
            float r11 = r13.f1607h
            r12[r17] = r11
            float r11 = r13.f1608i
            r12[r16] = r11
            float r11 = r13.f1609j
            r13 = 5
            r12[r13] = r11
            r11 = 0
            r21 = 0
        L_0x061c:
            int r13 = r15.length
            if (r11 >= r13) goto L_0x063d
            r13 = r15[r11]
            r22 = r10
            r10 = 6
            if (r13 >= r10) goto L_0x0634
            int r10 = r21 + 1
            r13 = r15[r11]
            r13 = r12[r13]
            r30 = r12
            double r12 = (double) r13
            r14[r21] = r12
            r21 = r10
            goto L_0x0636
        L_0x0634:
            r30 = r12
        L_0x0636:
            int r11 = r11 + 1
            r12 = r30
            r10 = r22
            goto L_0x061c
        L_0x063d:
            r22 = r10
            r10 = r2[r5]
            float r10 = r10.f1603d
            double r10 = (double) r10
            r4[r5] = r10
            int r5 = r5 + 1
            r12 = r19
            r11 = r20
            r10 = r22
            goto L_0x05eb
        L_0x064f:
            r22 = r10
            r20 = r11
            r19 = r12
            r5 = 0
        L_0x0656:
            int[] r10 = r0.f1536m
            int r11 = r10.length
            if (r5 >= r11) goto L_0x068d
            r10 = r10[r5]
            java.lang.String[] r11 = androidx.constraintlayout.motion.widget.C0362o.f1600a
            int r11 = r11.length
            if (r10 >= r11) goto L_0x068a
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>()
            java.lang.String[] r11 = androidx.constraintlayout.motion.widget.C0362o.f1600a
            int[] r12 = r0.f1536m
            r12 = r12[r5]
            r11 = r11[r12]
            java.lang.String r12 = " ["
            java.lang.String r10 = p165e.p166a.p167a.p168a.C4924a.m17852E(r10, r11, r12)
            r11 = 0
        L_0x0676:
            if (r11 >= r1) goto L_0x068a
            java.lang.StringBuilder r10 = p165e.p166a.p167a.p168a.C4924a.m17863P(r10)
            r12 = r3[r11]
            r13 = r12[r5]
            r10.append(r13)
            java.lang.String r10 = r10.toString()
            int r11 = r11 + 1
            goto L_0x0676
        L_0x068a:
            int r5 = r5 + 1
            goto L_0x0656
        L_0x068d:
            java.lang.String[] r5 = r0.f1539p
            int r5 = r5.length
            int r5 = r5 + 1
            d.e.a.a.b[] r5 = new p098d.p113e.p114a.p115a.C4635b[r5]
            r0.f1531h = r5
            r5 = 0
        L_0x0697:
            java.lang.String[] r10 = r0.f1539p
            int r11 = r10.length
            if (r5 >= r11) goto L_0x075f
            r10 = r10[r5]
            r11 = 0
            r12 = 0
            r13 = 0
            r14 = 0
        L_0x06a2:
            if (r11 >= r1) goto L_0x073f
            r15 = r2[r11]
            java.util.LinkedHashMap<java.lang.String, androidx.constraintlayout.widget.a> r15 = r15.f1611l
            boolean r15 = r15.containsKey(r10)
            if (r15 == 0) goto L_0x072f
            if (r14 != 0) goto L_0x06d2
            double[] r13 = new double[r1]
            r14 = r2[r11]
            java.util.LinkedHashMap<java.lang.String, androidx.constraintlayout.widget.a> r14 = r14.f1611l
            java.lang.Object r14 = r14.get(r10)
            androidx.constraintlayout.widget.a r14 = (androidx.constraintlayout.widget.C0407a) r14
            int r14 = r14.mo2057e()
            r15 = 2
            int[] r15 = new int[r15]
            r16 = 1
            r15[r16] = r14
            r14 = 0
            r15[r14] = r1
            java.lang.Class<double> r14 = double.class
            java.lang.Object r14 = java.lang.reflect.Array.newInstance(r14, r15)
            double[][] r14 = (double[][]) r14
        L_0x06d2:
            r15 = r2[r11]
            float r15 = r15.f1603d
            r28 = r8
            r16 = r9
            double r8 = (double) r15
            r13[r12] = r8
            r8 = r2[r11]
            r9 = r14[r12]
            java.util.LinkedHashMap<java.lang.String, androidx.constraintlayout.widget.a> r8 = r8.f1611l
            java.lang.Object r8 = r8.get(r10)
            androidx.constraintlayout.widget.a r8 = (androidx.constraintlayout.widget.C0407a) r8
            int r15 = r8.mo2057e()
            r30 = r10
            r10 = 1
            if (r15 != r10) goto L_0x0700
            float r8 = r8.mo2055c()
            r31 = r13
            r10 = r14
            double r13 = (double) r8
            r8 = 0
            r9[r8] = r13
        L_0x06fd:
            r21 = r10
            goto L_0x0728
        L_0x0700:
            r31 = r13
            r10 = r14
            int r13 = r8.mo2057e()
            float[] r14 = new float[r13]
            r8.mo2056d(r14)
            r8 = 0
            r15 = 0
        L_0x070e:
            if (r8 >= r13) goto L_0x06fd
            int r17 = r15 + 1
            r21 = r10
            r10 = r14[r8]
            r23 = r13
            r24 = r14
            double r13 = (double) r10
            r9[r15] = r13
            int r8 = r8 + 1
            r15 = r17
            r10 = r21
            r13 = r23
            r14 = r24
            goto L_0x070e
        L_0x0728:
            int r12 = r12 + 1
            r13 = r31
            r14 = r21
            goto L_0x0735
        L_0x072f:
            r28 = r8
            r16 = r9
            r30 = r10
        L_0x0735:
            int r11 = r11 + 1
            r8 = r28
            r10 = r30
            r9 = r16
            goto L_0x06a2
        L_0x073f:
            r28 = r8
            r16 = r9
            double[] r8 = java.util.Arrays.copyOf(r13, r12)
            java.lang.Object[] r9 = java.util.Arrays.copyOf(r14, r12)
            double[][] r9 = (double[][]) r9
            d.e.a.a.b[] r10 = r0.f1531h
            int r5 = r5 + 1
            int r11 = r0.f1526c
            d.e.a.a.b r8 = p098d.p113e.p114a.p115a.C4635b.m16690a(r11, r8, r9)
            r10[r5] = r8
            r8 = r28
            r9 = r16
            goto L_0x0697
        L_0x075f:
            r28 = r8
            r16 = r9
            d.e.a.a.b[] r5 = r0.f1531h
            int r8 = r0.f1526c
            d.e.a.a.b r3 = p098d.p113e.p114a.p115a.C4635b.m16690a(r8, r4, r3)
            r4 = 0
            r5[r4] = r3
            r3 = r2[r4]
            int r3 = r3.f1610k
            r5 = -1
            if (r3 == r5) goto L_0x07b6
            int[] r3 = new int[r1]
            double[] r5 = new double[r1]
            r8 = 2
            int[] r9 = new int[r8]
            r10 = 1
            r9[r10] = r8
            r9[r4] = r1
            java.lang.Class<double> r4 = double.class
            java.lang.Object r4 = java.lang.reflect.Array.newInstance(r4, r9)
            double[][] r4 = (double[][]) r4
            r8 = 0
        L_0x078a:
            if (r8 >= r1) goto L_0x07b0
            r9 = r2[r8]
            int r9 = r9.f1610k
            r3[r8] = r9
            r9 = r2[r8]
            float r9 = r9.f1603d
            double r9 = (double) r9
            r5[r8] = r9
            r9 = r4[r8]
            r10 = r2[r8]
            float r10 = r10.f1605f
            double r10 = (double) r10
            r12 = 0
            r9[r12] = r10
            r9 = r4[r8]
            r10 = r2[r8]
            float r10 = r10.f1606g
            double r10 = (double) r10
            r12 = 1
            r9[r12] = r10
            int r8 = r8 + 1
            goto L_0x078a
        L_0x07b0:
            d.e.a.a.b r1 = p098d.p113e.p114a.p115a.C4635b.m16691b(r3, r5, r4)
            r0.f1532i = r1
        L_0x07b6:
            r1 = 2143289344(0x7fc00000, float:NaN)
            java.util.HashMap r2 = new java.util.HashMap
            r2.<init>()
            r0.f1548y = r2
            java.util.ArrayList<androidx.constraintlayout.motion.widget.a> r2 = r0.f1545v
            if (r2 == 0) goto L_0x0b1e
            java.util.Iterator r2 = r18.iterator()
        L_0x07c7:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x0ae6
            java.lang.Object r3 = r2.next()
            java.lang.String r3 = (java.lang.String) r3
            java.lang.String r4 = "CUSTOM"
            boolean r4 = r3.startsWith(r4)
            if (r4 == 0) goto L_0x07ef
            androidx.constraintlayout.motion.widget.e$c r4 = new androidx.constraintlayout.motion.widget.e$c
            r4.<init>()
            r11 = r29
            r12 = r4
            r5 = r16
            r10 = r19
            r9 = r20
            r8 = r22
            r4 = r28
            goto L_0x09c2
        L_0x07ef:
            int r4 = r3.hashCode()
            switch(r4) {
                case -1249320806: goto L_0x0954;
                case -1249320805: goto L_0x093c;
                case -1225497657: goto L_0x0924;
                case -1225497656: goto L_0x0908;
                case -1225497655: goto L_0x08e8;
                case -1001078227: goto L_0x08cd;
                case -908189618: goto L_0x08b5;
                case -908189617: goto L_0x089d;
                case -797520672: goto L_0x0881;
                case -40300674: goto L_0x0866;
                case -4379043: goto L_0x084b;
                case 37232917: goto L_0x0830;
                case 92909918: goto L_0x0815;
                case 156108012: goto L_0x07fa;
                default: goto L_0x07f6;
            }
        L_0x07f6:
            r4 = r28
            goto L_0x08d5
        L_0x07fa:
            java.lang.String r4 = "waveOffset"
            boolean r4 = r3.equals(r4)
            if (r4 != 0) goto L_0x0803
            goto L_0x07f6
        L_0x0803:
            r4 = 13
            r4 = r28
            r11 = r29
            r5 = r16
            r10 = r19
            r9 = r20
            r8 = r22
            r12 = 13
            goto L_0x096a
        L_0x0815:
            java.lang.String r4 = "alpha"
            boolean r4 = r3.equals(r4)
            if (r4 != 0) goto L_0x081e
            goto L_0x07f6
        L_0x081e:
            r4 = 12
            r4 = r28
            r11 = r29
            r5 = r16
            r10 = r19
            r9 = r20
            r8 = r22
            r12 = 12
            goto L_0x096a
        L_0x0830:
            java.lang.String r4 = "transitionPathRotate"
            boolean r4 = r3.equals(r4)
            if (r4 != 0) goto L_0x0839
            goto L_0x07f6
        L_0x0839:
            r4 = 11
            r4 = r28
            r11 = r29
            r5 = r16
            r10 = r19
            r9 = r20
            r8 = r22
            r12 = 11
            goto L_0x096a
        L_0x084b:
            java.lang.String r4 = "elevation"
            boolean r4 = r3.equals(r4)
            if (r4 != 0) goto L_0x0854
            goto L_0x07f6
        L_0x0854:
            r4 = 10
            r4 = r28
            r11 = r29
            r5 = r16
            r10 = r19
            r9 = r20
            r8 = r22
            r12 = 10
            goto L_0x096a
        L_0x0866:
            java.lang.String r4 = "rotation"
            boolean r4 = r3.equals(r4)
            if (r4 != 0) goto L_0x086f
            goto L_0x07f6
        L_0x086f:
            r4 = 9
            r4 = r28
            r11 = r29
            r5 = r16
            r10 = r19
            r9 = r20
            r8 = r22
            r12 = 9
            goto L_0x096a
        L_0x0881:
            java.lang.String r4 = "waveVariesBy"
            boolean r4 = r3.equals(r4)
            if (r4 != 0) goto L_0x088b
            goto L_0x07f6
        L_0x088b:
            r4 = 8
            r4 = r28
            r11 = r29
            r5 = r16
            r10 = r19
            r9 = r20
            r8 = r22
            r12 = 8
            goto L_0x096a
        L_0x089d:
            boolean r4 = r3.equals(r6)
            if (r4 != 0) goto L_0x08a5
            goto L_0x07f6
        L_0x08a5:
            r4 = 7
            r4 = r28
            r11 = r29
            r5 = r16
            r10 = r19
            r9 = r20
            r8 = r22
            r12 = 7
            goto L_0x096a
        L_0x08b5:
            boolean r4 = r3.equals(r7)
            if (r4 != 0) goto L_0x08bd
            goto L_0x07f6
        L_0x08bd:
            r4 = 6
            r4 = r28
            r11 = r29
            r5 = r16
            r10 = r19
            r9 = r20
            r8 = r22
            r12 = 6
            goto L_0x096a
        L_0x08cd:
            r4 = r28
            boolean r5 = r3.equals(r4)
            if (r5 != 0) goto L_0x08da
        L_0x08d5:
            r11 = r29
            r5 = r16
            goto L_0x08f4
        L_0x08da:
            r5 = 5
            r11 = r29
            r5 = r16
            r10 = r19
            r9 = r20
            r8 = r22
            r12 = 5
            goto L_0x096a
        L_0x08e8:
            r4 = r28
            r5 = r16
            boolean r8 = r3.equals(r5)
            if (r8 != 0) goto L_0x08fc
            r11 = r29
        L_0x08f4:
            r10 = r19
            r9 = r20
            r8 = r22
            goto L_0x0969
        L_0x08fc:
            r8 = 4
            r11 = r29
            r10 = r19
            r9 = r20
            r8 = r22
            r12 = 4
            goto L_0x096a
        L_0x0908:
            r4 = r28
            r5 = r16
            r8 = r22
            boolean r9 = r3.equals(r8)
            if (r9 != 0) goto L_0x091b
            r11 = r29
            r10 = r19
            r9 = r20
            goto L_0x0969
        L_0x091b:
            r9 = 3
            r11 = r29
            r10 = r19
            r9 = r20
            r12 = 3
            goto L_0x096a
        L_0x0924:
            r4 = r28
            r5 = r16
            r9 = r20
            r8 = r22
            boolean r10 = r3.equals(r9)
            if (r10 != 0) goto L_0x0935
            r10 = r19
            goto L_0x094c
        L_0x0935:
            r10 = 2
            r11 = r29
            r10 = r19
            r12 = 2
            goto L_0x096a
        L_0x093c:
            r4 = r28
            r5 = r16
            r10 = r19
            r9 = r20
            r8 = r22
            boolean r11 = r3.equals(r10)
            if (r11 != 0) goto L_0x094f
        L_0x094c:
            r11 = r29
            goto L_0x0969
        L_0x094f:
            r11 = 1
            r11 = r29
            r12 = 1
            goto L_0x096a
        L_0x0954:
            r4 = r28
            r11 = r29
            r5 = r16
            r10 = r19
            r9 = r20
            r8 = r22
            boolean r12 = r3.equals(r11)
            if (r12 != 0) goto L_0x0967
            goto L_0x0969
        L_0x0967:
            r12 = 0
            goto L_0x096a
        L_0x0969:
            r12 = -1
        L_0x096a:
            switch(r12) {
                case 0: goto L_0x09bd;
                case 1: goto L_0x09b7;
                case 2: goto L_0x09b1;
                case 3: goto L_0x09ab;
                case 4: goto L_0x09a5;
                case 5: goto L_0x099f;
                case 6: goto L_0x0999;
                case 7: goto L_0x0993;
                case 8: goto L_0x098d;
                case 9: goto L_0x0987;
                case 10: goto L_0x0981;
                case 11: goto L_0x097b;
                case 12: goto L_0x0975;
                case 13: goto L_0x096f;
                default: goto L_0x096d;
            }
        L_0x096d:
            r12 = 0
            goto L_0x09c2
        L_0x096f:
            androidx.constraintlayout.motion.widget.e$b r12 = new androidx.constraintlayout.motion.widget.e$b
            r12.<init>()
            goto L_0x09c2
        L_0x0975:
            androidx.constraintlayout.motion.widget.e$b r12 = new androidx.constraintlayout.motion.widget.e$b
            r12.<init>()
            goto L_0x09c2
        L_0x097b:
            androidx.constraintlayout.motion.widget.e$f r12 = new androidx.constraintlayout.motion.widget.e$f
            r12.<init>()
            goto L_0x09c2
        L_0x0981:
            androidx.constraintlayout.motion.widget.e$e r12 = new androidx.constraintlayout.motion.widget.e$e
            r12.<init>()
            goto L_0x09c2
        L_0x0987:
            androidx.constraintlayout.motion.widget.e$h r12 = new androidx.constraintlayout.motion.widget.e$h
            r12.<init>()
            goto L_0x09c2
        L_0x098d:
            androidx.constraintlayout.motion.widget.e$b r12 = new androidx.constraintlayout.motion.widget.e$b
            r12.<init>()
            goto L_0x09c2
        L_0x0993:
            androidx.constraintlayout.motion.widget.e$l r12 = new androidx.constraintlayout.motion.widget.e$l
            r12.<init>()
            goto L_0x09c2
        L_0x0999:
            androidx.constraintlayout.motion.widget.e$k r12 = new androidx.constraintlayout.motion.widget.e$k
            r12.<init>()
            goto L_0x09c2
        L_0x099f:
            androidx.constraintlayout.motion.widget.e$g r12 = new androidx.constraintlayout.motion.widget.e$g
            r12.<init>()
            goto L_0x09c2
        L_0x09a5:
            androidx.constraintlayout.motion.widget.e$o r12 = new androidx.constraintlayout.motion.widget.e$o
            r12.<init>()
            goto L_0x09c2
        L_0x09ab:
            androidx.constraintlayout.motion.widget.e$n r12 = new androidx.constraintlayout.motion.widget.e$n
            r12.<init>()
            goto L_0x09c2
        L_0x09b1:
            androidx.constraintlayout.motion.widget.e$m r12 = new androidx.constraintlayout.motion.widget.e$m
            r12.<init>()
            goto L_0x09c2
        L_0x09b7:
            androidx.constraintlayout.motion.widget.e$j r12 = new androidx.constraintlayout.motion.widget.e$j
            r12.<init>()
            goto L_0x09c2
        L_0x09bd:
            androidx.constraintlayout.motion.widget.e$i r12 = new androidx.constraintlayout.motion.widget.e$i
            r12.<init>()
        L_0x09c2:
            if (r12 != 0) goto L_0x09d2
            r28 = r4
            r16 = r5
            r22 = r8
            r20 = r9
            r19 = r10
            r29 = r11
            goto L_0x07c7
        L_0x09d2:
            int r13 = r12.f1441e
            r14 = 1
            if (r13 != r14) goto L_0x09d9
            r13 = 1
            goto L_0x09da
        L_0x09d9:
            r13 = 0
        L_0x09da:
            if (r13 == 0) goto L_0x0abe
            boolean r13 = java.lang.Float.isNaN(r1)
            if (r13 == 0) goto L_0x0abe
            r1 = 2
            float[] r1 = new float[r1]
            r13 = 99
            float r13 = (float) r13
            r14 = 1065353216(0x3f800000, float:1.0)
            float r14 = r14 / r13
            r15 = 0
            r13 = 0
            r17 = 0
            r28 = r2
            r19 = r4
            r17 = r15
            r2 = 0
        L_0x09f7:
            r4 = 100
            if (r2 >= r4) goto L_0x0ab2
            float r4 = (float) r2
            float r4 = r4 * r14
            r20 = r5
            r29 = r6
            double r5 = (double) r4
            r21 = r5
            androidx.constraintlayout.motion.widget.o r5 = r0.f1527d
            d.e.a.a.c r5 = r5.f1601b
            java.util.ArrayList<androidx.constraintlayout.motion.widget.o> r6 = r0.f1543t
            java.util.Iterator r6 = r6.iterator()
            r23 = 0
            r23 = 2143289344(0x7fc00000, float:NaN)
            r24 = 0
        L_0x0a15:
            boolean r25 = r6.hasNext()
            if (r25 == 0) goto L_0x0a47
            java.lang.Object r25 = r6.next()
            r30 = r6
            r6 = r25
            androidx.constraintlayout.motion.widget.o r6 = (androidx.constraintlayout.motion.widget.C0362o) r6
            r25 = r7
            d.e.a.a.c r7 = r6.f1601b
            if (r7 == 0) goto L_0x0a42
            r31 = r7
            float r7 = r6.f1603d
            int r26 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r26 >= 0) goto L_0x0a38
            r5 = r31
            r24 = r7
            goto L_0x0a42
        L_0x0a38:
            boolean r7 = java.lang.Float.isNaN(r23)
            if (r7 == 0) goto L_0x0a42
            float r6 = r6.f1603d
            r23 = r6
        L_0x0a42:
            r6 = r30
            r7 = r25
            goto L_0x0a15
        L_0x0a47:
            r25 = r7
            if (r5 == 0) goto L_0x0a65
            boolean r6 = java.lang.Float.isNaN(r23)
            if (r6 == 0) goto L_0x0a53
            r23 = 1065353216(0x3f800000, float:1.0)
        L_0x0a53:
            float r4 = r4 - r24
            float r23 = r23 - r24
            float r4 = r4 / r23
            double r6 = (double) r4
            double r4 = r5.mo21492a(r6)
            float r4 = (float) r4
            float r4 = r4 * r23
            float r4 = r4 + r24
            double r5 = (double) r4
            goto L_0x0a67
        L_0x0a65:
            r5 = r21
        L_0x0a67:
            d.e.a.a.b[] r4 = r0.f1531h
            r7 = 0
            r4 = r4[r7]
            double[] r7 = r0.f1537n
            r4.mo21480d(r5, r7)
            androidx.constraintlayout.motion.widget.o r4 = r0.f1527d
            int[] r5 = r0.f1536m
            double[] r6 = r0.f1537n
            r7 = 0
            r4.mo1920j(r5, r6, r1, r7)
            if (r2 <= 0) goto L_0x0a95
            double r4 = (double) r13
            r6 = 1
            r6 = r1[r6]
            r22 = r8
            r21 = r9
            double r8 = (double) r6
            double r8 = r15 - r8
            r6 = r1[r7]
            double r6 = (double) r6
            double r6 = r17 - r6
            double r6 = java.lang.Math.hypot(r8, r6)
            double r6 = r6 + r4
            float r4 = (float) r6
            r13 = r4
            goto L_0x0a99
        L_0x0a95:
            r22 = r8
            r21 = r9
        L_0x0a99:
            r4 = 0
            r4 = r1[r4]
            double r4 = (double) r4
            r6 = 1
            r6 = r1[r6]
            double r6 = (double) r6
            int r2 = r2 + 1
            r17 = r4
            r15 = r6
            r5 = r20
            r9 = r21
            r8 = r22
            r7 = r25
            r6 = r29
            goto L_0x09f7
        L_0x0ab2:
            r20 = r5
            r29 = r6
            r25 = r7
            r22 = r8
            r21 = r9
            r1 = r13
            goto L_0x0acc
        L_0x0abe:
            r28 = r2
            r19 = r4
            r20 = r5
            r29 = r6
            r25 = r7
            r22 = r8
            r21 = r9
        L_0x0acc:
            r12.mo1887f(r3)
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.e> r2 = r0.f1548y
            r2.put(r3, r12)
            r2 = r28
            r6 = r29
            r29 = r11
            r28 = r19
            r16 = r20
            r20 = r21
            r7 = r25
            r19 = r10
            goto L_0x07c7
        L_0x0ae6:
            java.util.ArrayList<androidx.constraintlayout.motion.widget.a> r2 = r0.f1545v
            java.util.Iterator r2 = r2.iterator()
        L_0x0aec:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x0b04
            java.lang.Object r3 = r2.next()
            androidx.constraintlayout.motion.widget.a r3 = (androidx.constraintlayout.motion.widget.C0327a) r3
            boolean r4 = r3 instanceof androidx.constraintlayout.motion.widget.C0331d
            if (r4 == 0) goto L_0x0aec
            androidx.constraintlayout.motion.widget.d r3 = (androidx.constraintlayout.motion.widget.C0331d) r3
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.e> r4 = r0.f1548y
            r3.mo1881M(r4)
            goto L_0x0aec
        L_0x0b04:
            java.util.HashMap<java.lang.String, androidx.constraintlayout.motion.widget.e> r2 = r0.f1548y
            java.util.Collection r2 = r2.values()
            java.util.Iterator r2 = r2.iterator()
        L_0x0b0e:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x0b1e
            java.lang.Object r3 = r2.next()
            androidx.constraintlayout.motion.widget.e r3 = (androidx.constraintlayout.motion.widget.C0333e) r3
            r3.mo1888g(r1)
            goto L_0x0b0e
        L_0x0b1e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.C0359l.mo1915s(int, int, long):void");
    }

    public String toString() {
        StringBuilder P = C4924a.m17863P(" start: x: ");
        P.append(this.f1527d.f1605f);
        P.append(" y: ");
        P.append(this.f1527d.f1606g);
        P.append(" end: x: ");
        P.append(this.f1528e.f1605f);
        P.append(" y: ");
        P.append(this.f1528e.f1606g);
        return P.toString();
    }
}
