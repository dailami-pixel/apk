package androidx.constraintlayout.motion.widget;

import android.view.animation.Interpolator;

/* renamed from: androidx.constraintlayout.motion.widget.m */
public abstract class C0360m implements Interpolator {
    /* renamed from: a */
    public abstract float mo1867a();
}
