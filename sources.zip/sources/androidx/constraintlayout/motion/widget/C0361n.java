package androidx.constraintlayout.motion.widget;

import android.graphics.Paint;
import java.util.Objects;

/* renamed from: androidx.constraintlayout.motion.widget.n */
public /* synthetic */ class C0361n {

    /* renamed from: A */
    public static /* synthetic */ int[] f1550A;

    /* renamed from: B */
    public static /* synthetic */ int[] f1551B;

    /* renamed from: C */
    public static /* synthetic */ int[] f1552C;

    /* renamed from: D */
    public static /* synthetic */ int[] f1553D;

    /* renamed from: E */
    public static /* synthetic */ int[] f1554E;

    /* renamed from: F */
    public static /* synthetic */ int[] f1555F;

    /* renamed from: G */
    public static /* synthetic */ int[] f1556G;

    /* renamed from: H */
    public static /* synthetic */ int[] f1557H;

    /* renamed from: I */
    public static /* synthetic */ int[] f1558I;

    /* renamed from: J */
    public static /* synthetic */ int[] f1559J;

    /* renamed from: K */
    public static /* synthetic */ int[] f1560K;

    /* renamed from: L */
    public static /* synthetic */ int[] f1561L;

    /* renamed from: M */
    public static /* synthetic */ int[] f1562M;

    /* renamed from: N */
    public static /* synthetic */ int[] f1563N;

    /* renamed from: O */
    public static /* synthetic */ int[] f1564O;

    /* renamed from: P */
    public static /* synthetic */ int[] f1565P;

    /* renamed from: Q */
    public static /* synthetic */ int[] f1566Q;

    /* renamed from: R */
    public static /* synthetic */ int[] f1567R;

    /* renamed from: S */
    public static /* synthetic */ int[] f1568S;

    /* renamed from: T */
    public static /* synthetic */ int[] f1569T;

    /* renamed from: U */
    public static /* synthetic */ int[] f1570U;

    /* renamed from: V */
    public static /* synthetic */ int[] f1571V;

    /* renamed from: W */
    public static /* synthetic */ int[] f1572W;

    /* renamed from: X */
    public static /* synthetic */ int[] f1573X;

    /* renamed from: a */
    public static /* synthetic */ int[] f1574a;

    /* renamed from: b */
    public static /* synthetic */ int[] f1575b;

    /* renamed from: c */
    public static /* synthetic */ int[] f1576c;

    /* renamed from: d */
    public static /* synthetic */ int[] f1577d;

    /* renamed from: e */
    public static /* synthetic */ int[] f1578e;

    /* renamed from: f */
    public static /* synthetic */ int[] f1579f;

    /* renamed from: g */
    public static /* synthetic */ int[] f1580g;

    /* renamed from: h */
    public static /* synthetic */ int[] f1581h;

    /* renamed from: i */
    public static /* synthetic */ int[] f1582i;

    /* renamed from: j */
    public static /* synthetic */ int[] f1583j;

    /* renamed from: k */
    public static /* synthetic */ int[] f1584k;

    /* renamed from: l */
    public static /* synthetic */ int[] f1585l;

    /* renamed from: m */
    public static /* synthetic */ int[] f1586m;

    /* renamed from: n */
    public static /* synthetic */ int[] f1587n;

    /* renamed from: o */
    public static /* synthetic */ int[] f1588o;

    /* renamed from: p */
    public static /* synthetic */ int[] f1589p;

    /* renamed from: q */
    public static /* synthetic */ int[] f1590q;

    /* renamed from: r */
    public static /* synthetic */ int[] f1591r;

    /* renamed from: s */
    public static /* synthetic */ int[] f1592s;

    /* renamed from: t */
    public static /* synthetic */ int[] f1593t;

    /* renamed from: u */
    public static /* synthetic */ int[] f1594u;

    /* renamed from: v */
    public static /* synthetic */ int[] f1595v;

    /* renamed from: w */
    public static /* synthetic */ int[] f1596w;

    /* renamed from: x */
    public static /* synthetic */ int[] f1597x;

    /* renamed from: y */
    public static /* synthetic */ int[] f1598y;

    /* renamed from: z */
    public static /* synthetic */ int[] f1599z;

    /* renamed from: A */
    public static /* synthetic */ int m1717A(int i) {
        if (i == 1) {
            return 1;
        }
        if (i == 2) {
            return 2;
        }
        throw null;
    }

    /* renamed from: B */
    public static /* synthetic */ int m1718B(int i) {
        if (i == 1) {
            return 96;
        }
        if (i == 2) {
            return 512;
        }
        if (i == 3) {
            return -1;
        }
        throw null;
    }

    /* renamed from: C */
    public static /* synthetic */ int m1719C(String str) {
        Objects.requireNonNull(str, "Name is null");
        if (str.equals("AUTO")) {
            return 1;
        }
        if (str.equals("TEXT")) {
            return 2;
        }
        if (str.equals("BYTE")) {
            return 3;
        }
        if (str.equals("NUMERIC")) {
            return 4;
        }
        throw new IllegalArgumentException("No enum constant com.google.zxing.pdf417.encoder.Compaction.".concat(str));
    }

    /* renamed from: a */
    public static synchronized /* synthetic */ int[] m1720a() {
        int[] iArr;
        synchronized (C0361n.class) {
            if (f1580g == null) {
                f1580g = m1730j(3);
            }
            iArr = f1580g;
        }
        return iArr;
    }

    /* renamed from: b */
    public static synchronized /* synthetic */ int[] m1721b() {
        int[] iArr;
        synchronized (C0361n.class) {
            if (f1583j == null) {
                f1583j = m1730j(2);
            }
            iArr = f1583j;
        }
        return iArr;
    }

    /* renamed from: c */
    public static synchronized /* synthetic */ int[] m1722c() {
        int[] iArr;
        synchronized (C0361n.class) {
            if (f1584k == null) {
                f1584k = m1730j(3);
            }
            iArr = f1584k;
        }
        return iArr;
    }

    public static int[] com$airbnb$lottie$model$DocumentData$Justification$s$values() {
        return (int[]) m1720a().clone();
    }

    public static int[] com$airbnb$lottie$model$content$PolystarShape$Type$s$values() {
        return (int[]) m1721b().clone();
    }

    public static int[] com$airbnb$lottie$model$content$ShapeStroke$LineCapType$s$values() {
        return (int[]) m1722c().clone();
    }

    /* renamed from: com$airbnb$lottie$model$content$ShapeStroke$LineJoinType$s$values */
    public static int[] m1723x4b958c1e() {
        return (int[]) m1724d().clone();
    }

    public static int[] com$airbnb$lottie$model$layer$Layer$MatteType$s$values() {
        return (int[]) m1725e().clone();
    }

    public static int[] com$google$firebase$perf$util$Constants$CounterNames$s$values() {
        return (int[]) m1726f().clone();
    }

    public static int[] com$google$firebase$perf$util$Constants$TraceNames$s$values() {
        return (int[]) m1727g().clone();
    }

    public static int com$google$zxing$pdf417$encoder$Compaction$s$valueOf(String str) {
        return m1719C(str);
    }

    /* renamed from: d */
    public static synchronized /* synthetic */ int[] m1724d() {
        int[] iArr;
        synchronized (C0361n.class) {
            if (f1585l == null) {
                f1585l = m1730j(3);
            }
            iArr = f1585l;
        }
        return iArr;
    }

    /* renamed from: e */
    public static synchronized /* synthetic */ int[] m1725e() {
        int[] iArr;
        synchronized (C0361n.class) {
            if (f1587n == null) {
                f1587n = m1730j(4);
            }
            iArr = f1587n;
        }
        return iArr;
    }

    /* renamed from: f */
    public static synchronized /* synthetic */ int[] m1726f() {
        int[] iArr;
        synchronized (C0361n.class) {
            if (f1599z == null) {
                f1599z = m1730j(6);
            }
            iArr = f1599z;
        }
        return iArr;
    }

    /* renamed from: g */
    public static synchronized /* synthetic */ int[] m1727g() {
        int[] iArr;
        synchronized (C0361n.class) {
            if (f1550A == null) {
                f1550A = m1730j(6);
            }
            iArr = f1550A;
        }
        return iArr;
    }

    /* renamed from: h */
    public static /* synthetic */ boolean m1728h(int i, int i2) {
        if (i != 0) {
            return i == i2;
        }
        throw null;
    }

    /* renamed from: i */
    public static /* synthetic */ int m1729i(int i) {
        if (i != 0) {
            return i - 1;
        }
        throw null;
    }

    /* renamed from: j */
    public static /* synthetic */ int[] m1730j(int i) {
        int[] iArr = new int[i];
        int i2 = 0;
        while (i2 < i) {
            int i3 = i2 + 1;
            iArr[i2] = i3;
            i2 = i3;
        }
        return iArr;
    }

    /* renamed from: k */
    public static int m1731k(int i) {
        int[] com$airbnb$lottie$model$content$PolystarShape$Type$s$values = com$airbnb$lottie$model$content$PolystarShape$Type$s$values();
        for (int i2 = 0; i2 < 2; i2++) {
            int i3 = com$airbnb$lottie$model$content$PolystarShape$Type$s$values[i2];
            if (m1717A(i3) == i) {
                return i3;
            }
        }
        return 0;
    }

    /* renamed from: l */
    public static Paint.Cap m1732l(int i) {
        int i2 = m1729i(i);
        return i2 != 0 ? i2 != 1 ? Paint.Cap.SQUARE : Paint.Cap.ROUND : Paint.Cap.BUTT;
    }

    /* renamed from: m */
    public static Paint.Join m1733m(int i) {
        int i2 = m1729i(i);
        if (i2 == 0) {
            return Paint.Join.MITER;
        }
        if (i2 == 1) {
            return Paint.Join.ROUND;
        }
        if (i2 != 2) {
            return null;
        }
        return Paint.Join.BEVEL;
    }

    /* renamed from: n */
    public static int m1734n(int i) {
        return m1741u(i);
    }

    /* renamed from: o */
    public static int m1735o(int i) {
        return m1729i(i);
    }

    /* renamed from: p */
    public static String m1736p(int i) {
        return m1745y(i);
    }

    /* renamed from: q */
    public static String m1737q(int i) {
        return m1746z(i);
    }

    /* renamed from: r */
    public static boolean m1738r(int i) {
        return (i & 1) == 0;
    }

    /* renamed from: s */
    public static /* synthetic */ int m1739s(int i) {
        if (i == 1) {
            return 3;
        }
        if (i == 2) {
            return 1;
        }
        if (i == 3) {
            return 2;
        }
        throw null;
    }

    /* renamed from: t */
    public static /* synthetic */ int m1740t(int i) {
        if (i == 1) {
            return 96;
        }
        if (i == 2) {
            return 384;
        }
        if (i == 3) {
            return -1;
        }
        throw null;
    }

    /* renamed from: u */
    public static /* synthetic */ int m1741u(int i) {
        if (i == 1) {
            return 1;
        }
        if (i == 2) {
            return 2;
        }
        if (i == 3) {
            return 3;
        }
        if (i == 4) {
            return 4;
        }
        throw null;
    }

    /* renamed from: v */
    public static /* synthetic */ boolean m1742v(int i) {
        if (i == 1) {
            return false;
        }
        if (i == 2) {
            return true;
        }
        if (i == 3) {
            return false;
        }
        if (i == 4) {
            return true;
        }
        throw null;
    }

    /* renamed from: w */
    public static /* synthetic */ boolean m1743w(int i) {
        if (i == 1 || i == 2) {
            return false;
        }
        if (i == 3 || i == 4) {
            return true;
        }
        throw null;
    }

    /* renamed from: x */
    public static /* synthetic */ String m1744x(int i) {
        if (i == 1) {
            return "TLSv1.2";
        }
        if (i == 2) {
            return "TLSv1.1";
        }
        if (i == 3) {
            return "TLSv1";
        }
        if (i == 4) {
            return "SSLv3";
        }
        throw null;
    }

    /* renamed from: y */
    public static /* synthetic */ String m1745y(int i) {
        if (i == 1) {
            return "_fstec";
        }
        if (i == 2) {
            return "_fsntc";
        }
        if (i == 3) {
            return "_tsns";
        }
        if (i == 4) {
            return "_fr_tot";
        }
        if (i == 5) {
            return "_fr_slo";
        }
        if (i == 6) {
            return "_fr_fzn";
        }
        throw null;
    }

    /* renamed from: z */
    public static /* synthetic */ String m1746z(int i) {
        if (i == 1) {
            return "_as";
        }
        if (i == 2) {
            return "_astui";
        }
        if (i == 3) {
            return "_astfd";
        }
        if (i == 4) {
            return "_asti";
        }
        if (i == 5) {
            return "_fs";
        }
        if (i == 6) {
            return "_bs";
        }
        throw null;
    }
}
