package androidx.constraintlayout.motion.widget;

import androidx.constraintlayout.widget.C0407a;
import androidx.constraintlayout.widget.C0411c;
import java.util.LinkedHashMap;
import p098d.p113e.p114a.p115a.C4637c;

/* renamed from: androidx.constraintlayout.motion.widget.o */
class C0362o implements Comparable<C0362o> {

    /* renamed from: a */
    static String[] f1600a = {"position", "x", "y", "width", "height", "pathRotate"};

    /* renamed from: b */
    C4637c f1601b;

    /* renamed from: c */
    int f1602c = 0;

    /* renamed from: d */
    float f1603d;

    /* renamed from: e */
    float f1604e;

    /* renamed from: f */
    float f1605f;

    /* renamed from: g */
    float f1606g;

    /* renamed from: h */
    float f1607h;

    /* renamed from: i */
    float f1608i;

    /* renamed from: j */
    float f1609j = Float.NaN;

    /* renamed from: k */
    int f1610k = -1;

    /* renamed from: l */
    LinkedHashMap<String, C0407a> f1611l = new LinkedHashMap<>();

    /* renamed from: m */
    int f1612m = 0;

    /* renamed from: n */
    double[] f1613n = new double[18];

    /* renamed from: o */
    double[] f1614o = new double[18];

    public C0362o() {
    }

    public C0362o(int i, int i2, C0351g gVar, C0362o oVar, C0362o oVar2) {
        C0351g gVar2 = gVar;
        C0362o oVar3 = oVar;
        C0362o oVar4 = oVar2;
        int i3 = gVar2.f1466m;
        if (i3 == 1) {
            float f = ((float) gVar2.f1398a) / 100.0f;
            this.f1603d = f;
            this.f1602c = gVar2.f1461h;
            float f2 = Float.isNaN(gVar2.f1462i) ? f : gVar2.f1462i;
            float f3 = Float.isNaN(gVar2.f1463j) ? f : gVar2.f1463j;
            float f4 = oVar4.f1607h - oVar3.f1607h;
            float f5 = oVar4.f1608i - oVar3.f1608i;
            this.f1604e = this.f1603d;
            f = !Float.isNaN(gVar2.f1464k) ? gVar2.f1464k : f;
            float f6 = oVar3.f1605f;
            float f7 = oVar3.f1607h;
            float f8 = oVar3.f1606g;
            float f9 = oVar3.f1608i;
            float f10 = ((oVar4.f1607h / 2.0f) + oVar4.f1605f) - ((f7 / 2.0f) + f6);
            float f11 = ((oVar4.f1608i / 2.0f) + oVar4.f1606g) - ((f9 / 2.0f) + f8);
            float f12 = f10 * f;
            float f13 = f4 * f2;
            float f14 = f13 / 2.0f;
            this.f1605f = (float) ((int) ((f6 + f12) - f14));
            float f15 = f * f11;
            float f16 = f5 * f3;
            float f17 = f16 / 2.0f;
            this.f1606g = (float) ((int) ((f8 + f15) - f17));
            this.f1607h = (float) ((int) (f7 + f13));
            this.f1608i = (float) ((int) (f9 + f16));
            float f18 = Float.isNaN(gVar2.f1465l) ? 0.0f : gVar2.f1465l;
            this.f1612m = 1;
            C0362o oVar5 = oVar;
            float f19 = (float) ((int) ((oVar5.f1605f + f12) - f14));
            this.f1605f = f19;
            float f20 = (float) ((int) ((oVar5.f1606g + f15) - f17));
            this.f1606g = f20;
            this.f1605f = f19 + ((-f11) * f18);
            this.f1606g = f20 + (f10 * f18);
            this.f1601b = C4637c.m16704c(gVar2.f1459f);
            this.f1610k = gVar2.f1460g;
        } else if (i3 != 2) {
            float f21 = ((float) gVar2.f1398a) / 100.0f;
            this.f1603d = f21;
            this.f1602c = gVar2.f1461h;
            float f22 = Float.isNaN(gVar2.f1462i) ? f21 : gVar2.f1462i;
            float f23 = Float.isNaN(gVar2.f1463j) ? f21 : gVar2.f1463j;
            float f24 = oVar4.f1607h;
            float f25 = oVar3.f1607h;
            float f26 = f24 - f25;
            float f27 = oVar4.f1608i;
            float f28 = oVar3.f1608i;
            float f29 = f27 - f28;
            this.f1604e = this.f1603d;
            float f30 = oVar3.f1605f;
            float f31 = oVar3.f1606g;
            float f32 = ((f24 / 2.0f) + oVar4.f1605f) - ((f25 / 2.0f) + f30);
            float f33 = ((f27 / 2.0f) + oVar4.f1606g) - ((f28 / 2.0f) + f31);
            float f34 = f26 * f22;
            float f35 = f34 / 2.0f;
            this.f1605f = (float) ((int) (((f32 * f21) + f30) - f35));
            float f36 = (f33 * f21) + f31;
            float f37 = f29 * f23;
            float f38 = f37 / 2.0f;
            this.f1606g = (float) ((int) (f36 - f38));
            this.f1607h = (float) ((int) (f25 + f34));
            this.f1608i = (float) ((int) (f28 + f37));
            float f39 = Float.isNaN(gVar2.f1464k) ? f21 : gVar2.f1464k;
            float f40 = Float.isNaN(Float.NaN) ? 0.0f : Float.NaN;
            f21 = !Float.isNaN(gVar2.f1465l) ? gVar2.f1465l : f21;
            float f41 = Float.isNaN(Float.NaN) ? 0.0f : Float.NaN;
            this.f1612m = 2;
            this.f1605f = (float) ((int) (((f41 * f33) + ((f39 * f32) + oVar3.f1605f)) - f35));
            this.f1606g = (float) ((int) (((f33 * f21) + ((f32 * f40) + oVar3.f1606g)) - f38));
            this.f1601b = C4637c.m16704c(gVar2.f1459f);
            this.f1610k = gVar2.f1460g;
        } else {
            float f42 = ((float) gVar2.f1398a) / 100.0f;
            this.f1603d = f42;
            this.f1602c = gVar2.f1461h;
            float f43 = Float.isNaN(gVar2.f1462i) ? f42 : gVar2.f1462i;
            float f44 = Float.isNaN(gVar2.f1463j) ? f42 : gVar2.f1463j;
            float f45 = oVar4.f1607h;
            float f46 = oVar3.f1607h;
            float f47 = f45 - f46;
            float f48 = oVar4.f1608i;
            float f49 = oVar3.f1608i;
            float f50 = f48 - f49;
            this.f1604e = this.f1603d;
            float f51 = oVar3.f1605f;
            float f52 = oVar3.f1606g;
            float f53 = (f45 / 2.0f) + oVar4.f1605f;
            float f54 = (f48 / 2.0f) + oVar4.f1606g;
            float f55 = f47 * f43;
            this.f1605f = (float) ((int) ((((f53 - ((f46 / 2.0f) + f51)) * f42) + f51) - (f55 / 2.0f)));
            float f56 = f50 * f44;
            this.f1606g = (float) ((int) ((((f54 - ((f49 / 2.0f) + f52)) * f42) + f52) - (f56 / 2.0f)));
            this.f1607h = (float) ((int) (f46 + f55));
            this.f1608i = (float) ((int) (f49 + f56));
            this.f1612m = 3;
            C0351g gVar3 = gVar;
            if (!Float.isNaN(gVar3.f1464k)) {
                this.f1605f = (float) ((int) (gVar3.f1464k * ((float) ((int) (((float) i) - this.f1607h)))));
            }
            if (!Float.isNaN(gVar3.f1465l)) {
                this.f1606g = (float) ((int) (gVar3.f1465l * ((float) ((int) (((float) i2) - this.f1608i)))));
            }
            this.f1601b = C4637c.m16704c(gVar3.f1459f);
            this.f1610k = gVar3.f1460g;
        }
    }

    /* renamed from: b */
    private boolean m1747b(float f, float f2) {
        return (Float.isNaN(f) || Float.isNaN(f2)) ? Float.isNaN(f) != Float.isNaN(f2) : Math.abs(f - f2) > 1.0E-6f;
    }

    /* renamed from: a */
    public void mo1917a(C0411c.C0412a aVar) {
        this.f1601b = C4637c.m16704c(aVar.f1897c.f1967d);
        C0411c.C0414c cVar = aVar.f1897c;
        this.f1610k = cVar.f1968e;
        this.f1609j = cVar.f1971h;
        this.f1602c = cVar.f1969f;
        float f = aVar.f1896b.f1976e;
        for (String next : aVar.f1900f.keySet()) {
            C0407a aVar2 = aVar.f1900f.get(next);
            if (aVar2.mo2054b() != 5) {
                this.f1611l.put(next, aVar2);
            }
        }
    }

    public int compareTo(Object obj) {
        return Float.compare(this.f1604e, ((C0362o) obj).f1604e);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public void mo1919f(C0362o oVar, boolean[] zArr, boolean z) {
        zArr[0] = zArr[0] | m1747b(this.f1604e, oVar.f1604e);
        zArr[1] = zArr[1] | m1747b(this.f1605f, oVar.f1605f) | z;
        zArr[2] = z | m1747b(this.f1606g, oVar.f1606g) | zArr[2];
        zArr[3] = zArr[3] | m1747b(this.f1607h, oVar.f1607h);
        zArr[4] = m1747b(this.f1608i, oVar.f1608i) | zArr[4];
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j */
    public void mo1920j(int[] iArr, double[] dArr, float[] fArr, int i) {
        float f = this.f1605f;
        float f2 = this.f1606g;
        float f3 = this.f1607h;
        float f4 = this.f1608i;
        for (int i2 = 0; i2 < iArr.length; i2++) {
            float f5 = (float) dArr[i2];
            int i3 = iArr[i2];
            if (i3 == 1) {
                f = f5;
            } else if (i3 == 2) {
                f2 = f5;
            } else if (i3 == 3) {
                f3 = f5;
            } else if (i3 == 4) {
                f4 = f5;
            }
        }
        fArr[i] = (f3 / 2.0f) + f + 0.0f;
        fArr[i + 1] = (f4 / 2.0f) + f2 + 0.0f;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n */
    public void mo1921n(float f, float f2, float f3, float f4) {
        this.f1605f = f;
        this.f1606g = f2;
        this.f1607h = f3;
        this.f1608i = f4;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: o */
    public void mo1922o(float f, float f2, float[] fArr, int[] iArr, double[] dArr, double[] dArr2) {
        int[] iArr2 = iArr;
        float f3 = 0.0f;
        float f4 = 0.0f;
        float f5 = 0.0f;
        float f6 = 0.0f;
        for (int i = 0; i < iArr2.length; i++) {
            float f7 = (float) dArr[i];
            double d = dArr2[i];
            int i2 = iArr2[i];
            if (i2 == 1) {
                f3 = f7;
            } else if (i2 == 2) {
                f5 = f7;
            } else if (i2 == 3) {
                f4 = f7;
            } else if (i2 == 4) {
                f6 = f7;
            }
        }
        float f8 = f3 - ((0.0f * f4) / 2.0f);
        float f9 = f5 - ((0.0f * f6) / 2.0f);
        fArr[0] = (((f4 * 1.0f) + f8) * f) + ((1.0f - f) * f8) + 0.0f;
        fArr[1] = (((f6 * 1.0f) + f9) * f2) + ((1.0f - f2) * f9) + 0.0f;
    }
}
