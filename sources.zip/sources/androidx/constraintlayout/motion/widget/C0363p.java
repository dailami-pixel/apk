package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.constraintlayout.widget.C0411c;
import androidx.constraintlayout.widget.C0418e;
import androidx.constraintlayout.widget.C0419f;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;
import org.xmlpull.v1.XmlPullParser;
import p098d.p099a.C4567a;
import p098d.p113e.p114a.p115a.C4637c;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.constraintlayout.motion.widget.p */
public class C0363p {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public final MotionLayout f1615a;

    /* renamed from: b */
    C0419f f1616b = null;

    /* renamed from: c */
    C0365b f1617c = null;

    /* renamed from: d */
    private ArrayList<C0365b> f1618d = new ArrayList<>();

    /* renamed from: e */
    private C0365b f1619e = null;

    /* renamed from: f */
    private ArrayList<C0365b> f1620f = new ArrayList<>();
    /* access modifiers changed from: private */

    /* renamed from: g */
    public SparseArray<C0411c> f1621g = new SparseArray<>();

    /* renamed from: h */
    private HashMap<String, Integer> f1622h = new HashMap<>();

    /* renamed from: i */
    private SparseIntArray f1623i = new SparseIntArray();
    /* access modifiers changed from: private */

    /* renamed from: j */
    public int f1624j = 400;
    /* access modifiers changed from: private */

    /* renamed from: k */
    public int f1625k = 0;

    /* renamed from: l */
    private MotionEvent f1626l;

    /* renamed from: m */
    private boolean f1627m = false;

    /* renamed from: n */
    private MotionLayout.C0323e f1628n;

    /* renamed from: o */
    private boolean f1629o;

    /* renamed from: p */
    float f1630p;

    /* renamed from: q */
    float f1631q;

    /* renamed from: androidx.constraintlayout.motion.widget.p$a */
    class C0364a implements Interpolator {

        /* renamed from: a */
        final /* synthetic */ C4637c f1632a;

        C0364a(C0363p pVar, C4637c cVar) {
            this.f1632a = cVar;
        }

        public float getInterpolation(float f) {
            return (float) this.f1632a.mo21492a((double) f);
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.p$b */
    public static class C0365b {

        /* renamed from: a */
        private int f1633a = -1;
        /* access modifiers changed from: private */

        /* renamed from: b */
        public boolean f1634b = false;
        /* access modifiers changed from: private */

        /* renamed from: c */
        public int f1635c = -1;
        /* access modifiers changed from: private */

        /* renamed from: d */
        public int f1636d = -1;
        /* access modifiers changed from: private */

        /* renamed from: e */
        public int f1637e = 0;
        /* access modifiers changed from: private */

        /* renamed from: f */
        public String f1638f = null;
        /* access modifiers changed from: private */

        /* renamed from: g */
        public int f1639g = -1;
        /* access modifiers changed from: private */

        /* renamed from: h */
        public int f1640h = 400;
        /* access modifiers changed from: private */

        /* renamed from: i */
        public float f1641i = 0.0f;
        /* access modifiers changed from: private */

        /* renamed from: j */
        public final C0363p f1642j;
        /* access modifiers changed from: private */

        /* renamed from: k */
        public ArrayList<C0350f> f1643k = new ArrayList<>();
        /* access modifiers changed from: private */

        /* renamed from: l */
        public C0397s f1644l = null;
        /* access modifiers changed from: private */

        /* renamed from: m */
        public ArrayList<C0366a> f1645m = new ArrayList<>();
        /* access modifiers changed from: private */

        /* renamed from: n */
        public int f1646n = 0;
        /* access modifiers changed from: private */

        /* renamed from: o */
        public boolean f1647o = false;
        /* access modifiers changed from: private */

        /* renamed from: p */
        public int f1648p = -1;

        /* renamed from: q */
        private int f1649q = 0;

        /* renamed from: r */
        private int f1650r = 0;

        /* renamed from: androidx.constraintlayout.motion.widget.p$b$a */
        static class C0366a implements View.OnClickListener {

            /* renamed from: a */
            private final C0365b f1651a;

            /* renamed from: b */
            int f1652b = -1;

            /* renamed from: c */
            int f1653c = 17;

            public C0366a(Context context, C0365b bVar, XmlPullParser xmlPullParser) {
                this.f1651a = bVar;
                TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), C0418e.f2009s);
                int indexCount = obtainStyledAttributes.getIndexCount();
                for (int i = 0; i < indexCount; i++) {
                    int index = obtainStyledAttributes.getIndex(i);
                    if (index == 1) {
                        this.f1652b = obtainStyledAttributes.getResourceId(index, this.f1652b);
                    } else if (index == 0) {
                        this.f1653c = obtainStyledAttributes.getInt(index, this.f1653c);
                    }
                }
                obtainStyledAttributes.recycle();
            }

            /* renamed from: a */
            public void mo1950a(MotionLayout motionLayout, int i, C0365b bVar) {
                int i2 = this.f1652b;
                View view = motionLayout;
                if (i2 != -1) {
                    view = motionLayout.findViewById(i2);
                }
                if (view == null) {
                    StringBuilder P = C4924a.m17863P("OnClick could not find id ");
                    P.append(this.f1652b);
                    Log.e("MotionScene", P.toString());
                    return;
                }
                int c = bVar.f1636d;
                int a = bVar.f1635c;
                if (c == -1) {
                    view.setOnClickListener(this);
                    return;
                }
                int i3 = this.f1653c;
                boolean z = false;
                boolean z2 = ((i3 & 1) != 0 && i == c) | ((i3 & 1) != 0 && i == c) | ((i3 & 256) != 0 && i == c) | ((i3 & 16) != 0 && i == a);
                if ((i3 & 4096) != 0 && i == a) {
                    z = true;
                }
                if (z2 || z) {
                    view.setOnClickListener(this);
                }
            }

            /* renamed from: b */
            public void mo1951b(MotionLayout motionLayout) {
                int i = this.f1652b;
                if (i != -1) {
                    View findViewById = motionLayout.findViewById(i);
                    if (findViewById == null) {
                        StringBuilder P = C4924a.m17863P(" (*)  could not find id ");
                        P.append(this.f1652b);
                        Log.e("MotionScene", P.toString());
                        return;
                    }
                    findViewById.setOnClickListener((View.OnClickListener) null);
                }
            }

            public void onClick(View view) {
                MotionLayout c = this.f1651a.f1642j.f1615a;
                if (c.mo1841d0()) {
                    if (this.f1651a.f1636d == -1) {
                        int i = c.f1356w;
                        if (i == -1) {
                            c.mo1852o0(this.f1651a.f1635c);
                            return;
                        }
                        C0365b bVar = new C0365b(this.f1651a.f1642j, this.f1651a);
                        int unused = bVar.f1636d = i;
                        int unused2 = bVar.f1635c = this.f1651a.f1635c;
                        c.mo1850m0(bVar);
                        c.mo1833S(1.0f);
                        return;
                    }
                    C0365b bVar2 = this.f1651a.f1642j.f1617c;
                    int i2 = this.f1653c;
                    boolean z = false;
                    boolean z2 = ((i2 & 1) == 0 && (i2 & 256) == 0) ? false : true;
                    boolean z3 = ((i2 & 16) == 0 && (i2 & 4096) == 0) ? false : true;
                    if (z2 && z3) {
                        C0365b bVar3 = this.f1651a.f1642j.f1617c;
                        C0365b bVar4 = this.f1651a;
                        if (bVar3 != bVar4) {
                            c.mo1850m0(bVar4);
                        }
                        if (c.f1356w == c.mo1838Y() || c.f1316F > 0.5f) {
                            z2 = false;
                        } else {
                            z3 = false;
                        }
                    }
                    C0365b bVar5 = this.f1651a;
                    if (bVar5 != bVar2) {
                        int a = bVar5.f1635c;
                        int c2 = this.f1651a.f1636d;
                        int i3 = c.f1356w;
                        if (c2 != -1) {
                        }
                    }
                    z = true;
                    if (!z) {
                        return;
                    }
                    if (z2 && (this.f1653c & 1) != 0) {
                        c.mo1850m0(this.f1651a);
                        c.mo1833S(1.0f);
                    } else if (z3 && (this.f1653c & 16) != 0) {
                        c.mo1850m0(this.f1651a);
                        c.mo1833S(0.0f);
                    } else if (z2 && (this.f1653c & 256) != 0) {
                        c.mo1850m0(this.f1651a);
                        c.mo1844h0(1.0f);
                    } else if (z3 && (this.f1653c & 4096) != 0) {
                        c.mo1850m0(this.f1651a);
                        c.mo1844h0(0.0f);
                    }
                }
            }
        }

        C0365b(C0363p pVar, Context context, XmlPullParser xmlPullParser) {
            int i;
            SparseArray sparseArray;
            C0411c cVar;
            int i2;
            this.f1640h = pVar.f1624j;
            this.f1649q = pVar.f1625k;
            this.f1642j = pVar;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), C0418e.f2015y);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i3 = 0; i3 < indexCount; i3++) {
                int index = obtainStyledAttributes.getIndex(i3);
                if (index == 2) {
                    this.f1635c = obtainStyledAttributes.getResourceId(index, this.f1635c);
                    if ("layout".equals(context.getResources().getResourceTypeName(this.f1635c))) {
                        cVar = new C0411c();
                        cVar.mo2077s(context, this.f1635c);
                        sparseArray = pVar.f1621g;
                        i = this.f1635c;
                    }
                } else {
                    if (index == 3) {
                        this.f1636d = obtainStyledAttributes.getResourceId(index, this.f1636d);
                        if ("layout".equals(context.getResources().getResourceTypeName(this.f1636d))) {
                            cVar = new C0411c();
                            cVar.mo2077s(context, this.f1636d);
                            sparseArray = pVar.f1621g;
                            i = this.f1636d;
                        }
                    } else if (index == 6) {
                        int i4 = obtainStyledAttributes.peekValue(index).type;
                        if (i4 == 1) {
                            int resourceId = obtainStyledAttributes.getResourceId(index, -1);
                            this.f1639g = resourceId;
                            if (resourceId == -1) {
                            }
                        } else {
                            if (i4 == 3) {
                                String string = obtainStyledAttributes.getString(index);
                                this.f1638f = string;
                                if (string.indexOf("/") > 0) {
                                    this.f1639g = obtainStyledAttributes.getResourceId(index, -1);
                                } else {
                                    i2 = -1;
                                }
                            } else {
                                i2 = obtainStyledAttributes.getInteger(index, this.f1637e);
                            }
                            this.f1637e = i2;
                        }
                        this.f1637e = -2;
                    } else if (index == 4) {
                        this.f1640h = obtainStyledAttributes.getInt(index, this.f1640h);
                    } else if (index == 8) {
                        this.f1641i = obtainStyledAttributes.getFloat(index, this.f1641i);
                    } else if (index == 1) {
                        this.f1646n = obtainStyledAttributes.getInteger(index, this.f1646n);
                    } else if (index == 0) {
                        this.f1633a = obtainStyledAttributes.getResourceId(index, this.f1633a);
                    } else if (index == 9) {
                        this.f1647o = obtainStyledAttributes.getBoolean(index, this.f1647o);
                    } else if (index == 7) {
                        this.f1648p = obtainStyledAttributes.getInteger(index, -1);
                    } else if (index == 5) {
                        this.f1649q = obtainStyledAttributes.getInteger(index, 0);
                    } else if (index == 10) {
                        this.f1650r = obtainStyledAttributes.getInteger(index, 0);
                    }
                }
                sparseArray.append(i, cVar);
            }
            if (this.f1636d == -1) {
                this.f1634b = true;
            }
            obtainStyledAttributes.recycle();
        }

        C0365b(C0363p pVar, C0365b bVar) {
            this.f1642j = pVar;
            if (bVar != null) {
                this.f1648p = bVar.f1648p;
                this.f1637e = bVar.f1637e;
                this.f1638f = bVar.f1638f;
                this.f1639g = bVar.f1639g;
                this.f1640h = bVar.f1640h;
                this.f1643k = bVar.f1643k;
                this.f1641i = bVar.f1641i;
                this.f1649q = bVar.f1649q;
            }
        }

        /* renamed from: A */
        public boolean mo1941A(int i) {
            return (i & this.f1650r) != 0;
        }

        /* renamed from: s */
        public void mo1942s(Context context, XmlPullParser xmlPullParser) {
            this.f1645m.add(new C0366a(context, this, xmlPullParser));
        }

        /* renamed from: t */
        public String mo1943t(Context context) {
            String resourceEntryName = this.f1636d == -1 ? "null" : context.getResources().getResourceEntryName(this.f1636d);
            if (this.f1635c == -1) {
                return C4924a.m17907v(resourceEntryName, " -> null");
            }
            StringBuilder T = C4924a.m17867T(resourceEntryName, " -> ");
            T.append(context.getResources().getResourceEntryName(this.f1635c));
            return T.toString();
        }

        /* renamed from: u */
        public int mo1944u() {
            return this.f1640h;
        }

        /* renamed from: v */
        public int mo1945v() {
            return this.f1635c;
        }

        /* renamed from: w */
        public int mo1946w() {
            return this.f1649q;
        }

        /* renamed from: x */
        public int mo1947x() {
            return this.f1636d;
        }

        /* renamed from: y */
        public C0397s mo1948y() {
            return this.f1644l;
        }

        /* renamed from: z */
        public boolean mo1949z() {
            return !this.f1647o;
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    C0363p(android.content.Context r9, androidx.constraintlayout.motion.widget.MotionLayout r10, int r11) {
        /*
            r8 = this;
            r8.<init>()
            r0 = 0
            r8.f1616b = r0
            r8.f1617c = r0
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r8.f1618d = r1
            r8.f1619e = r0
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r8.f1620f = r1
            android.util.SparseArray r1 = new android.util.SparseArray
            r1.<init>()
            r8.f1621g = r1
            java.util.HashMap r1 = new java.util.HashMap
            r1.<init>()
            r8.f1622h = r1
            android.util.SparseIntArray r1 = new android.util.SparseIntArray
            r1.<init>()
            r8.f1623i = r1
            r1 = 400(0x190, float:5.6E-43)
            r8.f1624j = r1
            r1 = 0
            r8.f1625k = r1
            r8.f1627m = r1
            r8.f1615a = r10
            android.content.res.Resources r10 = r9.getResources()
            android.content.res.XmlResourceParser r10 = r10.getXml(r11)
            int r2 = r10.getEventType()     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
        L_0x0044:
            r3 = 1
            if (r2 == r3) goto L_0x016e
            if (r2 == 0) goto L_0x015c
            r4 = 2
            if (r2 == r4) goto L_0x004e
            goto L_0x015f
        L_0x004e:
            java.lang.String r2 = r10.getName()     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            int r5 = r2.hashCode()     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            java.lang.String r6 = "MotionScene"
            r7 = -1
            switch(r5) {
                case -1349929691: goto L_0x0096;
                case -1239391468: goto L_0x008c;
                case 269306229: goto L_0x0083;
                case 312750793: goto L_0x0079;
                case 327855227: goto L_0x006f;
                case 793277014: goto L_0x0067;
                case 1382829617: goto L_0x005d;
                default: goto L_0x005c;
            }
        L_0x005c:
            goto L_0x00a0
        L_0x005d:
            java.lang.String r3 = "StateSet"
            boolean r3 = r2.equals(r3)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            if (r3 == 0) goto L_0x00a0
            r3 = 4
            goto L_0x00a1
        L_0x0067:
            boolean r3 = r2.equals(r6)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            if (r3 == 0) goto L_0x00a0
            r3 = 0
            goto L_0x00a1
        L_0x006f:
            java.lang.String r3 = "OnSwipe"
            boolean r3 = r2.equals(r3)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            if (r3 == 0) goto L_0x00a0
            r3 = 2
            goto L_0x00a1
        L_0x0079:
            java.lang.String r3 = "OnClick"
            boolean r3 = r2.equals(r3)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            if (r3 == 0) goto L_0x00a0
            r3 = 3
            goto L_0x00a1
        L_0x0083:
            java.lang.String r4 = "Transition"
            boolean r4 = r2.equals(r4)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            if (r4 == 0) goto L_0x00a0
            goto L_0x00a1
        L_0x008c:
            java.lang.String r3 = "KeyFrameSet"
            boolean r3 = r2.equals(r3)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            if (r3 == 0) goto L_0x00a0
            r3 = 6
            goto L_0x00a1
        L_0x0096:
            java.lang.String r3 = "ConstraintSet"
            boolean r3 = r2.equals(r3)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            if (r3 == 0) goto L_0x00a0
            r3 = 5
            goto L_0x00a1
        L_0x00a0:
            r3 = -1
        L_0x00a1:
            switch(r3) {
                case 0: goto L_0x0143;
                case 1: goto L_0x0101;
                case 2: goto L_0x00c7;
                case 3: goto L_0x00c2;
                case 4: goto L_0x00b9;
                case 5: goto L_0x00b4;
                case 6: goto L_0x00a6;
                default: goto L_0x00a4;
            }     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
        L_0x00a4:
            goto L_0x0147
        L_0x00a6:
            androidx.constraintlayout.motion.widget.f r2 = new androidx.constraintlayout.motion.widget.f     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r2.<init>(r9, r10)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            java.util.ArrayList r3 = r0.f1643k     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r3.add(r2)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            goto L_0x015f
        L_0x00b4:
            r8.m1758q(r9, r10)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            goto L_0x015f
        L_0x00b9:
            androidx.constraintlayout.widget.f r2 = new androidx.constraintlayout.widget.f     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r2.<init>(r9, r10)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r8.f1616b = r2     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            goto L_0x015f
        L_0x00c2:
            r0.mo1942s(r9, r10)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            goto L_0x015f
        L_0x00c7:
            if (r0 != 0) goto L_0x00f6
            android.content.res.Resources r2 = r9.getResources()     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            java.lang.String r2 = r2.getResourceEntryName(r11)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            int r3 = r10.getLineNumber()     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r4.<init>()     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            java.lang.String r5 = " OnSwipe ("
            r4.append(r5)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r4.append(r2)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            java.lang.String r2 = ".xml:"
            r4.append(r2)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r4.append(r3)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            java.lang.String r2 = ")"
            r4.append(r2)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            java.lang.String r2 = r4.toString()     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            android.util.Log.v(r6, r2)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
        L_0x00f6:
            androidx.constraintlayout.motion.widget.s r2 = new androidx.constraintlayout.motion.widget.s     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            androidx.constraintlayout.motion.widget.MotionLayout r3 = r8.f1615a     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r2.<init>(r9, r3, r10)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            androidx.constraintlayout.motion.widget.C0397s unused = r0.f1644l = r2     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            goto L_0x015f
        L_0x0101:
            java.util.ArrayList<androidx.constraintlayout.motion.widget.p$b> r0 = r8.f1618d     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            androidx.constraintlayout.motion.widget.p$b r2 = new androidx.constraintlayout.motion.widget.p$b     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r2.<init>(r8, r9, r10)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r0.add(r2)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            androidx.constraintlayout.motion.widget.p$b r0 = r8.f1617c     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            if (r0 != 0) goto L_0x0128
            boolean r0 = r2.f1634b     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            if (r0 != 0) goto L_0x0128
            r8.f1617c = r2     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            androidx.constraintlayout.motion.widget.s r0 = r2.f1644l     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            if (r0 == 0) goto L_0x0128
            androidx.constraintlayout.motion.widget.p$b r0 = r8.f1617c     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            androidx.constraintlayout.motion.widget.s r0 = r0.f1644l     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            boolean r3 = r8.f1629o     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r0.mo1980n(r3)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
        L_0x0128:
            boolean r0 = r2.f1634b     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            if (r0 == 0) goto L_0x0141
            int r0 = r2.f1635c     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            if (r0 != r7) goto L_0x0137
            r8.f1619e = r2     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            goto L_0x013c
        L_0x0137:
            java.util.ArrayList<androidx.constraintlayout.motion.widget.p$b> r0 = r8.f1620f     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r0.add(r2)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
        L_0x013c:
            java.util.ArrayList<androidx.constraintlayout.motion.widget.p$b> r0 = r8.f1618d     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r0.remove(r2)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
        L_0x0141:
            r0 = r2
            goto L_0x015f
        L_0x0143:
            r8.m1759r(r9, r10)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            goto L_0x015f
        L_0x0147:
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r3.<init>()     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            java.lang.String r4 = "WARNING UNKNOWN ATTRIBUTE "
            r3.append(r4)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            r3.append(r2)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            java.lang.String r2 = r3.toString()     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            android.util.Log.v(r6, r2)     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            goto L_0x015f
        L_0x015c:
            r10.getName()     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
        L_0x015f:
            int r2 = r10.next()     // Catch:{ XmlPullParserException -> 0x016a, IOException -> 0x0165 }
            goto L_0x0044
        L_0x0165:
            r9 = move-exception
            r9.printStackTrace()
            goto L_0x016e
        L_0x016a:
            r9 = move-exception
            r9.printStackTrace()
        L_0x016e:
            android.util.SparseArray<androidx.constraintlayout.widget.c> r9 = r8.f1621g
            androidx.constraintlayout.widget.c r10 = new androidx.constraintlayout.widget.c
            r10.<init>()
            r11 = 2131362505(0x7f0a02c9, float:1.8344792E38)
            r9.put(r11, r10)
            java.util.HashMap<java.lang.String, java.lang.Integer> r9 = r8.f1622h
            java.lang.Integer r10 = java.lang.Integer.valueOf(r11)
            java.lang.String r11 = "motion_base"
            r9.put(r11, r10)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.C0363p.<init>(android.content.Context, androidx.constraintlayout.motion.widget.MotionLayout, int):void");
    }

    /* renamed from: k */
    private int m1757k(Context context, String str) {
        int i;
        if (str.contains("/")) {
            i = context.getResources().getIdentifier(str.substring(str.indexOf(47) + 1), "id", context.getPackageName());
        } else {
            i = -1;
        }
        if (i != -1) {
            return i;
        }
        if (str.length() > 1) {
            return Integer.parseInt(str.substring(1));
        }
        Log.e("MotionScene", "error in parsing id");
        return i;
    }

    /* renamed from: q */
    private void m1758q(Context context, XmlPullParser xmlPullParser) {
        C0411c cVar = new C0411c();
        cVar.mo2081w(false);
        int attributeCount = xmlPullParser.getAttributeCount();
        int i = -1;
        int i2 = -1;
        for (int i3 = 0; i3 < attributeCount; i3++) {
            String attributeName = xmlPullParser.getAttributeName(i3);
            String attributeValue = xmlPullParser.getAttributeValue(i3);
            attributeName.hashCode();
            if (attributeName.equals("deriveConstraintsFrom")) {
                i2 = m1757k(context, attributeValue);
            } else if (attributeName.equals("id")) {
                i = m1757k(context, attributeValue);
                HashMap<String, Integer> hashMap = this.f1622h;
                int indexOf = attributeValue.indexOf(47);
                if (indexOf >= 0) {
                    attributeValue = attributeValue.substring(indexOf + 1);
                }
                hashMap.put(attributeValue, Integer.valueOf(i));
            }
        }
        if (i != -1) {
            int i4 = this.f1615a.f1324M;
            cVar.mo2078t(context, xmlPullParser);
            if (i2 != -1) {
                this.f1623i.put(i, i2);
            }
            this.f1621g.put(i, cVar);
        }
    }

    /* renamed from: r */
    private void m1759r(Context context, XmlPullParser xmlPullParser) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), C0418e.f2007q);
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i = 0; i < indexCount; i++) {
            int index = obtainStyledAttributes.getIndex(i);
            if (index == 0) {
                this.f1624j = obtainStyledAttributes.getInt(index, this.f1624j);
            } else if (index == 1) {
                this.f1625k = obtainStyledAttributes.getInteger(index, 0);
            }
        }
        obtainStyledAttributes.recycle();
    }

    /* renamed from: t */
    private void m1760t(int i) {
        int i2 = this.f1623i.get(i);
        if (i2 > 0) {
            m1760t(this.f1623i.get(i));
            C0411c cVar = this.f1621g.get(i);
            C0411c cVar2 = this.f1621g.get(i2);
            if (cVar2 == null) {
                StringBuilder P = C4924a.m17863P("ERROR! invalid deriveConstraintsFrom: @id/");
                P.append(C4567a.m16427b(this.f1615a.getContext(), i2));
                Log.e("MotionScene", P.toString());
                return;
            }
            cVar.mo2080v(cVar2);
            this.f1623i.put(i, -1);
        }
    }

    /* renamed from: e */
    public void mo1923e(MotionLayout motionLayout, int i) {
        Iterator<C0365b> it = this.f1618d.iterator();
        while (it.hasNext()) {
            C0365b next = it.next();
            if (next.f1645m.size() > 0) {
                Iterator it2 = next.f1645m.iterator();
                while (it2.hasNext()) {
                    ((C0365b.C0366a) it2.next()).mo1951b(motionLayout);
                }
            }
        }
        Iterator<C0365b> it3 = this.f1620f.iterator();
        while (it3.hasNext()) {
            C0365b next2 = it3.next();
            if (next2.f1645m.size() > 0) {
                Iterator it4 = next2.f1645m.iterator();
                while (it4.hasNext()) {
                    ((C0365b.C0366a) it4.next()).mo1951b(motionLayout);
                }
            }
        }
        Iterator<C0365b> it5 = this.f1618d.iterator();
        while (it5.hasNext()) {
            C0365b next3 = it5.next();
            if (next3.f1645m.size() > 0) {
                Iterator it6 = next3.f1645m.iterator();
                while (it6.hasNext()) {
                    ((C0365b.C0366a) it6.next()).mo1950a(motionLayout, i, next3);
                }
            }
        }
        Iterator<C0365b> it7 = this.f1620f.iterator();
        while (it7.hasNext()) {
            C0365b next4 = it7.next();
            if (next4.f1645m.size() > 0) {
                Iterator it8 = next4.f1645m.iterator();
                while (it8.hasNext()) {
                    ((C0365b.C0366a) it8.next()).mo1950a(motionLayout, i, next4);
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public boolean mo1924f(MotionLayout motionLayout, int i) {
        if (this.f1628n != null) {
            return false;
        }
        Iterator<C0365b> it = this.f1618d.iterator();
        while (it.hasNext()) {
            C0365b next = it.next();
            if (next.f1646n != 0) {
                if (i == next.f1636d && (next.f1646n == 4 || next.f1646n == 2)) {
                    motionLayout.mo1848k0(4);
                    motionLayout.mo1850m0(next);
                    if (next.f1646n == 4) {
                        motionLayout.mo1833S(1.0f);
                        motionLayout.mo1848k0(2);
                        motionLayout.mo1848k0(3);
                    } else {
                        motionLayout.mo1844h0(1.0f);
                        motionLayout.mo1834T(true);
                        motionLayout.mo1848k0(2);
                        motionLayout.mo1848k0(3);
                        motionLayout.mo1848k0(4);
                    }
                    return true;
                } else if (i == next.f1635c && (next.f1646n == 3 || next.f1646n == 1)) {
                    motionLayout.mo1848k0(4);
                    motionLayout.mo1850m0(next);
                    if (next.f1646n == 3) {
                        motionLayout.mo1833S(0.0f);
                        motionLayout.mo1848k0(2);
                        motionLayout.mo1848k0(3);
                    } else {
                        motionLayout.mo1844h0(0.0f);
                        motionLayout.mo1834T(true);
                        motionLayout.mo1848k0(2);
                        motionLayout.mo1848k0(3);
                        motionLayout.mo1848k0(4);
                    }
                    return true;
                }
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public C0411c mo1925g(int i) {
        Object obj;
        int b;
        C0419f fVar = this.f1616b;
        if (!(fVar == null || (b = fVar.mo2093b(i, -1, -1)) == -1)) {
            i = b;
        }
        if (this.f1621g.get(i) == null) {
            StringBuilder P = C4924a.m17863P("Warning could not find ConstraintSet id/");
            P.append(C4567a.m16427b(this.f1615a.getContext(), i));
            P.append(" In MotionScene");
            Log.e("MotionScene", P.toString());
            SparseArray sparseArray = this.f1621g;
            obj = sparseArray.get(sparseArray.keyAt(0));
        } else {
            obj = this.f1621g.get(i);
        }
        return (C0411c) obj;
    }

    /* renamed from: h */
    public ArrayList<C0365b> mo1926h() {
        return this.f1618d;
    }

    /* renamed from: i */
    public int mo1927i() {
        C0365b bVar = this.f1617c;
        return bVar != null ? bVar.f1640h : this.f1624j;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j */
    public int mo1928j() {
        C0365b bVar = this.f1617c;
        if (bVar == null) {
            return -1;
        }
        return bVar.f1635c;
    }

    /* renamed from: l */
    public Interpolator mo1929l() {
        int g = this.f1617c.f1637e;
        if (g == -2) {
            return AnimationUtils.loadInterpolator(this.f1615a.getContext(), this.f1617c.f1639g);
        }
        if (g == -1) {
            return new C0364a(this, C4637c.m16704c(this.f1617c.f1638f));
        }
        if (g == 0) {
            return new AccelerateDecelerateInterpolator();
        }
        if (g == 1) {
            return new AccelerateInterpolator();
        }
        if (g == 2) {
            return new DecelerateInterpolator();
        }
        if (g == 4) {
            return new AnticipateInterpolator();
        }
        if (g != 5) {
            return null;
        }
        return new BounceInterpolator();
    }

    /* renamed from: m */
    public void mo1930m(C0359l lVar) {
        C0365b bVar = this.f1617c;
        if (bVar == null) {
            C0365b bVar2 = this.f1619e;
            if (bVar2 != null) {
                Iterator it = bVar2.f1643k.iterator();
                while (it.hasNext()) {
                    ((C0350f) it.next()).mo1891a(lVar);
                }
                return;
            }
            return;
        }
        Iterator it2 = bVar.f1643k.iterator();
        while (it2.hasNext()) {
            ((C0350f) it2.next()).mo1891a(lVar);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n */
    public float mo1931n() {
        C0365b bVar = this.f1617c;
        if (bVar == null || bVar.f1644l == null) {
            return 0.0f;
        }
        return this.f1617c.f1644l.mo1970d();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: o */
    public float mo1932o() {
        C0365b bVar = this.f1617c;
        if (bVar == null || bVar.f1644l == null) {
            return 0.0f;
        }
        return this.f1617c.f1644l.mo1971e();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p */
    public int mo1933p() {
        C0365b bVar = this.f1617c;
        if (bVar == null) {
            return -1;
        }
        return bVar.f1636d;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: s */
    public void mo1934s(MotionEvent motionEvent, int i, MotionLayout motionLayout) {
        MotionLayout.C0323e eVar;
        MotionEvent motionEvent2;
        C0365b bVar;
        int i2;
        RectF h;
        MotionEvent motionEvent3 = motionEvent;
        int i3 = i;
        MotionLayout motionLayout2 = motionLayout;
        RectF rectF = new RectF();
        if (this.f1628n == null) {
            Objects.requireNonNull(this.f1615a);
            this.f1628n = MotionLayout.C0324f.m1527a();
        }
        VelocityTracker velocityTracker = ((MotionLayout.C0324f) this.f1628n).f1392b;
        if (velocityTracker != null) {
            velocityTracker.addMovement(motionEvent3);
        }
        if (i3 != -1) {
            int action = motionEvent.getAction();
            if (action == 0) {
                this.f1630p = motionEvent.getRawX();
                this.f1631q = motionEvent.getRawY();
                this.f1626l = motionEvent3;
                if (this.f1617c.f1644l != null) {
                    RectF c = this.f1617c.f1644l.mo1969c(this.f1615a, rectF);
                    if (c == null || c.contains(this.f1626l.getX(), this.f1626l.getY())) {
                        RectF h2 = this.f1617c.f1644l.mo1974h(this.f1615a, rectF);
                        this.f1627m = h2 != null && !h2.contains(this.f1626l.getX(), this.f1626l.getY());
                        this.f1617c.f1644l.mo1979m(this.f1630p, this.f1631q);
                        return;
                    }
                    this.f1626l = null;
                    return;
                }
                return;
            } else if (action == 2) {
                float rawY = motionEvent.getRawY() - this.f1631q;
                float rawX = motionEvent.getRawX() - this.f1630p;
                if ((((double) rawX) != 0.0d || ((double) rawY) != 0.0d) && (motionEvent2 = this.f1626l) != null) {
                    if (i3 != -1) {
                        C0419f fVar = this.f1616b;
                        if (fVar == null || (i2 = fVar.mo2093b(i3, -1, -1)) == -1) {
                            i2 = i3;
                        }
                        ArrayList arrayList = new ArrayList();
                        Iterator<C0365b> it = this.f1618d.iterator();
                        while (it.hasNext()) {
                            C0365b next = it.next();
                            if (next.f1636d == i2 || next.f1635c == i2) {
                                arrayList.add(next);
                            }
                        }
                        float f = 0.0f;
                        RectF rectF2 = new RectF();
                        Iterator it2 = arrayList.iterator();
                        bVar = null;
                        while (it2.hasNext()) {
                            C0365b bVar2 = (C0365b) it2.next();
                            if (!bVar2.f1647o && bVar2.f1644l != null) {
                                bVar2.f1644l.mo1980n(this.f1629o);
                                RectF h3 = bVar2.f1644l.mo1974h(this.f1615a, rectF2);
                                if ((h3 == null || h3.contains(motionEvent2.getX(), motionEvent2.getY())) && ((h = bVar2.f1644l.mo1974h(this.f1615a, rectF2)) == null || h.contains(motionEvent2.getX(), motionEvent2.getY()))) {
                                    float a = bVar2.f1644l.mo1967a(rawX, rawY) * (bVar2.f1635c == i3 ? -1.0f : 1.1f);
                                    if (a > f) {
                                        f = a;
                                        bVar = bVar2;
                                    }
                                }
                            }
                        }
                    } else {
                        bVar = this.f1617c;
                    }
                    if (bVar != null) {
                        motionLayout2.mo1850m0(bVar);
                        RectF h4 = this.f1617c.f1644l.mo1974h(this.f1615a, rectF);
                        this.f1627m = h4 != null && !h4.contains(this.f1626l.getX(), this.f1626l.getY());
                        this.f1617c.f1644l.mo1981o(this.f1630p, this.f1631q);
                    }
                } else {
                    return;
                }
            }
        }
        C0365b bVar3 = this.f1617c;
        if (!(bVar3 == null || bVar3.f1644l == null || this.f1627m)) {
            this.f1617c.f1644l.mo1976j(motionEvent3, this.f1628n);
        }
        this.f1630p = motionEvent.getRawX();
        this.f1631q = motionEvent.getRawY();
        if (motionEvent.getAction() == 1 && (eVar = this.f1628n) != null) {
            MotionLayout.C0324f fVar2 = (MotionLayout.C0324f) eVar;
            fVar2.f1392b.recycle();
            fVar2.f1392b = null;
            this.f1628n = null;
            int i4 = motionLayout2.f1356w;
            if (i4 != -1) {
                mo1924f(motionLayout2, i4);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: u */
    public void mo1935u(MotionLayout motionLayout) {
        boolean z;
        int i = 0;
        while (i < this.f1621g.size()) {
            int keyAt = this.f1621g.keyAt(i);
            int i2 = this.f1623i.get(keyAt);
            int size = this.f1623i.size();
            while (true) {
                if (i2 <= 0) {
                    z = false;
                    break;
                } else if (i2 == keyAt) {
                    break;
                } else {
                    int i3 = size - 1;
                    if (size < 0) {
                        break;
                    }
                    i2 = this.f1623i.get(i2);
                    size = i3;
                }
            }
            z = true;
            if (z) {
                Log.e("MotionScene", "Cannot be derived from yourself");
                return;
            } else {
                m1760t(keyAt);
                i++;
            }
        }
        for (int i4 = 0; i4 < this.f1621g.size(); i4++) {
            this.f1621g.valueAt(i4).mo2079u(motionLayout);
        }
    }

    /* renamed from: v */
    public void mo1936v(boolean z) {
        this.f1629o = z;
        C0365b bVar = this.f1617c;
        if (bVar != null && bVar.f1644l != null) {
            this.f1617c.f1644l.mo1980n(this.f1629o);
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0013, code lost:
        if (r2 != -1) goto L_0x0018;
     */
    /* renamed from: w */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1937w(int r7, int r8) {
        /*
            r6 = this;
            androidx.constraintlayout.widget.f r0 = r6.f1616b
            r1 = -1
            if (r0 == 0) goto L_0x0016
            int r0 = r0.mo2093b(r7, r1, r1)
            if (r0 == r1) goto L_0x000c
            goto L_0x000d
        L_0x000c:
            r0 = r7
        L_0x000d:
            androidx.constraintlayout.widget.f r2 = r6.f1616b
            int r2 = r2.mo2093b(r8, r1, r1)
            if (r2 == r1) goto L_0x0017
            goto L_0x0018
        L_0x0016:
            r0 = r7
        L_0x0017:
            r2 = r8
        L_0x0018:
            java.util.ArrayList<androidx.constraintlayout.motion.widget.p$b> r3 = r6.f1618d
            java.util.Iterator r3 = r3.iterator()
        L_0x001e:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x0058
            java.lang.Object r4 = r3.next()
            androidx.constraintlayout.motion.widget.p$b r4 = (androidx.constraintlayout.motion.widget.C0363p.C0365b) r4
            int r5 = r4.f1635c
            if (r5 != r2) goto L_0x0036
            int r5 = r4.f1636d
            if (r5 == r0) goto L_0x0042
        L_0x0036:
            int r5 = r4.f1635c
            if (r5 != r8) goto L_0x001e
            int r5 = r4.f1636d
            if (r5 != r7) goto L_0x001e
        L_0x0042:
            r6.f1617c = r4
            if (r4 == 0) goto L_0x0057
            androidx.constraintlayout.motion.widget.s r7 = r4.f1644l
            if (r7 == 0) goto L_0x0057
            androidx.constraintlayout.motion.widget.p$b r7 = r6.f1617c
            androidx.constraintlayout.motion.widget.s r7 = r7.f1644l
            boolean r8 = r6.f1629o
            r7.mo1980n(r8)
        L_0x0057:
            return
        L_0x0058:
            androidx.constraintlayout.motion.widget.p$b r7 = r6.f1619e
            java.util.ArrayList<androidx.constraintlayout.motion.widget.p$b> r3 = r6.f1620f
            java.util.Iterator r3 = r3.iterator()
        L_0x0060:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x0074
            java.lang.Object r4 = r3.next()
            androidx.constraintlayout.motion.widget.p$b r4 = (androidx.constraintlayout.motion.widget.C0363p.C0365b) r4
            int r5 = r4.f1635c
            if (r5 != r8) goto L_0x0060
            r7 = r4
            goto L_0x0060
        L_0x0074:
            androidx.constraintlayout.motion.widget.p$b r8 = new androidx.constraintlayout.motion.widget.p$b
            r8.<init>(r6, r7)
            int unused = r8.f1636d = r0
            int unused = r8.f1635c = r2
            if (r0 == r1) goto L_0x0086
            java.util.ArrayList<androidx.constraintlayout.motion.widget.p$b> r7 = r6.f1618d
            r7.add(r8)
        L_0x0086:
            r6.f1617c = r8
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.C0363p.mo1937w(int, int):void");
    }

    /* renamed from: x */
    public void mo1938x(C0365b bVar) {
        this.f1617c = bVar;
        if (bVar != null && bVar.f1644l != null) {
            this.f1617c.f1644l.mo1980n(this.f1629o);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: y */
    public boolean mo1939y() {
        Iterator<C0365b> it = this.f1618d.iterator();
        while (it.hasNext()) {
            if (it.next().f1644l != null) {
                return true;
            }
        }
        C0365b bVar = this.f1617c;
        return (bVar == null || bVar.f1644l == null) ? false : true;
    }
}
