package androidx.constraintlayout.motion.widget;

import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import androidx.constraintlayout.widget.C0407a;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.Arrays;
import p098d.p113e.p114a.p115a.C4635b;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.constraintlayout.motion.widget.q */
public abstract class C0367q {

    /* renamed from: a */
    protected C4635b f1654a;

    /* renamed from: b */
    protected int[] f1655b = new int[10];

    /* renamed from: c */
    protected float[] f1656c = new float[10];

    /* renamed from: d */
    private int f1657d;

    /* renamed from: e */
    private String f1658e;

    /* renamed from: androidx.constraintlayout.motion.widget.q$a */
    static class C0368a extends C0367q {
        C0368a() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            view.setAlpha((float) this.f1654a.mo21479c((double) f, 0));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$b */
    static class C0369b extends C0367q {

        /* renamed from: f */
        SparseArray<C0407a> f1659f;

        /* renamed from: g */
        float[] f1660g;

        public C0369b(String str, SparseArray<C0407a> sparseArray) {
            String str2 = str.split(",")[1];
            this.f1659f = sparseArray;
        }

        /* renamed from: c */
        public void mo1955c(int i, float f) {
            throw new RuntimeException("don't call for custom attribute call setPoint(pos, ConstraintAttribute)");
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            this.f1654a.mo21481e((double) f, this.f1660g);
            this.f1659f.valueAt(0).mo2058h(view, this.f1660g);
        }

        /* renamed from: f */
        public void mo1958f(int i) {
            int size = this.f1659f.size();
            int e = this.f1659f.valueAt(0).mo2057e();
            double[] dArr = new double[size];
            this.f1660g = new float[e];
            int[] iArr = new int[2];
            iArr[1] = e;
            iArr[0] = size;
            double[][] dArr2 = (double[][]) Array.newInstance(double.class, iArr);
            for (int i2 = 0; i2 < size; i2++) {
                dArr[i2] = ((double) this.f1659f.keyAt(i2)) * 0.01d;
                this.f1659f.valueAt(i2).mo2056d(this.f1660g);
                int i3 = 0;
                while (true) {
                    float[] fArr = this.f1660g;
                    if (i3 >= fArr.length) {
                        break;
                    }
                    dArr2[i2][i3] = (double) fArr[i3];
                    i3++;
                }
            }
            this.f1654a = C4635b.m16690a(i, dArr, dArr2);
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$c */
    static class C0370c extends C0367q {
        C0370c() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            view.setElevation((float) this.f1654a.mo21479c((double) f, 0));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$d */
    static class C0371d extends C0367q {
        C0371d() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$e */
    static class C0372e extends C0367q {
        C0372e() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            view.setPivotX((float) this.f1654a.mo21479c((double) f, 0));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$f */
    static class C0373f extends C0367q {
        C0373f() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            view.setPivotY((float) this.f1654a.mo21479c((double) f, 0));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$g */
    static class C0374g extends C0367q {

        /* renamed from: f */
        boolean f1661f = false;

        C0374g() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            if (view instanceof MotionLayout) {
                ((MotionLayout) view).mo1844h0((float) this.f1654a.mo21479c((double) f, 0));
            } else if (!this.f1661f) {
                Method method = null;
                try {
                    method = view.getClass().getMethod("setProgress", new Class[]{Float.TYPE});
                } catch (NoSuchMethodException unused) {
                    this.f1661f = true;
                }
                if (method != null) {
                    try {
                        method.invoke(view, new Object[]{Float.valueOf((float) this.f1654a.mo21479c((double) f, 0))});
                    } catch (IllegalAccessException | InvocationTargetException e) {
                        Log.e("SplineSet", "unable to setProgress", e);
                    }
                }
            }
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$h */
    static class C0375h extends C0367q {
        C0375h() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            view.setRotation((float) this.f1654a.mo21479c((double) f, 0));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$i */
    static class C0376i extends C0367q {
        C0376i() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            view.setRotationX((float) this.f1654a.mo21479c((double) f, 0));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$j */
    static class C0377j extends C0367q {
        C0377j() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            view.setRotationY((float) this.f1654a.mo21479c((double) f, 0));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$k */
    static class C0378k extends C0367q {
        C0378k() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            view.setScaleX((float) this.f1654a.mo21479c((double) f, 0));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$l */
    static class C0379l extends C0367q {
        C0379l() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            view.setScaleY((float) this.f1654a.mo21479c((double) f, 0));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$m */
    static class C0380m extends C0367q {
        C0380m() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            view.setTranslationX((float) this.f1654a.mo21479c((double) f, 0));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$n */
    static class C0381n extends C0367q {
        C0381n() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            view.setTranslationY((float) this.f1654a.mo21479c((double) f, 0));
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.q$o */
    static class C0382o extends C0367q {
        C0382o() {
        }

        /* renamed from: d */
        public void mo1956d(View view, float f) {
            view.setTranslationZ((float) this.f1654a.mo21479c((double) f, 0));
        }
    }

    /* renamed from: a */
    public float mo1953a(float f) {
        return (float) this.f1654a.mo21479c((double) f, 0);
    }

    /* renamed from: b */
    public float mo1954b(float f) {
        return (float) this.f1654a.mo21482f((double) f, 0);
    }

    /* renamed from: c */
    public void mo1955c(int i, float f) {
        int[] iArr = this.f1655b;
        if (iArr.length < this.f1657d + 1) {
            this.f1655b = Arrays.copyOf(iArr, iArr.length * 2);
            float[] fArr = this.f1656c;
            this.f1656c = Arrays.copyOf(fArr, fArr.length * 2);
        }
        int[] iArr2 = this.f1655b;
        int i2 = this.f1657d;
        iArr2[i2] = i;
        this.f1656c[i2] = f;
        this.f1657d = i2 + 1;
    }

    /* renamed from: d */
    public abstract void mo1956d(View view, float f);

    /* renamed from: e */
    public void mo1957e(String str) {
        this.f1658e = str;
    }

    /* renamed from: f */
    public void mo1958f(int i) {
        int i2 = this.f1657d;
        if (i2 != 0) {
            int[] iArr = this.f1655b;
            float[] fArr = this.f1656c;
            int[] iArr2 = new int[(iArr.length + 10)];
            iArr2[0] = i2 - 1;
            iArr2[1] = 0;
            int i3 = 2;
            while (i3 > 0) {
                int i4 = i3 - 1;
                int i5 = iArr2[i4];
                i3 = i4 - 1;
                int i6 = iArr2[i3];
                if (i5 < i6) {
                    int i7 = iArr[i6];
                    int i8 = i5;
                    int i9 = i8;
                    while (i8 < i6) {
                        if (iArr[i8] <= i7) {
                            int i10 = iArr[i9];
                            iArr[i9] = iArr[i8];
                            iArr[i8] = i10;
                            float f = fArr[i9];
                            fArr[i9] = fArr[i8];
                            fArr[i8] = f;
                            i9++;
                        }
                        i8++;
                    }
                    int i11 = iArr[i9];
                    iArr[i9] = iArr[i6];
                    iArr[i6] = i11;
                    float f2 = fArr[i9];
                    fArr[i9] = fArr[i6];
                    fArr[i6] = f2;
                    int i12 = i3 + 1;
                    iArr2[i3] = i9 - 1;
                    int i13 = i12 + 1;
                    iArr2[i12] = i5;
                    int i14 = i13 + 1;
                    iArr2[i13] = i6;
                    i3 = i14 + 1;
                    iArr2[i14] = i9 + 1;
                }
            }
            int i15 = 1;
            for (int i16 = 1; i16 < this.f1657d; i16++) {
                int[] iArr3 = this.f1655b;
                if (iArr3[i16 - 1] != iArr3[i16]) {
                    i15++;
                }
            }
            double[] dArr = new double[i15];
            int[] iArr4 = new int[2];
            iArr4[1] = 1;
            iArr4[0] = i15;
            double[][] dArr2 = (double[][]) Array.newInstance(double.class, iArr4);
            int i17 = 0;
            for (int i18 = 0; i18 < this.f1657d; i18++) {
                if (i18 > 0) {
                    int[] iArr5 = this.f1655b;
                    if (iArr5[i18] == iArr5[i18 - 1]) {
                    }
                }
                dArr[i17] = ((double) this.f1655b[i18]) * 0.01d;
                dArr2[i17][0] = (double) this.f1656c[i18];
                i17++;
            }
            this.f1654a = C4635b.m16690a(i, dArr, dArr2);
        }
    }

    public String toString() {
        String str = this.f1658e;
        DecimalFormat decimalFormat = new DecimalFormat("##.##");
        for (int i = 0; i < this.f1657d; i++) {
            StringBuilder T = C4924a.m17867T(str, "[");
            T.append(this.f1655b[i]);
            T.append(" , ");
            T.append(decimalFormat.format((double) this.f1656c[i]));
            T.append("] ");
            str = T.toString();
        }
        return str;
    }
}
