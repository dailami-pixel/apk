package androidx.constraintlayout.motion.widget;

import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import androidx.constraintlayout.widget.C0407a;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.HashMap;
import p098d.p113e.p114a.p115a.C4635b;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.constraintlayout.motion.widget.r */
public abstract class C0383r {

    /* renamed from: a */
    protected C4635b f1662a;

    /* renamed from: b */
    protected int f1663b = 0;

    /* renamed from: c */
    protected int[] f1664c = new int[10];

    /* renamed from: d */
    protected float[][] f1665d = ((float[][]) Array.newInstance(float.class, new int[]{10, 3}));

    /* renamed from: e */
    private int f1666e;

    /* renamed from: f */
    private String f1667f;

    /* renamed from: g */
    private float[] f1668g = new float[3];

    /* renamed from: h */
    protected boolean f1669h = false;

    /* renamed from: i */
    long f1670i;

    /* renamed from: j */
    float f1671j = Float.NaN;

    /* renamed from: androidx.constraintlayout.motion.widget.r$a */
    static class C0384a extends C0383r {
        C0384a() {
        }

        /* renamed from: d */
        public boolean mo1963d(View view, float f, long j, C0330c cVar) {
            view.setAlpha(mo1961b(f, j, view, cVar));
            return this.f1669h;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.r$b */
    static class C0385b extends C0383r {

        /* renamed from: k */
        SparseArray<C0407a> f1672k;

        /* renamed from: l */
        SparseArray<float[]> f1673l = new SparseArray<>();

        /* renamed from: m */
        float[] f1674m;

        /* renamed from: n */
        float[] f1675n;

        public C0385b(String str, SparseArray<C0407a> sparseArray) {
            String str2 = str.split(",")[1];
            this.f1672k = sparseArray;
        }

        /* renamed from: c */
        public void mo1962c(int i, float f, float f2, int i2, float f3) {
            throw new RuntimeException("don't call for custom attribute call setPoint(pos, ConstraintAttribute,...)");
        }

        /* renamed from: d */
        public boolean mo1963d(View view, float f, long j, C0330c cVar) {
            this.f1662a.mo21481e((double) f, this.f1674m);
            float[] fArr = this.f1674m;
            float f2 = fArr[fArr.length - 2];
            float f3 = fArr[fArr.length - 1];
            float f4 = (float) ((((((double) (j - this.f1670i)) * 1.0E-9d) * ((double) f2)) + ((double) this.f1671j)) % 1.0d);
            this.f1671j = f4;
            this.f1670i = j;
            float a = mo1960a(f4);
            this.f1669h = false;
            int i = 0;
            while (true) {
                float[] fArr2 = this.f1675n;
                if (i >= fArr2.length) {
                    break;
                }
                boolean z = this.f1669h;
                float[] fArr3 = this.f1674m;
                this.f1669h = z | (((double) fArr3[i]) != 0.0d);
                fArr2[i] = (fArr3[i] * a) + f3;
                i++;
            }
            this.f1672k.valueAt(0).mo2058h(view, this.f1675n);
            if (f2 != 0.0f) {
                this.f1669h = true;
            }
            return this.f1669h;
        }

        /* renamed from: f */
        public void mo1965f(int i) {
            int size = this.f1672k.size();
            int e = this.f1672k.valueAt(0).mo2057e();
            double[] dArr = new double[size];
            int i2 = e + 2;
            this.f1674m = new float[i2];
            this.f1675n = new float[e];
            int[] iArr = new int[2];
            iArr[1] = i2;
            iArr[0] = size;
            double[][] dArr2 = (double[][]) Array.newInstance(double.class, iArr);
            for (int i3 = 0; i3 < size; i3++) {
                int keyAt = this.f1672k.keyAt(i3);
                float[] valueAt = this.f1673l.valueAt(i3);
                dArr[i3] = ((double) keyAt) * 0.01d;
                this.f1672k.valueAt(i3).mo2056d(this.f1674m);
                int i4 = 0;
                while (true) {
                    float[] fArr = this.f1674m;
                    if (i4 >= fArr.length) {
                        break;
                    }
                    dArr2[i3][i4] = (double) fArr[i4];
                    i4++;
                }
                dArr2[i3][e] = (double) valueAt[0];
                dArr2[i3][e + 1] = (double) valueAt[1];
            }
            this.f1662a = C4635b.m16690a(i, dArr, dArr2);
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.r$c */
    static class C0386c extends C0383r {
        C0386c() {
        }

        /* renamed from: d */
        public boolean mo1963d(View view, float f, long j, C0330c cVar) {
            view.setElevation(mo1961b(f, j, view, cVar));
            return this.f1669h;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.r$d */
    static class C0387d extends C0383r {
        C0387d() {
        }

        /* renamed from: d */
        public boolean mo1963d(View view, float f, long j, C0330c cVar) {
            return this.f1669h;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.r$e */
    static class C0388e extends C0383r {

        /* renamed from: k */
        boolean f1676k = false;

        C0388e() {
        }

        /* renamed from: d */
        public boolean mo1963d(View view, float f, long j, C0330c cVar) {
            View view2 = view;
            if (view2 instanceof MotionLayout) {
                ((MotionLayout) view2).mo1844h0(mo1961b(f, j, view, cVar));
            } else if (this.f1676k) {
                return false;
            } else {
                Method method = null;
                try {
                    method = view.getClass().getMethod("setProgress", new Class[]{Float.TYPE});
                } catch (NoSuchMethodException unused) {
                    this.f1676k = true;
                }
                Method method2 = method;
                if (method2 != null) {
                    try {
                        method2.invoke(view, new Object[]{Float.valueOf(mo1961b(f, j, view, cVar))});
                    } catch (IllegalAccessException | InvocationTargetException e) {
                        Log.e("SplineSet", "unable to setProgress", e);
                    }
                }
            }
            return this.f1669h;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.r$f */
    static class C0389f extends C0383r {
        C0389f() {
        }

        /* renamed from: d */
        public boolean mo1963d(View view, float f, long j, C0330c cVar) {
            view.setRotation(mo1961b(f, j, view, cVar));
            return this.f1669h;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.r$g */
    static class C0390g extends C0383r {
        C0390g() {
        }

        /* renamed from: d */
        public boolean mo1963d(View view, float f, long j, C0330c cVar) {
            view.setRotationX(mo1961b(f, j, view, cVar));
            return this.f1669h;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.r$h */
    static class C0391h extends C0383r {
        C0391h() {
        }

        /* renamed from: d */
        public boolean mo1963d(View view, float f, long j, C0330c cVar) {
            view.setRotationY(mo1961b(f, j, view, cVar));
            return this.f1669h;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.r$i */
    static class C0392i extends C0383r {
        C0392i() {
        }

        /* renamed from: d */
        public boolean mo1963d(View view, float f, long j, C0330c cVar) {
            view.setScaleX(mo1961b(f, j, view, cVar));
            return this.f1669h;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.r$j */
    static class C0393j extends C0383r {
        C0393j() {
        }

        /* renamed from: d */
        public boolean mo1963d(View view, float f, long j, C0330c cVar) {
            view.setScaleY(mo1961b(f, j, view, cVar));
            return this.f1669h;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.r$k */
    static class C0394k extends C0383r {
        C0394k() {
        }

        /* renamed from: d */
        public boolean mo1963d(View view, float f, long j, C0330c cVar) {
            view.setTranslationX(mo1961b(f, j, view, cVar));
            return this.f1669h;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.r$l */
    static class C0395l extends C0383r {
        C0395l() {
        }

        /* renamed from: d */
        public boolean mo1963d(View view, float f, long j, C0330c cVar) {
            view.setTranslationY(mo1961b(f, j, view, cVar));
            return this.f1669h;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.r$m */
    static class C0396m extends C0383r {
        C0396m() {
        }

        /* renamed from: d */
        public boolean mo1963d(View view, float f, long j, C0330c cVar) {
            view.setTranslationZ(mo1961b(f, j, view, cVar));
            return this.f1669h;
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public float mo1960a(float f) {
        float abs;
        switch (this.f1663b) {
            case 1:
                return Math.signum(f * 6.2831855f);
            case 2:
                abs = Math.abs(f);
                break;
            case 3:
                return (((f * 2.0f) + 1.0f) % 2.0f) - 1.0f;
            case 4:
                abs = ((f * 2.0f) + 1.0f) % 2.0f;
                break;
            case 5:
                return (float) Math.cos((double) (f * 6.2831855f));
            case 6:
                float abs2 = 1.0f - Math.abs(((f * 4.0f) % 4.0f) - 2.0f);
                abs = abs2 * abs2;
                break;
            default:
                return (float) Math.sin((double) (f * 6.2831855f));
        }
        return 1.0f - abs;
    }

    /* renamed from: b */
    public float mo1961b(float f, long j, View view, C0330c cVar) {
        HashMap hashMap;
        long j2 = j;
        View view2 = view;
        C0330c cVar2 = cVar;
        this.f1662a.mo21481e((double) f, this.f1668g);
        float[] fArr = this.f1668g;
        boolean z = true;
        float f2 = fArr[1];
        int i = (f2 > 0.0f ? 1 : (f2 == 0.0f ? 0 : -1));
        if (i == 0) {
            this.f1669h = false;
            return fArr[2];
        }
        if (Float.isNaN(this.f1671j)) {
            String str = this.f1667f;
            float f3 = Float.NaN;
            if (cVar2.f1418a.containsKey(view2)) {
                HashMap hashMap2 = cVar2.f1418a.get(view2);
                if (hashMap2.containsKey(str)) {
                    float[] fArr2 = (float[]) hashMap2.get(str);
                    if (fArr2.length > 0) {
                        f3 = fArr2[0];
                    }
                }
            }
            this.f1671j = f3;
            if (Float.isNaN(f3)) {
                this.f1671j = 0.0f;
            }
        }
        float f4 = (float) ((((((double) (j2 - this.f1670i)) * 1.0E-9d) * ((double) f2)) + ((double) this.f1671j)) % 1.0d);
        this.f1671j = f4;
        String str2 = this.f1667f;
        if (!cVar2.f1418a.containsKey(view2)) {
            hashMap = new HashMap();
            hashMap.put(str2, new float[]{f4});
        } else {
            hashMap = cVar2.f1418a.get(view2);
            if (!hashMap.containsKey(str2)) {
                hashMap.put(str2, new float[]{f4});
            } else {
                float[] fArr3 = (float[]) hashMap.get(str2);
                if (fArr3.length <= 0) {
                    fArr3 = Arrays.copyOf(fArr3, 1);
                }
                fArr3[0] = f4;
                hashMap.put(str2, fArr3);
                this.f1670i = j2;
                float f5 = this.f1668g[0];
                float a = (mo1960a(this.f1671j) * f5) + this.f1668g[2];
                if (f5 == 0.0f && i == 0) {
                    z = false;
                }
                this.f1669h = z;
                return a;
            }
        }
        cVar2.f1418a.put(view2, hashMap);
        this.f1670i = j2;
        float f52 = this.f1668g[0];
        float a2 = (mo1960a(this.f1671j) * f52) + this.f1668g[2];
        z = false;
        this.f1669h = z;
        return a2;
    }

    /* renamed from: c */
    public void mo1962c(int i, float f, float f2, int i2, float f3) {
        int[] iArr = this.f1664c;
        int i3 = this.f1666e;
        iArr[i3] = i;
        float[][] fArr = this.f1665d;
        fArr[i3][0] = f;
        fArr[i3][1] = f2;
        fArr[i3][2] = f3;
        this.f1663b = Math.max(this.f1663b, i2);
        this.f1666e++;
    }

    /* renamed from: d */
    public abstract boolean mo1963d(View view, float f, long j, C0330c cVar);

    /* renamed from: e */
    public void mo1964e(String str) {
        this.f1667f = str;
    }

    /* renamed from: f */
    public void mo1965f(int i) {
        int i2 = this.f1666e;
        if (i2 == 0) {
            StringBuilder P = C4924a.m17863P("Error no points added to ");
            P.append(this.f1667f);
            Log.e("SplineSet", P.toString());
            return;
        }
        int[] iArr = this.f1664c;
        float[][] fArr = this.f1665d;
        int[] iArr2 = new int[(iArr.length + 10)];
        iArr2[0] = i2 - 1;
        iArr2[1] = 0;
        int i3 = 2;
        while (i3 > 0) {
            int i4 = i3 - 1;
            int i5 = iArr2[i4];
            i3 = i4 - 1;
            int i6 = iArr2[i3];
            if (i5 < i6) {
                int i7 = iArr[i6];
                int i8 = i5;
                int i9 = i8;
                while (i8 < i6) {
                    if (iArr[i8] <= i7) {
                        int i10 = iArr[i9];
                        iArr[i9] = iArr[i8];
                        iArr[i8] = i10;
                        float[] fArr2 = fArr[i9];
                        fArr[i9] = fArr[i8];
                        fArr[i8] = fArr2;
                        i9++;
                    }
                    i8++;
                }
                int i11 = iArr[i9];
                iArr[i9] = iArr[i6];
                iArr[i6] = i11;
                float[] fArr3 = fArr[i9];
                fArr[i9] = fArr[i6];
                fArr[i6] = fArr3;
                int i12 = i3 + 1;
                iArr2[i3] = i9 - 1;
                int i13 = i12 + 1;
                iArr2[i12] = i5;
                int i14 = i13 + 1;
                iArr2[i13] = i6;
                i3 = i14 + 1;
                iArr2[i14] = i9 + 1;
            }
        }
        int i15 = 1;
        int i16 = 0;
        while (true) {
            int[] iArr3 = this.f1664c;
            if (i15 >= iArr3.length) {
                break;
            }
            if (iArr3[i15] != iArr3[i15 - 1]) {
                i16++;
            }
            i15++;
        }
        if (i16 == 0) {
            i16 = 1;
        }
        double[] dArr = new double[i16];
        int[] iArr4 = new int[2];
        iArr4[1] = 3;
        iArr4[0] = i16;
        double[][] dArr2 = (double[][]) Array.newInstance(double.class, iArr4);
        int i17 = 0;
        for (int i18 = 0; i18 < this.f1666e; i18++) {
            if (i18 > 0) {
                int[] iArr5 = this.f1664c;
                if (iArr5[i18] == iArr5[i18 - 1]) {
                }
            }
            dArr[i17] = ((double) this.f1664c[i18]) * 0.01d;
            double[] dArr3 = dArr2[i17];
            float[][] fArr4 = this.f1665d;
            dArr3[0] = (double) fArr4[i18][0];
            dArr2[i17][1] = (double) fArr4[i18][1];
            dArr2[i17][2] = (double) fArr4[i18][2];
            i17++;
        }
        this.f1662a = C4635b.m16690a(i, dArr, dArr2);
    }

    public String toString() {
        String str = this.f1667f;
        DecimalFormat decimalFormat = new DecimalFormat("##.##");
        for (int i = 0; i < this.f1666e; i++) {
            StringBuilder T = C4924a.m17867T(str, "[");
            T.append(this.f1664c[i]);
            T.append(" , ");
            T.append(decimalFormat.format(this.f1665d[i]));
            T.append("] ");
            str = T.toString();
        }
        return str;
    }
}
