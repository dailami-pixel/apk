package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.Log;
import android.util.Xml;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.constraintlayout.widget.C0418e;
import androidx.core.widget.NestedScrollView;
import org.xmlpull.v1.XmlPullParser;
import p098d.p099a.C4567a;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.constraintlayout.motion.widget.s */
class C0397s {

    /* renamed from: a */
    private static final float[][] f1677a = {new float[]{0.5f, 0.0f}, new float[]{0.0f, 0.5f}, new float[]{1.0f, 0.5f}, new float[]{0.5f, 1.0f}, new float[]{0.5f, 0.5f}, new float[]{0.0f, 0.5f}, new float[]{1.0f, 0.5f}};

    /* renamed from: b */
    private static final float[][] f1678b = {new float[]{0.0f, -1.0f}, new float[]{0.0f, 1.0f}, new float[]{-1.0f, 0.0f}, new float[]{1.0f, 0.0f}, new float[]{-1.0f, 0.0f}, new float[]{1.0f, 0.0f}};

    /* renamed from: c */
    private int f1679c = 0;

    /* renamed from: d */
    private int f1680d = 0;

    /* renamed from: e */
    private int f1681e = 0;

    /* renamed from: f */
    private int f1682f = -1;

    /* renamed from: g */
    private int f1683g = -1;

    /* renamed from: h */
    private int f1684h = -1;

    /* renamed from: i */
    private float f1685i = 0.5f;

    /* renamed from: j */
    private float f1686j = 0.5f;

    /* renamed from: k */
    private float f1687k = 0.0f;

    /* renamed from: l */
    private float f1688l = 1.0f;

    /* renamed from: m */
    private boolean f1689m = false;

    /* renamed from: n */
    private float[] f1690n = new float[2];

    /* renamed from: o */
    private float f1691o;

    /* renamed from: p */
    private float f1692p;

    /* renamed from: q */
    private final MotionLayout f1693q;

    /* renamed from: r */
    private float f1694r = 4.0f;

    /* renamed from: s */
    private float f1695s = 1.2f;

    /* renamed from: t */
    private boolean f1696t = true;

    /* renamed from: u */
    private float f1697u = 1.0f;

    /* renamed from: v */
    private int f1698v = 0;

    /* renamed from: w */
    private float f1699w = 10.0f;

    /* renamed from: androidx.constraintlayout.motion.widget.s$a */
    class C0398a implements View.OnTouchListener {
        C0398a(C0397s sVar) {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            return false;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.s$b */
    class C0399b implements NestedScrollView.C0497b {
        C0399b(C0397s sVar) {
        }

        /* renamed from: a */
        public void mo536a(NestedScrollView nestedScrollView, int i, int i2, int i3, int i4) {
        }
    }

    C0397s(Context context, MotionLayout motionLayout, XmlPullParser xmlPullParser) {
        this.f1693q = motionLayout;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), C0418e.f2010t);
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i = 0; i < indexCount; i++) {
            int index = obtainStyledAttributes.getIndex(i);
            if (index == 9) {
                this.f1682f = obtainStyledAttributes.getResourceId(index, this.f1682f);
            } else if (index == 10) {
                int i2 = obtainStyledAttributes.getInt(index, this.f1679c);
                this.f1679c = i2;
                float[][] fArr = f1677a;
                this.f1686j = fArr[i2][0];
                this.f1685i = fArr[i2][1];
            } else if (index == 0) {
                int i3 = obtainStyledAttributes.getInt(index, this.f1680d);
                this.f1680d = i3;
                float[][] fArr2 = f1678b;
                this.f1687k = fArr2[i3][0];
                this.f1688l = fArr2[i3][1];
            } else if (index == 5) {
                this.f1694r = obtainStyledAttributes.getFloat(index, this.f1694r);
            } else if (index == 4) {
                this.f1695s = obtainStyledAttributes.getFloat(index, this.f1695s);
            } else if (index == 6) {
                this.f1696t = obtainStyledAttributes.getBoolean(index, this.f1696t);
            } else if (index == 1) {
                this.f1697u = obtainStyledAttributes.getFloat(index, this.f1697u);
            } else if (index == 2) {
                this.f1699w = obtainStyledAttributes.getFloat(index, this.f1699w);
            } else if (index == 11) {
                this.f1683g = obtainStyledAttributes.getResourceId(index, this.f1683g);
            } else if (index == 8) {
                this.f1681e = obtainStyledAttributes.getInt(index, this.f1681e);
            } else if (index == 7) {
                this.f1698v = obtainStyledAttributes.getInteger(index, 0);
            } else if (index == 3) {
                this.f1684h = obtainStyledAttributes.getResourceId(index, 0);
            }
        }
        obtainStyledAttributes.recycle();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public float mo1967a(float f, float f2) {
        return (f2 * this.f1688l) + (f * this.f1687k);
    }

    /* renamed from: b */
    public int mo1968b() {
        return this.f1698v;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public RectF mo1969c(ViewGroup viewGroup, RectF rectF) {
        View findViewById;
        int i = this.f1684h;
        if (i == -1 || (findViewById = viewGroup.findViewById(i)) == null) {
            return null;
        }
        rectF.set((float) findViewById.getLeft(), (float) findViewById.getTop(), (float) findViewById.getRight(), (float) findViewById.getBottom());
        return rectF;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public float mo1970d() {
        return this.f1695s;
    }

    /* renamed from: e */
    public float mo1971e() {
        return this.f1694r;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public boolean mo1972f() {
        return this.f1696t;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public float mo1973g(float f, float f2) {
        MotionLayout motionLayout = this.f1693q;
        motionLayout.mo1837X(this.f1682f, motionLayout.f1316F, this.f1686j, this.f1685i, this.f1690n);
        float f3 = this.f1687k;
        if (f3 != 0.0f) {
            float[] fArr = this.f1690n;
            if (fArr[0] == 0.0f) {
                fArr[0] = 1.0E-7f;
            }
            return (f * f3) / fArr[0];
        }
        float[] fArr2 = this.f1690n;
        if (fArr2[1] == 0.0f) {
            fArr2[1] = 1.0E-7f;
        }
        return (f2 * this.f1688l) / fArr2[1];
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public RectF mo1974h(ViewGroup viewGroup, RectF rectF) {
        View findViewById;
        int i = this.f1683g;
        if (i == -1 || (findViewById = viewGroup.findViewById(i)) == null) {
            return null;
        }
        rectF.set((float) findViewById.getLeft(), (float) findViewById.getTop(), (float) findViewById.getRight(), (float) findViewById.getBottom());
        return rectF;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public int mo1975i() {
        return this.f1683g;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j */
    public void mo1976j(MotionEvent motionEvent, MotionLayout.C0323e eVar) {
        int i;
        float f;
        MotionLayout.C0324f fVar = (MotionLayout.C0324f) eVar;
        VelocityTracker velocityTracker = fVar.f1392b;
        MotionEvent motionEvent2 = motionEvent;
        if (velocityTracker != null) {
            velocityTracker.addMovement(motionEvent2);
        }
        int action = motionEvent.getAction();
        if (action == 0) {
            this.f1691o = motionEvent.getRawX();
            this.f1692p = motionEvent.getRawY();
            this.f1689m = false;
        } else if (action == 1) {
            this.f1689m = false;
            fVar.f1392b.computeCurrentVelocity(1000);
            float xVelocity = fVar.f1392b.getXVelocity();
            float yVelocity = fVar.f1392b.getYVelocity();
            MotionLayout motionLayout = this.f1693q;
            float f2 = motionLayout.f1316F;
            int i2 = this.f1682f;
            if (i2 != -1) {
                motionLayout.mo1837X(i2, f2, this.f1686j, this.f1685i, this.f1690n);
            } else {
                float min = (float) Math.min(motionLayout.getWidth(), this.f1693q.getHeight());
                float[] fArr = this.f1690n;
                fArr[1] = this.f1688l * min;
                fArr[0] = min * this.f1687k;
            }
            float f3 = this.f1687k;
            float[] fArr2 = this.f1690n;
            float f4 = fArr2[0];
            float f5 = fArr2[1];
            float f6 = f3 != 0.0f ? xVelocity / fArr2[0] : yVelocity / fArr2[1];
            float f7 = !Float.isNaN(f6) ? (f6 / 3.0f) + f2 : f2;
            if (f7 != 0.0f && f7 != 1.0f && (i = this.f1681e) != 3) {
                this.f1693q.mo1851n0(i, ((double) f7) < 0.5d ? 0.0f : 1.0f, f6);
                if (0.0f < f2 && 1.0f > f2) {
                    return;
                }
            } else if (0.0f < f7 && 1.0f > f7) {
                return;
            }
            this.f1693q.mo1848k0(4);
        } else if (action == 2) {
            float rawY = motionEvent.getRawY() - this.f1692p;
            float rawX = motionEvent.getRawX() - this.f1691o;
            if (Math.abs((this.f1688l * rawY) + (this.f1687k * rawX)) > this.f1699w || this.f1689m) {
                MotionLayout motionLayout2 = this.f1693q;
                float f8 = motionLayout2.f1316F;
                if (!this.f1689m) {
                    this.f1689m = true;
                    motionLayout2.mo1844h0(f8);
                }
                int i3 = this.f1682f;
                if (i3 != -1) {
                    f = f8;
                    this.f1693q.mo1837X(i3, f8, this.f1686j, this.f1685i, this.f1690n);
                } else {
                    f = f8;
                    float min2 = (float) Math.min(this.f1693q.getWidth(), this.f1693q.getHeight());
                    float[] fArr3 = this.f1690n;
                    fArr3[1] = this.f1688l * min2;
                    fArr3[0] = min2 * this.f1687k;
                }
                float f9 = this.f1687k;
                float[] fArr4 = this.f1690n;
                if (((double) Math.abs(((this.f1688l * fArr4[1]) + (f9 * fArr4[0])) * this.f1697u)) < 0.01d) {
                    float[] fArr5 = this.f1690n;
                    fArr5[0] = 0.01f;
                    fArr5[1] = 0.01f;
                }
                float max = Math.max(Math.min(f + (this.f1687k != 0.0f ? rawX / this.f1690n[0] : rawY / this.f1690n[1]), 1.0f), 0.0f);
                MotionLayout motionLayout3 = this.f1693q;
                if (max != motionLayout3.f1316F) {
                    motionLayout3.mo1844h0(max);
                    fVar.f1392b.computeCurrentVelocity(1000);
                    this.f1693q.f1352u = this.f1687k != 0.0f ? fVar.f1392b.getXVelocity() / this.f1690n[0] : fVar.f1392b.getYVelocity() / this.f1690n[1];
                } else {
                    motionLayout3.f1352u = 0.0f;
                }
                this.f1691o = motionEvent.getRawX();
                this.f1692p = motionEvent.getRawY();
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k */
    public void mo1977k(float f, float f2) {
        MotionLayout motionLayout = this.f1693q;
        float f3 = motionLayout.f1316F;
        if (!this.f1689m) {
            this.f1689m = true;
            motionLayout.mo1844h0(f3);
        }
        this.f1693q.mo1837X(this.f1682f, f3, this.f1686j, this.f1685i, this.f1690n);
        float f4 = this.f1687k;
        float[] fArr = this.f1690n;
        if (((double) Math.abs((this.f1688l * fArr[1]) + (f4 * fArr[0]))) < 0.01d) {
            float[] fArr2 = this.f1690n;
            fArr2[0] = 0.01f;
            fArr2[1] = 0.01f;
        }
        float f5 = this.f1687k;
        float max = Math.max(Math.min(f3 + (f5 != 0.0f ? (f * f5) / this.f1690n[0] : (f2 * this.f1688l) / this.f1690n[1]), 1.0f), 0.0f);
        MotionLayout motionLayout2 = this.f1693q;
        if (max != motionLayout2.f1316F) {
            motionLayout2.mo1844h0(max);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l */
    public void mo1978l(float f, float f2) {
        boolean z = false;
        this.f1689m = false;
        MotionLayout motionLayout = this.f1693q;
        float f3 = motionLayout.f1316F;
        motionLayout.mo1837X(this.f1682f, f3, this.f1686j, this.f1685i, this.f1690n);
        float f4 = this.f1687k;
        float[] fArr = this.f1690n;
        float f5 = fArr[0];
        float f6 = this.f1688l;
        float f7 = fArr[1];
        float f8 = 0.0f;
        float f9 = f4 != 0.0f ? (f * f4) / fArr[0] : (f2 * f6) / fArr[1];
        if (!Float.isNaN(f9)) {
            f3 += f9 / 3.0f;
        }
        if (f3 != 0.0f) {
            boolean z2 = f3 != 1.0f;
            int i = this.f1681e;
            if (i != 3) {
                z = true;
            }
            if (z && z2) {
                MotionLayout motionLayout2 = this.f1693q;
                if (((double) f3) >= 0.5d) {
                    f8 = 1.0f;
                }
                motionLayout2.mo1851n0(i, f8, f9);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: m */
    public void mo1979m(float f, float f2) {
        this.f1691o = f;
        this.f1692p = f2;
    }

    /* renamed from: n */
    public void mo1980n(boolean z) {
        if (z) {
            float[][] fArr = f1678b;
            fArr[4] = fArr[3];
            fArr[5] = fArr[2];
            float[][] fArr2 = f1677a;
            fArr2[5] = fArr2[2];
            fArr2[6] = fArr2[1];
        } else {
            float[][] fArr3 = f1678b;
            fArr3[4] = fArr3[2];
            fArr3[5] = fArr3[3];
            float[][] fArr4 = f1677a;
            fArr4[5] = fArr4[1];
            fArr4[6] = fArr4[2];
        }
        float[][] fArr5 = f1677a;
        int i = this.f1679c;
        this.f1686j = fArr5[i][0];
        this.f1685i = fArr5[i][1];
        float[][] fArr6 = f1678b;
        int i2 = this.f1680d;
        this.f1687k = fArr6[i2][0];
        this.f1688l = fArr6[i2][1];
    }

    /* access modifiers changed from: package-private */
    /* renamed from: o */
    public void mo1981o(float f, float f2) {
        this.f1691o = f;
        this.f1692p = f2;
        this.f1689m = false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p */
    public void mo1982p() {
        View view;
        int i = this.f1682f;
        if (i != -1) {
            view = this.f1693q.findViewById(i);
            if (view == null) {
                StringBuilder P = C4924a.m17863P("cannot find TouchAnchorId @id/");
                P.append(C4567a.m16427b(this.f1693q.getContext(), this.f1682f));
                Log.e("TouchResponse", P.toString());
            }
        } else {
            view = null;
        }
        if (view instanceof NestedScrollView) {
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            nestedScrollView.setOnTouchListener(new C0398a(this));
            nestedScrollView.mo2374C(new C0399b(this));
        }
    }

    public String toString() {
        return this.f1687k + " , " + this.f1688l;
    }
}
