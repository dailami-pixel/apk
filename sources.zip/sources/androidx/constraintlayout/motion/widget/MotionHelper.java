package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.constraintlayout.widget.C0418e;
import androidx.constraintlayout.widget.ConstraintHelper;

public class MotionHelper extends ConstraintHelper implements MotionLayout.C0326h {

    /* renamed from: h */
    private boolean f1303h = false;

    /* renamed from: i */
    private boolean f1304i = false;

    public MotionHelper(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        mo1809l(attributeSet);
    }

    public MotionHelper(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        mo1809l(attributeSet);
    }

    /* renamed from: a */
    public void mo1827a(MotionLayout motionLayout, int i, int i2, float f) {
    }

    /* renamed from: b */
    public void mo1828b(MotionLayout motionLayout, int i, int i2) {
    }

    /* renamed from: c */
    public void mo1829c(MotionLayout motionLayout, int i, boolean z, float f) {
    }

    /* renamed from: d */
    public void mo1830d(MotionLayout motionLayout, int i) {
    }

    /* access modifiers changed from: protected */
    /* renamed from: l */
    public void mo1809l(AttributeSet attributeSet) {
        super.mo1809l(attributeSet);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C0418e.f2005o);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 1) {
                    this.f1303h = obtainStyledAttributes.getBoolean(index, this.f1303h);
                } else if (index == 0) {
                    this.f1304i = obtainStyledAttributes.getBoolean(index, this.f1304i);
                }
            }
        }
    }

    /* renamed from: w */
    public boolean mo1831w() {
        return this.f1304i;
    }

    /* renamed from: x */
    public boolean mo1832x() {
        return this.f1303h;
    }
}
