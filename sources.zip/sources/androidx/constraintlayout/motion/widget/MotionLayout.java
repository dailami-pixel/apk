package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import androidx.constraintlayout.motion.widget.C0363p;
import androidx.constraintlayout.widget.Barrier;
import androidx.constraintlayout.widget.C0408b;
import androidx.constraintlayout.widget.C0411c;
import androidx.constraintlayout.widget.C0418e;
import androidx.constraintlayout.widget.C0419f;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Constraints;
import com.appsflyer.oaid.BuildConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import p098d.p099a.C4567a;
import p098d.p113e.p114a.p115a.C4642g;
import p098d.p113e.p116b.p117i.C4657a;
import p098d.p113e.p116b.p117i.C4662e;
import p098d.p113e.p116b.p117i.C4664f;
import p098d.p113e.p116b.p117i.C4665g;
import p098d.p113e.p116b.p117i.C4667h;
import p098d.p113e.p116b.p117i.C4668i;
import p098d.p113e.p116b.p117i.C4669j;
import p098d.p113e.p116b.p117i.C4671l;
import p098d.p120g.p130j.C4756h;
import p165e.p166a.p167a.p168a.C4924a;

public class MotionLayout extends ConstraintLayout implements C4756h {

    /* renamed from: r */
    public static boolean f1305r;

    /* renamed from: A */
    private boolean f1306A = true;

    /* renamed from: A0 */
    int f1307A0 = 1;

    /* renamed from: B */
    HashMap<View, C0359l> f1308B = new HashMap<>();

    /* renamed from: B0 */
    C0322d f1309B0 = new C0322d();

    /* renamed from: C */
    private long f1310C = 0;

    /* renamed from: C0 */
    private boolean f1311C0 = false;

    /* renamed from: D */
    private float f1312D = 1.0f;

    /* renamed from: D0 */
    private RectF f1313D0 = new RectF();

    /* renamed from: E */
    float f1314E = 0.0f;

    /* renamed from: E0 */
    private View f1315E0 = null;

    /* renamed from: F */
    float f1316F = 0.0f;

    /* renamed from: F0 */
    ArrayList<Integer> f1317F0 = new ArrayList<>();

    /* renamed from: G */
    private long f1318G;

    /* renamed from: H */
    float f1319H = 0.0f;

    /* renamed from: I */
    private boolean f1320I;

    /* renamed from: J */
    boolean f1321J = false;

    /* renamed from: K */
    private float f1322K;

    /* renamed from: L */
    private float f1323L;

    /* renamed from: M */
    int f1324M = 0;

    /* renamed from: N */
    C0321c f1325N;

    /* renamed from: O */
    private boolean f1326O = false;

    /* renamed from: P */
    private C4642g f1327P = new C4642g();

    /* renamed from: Q */
    private C0320b f1328Q = new C0320b();

    /* renamed from: R */
    int f1329R;

    /* renamed from: a0 */
    int f1330a0;

    /* renamed from: b0 */
    boolean f1331b0 = false;

    /* renamed from: c0 */
    float f1332c0;

    /* renamed from: d0 */
    float f1333d0;

    /* renamed from: e0 */
    long f1334e0;

    /* renamed from: f0 */
    float f1335f0;

    /* renamed from: g0 */
    private boolean f1336g0 = false;

    /* renamed from: h0 */
    private ArrayList<MotionHelper> f1337h0 = null;

    /* renamed from: i0 */
    private ArrayList<MotionHelper> f1338i0 = null;

    /* renamed from: j0 */
    private ArrayList<C0326h> f1339j0 = null;

    /* renamed from: k0 */
    private int f1340k0 = 0;

    /* renamed from: l0 */
    private long f1341l0 = -1;

    /* renamed from: m0 */
    private float f1342m0 = 0.0f;

    /* renamed from: n0 */
    private int f1343n0 = 0;

    /* renamed from: o0 */
    private float f1344o0 = 0.0f;

    /* renamed from: p0 */
    protected boolean f1345p0 = false;

    /* renamed from: q0 */
    int f1346q0;

    /* renamed from: r0 */
    int f1347r0;

    /* renamed from: s */
    C0363p f1348s;

    /* renamed from: s0 */
    int f1349s0;

    /* renamed from: t */
    Interpolator f1350t;

    /* renamed from: t0 */
    int f1351t0;

    /* renamed from: u */
    float f1352u = 0.0f;

    /* renamed from: u0 */
    int f1353u0;

    /* renamed from: v */
    private int f1354v = -1;

    /* renamed from: v0 */
    int f1355v0;

    /* renamed from: w */
    int f1356w = -1;

    /* renamed from: w0 */
    float f1357w0;
    /* access modifiers changed from: private */

    /* renamed from: x */
    public int f1358x = -1;

    /* renamed from: x0 */
    private C0330c f1359x0 = new C0330c();
    /* access modifiers changed from: private */

    /* renamed from: y */
    public int f1360y = 0;

    /* renamed from: y0 */
    private boolean f1361y0 = false;
    /* access modifiers changed from: private */

    /* renamed from: z */
    public int f1362z = 0;

    /* renamed from: z0 */
    private C0325g f1363z0;

    /* renamed from: androidx.constraintlayout.motion.widget.MotionLayout$a */
    class C0319a implements Runnable {

        /* renamed from: a */
        final /* synthetic */ View f1364a;

        C0319a(MotionLayout motionLayout, View view) {
            this.f1364a = view;
        }

        public void run() {
            this.f1364a.setNestedScrollingEnabled(true);
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.MotionLayout$b */
    class C0320b extends C0360m {

        /* renamed from: a */
        float f1365a = 0.0f;

        /* renamed from: b */
        float f1366b = 0.0f;

        /* renamed from: c */
        float f1367c;

        C0320b() {
        }

        /* renamed from: a */
        public float mo1867a() {
            return MotionLayout.this.f1352u;
        }

        public float getInterpolation(float f) {
            float f2 = this.f1365a;
            if (f2 > 0.0f) {
                float f3 = this.f1367c;
                if (f2 / f3 < f) {
                    f = f2 / f3;
                }
                MotionLayout.this.f1352u = f2 - (f3 * f);
                return ((f2 * f) - (((f3 * f) * f) / 2.0f)) + this.f1366b;
            }
            float f4 = this.f1367c;
            if ((-f2) / f4 < f) {
                f = (-f2) / f4;
            }
            MotionLayout.this.f1352u = (f4 * f) + f2;
            return (((f4 * f) * f) / 2.0f) + (f2 * f) + this.f1366b;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.MotionLayout$c */
    private class C0321c {

        /* renamed from: a */
        float[] f1369a;

        /* renamed from: b */
        int[] f1370b;

        /* renamed from: c */
        float[] f1371c;

        /* renamed from: d */
        Path f1372d;

        /* renamed from: e */
        Paint f1373e;

        /* renamed from: f */
        Paint f1374f;

        /* renamed from: g */
        Paint f1375g;

        /* renamed from: h */
        Paint f1376h;

        /* renamed from: i */
        Paint f1377i;

        /* renamed from: j */
        private float[] f1378j;

        /* renamed from: k */
        DashPathEffect f1379k;

        /* renamed from: l */
        int f1380l;

        /* renamed from: m */
        Rect f1381m = new Rect();

        /* renamed from: n */
        int f1382n = 1;

        public C0321c() {
            Paint paint = new Paint();
            this.f1373e = paint;
            paint.setAntiAlias(true);
            this.f1373e.setColor(-21965);
            this.f1373e.setStrokeWidth(2.0f);
            this.f1373e.setStyle(Paint.Style.STROKE);
            Paint paint2 = new Paint();
            this.f1374f = paint2;
            paint2.setAntiAlias(true);
            this.f1374f.setColor(-2067046);
            this.f1374f.setStrokeWidth(2.0f);
            this.f1374f.setStyle(Paint.Style.STROKE);
            Paint paint3 = new Paint();
            this.f1375g = paint3;
            paint3.setAntiAlias(true);
            this.f1375g.setColor(-13391360);
            this.f1375g.setStrokeWidth(2.0f);
            this.f1375g.setStyle(Paint.Style.STROKE);
            Paint paint4 = new Paint();
            this.f1376h = paint4;
            paint4.setAntiAlias(true);
            this.f1376h.setColor(-13391360);
            this.f1376h.setTextSize(MotionLayout.this.getContext().getResources().getDisplayMetrics().density * 12.0f);
            this.f1378j = new float[8];
            Paint paint5 = new Paint();
            this.f1377i = paint5;
            paint5.setAntiAlias(true);
            DashPathEffect dashPathEffect = new DashPathEffect(new float[]{4.0f, 8.0f}, 0.0f);
            this.f1379k = dashPathEffect;
            this.f1375g.setPathEffect(dashPathEffect);
            this.f1371c = new float[100];
            this.f1370b = new int[50];
        }

        /* renamed from: c */
        private void m1513c(Canvas canvas) {
            float[] fArr = this.f1369a;
            float f = fArr[0];
            float f2 = fArr[1];
            float f3 = fArr[fArr.length - 2];
            float f4 = fArr[fArr.length - 1];
            canvas.drawLine(Math.min(f, f3), Math.max(f2, f4), Math.max(f, f3), Math.max(f2, f4), this.f1375g);
            canvas.drawLine(Math.min(f, f3), Math.min(f2, f4), Math.min(f, f3), Math.max(f2, f4), this.f1375g);
        }

        /* renamed from: d */
        private void m1514d(Canvas canvas, float f, float f2) {
            Canvas canvas2 = canvas;
            float[] fArr = this.f1369a;
            float f3 = fArr[0];
            float f4 = fArr[1];
            float f5 = fArr[fArr.length - 2];
            float f6 = fArr[fArr.length - 1];
            float min = Math.min(f3, f5);
            float max = Math.max(f4, f6);
            float min2 = f - Math.min(f3, f5);
            float max2 = Math.max(f4, f6) - f2;
            StringBuilder P = C4924a.m17863P(BuildConfig.FLAVOR);
            P.append(((float) ((int) (((double) ((min2 * 100.0f) / Math.abs(f5 - f3))) + 0.5d))) / 100.0f);
            String sb = P.toString();
            mo1871h(sb, this.f1376h);
            canvas2.drawText(sb, ((min2 / 2.0f) - ((float) (this.f1381m.width() / 2))) + min, f2 - 20.0f, this.f1376h);
            canvas.drawLine(f, f2, Math.min(f3, f5), f2, this.f1375g);
            StringBuilder P2 = C4924a.m17863P(BuildConfig.FLAVOR);
            P2.append(((float) ((int) (((double) ((max2 * 100.0f) / Math.abs(f6 - f4))) + 0.5d))) / 100.0f);
            String sb2 = P2.toString();
            mo1871h(sb2, this.f1376h);
            canvas2.drawText(sb2, f + 5.0f, max - ((max2 / 2.0f) - ((float) (this.f1381m.height() / 2))), this.f1376h);
            canvas.drawLine(f, f2, f, Math.max(f4, f6), this.f1375g);
        }

        /* renamed from: e */
        private void m1515e(Canvas canvas) {
            float[] fArr = this.f1369a;
            canvas.drawLine(fArr[0], fArr[1], fArr[fArr.length - 2], fArr[fArr.length - 1], this.f1375g);
        }

        /* renamed from: f */
        private void m1516f(Canvas canvas, float f, float f2) {
            float f3 = f;
            float f4 = f2;
            float[] fArr = this.f1369a;
            float f5 = fArr[0];
            float f6 = fArr[1];
            float f7 = fArr[fArr.length - 2];
            float f8 = fArr[fArr.length - 1];
            float hypot = (float) Math.hypot((double) (f5 - f7), (double) (f6 - f8));
            float f9 = f7 - f5;
            float f10 = f8 - f6;
            float f11 = (((f4 - f6) * f10) + ((f3 - f5) * f9)) / (hypot * hypot);
            float f12 = f5 + (f9 * f11);
            float f13 = f6 + (f11 * f10);
            Path path = new Path();
            path.moveTo(f, f4);
            path.lineTo(f12, f13);
            float hypot2 = (float) Math.hypot((double) (f12 - f3), (double) (f13 - f4));
            StringBuilder P = C4924a.m17863P(BuildConfig.FLAVOR);
            P.append(((float) ((int) ((hypot2 * 100.0f) / hypot))) / 100.0f);
            String sb = P.toString();
            mo1871h(sb, this.f1376h);
            canvas.drawTextOnPath(sb, path, (hypot2 / 2.0f) - ((float) (this.f1381m.width() / 2)), -20.0f, this.f1376h);
            canvas.drawLine(f3, f4, f12, f13, this.f1375g);
        }

        /* renamed from: g */
        private void m1517g(Canvas canvas, float f, float f2, int i, int i2) {
            Canvas canvas2 = canvas;
            StringBuilder P = C4924a.m17863P(BuildConfig.FLAVOR);
            P.append(((float) ((int) (((double) (((f - ((float) (i / 2))) * 100.0f) / ((float) (MotionLayout.this.getWidth() - i)))) + 0.5d))) / 100.0f);
            String sb = P.toString();
            mo1871h(sb, this.f1376h);
            canvas2.drawText(sb, ((f / 2.0f) - ((float) (this.f1381m.width() / 2))) + 0.0f, f2 - 20.0f, this.f1376h);
            canvas.drawLine(f, f2, Math.min(0.0f, 1.0f), f2, this.f1375g);
            StringBuilder P2 = C4924a.m17863P(BuildConfig.FLAVOR);
            P2.append(((float) ((int) (((double) (((f2 - ((float) (i2 / 2))) * 100.0f) / ((float) (MotionLayout.this.getHeight() - i2)))) + 0.5d))) / 100.0f);
            String sb2 = P2.toString();
            mo1871h(sb2, this.f1376h);
            canvas2.drawText(sb2, f + 5.0f, 0.0f - ((f2 / 2.0f) - ((float) (this.f1381m.height() / 2))), this.f1376h);
            canvas.drawLine(f, f2, f, Math.max(0.0f, 1.0f), this.f1375g);
        }

        /* renamed from: a */
        public void mo1869a(Canvas canvas, HashMap<View, C0359l> hashMap, int i, int i2) {
            if (hashMap != null && hashMap.size() != 0) {
                canvas.save();
                if (!MotionLayout.this.isInEditMode() && (i2 & 1) == 2) {
                    String str = MotionLayout.this.getContext().getResources().getResourceName(MotionLayout.this.f1358x) + ":" + MotionLayout.this.f1316F;
                    canvas.drawText(str, 10.0f, (float) (MotionLayout.this.getHeight() - 30), this.f1376h);
                    canvas.drawText(str, 11.0f, (float) (MotionLayout.this.getHeight() - 29), this.f1373e);
                }
                for (C0359l next : hashMap.values()) {
                    int h = next.mo1905h();
                    if (i2 > 0 && h == 0) {
                        h = 1;
                    }
                    if (h != 0) {
                        this.f1380l = next.mo1901c(this.f1371c, this.f1370b);
                        if (h >= 1) {
                            int i3 = i / 16;
                            float[] fArr = this.f1369a;
                            if (fArr == null || fArr.length != i3 * 2) {
                                this.f1369a = new float[(i3 * 2)];
                                this.f1372d = new Path();
                            }
                            int i4 = this.f1382n;
                            canvas.translate((float) i4, (float) i4);
                            this.f1373e.setColor(1996488704);
                            this.f1377i.setColor(1996488704);
                            this.f1374f.setColor(1996488704);
                            this.f1375g.setColor(1996488704);
                            next.mo1902d(this.f1369a, i3);
                            mo1870b(canvas, h, this.f1380l, next);
                            this.f1373e.setColor(-21965);
                            this.f1374f.setColor(-2067046);
                            this.f1377i.setColor(-2067046);
                            this.f1375g.setColor(-13391360);
                            int i5 = this.f1382n;
                            canvas.translate((float) (-i5), (float) (-i5));
                            mo1870b(canvas, h, this.f1380l, next);
                            if (h == 5) {
                                this.f1372d.reset();
                                for (int i6 = 0; i6 <= 50; i6++) {
                                    next.mo1903e(((float) i6) / ((float) 50), this.f1378j, 0);
                                    Path path = this.f1372d;
                                    float[] fArr2 = this.f1378j;
                                    path.moveTo(fArr2[0], fArr2[1]);
                                    Path path2 = this.f1372d;
                                    float[] fArr3 = this.f1378j;
                                    path2.lineTo(fArr3[2], fArr3[3]);
                                    Path path3 = this.f1372d;
                                    float[] fArr4 = this.f1378j;
                                    path3.lineTo(fArr4[4], fArr4[5]);
                                    Path path4 = this.f1372d;
                                    float[] fArr5 = this.f1378j;
                                    path4.lineTo(fArr5[6], fArr5[7]);
                                    this.f1372d.close();
                                }
                                this.f1373e.setColor(1140850688);
                                canvas.translate(2.0f, 2.0f);
                                canvas.drawPath(this.f1372d, this.f1373e);
                                canvas.translate(-2.0f, -2.0f);
                                this.f1373e.setColor(-65536);
                                canvas.drawPath(this.f1372d, this.f1373e);
                            }
                        }
                    }
                }
                canvas.restore();
            }
        }

        /* renamed from: b */
        public void mo1870b(Canvas canvas, int i, int i2, C0359l lVar) {
            int i3;
            int i4;
            int i5;
            float f;
            float f2;
            Canvas canvas2 = canvas;
            int i6 = i;
            C0359l lVar2 = lVar;
            if (i6 == 4) {
                boolean z = false;
                boolean z2 = false;
                for (int i7 = 0; i7 < this.f1380l; i7++) {
                    int[] iArr = this.f1370b;
                    if (iArr[i7] == 1) {
                        z = true;
                    }
                    if (iArr[i7] == 2) {
                        z2 = true;
                    }
                }
                if (z) {
                    m1515e(canvas);
                }
                if (z2) {
                    m1513c(canvas);
                }
            }
            if (i6 == 2) {
                m1515e(canvas);
            }
            if (i6 == 3) {
                m1513c(canvas);
            }
            canvas2.drawLines(this.f1369a, this.f1373e);
            View view = lVar2.f1524a;
            if (view != null) {
                i4 = view.getWidth();
                i3 = lVar2.f1524a.getHeight();
            } else {
                i4 = 0;
                i3 = 0;
            }
            int i8 = 1;
            while (i8 < i2 - 1) {
                if (i6 == 4 && this.f1370b[i8 - 1] == 0) {
                    i5 = i8;
                } else {
                    float[] fArr = this.f1371c;
                    int i9 = i8 * 2;
                    float f3 = fArr[i9];
                    float f4 = fArr[i9 + 1];
                    this.f1372d.reset();
                    this.f1372d.moveTo(f3, f4 + 10.0f);
                    this.f1372d.lineTo(f3 + 10.0f, f4);
                    this.f1372d.lineTo(f3, f4 - 10.0f);
                    this.f1372d.lineTo(f3 - 10.0f, f4);
                    this.f1372d.close();
                    int i10 = i8 - 1;
                    lVar2.mo1908k(i10);
                    if (i6 == 4) {
                        int[] iArr2 = this.f1370b;
                        if (iArr2[i10] == 1) {
                            m1516f(canvas2, f3 - 0.0f, f4 - 0.0f);
                        } else if (iArr2[i10] == 2) {
                            m1514d(canvas2, f3 - 0.0f, f4 - 0.0f);
                        } else if (iArr2[i10] == 3) {
                            f = f4;
                            f2 = f3;
                            i5 = i8;
                            m1517g(canvas, f3 - 0.0f, f4 - 0.0f, i4, i3);
                            canvas2.drawPath(this.f1372d, this.f1377i);
                        }
                        f = f4;
                        f2 = f3;
                        i5 = i8;
                        canvas2.drawPath(this.f1372d, this.f1377i);
                    } else {
                        f = f4;
                        f2 = f3;
                        i5 = i8;
                    }
                    if (i6 == 2) {
                        m1516f(canvas2, f2 - 0.0f, f - 0.0f);
                    }
                    if (i6 == 3) {
                        m1514d(canvas2, f2 - 0.0f, f - 0.0f);
                    }
                    if (i6 == 6) {
                        m1517g(canvas, f2 - 0.0f, f - 0.0f, i4, i3);
                    }
                    canvas2.drawPath(this.f1372d, this.f1377i);
                }
                i8 = i5 + 1;
            }
            float[] fArr2 = this.f1369a;
            if (fArr2.length > 1) {
                canvas2.drawCircle(fArr2[0], fArr2[1], 8.0f, this.f1374f);
                float[] fArr3 = this.f1369a;
                canvas2.drawCircle(fArr3[fArr3.length - 2], fArr3[fArr3.length - 1], 8.0f, this.f1374f);
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: h */
        public void mo1871h(String str, Paint paint) {
            paint.getTextBounds(str, 0, str.length(), this.f1381m);
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.MotionLayout$d */
    class C0322d {

        /* renamed from: a */
        C4664f f1384a = new C4664f();

        /* renamed from: b */
        C4664f f1385b = new C4664f();

        /* renamed from: c */
        C0411c f1386c = null;

        /* renamed from: d */
        C0411c f1387d = null;

        /* renamed from: e */
        int f1388e;

        /* renamed from: f */
        int f1389f;

        C0322d() {
        }

        /* renamed from: f */
        private void m1521f(C4664f fVar, C0411c cVar) {
            SparseArray sparseArray = new SparseArray();
            Constraints.LayoutParams layoutParams = new Constraints.LayoutParams(-2, -2);
            sparseArray.clear();
            sparseArray.put(0, fVar);
            sparseArray.put(MotionLayout.this.getId(), fVar);
            Iterator<C4662e> it = fVar.f17032C0.iterator();
            while (it.hasNext()) {
                C4662e next = it.next();
                sparseArray.put(((View) next.mo21644p()).getId(), next);
            }
            Iterator<C4662e> it2 = fVar.f17032C0.iterator();
            while (it2.hasNext()) {
                C4662e next2 = it2.next();
                View view = (View) next2.mo21644p();
                cVar.mo2067f(view.getId(), layoutParams);
                next2.mo21641n0(cVar.mo2076r(view.getId()));
                next2.mo21619Y(cVar.mo2071m(view.getId()));
                if (view instanceof ConstraintHelper) {
                    cVar.mo2065d((ConstraintHelper) view, next2, layoutParams, sparseArray);
                    if (view instanceof Barrier) {
                        ((Barrier) view).mo2012v();
                    }
                }
                layoutParams.resolveLayoutDirection(MotionLayout.this.getLayoutDirection());
                MotionLayout.this.mo2015f(false, view, next2, layoutParams, sparseArray);
                next2.mo21639m0(cVar.mo2075q(view.getId()) == 1 ? view.getVisibility() : cVar.mo2074p(view.getId()));
            }
            Iterator<C4662e> it3 = fVar.f17032C0.iterator();
            while (it3.hasNext()) {
                C4662e next3 = it3.next();
                if (next3 instanceof C4671l) {
                    C4668i iVar = (C4668i) next3;
                    ((ConstraintHelper) next3.mo21644p()).mo2010t(iVar, sparseArray);
                    C4671l lVar = (C4671l) iVar;
                    for (int i = 0; i < lVar.f17019D0; i++) {
                        C4662e eVar = lVar.f17018C0[i];
                    }
                }
            }
        }

        /* renamed from: a */
        public void mo1872a() {
            int childCount = MotionLayout.this.getChildCount();
            MotionLayout.this.f1308B.clear();
            for (int i = 0; i < childCount; i++) {
                View childAt = MotionLayout.this.getChildAt(i);
                MotionLayout.this.f1308B.put(childAt, new C0359l(childAt));
            }
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt2 = MotionLayout.this.getChildAt(i2);
                C0359l lVar = MotionLayout.this.f1308B.get(childAt2);
                if (lVar != null) {
                    if (this.f1386c != null) {
                        C4662e c = mo1874c(this.f1384a, childAt2);
                        if (c != null) {
                            lVar.mo1914r(c, this.f1386c);
                        } else if (MotionLayout.this.f1324M != 0) {
                            Log.e("MotionLayout", C4567a.m16426a() + "no widget for  " + C4567a.m16428c(childAt2) + " (" + childAt2.getClass().getName() + ")");
                        }
                    }
                    if (this.f1387d != null) {
                        C4662e c2 = mo1874c(this.f1385b, childAt2);
                        if (c2 != null) {
                            lVar.mo1911o(c2, this.f1387d);
                        } else if (MotionLayout.this.f1324M != 0) {
                            Log.e("MotionLayout", C4567a.m16426a() + "no widget for  " + C4567a.m16428c(childAt2) + " (" + childAt2.getClass().getName() + ")");
                        }
                    }
                }
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo1873b(C4664f fVar, C4664f fVar2) {
            ArrayList<C4662e> arrayList = fVar.f17032C0;
            HashMap hashMap = new HashMap();
            hashMap.put(fVar, fVar2);
            fVar2.f17032C0.clear();
            fVar2.mo21574j(fVar, hashMap);
            Iterator<C4662e> it = arrayList.iterator();
            while (it.hasNext()) {
                C4662e next = it.next();
                C4662e aVar = next instanceof C4657a ? new C4657a() : next instanceof C4667h ? new C4667h() : next instanceof C4665g ? new C4665g() : next instanceof C4668i ? new C4669j() : new C4662e();
                fVar2.mo21728a(aVar);
                hashMap.put(next, aVar);
            }
            Iterator<C4662e> it2 = arrayList.iterator();
            while (it2.hasNext()) {
                C4662e next2 = it2.next();
                ((C4662e) hashMap.get(next2)).mo21574j(next2, hashMap);
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: c */
        public C4662e mo1874c(C4664f fVar, View view) {
            if (fVar.mo21644p() == view) {
                return fVar;
            }
            ArrayList<C4662e> arrayList = fVar.f17032C0;
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                C4662e eVar = arrayList.get(i);
                if (eVar.mo21644p() == view) {
                    return eVar;
                }
            }
            return null;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: d */
        public void mo1875d(C0411c cVar, C0411c cVar2) {
            C4662e.C4663a aVar = C4662e.C4663a.WRAP_CONTENT;
            this.f1386c = cVar;
            this.f1387d = cVar2;
            this.f1384a = new C4664f();
            this.f1385b = new C4664f();
            this.f1384a.mo21659B0(MotionLayout.this.f1761c.mo21666v0());
            this.f1385b.mo21659B0(MotionLayout.this.f1761c.mo21666v0());
            this.f1384a.f17032C0.clear();
            this.f1385b.f17032C0.clear();
            mo1873b(MotionLayout.this.f1761c, this.f1384a);
            mo1873b(MotionLayout.this.f1761c, this.f1385b);
            if (((double) MotionLayout.this.f1316F) > 0.5d) {
                if (cVar != null) {
                    m1521f(this.f1384a, cVar);
                }
                m1521f(this.f1385b, cVar2);
            } else {
                m1521f(this.f1385b, cVar2);
                if (cVar != null) {
                    m1521f(this.f1384a, cVar);
                }
            }
            this.f1384a.mo21661D0(MotionLayout.this.mo2026s());
            this.f1384a.mo21662E0();
            this.f1385b.mo21661D0(MotionLayout.this.mo2026s());
            this.f1385b.mo21662E0();
            ViewGroup.LayoutParams layoutParams = MotionLayout.this.getLayoutParams();
            if (layoutParams != null) {
                if (layoutParams.width == -2) {
                    this.f1384a.f16884L[0] = aVar;
                    this.f1385b.f16884L[0] = aVar;
                }
                if (layoutParams.height == -2) {
                    this.f1384a.f16884L[1] = aVar;
                    this.f1385b.f16884L[1] = aVar;
                }
            }
        }

        /* renamed from: e */
        public void mo1876e() {
            int R = MotionLayout.this.f1360y;
            int A = MotionLayout.this.f1362z;
            int mode = View.MeasureSpec.getMode(R);
            int mode2 = View.MeasureSpec.getMode(A);
            MotionLayout motionLayout = MotionLayout.this;
            motionLayout.f1353u0 = mode;
            motionLayout.f1355v0 = mode2;
            int i = motionLayout.mo2022i();
            MotionLayout motionLayout2 = MotionLayout.this;
            if (motionLayout2.f1356w == motionLayout2.mo1839Z()) {
                MotionLayout.this.mo2030v(this.f1385b, i, R, A);
                if (this.f1386c != null) {
                    MotionLayout.this.mo2030v(this.f1384a, i, R, A);
                }
            } else {
                if (this.f1386c != null) {
                    MotionLayout.this.mo2030v(this.f1384a, i, R, A);
                }
                MotionLayout.this.mo2030v(this.f1385b, i, R, A);
            }
            int i2 = 0;
            boolean z = true;
            if (((MotionLayout.this.getParent() instanceof MotionLayout) && mode == 1073741824 && mode2 == 1073741824) ? false : true) {
                MotionLayout motionLayout3 = MotionLayout.this;
                motionLayout3.f1353u0 = mode;
                motionLayout3.f1355v0 = mode2;
                if (motionLayout3.f1356w == motionLayout3.mo1839Z()) {
                    MotionLayout.this.mo2030v(this.f1385b, i, R, A);
                    if (this.f1386c != null) {
                        MotionLayout.this.mo2030v(this.f1384a, i, R, A);
                    }
                } else {
                    if (this.f1386c != null) {
                        MotionLayout.this.mo2030v(this.f1384a, i, R, A);
                    }
                    MotionLayout.this.mo2030v(this.f1385b, i, R, A);
                }
                MotionLayout.this.f1346q0 = this.f1384a.mo21604I();
                MotionLayout.this.f1347r0 = this.f1384a.mo21651t();
                MotionLayout.this.f1349s0 = this.f1385b.mo21604I();
                MotionLayout.this.f1351t0 = this.f1385b.mo21651t();
                MotionLayout motionLayout4 = MotionLayout.this;
                motionLayout4.f1345p0 = (motionLayout4.f1346q0 == motionLayout4.f1349s0 && motionLayout4.f1347r0 == motionLayout4.f1351t0) ? false : true;
            }
            MotionLayout motionLayout5 = MotionLayout.this;
            int i3 = motionLayout5.f1346q0;
            int i4 = motionLayout5.f1347r0;
            int i5 = motionLayout5.f1353u0;
            if (i5 == Integer.MIN_VALUE || i5 == 0) {
                i3 = (int) ((motionLayout5.f1357w0 * ((float) (motionLayout5.f1349s0 - i3))) + ((float) i3));
            }
            int i6 = i3;
            int i7 = motionLayout5.f1355v0;
            MotionLayout.this.mo2029u(R, A, i6, (i7 == Integer.MIN_VALUE || i7 == 0) ? (int) ((motionLayout5.f1357w0 * ((float) (motionLayout5.f1351t0 - i4))) + ((float) i4)) : i4, this.f1384a.mo21670z0() || this.f1385b.mo21670z0(), this.f1384a.mo21668x0() || this.f1385b.mo21668x0());
            MotionLayout motionLayout6 = MotionLayout.this;
            int childCount = motionLayout6.getChildCount();
            motionLayout6.f1309B0.mo1872a();
            motionLayout6.f1321J = true;
            int width = motionLayout6.getWidth();
            int height = motionLayout6.getHeight();
            C0363p.C0365b bVar = motionLayout6.f1348s.f1617c;
            int k = bVar != null ? bVar.f1648p : -1;
            if (k != -1) {
                for (int i8 = 0; i8 < childCount; i8++) {
                    C0359l lVar = motionLayout6.f1308B.get(motionLayout6.getChildAt(i8));
                    if (lVar != null) {
                        lVar.mo1912p(k);
                    }
                }
            }
            for (int i9 = 0; i9 < childCount; i9++) {
                C0359l lVar2 = motionLayout6.f1308B.get(motionLayout6.getChildAt(i9));
                if (lVar2 != null) {
                    motionLayout6.f1348s.mo1930m(lVar2);
                    lVar2.mo1915s(width, height, System.nanoTime());
                }
            }
            C0363p.C0365b bVar2 = motionLayout6.f1348s.f1617c;
            float l = bVar2 != null ? bVar2.f1641i : 0.0f;
            if (l != 0.0f) {
                boolean z2 = ((double) l) < 0.0d;
                float abs = Math.abs(l);
                float f = -3.4028235E38f;
                float f2 = Float.MAX_VALUE;
                int i10 = 0;
                float f3 = Float.MAX_VALUE;
                float f4 = -3.4028235E38f;
                while (true) {
                    if (i10 >= childCount) {
                        z = false;
                        break;
                    }
                    C0359l lVar3 = motionLayout6.f1308B.get(motionLayout6.getChildAt(i10));
                    if (!Float.isNaN(lVar3.f1533j)) {
                        break;
                    }
                    float i11 = lVar3.mo1906i();
                    float j = lVar3.mo1907j();
                    float f5 = z2 ? j - i11 : j + i11;
                    f3 = Math.min(f3, f5);
                    f4 = Math.max(f4, f5);
                    i10++;
                }
                if (z) {
                    for (int i12 = 0; i12 < childCount; i12++) {
                        C0359l lVar4 = motionLayout6.f1308B.get(motionLayout6.getChildAt(i12));
                        if (!Float.isNaN(lVar4.f1533j)) {
                            f2 = Math.min(f2, lVar4.f1533j);
                            f = Math.max(f, lVar4.f1533j);
                        }
                    }
                    while (i2 < childCount) {
                        C0359l lVar5 = motionLayout6.f1308B.get(motionLayout6.getChildAt(i2));
                        if (!Float.isNaN(lVar5.f1533j)) {
                            lVar5.f1535l = 1.0f / (1.0f - abs);
                            float f6 = lVar5.f1533j;
                            lVar5.f1534k = abs - (z2 ? ((f - f6) / (f - f2)) * abs : ((f6 - f2) * abs) / (f - f2));
                        }
                        i2++;
                    }
                    return;
                }
                while (i2 < childCount) {
                    C0359l lVar6 = motionLayout6.f1308B.get(motionLayout6.getChildAt(i2));
                    float i13 = lVar6.mo1906i();
                    float j2 = lVar6.mo1907j();
                    float f7 = z2 ? j2 - i13 : j2 + i13;
                    lVar6.f1535l = 1.0f / (1.0f - abs);
                    lVar6.f1534k = abs - (((f7 - f3) * abs) / (f4 - f3));
                    i2++;
                }
            }
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.MotionLayout$e */
    protected interface C0323e {
    }

    /* renamed from: androidx.constraintlayout.motion.widget.MotionLayout$f */
    private static class C0324f implements C0323e {

        /* renamed from: a */
        private static C0324f f1391a = new C0324f();

        /* renamed from: b */
        VelocityTracker f1392b;

        private C0324f() {
        }

        /* renamed from: a */
        public static C0324f m1527a() {
            f1391a.f1392b = VelocityTracker.obtain();
            return f1391a;
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.MotionLayout$g */
    class C0325g {

        /* renamed from: a */
        float f1393a = Float.NaN;

        /* renamed from: b */
        float f1394b = Float.NaN;

        /* renamed from: c */
        int f1395c = -1;

        /* renamed from: d */
        int f1396d = -1;

        C0325g() {
        }
    }

    /* renamed from: androidx.constraintlayout.motion.widget.MotionLayout$h */
    public interface C0326h {
        /* renamed from: a */
        void mo1827a(MotionLayout motionLayout, int i, int i2, float f);

        /* renamed from: b */
        void mo1828b(MotionLayout motionLayout, int i, int i2);

        /* renamed from: c */
        void mo1829c(MotionLayout motionLayout, int i, boolean z, float f);

        /* renamed from: d */
        void mo1830d(MotionLayout motionLayout, int i);
    }

    public MotionLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m1483c0(attributeSet);
    }

    public MotionLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        m1483c0(attributeSet);
    }

    /* renamed from: U */
    private void m1481U() {
        ArrayList<C0326h> arrayList;
        ArrayList<C0326h> arrayList2 = this.f1339j0;
        if (arrayList2 != null && !arrayList2.isEmpty() && this.f1344o0 != this.f1314E) {
            if (!(this.f1343n0 == -1 || (arrayList = this.f1339j0) == null)) {
                Iterator<C0326h> it = arrayList.iterator();
                while (it.hasNext()) {
                    it.next().mo1828b(this, this.f1354v, this.f1358x);
                }
            }
            this.f1343n0 = -1;
            this.f1344o0 = this.f1314E;
            ArrayList<C0326h> arrayList3 = this.f1339j0;
            if (arrayList3 != null) {
                Iterator<C0326h> it2 = arrayList3.iterator();
                while (it2.hasNext()) {
                    it2.next().mo1827a(this, this.f1354v, this.f1358x, this.f1314E);
                }
            }
        }
    }

    /* renamed from: b0 */
    private boolean m1482b0(float f, float f2, View view, MotionEvent motionEvent) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                if (m1482b0(((float) view.getLeft()) + f, ((float) view.getTop()) + f2, viewGroup.getChildAt(i), motionEvent)) {
                    return true;
                }
            }
        }
        this.f1313D0.set(((float) view.getLeft()) + f, ((float) view.getTop()) + f2, f + ((float) view.getRight()), f2 + ((float) view.getBottom()));
        if (motionEvent.getAction() == 0) {
            return this.f1313D0.contains(motionEvent.getX(), motionEvent.getY()) && view.onTouchEvent(motionEvent);
        }
        if (view.onTouchEvent(motionEvent)) {
            return true;
        }
    }

    /* renamed from: c0 */
    private void m1483c0(AttributeSet attributeSet) {
        C0363p pVar;
        f1305r = isInEditMode();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C0418e.f2006p);
            int indexCount = obtainStyledAttributes.getIndexCount();
            boolean z = true;
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                int i2 = 2;
                if (index == 2) {
                    this.f1348s = new C0363p(getContext(), this, obtainStyledAttributes.getResourceId(index, -1));
                } else if (index == 1) {
                    this.f1356w = obtainStyledAttributes.getResourceId(index, -1);
                } else if (index == 4) {
                    this.f1319H = obtainStyledAttributes.getFloat(index, 0.0f);
                    this.f1321J = true;
                } else if (index == 0) {
                    z = obtainStyledAttributes.getBoolean(index, z);
                } else if (index == 5) {
                    if (this.f1324M == 0) {
                        if (!obtainStyledAttributes.getBoolean(index, false)) {
                            i2 = 0;
                        }
                        this.f1324M = i2;
                    }
                } else if (index == 3) {
                    this.f1324M = obtainStyledAttributes.getInt(index, 0);
                }
            }
            obtainStyledAttributes.recycle();
            if (this.f1348s == null) {
                Log.e("MotionLayout", "WARNING NO app:layoutDescription tag");
            }
            if (!z) {
                this.f1348s = null;
            }
        }
        if (this.f1324M != 0) {
            C0363p pVar2 = this.f1348s;
            if (pVar2 == null) {
                Log.e("MotionLayout", "CHECK: motion scene not set! set \"app:layoutDescription=\"@xml/file\"");
            } else {
                int p = pVar2.mo1933p();
                C0363p pVar3 = this.f1348s;
                C0411c g = pVar3.mo1925g(pVar3.mo1933p());
                String b = C4567a.m16427b(getContext(), p);
                int childCount = getChildCount();
                for (int i3 = 0; i3 < childCount; i3++) {
                    View childAt = getChildAt(i3);
                    int id = childAt.getId();
                    if (id == -1) {
                        StringBuilder U = C4924a.m17868U("CHECK: ", b, " ALL VIEWS SHOULD HAVE ID's ");
                        U.append(childAt.getClass().getName());
                        U.append(" does not!");
                        Log.w("MotionLayout", U.toString());
                    }
                    if (g.mo2070l(id) == null) {
                        StringBuilder U2 = C4924a.m17868U("CHECK: ", b, " NO CONSTRAINTS for ");
                        U2.append(C4567a.m16428c(childAt));
                        Log.w("MotionLayout", U2.toString());
                    }
                }
                int[] n = g.mo2072n();
                for (int i4 = 0; i4 < n.length; i4++) {
                    int i5 = n[i4];
                    String b2 = C4567a.m16427b(getContext(), i5);
                    if (findViewById(n[i4]) == null) {
                        Log.w("MotionLayout", "CHECK: " + b + " NO View matches id " + b2);
                    }
                    if (g.mo2071m(i5) == -1) {
                        Log.w("MotionLayout", "CHECK: " + b + "(" + b2 + ") no LAYOUT_HEIGHT");
                    }
                    if (g.mo2076r(i5) == -1) {
                        Log.w("MotionLayout", "CHECK: " + b + "(" + b2 + ") no LAYOUT_HEIGHT");
                    }
                }
                SparseIntArray sparseIntArray = new SparseIntArray();
                SparseIntArray sparseIntArray2 = new SparseIntArray();
                Iterator<C0363p.C0365b> it = this.f1348s.mo1926h().iterator();
                while (it.hasNext()) {
                    C0363p.C0365b next = it.next();
                    if (next == this.f1348s.f1617c) {
                        Log.v("MotionLayout", "CHECK: CURRENT");
                    }
                    StringBuilder P = C4924a.m17863P("CHECK: transition = ");
                    P.append(next.mo1943t(getContext()));
                    Log.v("MotionLayout", P.toString());
                    Log.v("MotionLayout", "CHECK: transition.setDuration = " + next.mo1944u());
                    if (next.mo1947x() == next.mo1945v()) {
                        Log.e("MotionLayout", "CHECK: start and end constraint set should not be the same!");
                    }
                    int x = next.mo1947x();
                    int v = next.mo1945v();
                    String b3 = C4567a.m16427b(getContext(), x);
                    String b4 = C4567a.m16427b(getContext(), v);
                    if (sparseIntArray.get(x) == v) {
                        Log.e("MotionLayout", "CHECK: two transitions with the same start and end " + b3 + "->" + b4);
                    }
                    if (sparseIntArray2.get(v) == x) {
                        Log.e("MotionLayout", "CHECK: you can't have reverse transitions" + b3 + "->" + b4);
                    }
                    sparseIntArray.put(x, v);
                    sparseIntArray2.put(v, x);
                    if (this.f1348s.mo1925g(x) == null) {
                        Log.e("MotionLayout", " no such constraintSetStart " + b3);
                    }
                    if (this.f1348s.mo1925g(v) == null) {
                        Log.e("MotionLayout", " no such constraintSetEnd " + b3);
                    }
                }
            }
        }
        if (this.f1356w == -1 && (pVar = this.f1348s) != null) {
            this.f1356w = pVar.mo1933p();
            this.f1354v = this.f1348s.mo1933p();
            this.f1358x = this.f1348s.mo1928j();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0023, code lost:
        r0 = r2.f1348s;
     */
    /* renamed from: e0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m1484e0() {
        /*
            r2 = this;
            androidx.constraintlayout.motion.widget.p r0 = r2.f1348s
            if (r0 != 0) goto L_0x0005
            return
        L_0x0005:
            int r1 = r2.f1356w
            boolean r0 = r0.mo1924f(r2, r1)
            if (r0 == 0) goto L_0x0011
            r2.requestLayout()
            return
        L_0x0011:
            int r0 = r2.f1356w
            r1 = -1
            if (r0 == r1) goto L_0x001b
            androidx.constraintlayout.motion.widget.p r1 = r2.f1348s
            r1.mo1923e(r2, r0)
        L_0x001b:
            androidx.constraintlayout.motion.widget.p r0 = r2.f1348s
            boolean r0 = r0.mo1939y()
            if (r0 == 0) goto L_0x0038
            androidx.constraintlayout.motion.widget.p r0 = r2.f1348s
            androidx.constraintlayout.motion.widget.p$b r1 = r0.f1617c
            if (r1 == 0) goto L_0x0038
            androidx.constraintlayout.motion.widget.s r1 = r1.f1644l
            if (r1 == 0) goto L_0x0038
            androidx.constraintlayout.motion.widget.p$b r0 = r0.f1617c
            androidx.constraintlayout.motion.widget.s r0 = r0.f1644l
            r0.mo1982p()
        L_0x0038:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.m1484e0():void");
    }

    /* renamed from: f0 */
    private void m1485f0() {
        ArrayList<C0326h> arrayList = this.f1339j0;
        if (arrayList != null && !arrayList.isEmpty()) {
            Iterator<Integer> it = this.f1317F0.iterator();
            while (it.hasNext()) {
                Integer next = it.next();
                ArrayList<C0326h> arrayList2 = this.f1339j0;
                if (arrayList2 != null) {
                    Iterator<C0326h> it2 = arrayList2.iterator();
                    while (it2.hasNext()) {
                        it2.next().mo1830d(this, next.intValue());
                    }
                }
            }
            this.f1317F0.clear();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: S */
    public void mo1833S(float f) {
        C0363p pVar = this.f1348s;
        if (pVar != null) {
            float f2 = this.f1316F;
            float f3 = this.f1314E;
            if (f2 != f3 && this.f1320I) {
                this.f1316F = f3;
            }
            float f4 = this.f1316F;
            if (f4 != f) {
                this.f1326O = false;
                this.f1319H = f;
                this.f1312D = ((float) pVar.mo1927i()) / 1000.0f;
                mo1844h0(this.f1319H);
                this.f1350t = this.f1348s.mo1929l();
                this.f1320I = false;
                this.f1310C = System.nanoTime();
                this.f1321J = true;
                this.f1314E = f4;
                this.f1316F = f4;
                invalidate();
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:137:0x0206, code lost:
        if (r1 != r2) goto L_0x0216;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:141:0x0212, code lost:
        if (r1 != r2) goto L_0x0216;
     */
    /* renamed from: T */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1834T(boolean r23) {
        /*
            r22 = this;
            r0 = r22
            long r1 = r0.f1318G
            r3 = -1
            int r5 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r5 != 0) goto L_0x0010
            long r1 = java.lang.System.nanoTime()
            r0.f1318G = r1
        L_0x0010:
            float r1 = r0.f1316F
            r2 = -1
            r3 = 0
            r4 = 1065353216(0x3f800000, float:1.0)
            int r5 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r5 <= 0) goto L_0x0020
            int r5 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r5 >= 0) goto L_0x0020
            r0.f1356w = r2
        L_0x0020:
            boolean r5 = r0.f1336g0
            r6 = 0
            r7 = 1
            if (r5 != 0) goto L_0x0032
            boolean r5 = r0.f1321J
            if (r5 == 0) goto L_0x01fc
            if (r23 != 0) goto L_0x0032
            float r5 = r0.f1319H
            int r5 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1))
            if (r5 == 0) goto L_0x01fc
        L_0x0032:
            float r5 = r0.f1319H
            float r5 = r5 - r1
            float r1 = java.lang.Math.signum(r5)
            long r8 = java.lang.System.nanoTime()
            android.view.animation.Interpolator r5 = r0.f1350t
            boolean r10 = r5 instanceof androidx.constraintlayout.motion.widget.C0360m
            r11 = 814313567(0x3089705f, float:1.0E-9)
            if (r10 != 0) goto L_0x0055
            long r12 = r0.f1318G
            long r12 = r8 - r12
            float r10 = (float) r12
            float r10 = r10 * r1
            float r10 = r10 * r11
            float r12 = r0.f1312D
            float r10 = r10 / r12
            r0.f1352u = r10
            goto L_0x0056
        L_0x0055:
            r10 = 0
        L_0x0056:
            float r12 = r0.f1316F
            float r12 = r12 + r10
            boolean r13 = r0.f1320I
            if (r13 == 0) goto L_0x005f
            float r12 = r0.f1319H
        L_0x005f:
            int r13 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r13 <= 0) goto L_0x0069
            float r14 = r0.f1319H
            int r14 = (r12 > r14 ? 1 : (r12 == r14 ? 0 : -1))
            if (r14 >= 0) goto L_0x0073
        L_0x0069:
            int r14 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r14 > 0) goto L_0x0079
            float r14 = r0.f1319H
            int r14 = (r12 > r14 ? 1 : (r12 == r14 ? 0 : -1))
            if (r14 > 0) goto L_0x0079
        L_0x0073:
            float r12 = r0.f1319H
            r0.f1321J = r6
            r14 = 1
            goto L_0x007a
        L_0x0079:
            r14 = 0
        L_0x007a:
            r0.f1316F = r12
            r0.f1314E = r12
            r0.f1318G = r8
            r15 = 925353388(0x3727c5ac, float:1.0E-5)
            if (r5 == 0) goto L_0x00f2
            if (r14 != 0) goto L_0x00f2
            boolean r14 = r0.f1326O
            if (r14 == 0) goto L_0x00d5
            long r2 = r0.f1310C
            long r2 = r8 - r2
            float r2 = (float) r2
            float r2 = r2 * r11
            float r2 = r5.getInterpolation(r2)
            r0.f1316F = r2
            r0.f1318G = r8
            android.view.animation.Interpolator r3 = r0.f1350t
            boolean r5 = r3 instanceof androidx.constraintlayout.motion.widget.C0360m
            if (r5 == 0) goto L_0x00d3
            androidx.constraintlayout.motion.widget.m r3 = (androidx.constraintlayout.motion.widget.C0360m) r3
            float r3 = r3.mo1867a()
            r0.f1352u = r3
            float r5 = java.lang.Math.abs(r3)
            float r8 = r0.f1312D
            float r5 = r5 * r8
            int r5 = (r5 > r15 ? 1 : (r5 == r15 ? 0 : -1))
            if (r5 > 0) goto L_0x00b6
            r0.f1321J = r6
        L_0x00b6:
            r5 = 0
            int r8 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r8 <= 0) goto L_0x00c5
            int r8 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r8 < 0) goto L_0x00c5
            r0.f1316F = r4
            r0.f1321J = r6
            r2 = 1065353216(0x3f800000, float:1.0)
        L_0x00c5:
            int r3 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r3 >= 0) goto L_0x00d3
            int r3 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r3 > 0) goto L_0x00d3
            r0.f1316F = r5
            r0.f1321J = r6
            r12 = 0
            goto L_0x00f2
        L_0x00d3:
            r12 = r2
            goto L_0x00f2
        L_0x00d5:
            float r2 = r5.getInterpolation(r12)
            android.view.animation.Interpolator r3 = r0.f1350t
            boolean r5 = r3 instanceof androidx.constraintlayout.motion.widget.C0360m
            if (r5 == 0) goto L_0x00e6
            androidx.constraintlayout.motion.widget.m r3 = (androidx.constraintlayout.motion.widget.C0360m) r3
            float r3 = r3.mo1867a()
            goto L_0x00ef
        L_0x00e6:
            float r12 = r12 + r10
            float r3 = r3.getInterpolation(r12)
            float r3 = r3 - r2
            float r3 = r3 * r1
            float r3 = r3 / r10
        L_0x00ef:
            r0.f1352u = r3
            goto L_0x00d3
        L_0x00f2:
            float r2 = r0.f1352u
            float r2 = java.lang.Math.abs(r2)
            int r2 = (r2 > r15 ? 1 : (r2 == r15 ? 0 : -1))
            if (r2 <= 0) goto L_0x0100
            r2 = 3
            r0.mo1848k0(r2)
        L_0x0100:
            if (r13 <= 0) goto L_0x0108
            float r2 = r0.f1319H
            int r2 = (r12 > r2 ? 1 : (r12 == r2 ? 0 : -1))
            if (r2 >= 0) goto L_0x0113
        L_0x0108:
            r2 = 0
            int r3 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r3 > 0) goto L_0x0117
            float r2 = r0.f1319H
            int r2 = (r12 > r2 ? 1 : (r12 == r2 ? 0 : -1))
            if (r2 > 0) goto L_0x0117
        L_0x0113:
            float r12 = r0.f1319H
            r0.f1321J = r6
        L_0x0117:
            r2 = 4
            int r3 = (r12 > r4 ? 1 : (r12 == r4 ? 0 : -1))
            if (r3 >= 0) goto L_0x0121
            r5 = 0
            int r8 = (r12 > r5 ? 1 : (r12 == r5 ? 0 : -1))
            if (r8 > 0) goto L_0x0126
        L_0x0121:
            r0.f1321J = r6
            r0.mo1848k0(r2)
        L_0x0126:
            int r5 = r22.getChildCount()
            r0.f1336g0 = r6
            long r8 = java.lang.System.nanoTime()
            r0.f1357w0 = r12
            r10 = 0
        L_0x0133:
            if (r10 >= r5) goto L_0x015c
            android.view.View r11 = r0.getChildAt(r10)
            java.util.HashMap<android.view.View, androidx.constraintlayout.motion.widget.l> r15 = r0.f1308B
            java.lang.Object r15 = r15.get(r11)
            r16 = r15
            androidx.constraintlayout.motion.widget.l r16 = (androidx.constraintlayout.motion.widget.C0359l) r16
            if (r16 == 0) goto L_0x0158
            boolean r15 = r0.f1336g0
            androidx.constraintlayout.motion.widget.c r6 = r0.f1359x0
            r17 = r11
            r18 = r12
            r19 = r8
            r21 = r6
            boolean r6 = r16.mo1910m(r17, r18, r19, r21)
            r6 = r6 | r15
            r0.f1336g0 = r6
        L_0x0158:
            int r10 = r10 + 1
            r6 = 0
            goto L_0x0133
        L_0x015c:
            if (r13 <= 0) goto L_0x0164
            float r5 = r0.f1319H
            int r5 = (r12 > r5 ? 1 : (r12 == r5 ? 0 : -1))
            if (r5 >= 0) goto L_0x016f
        L_0x0164:
            r5 = 0
            int r6 = (r1 > r5 ? 1 : (r1 == r5 ? 0 : -1))
            if (r6 > 0) goto L_0x0171
            float r5 = r0.f1319H
            int r5 = (r12 > r5 ? 1 : (r12 == r5 ? 0 : -1))
            if (r5 > 0) goto L_0x0171
        L_0x016f:
            r5 = 1
            goto L_0x0172
        L_0x0171:
            r5 = 0
        L_0x0172:
            boolean r6 = r0.f1336g0
            if (r6 != 0) goto L_0x017f
            boolean r6 = r0.f1321J
            if (r6 != 0) goto L_0x017f
            if (r5 == 0) goto L_0x017f
            r0.mo1848k0(r2)
        L_0x017f:
            boolean r6 = r0.f1345p0
            if (r6 == 0) goto L_0x0186
            r22.requestLayout()
        L_0x0186:
            boolean r6 = r0.f1336g0
            r5 = r5 ^ r7
            r5 = r5 | r6
            r0.f1336g0 = r5
            r5 = 0
            int r6 = (r12 > r5 ? 1 : (r12 == r5 ? 0 : -1))
            if (r6 > 0) goto L_0x01aa
            int r5 = r0.f1354v
            r6 = -1
            if (r5 == r6) goto L_0x01aa
            int r6 = r0.f1356w
            if (r6 == r5) goto L_0x01aa
            r0.f1356w = r5
            androidx.constraintlayout.motion.widget.p r6 = r0.f1348s
            androidx.constraintlayout.widget.c r5 = r6.mo1925g(r5)
            r5.mo2063b(r0)
            r0.mo1848k0(r2)
            r6 = 1
            goto L_0x01ab
        L_0x01aa:
            r6 = 0
        L_0x01ab:
            double r8 = (double) r12
            r10 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            int r5 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r5 < 0) goto L_0x01c7
            int r5 = r0.f1356w
            int r8 = r0.f1358x
            if (r5 == r8) goto L_0x01c7
            r0.f1356w = r8
            androidx.constraintlayout.motion.widget.p r5 = r0.f1348s
            androidx.constraintlayout.widget.c r5 = r5.mo1925g(r8)
            r5.mo2063b(r0)
            r0.mo1848k0(r2)
            r6 = 1
        L_0x01c7:
            boolean r5 = r0.f1336g0
            if (r5 != 0) goto L_0x01e1
            boolean r5 = r0.f1321J
            if (r5 == 0) goto L_0x01d0
            goto L_0x01e1
        L_0x01d0:
            if (r13 <= 0) goto L_0x01d4
            if (r3 == 0) goto L_0x01dd
        L_0x01d4:
            r5 = 0
            int r8 = (r1 > r5 ? 1 : (r1 == r5 ? 0 : -1))
            if (r8 >= 0) goto L_0x01e4
            int r8 = (r12 > r5 ? 1 : (r12 == r5 ? 0 : -1))
            if (r8 != 0) goto L_0x01e4
        L_0x01dd:
            r0.mo1848k0(r2)
            goto L_0x01e4
        L_0x01e1:
            r22.invalidate()
        L_0x01e4:
            boolean r2 = r0.f1336g0
            if (r2 != 0) goto L_0x01f0
            boolean r2 = r0.f1321J
            if (r2 == 0) goto L_0x01f0
            if (r13 <= 0) goto L_0x01f0
            if (r3 == 0) goto L_0x01f9
        L_0x01f0:
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 >= 0) goto L_0x01fc
            int r1 = (r12 > r2 ? 1 : (r12 == r2 ? 0 : -1))
            if (r1 != 0) goto L_0x01fc
        L_0x01f9:
            r22.m1484e0()
        L_0x01fc:
            float r1 = r0.f1316F
            int r2 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r2 < 0) goto L_0x0209
            int r1 = r0.f1356w
            int r2 = r0.f1358x
            if (r1 == r2) goto L_0x0215
            goto L_0x0216
        L_0x0209:
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 > 0) goto L_0x0219
            int r1 = r0.f1356w
            int r2 = r0.f1354v
            if (r1 == r2) goto L_0x0215
            goto L_0x0216
        L_0x0215:
            r7 = r6
        L_0x0216:
            r0.f1356w = r2
            r6 = r7
        L_0x0219:
            boolean r1 = r0.f1311C0
            r1 = r1 | r6
            r0.f1311C0 = r1
            if (r6 == 0) goto L_0x0227
            boolean r1 = r0.f1361y0
            if (r1 != 0) goto L_0x0227
            r22.requestLayout()
        L_0x0227:
            float r1 = r0.f1316F
            r0.f1314E = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.mo1834T(boolean):void");
    }

    /* access modifiers changed from: protected */
    /* renamed from: V */
    public void mo1835V() {
        int i;
        ArrayList<C0326h> arrayList = this.f1339j0;
        if (arrayList != null && !arrayList.isEmpty() && this.f1343n0 == -1) {
            this.f1343n0 = this.f1356w;
            if (!this.f1317F0.isEmpty()) {
                ArrayList<Integer> arrayList2 = this.f1317F0;
                i = arrayList2.get(arrayList2.size() - 1).intValue();
            } else {
                i = -1;
            }
            int i2 = this.f1356w;
            if (!(i == i2 || i2 == -1)) {
                this.f1317F0.add(Integer.valueOf(i2));
            }
        }
        m1485f0();
    }

    /* renamed from: W */
    public void mo1836W(int i, boolean z, float f) {
        ArrayList<C0326h> arrayList = this.f1339j0;
        if (arrayList != null) {
            Iterator<C0326h> it = arrayList.iterator();
            while (it.hasNext()) {
                it.next().mo1829c(this, i, z, f);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: X */
    public void mo1837X(int i, float f, float f2, float f3, float[] fArr) {
        HashMap<View, C0359l> hashMap = this.f1308B;
        View j = mo2023j(i);
        C0359l lVar = hashMap.get(j);
        if (lVar != null) {
            lVar.mo1904g(f, f2, f3, fArr);
            float y = j.getY();
            this.f1322K = f;
            this.f1323L = y;
            return;
        }
        C4924a.m17877b0("WARNING could not find view id ", j == null ? C4924a.m17900o(BuildConfig.FLAVOR, i) : j.getContext().getResources().getResourceName(i), "MotionLayout");
    }

    /* renamed from: Y */
    public int mo1838Y() {
        return this.f1358x;
    }

    /* renamed from: Z */
    public int mo1839Z() {
        return this.f1354v;
    }

    /* renamed from: a0 */
    public void mo1840a0(View view, float f, float f2, float[] fArr, int i) {
        float f3;
        float f4 = this.f1352u;
        float f5 = this.f1316F;
        if (this.f1350t != null) {
            float signum = Math.signum(this.f1319H - f5);
            float interpolation = this.f1350t.getInterpolation(this.f1316F + 1.0E-5f);
            float interpolation2 = this.f1350t.getInterpolation(this.f1316F);
            f4 = (((interpolation - interpolation2) / 1.0E-5f) * signum) / this.f1312D;
            f3 = interpolation2;
        } else {
            f3 = f5;
        }
        Interpolator interpolator = this.f1350t;
        if (interpolator instanceof C0360m) {
            f4 = ((C0360m) interpolator).mo1867a();
        }
        C0359l lVar = this.f1308B.get(view);
        if ((i & 1) == 0) {
            lVar.mo1909l(f3, view.getWidth(), view.getHeight(), f, f2, fArr);
        } else {
            lVar.mo1904g(f3, f, f2, fArr);
        }
        if (i < 2) {
            fArr[0] = fArr[0] * f4;
            fArr[1] = fArr[1] * f4;
        }
    }

    /* renamed from: d0 */
    public boolean mo1841d0() {
        return this.f1306A;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x009e  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x00a1  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void dispatchDraw(android.graphics.Canvas r10) {
        /*
            r9 = this;
            r0 = 0
            r9.mo1834T(r0)
            super.dispatchDraw(r10)
            androidx.constraintlayout.motion.widget.p r1 = r9.f1348s
            if (r1 != 0) goto L_0x000c
            return
        L_0x000c:
            int r1 = r9.f1324M
            r2 = 1
            r1 = r1 & r2
            if (r1 != r2) goto L_0x00cd
            boolean r1 = r9.isInEditMode()
            if (r1 != 0) goto L_0x00cd
            int r1 = r9.f1340k0
            int r1 = r1 + r2
            r9.f1340k0 = r1
            long r3 = java.lang.System.nanoTime()
            long r5 = r9.f1341l0
            r7 = -1
            int r1 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r1 == 0) goto L_0x0047
            long r5 = r3 - r5
            r7 = 200000000(0xbebc200, double:9.8813129E-316)
            int r1 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r1 <= 0) goto L_0x0049
            int r1 = r9.f1340k0
            float r1 = (float) r1
            float r5 = (float) r5
            r6 = 814313567(0x3089705f, float:1.0E-9)
            float r5 = r5 * r6
            float r1 = r1 / r5
            r5 = 1120403456(0x42c80000, float:100.0)
            float r1 = r1 * r5
            int r1 = (int) r1
            float r1 = (float) r1
            float r1 = r1 / r5
            r9.f1342m0 = r1
            r9.f1340k0 = r0
        L_0x0047:
            r9.f1341l0 = r3
        L_0x0049:
            android.graphics.Paint r0 = new android.graphics.Paint
            r0.<init>()
            r1 = 1109917696(0x42280000, float:42.0)
            r0.setTextSize(r1)
            float r1 = r9.f1316F
            r3 = 1148846080(0x447a0000, float:1000.0)
            float r1 = r1 * r3
            int r1 = (int) r1
            float r1 = (float) r1
            r3 = 1092616192(0x41200000, float:10.0)
            float r1 = r1 / r3
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            float r5 = r9.f1342m0
            r4.append(r5)
            java.lang.String r5 = " fps "
            r4.append(r5)
            int r5 = r9.f1354v
            java.lang.String r5 = p098d.p099a.C4567a.m16429d(r9, r5)
            r4.append(r5)
            java.lang.String r5 = " -> "
            r4.append(r5)
            java.lang.String r4 = r4.toString()
            java.lang.StringBuilder r4 = p165e.p166a.p167a.p168a.C4924a.m17863P(r4)
            int r5 = r9.f1358x
            java.lang.String r5 = p098d.p099a.C4567a.m16429d(r9, r5)
            r4.append(r5)
            java.lang.String r5 = " (progress: "
            r4.append(r5)
            r4.append(r1)
            java.lang.String r1 = " ) state="
            r4.append(r1)
            int r1 = r9.f1356w
            r5 = -1
            if (r1 != r5) goto L_0x00a1
            java.lang.String r1 = "undefined"
            goto L_0x00a5
        L_0x00a1:
            java.lang.String r1 = p098d.p099a.C4567a.m16429d(r9, r1)
        L_0x00a5:
            r4.append(r1)
            java.lang.String r1 = r4.toString()
            r4 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r0.setColor(r4)
            r4 = 1093664768(0x41300000, float:11.0)
            int r5 = r9.getHeight()
            int r5 = r5 + -29
            float r5 = (float) r5
            r10.drawText(r1, r4, r5, r0)
            r4 = -7864184(0xffffffffff880088, float:NaN)
            r0.setColor(r4)
            int r4 = r9.getHeight()
            int r4 = r4 + -30
            float r4 = (float) r4
            r10.drawText(r1, r3, r4, r0)
        L_0x00cd:
            int r0 = r9.f1324M
            if (r0 <= r2) goto L_0x00eb
            androidx.constraintlayout.motion.widget.MotionLayout$c r0 = r9.f1325N
            if (r0 != 0) goto L_0x00dc
            androidx.constraintlayout.motion.widget.MotionLayout$c r0 = new androidx.constraintlayout.motion.widget.MotionLayout$c
            r0.<init>()
            r9.f1325N = r0
        L_0x00dc:
            androidx.constraintlayout.motion.widget.MotionLayout$c r0 = r9.f1325N
            java.util.HashMap<android.view.View, androidx.constraintlayout.motion.widget.l> r1 = r9.f1308B
            androidx.constraintlayout.motion.widget.p r2 = r9.f1348s
            int r2 = r2.mo1927i()
            int r3 = r9.f1324M
            r0.mo1869a(r10, r1, r2, r3)
        L_0x00eb:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.dispatchDraw(android.graphics.Canvas):void");
    }

    /* renamed from: g0 */
    public void mo1843g0() {
        this.f1309B0.mo1876e();
        invalidate();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0023, code lost:
        if (r3.f1316F == 0.0f) goto L_0x0036;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0034, code lost:
        if (r3.f1316F == 1.0f) goto L_0x0036;
     */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0043 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0044  */
    /* renamed from: h0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1844h0(float r4) {
        /*
            r3 = this;
            boolean r0 = r3.isAttachedToWindow()
            if (r0 != 0) goto L_0x0016
            androidx.constraintlayout.motion.widget.MotionLayout$g r0 = r3.f1363z0
            if (r0 != 0) goto L_0x0011
            androidx.constraintlayout.motion.widget.MotionLayout$g r0 = new androidx.constraintlayout.motion.widget.MotionLayout$g
            r0.<init>()
            r3.f1363z0 = r0
        L_0x0011:
            androidx.constraintlayout.motion.widget.MotionLayout$g r0 = r3.f1363z0
            r0.f1393a = r4
            return
        L_0x0016:
            r0 = 0
            int r1 = (r4 > r0 ? 1 : (r4 == r0 ? 0 : -1))
            if (r1 > 0) goto L_0x0026
            int r1 = r3.f1354v
            r3.f1356w = r1
            float r1 = r3.f1316F
            int r0 = (r1 > r0 ? 1 : (r1 == r0 ? 0 : -1))
            if (r0 != 0) goto L_0x003f
            goto L_0x0036
        L_0x0026:
            r0 = 1065353216(0x3f800000, float:1.0)
            int r1 = (r4 > r0 ? 1 : (r4 == r0 ? 0 : -1))
            if (r1 < 0) goto L_0x0038
            int r1 = r3.f1358x
            r3.f1356w = r1
            float r1 = r3.f1316F
            int r0 = (r1 > r0 ? 1 : (r1 == r0 ? 0 : -1))
            if (r0 != 0) goto L_0x003f
        L_0x0036:
            r0 = 4
            goto L_0x003c
        L_0x0038:
            r0 = -1
            r3.f1356w = r0
            r0 = 3
        L_0x003c:
            r3.mo1848k0(r0)
        L_0x003f:
            androidx.constraintlayout.motion.widget.p r0 = r3.f1348s
            if (r0 != 0) goto L_0x0044
            return
        L_0x0044:
            r0 = 1
            r3.f1320I = r0
            r3.f1319H = r4
            r3.f1314E = r4
            r1 = -1
            r3.f1318G = r1
            r3.f1310C = r1
            r4 = 0
            r3.f1350t = r4
            r3.f1321J = r0
            r3.invalidate()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.mo1844h0(float):void");
    }

    /* renamed from: i0 */
    public void mo1845i0(float f, float f2) {
        if (!isAttachedToWindow()) {
            if (this.f1363z0 == null) {
                this.f1363z0 = new C0325g();
            }
            C0325g gVar = this.f1363z0;
            gVar.f1393a = f;
            gVar.f1394b = f2;
            return;
        }
        mo1844h0(f);
        mo1848k0(3);
        this.f1352u = f2;
        mo1833S(1.0f);
    }

    public boolean isAttachedToWindow() {
        return super.isAttachedToWindow();
    }

    /* renamed from: j0 */
    public void mo1847j0(int i, int i2, int i3) {
        mo1848k0(2);
        this.f1356w = i;
        this.f1354v = -1;
        this.f1358x = -1;
        C0408b bVar = this.f1769k;
        if (bVar != null) {
            bVar.mo2060b(i, (float) i2, (float) i3);
            return;
        }
        C0363p pVar = this.f1348s;
        if (pVar != null) {
            pVar.mo1925g(i).mo2064c(this);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k0 */
    public void mo1848k0(int i) {
        if (i != 4 || this.f1356w != -1) {
            int i2 = this.f1307A0;
            this.f1307A0 = i;
            if (i2 == 3 && i == 3) {
                m1481U();
            }
            int i3 = C0361n.m1729i(i2);
            if (i3 == 0 || i3 == 1) {
                if (i == 3) {
                    m1481U();
                }
                if (i != 4) {
                    return;
                }
            } else if (!(i3 == 2 && i == 4)) {
                return;
            }
            mo1835V();
        }
    }

    /* renamed from: l */
    public void mo1064l(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        if (!(!this.f1331b0 && i == 0 && i2 == 0)) {
            iArr[0] = iArr[0] + i3;
            iArr[1] = iArr[1] + i4;
        }
        this.f1331b0 = false;
    }

    /* renamed from: l0 */
    public void mo1849l0(int i, int i2) {
        if (!isAttachedToWindow()) {
            if (this.f1363z0 == null) {
                this.f1363z0 = new C0325g();
            }
            C0325g gVar = this.f1363z0;
            gVar.f1395c = i;
            gVar.f1396d = i2;
            return;
        }
        C0363p pVar = this.f1348s;
        if (pVar != null) {
            this.f1354v = i;
            this.f1358x = i2;
            pVar.mo1937w(i, i2);
            this.f1309B0.mo1875d(this.f1348s.mo1925g(i), this.f1348s.mo1925g(i2));
            mo1843g0();
            this.f1316F = 0.0f;
            mo1833S(0.0f);
        }
    }

    /* renamed from: m */
    public void mo1065m(View view, int i, int i2, int i3, int i4, int i5) {
    }

    /* access modifiers changed from: protected */
    /* renamed from: m0 */
    public void mo1850m0(C0363p.C0365b bVar) {
        this.f1348s.mo1938x(bVar);
        mo1848k0(2);
        float f = this.f1356w == this.f1348s.mo1928j() ? 1.0f : 0.0f;
        this.f1316F = f;
        this.f1314E = f;
        this.f1319H = f;
        this.f1318G = bVar.mo1941A(1) ? -1 : System.nanoTime();
        int p = this.f1348s.mo1933p();
        int j = this.f1348s.mo1928j();
        if (p != this.f1354v || j != this.f1358x) {
            this.f1354v = p;
            this.f1358x = j;
            this.f1348s.mo1937w(p, j);
            this.f1309B0.mo1875d(this.f1348s.mo1925g(this.f1354v), this.f1348s.mo1925g(this.f1358x));
            C0322d dVar = this.f1309B0;
            int i = this.f1354v;
            int i2 = this.f1358x;
            dVar.f1388e = i;
            dVar.f1389f = i2;
            dVar.mo1876e();
            mo1843g0();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r1 = r1.f1617c;
     */
    /* renamed from: n */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo1066n(android.view.View r1, android.view.View r2, int r3, int r4) {
        /*
            r0 = this;
            androidx.constraintlayout.motion.widget.p r1 = r0.f1348s
            if (r1 == 0) goto L_0x0021
            androidx.constraintlayout.motion.widget.p$b r1 = r1.f1617c
            if (r1 == 0) goto L_0x0021
            androidx.constraintlayout.motion.widget.s r1 = r1.mo1948y()
            if (r1 == 0) goto L_0x0021
            androidx.constraintlayout.motion.widget.p r1 = r0.f1348s
            androidx.constraintlayout.motion.widget.p$b r1 = r1.f1617c
            androidx.constraintlayout.motion.widget.s r1 = r1.mo1948y()
            int r1 = r1.mo1968b()
            r1 = r1 & 2
            if (r1 == 0) goto L_0x001f
            goto L_0x0021
        L_0x001f:
            r1 = 1
            return r1
        L_0x0021:
            r1 = 0
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.mo1066n(android.view.View, android.view.View, int, int):boolean");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0054, code lost:
        if ((((r14 * r6) - (((r1 * r6) * r6) / 2.0f)) + r12) > 1.0f) goto L_0x0068;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0064, code lost:
        if ((((((r1 * r4) * r4) / 2.0f) + (r14 * r4)) + r12) < 0.0f) goto L_0x0068;
     */
    /* renamed from: n0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1851n0(int r12, float r13, float r14) {
        /*
            r11 = this;
            androidx.constraintlayout.motion.widget.p r0 = r11.f1348s
            if (r0 != 0) goto L_0x0005
            return
        L_0x0005:
            float r0 = r11.f1316F
            int r0 = (r0 > r13 ? 1 : (r0 == r13 ? 0 : -1))
            if (r0 != 0) goto L_0x000c
            return
        L_0x000c:
            r0 = 1
            r11.f1326O = r0
            long r1 = java.lang.System.nanoTime()
            r11.f1310C = r1
            androidx.constraintlayout.motion.widget.p r1 = r11.f1348s
            int r1 = r1.mo1927i()
            float r1 = (float) r1
            r2 = 1148846080(0x447a0000, float:1000.0)
            float r7 = r1 / r2
            r11.f1312D = r7
            r11.f1319H = r13
            r11.f1321J = r0
            r1 = 2
            r2 = 0
            r3 = 0
            r4 = 1065353216(0x3f800000, float:1.0)
            if (r12 == 0) goto L_0x0098
            if (r12 == r0) goto L_0x0098
            if (r12 == r1) goto L_0x0098
            r1 = 4
            if (r12 == r1) goto L_0x0085
            r1 = 5
            if (r12 == r1) goto L_0x0039
            goto L_0x00bf
        L_0x0039:
            float r12 = r11.f1316F
            androidx.constraintlayout.motion.widget.p r1 = r11.f1348s
            float r1 = r1.mo1931n()
            r5 = 1073741824(0x40000000, float:2.0)
            int r6 = (r14 > r3 ? 1 : (r14 == r3 ? 0 : -1))
            if (r6 <= 0) goto L_0x0057
            float r6 = r14 / r1
            float r7 = r14 * r6
            float r1 = r1 * r6
            float r1 = r1 * r6
            float r1 = r1 / r5
            float r7 = r7 - r1
            float r7 = r7 + r12
            int r12 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r12 <= 0) goto L_0x0067
            goto L_0x0068
        L_0x0057:
            float r4 = -r14
            float r4 = r4 / r1
            float r6 = r14 * r4
            float r1 = r1 * r4
            float r1 = r1 * r4
            float r1 = r1 / r5
            float r1 = r1 + r6
            float r1 = r1 + r12
            int r12 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r12 >= 0) goto L_0x0067
            goto L_0x0068
        L_0x0067:
            r0 = 0
        L_0x0068:
            if (r0 == 0) goto L_0x006b
            goto L_0x0085
        L_0x006b:
            d.e.a.a.g r4 = r11.f1327P
            float r5 = r11.f1316F
            float r8 = r11.f1312D
            androidx.constraintlayout.motion.widget.p r12 = r11.f1348s
            float r9 = r12.mo1931n()
            androidx.constraintlayout.motion.widget.p r12 = r11.f1348s
            float r10 = r12.mo1932o()
            r6 = r13
            r7 = r14
            r4.mo21503b(r5, r6, r7, r8, r9, r10)
            r11.f1352u = r3
            goto L_0x00b5
        L_0x0085:
            androidx.constraintlayout.motion.widget.MotionLayout$b r12 = r11.f1328Q
            float r13 = r11.f1316F
            androidx.constraintlayout.motion.widget.p r0 = r11.f1348s
            float r0 = r0.mo1931n()
            r12.f1365a = r14
            r12.f1366b = r13
            r12.f1367c = r0
            androidx.constraintlayout.motion.widget.MotionLayout$b r12 = r11.f1328Q
            goto L_0x00bd
        L_0x0098:
            if (r12 != r0) goto L_0x009c
            r13 = 0
            goto L_0x00a0
        L_0x009c:
            if (r12 != r1) goto L_0x00a0
            r13 = 1065353216(0x3f800000, float:1.0)
        L_0x00a0:
            d.e.a.a.g r3 = r11.f1327P
            float r4 = r11.f1316F
            androidx.constraintlayout.motion.widget.p r12 = r11.f1348s
            float r8 = r12.mo1931n()
            androidx.constraintlayout.motion.widget.p r12 = r11.f1348s
            float r9 = r12.mo1932o()
            r5 = r13
            r6 = r14
            r3.mo21503b(r4, r5, r6, r7, r8, r9)
        L_0x00b5:
            int r12 = r11.f1356w
            r11.f1319H = r13
            r11.f1356w = r12
            d.e.a.a.g r12 = r11.f1327P
        L_0x00bd:
            r11.f1350t = r12
        L_0x00bf:
            r11.f1320I = r2
            long r12 = java.lang.System.nanoTime()
            r11.f1310C = r12
            r11.invalidate()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.mo1851n0(int, float, float):void");
    }

    /* renamed from: o */
    public void mo1067o(View view, View view2, int i, int i2) {
    }

    /* renamed from: o0 */
    public void mo1852o0(int i) {
        C0419f fVar;
        float f;
        int a;
        if (!isAttachedToWindow()) {
            if (this.f1363z0 == null) {
                this.f1363z0 = new C0325g();
            }
            this.f1363z0.f1396d = i;
            return;
        }
        C0363p pVar = this.f1348s;
        if (!(pVar == null || (fVar = pVar.f1616b) == null || (a = fVar.mo2092a(this.f1356w, i, (f = (float) -1), f)) == -1)) {
            i = a;
        }
        int i2 = this.f1356w;
        if (i2 != i) {
            if (this.f1354v == i) {
                mo1833S(0.0f);
            } else if (this.f1358x == i) {
                mo1833S(1.0f);
            } else {
                this.f1358x = i;
                if (i2 != -1) {
                    mo1849l0(i2, i);
                    mo1833S(1.0f);
                    this.f1316F = 0.0f;
                    mo1833S(1.0f);
                    return;
                }
                this.f1326O = false;
                this.f1319H = 1.0f;
                this.f1314E = 0.0f;
                this.f1316F = 0.0f;
                this.f1318G = System.nanoTime();
                this.f1310C = System.nanoTime();
                this.f1320I = false;
                this.f1350t = null;
                this.f1312D = ((float) this.f1348s.mo1927i()) / 1000.0f;
                this.f1354v = -1;
                this.f1348s.mo1937w(-1, this.f1358x);
                this.f1348s.mo1933p();
                int childCount = getChildCount();
                this.f1308B.clear();
                for (int i3 = 0; i3 < childCount; i3++) {
                    View childAt = getChildAt(i3);
                    this.f1308B.put(childAt, new C0359l(childAt));
                }
                this.f1321J = true;
                this.f1309B0.mo1875d((C0411c) null, this.f1348s.mo1925g(i));
                mo1843g0();
                this.f1309B0.mo1872a();
                int childCount2 = getChildCount();
                for (int i4 = 0; i4 < childCount2; i4++) {
                    View childAt2 = getChildAt(i4);
                    C0359l lVar = this.f1308B.get(childAt2);
                    if (lVar != null) {
                        lVar.mo1913q(childAt2);
                    }
                }
                int width = getWidth();
                int height = getHeight();
                for (int i5 = 0; i5 < childCount; i5++) {
                    C0359l lVar2 = this.f1308B.get(getChildAt(i5));
                    this.f1348s.mo1930m(lVar2);
                    lVar2.mo1915s(width, height, System.nanoTime());
                }
                C0363p.C0365b bVar = this.f1348s.f1617c;
                float l = bVar != null ? bVar.f1641i : 0.0f;
                if (l != 0.0f) {
                    float f2 = Float.MAX_VALUE;
                    float f3 = -3.4028235E38f;
                    for (int i6 = 0; i6 < childCount; i6++) {
                        C0359l lVar3 = this.f1308B.get(getChildAt(i6));
                        float j = lVar3.mo1907j() + lVar3.mo1906i();
                        f2 = Math.min(f2, j);
                        f3 = Math.max(f3, j);
                    }
                    for (int i7 = 0; i7 < childCount; i7++) {
                        C0359l lVar4 = this.f1308B.get(getChildAt(i7));
                        float i8 = lVar4.mo1906i();
                        float j2 = lVar4.mo1907j();
                        lVar4.f1535l = 1.0f / (1.0f - l);
                        lVar4.f1534k = l - ((((i8 + j2) - f2) * l) / (f3 - f2));
                    }
                }
                this.f1314E = 0.0f;
                this.f1316F = 0.0f;
                this.f1321J = true;
                invalidate();
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        int i;
        super.onAttachedToWindow();
        C0363p pVar = this.f1348s;
        if (!(pVar == null || (i = this.f1356w) == -1)) {
            C0411c g = pVar.mo1925g(i);
            this.f1348s.mo1935u(this);
            if (g != null) {
                g.mo2064c(this);
            }
            this.f1354v = this.f1356w;
        }
        m1484e0();
        C0325g gVar = this.f1363z0;
        if (gVar != null) {
            int i2 = gVar.f1395c;
            if (!(i2 == -1 && gVar.f1396d == -1)) {
                if (i2 == -1) {
                    MotionLayout.this.mo1852o0(gVar.f1396d);
                } else {
                    int i3 = gVar.f1396d;
                    if (i3 == -1) {
                        MotionLayout.this.mo1847j0(i2, -1, -1);
                    } else {
                        MotionLayout.this.mo1849l0(i2, i3);
                    }
                }
                MotionLayout.this.mo1848k0(2);
            }
            if (!Float.isNaN(gVar.f1394b)) {
                MotionLayout.this.mo1845i0(gVar.f1393a, gVar.f1394b);
                gVar.f1393a = Float.NaN;
                gVar.f1394b = Float.NaN;
                gVar.f1395c = -1;
                gVar.f1396d = -1;
            } else if (!Float.isNaN(gVar.f1393a)) {
                MotionLayout.this.mo1844h0(gVar.f1393a);
            }
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        C0363p.C0365b bVar;
        C0397s y;
        int i;
        RectF h;
        C0363p pVar = this.f1348s;
        if (pVar != null && this.f1306A && (bVar = pVar.f1617c) != null && bVar.mo1949z() && (y = bVar.mo1948y()) != null && ((motionEvent.getAction() != 0 || (h = y.mo1974h(this, new RectF())) == null || h.contains(motionEvent.getX(), motionEvent.getY())) && (i = y.mo1975i()) != -1)) {
            View view = this.f1315E0;
            if (view == null || view.getId() != i) {
                this.f1315E0 = findViewById(i);
            }
            View view2 = this.f1315E0;
            if (view2 != null) {
                this.f1313D0.set((float) view2.getLeft(), (float) this.f1315E0.getTop(), (float) this.f1315E0.getRight(), (float) this.f1315E0.getBottom());
                if (this.f1313D0.contains(motionEvent.getX(), motionEvent.getY()) && !m1482b0(0.0f, 0.0f, this.f1315E0, motionEvent)) {
                    return onTouchEvent(motionEvent);
                }
            }
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.f1361y0 = true;
        try {
            if (this.f1348s == null) {
                super.onLayout(z, i, i2, i3, i4);
                return;
            }
            int i5 = i3 - i;
            int i6 = i4 - i2;
            if (!(this.f1329R == i5 && this.f1330a0 == i6)) {
                mo1843g0();
                mo1834T(true);
            }
            this.f1329R = i5;
            this.f1330a0 = i6;
            this.f1361y0 = false;
        } finally {
            this.f1361y0 = false;
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x004e, code lost:
        if (((r6 == r3.f1388e && r7 == r3.f1389f) ? false : true) != false) goto L_0x0050;
     */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00e5  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00f2  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00fa  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x0110  */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x0113  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x011c  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x0127  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x014b  */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x016a  */
    /* JADX WARNING: Removed duplicated region for block: B:85:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r18, int r19) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            r2 = r19
            androidx.constraintlayout.motion.widget.p r3 = r0.f1348s
            if (r3 != 0) goto L_0x000e
            super.onMeasure(r18, r19)
            return
        L_0x000e:
            int r3 = r0.f1360y
            r4 = 0
            r5 = 1
            if (r3 != r1) goto L_0x001b
            int r3 = r0.f1362z
            if (r3 == r2) goto L_0x0019
            goto L_0x001b
        L_0x0019:
            r3 = 0
            goto L_0x001c
        L_0x001b:
            r3 = 1
        L_0x001c:
            boolean r6 = r0.f1311C0
            if (r6 == 0) goto L_0x0029
            r0.f1311C0 = r4
            r17.m1484e0()
            r17.m1485f0()
            r3 = 1
        L_0x0029:
            boolean r6 = r0.f1766h
            if (r6 == 0) goto L_0x002e
            r3 = 1
        L_0x002e:
            r0.f1360y = r1
            r0.f1362z = r2
            androidx.constraintlayout.motion.widget.p r6 = r0.f1348s
            int r6 = r6.mo1933p()
            androidx.constraintlayout.motion.widget.p r7 = r0.f1348s
            int r7 = r7.mo1928j()
            if (r3 != 0) goto L_0x0050
            androidx.constraintlayout.motion.widget.MotionLayout$d r3 = r0.f1309B0
            int r8 = r3.f1388e
            if (r6 != r8) goto L_0x004d
            int r3 = r3.f1389f
            if (r7 == r3) goto L_0x004b
            goto L_0x004d
        L_0x004b:
            r3 = 0
            goto L_0x004e
        L_0x004d:
            r3 = 1
        L_0x004e:
            if (r3 == 0) goto L_0x0076
        L_0x0050:
            int r3 = r0.f1354v
            r8 = -1
            if (r3 == r8) goto L_0x0076
            super.onMeasure(r18, r19)
            androidx.constraintlayout.motion.widget.MotionLayout$d r1 = r0.f1309B0
            androidx.constraintlayout.motion.widget.p r2 = r0.f1348s
            androidx.constraintlayout.widget.c r2 = r2.mo1925g(r6)
            androidx.constraintlayout.motion.widget.p r3 = r0.f1348s
            androidx.constraintlayout.widget.c r3 = r3.mo1925g(r7)
            r1.mo1875d(r2, r3)
            androidx.constraintlayout.motion.widget.MotionLayout$d r1 = r0.f1309B0
            r1.mo1876e()
            androidx.constraintlayout.motion.widget.MotionLayout$d r1 = r0.f1309B0
            r1.f1388e = r6
            r1.f1389f = r7
            r1 = 0
            goto L_0x0077
        L_0x0076:
            r1 = 1
        L_0x0077:
            boolean r2 = r0.f1345p0
            if (r2 != 0) goto L_0x007d
            if (r1 == 0) goto L_0x00ce
        L_0x007d:
            int r1 = r17.getPaddingTop()
            int r2 = r17.getPaddingBottom()
            int r2 = r2 + r1
            int r1 = r17.getPaddingLeft()
            int r3 = r17.getPaddingRight()
            int r3 = r3 + r1
            d.e.b.i.f r1 = r0.f1761c
            int r1 = r1.mo21604I()
            int r1 = r1 + r3
            d.e.b.i.f r3 = r0.f1761c
            int r3 = r3.mo21651t()
            int r3 = r3 + r2
            int r2 = r0.f1353u0
            r6 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r2 == r6) goto L_0x00a5
            if (r2 != 0) goto L_0x00b5
        L_0x00a5:
            int r1 = r0.f1346q0
            float r2 = (float) r1
            float r7 = r0.f1357w0
            int r8 = r0.f1349s0
            int r8 = r8 - r1
            float r1 = (float) r8
            float r7 = r7 * r1
            float r7 = r7 + r2
            int r1 = (int) r7
            r17.requestLayout()
        L_0x00b5:
            int r2 = r0.f1355v0
            if (r2 == r6) goto L_0x00bb
            if (r2 != 0) goto L_0x00cb
        L_0x00bb:
            int r2 = r0.f1347r0
            float r3 = (float) r2
            float r6 = r0.f1357w0
            int r7 = r0.f1351t0
            int r7 = r7 - r2
            float r2 = (float) r7
            float r6 = r6 * r2
            float r6 = r6 + r3
            int r3 = (int) r6
            r17.requestLayout()
        L_0x00cb:
            r0.setMeasuredDimension(r1, r3)
        L_0x00ce:
            float r1 = r0.f1319H
            float r2 = r0.f1316F
            float r1 = r1 - r2
            float r1 = java.lang.Math.signum(r1)
            long r2 = java.lang.System.nanoTime()
            android.view.animation.Interpolator r6 = r0.f1350t
            boolean r7 = r6 instanceof p098d.p113e.p114a.p115a.C4642g
            r8 = 814313567(0x3089705f, float:1.0E-9)
            r9 = 0
            if (r7 != 0) goto L_0x00f2
            long r10 = r0.f1318G
            long r10 = r2 - r10
            float r7 = (float) r10
            float r7 = r7 * r1
            float r7 = r7 * r8
            float r10 = r0.f1312D
            float r7 = r7 / r10
            goto L_0x00f3
        L_0x00f2:
            r7 = 0
        L_0x00f3:
            float r10 = r0.f1316F
            float r10 = r10 + r7
            boolean r7 = r0.f1320I
            if (r7 == 0) goto L_0x00fc
            float r10 = r0.f1319H
        L_0x00fc:
            int r7 = (r1 > r9 ? 1 : (r1 == r9 ? 0 : -1))
            if (r7 <= 0) goto L_0x0106
            float r11 = r0.f1319H
            int r11 = (r10 > r11 ? 1 : (r10 == r11 ? 0 : -1))
            if (r11 >= 0) goto L_0x0110
        L_0x0106:
            int r11 = (r1 > r9 ? 1 : (r1 == r9 ? 0 : -1))
            if (r11 > 0) goto L_0x0113
            float r11 = r0.f1319H
            int r11 = (r10 > r11 ? 1 : (r10 == r11 ? 0 : -1))
            if (r11 > 0) goto L_0x0113
        L_0x0110:
            float r10 = r0.f1319H
            goto L_0x0114
        L_0x0113:
            r5 = 0
        L_0x0114:
            if (r6 == 0) goto L_0x012b
            if (r5 != 0) goto L_0x012b
            boolean r5 = r0.f1326O
            if (r5 == 0) goto L_0x0127
            long r10 = r0.f1310C
            long r2 = r2 - r10
            float r2 = (float) r2
            float r2 = r2 * r8
            float r10 = r6.getInterpolation(r2)
            goto L_0x012b
        L_0x0127:
            float r10 = r6.getInterpolation(r10)
        L_0x012b:
            if (r7 <= 0) goto L_0x0133
            float r2 = r0.f1319H
            int r2 = (r10 > r2 ? 1 : (r10 == r2 ? 0 : -1))
            if (r2 >= 0) goto L_0x013d
        L_0x0133:
            int r1 = (r1 > r9 ? 1 : (r1 == r9 ? 0 : -1))
            if (r1 > 0) goto L_0x013f
            float r1 = r0.f1319H
            int r1 = (r10 > r1 ? 1 : (r10 == r1 ? 0 : -1))
            if (r1 > 0) goto L_0x013f
        L_0x013d:
            float r10 = r0.f1319H
        L_0x013f:
            r0.f1357w0 = r10
            int r1 = r17.getChildCount()
            long r2 = java.lang.System.nanoTime()
        L_0x0149:
            if (r4 >= r1) goto L_0x0166
            android.view.View r12 = r0.getChildAt(r4)
            java.util.HashMap<android.view.View, androidx.constraintlayout.motion.widget.l> r5 = r0.f1308B
            java.lang.Object r5 = r5.get(r12)
            r11 = r5
            androidx.constraintlayout.motion.widget.l r11 = (androidx.constraintlayout.motion.widget.C0359l) r11
            if (r11 == 0) goto L_0x0163
            androidx.constraintlayout.motion.widget.c r5 = r0.f1359x0
            r13 = r10
            r14 = r2
            r16 = r5
            r11.mo1910m(r12, r13, r14, r16)
        L_0x0163:
            int r4 = r4 + 1
            goto L_0x0149
        L_0x0166:
            boolean r1 = r0.f1345p0
            if (r1 == 0) goto L_0x016d
            r17.requestLayout()
        L_0x016d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.onMeasure(int, int):void");
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        return false;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    public void onRtlPropertiesChanged(int i) {
        C0363p pVar = this.f1348s;
        if (pVar != null) {
            pVar.mo1936v(mo2026s());
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        C0363p pVar = this.f1348s;
        if (pVar == null || !this.f1306A || !pVar.mo1939y()) {
            return super.onTouchEvent(motionEvent);
        }
        C0363p.C0365b bVar = this.f1348s.f1617c;
        if (bVar != null && !bVar.mo1949z()) {
            return super.onTouchEvent(motionEvent);
        }
        this.f1348s.mo1934s(motionEvent, this.f1356w, this);
        return true;
    }

    public void onViewAdded(View view) {
        super.onViewAdded(view);
        if (view instanceof MotionHelper) {
            MotionHelper motionHelper = (MotionHelper) view;
            if (this.f1339j0 == null) {
                this.f1339j0 = new ArrayList<>();
            }
            this.f1339j0.add(motionHelper);
            if (motionHelper.mo1832x()) {
                if (this.f1337h0 == null) {
                    this.f1337h0 = new ArrayList<>();
                }
                this.f1337h0.add(motionHelper);
            }
            if (motionHelper.mo1831w()) {
                if (this.f1338i0 == null) {
                    this.f1338i0 = new ArrayList<>();
                }
                this.f1338i0.add(motionHelper);
            }
        }
    }

    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        ArrayList<MotionHelper> arrayList = this.f1337h0;
        if (arrayList != null) {
            arrayList.remove(view);
        }
        ArrayList<MotionHelper> arrayList2 = this.f1338i0;
        if (arrayList2 != null) {
            arrayList2.remove(view);
        }
    }

    /* renamed from: p */
    public void mo1082p(View view, int i) {
        C0363p pVar = this.f1348s;
        if (pVar != null) {
            float f = this.f1332c0;
            float f2 = this.f1335f0;
            float f3 = f / f2;
            float f4 = this.f1333d0 / f2;
            C0363p.C0365b bVar = pVar.f1617c;
            if (bVar != null && bVar.f1644l != null) {
                pVar.f1617c.f1644l.mo1978l(f3, f4);
            }
        }
    }

    /* renamed from: q */
    public void mo1083q(View view, int i, int i2, int[] iArr, int i3) {
        C0363p.C0365b bVar;
        C0397s y;
        int i4;
        C0363p pVar = this.f1348s;
        if (pVar != null && (bVar = pVar.f1617c) != null && bVar.mo1949z()) {
            C0363p.C0365b bVar2 = this.f1348s.f1617c;
            if (bVar2 == null || !bVar2.mo1949z() || (y = bVar2.mo1948y()) == null || (i4 = y.mo1975i()) == -1 || view.getId() == i4) {
                C0363p pVar2 = this.f1348s;
                if (pVar2 != null) {
                    C0363p.C0365b bVar3 = pVar2.f1617c;
                    if ((bVar3 == null || bVar3.f1644l == null) ? false : pVar2.f1617c.f1644l.mo1972f()) {
                        float f = this.f1314E;
                        if ((f == 1.0f || f == 0.0f) && view.canScrollVertically(-1)) {
                            return;
                        }
                    }
                }
                if (!(bVar2.mo1948y() == null || (this.f1348s.f1617c.mo1948y().mo1968b() & 1) == 0)) {
                    C0363p pVar3 = this.f1348s;
                    float f2 = (float) i;
                    float f3 = (float) i2;
                    C0363p.C0365b bVar4 = pVar3.f1617c;
                    float g = (bVar4 == null || bVar4.f1644l == null) ? 0.0f : pVar3.f1617c.f1644l.mo1973g(f2, f3);
                    float f4 = this.f1316F;
                    if ((f4 <= 0.0f && g < 0.0f) || (f4 >= 1.0f && g > 0.0f)) {
                        view.setNestedScrollingEnabled(false);
                        view.post(new C0319a(this, view));
                        return;
                    }
                }
                float f5 = this.f1314E;
                long nanoTime = System.nanoTime();
                float f6 = (float) i;
                this.f1332c0 = f6;
                float f7 = (float) i2;
                this.f1333d0 = f7;
                this.f1335f0 = (float) (((double) (nanoTime - this.f1334e0)) * 1.0E-9d);
                this.f1334e0 = nanoTime;
                C0363p pVar4 = this.f1348s;
                C0363p.C0365b bVar5 = pVar4.f1617c;
                if (!(bVar5 == null || bVar5.f1644l == null)) {
                    pVar4.f1617c.f1644l.mo1977k(f6, f7);
                }
                if (f5 != this.f1314E) {
                    iArr[0] = i;
                    iArr[1] = i2;
                }
                mo1834T(false);
                if (iArr[0] != 0 || iArr[1] != 0) {
                    this.f1331b0 = true;
                }
            }
        }
    }

    public void requestLayout() {
        C0363p pVar;
        C0363p.C0365b bVar;
        if (this.f1345p0 || this.f1356w != -1 || (pVar = this.f1348s) == null || (bVar = pVar.f1617c) == null || bVar.mo1946w() != 0) {
            super.requestLayout();
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: t */
    public void mo1864t(int i) {
        this.f1769k = null;
    }

    public String toString() {
        Context context = getContext();
        return C4567a.m16427b(context, this.f1354v) + "->" + C4567a.m16427b(context, this.f1358x) + " (pos:" + this.f1316F + " Dpos/Dt:" + this.f1352u;
    }
}
