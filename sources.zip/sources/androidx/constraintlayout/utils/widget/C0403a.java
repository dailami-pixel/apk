package androidx.constraintlayout.utils.widget;

import android.graphics.Outline;
import android.view.View;
import android.view.ViewOutlineProvider;

/* renamed from: androidx.constraintlayout.utils.widget.a */
class C0403a extends ViewOutlineProvider {

    /* renamed from: a */
    final /* synthetic */ ImageFilterButton f1747a;

    C0403a(ImageFilterButton imageFilterButton) {
        this.f1747a = imageFilterButton;
    }

    public void getOutline(View view, Outline outline) {
        outline.setRoundRect(0, 0, this.f1747a.getWidth(), this.f1747a.getHeight(), this.f1747a.f1703f);
    }
}
