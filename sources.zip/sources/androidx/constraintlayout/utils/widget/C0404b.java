package androidx.constraintlayout.utils.widget;

import android.graphics.Outline;
import android.view.View;
import android.view.ViewOutlineProvider;

/* renamed from: androidx.constraintlayout.utils.widget.b */
class C0404b extends ViewOutlineProvider {

    /* renamed from: a */
    final /* synthetic */ ImageFilterView f1748a;

    C0404b(ImageFilterView imageFilterView) {
        this.f1748a = imageFilterView;
    }

    public void getOutline(View view, Outline outline) {
        outline.setRoundRect(0, 0, this.f1748a.getWidth(), this.f1748a.getHeight(), this.f1748a.f1715e);
    }
}
