package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewOutlineProvider;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.constraintlayout.utils.widget.ImageFilterView;
import androidx.constraintlayout.widget.C0418e;

public class ImageFilterButton extends AppCompatImageButton {

    /* renamed from: c */
    private ImageFilterView.C0402b f1700c = new ImageFilterView.C0402b();

    /* renamed from: d */
    private float f1701d = 0.0f;
    /* access modifiers changed from: private */

    /* renamed from: e */
    public float f1702e = 0.0f;
    /* access modifiers changed from: private */

    /* renamed from: f */
    public float f1703f = Float.NaN;

    /* renamed from: g */
    private Path f1704g;

    /* renamed from: h */
    ViewOutlineProvider f1705h;

    /* renamed from: i */
    RectF f1706i;

    /* renamed from: j */
    Drawable[] f1707j;

    /* renamed from: k */
    LayerDrawable f1708k;

    /* renamed from: l */
    private boolean f1709l = true;

    /* renamed from: androidx.constraintlayout.utils.widget.ImageFilterButton$a */
    class C0400a extends ViewOutlineProvider {
        C0400a() {
        }

        public void getOutline(View view, Outline outline) {
            int width = ImageFilterButton.this.getWidth();
            int height = ImageFilterButton.this.getHeight();
            outline.setRoundRect(0, 0, width, height, (((float) Math.min(width, height)) * ImageFilterButton.this.f1702e) / 2.0f);
        }
    }

    public ImageFilterButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m1870c(attributeSet);
    }

    public ImageFilterButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        m1870c(attributeSet);
    }

    /* renamed from: c */
    private void m1870c(AttributeSet attributeSet) {
        setPadding(0, 0, 0, 0);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C0418e.f1996f);
            int indexCount = obtainStyledAttributes.getIndexCount();
            Drawable drawable = obtainStyledAttributes.getDrawable(0);
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 3) {
                    this.f1701d = obtainStyledAttributes.getFloat(index, 0.0f);
                } else if (index == 8) {
                    float f = obtainStyledAttributes.getFloat(index, 0.0f);
                    ImageFilterView.C0402b bVar = this.f1700c;
                    bVar.f1728g = f;
                    bVar.mo1991a(this);
                } else if (index == 7) {
                    float f2 = obtainStyledAttributes.getFloat(index, 0.0f);
                    ImageFilterView.C0402b bVar2 = this.f1700c;
                    bVar2.f1726e = f2;
                    bVar2.mo1991a(this);
                } else if (index == 2) {
                    float f3 = obtainStyledAttributes.getFloat(index, 0.0f);
                    ImageFilterView.C0402b bVar3 = this.f1700c;
                    bVar3.f1727f = f3;
                    bVar3.mo1991a(this);
                } else if (index == 5) {
                    float dimension = obtainStyledAttributes.getDimension(index, 0.0f);
                    if (Float.isNaN(dimension)) {
                        this.f1703f = dimension;
                        float f4 = this.f1702e;
                        this.f1702e = -1.0f;
                        mo1985d(f4);
                    } else {
                        boolean z = this.f1703f != dimension;
                        this.f1703f = dimension;
                        if (dimension != 0.0f) {
                            if (this.f1704g == null) {
                                this.f1704g = new Path();
                            }
                            if (this.f1706i == null) {
                                this.f1706i = new RectF();
                            }
                            if (this.f1705h == null) {
                                C0403a aVar = new C0403a(this);
                                this.f1705h = aVar;
                                setOutlineProvider(aVar);
                            }
                            setClipToOutline(true);
                            this.f1706i.set(0.0f, 0.0f, (float) getWidth(), (float) getHeight());
                            this.f1704g.reset();
                            Path path = this.f1704g;
                            RectF rectF = this.f1706i;
                            float f5 = this.f1703f;
                            path.addRoundRect(rectF, f5, f5, Path.Direction.CW);
                        } else {
                            setClipToOutline(false);
                        }
                        if (z) {
                            invalidateOutline();
                        }
                    }
                } else if (index == 6) {
                    mo1985d(obtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 4) {
                    this.f1709l = obtainStyledAttributes.getBoolean(index, this.f1709l);
                }
            }
            obtainStyledAttributes.recycle();
            if (drawable != null) {
                Drawable[] drawableArr = new Drawable[2];
                this.f1707j = drawableArr;
                drawableArr[0] = getDrawable();
                this.f1707j[1] = drawable;
                LayerDrawable layerDrawable = new LayerDrawable(this.f1707j);
                this.f1708k = layerDrawable;
                layerDrawable.getDrawable(1).setAlpha((int) (this.f1701d * 255.0f));
                super.setImageDrawable(this.f1708k);
            }
        }
    }

    /* renamed from: d */
    public void mo1985d(float f) {
        boolean z = this.f1702e != f;
        this.f1702e = f;
        if (f != 0.0f) {
            if (this.f1704g == null) {
                this.f1704g = new Path();
            }
            if (this.f1706i == null) {
                this.f1706i = new RectF();
            }
            if (this.f1705h == null) {
                C0400a aVar = new C0400a();
                this.f1705h = aVar;
                setOutlineProvider(aVar);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float min = (((float) Math.min(width, height)) * this.f1702e) / 2.0f;
            this.f1706i.set(0.0f, 0.0f, (float) width, (float) height);
            this.f1704g.reset();
            this.f1704g.addRoundRect(this.f1706i, min, min, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z) {
            invalidateOutline();
        }
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (0 != 0) {
            canvas.restore();
        }
    }
}
