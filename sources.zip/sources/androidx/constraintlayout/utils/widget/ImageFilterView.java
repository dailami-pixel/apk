package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Outline;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.constraintlayout.widget.C0418e;

public class ImageFilterView extends AppCompatImageView {

    /* renamed from: a */
    private C0402b f1711a = new C0402b();

    /* renamed from: b */
    private boolean f1712b = true;

    /* renamed from: c */
    private float f1713c = 0.0f;
    /* access modifiers changed from: private */

    /* renamed from: d */
    public float f1714d = 0.0f;
    /* access modifiers changed from: private */

    /* renamed from: e */
    public float f1715e = Float.NaN;

    /* renamed from: f */
    private Path f1716f;

    /* renamed from: g */
    ViewOutlineProvider f1717g;

    /* renamed from: h */
    RectF f1718h;

    /* renamed from: i */
    Drawable[] f1719i;

    /* renamed from: j */
    LayerDrawable f1720j;

    /* renamed from: androidx.constraintlayout.utils.widget.ImageFilterView$a */
    class C0401a extends ViewOutlineProvider {
        C0401a() {
        }

        public void getOutline(View view, Outline outline) {
            int width = ImageFilterView.this.getWidth();
            int height = ImageFilterView.this.getHeight();
            outline.setRoundRect(0, 0, width, height, (((float) Math.min(width, height)) * ImageFilterView.this.f1714d) / 2.0f);
        }
    }

    /* renamed from: androidx.constraintlayout.utils.widget.ImageFilterView$b */
    static class C0402b {

        /* renamed from: a */
        float[] f1722a = new float[20];

        /* renamed from: b */
        ColorMatrix f1723b = new ColorMatrix();

        /* renamed from: c */
        ColorMatrix f1724c = new ColorMatrix();

        /* renamed from: d */
        float f1725d = 1.0f;

        /* renamed from: e */
        float f1726e = 1.0f;

        /* renamed from: f */
        float f1727f = 1.0f;

        /* renamed from: g */
        float f1728g = 1.0f;

        C0402b() {
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo1991a(ImageView imageView) {
            boolean z;
            float f;
            float f2;
            float f3;
            float f4;
            this.f1723b.reset();
            float f5 = this.f1726e;
            boolean z2 = true;
            if (f5 != 1.0f) {
                float f6 = 1.0f - f5;
                float f7 = 0.2999f * f6;
                float f8 = 0.587f * f6;
                float f9 = f6 * 0.114f;
                float[] fArr = this.f1722a;
                fArr[0] = f7 + f5;
                fArr[1] = f8;
                fArr[2] = f9;
                fArr[3] = 0.0f;
                fArr[4] = 0.0f;
                fArr[5] = f7;
                fArr[6] = f8 + f5;
                fArr[7] = f9;
                fArr[8] = 0.0f;
                fArr[9] = 0.0f;
                fArr[10] = f7;
                fArr[11] = f8;
                fArr[12] = f9 + f5;
                fArr[13] = 0.0f;
                fArr[14] = 0.0f;
                fArr[15] = 0.0f;
                fArr[16] = 0.0f;
                fArr[17] = 0.0f;
                f = 1.0f;
                fArr[18] = 1.0f;
                fArr[19] = 0.0f;
                this.f1723b.set(fArr);
                z = true;
            } else {
                f = 1.0f;
                z = false;
            }
            float f10 = this.f1727f;
            if (f10 != f) {
                this.f1724c.setScale(f10, f10, f10, f);
                this.f1723b.postConcat(this.f1724c);
                z = true;
            }
            float f11 = this.f1728g;
            if (f11 != f) {
                if (f11 <= 0.0f) {
                    f11 = 0.01f;
                }
                float f12 = (5000.0f / f11) / 100.0f;
                if (f12 > 66.0f) {
                    double d = (double) (f12 - 60.0f);
                    f4 = ((float) Math.pow(d, 0.07551484555006027d)) * 288.12216f;
                    f3 = ((float) Math.pow(d, -0.13320475816726685d)) * 329.69873f;
                } else {
                    f4 = (((float) Math.log((double) f12)) * 99.4708f) - 161.11957f;
                    f3 = 255.0f;
                }
                float log = f12 < 66.0f ? f12 > 19.0f ? (((float) Math.log((double) (f12 - 10.0f))) * 138.51773f) - 305.0448f : 0.0f : 255.0f;
                float min = Math.min(255.0f, Math.max(f3, 0.0f));
                float min2 = Math.min(255.0f, Math.max(f4, 0.0f));
                float min3 = Math.min(255.0f, Math.max(log, 0.0f));
                float min4 = Math.min(255.0f, Math.max(255.0f, 0.0f));
                float min5 = Math.min(255.0f, Math.max((((float) Math.log((double) 50.0f)) * 99.4708f) - 161.11957f, 0.0f));
                float min6 = min3 / Math.min(255.0f, Math.max((((float) Math.log((double) 40.0f)) * 138.51773f) - 305.0448f, 0.0f));
                float[] fArr2 = this.f1722a;
                fArr2[0] = min / min4;
                fArr2[1] = 0.0f;
                fArr2[2] = 0.0f;
                fArr2[3] = 0.0f;
                fArr2[4] = 0.0f;
                fArr2[5] = 0.0f;
                fArr2[6] = min2 / min5;
                fArr2[7] = 0.0f;
                fArr2[8] = 0.0f;
                fArr2[9] = 0.0f;
                fArr2[10] = 0.0f;
                fArr2[11] = 0.0f;
                fArr2[12] = min6;
                fArr2[13] = 0.0f;
                fArr2[14] = 0.0f;
                fArr2[15] = 0.0f;
                fArr2[16] = 0.0f;
                fArr2[17] = 0.0f;
                f2 = 1.0f;
                fArr2[18] = 1.0f;
                fArr2[19] = 0.0f;
                this.f1724c.set(fArr2);
                this.f1723b.postConcat(this.f1724c);
                z = true;
            } else {
                f2 = 1.0f;
            }
            float f13 = this.f1725d;
            if (f13 != f2) {
                float[] fArr3 = this.f1722a;
                fArr3[0] = f13;
                fArr3[1] = 0.0f;
                fArr3[2] = 0.0f;
                fArr3[3] = 0.0f;
                fArr3[4] = 0.0f;
                fArr3[5] = 0.0f;
                fArr3[6] = f13;
                fArr3[7] = 0.0f;
                fArr3[8] = 0.0f;
                fArr3[9] = 0.0f;
                fArr3[10] = 0.0f;
                fArr3[11] = 0.0f;
                fArr3[12] = f13;
                fArr3[13] = 0.0f;
                fArr3[14] = 0.0f;
                fArr3[15] = 0.0f;
                fArr3[16] = 0.0f;
                fArr3[17] = 0.0f;
                fArr3[18] = 1.0f;
                fArr3[19] = 0.0f;
                this.f1724c.set(fArr3);
                this.f1723b.postConcat(this.f1724c);
            } else {
                z2 = z;
            }
            if (z2) {
                imageView.setColorFilter(new ColorMatrixColorFilter(this.f1723b));
                return;
            }
            ImageView imageView2 = imageView;
            imageView.clearColorFilter();
        }
    }

    public ImageFilterView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(attributeSet);
    }

    public ImageFilterView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(attributeSet);
    }

    private void init(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C0418e.f1996f);
            int indexCount = obtainStyledAttributes.getIndexCount();
            Drawable drawable = obtainStyledAttributes.getDrawable(0);
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 3) {
                    this.f1713c = obtainStyledAttributes.getFloat(index, 0.0f);
                } else if (index == 8) {
                    float f = obtainStyledAttributes.getFloat(index, 0.0f);
                    C0402b bVar = this.f1711a;
                    bVar.f1728g = f;
                    bVar.mo1991a(this);
                } else if (index == 7) {
                    float f2 = obtainStyledAttributes.getFloat(index, 0.0f);
                    C0402b bVar2 = this.f1711a;
                    bVar2.f1726e = f2;
                    bVar2.mo1991a(this);
                } else if (index == 2) {
                    float f3 = obtainStyledAttributes.getFloat(index, 0.0f);
                    C0402b bVar3 = this.f1711a;
                    bVar3.f1727f = f3;
                    bVar3.mo1991a(this);
                } else if (index == 5) {
                    float dimension = obtainStyledAttributes.getDimension(index, 0.0f);
                    if (Float.isNaN(dimension)) {
                        this.f1715e = dimension;
                        float f4 = this.f1714d;
                        this.f1714d = -1.0f;
                        mo1989f(f4);
                    } else {
                        boolean z = this.f1715e != dimension;
                        this.f1715e = dimension;
                        if (dimension != 0.0f) {
                            if (this.f1716f == null) {
                                this.f1716f = new Path();
                            }
                            if (this.f1718h == null) {
                                this.f1718h = new RectF();
                            }
                            if (this.f1717g == null) {
                                C0404b bVar4 = new C0404b(this);
                                this.f1717g = bVar4;
                                setOutlineProvider(bVar4);
                            }
                            setClipToOutline(true);
                            this.f1718h.set(0.0f, 0.0f, (float) getWidth(), (float) getHeight());
                            this.f1716f.reset();
                            Path path = this.f1716f;
                            RectF rectF = this.f1718h;
                            float f5 = this.f1715e;
                            path.addRoundRect(rectF, f5, f5, Path.Direction.CW);
                        } else {
                            setClipToOutline(false);
                        }
                        if (z) {
                            invalidateOutline();
                        }
                    }
                } else if (index == 6) {
                    mo1989f(obtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 4) {
                    this.f1712b = obtainStyledAttributes.getBoolean(index, this.f1712b);
                }
            }
            obtainStyledAttributes.recycle();
            if (drawable != null) {
                Drawable[] drawableArr = new Drawable[2];
                this.f1719i = drawableArr;
                drawableArr[0] = getDrawable();
                this.f1719i[1] = drawable;
                LayerDrawable layerDrawable = new LayerDrawable(this.f1719i);
                this.f1720j = layerDrawable;
                layerDrawable.getDrawable(1).setAlpha((int) (this.f1713c * 255.0f));
                super.setImageDrawable(this.f1720j);
            }
        }
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (0 != 0) {
            canvas.restore();
        }
    }

    /* renamed from: f */
    public void mo1989f(float f) {
        boolean z = this.f1714d != f;
        this.f1714d = f;
        if (f != 0.0f) {
            if (this.f1716f == null) {
                this.f1716f = new Path();
            }
            if (this.f1718h == null) {
                this.f1718h = new RectF();
            }
            if (this.f1717g == null) {
                C0401a aVar = new C0401a();
                this.f1717g = aVar;
                setOutlineProvider(aVar);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float min = (((float) Math.min(width, height)) * this.f1714d) / 2.0f;
            this.f1718h.set(0.0f, 0.0f, (float) width, (float) height);
            this.f1716f.reset();
            this.f1716f.addRoundRect(this.f1718h, min, min, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z) {
            invalidateOutline();
        }
    }
}
