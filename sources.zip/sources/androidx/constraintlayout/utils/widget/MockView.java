package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.widget.C0418e;

public class MockView extends View {

    /* renamed from: a */
    private Paint f1729a = new Paint();

    /* renamed from: b */
    private Paint f1730b = new Paint();

    /* renamed from: c */
    private Paint f1731c = new Paint();

    /* renamed from: d */
    private boolean f1732d = true;

    /* renamed from: e */
    private boolean f1733e = true;

    /* renamed from: f */
    protected String f1734f = null;

    /* renamed from: g */
    private Rect f1735g = new Rect();

    /* renamed from: h */
    private int f1736h = Color.argb(255, 0, 0, 0);

    /* renamed from: i */
    private int f1737i = Color.argb(255, 200, 200, 200);

    /* renamed from: j */
    private int f1738j = Color.argb(255, 50, 50, 50);

    /* renamed from: k */
    private int f1739k = 4;

    public MockView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m1876a(context, attributeSet);
    }

    public MockView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        m1876a(context, attributeSet);
    }

    /* renamed from: a */
    private void m1876a(Context context, AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0418e.f2003m);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 1) {
                    this.f1734f = obtainStyledAttributes.getString(index);
                } else if (index == 4) {
                    this.f1732d = obtainStyledAttributes.getBoolean(index, this.f1732d);
                } else if (index == 0) {
                    this.f1736h = obtainStyledAttributes.getColor(index, this.f1736h);
                } else if (index == 2) {
                    this.f1738j = obtainStyledAttributes.getColor(index, this.f1738j);
                } else if (index == 3) {
                    this.f1737i = obtainStyledAttributes.getColor(index, this.f1737i);
                } else if (index == 5) {
                    this.f1733e = obtainStyledAttributes.getBoolean(index, this.f1733e);
                }
            }
        }
        if (this.f1734f == null) {
            try {
                this.f1734f = context.getResources().getResourceEntryName(getId());
            } catch (Exception unused) {
            }
        }
        this.f1729a.setColor(this.f1736h);
        this.f1729a.setAntiAlias(true);
        this.f1730b.setColor(this.f1737i);
        this.f1730b.setAntiAlias(true);
        this.f1731c.setColor(this.f1738j);
        this.f1739k = Math.round((getResources().getDisplayMetrics().xdpi / 160.0f) * ((float) this.f1739k));
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (this.f1732d) {
            width--;
            height--;
            float f = (float) width;
            float f2 = (float) height;
            canvas.drawLine(0.0f, 0.0f, f, f2, this.f1729a);
            Canvas canvas2 = canvas;
            float f3 = f;
            canvas2.drawLine(0.0f, f2, f3, 0.0f, this.f1729a);
            canvas2.drawLine(0.0f, 0.0f, f3, 0.0f, this.f1729a);
            float f4 = f;
            float f5 = f2;
            canvas2.drawLine(f4, 0.0f, f3, f5, this.f1729a);
            float f6 = f2;
            canvas2.drawLine(f4, f6, 0.0f, f5, this.f1729a);
            canvas2.drawLine(0.0f, f6, 0.0f, 0.0f, this.f1729a);
        }
        String str = this.f1734f;
        if (str != null && this.f1733e) {
            this.f1730b.getTextBounds(str, 0, str.length(), this.f1735g);
            float width2 = ((float) (width - this.f1735g.width())) / 2.0f;
            float height2 = (((float) (height - this.f1735g.height())) / 2.0f) + ((float) this.f1735g.height());
            this.f1735g.offset((int) width2, (int) height2);
            Rect rect = this.f1735g;
            int i = rect.left;
            int i2 = this.f1739k;
            rect.set(i - i2, rect.top - i2, rect.right + i2, rect.bottom + i2);
            canvas.drawRect(this.f1735g, this.f1731c);
            canvas.drawText(this.f1734f, width2, height2, this.f1730b);
        }
    }
}
