package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.ViewParent;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.constraintlayout.widget.C0418e;

public class MotionTelltales extends MockView {

    /* renamed from: l */
    private Paint f1740l = new Paint();

    /* renamed from: m */
    MotionLayout f1741m;

    /* renamed from: n */
    float[] f1742n = new float[2];

    /* renamed from: o */
    Matrix f1743o = new Matrix();

    /* renamed from: p */
    int f1744p = 0;

    /* renamed from: q */
    int f1745q = -65281;

    /* renamed from: r */
    float f1746r = 0.25f;

    public MotionTelltales(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m1877a(context, attributeSet);
    }

    public MotionTelltales(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        m1877a(context, attributeSet);
    }

    /* renamed from: a */
    private void m1877a(Context context, AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0418e.f2008r);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 0) {
                    this.f1745q = obtainStyledAttributes.getColor(index, this.f1745q);
                } else if (index == 2) {
                    this.f1744p = obtainStyledAttributes.getInt(index, this.f1744p);
                } else if (index == 1) {
                    this.f1746r = obtainStyledAttributes.getFloat(index, this.f1746r);
                }
            }
        }
        this.f1740l.setColor(this.f1745q);
        this.f1740l.setStrokeWidth(5.0f);
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        getMatrix().invert(this.f1743o);
        if (this.f1741m == null) {
            ViewParent parent = getParent();
            if (parent instanceof MotionLayout) {
                this.f1741m = (MotionLayout) parent;
                return;
            }
            return;
        }
        int width = getWidth();
        int height = getHeight();
        float[] fArr = {0.1f, 0.25f, 0.5f, 0.75f, 0.9f};
        for (int i = 0; i < 5; i++) {
            float f = fArr[i];
            for (int i2 = 0; i2 < 5; i2++) {
                float f2 = fArr[i2];
                this.f1741m.mo1840a0(this, f2, f, this.f1742n, this.f1744p);
                this.f1743o.mapVectors(this.f1742n);
                float f3 = ((float) width) * f2;
                float f4 = ((float) height) * f;
                float[] fArr2 = this.f1742n;
                float f5 = fArr2[0];
                float f6 = this.f1746r;
                float f7 = f4 - (fArr2[1] * f6);
                this.f1743o.mapVectors(fArr2);
                canvas.drawLine(f3, f4, f3 - (f5 * f6), f7, this.f1740l);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        postInvalidate();
    }
}
