package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseArray;
import androidx.constraintlayout.widget.C0411c;
import androidx.constraintlayout.widget.ConstraintLayout;
import p098d.p113e.p116b.p117i.C4657a;
import p098d.p113e.p116b.p117i.C4662e;
import p098d.p113e.p116b.p117i.C4664f;
import p098d.p113e.p116b.p117i.C4669j;

public class Barrier extends ConstraintHelper {

    /* renamed from: h */
    private int f1749h;

    /* renamed from: i */
    private int f1750i;

    /* renamed from: j */
    private C4657a f1751j;

    public Barrier(Context context) {
        super(context);
        super.setVisibility(8);
    }

    public Barrier(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        super.setVisibility(8);
    }

    public Barrier(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        super.setVisibility(8);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x000f, code lost:
        if (r6 == 6) goto L_0x0016;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0019, code lost:
        if (r6 == 6) goto L_0x000c;
     */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0020  */
    /* JADX WARNING: Removed duplicated region for block: B:14:? A[RETURN, SYNTHETIC] */
    /* renamed from: C */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m1878C(p098d.p113e.p116b.p117i.C4662e r4, int r5, boolean r6) {
        /*
            r3 = this;
            r3.f1750i = r5
            r5 = 1
            r0 = 0
            r1 = 6
            r2 = 5
            if (r6 == 0) goto L_0x0012
            int r6 = r3.f1749h
            if (r6 != r2) goto L_0x000f
        L_0x000c:
            r3.f1750i = r5
            goto L_0x001c
        L_0x000f:
            if (r6 != r1) goto L_0x001c
            goto L_0x0016
        L_0x0012:
            int r6 = r3.f1749h
            if (r6 != r2) goto L_0x0019
        L_0x0016:
            r3.f1750i = r0
            goto L_0x001c
        L_0x0019:
            if (r6 != r1) goto L_0x001c
            goto L_0x000c
        L_0x001c:
            boolean r5 = r4 instanceof p098d.p113e.p116b.p117i.C4657a
            if (r5 == 0) goto L_0x0027
            d.e.b.i.a r4 = (p098d.p113e.p116b.p117i.C4657a) r4
            int r5 = r3.f1750i
            r4.mo21581x0(r5)
        L_0x0027:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.Barrier.m1878C(d.e.b.i.e, int, boolean):void");
    }

    /* renamed from: A */
    public void mo1997A(int i) {
        this.f1751j.mo21582y0(i);
    }

    /* renamed from: B */
    public void mo1998B(int i) {
        this.f1749h = i;
    }

    /* access modifiers changed from: protected */
    /* renamed from: l */
    public void mo1809l(AttributeSet attributeSet) {
        super.mo1809l(attributeSet);
        this.f1751j = new C4657a();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C0418e.f1992b);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 15) {
                    this.f1749h = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 14) {
                    this.f1751j.mo21580w0(obtainStyledAttributes.getBoolean(index, true));
                } else if (index == 16) {
                    this.f1751j.mo21582y0(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                }
            }
        }
        this.f1755d = this.f1751j;
        mo2012v();
    }

    /* renamed from: m */
    public void mo1810m(C0411c.C0412a aVar, C4669j jVar, ConstraintLayout.LayoutParams layoutParams, SparseArray<C4662e> sparseArray) {
        super.mo1810m(aVar, jVar, layoutParams, sparseArray);
        if (jVar instanceof C4657a) {
            C4657a aVar2 = (C4657a) jVar;
            m1878C(aVar2, aVar.f1898d.f1932c0, ((C4664f) jVar.f16885M).mo21669y0());
            aVar2.mo21580w0(aVar.f1898d.f1948k0);
            aVar2.mo21582y0(aVar.f1898d.f1934d0);
        }
    }

    /* renamed from: n */
    public void mo1811n(C4662e eVar, boolean z) {
        m1878C(eVar, this.f1749h, z);
    }

    /* renamed from: w */
    public boolean mo1999w() {
        return this.f1751j.mo21575s0();
    }

    /* renamed from: x */
    public int mo2000x() {
        return this.f1751j.mo21578u0();
    }

    /* renamed from: y */
    public int mo2001y() {
        return this.f1749h;
    }

    /* renamed from: z */
    public void mo2002z(boolean z) {
        this.f1751j.mo21580w0(z);
    }
}
