package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import android.view.View;
import androidx.constraintlayout.motion.widget.C0361n;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParser;
import p098d.p099a.C4567a;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.constraintlayout.widget.a */
public class C0407a {

    /* renamed from: a */
    String f1867a;

    /* renamed from: b */
    private int f1868b;

    /* renamed from: c */
    private int f1869c;

    /* renamed from: d */
    private float f1870d;

    /* renamed from: e */
    private String f1871e;

    /* renamed from: f */
    boolean f1872f;

    /* renamed from: g */
    private int f1873g;

    public C0407a(C0407a aVar, Object obj) {
        this.f1867a = aVar.f1867a;
        this.f1868b = aVar.f1868b;
        mo2059i(obj);
    }

    public C0407a(String str, int i, Object obj) {
        this.f1867a = str;
        this.f1868b = i;
        mo2059i(obj);
    }

    /* renamed from: a */
    private static int m1933a(int i) {
        int i2 = (i & (~(i >> 31))) - 255;
        return (i2 & (i2 >> 31)) + 255;
    }

    /* renamed from: f */
    public static void m1934f(Context context, XmlPullParser xmlPullParser, HashMap<String, C0407a> hashMap) {
        int i;
        float f;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), C0418e.f1995e);
        int indexCount = obtainStyledAttributes.getIndexCount();
        String str = null;
        Object obj = null;
        int i2 = 0;
        for (int i3 = 0; i3 < indexCount; i3++) {
            int index = obtainStyledAttributes.getIndex(i3);
            int i4 = 1;
            if (index == 0) {
                str = obtainStyledAttributes.getString(index);
                if (str != null && str.length() > 0) {
                    str = Character.toUpperCase(str.charAt(0)) + str.substring(1);
                }
            } else if (index == 1) {
                obj = Boolean.valueOf(obtainStyledAttributes.getBoolean(index, false));
                i2 = 6;
            } else {
                if (index == 3) {
                    i4 = 3;
                } else if (index == 2) {
                    i4 = 4;
                } else {
                    if (index == 7) {
                        f = TypedValue.applyDimension(1, obtainStyledAttributes.getDimension(index, 0.0f), context.getResources().getDisplayMetrics());
                    } else if (index == 4) {
                        f = obtainStyledAttributes.getDimension(index, 0.0f);
                    } else if (index == 5) {
                        obj = Float.valueOf(obtainStyledAttributes.getFloat(index, Float.NaN));
                        i2 = 2;
                    } else if (index == 6) {
                        i = obtainStyledAttributes.getInteger(index, -1);
                        obj = Integer.valueOf(i);
                        i2 = i4;
                    } else if (index == 8) {
                        obj = obtainStyledAttributes.getString(index);
                        i2 = 5;
                    }
                    obj = Float.valueOf(f);
                    i2 = 7;
                }
                i = obtainStyledAttributes.getColor(index, 0);
                obj = Integer.valueOf(i);
                i2 = i4;
            }
        }
        if (!(str == null || obj == null)) {
            hashMap.put(str, new C0407a(str, i2, obj));
        }
        obtainStyledAttributes.recycle();
    }

    /* renamed from: g */
    public static void m1935g(View view, HashMap<String, C0407a> hashMap) {
        Class<?> cls = view.getClass();
        for (String next : hashMap.keySet()) {
            C0407a aVar = hashMap.get(next);
            String v = C4924a.m17907v("set", next);
            try {
                switch (C0361n.m1729i(aVar.f1868b)) {
                    case 0:
                        cls.getMethod(v, new Class[]{Integer.TYPE}).invoke(view, new Object[]{Integer.valueOf(aVar.f1869c)});
                        break;
                    case 1:
                        cls.getMethod(v, new Class[]{Float.TYPE}).invoke(view, new Object[]{Float.valueOf(aVar.f1870d)});
                        break;
                    case 2:
                        cls.getMethod(v, new Class[]{Integer.TYPE}).invoke(view, new Object[]{Integer.valueOf(aVar.f1873g)});
                        break;
                    case 3:
                        Method method = cls.getMethod(v, new Class[]{Drawable.class});
                        ColorDrawable colorDrawable = new ColorDrawable();
                        colorDrawable.setColor(aVar.f1873g);
                        method.invoke(view, new Object[]{colorDrawable});
                        break;
                    case 4:
                        cls.getMethod(v, new Class[]{CharSequence.class}).invoke(view, new Object[]{aVar.f1871e});
                        break;
                    case 5:
                        cls.getMethod(v, new Class[]{Boolean.TYPE}).invoke(view, new Object[]{Boolean.valueOf(aVar.f1872f)});
                        break;
                    case 6:
                        cls.getMethod(v, new Class[]{Float.TYPE}).invoke(view, new Object[]{Float.valueOf(aVar.f1870d)});
                        break;
                }
            } catch (NoSuchMethodException e) {
                Log.e("TransitionLayout", e.getMessage());
                Log.e("TransitionLayout", " Custom Attribute \"" + next + "\" not found on " + cls.getName());
                StringBuilder sb = new StringBuilder();
                sb.append(cls.getName());
                sb.append(" must have a method ");
                sb.append(v);
                Log.e("TransitionLayout", sb.toString());
            } catch (IllegalAccessException e2) {
                StringBuilder U = C4924a.m17868U(" Custom Attribute \"", next, "\" not found on ");
                U.append(cls.getName());
                Log.e("TransitionLayout", U.toString());
                e2.printStackTrace();
            } catch (InvocationTargetException e3) {
                StringBuilder U2 = C4924a.m17868U(" Custom Attribute \"", next, "\" not found on ");
                U2.append(cls.getName());
                Log.e("TransitionLayout", U2.toString());
                e3.printStackTrace();
            }
        }
    }

    /* renamed from: b */
    public int mo2054b() {
        return this.f1868b;
    }

    /* renamed from: c */
    public float mo2055c() {
        switch (C0361n.m1729i(this.f1868b)) {
            case 0:
                return (float) this.f1869c;
            case 1:
                return this.f1870d;
            case 2:
            case 3:
                throw new RuntimeException("Color does not have a single color to interpolate");
            case 4:
                throw new RuntimeException("Cannot interpolate String");
            case 5:
                return this.f1872f ? 0.0f : 1.0f;
            case 6:
                return this.f1870d;
            default:
                return Float.NaN;
        }
    }

    /* renamed from: d */
    public void mo2056d(float[] fArr) {
        switch (C0361n.m1729i(this.f1868b)) {
            case 0:
                fArr[0] = (float) this.f1869c;
                return;
            case 1:
                fArr[0] = this.f1870d;
                return;
            case 2:
            case 3:
                int i = this.f1873g;
                float pow = (float) Math.pow((double) (((float) ((i >> 16) & 255)) / 255.0f), 2.2d);
                float pow2 = (float) Math.pow((double) (((float) ((i >> 8) & 255)) / 255.0f), 2.2d);
                fArr[0] = pow;
                fArr[1] = pow2;
                fArr[2] = (float) Math.pow((double) (((float) (i & 255)) / 255.0f), 2.2d);
                fArr[3] = ((float) ((i >> 24) & 255)) / 255.0f;
                return;
            case 4:
                throw new RuntimeException("Color does not have a single color to interpolate");
            case 5:
                fArr[0] = this.f1872f ? 0.0f : 1.0f;
                return;
            case 6:
                fArr[0] = this.f1870d;
                return;
            default:
                return;
        }
    }

    /* renamed from: e */
    public int mo2057e() {
        int i = C0361n.m1729i(this.f1868b);
        return (i == 2 || i == 3) ? 4 : 1;
    }

    /* renamed from: h */
    public void mo2058h(View view, float[] fArr) {
        View view2 = view;
        Class<?> cls = view.getClass();
        StringBuilder P = C4924a.m17863P("set");
        P.append(this.f1867a);
        String sb = P.toString();
        try {
            boolean z = true;
            switch (C0361n.m1729i(this.f1868b)) {
                case 0:
                    cls.getMethod(sb, new Class[]{Integer.TYPE}).invoke(view2, new Object[]{Integer.valueOf((int) fArr[0])});
                    return;
                case 1:
                    cls.getMethod(sb, new Class[]{Float.TYPE}).invoke(view2, new Object[]{Float.valueOf(fArr[0])});
                    return;
                case 2:
                    Method method = cls.getMethod(sb, new Class[]{Integer.TYPE});
                    int a = m1933a((int) (((float) Math.pow((double) fArr[0], 0.45454545454545453d)) * 255.0f));
                    int a2 = m1933a((int) (((float) Math.pow((double) fArr[1], 0.45454545454545453d)) * 255.0f));
                    method.invoke(view2, new Object[]{Integer.valueOf((a << 16) | (m1933a((int) (fArr[3] * 255.0f)) << 24) | (a2 << 8) | m1933a((int) (((float) Math.pow((double) fArr[2], 0.45454545454545453d)) * 255.0f)))});
                    return;
                case 3:
                    Method method2 = cls.getMethod(sb, new Class[]{Drawable.class});
                    int a3 = m1933a((int) (((float) Math.pow((double) fArr[0], 0.45454545454545453d)) * 255.0f));
                    int a4 = m1933a((int) (((float) Math.pow((double) fArr[1], 0.45454545454545453d)) * 255.0f));
                    int a5 = (a3 << 16) | (m1933a((int) (fArr[3] * 255.0f)) << 24) | (a4 << 8) | m1933a((int) (((float) Math.pow((double) fArr[2], 0.45454545454545453d)) * 255.0f));
                    ColorDrawable colorDrawable = new ColorDrawable();
                    colorDrawable.setColor(a5);
                    method2.invoke(view2, new Object[]{colorDrawable});
                    return;
                case 4:
                    throw new RuntimeException("unable to interpolate strings " + this.f1867a);
                case 5:
                    Method method3 = cls.getMethod(sb, new Class[]{Boolean.TYPE});
                    Object[] objArr = new Object[1];
                    if (fArr[0] <= 0.5f) {
                        z = false;
                    }
                    objArr[0] = Boolean.valueOf(z);
                    method3.invoke(view2, objArr);
                    return;
                case 6:
                    cls.getMethod(sb, new Class[]{Float.TYPE}).invoke(view2, new Object[]{Float.valueOf(fArr[0])});
                    return;
                default:
                    return;
            }
        } catch (NoSuchMethodException e) {
            StringBuilder U = C4924a.m17868U("no method ", sb, "on View \"");
            U.append(C4567a.m16428c(view));
            U.append("\"");
            Log.e("TransitionLayout", U.toString());
            e.printStackTrace();
        } catch (IllegalAccessException e2) {
            StringBuilder U2 = C4924a.m17868U("cannot access method ", sb, "on View \"");
            U2.append(C4567a.m16428c(view));
            U2.append("\"");
            Log.e("TransitionLayout", U2.toString());
            e2.printStackTrace();
        } catch (InvocationTargetException e3) {
            e3.printStackTrace();
        }
    }

    /* renamed from: i */
    public void mo2059i(Object obj) {
        switch (C0361n.m1729i(this.f1868b)) {
            case 0:
                this.f1869c = ((Integer) obj).intValue();
                return;
            case 1:
            case 6:
                this.f1870d = ((Float) obj).floatValue();
                return;
            case 2:
            case 3:
                this.f1873g = ((Integer) obj).intValue();
                return;
            case 4:
                this.f1871e = (String) obj;
                return;
            case 5:
                this.f1872f = ((Boolean) obj).booleanValue();
                return;
            default:
                return;
        }
    }
}
