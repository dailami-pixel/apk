package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.Log;
import android.util.SparseArray;
import android.util.Xml;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;

/* renamed from: androidx.constraintlayout.widget.b */
public class C0408b {

    /* renamed from: a */
    private final ConstraintLayout f1874a;

    /* renamed from: b */
    int f1875b = -1;

    /* renamed from: c */
    int f1876c = -1;

    /* renamed from: d */
    private SparseArray<C0409a> f1877d = new SparseArray<>();

    /* renamed from: e */
    private SparseArray<C0411c> f1878e = new SparseArray<>();

    /* renamed from: androidx.constraintlayout.widget.b$a */
    static class C0409a {

        /* renamed from: a */
        int f1879a;

        /* renamed from: b */
        ArrayList<C0410b> f1880b = new ArrayList<>();

        /* renamed from: c */
        int f1881c = -1;

        /* renamed from: d */
        C0411c f1882d;

        public C0409a(Context context, XmlPullParser xmlPullParser) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), C0418e.f2012v);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 0) {
                    this.f1879a = obtainStyledAttributes.getResourceId(index, this.f1879a);
                } else if (index == 1) {
                    this.f1881c = obtainStyledAttributes.getResourceId(index, this.f1881c);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.f1881c);
                    context.getResources().getResourceName(this.f1881c);
                    if ("layout".equals(resourceTypeName)) {
                        C0411c cVar = new C0411c();
                        this.f1882d = cVar;
                        cVar.mo2068g(context, this.f1881c);
                    }
                }
            }
            obtainStyledAttributes.recycle();
        }

        /* renamed from: a */
        public int mo2061a(float f, float f2) {
            for (int i = 0; i < this.f1880b.size(); i++) {
                if (this.f1880b.get(i).mo2062a(f, f2)) {
                    return i;
                }
            }
            return -1;
        }
    }

    /* renamed from: androidx.constraintlayout.widget.b$b */
    static class C0410b {

        /* renamed from: a */
        float f1883a = Float.NaN;

        /* renamed from: b */
        float f1884b = Float.NaN;

        /* renamed from: c */
        float f1885c = Float.NaN;

        /* renamed from: d */
        float f1886d = Float.NaN;

        /* renamed from: e */
        int f1887e = -1;

        /* renamed from: f */
        C0411c f1888f;

        public C0410b(Context context, XmlPullParser xmlPullParser) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), C0418e.f2016z);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 0) {
                    this.f1887e = obtainStyledAttributes.getResourceId(index, this.f1887e);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.f1887e);
                    context.getResources().getResourceName(this.f1887e);
                    if ("layout".equals(resourceTypeName)) {
                        C0411c cVar = new C0411c();
                        this.f1888f = cVar;
                        cVar.mo2068g(context, this.f1887e);
                    }
                } else if (index == 1) {
                    this.f1886d = obtainStyledAttributes.getDimension(index, this.f1886d);
                } else if (index == 2) {
                    this.f1884b = obtainStyledAttributes.getDimension(index, this.f1884b);
                } else if (index == 3) {
                    this.f1885c = obtainStyledAttributes.getDimension(index, this.f1885c);
                } else if (index == 4) {
                    this.f1883a = obtainStyledAttributes.getDimension(index, this.f1883a);
                } else {
                    Log.v("ConstraintLayoutStates", "Unknown tag");
                }
            }
            obtainStyledAttributes.recycle();
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public boolean mo2062a(float f, float f2) {
            if (!Float.isNaN(this.f1883a) && f < this.f1883a) {
                return false;
            }
            if (!Float.isNaN(this.f1884b) && f2 < this.f1884b) {
                return false;
            }
            if (Float.isNaN(this.f1885c) || f <= this.f1885c) {
                return Float.isNaN(this.f1886d) || f2 <= this.f1886d;
            }
            return false;
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    C0408b(android.content.Context r8, androidx.constraintlayout.widget.ConstraintLayout r9, int r10) {
        /*
            r7 = this;
            r7.<init>()
            r0 = -1
            r7.f1875b = r0
            r7.f1876c = r0
            android.util.SparseArray r1 = new android.util.SparseArray
            r1.<init>()
            r7.f1877d = r1
            android.util.SparseArray r1 = new android.util.SparseArray
            r1.<init>()
            r7.f1878e = r1
            r7.f1874a = r9
            android.content.res.Resources r9 = r8.getResources()
            android.content.res.XmlResourceParser r9 = r9.getXml(r10)
            int r10 = r9.getEventType()     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            r1 = 0
        L_0x0025:
            r2 = 1
            if (r10 == r2) goto L_0x00c2
            if (r10 == 0) goto L_0x00b0
            r3 = 2
            if (r10 == r3) goto L_0x002f
            goto L_0x00b3
        L_0x002f:
            java.lang.String r10 = r9.getName()     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            int r4 = r10.hashCode()     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            r5 = 4
            r6 = 3
            switch(r4) {
                case -1349929691: goto L_0x0065;
                case 80204913: goto L_0x005b;
                case 1382829617: goto L_0x0051;
                case 1657696882: goto L_0x0047;
                case 1901439077: goto L_0x003d;
                default: goto L_0x003c;
            }     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
        L_0x003c:
            goto L_0x006f
        L_0x003d:
            java.lang.String r4 = "Variant"
            boolean r4 = r10.equals(r4)     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            if (r4 == 0) goto L_0x006f
            r4 = 3
            goto L_0x0070
        L_0x0047:
            java.lang.String r4 = "layoutDescription"
            boolean r4 = r10.equals(r4)     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            if (r4 == 0) goto L_0x006f
            r4 = 0
            goto L_0x0070
        L_0x0051:
            java.lang.String r4 = "StateSet"
            boolean r4 = r10.equals(r4)     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            if (r4 == 0) goto L_0x006f
            r4 = 1
            goto L_0x0070
        L_0x005b:
            java.lang.String r4 = "State"
            boolean r4 = r10.equals(r4)     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            if (r4 == 0) goto L_0x006f
            r4 = 2
            goto L_0x0070
        L_0x0065:
            java.lang.String r4 = "ConstraintSet"
            boolean r4 = r10.equals(r4)     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            if (r4 == 0) goto L_0x006f
            r4 = 4
            goto L_0x0070
        L_0x006f:
            r4 = -1
        L_0x0070:
            if (r4 == 0) goto L_0x00b3
            if (r4 == r2) goto L_0x00b3
            if (r4 == r3) goto L_0x00a2
            if (r4 == r6) goto L_0x0095
            if (r4 == r5) goto L_0x0091
            java.lang.String r2 = "ConstraintLayoutStates"
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            r3.<init>()     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            java.lang.String r4 = "unknown tag "
            r3.append(r4)     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            r3.append(r10)     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            java.lang.String r10 = r3.toString()     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            android.util.Log.v(r2, r10)     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            goto L_0x00b3
        L_0x0091:
            r7.m1942a(r8, r9)     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            goto L_0x00b3
        L_0x0095:
            androidx.constraintlayout.widget.b$b r10 = new androidx.constraintlayout.widget.b$b     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            r10.<init>(r8, r9)     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            if (r1 == 0) goto L_0x00b3
            java.util.ArrayList<androidx.constraintlayout.widget.b$b> r2 = r1.f1880b     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            r2.add(r10)     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            goto L_0x00b3
        L_0x00a2:
            androidx.constraintlayout.widget.b$a r10 = new androidx.constraintlayout.widget.b$a     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            r10.<init>(r8, r9)     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            android.util.SparseArray<androidx.constraintlayout.widget.b$a> r1 = r7.f1877d     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            int r2 = r10.f1879a     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            r1.put(r2, r10)     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            r1 = r10
            goto L_0x00b3
        L_0x00b0:
            r9.getName()     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
        L_0x00b3:
            int r10 = r9.next()     // Catch:{ XmlPullParserException -> 0x00be, IOException -> 0x00b9 }
            goto L_0x0025
        L_0x00b9:
            r8 = move-exception
            r8.printStackTrace()
            goto L_0x00c2
        L_0x00be:
            r8 = move-exception
            r8.printStackTrace()
        L_0x00c2:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.C0408b.<init>(android.content.Context, androidx.constraintlayout.widget.ConstraintLayout, int):void");
    }

    /* renamed from: a */
    private void m1942a(Context context, XmlPullParser xmlPullParser) {
        int i;
        C0411c cVar = new C0411c();
        int attributeCount = xmlPullParser.getAttributeCount();
        for (int i2 = 0; i2 < attributeCount; i2++) {
            if ("id".equals(xmlPullParser.getAttributeName(i2))) {
                String attributeValue = xmlPullParser.getAttributeValue(i2);
                if (attributeValue.contains("/")) {
                    i = context.getResources().getIdentifier(attributeValue.substring(attributeValue.indexOf(47) + 1), "id", context.getPackageName());
                } else {
                    i = -1;
                }
                if (i == -1) {
                    if (attributeValue.length() > 1) {
                        i = Integer.parseInt(attributeValue.substring(1));
                    } else {
                        Log.e("ConstraintLayoutStates", "error in parsing id");
                    }
                }
                cVar.mo2078t(context, xmlPullParser);
                this.f1878e.put(i, cVar);
                return;
            }
        }
    }

    /* renamed from: b */
    public void mo2060b(int i, float f, float f2) {
        int a;
        int i2 = this.f1875b;
        if (i2 == i) {
            C0409a aVar = (C0409a) (i == -1 ? this.f1877d.valueAt(0) : this.f1877d.get(i2));
            int i3 = this.f1876c;
            if ((i3 == -1 || !aVar.f1880b.get(i3).mo2062a(f, f2)) && this.f1876c != (a = aVar.mo2061a(f, f2))) {
                C0411c cVar = a == -1 ? null : aVar.f1880b.get(a).f1888f;
                if (a != -1) {
                    int i4 = aVar.f1880b.get(a).f1887e;
                }
                if (cVar != null) {
                    this.f1876c = a;
                    cVar.mo2064c(this.f1874a);
                    return;
                }
                return;
            }
            return;
        }
        this.f1875b = i;
        C0409a aVar2 = this.f1877d.get(i);
        int a2 = aVar2.mo2061a(f, f2);
        C0411c cVar2 = a2 == -1 ? aVar2.f1882d : aVar2.f1880b.get(a2).f1888f;
        if (a2 != -1) {
            int i5 = aVar2.f1880b.get(a2).f1887e;
        }
        if (cVar2 == null) {
            Log.v("ConstraintLayoutStates", "NO Constraint set found ! id=" + i + ", dim =" + f + ", " + f2);
            return;
        }
        this.f1876c = a2;
        cVar2.mo2064c(this.f1874a);
    }
}
