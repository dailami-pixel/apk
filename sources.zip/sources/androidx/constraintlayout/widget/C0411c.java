package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Constraints;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParserException;
import p098d.p099a.C4567a;
import p098d.p113e.p114a.p115a.C4637c;
import p098d.p113e.p116b.p117i.C4662e;
import p098d.p113e.p116b.p117i.C4669j;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.constraintlayout.widget.c */
public class C0411c {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public static final int[] f1889a = {0, 4, 8};

    /* renamed from: b */
    private static SparseIntArray f1890b;

    /* renamed from: c */
    public static final /* synthetic */ int f1891c = 0;

    /* renamed from: d */
    private HashMap<String, C0407a> f1892d = new HashMap<>();

    /* renamed from: e */
    private boolean f1893e = true;

    /* renamed from: f */
    private HashMap<Integer, C0412a> f1894f = new HashMap<>();

    /* renamed from: androidx.constraintlayout.widget.c$a */
    public static class C0412a {

        /* renamed from: a */
        int f1895a;

        /* renamed from: b */
        public final C0415d f1896b = new C0415d();

        /* renamed from: c */
        public final C0414c f1897c = new C0414c();

        /* renamed from: d */
        public final C0413b f1898d = new C0413b();

        /* renamed from: e */
        public final C0416e f1899e = new C0416e();

        /* renamed from: f */
        public HashMap<String, C0407a> f1900f = new HashMap<>();

        /* renamed from: b */
        static void m1970b(C0412a aVar, ConstraintHelper constraintHelper, int i, Constraints.LayoutParams layoutParams) {
            aVar.m1973f(i, layoutParams);
            if (constraintHelper instanceof Barrier) {
                C0413b bVar = aVar.f1898d;
                bVar.f1936e0 = 1;
                Barrier barrier = (Barrier) constraintHelper;
                bVar.f1932c0 = barrier.mo2001y();
                aVar.f1898d.f1938f0 = barrier.mo2004j();
                aVar.f1898d.f1934d0 = barrier.mo2000x();
            }
        }

        /* access modifiers changed from: private */
        /* renamed from: e */
        public void m1972e(int i, ConstraintLayout.LayoutParams layoutParams) {
            this.f1895a = i;
            C0413b bVar = this.f1898d;
            bVar.f1943i = layoutParams.f1808d;
            bVar.f1945j = layoutParams.f1810e;
            bVar.f1947k = layoutParams.f1812f;
            bVar.f1949l = layoutParams.f1814g;
            bVar.f1950m = layoutParams.f1816h;
            bVar.f1951n = layoutParams.f1818i;
            bVar.f1952o = layoutParams.f1820j;
            bVar.f1953p = layoutParams.f1822k;
            bVar.f1954q = layoutParams.f1824l;
            bVar.f1955r = layoutParams.f1829p;
            bVar.f1956s = layoutParams.f1830q;
            bVar.f1957t = layoutParams.f1831r;
            bVar.f1958u = layoutParams.f1832s;
            bVar.f1959v = layoutParams.f1839z;
            bVar.f1960w = layoutParams.f1776A;
            bVar.f1961x = layoutParams.f1777B;
            bVar.f1962y = layoutParams.f1826m;
            bVar.f1963z = layoutParams.f1827n;
            bVar.f1902A = layoutParams.f1828o;
            bVar.f1903B = layoutParams.f1791P;
            bVar.f1904C = layoutParams.f1792Q;
            bVar.f1905D = layoutParams.f1793R;
            bVar.f1941h = layoutParams.f1806c;
            bVar.f1937f = layoutParams.f1802a;
            bVar.f1939g = layoutParams.f1804b;
            C0413b bVar2 = this.f1898d;
            bVar2.f1933d = layoutParams.width;
            bVar2.f1935e = layoutParams.height;
            bVar2.f1906E = layoutParams.leftMargin;
            bVar2.f1907F = layoutParams.rightMargin;
            bVar2.f1908G = layoutParams.topMargin;
            bVar2.f1909H = layoutParams.bottomMargin;
            bVar2.f1918Q = layoutParams.f1780E;
            bVar2.f1919R = layoutParams.f1779D;
            bVar2.f1921T = layoutParams.f1782G;
            bVar2.f1920S = layoutParams.f1781F;
            bVar2.f1944i0 = layoutParams.f1794S;
            bVar2.f1946j0 = layoutParams.f1795T;
            bVar2.f1922U = layoutParams.f1783H;
            bVar2.f1923V = layoutParams.f1784I;
            bVar2.f1924W = layoutParams.f1787L;
            bVar2.f1925X = layoutParams.f1788M;
            bVar2.f1926Y = layoutParams.f1785J;
            bVar2.f1927Z = layoutParams.f1786K;
            bVar2.f1928a0 = layoutParams.f1789N;
            bVar2.f1930b0 = layoutParams.f1790O;
            bVar2.f1942h0 = layoutParams.f1796U;
            bVar2.f1913L = layoutParams.f1834u;
            bVar2.f1915N = layoutParams.f1836w;
            bVar2.f1912K = layoutParams.f1833t;
            bVar2.f1914M = layoutParams.f1835v;
            C0413b bVar3 = this.f1898d;
            bVar3.f1917P = layoutParams.f1837x;
            bVar3.f1916O = layoutParams.f1838y;
            bVar3.f1910I = layoutParams.getMarginEnd();
            this.f1898d.f1911J = layoutParams.getMarginStart();
        }

        /* access modifiers changed from: private */
        /* renamed from: f */
        public void m1973f(int i, Constraints.LayoutParams layoutParams) {
            m1972e(i, layoutParams);
            this.f1896b.f1975d = layoutParams.f1849m0;
            C0416e eVar = this.f1899e;
            eVar.f1979c = layoutParams.f1852p0;
            eVar.f1980d = layoutParams.f1853q0;
            eVar.f1981e = layoutParams.f1854r0;
            eVar.f1982f = layoutParams.f1855s0;
            eVar.f1983g = layoutParams.f1856t0;
            eVar.f1984h = layoutParams.f1857u0;
            eVar.f1985i = layoutParams.f1858v0;
            eVar.f1986j = layoutParams.f1859w0;
            eVar.f1987k = layoutParams.f1860x0;
            eVar.f1988l = layoutParams.f1861y0;
            eVar.f1990n = layoutParams.f1851o0;
            eVar.f1989m = layoutParams.f1850n0;
        }

        public Object clone() throws CloneNotSupportedException {
            C0412a aVar = new C0412a();
            aVar.f1898d.mo2084a(this.f1898d);
            aVar.f1897c.mo2086a(this.f1897c);
            aVar.f1896b.mo2088a(this.f1896b);
            aVar.f1899e.mo2090a(this.f1899e);
            aVar.f1895a = this.f1895a;
            return aVar;
        }

        /* renamed from: d */
        public void mo2083d(ConstraintLayout.LayoutParams layoutParams) {
            C0413b bVar = this.f1898d;
            layoutParams.f1808d = bVar.f1943i;
            layoutParams.f1810e = bVar.f1945j;
            layoutParams.f1812f = bVar.f1947k;
            layoutParams.f1814g = bVar.f1949l;
            layoutParams.f1816h = bVar.f1950m;
            layoutParams.f1818i = bVar.f1951n;
            layoutParams.f1820j = bVar.f1952o;
            layoutParams.f1822k = bVar.f1953p;
            layoutParams.f1824l = bVar.f1954q;
            layoutParams.f1829p = bVar.f1955r;
            layoutParams.f1830q = bVar.f1956s;
            layoutParams.f1831r = bVar.f1957t;
            layoutParams.f1832s = bVar.f1958u;
            layoutParams.leftMargin = bVar.f1906E;
            layoutParams.rightMargin = bVar.f1907F;
            layoutParams.topMargin = bVar.f1908G;
            layoutParams.bottomMargin = bVar.f1909H;
            layoutParams.f1837x = bVar.f1917P;
            layoutParams.f1838y = bVar.f1916O;
            layoutParams.f1834u = bVar.f1913L;
            layoutParams.f1836w = bVar.f1915N;
            layoutParams.f1839z = bVar.f1959v;
            layoutParams.f1776A = bVar.f1960w;
            layoutParams.f1826m = bVar.f1962y;
            layoutParams.f1827n = bVar.f1963z;
            C0413b bVar2 = this.f1898d;
            layoutParams.f1828o = bVar2.f1902A;
            layoutParams.f1777B = bVar2.f1961x;
            layoutParams.f1791P = bVar2.f1903B;
            layoutParams.f1792Q = bVar2.f1904C;
            layoutParams.f1780E = bVar2.f1918Q;
            layoutParams.f1779D = bVar2.f1919R;
            layoutParams.f1782G = bVar2.f1921T;
            layoutParams.f1781F = bVar2.f1920S;
            layoutParams.f1794S = bVar2.f1944i0;
            layoutParams.f1795T = bVar2.f1946j0;
            layoutParams.f1783H = bVar2.f1922U;
            layoutParams.f1784I = bVar2.f1923V;
            layoutParams.f1787L = bVar2.f1924W;
            layoutParams.f1788M = bVar2.f1925X;
            layoutParams.f1785J = bVar2.f1926Y;
            layoutParams.f1786K = bVar2.f1927Z;
            layoutParams.f1789N = bVar2.f1928a0;
            layoutParams.f1790O = bVar2.f1930b0;
            layoutParams.f1793R = bVar2.f1905D;
            layoutParams.f1806c = bVar2.f1941h;
            layoutParams.f1802a = bVar2.f1937f;
            layoutParams.f1804b = bVar2.f1939g;
            layoutParams.width = bVar2.f1933d;
            layoutParams.height = bVar2.f1935e;
            String str = bVar2.f1942h0;
            if (str != null) {
                layoutParams.f1796U = str;
            }
            layoutParams.setMarginStart(this.f1898d.f1911J);
            layoutParams.setMarginEnd(this.f1898d.f1910I);
            layoutParams.mo2035b();
        }
    }

    /* renamed from: androidx.constraintlayout.widget.c$b */
    public static class C0413b {

        /* renamed from: a */
        private static SparseIntArray f1901a;

        /* renamed from: A */
        public float f1902A = 0.0f;

        /* renamed from: B */
        public int f1903B = -1;

        /* renamed from: C */
        public int f1904C = -1;

        /* renamed from: D */
        public int f1905D = -1;

        /* renamed from: E */
        public int f1906E = -1;

        /* renamed from: F */
        public int f1907F = -1;

        /* renamed from: G */
        public int f1908G = -1;

        /* renamed from: H */
        public int f1909H = -1;

        /* renamed from: I */
        public int f1910I = -1;

        /* renamed from: J */
        public int f1911J = -1;

        /* renamed from: K */
        public int f1912K = -1;

        /* renamed from: L */
        public int f1913L = -1;

        /* renamed from: M */
        public int f1914M = -1;

        /* renamed from: N */
        public int f1915N = -1;

        /* renamed from: O */
        public int f1916O = -1;

        /* renamed from: P */
        public int f1917P = -1;

        /* renamed from: Q */
        public float f1918Q = -1.0f;

        /* renamed from: R */
        public float f1919R = -1.0f;

        /* renamed from: S */
        public int f1920S = 0;

        /* renamed from: T */
        public int f1921T = 0;

        /* renamed from: U */
        public int f1922U = 0;

        /* renamed from: V */
        public int f1923V = 0;

        /* renamed from: W */
        public int f1924W = -1;

        /* renamed from: X */
        public int f1925X = -1;

        /* renamed from: Y */
        public int f1926Y = -1;

        /* renamed from: Z */
        public int f1927Z = -1;

        /* renamed from: a0 */
        public float f1928a0 = 1.0f;

        /* renamed from: b */
        public boolean f1929b = false;

        /* renamed from: b0 */
        public float f1930b0 = 1.0f;

        /* renamed from: c */
        public boolean f1931c = false;

        /* renamed from: c0 */
        public int f1932c0 = -1;

        /* renamed from: d */
        public int f1933d;

        /* renamed from: d0 */
        public int f1934d0 = 0;

        /* renamed from: e */
        public int f1935e;

        /* renamed from: e0 */
        public int f1936e0 = -1;

        /* renamed from: f */
        public int f1937f = -1;

        /* renamed from: f0 */
        public int[] f1938f0;

        /* renamed from: g */
        public int f1939g = -1;

        /* renamed from: g0 */
        public String f1940g0;

        /* renamed from: h */
        public float f1941h = -1.0f;

        /* renamed from: h0 */
        public String f1942h0;

        /* renamed from: i */
        public int f1943i = -1;

        /* renamed from: i0 */
        public boolean f1944i0 = false;

        /* renamed from: j */
        public int f1945j = -1;

        /* renamed from: j0 */
        public boolean f1946j0 = false;

        /* renamed from: k */
        public int f1947k = -1;

        /* renamed from: k0 */
        public boolean f1948k0 = true;

        /* renamed from: l */
        public int f1949l = -1;

        /* renamed from: m */
        public int f1950m = -1;

        /* renamed from: n */
        public int f1951n = -1;

        /* renamed from: o */
        public int f1952o = -1;

        /* renamed from: p */
        public int f1953p = -1;

        /* renamed from: q */
        public int f1954q = -1;

        /* renamed from: r */
        public int f1955r = -1;

        /* renamed from: s */
        public int f1956s = -1;

        /* renamed from: t */
        public int f1957t = -1;

        /* renamed from: u */
        public int f1958u = -1;

        /* renamed from: v */
        public float f1959v = 0.5f;

        /* renamed from: w */
        public float f1960w = 0.5f;

        /* renamed from: x */
        public String f1961x = null;

        /* renamed from: y */
        public int f1962y = -1;

        /* renamed from: z */
        public int f1963z = 0;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1901a = sparseIntArray;
            sparseIntArray.append(38, 24);
            f1901a.append(39, 25);
            f1901a.append(41, 28);
            f1901a.append(42, 29);
            f1901a.append(47, 35);
            f1901a.append(46, 34);
            f1901a.append(20, 4);
            f1901a.append(19, 3);
            f1901a.append(17, 1);
            f1901a.append(55, 6);
            f1901a.append(56, 7);
            f1901a.append(27, 17);
            f1901a.append(28, 18);
            f1901a.append(29, 19);
            f1901a.append(0, 26);
            f1901a.append(43, 31);
            f1901a.append(44, 32);
            f1901a.append(26, 10);
            f1901a.append(25, 9);
            f1901a.append(59, 13);
            f1901a.append(62, 16);
            f1901a.append(60, 14);
            f1901a.append(57, 11);
            f1901a.append(61, 15);
            f1901a.append(58, 12);
            f1901a.append(50, 38);
            f1901a.append(36, 37);
            f1901a.append(35, 39);
            f1901a.append(49, 40);
            f1901a.append(34, 20);
            f1901a.append(48, 36);
            f1901a.append(24, 5);
            f1901a.append(37, 76);
            f1901a.append(45, 76);
            f1901a.append(40, 76);
            f1901a.append(18, 76);
            f1901a.append(16, 76);
            f1901a.append(3, 23);
            f1901a.append(5, 27);
            f1901a.append(7, 30);
            f1901a.append(8, 8);
            f1901a.append(4, 33);
            f1901a.append(6, 2);
            f1901a.append(1, 22);
            f1901a.append(2, 21);
            f1901a.append(21, 61);
            f1901a.append(23, 62);
            f1901a.append(22, 63);
            f1901a.append(54, 69);
            f1901a.append(33, 70);
            f1901a.append(12, 71);
            f1901a.append(10, 72);
            f1901a.append(11, 73);
            f1901a.append(13, 74);
            f1901a.append(9, 75);
        }

        /* renamed from: a */
        public void mo2084a(C0413b bVar) {
            this.f1929b = bVar.f1929b;
            this.f1933d = bVar.f1933d;
            this.f1931c = bVar.f1931c;
            this.f1935e = bVar.f1935e;
            this.f1937f = bVar.f1937f;
            this.f1939g = bVar.f1939g;
            this.f1941h = bVar.f1941h;
            this.f1943i = bVar.f1943i;
            this.f1945j = bVar.f1945j;
            this.f1947k = bVar.f1947k;
            this.f1949l = bVar.f1949l;
            this.f1950m = bVar.f1950m;
            this.f1951n = bVar.f1951n;
            this.f1952o = bVar.f1952o;
            this.f1953p = bVar.f1953p;
            this.f1954q = bVar.f1954q;
            this.f1955r = bVar.f1955r;
            this.f1956s = bVar.f1956s;
            this.f1957t = bVar.f1957t;
            this.f1958u = bVar.f1958u;
            this.f1959v = bVar.f1959v;
            this.f1960w = bVar.f1960w;
            this.f1961x = bVar.f1961x;
            this.f1962y = bVar.f1962y;
            this.f1963z = bVar.f1963z;
            this.f1902A = bVar.f1902A;
            this.f1903B = bVar.f1903B;
            this.f1904C = bVar.f1904C;
            this.f1905D = bVar.f1905D;
            this.f1906E = bVar.f1906E;
            this.f1907F = bVar.f1907F;
            this.f1908G = bVar.f1908G;
            this.f1909H = bVar.f1909H;
            this.f1910I = bVar.f1910I;
            this.f1911J = bVar.f1911J;
            this.f1912K = bVar.f1912K;
            this.f1913L = bVar.f1913L;
            this.f1914M = bVar.f1914M;
            this.f1915N = bVar.f1915N;
            this.f1916O = bVar.f1916O;
            this.f1917P = bVar.f1917P;
            this.f1918Q = bVar.f1918Q;
            this.f1919R = bVar.f1919R;
            this.f1920S = bVar.f1920S;
            this.f1921T = bVar.f1921T;
            this.f1922U = bVar.f1922U;
            this.f1923V = bVar.f1923V;
            this.f1924W = bVar.f1924W;
            this.f1925X = bVar.f1925X;
            this.f1926Y = bVar.f1926Y;
            this.f1927Z = bVar.f1927Z;
            this.f1928a0 = bVar.f1928a0;
            this.f1930b0 = bVar.f1930b0;
            this.f1932c0 = bVar.f1932c0;
            this.f1934d0 = bVar.f1934d0;
            this.f1936e0 = bVar.f1936e0;
            this.f1942h0 = bVar.f1942h0;
            int[] iArr = bVar.f1938f0;
            if (iArr != null) {
                this.f1938f0 = Arrays.copyOf(iArr, iArr.length);
            } else {
                this.f1938f0 = null;
            }
            this.f1940g0 = bVar.f1940g0;
            this.f1944i0 = bVar.f1944i0;
            this.f1946j0 = bVar.f1946j0;
            this.f1948k0 = bVar.f1948k0;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo2085b(Context context, AttributeSet attributeSet) {
            String str;
            StringBuilder sb;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0418e.f2002l);
            this.f1931c = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                int i2 = f1901a.get(index);
                if (i2 == 80) {
                    this.f1944i0 = obtainStyledAttributes.getBoolean(index, this.f1944i0);
                } else if (i2 != 81) {
                    switch (i2) {
                        case 1:
                            int i3 = this.f1954q;
                            int i4 = C0411c.f1891c;
                            int resourceId = obtainStyledAttributes.getResourceId(index, i3);
                            if (resourceId == -1) {
                                resourceId = obtainStyledAttributes.getInt(index, -1);
                            }
                            this.f1954q = resourceId;
                            break;
                        case 2:
                            this.f1909H = obtainStyledAttributes.getDimensionPixelSize(index, this.f1909H);
                            break;
                        case 3:
                            int i5 = this.f1953p;
                            int i6 = C0411c.f1891c;
                            int resourceId2 = obtainStyledAttributes.getResourceId(index, i5);
                            if (resourceId2 == -1) {
                                resourceId2 = obtainStyledAttributes.getInt(index, -1);
                            }
                            this.f1953p = resourceId2;
                            break;
                        case 4:
                            int i7 = this.f1952o;
                            int i8 = C0411c.f1891c;
                            int resourceId3 = obtainStyledAttributes.getResourceId(index, i7);
                            if (resourceId3 == -1) {
                                resourceId3 = obtainStyledAttributes.getInt(index, -1);
                            }
                            this.f1952o = resourceId3;
                            break;
                        case 5:
                            this.f1961x = obtainStyledAttributes.getString(index);
                            break;
                        case 6:
                            this.f1903B = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1903B);
                            break;
                        case 7:
                            this.f1904C = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1904C);
                            break;
                        case 8:
                            this.f1910I = obtainStyledAttributes.getDimensionPixelSize(index, this.f1910I);
                            break;
                        case 9:
                            int i9 = this.f1958u;
                            int i10 = C0411c.f1891c;
                            int resourceId4 = obtainStyledAttributes.getResourceId(index, i9);
                            if (resourceId4 == -1) {
                                resourceId4 = obtainStyledAttributes.getInt(index, -1);
                            }
                            this.f1958u = resourceId4;
                            break;
                        case 10:
                            int i11 = this.f1957t;
                            int i12 = C0411c.f1891c;
                            int resourceId5 = obtainStyledAttributes.getResourceId(index, i11);
                            if (resourceId5 == -1) {
                                resourceId5 = obtainStyledAttributes.getInt(index, -1);
                            }
                            this.f1957t = resourceId5;
                            break;
                        case 11:
                            this.f1915N = obtainStyledAttributes.getDimensionPixelSize(index, this.f1915N);
                            break;
                        case 12:
                            this.f1916O = obtainStyledAttributes.getDimensionPixelSize(index, this.f1916O);
                            break;
                        case 13:
                            this.f1912K = obtainStyledAttributes.getDimensionPixelSize(index, this.f1912K);
                            break;
                        case 14:
                            this.f1914M = obtainStyledAttributes.getDimensionPixelSize(index, this.f1914M);
                            break;
                        case 15:
                            this.f1917P = obtainStyledAttributes.getDimensionPixelSize(index, this.f1917P);
                            break;
                        case 16:
                            this.f1913L = obtainStyledAttributes.getDimensionPixelSize(index, this.f1913L);
                            break;
                        case 17:
                            this.f1937f = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1937f);
                            break;
                        case 18:
                            this.f1939g = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1939g);
                            break;
                        case 19:
                            this.f1941h = obtainStyledAttributes.getFloat(index, this.f1941h);
                            break;
                        case 20:
                            this.f1959v = obtainStyledAttributes.getFloat(index, this.f1959v);
                            break;
                        case 21:
                            this.f1935e = obtainStyledAttributes.getLayoutDimension(index, this.f1935e);
                            break;
                        case 22:
                            this.f1933d = obtainStyledAttributes.getLayoutDimension(index, this.f1933d);
                            break;
                        case 23:
                            this.f1906E = obtainStyledAttributes.getDimensionPixelSize(index, this.f1906E);
                            break;
                        case 24:
                            int i13 = this.f1943i;
                            int i14 = C0411c.f1891c;
                            int resourceId6 = obtainStyledAttributes.getResourceId(index, i13);
                            if (resourceId6 == -1) {
                                resourceId6 = obtainStyledAttributes.getInt(index, -1);
                            }
                            this.f1943i = resourceId6;
                            break;
                        case 25:
                            int i15 = this.f1945j;
                            int i16 = C0411c.f1891c;
                            int resourceId7 = obtainStyledAttributes.getResourceId(index, i15);
                            if (resourceId7 == -1) {
                                resourceId7 = obtainStyledAttributes.getInt(index, -1);
                            }
                            this.f1945j = resourceId7;
                            break;
                        case 26:
                            this.f1905D = obtainStyledAttributes.getInt(index, this.f1905D);
                            break;
                        case 27:
                            this.f1907F = obtainStyledAttributes.getDimensionPixelSize(index, this.f1907F);
                            break;
                        case 28:
                            int i17 = this.f1947k;
                            int i18 = C0411c.f1891c;
                            int resourceId8 = obtainStyledAttributes.getResourceId(index, i17);
                            if (resourceId8 == -1) {
                                resourceId8 = obtainStyledAttributes.getInt(index, -1);
                            }
                            this.f1947k = resourceId8;
                            break;
                        case 29:
                            int i19 = this.f1949l;
                            int i20 = C0411c.f1891c;
                            int resourceId9 = obtainStyledAttributes.getResourceId(index, i19);
                            if (resourceId9 == -1) {
                                resourceId9 = obtainStyledAttributes.getInt(index, -1);
                            }
                            this.f1949l = resourceId9;
                            break;
                        case 30:
                            this.f1911J = obtainStyledAttributes.getDimensionPixelSize(index, this.f1911J);
                            break;
                        case 31:
                            int i21 = this.f1955r;
                            int i22 = C0411c.f1891c;
                            int resourceId10 = obtainStyledAttributes.getResourceId(index, i21);
                            if (resourceId10 == -1) {
                                resourceId10 = obtainStyledAttributes.getInt(index, -1);
                            }
                            this.f1955r = resourceId10;
                            break;
                        case 32:
                            int i23 = this.f1956s;
                            int i24 = C0411c.f1891c;
                            int resourceId11 = obtainStyledAttributes.getResourceId(index, i23);
                            if (resourceId11 == -1) {
                                resourceId11 = obtainStyledAttributes.getInt(index, -1);
                            }
                            this.f1956s = resourceId11;
                            break;
                        case 33:
                            this.f1908G = obtainStyledAttributes.getDimensionPixelSize(index, this.f1908G);
                            break;
                        case 34:
                            int i25 = this.f1951n;
                            int i26 = C0411c.f1891c;
                            int resourceId12 = obtainStyledAttributes.getResourceId(index, i25);
                            if (resourceId12 == -1) {
                                resourceId12 = obtainStyledAttributes.getInt(index, -1);
                            }
                            this.f1951n = resourceId12;
                            break;
                        case 35:
                            int i27 = this.f1950m;
                            int i28 = C0411c.f1891c;
                            int resourceId13 = obtainStyledAttributes.getResourceId(index, i27);
                            if (resourceId13 == -1) {
                                resourceId13 = obtainStyledAttributes.getInt(index, -1);
                            }
                            this.f1950m = resourceId13;
                            break;
                        case 36:
                            this.f1960w = obtainStyledAttributes.getFloat(index, this.f1960w);
                            break;
                        case 37:
                            this.f1919R = obtainStyledAttributes.getFloat(index, this.f1919R);
                            break;
                        case 38:
                            this.f1918Q = obtainStyledAttributes.getFloat(index, this.f1918Q);
                            break;
                        case 39:
                            this.f1920S = obtainStyledAttributes.getInt(index, this.f1920S);
                            break;
                        case 40:
                            this.f1921T = obtainStyledAttributes.getInt(index, this.f1921T);
                            break;
                        default:
                            switch (i2) {
                                case 54:
                                    this.f1922U = obtainStyledAttributes.getInt(index, this.f1922U);
                                    break;
                                case 55:
                                    this.f1923V = obtainStyledAttributes.getInt(index, this.f1923V);
                                    break;
                                case 56:
                                    this.f1924W = obtainStyledAttributes.getDimensionPixelSize(index, this.f1924W);
                                    break;
                                case 57:
                                    this.f1925X = obtainStyledAttributes.getDimensionPixelSize(index, this.f1925X);
                                    break;
                                case 58:
                                    this.f1926Y = obtainStyledAttributes.getDimensionPixelSize(index, this.f1926Y);
                                    break;
                                case 59:
                                    this.f1927Z = obtainStyledAttributes.getDimensionPixelSize(index, this.f1927Z);
                                    break;
                                default:
                                    switch (i2) {
                                        case 61:
                                            int i29 = this.f1962y;
                                            int i30 = C0411c.f1891c;
                                            int resourceId14 = obtainStyledAttributes.getResourceId(index, i29);
                                            if (resourceId14 == -1) {
                                                resourceId14 = obtainStyledAttributes.getInt(index, -1);
                                            }
                                            this.f1962y = resourceId14;
                                            break;
                                        case 62:
                                            this.f1963z = obtainStyledAttributes.getDimensionPixelSize(index, this.f1963z);
                                            break;
                                        case 63:
                                            this.f1902A = obtainStyledAttributes.getFloat(index, this.f1902A);
                                            break;
                                        default:
                                            switch (i2) {
                                                case 69:
                                                    this.f1928a0 = obtainStyledAttributes.getFloat(index, 1.0f);
                                                    continue;
                                                case 70:
                                                    this.f1930b0 = obtainStyledAttributes.getFloat(index, 1.0f);
                                                    continue;
                                                case 71:
                                                    Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                                                    continue;
                                                case 72:
                                                    this.f1932c0 = obtainStyledAttributes.getInt(index, this.f1932c0);
                                                    continue;
                                                case 73:
                                                    this.f1934d0 = obtainStyledAttributes.getDimensionPixelSize(index, this.f1934d0);
                                                    continue;
                                                case 74:
                                                    this.f1940g0 = obtainStyledAttributes.getString(index);
                                                    continue;
                                                case 75:
                                                    this.f1948k0 = obtainStyledAttributes.getBoolean(index, this.f1948k0);
                                                    continue;
                                                case 76:
                                                    sb = new StringBuilder();
                                                    str = "unused attribute 0x";
                                                    break;
                                                case 77:
                                                    this.f1942h0 = obtainStyledAttributes.getString(index);
                                                    continue;
                                                default:
                                                    sb = new StringBuilder();
                                                    str = "Unknown attribute 0x";
                                                    break;
                                            }
                                            sb.append(str);
                                            sb.append(Integer.toHexString(index));
                                            sb.append("   ");
                                            sb.append(f1901a.get(index));
                                            Log.w("ConstraintSet", sb.toString());
                                            break;
                                    }
                            }
                    }
                } else {
                    this.f1946j0 = obtainStyledAttributes.getBoolean(index, this.f1946j0);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* renamed from: androidx.constraintlayout.widget.c$c */
    public static class C0414c {

        /* renamed from: a */
        private static SparseIntArray f1964a;

        /* renamed from: b */
        public boolean f1965b = false;

        /* renamed from: c */
        public int f1966c = -1;

        /* renamed from: d */
        public String f1967d = null;

        /* renamed from: e */
        public int f1968e = -1;

        /* renamed from: f */
        public int f1969f = 0;

        /* renamed from: g */
        public float f1970g = Float.NaN;

        /* renamed from: h */
        public float f1971h = Float.NaN;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1964a = sparseIntArray;
            sparseIntArray.append(2, 1);
            f1964a.append(4, 2);
            f1964a.append(5, 3);
            f1964a.append(1, 4);
            f1964a.append(0, 5);
            f1964a.append(3, 6);
        }

        /* renamed from: a */
        public void mo2086a(C0414c cVar) {
            this.f1965b = cVar.f1965b;
            this.f1966c = cVar.f1966c;
            this.f1967d = cVar.f1967d;
            this.f1968e = cVar.f1968e;
            this.f1969f = cVar.f1969f;
            this.f1971h = cVar.f1971h;
            this.f1970g = cVar.f1970g;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo2087b(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0418e.f2004n);
            this.f1965b = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                switch (f1964a.get(index)) {
                    case 1:
                        this.f1971h = obtainStyledAttributes.getFloat(index, this.f1971h);
                        break;
                    case 2:
                        this.f1968e = obtainStyledAttributes.getInt(index, this.f1968e);
                        break;
                    case 3:
                        this.f1967d = obtainStyledAttributes.peekValue(index).type == 3 ? obtainStyledAttributes.getString(index) : C4637c.f16727b[obtainStyledAttributes.getInteger(index, 0)];
                        break;
                    case 4:
                        this.f1969f = obtainStyledAttributes.getInt(index, 0);
                        break;
                    case 5:
                        int i2 = this.f1966c;
                        int i3 = C0411c.f1891c;
                        int resourceId = obtainStyledAttributes.getResourceId(index, i2);
                        if (resourceId == -1) {
                            resourceId = obtainStyledAttributes.getInt(index, -1);
                        }
                        this.f1966c = resourceId;
                        break;
                    case 6:
                        this.f1970g = obtainStyledAttributes.getFloat(index, this.f1970g);
                        break;
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* renamed from: androidx.constraintlayout.widget.c$d */
    public static class C0415d {

        /* renamed from: a */
        public boolean f1972a = false;

        /* renamed from: b */
        public int f1973b = 0;

        /* renamed from: c */
        public int f1974c = 0;

        /* renamed from: d */
        public float f1975d = 1.0f;

        /* renamed from: e */
        public float f1976e = Float.NaN;

        /* renamed from: a */
        public void mo2088a(C0415d dVar) {
            this.f1972a = dVar.f1972a;
            this.f1973b = dVar.f1973b;
            this.f1975d = dVar.f1975d;
            this.f1976e = dVar.f1976e;
            this.f1974c = dVar.f1974c;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo2089b(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0418e.f2011u);
            this.f1972a = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 1) {
                    this.f1975d = obtainStyledAttributes.getFloat(index, this.f1975d);
                } else if (index == 0) {
                    this.f1973b = obtainStyledAttributes.getInt(index, this.f1973b);
                    this.f1973b = C0411c.f1889a[this.f1973b];
                } else if (index == 4) {
                    this.f1974c = obtainStyledAttributes.getInt(index, this.f1974c);
                } else if (index == 3) {
                    this.f1976e = obtainStyledAttributes.getFloat(index, this.f1976e);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* renamed from: androidx.constraintlayout.widget.c$e */
    public static class C0416e {

        /* renamed from: a */
        private static SparseIntArray f1977a;

        /* renamed from: b */
        public boolean f1978b = false;

        /* renamed from: c */
        public float f1979c = 0.0f;

        /* renamed from: d */
        public float f1980d = 0.0f;

        /* renamed from: e */
        public float f1981e = 0.0f;

        /* renamed from: f */
        public float f1982f = 1.0f;

        /* renamed from: g */
        public float f1983g = 1.0f;

        /* renamed from: h */
        public float f1984h = Float.NaN;

        /* renamed from: i */
        public float f1985i = Float.NaN;

        /* renamed from: j */
        public float f1986j = 0.0f;

        /* renamed from: k */
        public float f1987k = 0.0f;

        /* renamed from: l */
        public float f1988l = 0.0f;

        /* renamed from: m */
        public boolean f1989m = false;

        /* renamed from: n */
        public float f1990n = 0.0f;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1977a = sparseIntArray;
            sparseIntArray.append(6, 1);
            f1977a.append(7, 2);
            f1977a.append(8, 3);
            f1977a.append(4, 4);
            f1977a.append(5, 5);
            f1977a.append(0, 6);
            f1977a.append(1, 7);
            f1977a.append(2, 8);
            f1977a.append(3, 9);
            f1977a.append(9, 10);
            f1977a.append(10, 11);
        }

        /* renamed from: a */
        public void mo2090a(C0416e eVar) {
            this.f1978b = eVar.f1978b;
            this.f1979c = eVar.f1979c;
            this.f1980d = eVar.f1980d;
            this.f1981e = eVar.f1981e;
            this.f1982f = eVar.f1982f;
            this.f1983g = eVar.f1983g;
            this.f1984h = eVar.f1984h;
            this.f1985i = eVar.f1985i;
            this.f1986j = eVar.f1986j;
            this.f1987k = eVar.f1987k;
            this.f1988l = eVar.f1988l;
            this.f1989m = eVar.f1989m;
            this.f1990n = eVar.f1990n;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo2091b(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0418e.f2014x);
            this.f1978b = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                switch (f1977a.get(index)) {
                    case 1:
                        this.f1979c = obtainStyledAttributes.getFloat(index, this.f1979c);
                        break;
                    case 2:
                        this.f1980d = obtainStyledAttributes.getFloat(index, this.f1980d);
                        break;
                    case 3:
                        this.f1981e = obtainStyledAttributes.getFloat(index, this.f1981e);
                        break;
                    case 4:
                        this.f1982f = obtainStyledAttributes.getFloat(index, this.f1982f);
                        break;
                    case 5:
                        this.f1983g = obtainStyledAttributes.getFloat(index, this.f1983g);
                        break;
                    case 6:
                        this.f1984h = obtainStyledAttributes.getDimension(index, this.f1984h);
                        break;
                    case 7:
                        this.f1985i = obtainStyledAttributes.getDimension(index, this.f1985i);
                        break;
                    case 8:
                        this.f1986j = obtainStyledAttributes.getDimension(index, this.f1986j);
                        break;
                    case 9:
                        this.f1987k = obtainStyledAttributes.getDimension(index, this.f1987k);
                        break;
                    case 10:
                        this.f1988l = obtainStyledAttributes.getDimension(index, this.f1988l);
                        break;
                    case 11:
                        this.f1989m = true;
                        this.f1990n = obtainStyledAttributes.getDimension(index, this.f1990n);
                        break;
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f1890b = sparseIntArray;
        sparseIntArray.append(76, 25);
        f1890b.append(77, 26);
        f1890b.append(79, 29);
        f1890b.append(80, 30);
        f1890b.append(86, 36);
        f1890b.append(85, 35);
        f1890b.append(58, 4);
        f1890b.append(57, 3);
        f1890b.append(55, 1);
        f1890b.append(94, 6);
        f1890b.append(95, 7);
        f1890b.append(65, 17);
        f1890b.append(66, 18);
        f1890b.append(67, 19);
        f1890b.append(0, 27);
        f1890b.append(81, 32);
        f1890b.append(82, 33);
        f1890b.append(64, 10);
        f1890b.append(63, 9);
        f1890b.append(98, 13);
        f1890b.append(101, 16);
        f1890b.append(99, 14);
        f1890b.append(96, 11);
        f1890b.append(100, 15);
        f1890b.append(97, 12);
        f1890b.append(89, 40);
        f1890b.append(74, 39);
        f1890b.append(73, 41);
        f1890b.append(88, 42);
        f1890b.append(72, 20);
        f1890b.append(87, 37);
        f1890b.append(62, 5);
        f1890b.append(75, 82);
        f1890b.append(84, 82);
        f1890b.append(78, 82);
        f1890b.append(56, 82);
        f1890b.append(54, 82);
        f1890b.append(5, 24);
        f1890b.append(7, 28);
        f1890b.append(23, 31);
        f1890b.append(24, 8);
        f1890b.append(6, 34);
        f1890b.append(8, 2);
        f1890b.append(3, 23);
        f1890b.append(4, 21);
        f1890b.append(2, 22);
        f1890b.append(13, 43);
        f1890b.append(26, 44);
        f1890b.append(21, 45);
        f1890b.append(22, 46);
        f1890b.append(20, 60);
        f1890b.append(18, 47);
        f1890b.append(19, 48);
        f1890b.append(14, 49);
        f1890b.append(15, 50);
        f1890b.append(16, 51);
        f1890b.append(17, 52);
        f1890b.append(25, 53);
        f1890b.append(90, 54);
        f1890b.append(68, 55);
        f1890b.append(91, 56);
        f1890b.append(69, 57);
        f1890b.append(92, 58);
        f1890b.append(70, 59);
        f1890b.append(59, 61);
        f1890b.append(61, 62);
        f1890b.append(60, 63);
        f1890b.append(27, 64);
        f1890b.append(106, 65);
        f1890b.append(33, 66);
        f1890b.append(107, 67);
        f1890b.append(103, 79);
        f1890b.append(1, 38);
        f1890b.append(102, 68);
        f1890b.append(93, 69);
        f1890b.append(71, 70);
        f1890b.append(31, 71);
        f1890b.append(29, 72);
        f1890b.append(30, 73);
        f1890b.append(32, 74);
        f1890b.append(28, 75);
        f1890b.append(104, 76);
        f1890b.append(83, 77);
        f1890b.append(108, 78);
        f1890b.append(53, 80);
        f1890b.append(52, 81);
    }

    /* renamed from: i */
    private int[] m1947i(View view, String str) {
        int i;
        Object h;
        String[] split = str.split(",");
        Context context = view.getContext();
        int[] iArr = new int[split.length];
        int i2 = 0;
        int i3 = 0;
        while (i2 < split.length) {
            String trim = split[i2].trim();
            try {
                i = C0417d.class.getField(trim).getInt((Object) null);
            } catch (Exception unused) {
                i = 0;
            }
            if (i == 0) {
                i = context.getResources().getIdentifier(trim, "id", context.getPackageName());
            }
            if (i == 0 && view.isInEditMode() && (view.getParent() instanceof ConstraintLayout) && (h = ((ConstraintLayout) view.getParent()).mo2021h(0, trim)) != null && (h instanceof Integer)) {
                i = ((Integer) h).intValue();
            }
            iArr[i3] = i;
            i2++;
            i3++;
        }
        return i3 != split.length ? Arrays.copyOf(iArr, i3) : iArr;
    }

    /* renamed from: j */
    private C0412a m1948j(Context context, AttributeSet attributeSet) {
        String str;
        StringBuilder sb;
        C0414c cVar;
        String str2;
        C0412a aVar = new C0412a();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0418e.f1991a);
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i = 0; i < indexCount; i++) {
            int index = obtainStyledAttributes.getIndex(i);
            if (!(index == 1 || 23 == index || 24 == index)) {
                aVar.f1897c.f1965b = true;
                aVar.f1898d.f1931c = true;
                aVar.f1896b.f1972a = true;
                aVar.f1899e.f1978b = true;
            }
            switch (f1890b.get(index)) {
                case 1:
                    C0413b bVar = aVar.f1898d;
                    int resourceId = obtainStyledAttributes.getResourceId(index, bVar.f1954q);
                    if (resourceId == -1) {
                        resourceId = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar.f1954q = resourceId;
                    continue;
                case 2:
                    C0413b bVar2 = aVar.f1898d;
                    bVar2.f1909H = obtainStyledAttributes.getDimensionPixelSize(index, bVar2.f1909H);
                    continue;
                case 3:
                    C0413b bVar3 = aVar.f1898d;
                    int resourceId2 = obtainStyledAttributes.getResourceId(index, bVar3.f1953p);
                    if (resourceId2 == -1) {
                        resourceId2 = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar3.f1953p = resourceId2;
                    continue;
                case 4:
                    C0413b bVar4 = aVar.f1898d;
                    int resourceId3 = obtainStyledAttributes.getResourceId(index, bVar4.f1952o);
                    if (resourceId3 == -1) {
                        resourceId3 = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar4.f1952o = resourceId3;
                    continue;
                case 5:
                    aVar.f1898d.f1961x = obtainStyledAttributes.getString(index);
                    continue;
                case 6:
                    C0413b bVar5 = aVar.f1898d;
                    bVar5.f1903B = obtainStyledAttributes.getDimensionPixelOffset(index, bVar5.f1903B);
                    continue;
                case 7:
                    C0413b bVar6 = aVar.f1898d;
                    bVar6.f1904C = obtainStyledAttributes.getDimensionPixelOffset(index, bVar6.f1904C);
                    continue;
                case 8:
                    C0413b bVar7 = aVar.f1898d;
                    bVar7.f1910I = obtainStyledAttributes.getDimensionPixelSize(index, bVar7.f1910I);
                    continue;
                case 9:
                    C0413b bVar8 = aVar.f1898d;
                    int resourceId4 = obtainStyledAttributes.getResourceId(index, bVar8.f1958u);
                    if (resourceId4 == -1) {
                        resourceId4 = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar8.f1958u = resourceId4;
                    continue;
                case 10:
                    C0413b bVar9 = aVar.f1898d;
                    int resourceId5 = obtainStyledAttributes.getResourceId(index, bVar9.f1957t);
                    if (resourceId5 == -1) {
                        resourceId5 = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar9.f1957t = resourceId5;
                    continue;
                case 11:
                    C0413b bVar10 = aVar.f1898d;
                    bVar10.f1915N = obtainStyledAttributes.getDimensionPixelSize(index, bVar10.f1915N);
                    continue;
                case 12:
                    C0413b bVar11 = aVar.f1898d;
                    bVar11.f1916O = obtainStyledAttributes.getDimensionPixelSize(index, bVar11.f1916O);
                    continue;
                case 13:
                    C0413b bVar12 = aVar.f1898d;
                    bVar12.f1912K = obtainStyledAttributes.getDimensionPixelSize(index, bVar12.f1912K);
                    continue;
                case 14:
                    C0413b bVar13 = aVar.f1898d;
                    bVar13.f1914M = obtainStyledAttributes.getDimensionPixelSize(index, bVar13.f1914M);
                    continue;
                case 15:
                    C0413b bVar14 = aVar.f1898d;
                    bVar14.f1917P = obtainStyledAttributes.getDimensionPixelSize(index, bVar14.f1917P);
                    continue;
                case 16:
                    C0413b bVar15 = aVar.f1898d;
                    bVar15.f1913L = obtainStyledAttributes.getDimensionPixelSize(index, bVar15.f1913L);
                    continue;
                case 17:
                    C0413b bVar16 = aVar.f1898d;
                    bVar16.f1937f = obtainStyledAttributes.getDimensionPixelOffset(index, bVar16.f1937f);
                    continue;
                case 18:
                    C0413b bVar17 = aVar.f1898d;
                    bVar17.f1939g = obtainStyledAttributes.getDimensionPixelOffset(index, bVar17.f1939g);
                    continue;
                case 19:
                    C0413b bVar18 = aVar.f1898d;
                    bVar18.f1941h = obtainStyledAttributes.getFloat(index, bVar18.f1941h);
                    continue;
                case 20:
                    C0413b bVar19 = aVar.f1898d;
                    bVar19.f1959v = obtainStyledAttributes.getFloat(index, bVar19.f1959v);
                    continue;
                case 21:
                    C0413b bVar20 = aVar.f1898d;
                    bVar20.f1935e = obtainStyledAttributes.getLayoutDimension(index, bVar20.f1935e);
                    continue;
                case 22:
                    C0415d dVar = aVar.f1896b;
                    dVar.f1973b = obtainStyledAttributes.getInt(index, dVar.f1973b);
                    C0415d dVar2 = aVar.f1896b;
                    dVar2.f1973b = f1889a[dVar2.f1973b];
                    continue;
                case 23:
                    C0413b bVar21 = aVar.f1898d;
                    bVar21.f1933d = obtainStyledAttributes.getLayoutDimension(index, bVar21.f1933d);
                    continue;
                case 24:
                    C0413b bVar22 = aVar.f1898d;
                    bVar22.f1906E = obtainStyledAttributes.getDimensionPixelSize(index, bVar22.f1906E);
                    continue;
                case 25:
                    C0413b bVar23 = aVar.f1898d;
                    int resourceId6 = obtainStyledAttributes.getResourceId(index, bVar23.f1943i);
                    if (resourceId6 == -1) {
                        resourceId6 = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar23.f1943i = resourceId6;
                    continue;
                case 26:
                    C0413b bVar24 = aVar.f1898d;
                    int resourceId7 = obtainStyledAttributes.getResourceId(index, bVar24.f1945j);
                    if (resourceId7 == -1) {
                        resourceId7 = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar24.f1945j = resourceId7;
                    continue;
                case 27:
                    C0413b bVar25 = aVar.f1898d;
                    bVar25.f1905D = obtainStyledAttributes.getInt(index, bVar25.f1905D);
                    continue;
                case 28:
                    C0413b bVar26 = aVar.f1898d;
                    bVar26.f1907F = obtainStyledAttributes.getDimensionPixelSize(index, bVar26.f1907F);
                    continue;
                case 29:
                    C0413b bVar27 = aVar.f1898d;
                    int resourceId8 = obtainStyledAttributes.getResourceId(index, bVar27.f1947k);
                    if (resourceId8 == -1) {
                        resourceId8 = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar27.f1947k = resourceId8;
                    continue;
                case 30:
                    C0413b bVar28 = aVar.f1898d;
                    int resourceId9 = obtainStyledAttributes.getResourceId(index, bVar28.f1949l);
                    if (resourceId9 == -1) {
                        resourceId9 = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar28.f1949l = resourceId9;
                    continue;
                case 31:
                    C0413b bVar29 = aVar.f1898d;
                    bVar29.f1911J = obtainStyledAttributes.getDimensionPixelSize(index, bVar29.f1911J);
                    continue;
                case 32:
                    C0413b bVar30 = aVar.f1898d;
                    int resourceId10 = obtainStyledAttributes.getResourceId(index, bVar30.f1955r);
                    if (resourceId10 == -1) {
                        resourceId10 = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar30.f1955r = resourceId10;
                    continue;
                case 33:
                    C0413b bVar31 = aVar.f1898d;
                    int resourceId11 = obtainStyledAttributes.getResourceId(index, bVar31.f1956s);
                    if (resourceId11 == -1) {
                        resourceId11 = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar31.f1956s = resourceId11;
                    continue;
                case 34:
                    C0413b bVar32 = aVar.f1898d;
                    bVar32.f1908G = obtainStyledAttributes.getDimensionPixelSize(index, bVar32.f1908G);
                    continue;
                case 35:
                    C0413b bVar33 = aVar.f1898d;
                    int resourceId12 = obtainStyledAttributes.getResourceId(index, bVar33.f1951n);
                    if (resourceId12 == -1) {
                        resourceId12 = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar33.f1951n = resourceId12;
                    continue;
                case 36:
                    C0413b bVar34 = aVar.f1898d;
                    int resourceId13 = obtainStyledAttributes.getResourceId(index, bVar34.f1950m);
                    if (resourceId13 == -1) {
                        resourceId13 = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar34.f1950m = resourceId13;
                    continue;
                case 37:
                    C0413b bVar35 = aVar.f1898d;
                    bVar35.f1960w = obtainStyledAttributes.getFloat(index, bVar35.f1960w);
                    continue;
                case 38:
                    aVar.f1895a = obtainStyledAttributes.getResourceId(index, aVar.f1895a);
                    continue;
                case 39:
                    C0413b bVar36 = aVar.f1898d;
                    bVar36.f1919R = obtainStyledAttributes.getFloat(index, bVar36.f1919R);
                    continue;
                case 40:
                    C0413b bVar37 = aVar.f1898d;
                    bVar37.f1918Q = obtainStyledAttributes.getFloat(index, bVar37.f1918Q);
                    continue;
                case 41:
                    C0413b bVar38 = aVar.f1898d;
                    bVar38.f1920S = obtainStyledAttributes.getInt(index, bVar38.f1920S);
                    continue;
                case 42:
                    C0413b bVar39 = aVar.f1898d;
                    bVar39.f1921T = obtainStyledAttributes.getInt(index, bVar39.f1921T);
                    continue;
                case 43:
                    C0415d dVar3 = aVar.f1896b;
                    dVar3.f1975d = obtainStyledAttributes.getFloat(index, dVar3.f1975d);
                    continue;
                case 44:
                    C0416e eVar = aVar.f1899e;
                    eVar.f1989m = true;
                    eVar.f1990n = obtainStyledAttributes.getDimension(index, eVar.f1990n);
                    continue;
                case 45:
                    C0416e eVar2 = aVar.f1899e;
                    eVar2.f1980d = obtainStyledAttributes.getFloat(index, eVar2.f1980d);
                    continue;
                case 46:
                    C0416e eVar3 = aVar.f1899e;
                    eVar3.f1981e = obtainStyledAttributes.getFloat(index, eVar3.f1981e);
                    continue;
                case 47:
                    C0416e eVar4 = aVar.f1899e;
                    eVar4.f1982f = obtainStyledAttributes.getFloat(index, eVar4.f1982f);
                    continue;
                case 48:
                    C0416e eVar5 = aVar.f1899e;
                    eVar5.f1983g = obtainStyledAttributes.getFloat(index, eVar5.f1983g);
                    continue;
                case 49:
                    C0416e eVar6 = aVar.f1899e;
                    eVar6.f1984h = obtainStyledAttributes.getDimension(index, eVar6.f1984h);
                    continue;
                case 50:
                    C0416e eVar7 = aVar.f1899e;
                    eVar7.f1985i = obtainStyledAttributes.getDimension(index, eVar7.f1985i);
                    continue;
                case 51:
                    C0416e eVar8 = aVar.f1899e;
                    eVar8.f1986j = obtainStyledAttributes.getDimension(index, eVar8.f1986j);
                    continue;
                case 52:
                    C0416e eVar9 = aVar.f1899e;
                    eVar9.f1987k = obtainStyledAttributes.getDimension(index, eVar9.f1987k);
                    continue;
                case 53:
                    C0416e eVar10 = aVar.f1899e;
                    eVar10.f1988l = obtainStyledAttributes.getDimension(index, eVar10.f1988l);
                    continue;
                case 54:
                    C0413b bVar40 = aVar.f1898d;
                    bVar40.f1922U = obtainStyledAttributes.getInt(index, bVar40.f1922U);
                    continue;
                case 55:
                    C0413b bVar41 = aVar.f1898d;
                    bVar41.f1923V = obtainStyledAttributes.getInt(index, bVar41.f1923V);
                    continue;
                case 56:
                    C0413b bVar42 = aVar.f1898d;
                    bVar42.f1924W = obtainStyledAttributes.getDimensionPixelSize(index, bVar42.f1924W);
                    continue;
                case 57:
                    C0413b bVar43 = aVar.f1898d;
                    bVar43.f1925X = obtainStyledAttributes.getDimensionPixelSize(index, bVar43.f1925X);
                    continue;
                case 58:
                    C0413b bVar44 = aVar.f1898d;
                    bVar44.f1926Y = obtainStyledAttributes.getDimensionPixelSize(index, bVar44.f1926Y);
                    continue;
                case 59:
                    C0413b bVar45 = aVar.f1898d;
                    bVar45.f1927Z = obtainStyledAttributes.getDimensionPixelSize(index, bVar45.f1927Z);
                    continue;
                case 60:
                    C0416e eVar11 = aVar.f1899e;
                    eVar11.f1979c = obtainStyledAttributes.getFloat(index, eVar11.f1979c);
                    continue;
                case 61:
                    C0413b bVar46 = aVar.f1898d;
                    int resourceId14 = obtainStyledAttributes.getResourceId(index, bVar46.f1962y);
                    if (resourceId14 == -1) {
                        resourceId14 = obtainStyledAttributes.getInt(index, -1);
                    }
                    bVar46.f1962y = resourceId14;
                    continue;
                case 62:
                    C0413b bVar47 = aVar.f1898d;
                    bVar47.f1963z = obtainStyledAttributes.getDimensionPixelSize(index, bVar47.f1963z);
                    continue;
                case 63:
                    C0413b bVar48 = aVar.f1898d;
                    bVar48.f1902A = obtainStyledAttributes.getFloat(index, bVar48.f1902A);
                    continue;
                case 64:
                    C0414c cVar2 = aVar.f1897c;
                    int resourceId15 = obtainStyledAttributes.getResourceId(index, cVar2.f1966c);
                    if (resourceId15 == -1) {
                        resourceId15 = obtainStyledAttributes.getInt(index, -1);
                    }
                    cVar2.f1966c = resourceId15;
                    continue;
                case 65:
                    if (obtainStyledAttributes.peekValue(index).type == 3) {
                        cVar = aVar.f1897c;
                        str2 = obtainStyledAttributes.getString(index);
                    } else {
                        cVar = aVar.f1897c;
                        str2 = C4637c.f16727b[obtainStyledAttributes.getInteger(index, 0)];
                    }
                    cVar.f1967d = str2;
                    continue;
                case 66:
                    aVar.f1897c.f1969f = obtainStyledAttributes.getInt(index, 0);
                    continue;
                case 67:
                    C0414c cVar3 = aVar.f1897c;
                    cVar3.f1971h = obtainStyledAttributes.getFloat(index, cVar3.f1971h);
                    continue;
                case 68:
                    C0415d dVar4 = aVar.f1896b;
                    dVar4.f1976e = obtainStyledAttributes.getFloat(index, dVar4.f1976e);
                    continue;
                case 69:
                    aVar.f1898d.f1928a0 = obtainStyledAttributes.getFloat(index, 1.0f);
                    continue;
                case 70:
                    aVar.f1898d.f1930b0 = obtainStyledAttributes.getFloat(index, 1.0f);
                    continue;
                case 71:
                    Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                    continue;
                case 72:
                    C0413b bVar49 = aVar.f1898d;
                    bVar49.f1932c0 = obtainStyledAttributes.getInt(index, bVar49.f1932c0);
                    continue;
                case 73:
                    C0413b bVar50 = aVar.f1898d;
                    bVar50.f1934d0 = obtainStyledAttributes.getDimensionPixelSize(index, bVar50.f1934d0);
                    continue;
                case 74:
                    aVar.f1898d.f1940g0 = obtainStyledAttributes.getString(index);
                    continue;
                case 75:
                    C0413b bVar51 = aVar.f1898d;
                    bVar51.f1948k0 = obtainStyledAttributes.getBoolean(index, bVar51.f1948k0);
                    continue;
                case 76:
                    C0414c cVar4 = aVar.f1897c;
                    cVar4.f1968e = obtainStyledAttributes.getInt(index, cVar4.f1968e);
                    continue;
                case 77:
                    aVar.f1898d.f1942h0 = obtainStyledAttributes.getString(index);
                    continue;
                case 78:
                    C0415d dVar5 = aVar.f1896b;
                    dVar5.f1974c = obtainStyledAttributes.getInt(index, dVar5.f1974c);
                    continue;
                case 79:
                    C0414c cVar5 = aVar.f1897c;
                    cVar5.f1970g = obtainStyledAttributes.getFloat(index, cVar5.f1970g);
                    continue;
                case 80:
                    C0413b bVar52 = aVar.f1898d;
                    bVar52.f1944i0 = obtainStyledAttributes.getBoolean(index, bVar52.f1944i0);
                    continue;
                case 81:
                    C0413b bVar53 = aVar.f1898d;
                    bVar53.f1946j0 = obtainStyledAttributes.getBoolean(index, bVar53.f1946j0);
                    continue;
                case 82:
                    sb = new StringBuilder();
                    str = "unused attribute 0x";
                    break;
                default:
                    sb = new StringBuilder();
                    str = "Unknown attribute 0x";
                    break;
            }
            sb.append(str);
            sb.append(Integer.toHexString(index));
            sb.append("   ");
            sb.append(f1890b.get(index));
            Log.w("ConstraintSet", sb.toString());
        }
        obtainStyledAttributes.recycle();
        return aVar;
    }

    /* renamed from: k */
    private C0412a m1949k(int i) {
        if (!this.f1894f.containsKey(Integer.valueOf(i))) {
            this.f1894f.put(Integer.valueOf(i), new C0412a());
        }
        return this.f1894f.get(Integer.valueOf(i));
    }

    /* renamed from: b */
    public void mo2063b(ConstraintLayout constraintLayout) {
        int childCount = constraintLayout.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = constraintLayout.getChildAt(i);
            int id = childAt.getId();
            if (!this.f1894f.containsKey(Integer.valueOf(id))) {
                StringBuilder P = C4924a.m17863P("id unknown ");
                P.append(C4567a.m16428c(childAt));
                Log.v("ConstraintSet", P.toString());
            } else if (this.f1893e && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            } else if (this.f1894f.containsKey(Integer.valueOf(id))) {
                C0407a.m1935g(childAt, this.f1894f.get(Integer.valueOf(id)).f1900f);
            }
        }
    }

    /* renamed from: c */
    public void mo2064c(ConstraintLayout constraintLayout) {
        mo2066e(constraintLayout, true);
        constraintLayout.mo2031w((C0411c) null);
        constraintLayout.requestLayout();
    }

    /* renamed from: d */
    public void mo2065d(ConstraintHelper constraintHelper, C4662e eVar, ConstraintLayout.LayoutParams layoutParams, SparseArray<C4662e> sparseArray) {
        int id = constraintHelper.getId();
        if (this.f1894f.containsKey(Integer.valueOf(id))) {
            C0412a aVar = this.f1894f.get(Integer.valueOf(id));
            if (eVar instanceof C4669j) {
                constraintHelper.mo1810m(aVar, (C4669j) eVar, layoutParams, sparseArray);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo2066e(ConstraintLayout constraintLayout, boolean z) {
        int childCount = constraintLayout.getChildCount();
        HashSet hashSet = new HashSet(this.f1894f.keySet());
        for (int i = 0; i < childCount; i++) {
            View childAt = constraintLayout.getChildAt(i);
            int id = childAt.getId();
            if (!this.f1894f.containsKey(Integer.valueOf(id))) {
                StringBuilder P = C4924a.m17863P("id unknown ");
                P.append(C4567a.m16428c(childAt));
                Log.w("ConstraintSet", P.toString());
            } else if (this.f1893e && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            } else if (id != -1) {
                if (this.f1894f.containsKey(Integer.valueOf(id))) {
                    hashSet.remove(Integer.valueOf(id));
                    C0412a aVar = this.f1894f.get(Integer.valueOf(id));
                    if (childAt instanceof Barrier) {
                        aVar.f1898d.f1936e0 = 1;
                    }
                    int i2 = aVar.f1898d.f1936e0;
                    if (i2 != -1 && i2 == 1) {
                        Barrier barrier = (Barrier) childAt;
                        barrier.setId(id);
                        barrier.mo1998B(aVar.f1898d.f1932c0);
                        barrier.mo1997A(aVar.f1898d.f1934d0);
                        barrier.mo2002z(aVar.f1898d.f1948k0);
                        C0413b bVar = aVar.f1898d;
                        int[] iArr = bVar.f1938f0;
                        if (iArr != null) {
                            barrier.mo2008p(iArr);
                        } else {
                            String str = bVar.f1940g0;
                            if (str != null) {
                                bVar.f1938f0 = m1947i(barrier, str);
                                barrier.mo2008p(aVar.f1898d.f1938f0);
                            }
                        }
                    }
                    ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) childAt.getLayoutParams();
                    layoutParams.mo2035b();
                    aVar.mo2083d(layoutParams);
                    if (z) {
                        C0407a.m1935g(childAt, aVar.f1900f);
                    }
                    childAt.setLayoutParams(layoutParams);
                    C0415d dVar = aVar.f1896b;
                    if (dVar.f1974c == 0) {
                        childAt.setVisibility(dVar.f1973b);
                    }
                    childAt.setAlpha(aVar.f1896b.f1975d);
                    childAt.setRotation(aVar.f1899e.f1979c);
                    childAt.setRotationX(aVar.f1899e.f1980d);
                    childAt.setRotationY(aVar.f1899e.f1981e);
                    childAt.setScaleX(aVar.f1899e.f1982f);
                    childAt.setScaleY(aVar.f1899e.f1983g);
                    if (!Float.isNaN(aVar.f1899e.f1984h)) {
                        childAt.setPivotX(aVar.f1899e.f1984h);
                    }
                    if (!Float.isNaN(aVar.f1899e.f1985i)) {
                        childAt.setPivotY(aVar.f1899e.f1985i);
                    }
                    childAt.setTranslationX(aVar.f1899e.f1986j);
                    childAt.setTranslationY(aVar.f1899e.f1987k);
                    childAt.setTranslationZ(aVar.f1899e.f1988l);
                    C0416e eVar = aVar.f1899e;
                    if (eVar.f1989m) {
                        childAt.setElevation(eVar.f1990n);
                    }
                } else {
                    Log.v("ConstraintSet", "WARNING NO CONSTRAINTS for view " + id);
                }
            }
        }
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            Integer num = (Integer) it.next();
            C0412a aVar2 = this.f1894f.get(num);
            int i3 = aVar2.f1898d.f1936e0;
            if (i3 != -1 && i3 == 1) {
                Barrier barrier2 = new Barrier(constraintLayout.getContext());
                barrier2.setId(num.intValue());
                C0413b bVar2 = aVar2.f1898d;
                int[] iArr2 = bVar2.f1938f0;
                if (iArr2 != null) {
                    barrier2.mo2008p(iArr2);
                } else {
                    String str2 = bVar2.f1940g0;
                    if (str2 != null) {
                        bVar2.f1938f0 = m1947i(barrier2, str2);
                        barrier2.mo2008p(aVar2.f1898d.f1938f0);
                    }
                }
                barrier2.mo1998B(aVar2.f1898d.f1932c0);
                barrier2.mo1997A(aVar2.f1898d.f1934d0);
                ConstraintLayout.LayoutParams g = constraintLayout.generateDefaultLayoutParams();
                barrier2.mo2012v();
                aVar2.mo2083d(g);
                constraintLayout.addView(barrier2, g);
            }
            if (aVar2.f1898d.f1929b) {
                Guideline guideline = new Guideline(constraintLayout.getContext());
                guideline.setId(num.intValue());
                ConstraintLayout.LayoutParams g2 = constraintLayout.generateDefaultLayoutParams();
                aVar2.mo2083d(g2);
                constraintLayout.addView(guideline, g2);
            }
        }
    }

    /* renamed from: f */
    public void mo2067f(int i, ConstraintLayout.LayoutParams layoutParams) {
        if (this.f1894f.containsKey(Integer.valueOf(i))) {
            this.f1894f.get(Integer.valueOf(i)).mo2083d(layoutParams);
        }
    }

    /* renamed from: g */
    public void mo2068g(Context context, int i) {
        C0407a aVar;
        C0411c cVar = this;
        ConstraintLayout constraintLayout = (ConstraintLayout) LayoutInflater.from(context).inflate(i, (ViewGroup) null);
        int childCount = constraintLayout.getChildCount();
        cVar.f1894f.clear();
        int i2 = 0;
        while (i2 < childCount) {
            View childAt = constraintLayout.getChildAt(i2);
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) childAt.getLayoutParams();
            int id = childAt.getId();
            if (!cVar.f1893e || id != -1) {
                if (!cVar.f1894f.containsKey(Integer.valueOf(id))) {
                    cVar.f1894f.put(Integer.valueOf(id), new C0412a());
                }
                C0412a aVar2 = cVar.f1894f.get(Integer.valueOf(id));
                HashMap<String, C0407a> hashMap = cVar.f1892d;
                HashMap<String, C0407a> hashMap2 = new HashMap<>();
                Class<?> cls = childAt.getClass();
                for (String next : hashMap.keySet()) {
                    C0407a aVar3 = hashMap.get(next);
                    try {
                        if (next.equals("BackgroundColor")) {
                            aVar = new C0407a(aVar3, Integer.valueOf(((ColorDrawable) childAt.getBackground()).getColor()));
                        } else {
                            try {
                                aVar = new C0407a(aVar3, cls.getMethod("getMap" + next, new Class[0]).invoke(childAt, new Object[0]));
                            } catch (NoSuchMethodException e) {
                                e = e;
                                e.printStackTrace();
                            } catch (IllegalAccessException e2) {
                                e = e2;
                                e.printStackTrace();
                            } catch (InvocationTargetException e3) {
                                e = e3;
                                e.printStackTrace();
                            }
                        }
                        hashMap2.put(next, aVar);
                    } catch (NoSuchMethodException e4) {
                        e = e4;
                        e.printStackTrace();
                    } catch (IllegalAccessException e5) {
                        e = e5;
                        e.printStackTrace();
                    } catch (InvocationTargetException e6) {
                        e = e6;
                        e.printStackTrace();
                    }
                }
                aVar2.f1900f = hashMap2;
                aVar2.m1972e(id, layoutParams);
                aVar2.f1896b.f1973b = childAt.getVisibility();
                aVar2.f1896b.f1975d = childAt.getAlpha();
                aVar2.f1899e.f1979c = childAt.getRotation();
                aVar2.f1899e.f1980d = childAt.getRotationX();
                aVar2.f1899e.f1981e = childAt.getRotationY();
                aVar2.f1899e.f1982f = childAt.getScaleX();
                aVar2.f1899e.f1983g = childAt.getScaleY();
                float pivotX = childAt.getPivotX();
                float pivotY = childAt.getPivotY();
                if (!(((double) pivotX) == 0.0d && ((double) pivotY) == 0.0d)) {
                    C0416e eVar = aVar2.f1899e;
                    eVar.f1984h = pivotX;
                    eVar.f1985i = pivotY;
                }
                aVar2.f1899e.f1986j = childAt.getTranslationX();
                aVar2.f1899e.f1987k = childAt.getTranslationY();
                aVar2.f1899e.f1988l = childAt.getTranslationZ();
                C0416e eVar2 = aVar2.f1899e;
                if (eVar2.f1989m) {
                    eVar2.f1990n = childAt.getElevation();
                }
                if (childAt instanceof Barrier) {
                    Barrier barrier = (Barrier) childAt;
                    aVar2.f1898d.f1948k0 = barrier.mo1999w();
                    aVar2.f1898d.f1938f0 = barrier.mo2004j();
                    aVar2.f1898d.f1932c0 = barrier.mo2001y();
                    aVar2.f1898d.f1934d0 = barrier.mo2000x();
                }
                i2++;
                cVar = this;
            } else {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
        }
    }

    /* renamed from: h */
    public void mo2069h(Constraints constraints) {
        int childCount = constraints.getChildCount();
        this.f1894f.clear();
        int i = 0;
        while (i < childCount) {
            View childAt = constraints.getChildAt(i);
            Constraints.LayoutParams layoutParams = (Constraints.LayoutParams) childAt.getLayoutParams();
            int id = childAt.getId();
            if (!this.f1893e || id != -1) {
                if (!this.f1894f.containsKey(Integer.valueOf(id))) {
                    this.f1894f.put(Integer.valueOf(id), new C0412a());
                }
                C0412a aVar = this.f1894f.get(Integer.valueOf(id));
                if (childAt instanceof ConstraintHelper) {
                    C0412a.m1970b(aVar, (ConstraintHelper) childAt, id, layoutParams);
                }
                aVar.m1973f(id, layoutParams);
                i++;
            } else {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
        }
    }

    /* renamed from: l */
    public C0412a mo2070l(int i) {
        if (this.f1894f.containsKey(Integer.valueOf(i))) {
            return this.f1894f.get(Integer.valueOf(i));
        }
        return null;
    }

    /* renamed from: m */
    public int mo2071m(int i) {
        return m1949k(i).f1898d.f1935e;
    }

    /* renamed from: n */
    public int[] mo2072n() {
        Integer[] numArr = (Integer[]) this.f1894f.keySet().toArray(new Integer[0]);
        int length = numArr.length;
        int[] iArr = new int[length];
        for (int i = 0; i < length; i++) {
            iArr[i] = numArr[i].intValue();
        }
        return iArr;
    }

    /* renamed from: o */
    public C0412a mo2073o(int i) {
        return m1949k(i);
    }

    /* renamed from: p */
    public int mo2074p(int i) {
        return m1949k(i).f1896b.f1973b;
    }

    /* renamed from: q */
    public int mo2075q(int i) {
        return m1949k(i).f1896b.f1974c;
    }

    /* renamed from: r */
    public int mo2076r(int i) {
        return m1949k(i).f1898d.f1933d;
    }

    /* renamed from: s */
    public void mo2077s(Context context, int i) {
        XmlResourceParser xml = context.getResources().getXml(i);
        try {
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType == 0) {
                    xml.getName();
                } else if (eventType == 2) {
                    String name = xml.getName();
                    C0412a j = m1948j(context, Xml.asAttributeSet(xml));
                    if (name.equalsIgnoreCase("Guideline")) {
                        j.f1898d.f1929b = true;
                    }
                    this.f1894f.put(Integer.valueOf(j.f1895a), j);
                }
            }
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:94:0x0178, code lost:
        continue;
     */
    /* renamed from: t */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2078t(android.content.Context r9, org.xmlpull.v1.XmlPullParser r10) {
        /*
            r8 = this;
            int r0 = r10.getEventType()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1 = 0
            r2 = r1
        L_0x0006:
            r3 = 1
            if (r0 == r3) goto L_0x0187
            if (r0 == 0) goto L_0x0175
            java.lang.String r4 = "Constraint"
            r5 = 3
            r6 = 2
            if (r0 == r6) goto L_0x0036
            if (r0 == r5) goto L_0x0015
            goto L_0x0178
        L_0x0015:
            java.lang.String r0 = r10.getName()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            java.lang.String r3 = "ConstraintSet"
            boolean r3 = r3.equals(r0)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            if (r3 == 0) goto L_0x0022
            return
        L_0x0022:
            boolean r0 = r0.equalsIgnoreCase(r4)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            if (r0 == 0) goto L_0x0178
            java.util.HashMap<java.lang.Integer, androidx.constraintlayout.widget.c$a> r0 = r8.f1894f     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            int r3 = r2.f1895a     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r0.put(r3, r2)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r2 = r1
            goto L_0x0178
        L_0x0036:
            java.lang.String r0 = r10.getName()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            int r7 = r0.hashCode()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            switch(r7) {
                case -2025855158: goto L_0x0085;
                case -1984451626: goto L_0x007b;
                case -1269513683: goto L_0x0072;
                case -1238332596: goto L_0x0068;
                case -71750448: goto L_0x005e;
                case 1331510167: goto L_0x0054;
                case 1791837707: goto L_0x004a;
                case 1803088381: goto L_0x0042;
                default: goto L_0x0041;
            }     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
        L_0x0041:
            goto L_0x008f
        L_0x0042:
            boolean r0 = r0.equals(r4)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            if (r0 == 0) goto L_0x008f
            r5 = 0
            goto L_0x0090
        L_0x004a:
            java.lang.String r4 = "CustomAttribute"
            boolean r0 = r0.equals(r4)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            if (r0 == 0) goto L_0x008f
            r5 = 7
            goto L_0x0090
        L_0x0054:
            java.lang.String r4 = "Barrier"
            boolean r0 = r0.equals(r4)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            if (r0 == 0) goto L_0x008f
            r5 = 2
            goto L_0x0090
        L_0x005e:
            java.lang.String r4 = "Guideline"
            boolean r0 = r0.equals(r4)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            if (r0 == 0) goto L_0x008f
            r5 = 1
            goto L_0x0090
        L_0x0068:
            java.lang.String r4 = "Transform"
            boolean r0 = r0.equals(r4)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            if (r0 == 0) goto L_0x008f
            r5 = 4
            goto L_0x0090
        L_0x0072:
            java.lang.String r4 = "PropertySet"
            boolean r0 = r0.equals(r4)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            if (r0 == 0) goto L_0x008f
            goto L_0x0090
        L_0x007b:
            java.lang.String r4 = "Motion"
            boolean r0 = r0.equals(r4)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            if (r0 == 0) goto L_0x008f
            r5 = 6
            goto L_0x0090
        L_0x0085:
            java.lang.String r4 = "Layout"
            boolean r0 = r0.equals(r4)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            if (r0 == 0) goto L_0x008f
            r5 = 5
            goto L_0x0090
        L_0x008f:
            r5 = -1
        L_0x0090:
            java.lang.String r0 = "XML parser error must be within a Constraint "
            switch(r5) {
                case 0: goto L_0x016b;
                case 1: goto L_0x015c;
                case 2: goto L_0x014f;
                case 3: goto L_0x012a;
                case 4: goto L_0x0105;
                case 5: goto L_0x00df;
                case 6: goto L_0x00b9;
                case 7: goto L_0x0097;
                default: goto L_0x0095;
            }
        L_0x0095:
            goto L_0x0178
        L_0x0097:
            if (r2 == 0) goto L_0x00a0
            java.util.HashMap<java.lang.String, androidx.constraintlayout.widget.a> r0 = r2.f1900f     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            androidx.constraintlayout.widget.C0407a.m1934f(r9, r10, r0)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            goto L_0x0178
        L_0x00a0:
            java.lang.RuntimeException r9 = new java.lang.RuntimeException     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.<init>()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.append(r0)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            int r10 = r10.getLineNumber()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.append(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            java.lang.String r10 = r1.toString()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r9.<init>(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            throw r9     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
        L_0x00b9:
            if (r2 == 0) goto L_0x00c6
            androidx.constraintlayout.widget.c$c r0 = r2.f1897c     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            android.util.AttributeSet r3 = android.util.Xml.asAttributeSet(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r0.mo2087b(r9, r3)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            goto L_0x0178
        L_0x00c6:
            java.lang.RuntimeException r9 = new java.lang.RuntimeException     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.<init>()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.append(r0)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            int r10 = r10.getLineNumber()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.append(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            java.lang.String r10 = r1.toString()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r9.<init>(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            throw r9     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
        L_0x00df:
            if (r2 == 0) goto L_0x00ec
            androidx.constraintlayout.widget.c$b r0 = r2.f1898d     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            android.util.AttributeSet r3 = android.util.Xml.asAttributeSet(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r0.mo2085b(r9, r3)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            goto L_0x0178
        L_0x00ec:
            java.lang.RuntimeException r9 = new java.lang.RuntimeException     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.<init>()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.append(r0)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            int r10 = r10.getLineNumber()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.append(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            java.lang.String r10 = r1.toString()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r9.<init>(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            throw r9     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
        L_0x0105:
            if (r2 == 0) goto L_0x0111
            androidx.constraintlayout.widget.c$e r0 = r2.f1899e     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            android.util.AttributeSet r3 = android.util.Xml.asAttributeSet(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r0.mo2091b(r9, r3)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            goto L_0x0178
        L_0x0111:
            java.lang.RuntimeException r9 = new java.lang.RuntimeException     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.<init>()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.append(r0)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            int r10 = r10.getLineNumber()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.append(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            java.lang.String r10 = r1.toString()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r9.<init>(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            throw r9     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
        L_0x012a:
            if (r2 == 0) goto L_0x0136
            androidx.constraintlayout.widget.c$d r0 = r2.f1896b     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            android.util.AttributeSet r3 = android.util.Xml.asAttributeSet(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r0.mo2089b(r9, r3)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            goto L_0x0178
        L_0x0136:
            java.lang.RuntimeException r9 = new java.lang.RuntimeException     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.<init>()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.append(r0)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            int r10 = r10.getLineNumber()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r1.append(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            java.lang.String r10 = r1.toString()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r9.<init>(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            throw r9     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
        L_0x014f:
            android.util.AttributeSet r0 = android.util.Xml.asAttributeSet(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            androidx.constraintlayout.widget.c$a r0 = r8.m1948j(r9, r0)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            androidx.constraintlayout.widget.c$b r2 = r0.f1898d     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r2.f1936e0 = r3     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            goto L_0x0173
        L_0x015c:
            android.util.AttributeSet r0 = android.util.Xml.asAttributeSet(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            androidx.constraintlayout.widget.c$a r0 = r8.m1948j(r9, r0)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            androidx.constraintlayout.widget.c$b r2 = r0.f1898d     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r2.f1929b = r3     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            r2.f1931c = r3     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            goto L_0x0173
        L_0x016b:
            android.util.AttributeSet r0 = android.util.Xml.asAttributeSet(r10)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            androidx.constraintlayout.widget.c$a r0 = r8.m1948j(r9, r0)     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
        L_0x0173:
            r2 = r0
            goto L_0x0178
        L_0x0175:
            r10.getName()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
        L_0x0178:
            int r0 = r10.next()     // Catch:{ XmlPullParserException -> 0x0183, IOException -> 0x017e }
            goto L_0x0006
        L_0x017e:
            r9 = move-exception
            r9.printStackTrace()
            goto L_0x0187
        L_0x0183:
            r9 = move-exception
            r9.printStackTrace()
        L_0x0187:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.C0411c.mo2078t(android.content.Context, org.xmlpull.v1.XmlPullParser):void");
    }

    /* renamed from: u */
    public void mo2079u(ConstraintLayout constraintLayout) {
        int childCount = constraintLayout.getChildCount();
        int i = 0;
        while (i < childCount) {
            View childAt = constraintLayout.getChildAt(i);
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) childAt.getLayoutParams();
            int id = childAt.getId();
            if (!this.f1893e || id != -1) {
                if (!this.f1894f.containsKey(Integer.valueOf(id))) {
                    this.f1894f.put(Integer.valueOf(id), new C0412a());
                }
                C0412a aVar = this.f1894f.get(Integer.valueOf(id));
                if (!aVar.f1898d.f1931c) {
                    aVar.m1972e(id, layoutParams);
                    if (childAt instanceof ConstraintHelper) {
                        aVar.f1898d.f1938f0 = ((ConstraintHelper) childAt).mo2004j();
                        if (childAt instanceof Barrier) {
                            Barrier barrier = (Barrier) childAt;
                            aVar.f1898d.f1948k0 = barrier.mo1999w();
                            aVar.f1898d.f1932c0 = barrier.mo2001y();
                            aVar.f1898d.f1934d0 = barrier.mo2000x();
                        }
                    }
                    aVar.f1898d.f1931c = true;
                }
                C0415d dVar = aVar.f1896b;
                if (!dVar.f1972a) {
                    dVar.f1973b = childAt.getVisibility();
                    aVar.f1896b.f1975d = childAt.getAlpha();
                    aVar.f1896b.f1972a = true;
                }
                C0416e eVar = aVar.f1899e;
                if (!eVar.f1978b) {
                    eVar.f1978b = true;
                    eVar.f1979c = childAt.getRotation();
                    aVar.f1899e.f1980d = childAt.getRotationX();
                    aVar.f1899e.f1981e = childAt.getRotationY();
                    aVar.f1899e.f1982f = childAt.getScaleX();
                    aVar.f1899e.f1983g = childAt.getScaleY();
                    float pivotX = childAt.getPivotX();
                    float pivotY = childAt.getPivotY();
                    if (!(((double) pivotX) == 0.0d && ((double) pivotY) == 0.0d)) {
                        C0416e eVar2 = aVar.f1899e;
                        eVar2.f1984h = pivotX;
                        eVar2.f1985i = pivotY;
                    }
                    aVar.f1899e.f1986j = childAt.getTranslationX();
                    aVar.f1899e.f1987k = childAt.getTranslationY();
                    aVar.f1899e.f1988l = childAt.getTranslationZ();
                    C0416e eVar3 = aVar.f1899e;
                    if (eVar3.f1989m) {
                        eVar3.f1990n = childAt.getElevation();
                    }
                }
                i++;
            } else {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
        }
    }

    /* renamed from: v */
    public void mo2080v(C0411c cVar) {
        for (Integer next : cVar.f1894f.keySet()) {
            int intValue = next.intValue();
            C0412a aVar = cVar.f1894f.get(next);
            if (!this.f1894f.containsKey(Integer.valueOf(intValue))) {
                this.f1894f.put(Integer.valueOf(intValue), new C0412a());
            }
            C0412a aVar2 = this.f1894f.get(Integer.valueOf(intValue));
            C0413b bVar = aVar2.f1898d;
            if (!bVar.f1931c) {
                bVar.mo2084a(aVar.f1898d);
            }
            C0415d dVar = aVar2.f1896b;
            if (!dVar.f1972a) {
                dVar.mo2088a(aVar.f1896b);
            }
            C0416e eVar = aVar2.f1899e;
            if (!eVar.f1978b) {
                eVar.mo2090a(aVar.f1899e);
            }
            C0414c cVar2 = aVar2.f1897c;
            if (!cVar2.f1965b) {
                cVar2.mo2086a(aVar.f1897c);
            }
            for (String next2 : aVar.f1900f.keySet()) {
                if (!aVar2.f1900f.containsKey(next2)) {
                    aVar2.f1900f.put(next2, aVar.f1900f.get(next2));
                }
            }
        }
    }

    /* renamed from: w */
    public void mo2081w(boolean z) {
        this.f1893e = z;
    }
}
