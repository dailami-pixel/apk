package androidx.constraintlayout.widget;

/* renamed from: androidx.constraintlayout.widget.d */
public final class C0417d {
    private C0417d() {
    }
}
