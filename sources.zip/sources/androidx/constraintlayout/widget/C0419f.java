package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.Log;
import android.util.SparseArray;
import android.util.Xml;
import java.util.ArrayList;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParser;

/* renamed from: androidx.constraintlayout.widget.f */
public class C0419f {

    /* renamed from: a */
    int f2017a = -1;

    /* renamed from: b */
    private SparseArray<C0420a> f2018b = new SparseArray<>();

    /* renamed from: androidx.constraintlayout.widget.f$a */
    static class C0420a {

        /* renamed from: a */
        int f2019a;

        /* renamed from: b */
        ArrayList<C0421b> f2020b = new ArrayList<>();

        /* renamed from: c */
        int f2021c = -1;

        public C0420a(Context context, XmlPullParser xmlPullParser) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), C0418e.f2012v);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 0) {
                    this.f2019a = obtainStyledAttributes.getResourceId(index, this.f2019a);
                } else if (index == 1) {
                    this.f2021c = obtainStyledAttributes.getResourceId(index, this.f2021c);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.f2021c);
                    context.getResources().getResourceName(this.f2021c);
                    "layout".equals(resourceTypeName);
                }
            }
            obtainStyledAttributes.recycle();
        }

        /* renamed from: a */
        public int mo2094a(float f, float f2) {
            for (int i = 0; i < this.f2020b.size(); i++) {
                if (this.f2020b.get(i).mo2095a(f, f2)) {
                    return i;
                }
            }
            return -1;
        }
    }

    /* renamed from: androidx.constraintlayout.widget.f$b */
    static class C0421b {

        /* renamed from: a */
        float f2022a = Float.NaN;

        /* renamed from: b */
        float f2023b = Float.NaN;

        /* renamed from: c */
        float f2024c = Float.NaN;

        /* renamed from: d */
        float f2025d = Float.NaN;

        /* renamed from: e */
        int f2026e = -1;

        public C0421b(Context context, XmlPullParser xmlPullParser) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), C0418e.f2016z);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 0) {
                    this.f2026e = obtainStyledAttributes.getResourceId(index, this.f2026e);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.f2026e);
                    context.getResources().getResourceName(this.f2026e);
                    "layout".equals(resourceTypeName);
                } else if (index == 1) {
                    this.f2025d = obtainStyledAttributes.getDimension(index, this.f2025d);
                } else if (index == 2) {
                    this.f2023b = obtainStyledAttributes.getDimension(index, this.f2023b);
                } else if (index == 3) {
                    this.f2024c = obtainStyledAttributes.getDimension(index, this.f2024c);
                } else if (index == 4) {
                    this.f2022a = obtainStyledAttributes.getDimension(index, this.f2022a);
                } else {
                    Log.v("ConstraintLayoutStates", "Unknown tag");
                }
            }
            obtainStyledAttributes.recycle();
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public boolean mo2095a(float f, float f2) {
            if (!Float.isNaN(this.f2022a) && f < this.f2022a) {
                return false;
            }
            if (!Float.isNaN(this.f2023b) && f2 < this.f2023b) {
                return false;
            }
            if (Float.isNaN(this.f2024c) || f <= this.f2024c) {
                return Float.isNaN(this.f2025d) || f2 <= this.f2025d;
            }
            return false;
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0419f(android.content.Context r10, org.xmlpull.v1.XmlPullParser r11) {
        /*
            r9 = this;
            r9.<init>()
            r0 = -1
            r9.f2017a = r0
            android.util.SparseArray r1 = new android.util.SparseArray
            r1.<init>()
            r9.f2018b = r1
            android.util.SparseArray r1 = new android.util.SparseArray
            r1.<init>()
            android.util.AttributeSet r1 = android.util.Xml.asAttributeSet(r11)
            int[] r2 = androidx.constraintlayout.widget.C0418e.f2013w
            android.content.res.TypedArray r1 = r10.obtainStyledAttributes(r1, r2)
            int r2 = r1.getIndexCount()
            r3 = 0
            r4 = 0
        L_0x0022:
            if (r4 >= r2) goto L_0x0035
            int r5 = r1.getIndex(r4)
            if (r5 != 0) goto L_0x0032
            int r6 = r9.f2017a
            int r5 = r1.getResourceId(r5, r6)
            r9.f2017a = r5
        L_0x0032:
            int r4 = r4 + 1
            goto L_0x0022
        L_0x0035:
            r1 = 0
            int r2 = r11.getEventType()     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
        L_0x003a:
            r4 = 1
            if (r2 == r4) goto L_0x00d3
            if (r2 == 0) goto L_0x00c1
            java.lang.String r5 = "StateSet"
            r6 = 3
            r7 = 2
            if (r2 == r7) goto L_0x0055
            if (r2 == r6) goto L_0x0049
            goto L_0x00c4
        L_0x0049:
            java.lang.String r2 = r11.getName()     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            boolean r2 = r5.equals(r2)     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            if (r2 == 0) goto L_0x00c4
            goto L_0x00d3
        L_0x0055:
            java.lang.String r2 = r11.getName()     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            int r8 = r2.hashCode()     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            switch(r8) {
                case 80204913: goto L_0x007d;
                case 1301459538: goto L_0x0073;
                case 1382829617: goto L_0x006b;
                case 1901439077: goto L_0x0061;
                default: goto L_0x0060;
            }     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
        L_0x0060:
            goto L_0x0087
        L_0x0061:
            java.lang.String r5 = "Variant"
            boolean r5 = r2.equals(r5)     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            if (r5 == 0) goto L_0x0087
            r5 = 3
            goto L_0x0088
        L_0x006b:
            boolean r5 = r2.equals(r5)     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            if (r5 == 0) goto L_0x0087
            r5 = 1
            goto L_0x0088
        L_0x0073:
            java.lang.String r5 = "LayoutDescription"
            boolean r5 = r2.equals(r5)     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            if (r5 == 0) goto L_0x0087
            r5 = 0
            goto L_0x0088
        L_0x007d:
            java.lang.String r5 = "State"
            boolean r5 = r2.equals(r5)     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            if (r5 == 0) goto L_0x0087
            r5 = 2
            goto L_0x0088
        L_0x0087:
            r5 = -1
        L_0x0088:
            if (r5 == 0) goto L_0x00c4
            if (r5 == r4) goto L_0x00c4
            if (r5 == r7) goto L_0x00b4
            if (r5 == r6) goto L_0x00a7
            java.lang.String r4 = "ConstraintLayoutStates"
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            r5.<init>()     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            java.lang.String r6 = "unknown tag "
            r5.append(r6)     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            r5.append(r2)     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            java.lang.String r2 = r5.toString()     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            android.util.Log.v(r4, r2)     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            goto L_0x00c4
        L_0x00a7:
            androidx.constraintlayout.widget.f$b r2 = new androidx.constraintlayout.widget.f$b     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            r2.<init>(r10, r11)     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            if (r1 == 0) goto L_0x00c4
            java.util.ArrayList<androidx.constraintlayout.widget.f$b> r4 = r1.f2020b     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            r4.add(r2)     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            goto L_0x00c4
        L_0x00b4:
            androidx.constraintlayout.widget.f$a r1 = new androidx.constraintlayout.widget.f$a     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            r1.<init>(r10, r11)     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            android.util.SparseArray<androidx.constraintlayout.widget.f$a> r2 = r9.f2018b     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            int r4 = r1.f2019a     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            r2.put(r4, r1)     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            goto L_0x00c4
        L_0x00c1:
            r11.getName()     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
        L_0x00c4:
            int r2 = r11.next()     // Catch:{ XmlPullParserException -> 0x00cf, IOException -> 0x00ca }
            goto L_0x003a
        L_0x00ca:
            r10 = move-exception
            r10.printStackTrace()
            goto L_0x00d3
        L_0x00cf:
            r10 = move-exception
            r10.printStackTrace()
        L_0x00d3:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.C0419f.<init>(android.content.Context, org.xmlpull.v1.XmlPullParser):void");
    }

    /* renamed from: a */
    public int mo2092a(int i, int i2, float f, float f2) {
        C0420a aVar = this.f2018b.get(i2);
        if (aVar == null) {
            return i2;
        }
        if (f != -1.0f && f2 != -1.0f) {
            C0421b bVar = null;
            Iterator<C0421b> it = aVar.f2020b.iterator();
            while (it.hasNext()) {
                C0421b next = it.next();
                if (next.mo2095a(f, f2)) {
                    if (i == next.f2026e) {
                        return i;
                    }
                    bVar = next;
                }
            }
            return bVar != null ? bVar.f2026e : aVar.f2021c;
        } else if (aVar.f2021c == i) {
            return i;
        } else {
            Iterator<C0421b> it2 = aVar.f2020b.iterator();
            while (it2.hasNext()) {
                if (i == it2.next().f2026e) {
                    return i;
                }
            }
            return aVar.f2021c;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0026, code lost:
        r3 = r3.f2020b.get(r4).f2026e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0041, code lost:
        if (r4 == -1) goto L_0x0023;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0021, code lost:
        if (r4 == -1) goto L_0x0023;
     */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int mo2093b(int r3, int r4, int r5) {
        /*
            r2 = this;
            float r4 = (float) r4
            float r5 = (float) r5
            r0 = -1
            if (r0 != r3) goto L_0x0032
            if (r3 != r0) goto L_0x000f
            android.util.SparseArray<androidx.constraintlayout.widget.f$a> r3 = r2.f2018b
            r1 = 0
            java.lang.Object r3 = r3.valueAt(r1)
            goto L_0x0015
        L_0x000f:
            android.util.SparseArray<androidx.constraintlayout.widget.f$a> r3 = r2.f2018b
            java.lang.Object r3 = r3.get(r0)
        L_0x0015:
            androidx.constraintlayout.widget.f$a r3 = (androidx.constraintlayout.widget.C0419f.C0420a) r3
            if (r3 != 0) goto L_0x001a
            goto L_0x0044
        L_0x001a:
            int r4 = r3.mo2094a(r4, r5)
            if (r0 != r4) goto L_0x0021
            goto L_0x0044
        L_0x0021:
            if (r4 != r0) goto L_0x0026
        L_0x0023:
            int r3 = r3.f2021c
            goto L_0x0030
        L_0x0026:
            java.util.ArrayList<androidx.constraintlayout.widget.f$b> r3 = r3.f2020b
            java.lang.Object r3 = r3.get(r4)
            androidx.constraintlayout.widget.f$b r3 = (androidx.constraintlayout.widget.C0419f.C0421b) r3
            int r3 = r3.f2026e
        L_0x0030:
            r0 = r3
            goto L_0x0044
        L_0x0032:
            android.util.SparseArray<androidx.constraintlayout.widget.f$a> r1 = r2.f2018b
            java.lang.Object r3 = r1.get(r3)
            androidx.constraintlayout.widget.f$a r3 = (androidx.constraintlayout.widget.C0419f.C0420a) r3
            if (r3 != 0) goto L_0x003d
            goto L_0x0044
        L_0x003d:
            int r4 = r3.mo2094a(r4, r5)
            if (r4 != r0) goto L_0x0026
            goto L_0x0023
        L_0x0044:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.C0419f.mo2093b(int, int, int):int");
    }
}
