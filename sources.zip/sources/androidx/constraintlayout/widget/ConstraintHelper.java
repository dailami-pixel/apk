package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.constraintlayout.widget.C0411c;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.Arrays;
import java.util.HashMap;
import p098d.p113e.p116b.p117i.C4662e;
import p098d.p113e.p116b.p117i.C4668i;
import p098d.p113e.p116b.p117i.C4669j;

public abstract class ConstraintHelper extends View {

    /* renamed from: a */
    protected int[] f1752a = new int[32];

    /* renamed from: b */
    protected int f1753b;

    /* renamed from: c */
    protected Context f1754c;

    /* renamed from: d */
    protected C4668i f1755d;

    /* renamed from: e */
    protected String f1756e;

    /* renamed from: f */
    private View[] f1757f = null;

    /* renamed from: g */
    private HashMap<Integer, String> f1758g = new HashMap<>();

    public ConstraintHelper(Context context) {
        super(context);
        this.f1754c = context;
        mo1809l((AttributeSet) null);
    }

    public ConstraintHelper(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1754c = context;
        mo1809l(attributeSet);
    }

    public ConstraintHelper(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1754c = context;
        mo1809l(attributeSet);
    }

    /* renamed from: e */
    private void m1888e(String str) {
        if (str != null && str.length() != 0 && this.f1754c != null) {
            String trim = str.trim();
            if (getParent() instanceof ConstraintLayout) {
                ConstraintLayout constraintLayout = (ConstraintLayout) getParent();
            }
            int i = m1891i(trim);
            if (i != 0) {
                this.f1758g.put(Integer.valueOf(i), trim);
                m1889f(i);
                return;
            }
            Log.w("ConstraintHelper", "Could not find id of \"" + trim + "\"");
        }
    }

    /* renamed from: f */
    private void m1889f(int i) {
        if (i != getId()) {
            int i2 = this.f1753b + 1;
            int[] iArr = this.f1752a;
            if (i2 > iArr.length) {
                this.f1752a = Arrays.copyOf(iArr, iArr.length * 2);
            }
            int[] iArr2 = this.f1752a;
            int i3 = this.f1753b;
            iArr2[i3] = i;
            this.f1753b = i3 + 1;
        }
    }

    /* renamed from: h */
    private int m1890h(ConstraintLayout constraintLayout, String str) {
        Resources resources;
        if (str == null || (resources = this.f1754c.getResources()) == null) {
            return 0;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = constraintLayout.getChildAt(i);
            if (childAt.getId() != -1) {
                String str2 = null;
                try {
                    str2 = resources.getResourceEntryName(childAt.getId());
                } catch (Resources.NotFoundException unused) {
                }
                if (str.equals(str2)) {
                    return childAt.getId();
                }
            }
        }
        return 0;
    }

    /* renamed from: i */
    private int m1891i(String str) {
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        int i = 0;
        if (isInEditMode() && constraintLayout != null) {
            Object h = constraintLayout.mo2021h(0, str);
            if (h instanceof Integer) {
                i = ((Integer) h).intValue();
            }
        }
        if (i == 0 && constraintLayout != null) {
            i = m1890h(constraintLayout, str);
        }
        if (i == 0) {
            try {
                i = C0417d.class.getField(str).getInt((Object) null);
            } catch (Exception unused) {
            }
        }
        return i == 0 ? this.f1754c.getResources().getIdentifier(str, "id", this.f1754c.getPackageName()) : i;
    }

    /* access modifiers changed from: protected */
    /* renamed from: g */
    public void mo2003g() {
        ViewParent parent = getParent();
        if (parent != null && (parent instanceof ConstraintLayout)) {
            ConstraintLayout constraintLayout = (ConstraintLayout) parent;
            int visibility = getVisibility();
            float elevation = getElevation();
            for (int i = 0; i < this.f1753b; i++) {
                View j = constraintLayout.mo2023j(this.f1752a[i]);
                if (j != null) {
                    j.setVisibility(visibility);
                    if (elevation > 0.0f) {
                        j.setTranslationZ(j.getTranslationZ() + elevation);
                    }
                }
            }
        }
    }

    /* renamed from: j */
    public int[] mo2004j() {
        return Arrays.copyOf(this.f1752a, this.f1753b);
    }

    /* access modifiers changed from: protected */
    /* renamed from: k */
    public View[] mo2005k(ConstraintLayout constraintLayout) {
        View[] viewArr = this.f1757f;
        if (viewArr == null || viewArr.length != this.f1753b) {
            this.f1757f = new View[this.f1753b];
        }
        for (int i = 0; i < this.f1753b; i++) {
            this.f1757f[i] = constraintLayout.mo2023j(this.f1752a[i]);
        }
        return this.f1757f;
    }

    /* access modifiers changed from: protected */
    /* renamed from: l */
    public void mo1809l(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C0418e.f1992b);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 19) {
                    String string = obtainStyledAttributes.getString(index);
                    this.f1756e = string;
                    mo2006o(string);
                }
            }
        }
    }

    /* renamed from: m */
    public void mo1810m(C0411c.C0412a aVar, C4669j jVar, ConstraintLayout.LayoutParams layoutParams, SparseArray<C4662e> sparseArray) {
        C0411c.C0413b bVar = aVar.f1898d;
        int[] iArr = bVar.f1938f0;
        int i = 0;
        if (iArr != null) {
            mo2008p(iArr);
        } else {
            String str = bVar.f1940g0;
            if (str != null && str.length() > 0) {
                C0411c.C0413b bVar2 = aVar.f1898d;
                String[] split = bVar2.f1940g0.split(",");
                getContext();
                int[] iArr2 = new int[split.length];
                int i2 = 0;
                for (String trim : split) {
                    int i3 = m1891i(trim.trim());
                    if (i3 != 0) {
                        iArr2[i2] = i3;
                        i2++;
                    }
                }
                if (i2 != split.length) {
                    iArr2 = Arrays.copyOf(iArr2, i2);
                }
                bVar2.f1938f0 = iArr2;
            }
        }
        jVar.mo21708b();
        if (aVar.f1898d.f1938f0 != null) {
            while (true) {
                int[] iArr3 = aVar.f1898d.f1938f0;
                if (i < iArr3.length) {
                    C4662e eVar = sparseArray.get(iArr3[i]);
                    if (eVar != null) {
                        jVar.mo21707a(eVar);
                    }
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    /* renamed from: n */
    public void mo1811n(C4662e eVar, boolean z) {
    }

    /* access modifiers changed from: protected */
    /* renamed from: o */
    public void mo2006o(String str) {
        this.f1756e = str;
        if (str != null) {
            int i = 0;
            this.f1753b = 0;
            while (true) {
                int indexOf = str.indexOf(44, i);
                if (indexOf == -1) {
                    m1888e(str.substring(i));
                    return;
                } else {
                    m1888e(str.substring(i, indexOf));
                    i = indexOf + 1;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.f1756e;
        if (str != null) {
            mo2006o(str);
        }
    }

    public void onDraw(Canvas canvas) {
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        setMeasuredDimension(0, 0);
    }

    /* renamed from: p */
    public void mo2008p(int[] iArr) {
        this.f1756e = null;
        this.f1753b = 0;
        for (int f : iArr) {
            m1889f(f);
        }
    }

    /* renamed from: q */
    public void mo1815q(ConstraintLayout constraintLayout) {
    }

    /* renamed from: r */
    public void mo2009r() {
    }

    /* renamed from: s */
    public void mo1816s(ConstraintLayout constraintLayout) {
    }

    /* renamed from: t */
    public void mo2010t(C4668i iVar, SparseArray sparseArray) {
        iVar.mo21708b();
        for (int i = 0; i < this.f1753b; i++) {
            iVar.mo21707a((C4662e) sparseArray.get(this.f1752a[i]));
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0022, code lost:
        r1 = r5.f1758g.get(java.lang.Integer.valueOf(r1));
     */
    /* renamed from: u */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2011u(androidx.constraintlayout.widget.ConstraintLayout r6) {
        /*
            r5 = this;
            boolean r0 = r5.isInEditMode()
            if (r0 == 0) goto L_0x000b
            java.lang.String r0 = r5.f1756e
            r5.mo2006o(r0)
        L_0x000b:
            d.e.b.i.i r0 = r5.f1755d
            if (r0 != 0) goto L_0x0010
            return
        L_0x0010:
            r0.mo21708b()
            r0 = 0
        L_0x0014:
            int r1 = r5.f1753b
            if (r0 >= r1) goto L_0x0053
            int[] r1 = r5.f1752a
            r1 = r1[r0]
            android.view.View r2 = r6.mo2023j(r1)
            if (r2 != 0) goto L_0x0045
            java.util.HashMap<java.lang.Integer, java.lang.String> r3 = r5.f1758g
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            java.lang.Object r1 = r3.get(r1)
            java.lang.String r1 = (java.lang.String) r1
            int r3 = r5.m1890h(r6, r1)
            if (r3 == 0) goto L_0x0045
            int[] r2 = r5.f1752a
            r2[r0] = r3
            java.util.HashMap<java.lang.Integer, java.lang.String> r2 = r5.f1758g
            java.lang.Integer r4 = java.lang.Integer.valueOf(r3)
            r2.put(r4, r1)
            android.view.View r2 = r6.mo2023j(r3)
        L_0x0045:
            if (r2 == 0) goto L_0x0050
            d.e.b.i.i r1 = r5.f1755d
            d.e.b.i.e r2 = r6.mo2024k(r2)
            r1.mo21707a(r2)
        L_0x0050:
            int r0 = r0 + 1
            goto L_0x0014
        L_0x0053:
            d.e.b.i.i r0 = r5.f1755d
            d.e.b.i.f r6 = r6.f1761c
            r0.mo21709c(r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintHelper.mo2011u(androidx.constraintlayout.widget.ConstraintLayout):void");
    }

    /* renamed from: v */
    public void mo2012v() {
        if (this.f1755d != null) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            if (layoutParams instanceof ConstraintLayout.LayoutParams) {
                ((ConstraintLayout.LayoutParams) layoutParams).f1825l0 = (C4662e) this.f1755d;
            }
        }
    }
}
