package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.common.api.C4291a;
import java.util.ArrayList;
import java.util.HashMap;
import p098d.p113e.p116b.p117i.C4662e;
import p098d.p113e.p116b.p117i.C4664f;
import p098d.p113e.p116b.p117i.C4667h;
import p098d.p113e.p116b.p117i.p118n.C4674b;

public class ConstraintLayout extends ViewGroup {

    /* renamed from: a */
    SparseArray<View> f1759a = new SparseArray<>();
    /* access modifiers changed from: private */

    /* renamed from: b */
    public ArrayList<ConstraintHelper> f1760b = new ArrayList<>(4);
    /* access modifiers changed from: protected */

    /* renamed from: c */
    public C4664f f1761c = new C4664f();

    /* renamed from: d */
    private int f1762d = 0;

    /* renamed from: e */
    private int f1763e = 0;

    /* renamed from: f */
    private int f1764f = C4291a.C4299e.API_PRIORITY_OTHER;

    /* renamed from: g */
    private int f1765g = C4291a.C4299e.API_PRIORITY_OTHER;

    /* renamed from: h */
    protected boolean f1766h = true;

    /* renamed from: i */
    private int f1767i = 263;

    /* renamed from: j */
    private C0411c f1768j = null;

    /* renamed from: k */
    protected C0408b f1769k = null;

    /* renamed from: l */
    private int f1770l = -1;

    /* renamed from: m */
    private HashMap<String, Integer> f1771m = new HashMap<>();

    /* renamed from: n */
    private int f1772n = -1;

    /* renamed from: o */
    private int f1773o = -1;

    /* renamed from: p */
    private SparseArray<C4662e> f1774p = new SparseArray<>();

    /* renamed from: q */
    C0406a f1775q = new C0406a(this, this);

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {

        /* renamed from: A */
        public float f1776A = 0.5f;

        /* renamed from: B */
        public String f1777B = null;

        /* renamed from: C */
        int f1778C = 1;

        /* renamed from: D */
        public float f1779D = -1.0f;

        /* renamed from: E */
        public float f1780E = -1.0f;

        /* renamed from: F */
        public int f1781F = 0;

        /* renamed from: G */
        public int f1782G = 0;

        /* renamed from: H */
        public int f1783H = 0;

        /* renamed from: I */
        public int f1784I = 0;

        /* renamed from: J */
        public int f1785J = 0;

        /* renamed from: K */
        public int f1786K = 0;

        /* renamed from: L */
        public int f1787L = 0;

        /* renamed from: M */
        public int f1788M = 0;

        /* renamed from: N */
        public float f1789N = 1.0f;

        /* renamed from: O */
        public float f1790O = 1.0f;

        /* renamed from: P */
        public int f1791P = -1;

        /* renamed from: Q */
        public int f1792Q = -1;

        /* renamed from: R */
        public int f1793R = -1;

        /* renamed from: S */
        public boolean f1794S = false;

        /* renamed from: T */
        public boolean f1795T = false;

        /* renamed from: U */
        public String f1796U = null;

        /* renamed from: V */
        boolean f1797V = true;

        /* renamed from: W */
        boolean f1798W = true;

        /* renamed from: X */
        boolean f1799X = false;

        /* renamed from: Y */
        boolean f1800Y = false;

        /* renamed from: Z */
        boolean f1801Z = false;

        /* renamed from: a */
        public int f1802a = -1;

        /* renamed from: a0 */
        boolean f1803a0 = false;

        /* renamed from: b */
        public int f1804b = -1;

        /* renamed from: b0 */
        int f1805b0 = -1;

        /* renamed from: c */
        public float f1806c = -1.0f;

        /* renamed from: c0 */
        int f1807c0 = -1;

        /* renamed from: d */
        public int f1808d = -1;

        /* renamed from: d0 */
        int f1809d0 = -1;

        /* renamed from: e */
        public int f1810e = -1;

        /* renamed from: e0 */
        int f1811e0 = -1;

        /* renamed from: f */
        public int f1812f = -1;

        /* renamed from: f0 */
        int f1813f0 = -1;

        /* renamed from: g */
        public int f1814g = -1;

        /* renamed from: g0 */
        int f1815g0 = -1;

        /* renamed from: h */
        public int f1816h = -1;

        /* renamed from: h0 */
        float f1817h0 = 0.5f;

        /* renamed from: i */
        public int f1818i = -1;

        /* renamed from: i0 */
        int f1819i0;

        /* renamed from: j */
        public int f1820j = -1;

        /* renamed from: j0 */
        int f1821j0;

        /* renamed from: k */
        public int f1822k = -1;

        /* renamed from: k0 */
        float f1823k0;

        /* renamed from: l */
        public int f1824l = -1;

        /* renamed from: l0 */
        C4662e f1825l0 = new C4662e();

        /* renamed from: m */
        public int f1826m = -1;

        /* renamed from: n */
        public int f1827n = 0;

        /* renamed from: o */
        public float f1828o = 0.0f;

        /* renamed from: p */
        public int f1829p = -1;

        /* renamed from: q */
        public int f1830q = -1;

        /* renamed from: r */
        public int f1831r = -1;

        /* renamed from: s */
        public int f1832s = -1;

        /* renamed from: t */
        public int f1833t = -1;

        /* renamed from: u */
        public int f1834u = -1;

        /* renamed from: v */
        public int f1835v = -1;

        /* renamed from: w */
        public int f1836w = -1;

        /* renamed from: x */
        public int f1837x = -1;

        /* renamed from: y */
        public int f1838y = -1;

        /* renamed from: z */
        public float f1839z = 0.5f;

        /* renamed from: androidx.constraintlayout.widget.ConstraintLayout$LayoutParams$a */
        private static class C0405a {

            /* renamed from: a */
            public static final SparseIntArray f1840a;

            static {
                SparseIntArray sparseIntArray = new SparseIntArray();
                f1840a = sparseIntArray;
                sparseIntArray.append(63, 8);
                sparseIntArray.append(64, 9);
                sparseIntArray.append(66, 10);
                sparseIntArray.append(67, 11);
                sparseIntArray.append(73, 12);
                sparseIntArray.append(72, 13);
                sparseIntArray.append(45, 14);
                sparseIntArray.append(44, 15);
                sparseIntArray.append(42, 16);
                sparseIntArray.append(46, 2);
                sparseIntArray.append(48, 3);
                sparseIntArray.append(47, 4);
                sparseIntArray.append(81, 49);
                sparseIntArray.append(82, 50);
                sparseIntArray.append(52, 5);
                sparseIntArray.append(53, 6);
                sparseIntArray.append(54, 7);
                sparseIntArray.append(0, 1);
                sparseIntArray.append(68, 17);
                sparseIntArray.append(69, 18);
                sparseIntArray.append(51, 19);
                sparseIntArray.append(50, 20);
                sparseIntArray.append(85, 21);
                sparseIntArray.append(88, 22);
                sparseIntArray.append(86, 23);
                sparseIntArray.append(83, 24);
                sparseIntArray.append(87, 25);
                sparseIntArray.append(84, 26);
                sparseIntArray.append(59, 29);
                sparseIntArray.append(74, 30);
                sparseIntArray.append(49, 44);
                sparseIntArray.append(61, 45);
                sparseIntArray.append(76, 46);
                sparseIntArray.append(60, 47);
                sparseIntArray.append(75, 48);
                sparseIntArray.append(40, 27);
                sparseIntArray.append(39, 28);
                sparseIntArray.append(77, 31);
                sparseIntArray.append(55, 32);
                sparseIntArray.append(79, 33);
                sparseIntArray.append(78, 34);
                sparseIntArray.append(80, 35);
                sparseIntArray.append(57, 36);
                sparseIntArray.append(56, 37);
                sparseIntArray.append(58, 38);
                sparseIntArray.append(62, 39);
                sparseIntArray.append(71, 40);
                sparseIntArray.append(65, 41);
                sparseIntArray.append(43, 42);
                sparseIntArray.append(41, 43);
                sparseIntArray.append(70, 51);
            }
        }

        public LayoutParams(int i, int i2) {
            super(i, i2);
        }

        /* JADX WARNING: Can't fix incorrect switch cases order */
        /* JADX WARNING: Code restructure failed: missing block: B:37:0x013f, code lost:
            android.util.Log.e("ConstraintLayout", r4);
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public LayoutParams(android.content.Context r10, android.util.AttributeSet r11) {
            /*
                r9 = this;
                r9.<init>(r10, r11)
                r0 = -1
                r9.f1802a = r0
                r9.f1804b = r0
                r1 = -1082130432(0xffffffffbf800000, float:-1.0)
                r9.f1806c = r1
                r9.f1808d = r0
                r9.f1810e = r0
                r9.f1812f = r0
                r9.f1814g = r0
                r9.f1816h = r0
                r9.f1818i = r0
                r9.f1820j = r0
                r9.f1822k = r0
                r9.f1824l = r0
                r9.f1826m = r0
                r2 = 0
                r9.f1827n = r2
                r3 = 0
                r9.f1828o = r3
                r9.f1829p = r0
                r9.f1830q = r0
                r9.f1831r = r0
                r9.f1832s = r0
                r9.f1833t = r0
                r9.f1834u = r0
                r9.f1835v = r0
                r9.f1836w = r0
                r9.f1837x = r0
                r9.f1838y = r0
                r4 = 1056964608(0x3f000000, float:0.5)
                r9.f1839z = r4
                r9.f1776A = r4
                r5 = 0
                r9.f1777B = r5
                r6 = 1
                r9.f1778C = r6
                r9.f1779D = r1
                r9.f1780E = r1
                r9.f1781F = r2
                r9.f1782G = r2
                r9.f1783H = r2
                r9.f1784I = r2
                r9.f1785J = r2
                r9.f1786K = r2
                r9.f1787L = r2
                r9.f1788M = r2
                r1 = 1065353216(0x3f800000, float:1.0)
                r9.f1789N = r1
                r9.f1790O = r1
                r9.f1791P = r0
                r9.f1792Q = r0
                r9.f1793R = r0
                r9.f1794S = r2
                r9.f1795T = r2
                r9.f1796U = r5
                r9.f1797V = r6
                r9.f1798W = r6
                r9.f1799X = r2
                r9.f1800Y = r2
                r9.f1801Z = r2
                r9.f1803a0 = r2
                r9.f1805b0 = r0
                r9.f1807c0 = r0
                r9.f1809d0 = r0
                r9.f1811e0 = r0
                r9.f1813f0 = r0
                r9.f1815g0 = r0
                r9.f1817h0 = r4
                d.e.b.i.e r1 = new d.e.b.i.e
                r1.<init>()
                r9.f1825l0 = r1
                int[] r1 = androidx.constraintlayout.widget.C0418e.f1992b
                android.content.res.TypedArray r10 = r10.obtainStyledAttributes(r11, r1)
                int r11 = r10.getIndexCount()
                r1 = 0
            L_0x0098:
                if (r1 >= r11) goto L_0x03c2
                int r4 = r10.getIndex(r1)
                android.util.SparseIntArray r5 = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.C0405a.f1840a
                int r5 = r5.get(r4)
                r7 = 2
                r8 = -2
                switch(r5) {
                    case 1: goto L_0x02e4;
                    case 2: goto L_0x02d2;
                    case 3: goto L_0x02c8;
                    case 4: goto L_0x02b2;
                    case 5: goto L_0x02a8;
                    case 6: goto L_0x029e;
                    case 7: goto L_0x0294;
                    case 8: goto L_0x0282;
                    case 9: goto L_0x0270;
                    case 10: goto L_0x025e;
                    case 11: goto L_0x024c;
                    case 12: goto L_0x023a;
                    case 13: goto L_0x0228;
                    case 14: goto L_0x0216;
                    case 15: goto L_0x0204;
                    case 16: goto L_0x01f2;
                    case 17: goto L_0x01e0;
                    case 18: goto L_0x01ce;
                    case 19: goto L_0x01bc;
                    case 20: goto L_0x01aa;
                    case 21: goto L_0x01a0;
                    case 22: goto L_0x0196;
                    case 23: goto L_0x018c;
                    case 24: goto L_0x0182;
                    case 25: goto L_0x0178;
                    case 26: goto L_0x016e;
                    case 27: goto L_0x0164;
                    case 28: goto L_0x015a;
                    case 29: goto L_0x0150;
                    case 30: goto L_0x0146;
                    case 31: goto L_0x0135;
                    case 32: goto L_0x012a;
                    case 33: goto L_0x0113;
                    case 34: goto L_0x00fc;
                    case 35: goto L_0x00ec;
                    case 36: goto L_0x00d5;
                    case 37: goto L_0x00be;
                    case 38: goto L_0x00ae;
                    default: goto L_0x00a9;
                }
            L_0x00a9:
                switch(r5) {
                    case 44: goto L_0x032e;
                    case 45: goto L_0x0324;
                    case 46: goto L_0x031a;
                    case 47: goto L_0x0312;
                    case 48: goto L_0x030a;
                    case 49: goto L_0x0300;
                    case 50: goto L_0x02f6;
                    case 51: goto L_0x02ee;
                    default: goto L_0x00ac;
                }
            L_0x00ac:
                goto L_0x03be
            L_0x00ae:
                float r5 = r9.f1790O
                float r4 = r10.getFloat(r4, r5)
                float r4 = java.lang.Math.max(r3, r4)
                r9.f1790O = r4
                r9.f1784I = r7
                goto L_0x03be
            L_0x00be:
                int r5 = r9.f1788M     // Catch:{ Exception -> 0x00c8 }
                int r5 = r10.getDimensionPixelSize(r4, r5)     // Catch:{ Exception -> 0x00c8 }
                r9.f1788M = r5     // Catch:{ Exception -> 0x00c8 }
                goto L_0x03be
            L_0x00c8:
                int r5 = r9.f1788M
                int r4 = r10.getInt(r4, r5)
                if (r4 != r8) goto L_0x03be
                r9.f1788M = r8
                goto L_0x03be
            L_0x00d5:
                int r5 = r9.f1786K     // Catch:{ Exception -> 0x00df }
                int r5 = r10.getDimensionPixelSize(r4, r5)     // Catch:{ Exception -> 0x00df }
                r9.f1786K = r5     // Catch:{ Exception -> 0x00df }
                goto L_0x03be
            L_0x00df:
                int r5 = r9.f1786K
                int r4 = r10.getInt(r4, r5)
                if (r4 != r8) goto L_0x03be
                r9.f1786K = r8
                goto L_0x03be
            L_0x00ec:
                float r5 = r9.f1789N
                float r4 = r10.getFloat(r4, r5)
                float r4 = java.lang.Math.max(r3, r4)
                r9.f1789N = r4
                r9.f1783H = r7
                goto L_0x03be
            L_0x00fc:
                int r5 = r9.f1787L     // Catch:{ Exception -> 0x0106 }
                int r5 = r10.getDimensionPixelSize(r4, r5)     // Catch:{ Exception -> 0x0106 }
                r9.f1787L = r5     // Catch:{ Exception -> 0x0106 }
                goto L_0x03be
            L_0x0106:
                int r5 = r9.f1787L
                int r4 = r10.getInt(r4, r5)
                if (r4 != r8) goto L_0x03be
                r9.f1787L = r8
                goto L_0x03be
            L_0x0113:
                int r5 = r9.f1785J     // Catch:{ Exception -> 0x011d }
                int r5 = r10.getDimensionPixelSize(r4, r5)     // Catch:{ Exception -> 0x011d }
                r9.f1785J = r5     // Catch:{ Exception -> 0x011d }
                goto L_0x03be
            L_0x011d:
                int r5 = r9.f1785J
                int r4 = r10.getInt(r4, r5)
                if (r4 != r8) goto L_0x03be
                r9.f1785J = r8
                goto L_0x03be
            L_0x012a:
                int r4 = r10.getInt(r4, r2)
                r9.f1784I = r4
                if (r4 != r6) goto L_0x03be
                java.lang.String r4 = "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead."
                goto L_0x013f
            L_0x0135:
                int r4 = r10.getInt(r4, r2)
                r9.f1783H = r4
                if (r4 != r6) goto L_0x03be
                java.lang.String r4 = "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead."
            L_0x013f:
                java.lang.String r5 = "ConstraintLayout"
                android.util.Log.e(r5, r4)
                goto L_0x03be
            L_0x0146:
                float r5 = r9.f1776A
                float r4 = r10.getFloat(r4, r5)
                r9.f1776A = r4
                goto L_0x03be
            L_0x0150:
                float r5 = r9.f1839z
                float r4 = r10.getFloat(r4, r5)
                r9.f1839z = r4
                goto L_0x03be
            L_0x015a:
                boolean r5 = r9.f1795T
                boolean r4 = r10.getBoolean(r4, r5)
                r9.f1795T = r4
                goto L_0x03be
            L_0x0164:
                boolean r5 = r9.f1794S
                boolean r4 = r10.getBoolean(r4, r5)
                r9.f1794S = r4
                goto L_0x03be
            L_0x016e:
                int r5 = r9.f1838y
                int r4 = r10.getDimensionPixelSize(r4, r5)
                r9.f1838y = r4
                goto L_0x03be
            L_0x0178:
                int r5 = r9.f1837x
                int r4 = r10.getDimensionPixelSize(r4, r5)
                r9.f1837x = r4
                goto L_0x03be
            L_0x0182:
                int r5 = r9.f1836w
                int r4 = r10.getDimensionPixelSize(r4, r5)
                r9.f1836w = r4
                goto L_0x03be
            L_0x018c:
                int r5 = r9.f1835v
                int r4 = r10.getDimensionPixelSize(r4, r5)
                r9.f1835v = r4
                goto L_0x03be
            L_0x0196:
                int r5 = r9.f1834u
                int r4 = r10.getDimensionPixelSize(r4, r5)
                r9.f1834u = r4
                goto L_0x03be
            L_0x01a0:
                int r5 = r9.f1833t
                int r4 = r10.getDimensionPixelSize(r4, r5)
                r9.f1833t = r4
                goto L_0x03be
            L_0x01aa:
                int r5 = r9.f1832s
                int r5 = r10.getResourceId(r4, r5)
                r9.f1832s = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1832s = r4
                goto L_0x03be
            L_0x01bc:
                int r5 = r9.f1831r
                int r5 = r10.getResourceId(r4, r5)
                r9.f1831r = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1831r = r4
                goto L_0x03be
            L_0x01ce:
                int r5 = r9.f1830q
                int r5 = r10.getResourceId(r4, r5)
                r9.f1830q = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1830q = r4
                goto L_0x03be
            L_0x01e0:
                int r5 = r9.f1829p
                int r5 = r10.getResourceId(r4, r5)
                r9.f1829p = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1829p = r4
                goto L_0x03be
            L_0x01f2:
                int r5 = r9.f1824l
                int r5 = r10.getResourceId(r4, r5)
                r9.f1824l = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1824l = r4
                goto L_0x03be
            L_0x0204:
                int r5 = r9.f1822k
                int r5 = r10.getResourceId(r4, r5)
                r9.f1822k = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1822k = r4
                goto L_0x03be
            L_0x0216:
                int r5 = r9.f1820j
                int r5 = r10.getResourceId(r4, r5)
                r9.f1820j = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1820j = r4
                goto L_0x03be
            L_0x0228:
                int r5 = r9.f1818i
                int r5 = r10.getResourceId(r4, r5)
                r9.f1818i = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1818i = r4
                goto L_0x03be
            L_0x023a:
                int r5 = r9.f1816h
                int r5 = r10.getResourceId(r4, r5)
                r9.f1816h = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1816h = r4
                goto L_0x03be
            L_0x024c:
                int r5 = r9.f1814g
                int r5 = r10.getResourceId(r4, r5)
                r9.f1814g = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1814g = r4
                goto L_0x03be
            L_0x025e:
                int r5 = r9.f1812f
                int r5 = r10.getResourceId(r4, r5)
                r9.f1812f = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1812f = r4
                goto L_0x03be
            L_0x0270:
                int r5 = r9.f1810e
                int r5 = r10.getResourceId(r4, r5)
                r9.f1810e = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1810e = r4
                goto L_0x03be
            L_0x0282:
                int r5 = r9.f1808d
                int r5 = r10.getResourceId(r4, r5)
                r9.f1808d = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1808d = r4
                goto L_0x03be
            L_0x0294:
                float r5 = r9.f1806c
                float r4 = r10.getFloat(r4, r5)
                r9.f1806c = r4
                goto L_0x03be
            L_0x029e:
                int r5 = r9.f1804b
                int r4 = r10.getDimensionPixelOffset(r4, r5)
                r9.f1804b = r4
                goto L_0x03be
            L_0x02a8:
                int r5 = r9.f1802a
                int r4 = r10.getDimensionPixelOffset(r4, r5)
                r9.f1802a = r4
                goto L_0x03be
            L_0x02b2:
                float r5 = r9.f1828o
                float r4 = r10.getFloat(r4, r5)
                r5 = 1135869952(0x43b40000, float:360.0)
                float r4 = r4 % r5
                r9.f1828o = r4
                int r7 = (r4 > r3 ? 1 : (r4 == r3 ? 0 : -1))
                if (r7 >= 0) goto L_0x03be
                float r4 = r5 - r4
                float r4 = r4 % r5
                r9.f1828o = r4
                goto L_0x03be
            L_0x02c8:
                int r5 = r9.f1827n
                int r4 = r10.getDimensionPixelSize(r4, r5)
                r9.f1827n = r4
                goto L_0x03be
            L_0x02d2:
                int r5 = r9.f1826m
                int r5 = r10.getResourceId(r4, r5)
                r9.f1826m = r5
                if (r5 != r0) goto L_0x03be
                int r4 = r10.getInt(r4, r0)
                r9.f1826m = r4
                goto L_0x03be
            L_0x02e4:
                int r5 = r9.f1793R
                int r4 = r10.getInt(r4, r5)
                r9.f1793R = r4
                goto L_0x03be
            L_0x02ee:
                java.lang.String r4 = r10.getString(r4)
                r9.f1796U = r4
                goto L_0x03be
            L_0x02f6:
                int r5 = r9.f1792Q
                int r4 = r10.getDimensionPixelOffset(r4, r5)
                r9.f1792Q = r4
                goto L_0x03be
            L_0x0300:
                int r5 = r9.f1791P
                int r4 = r10.getDimensionPixelOffset(r4, r5)
                r9.f1791P = r4
                goto L_0x03be
            L_0x030a:
                int r4 = r10.getInt(r4, r2)
                r9.f1782G = r4
                goto L_0x03be
            L_0x0312:
                int r4 = r10.getInt(r4, r2)
                r9.f1781F = r4
                goto L_0x03be
            L_0x031a:
                float r5 = r9.f1780E
                float r4 = r10.getFloat(r4, r5)
                r9.f1780E = r4
                goto L_0x03be
            L_0x0324:
                float r5 = r9.f1779D
                float r4 = r10.getFloat(r4, r5)
                r9.f1779D = r4
                goto L_0x03be
            L_0x032e:
                java.lang.String r4 = r10.getString(r4)
                r9.f1777B = r4
                r9.f1778C = r0
                if (r4 == 0) goto L_0x03be
                int r4 = r4.length()
                java.lang.String r5 = r9.f1777B
                r7 = 44
                int r5 = r5.indexOf(r7)
                if (r5 <= 0) goto L_0x0368
                int r7 = r4 + -1
                if (r5 >= r7) goto L_0x0368
                java.lang.String r7 = r9.f1777B
                java.lang.String r7 = r7.substring(r2, r5)
                java.lang.String r8 = "W"
                boolean r8 = r7.equalsIgnoreCase(r8)
                if (r8 == 0) goto L_0x035b
                r9.f1778C = r2
                goto L_0x0365
            L_0x035b:
                java.lang.String r8 = "H"
                boolean r7 = r7.equalsIgnoreCase(r8)
                if (r7 == 0) goto L_0x0365
                r9.f1778C = r6
            L_0x0365:
                int r5 = r5 + 1
                goto L_0x0369
            L_0x0368:
                r5 = 0
            L_0x0369:
                java.lang.String r7 = r9.f1777B
                r8 = 58
                int r7 = r7.indexOf(r8)
                if (r7 < 0) goto L_0x03af
                int r4 = r4 + -1
                if (r7 >= r4) goto L_0x03af
                java.lang.String r4 = r9.f1777B
                java.lang.String r4 = r4.substring(r5, r7)
                java.lang.String r5 = r9.f1777B
                int r7 = r7 + 1
                java.lang.String r5 = r5.substring(r7)
                int r7 = r4.length()
                if (r7 <= 0) goto L_0x03be
                int r7 = r5.length()
                if (r7 <= 0) goto L_0x03be
                float r4 = java.lang.Float.parseFloat(r4)     // Catch:{ NumberFormatException -> 0x03be }
                float r5 = java.lang.Float.parseFloat(r5)     // Catch:{ NumberFormatException -> 0x03be }
                int r7 = (r4 > r3 ? 1 : (r4 == r3 ? 0 : -1))
                if (r7 <= 0) goto L_0x03be
                int r7 = (r5 > r3 ? 1 : (r5 == r3 ? 0 : -1))
                if (r7 <= 0) goto L_0x03be
                int r7 = r9.f1778C     // Catch:{ NumberFormatException -> 0x03be }
                if (r7 != r6) goto L_0x03aa
                float r5 = r5 / r4
                java.lang.Math.abs(r5)     // Catch:{ NumberFormatException -> 0x03be }
                goto L_0x03be
            L_0x03aa:
                float r4 = r4 / r5
                java.lang.Math.abs(r4)     // Catch:{ NumberFormatException -> 0x03be }
                goto L_0x03be
            L_0x03af:
                java.lang.String r4 = r9.f1777B
                java.lang.String r4 = r4.substring(r5)
                int r5 = r4.length()
                if (r5 <= 0) goto L_0x03be
                java.lang.Float.parseFloat(r4)     // Catch:{ NumberFormatException -> 0x03be }
            L_0x03be:
                int r1 = r1 + 1
                goto L_0x0098
            L_0x03c2:
                r10.recycle()
                r9.mo2035b()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.<init>(android.content.Context, android.util.AttributeSet):void");
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        /* renamed from: a */
        public C4662e mo2034a() {
            return this.f1825l0;
        }

        /* renamed from: b */
        public void mo2035b() {
            this.f1800Y = false;
            this.f1797V = true;
            this.f1798W = true;
            int i = this.width;
            if (i == -2 && this.f1794S) {
                this.f1797V = false;
                if (this.f1783H == 0) {
                    this.f1783H = 1;
                }
            }
            int i2 = this.height;
            if (i2 == -2 && this.f1795T) {
                this.f1798W = false;
                if (this.f1784I == 0) {
                    this.f1784I = 1;
                }
            }
            if (i == 0 || i == -1) {
                this.f1797V = false;
                if (i == 0 && this.f1783H == 1) {
                    this.width = -2;
                    this.f1794S = true;
                }
            }
            if (i2 == 0 || i2 == -1) {
                this.f1798W = false;
                if (i2 == 0 && this.f1784I == 1) {
                    this.height = -2;
                    this.f1795T = true;
                }
            }
            if (this.f1806c != -1.0f || this.f1802a != -1 || this.f1804b != -1) {
                this.f1800Y = true;
                this.f1797V = true;
                this.f1798W = true;
                if (!(this.f1825l0 instanceof C4667h)) {
                    this.f1825l0 = new C4667h();
                }
                ((C4667h) this.f1825l0).mo21706z0(this.f1793R);
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:70:0x00ce, code lost:
            if (r1 > 0) goto L_0x00d0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:76:0x00dd, code lost:
            if (r1 > 0) goto L_0x00d0;
         */
        /* JADX WARNING: Removed duplicated region for block: B:15:0x004c  */
        /* JADX WARNING: Removed duplicated region for block: B:18:0x0053  */
        /* JADX WARNING: Removed duplicated region for block: B:21:0x005a  */
        /* JADX WARNING: Removed duplicated region for block: B:24:0x0060  */
        /* JADX WARNING: Removed duplicated region for block: B:27:0x0066  */
        /* JADX WARNING: Removed duplicated region for block: B:34:0x0078  */
        /* JADX WARNING: Removed duplicated region for block: B:35:0x0080  */
        /* JADX WARNING: Removed duplicated region for block: B:79:0x00e4  */
        /* JADX WARNING: Removed duplicated region for block: B:83:0x00ef  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void resolveLayoutDirection(int r10) {
            /*
                r9 = this;
                int r0 = r9.leftMargin
                int r1 = r9.rightMargin
                super.resolveLayoutDirection(r10)
                int r10 = r9.getLayoutDirection()
                r2 = 0
                r3 = 1
                if (r3 != r10) goto L_0x0011
                r10 = 1
                goto L_0x0012
            L_0x0011:
                r10 = 0
            L_0x0012:
                r4 = -1
                r9.f1809d0 = r4
                r9.f1811e0 = r4
                r9.f1805b0 = r4
                r9.f1807c0 = r4
                r9.f1813f0 = r4
                r9.f1815g0 = r4
                int r5 = r9.f1833t
                r9.f1813f0 = r5
                int r5 = r9.f1835v
                r9.f1815g0 = r5
                float r5 = r9.f1839z
                r9.f1817h0 = r5
                int r6 = r9.f1802a
                r9.f1819i0 = r6
                int r7 = r9.f1804b
                r9.f1821j0 = r7
                float r8 = r9.f1806c
                r9.f1823k0 = r8
                if (r10 == 0) goto L_0x0090
                int r10 = r9.f1829p
                if (r10 == r4) goto L_0x0041
                r9.f1809d0 = r10
            L_0x003f:
                r2 = 1
                goto L_0x0048
            L_0x0041:
                int r10 = r9.f1830q
                if (r10 == r4) goto L_0x0048
                r9.f1811e0 = r10
                goto L_0x003f
            L_0x0048:
                int r10 = r9.f1831r
                if (r10 == r4) goto L_0x004f
                r9.f1807c0 = r10
                r2 = 1
            L_0x004f:
                int r10 = r9.f1832s
                if (r10 == r4) goto L_0x0056
                r9.f1805b0 = r10
                r2 = 1
            L_0x0056:
                int r10 = r9.f1837x
                if (r10 == r4) goto L_0x005c
                r9.f1815g0 = r10
            L_0x005c:
                int r10 = r9.f1838y
                if (r10 == r4) goto L_0x0062
                r9.f1813f0 = r10
            L_0x0062:
                r10 = 1065353216(0x3f800000, float:1.0)
                if (r2 == 0) goto L_0x006a
                float r2 = r10 - r5
                r9.f1817h0 = r2
            L_0x006a:
                boolean r2 = r9.f1800Y
                if (r2 == 0) goto L_0x00b4
                int r2 = r9.f1793R
                if (r2 != r3) goto L_0x00b4
                r2 = -1082130432(0xffffffffbf800000, float:-1.0)
                int r3 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
                if (r3 == 0) goto L_0x0080
                float r10 = r10 - r8
                r9.f1823k0 = r10
                r9.f1819i0 = r4
                r9.f1821j0 = r4
                goto L_0x00b4
            L_0x0080:
                if (r6 == r4) goto L_0x0089
                r9.f1821j0 = r6
                r9.f1819i0 = r4
            L_0x0086:
                r9.f1823k0 = r2
                goto L_0x00b4
            L_0x0089:
                if (r7 == r4) goto L_0x00b4
                r9.f1819i0 = r7
                r9.f1821j0 = r4
                goto L_0x0086
            L_0x0090:
                int r10 = r9.f1829p
                if (r10 == r4) goto L_0x0096
                r9.f1807c0 = r10
            L_0x0096:
                int r10 = r9.f1830q
                if (r10 == r4) goto L_0x009c
                r9.f1805b0 = r10
            L_0x009c:
                int r10 = r9.f1831r
                if (r10 == r4) goto L_0x00a2
                r9.f1809d0 = r10
            L_0x00a2:
                int r10 = r9.f1832s
                if (r10 == r4) goto L_0x00a8
                r9.f1811e0 = r10
            L_0x00a8:
                int r10 = r9.f1837x
                if (r10 == r4) goto L_0x00ae
                r9.f1813f0 = r10
            L_0x00ae:
                int r10 = r9.f1838y
                if (r10 == r4) goto L_0x00b4
                r9.f1815g0 = r10
            L_0x00b4:
                int r10 = r9.f1831r
                if (r10 != r4) goto L_0x00fc
                int r10 = r9.f1832s
                if (r10 != r4) goto L_0x00fc
                int r10 = r9.f1830q
                if (r10 != r4) goto L_0x00fc
                int r10 = r9.f1829p
                if (r10 != r4) goto L_0x00fc
                int r10 = r9.f1812f
                if (r10 == r4) goto L_0x00d3
                r9.f1809d0 = r10
                int r10 = r9.rightMargin
                if (r10 > 0) goto L_0x00e0
                if (r1 <= 0) goto L_0x00e0
            L_0x00d0:
                r9.rightMargin = r1
                goto L_0x00e0
            L_0x00d3:
                int r10 = r9.f1814g
                if (r10 == r4) goto L_0x00e0
                r9.f1811e0 = r10
                int r10 = r9.rightMargin
                if (r10 > 0) goto L_0x00e0
                if (r1 <= 0) goto L_0x00e0
                goto L_0x00d0
            L_0x00e0:
                int r10 = r9.f1808d
                if (r10 == r4) goto L_0x00ef
                r9.f1805b0 = r10
                int r10 = r9.leftMargin
                if (r10 > 0) goto L_0x00fc
                if (r0 <= 0) goto L_0x00fc
            L_0x00ec:
                r9.leftMargin = r0
                goto L_0x00fc
            L_0x00ef:
                int r10 = r9.f1810e
                if (r10 == r4) goto L_0x00fc
                r9.f1807c0 = r10
                int r10 = r9.leftMargin
                if (r10 > 0) goto L_0x00fc
                if (r0 <= 0) goto L_0x00fc
                goto L_0x00ec
            L_0x00fc:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.resolveLayoutDirection(int):void");
        }
    }

    /* renamed from: androidx.constraintlayout.widget.ConstraintLayout$a */
    class C0406a implements C4674b.C4676b {

        /* renamed from: a */
        ConstraintLayout f1841a;

        /* renamed from: b */
        int f1842b;

        /* renamed from: c */
        int f1843c;

        /* renamed from: d */
        int f1844d;

        /* renamed from: e */
        int f1845e;

        /* renamed from: f */
        int f1846f;

        /* renamed from: g */
        int f1847g;

        public C0406a(ConstraintLayout constraintLayout, ConstraintLayout constraintLayout2) {
            this.f1841a = constraintLayout2;
        }

        /* renamed from: a */
        public final void mo2037a() {
            int childCount = this.f1841a.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = this.f1841a.getChildAt(i);
                if (childAt instanceof Placeholder) {
                    ((Placeholder) childAt).mo2049c();
                }
            }
            int size = this.f1841a.f1760b.size();
            if (size > 0) {
                for (int i2 = 0; i2 < size; i2++) {
                    ((ConstraintHelper) this.f1841a.f1760b.get(i2)).mo2009r();
                }
            }
        }

        /* JADX WARNING: Removed duplicated region for block: B:104:0x0177  */
        /* JADX WARNING: Removed duplicated region for block: B:105:0x0179  */
        /* JADX WARNING: Removed duplicated region for block: B:109:0x0182  */
        /* JADX WARNING: Removed duplicated region for block: B:110:0x0184  */
        /* JADX WARNING: Removed duplicated region for block: B:113:0x018f A[ADDED_TO_REGION] */
        /* JADX WARNING: Removed duplicated region for block: B:124:0x01ac  */
        /* JADX WARNING: Removed duplicated region for block: B:125:0x01b6  */
        /* JADX WARNING: Removed duplicated region for block: B:128:0x01c7  */
        /* JADX WARNING: Removed duplicated region for block: B:129:0x01d2  */
        /* JADX WARNING: Removed duplicated region for block: B:131:0x01de  */
        /* JADX WARNING: Removed duplicated region for block: B:132:0x01e8  */
        /* JADX WARNING: Removed duplicated region for block: B:135:0x01f5  */
        /* JADX WARNING: Removed duplicated region for block: B:136:0x01fa  */
        /* JADX WARNING: Removed duplicated region for block: B:139:0x01ff  */
        /* JADX WARNING: Removed duplicated region for block: B:142:0x0207  */
        /* JADX WARNING: Removed duplicated region for block: B:143:0x020c  */
        /* JADX WARNING: Removed duplicated region for block: B:146:0x0211  */
        /* JADX WARNING: Removed duplicated region for block: B:149:0x0219 A[ADDED_TO_REGION] */
        /* JADX WARNING: Removed duplicated region for block: B:159:0x0238  */
        /* JADX WARNING: Removed duplicated region for block: B:161:0x023e  */
        /* JADX WARNING: Removed duplicated region for block: B:164:0x0254  */
        /* JADX WARNING: Removed duplicated region for block: B:165:0x0256  */
        /* JADX WARNING: Removed duplicated region for block: B:170:0x0260  */
        /* JADX WARNING: Removed duplicated region for block: B:171:0x0262  */
        /* JADX WARNING: Removed duplicated region for block: B:174:0x0269  */
        /* JADX WARNING: Removed duplicated region for block: B:48:0x00c5  */
        /* JADX WARNING: Removed duplicated region for block: B:83:0x0141  */
        /* JADX WARNING: Removed duplicated region for block: B:86:0x0154  */
        /* JADX WARNING: Removed duplicated region for block: B:87:0x0156  */
        /* JADX WARNING: Removed duplicated region for block: B:89:0x0159  */
        /* JADX WARNING: Removed duplicated region for block: B:90:0x015b  */
        /* JADX WARNING: Removed duplicated region for block: B:93:0x0160 A[ADDED_TO_REGION] */
        /* JADX WARNING: Removed duplicated region for block: B:97:0x0168 A[ADDED_TO_REGION] */
        /* renamed from: b */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void mo2038b(p098d.p113e.p116b.p117i.C4662e r21, p098d.p113e.p116b.p117i.p118n.C4674b.C4675a r22) {
            /*
                r20 = this;
                r0 = r20
                r1 = r21
                r2 = r22
                d.e.b.i.e$a r3 = p098d.p113e.p116b.p117i.C4662e.C4663a.FIXED
                if (r1 != 0) goto L_0x000b
                return
            L_0x000b:
                int r4 = r21.mo21603H()
                r5 = 8
                r6 = 0
                if (r4 != r5) goto L_0x0021
                boolean r4 = r21.mo21609O()
                if (r4 != 0) goto L_0x0021
                r2.f17040e = r6
                r2.f17041f = r6
                r2.f17042g = r6
                return
            L_0x0021:
                d.e.b.i.e$a r4 = r2.f17036a
                d.e.b.i.e$a r5 = r2.f17037b
                int r7 = r2.f17038c
                int r8 = r2.f17039d
                int r9 = r0.f1842b
                int r10 = r0.f1843c
                int r9 = r9 + r10
                int r10 = r0.f1844d
                java.lang.Object r11 = r21.mo21644p()
                android.view.View r11 = (android.view.View) r11
                int r12 = r4.ordinal()
                r15 = 3
                r14 = 2
                r13 = 1
                if (r12 == 0) goto L_0x00b3
                if (r12 == r13) goto L_0x00a4
                if (r12 == r14) goto L_0x0066
                if (r12 == r15) goto L_0x0049
                r7 = 0
            L_0x0046:
                r10 = 0
                goto L_0x00bf
            L_0x0049:
                int r7 = r0.f1846f
                d.e.b.i.d r12 = r1.f16871A
                if (r12 == 0) goto L_0x0053
                int r12 = r12.f16858e
                int r12 = r12 + r6
                goto L_0x0054
            L_0x0053:
                r12 = 0
            L_0x0054:
                d.e.b.i.d r15 = r1.f16875C
                if (r15 == 0) goto L_0x005b
                int r15 = r15.f16858e
                int r12 = r12 + r15
            L_0x005b:
                int r10 = r10 + r12
                r12 = -1
                int r7 = android.view.ViewGroup.getChildMeasureSpec(r7, r10, r12)
                int[] r10 = r1.f16911g
                r10[r14] = r12
                goto L_0x0046
            L_0x0066:
                int r7 = r0.f1846f
                r12 = -2
                int r7 = android.view.ViewGroup.getChildMeasureSpec(r7, r10, r12)
                int r10 = r1.f16917j
                if (r10 != r13) goto L_0x0073
                r10 = 1
                goto L_0x0074
            L_0x0073:
                r10 = 0
            L_0x0074:
                int[] r12 = r1.f16911g
                r12[r14] = r6
                boolean r15 = r2.f17045j
                if (r15 == 0) goto L_0x00a1
                if (r10 == 0) goto L_0x008b
                r15 = 3
                r18 = r12[r15]
                if (r18 == 0) goto L_0x008b
                r12 = r12[r6]
                int r15 = r21.mo21604I()
                if (r12 != r15) goto L_0x008f
            L_0x008b:
                boolean r12 = r11 instanceof androidx.constraintlayout.widget.Placeholder
                if (r12 == 0) goto L_0x0091
            L_0x008f:
                r12 = 1
                goto L_0x0092
            L_0x0091:
                r12 = 0
            L_0x0092:
                if (r10 == 0) goto L_0x0096
                if (r12 == 0) goto L_0x00a1
            L_0x0096:
                int r7 = r21.mo21604I()
                r12 = 1073741824(0x40000000, float:2.0)
                int r7 = android.view.View.MeasureSpec.makeMeasureSpec(r7, r12)
                goto L_0x0046
            L_0x00a1:
                r12 = 1073741824(0x40000000, float:2.0)
                goto L_0x00b1
            L_0x00a4:
                r12 = 1073741824(0x40000000, float:2.0)
                int r7 = r0.f1846f
                r15 = -2
                int r7 = android.view.ViewGroup.getChildMeasureSpec(r7, r10, r15)
                int[] r10 = r1.f16911g
                r10[r14] = r15
            L_0x00b1:
                r10 = 1
                goto L_0x00bf
            L_0x00b3:
                r12 = 1073741824(0x40000000, float:2.0)
                int r10 = android.view.View.MeasureSpec.makeMeasureSpec(r7, r12)
                int[] r12 = r1.f16911g
                r12[r14] = r7
                r7 = r10
                goto L_0x0046
            L_0x00bf:
                int r12 = r5.ordinal()
                if (r12 == 0) goto L_0x0141
                if (r12 == r13) goto L_0x0130
                if (r12 == r14) goto L_0x00f2
                r8 = 3
                if (r12 == r8) goto L_0x00d0
                r8 = 0
            L_0x00cd:
                r9 = 0
                goto L_0x0150
            L_0x00d0:
                int r8 = r0.f1847g
                d.e.b.i.d r12 = r1.f16871A
                if (r12 == 0) goto L_0x00dc
                d.e.b.i.d r12 = r1.f16873B
                int r12 = r12.f16858e
                int r12 = r12 + r6
                goto L_0x00dd
            L_0x00dc:
                r12 = 0
            L_0x00dd:
                d.e.b.i.d r15 = r1.f16875C
                if (r15 == 0) goto L_0x00e6
                d.e.b.i.d r15 = r1.f16876D
                int r15 = r15.f16858e
                int r12 = r12 + r15
            L_0x00e6:
                int r9 = r9 + r12
                r12 = -1
                int r8 = android.view.ViewGroup.getChildMeasureSpec(r8, r9, r12)
                int[] r9 = r1.f16911g
                r15 = 3
                r9[r15] = r12
                goto L_0x00cd
            L_0x00f2:
                r15 = 3
                int r8 = r0.f1847g
                r12 = -2
                int r8 = android.view.ViewGroup.getChildMeasureSpec(r8, r9, r12)
                int r9 = r1.f16919k
                if (r9 != r13) goto L_0x0100
                r9 = 1
                goto L_0x0101
            L_0x0100:
                r9 = 0
            L_0x0101:
                int[] r12 = r1.f16911g
                r12[r15] = r6
                boolean r15 = r2.f17045j
                if (r15 == 0) goto L_0x012d
                if (r9 == 0) goto L_0x0117
                r15 = r12[r14]
                if (r15 == 0) goto L_0x0117
                r12 = r12[r13]
                int r15 = r21.mo21651t()
                if (r12 != r15) goto L_0x011b
            L_0x0117:
                boolean r12 = r11 instanceof androidx.constraintlayout.widget.Placeholder
                if (r12 == 0) goto L_0x011d
            L_0x011b:
                r12 = 1
                goto L_0x011e
            L_0x011d:
                r12 = 0
            L_0x011e:
                if (r9 == 0) goto L_0x0122
                if (r12 == 0) goto L_0x012d
            L_0x0122:
                int r8 = r21.mo21651t()
                r12 = 1073741824(0x40000000, float:2.0)
                int r8 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r12)
                goto L_0x00cd
            L_0x012d:
                r12 = 1073741824(0x40000000, float:2.0)
                goto L_0x013f
            L_0x0130:
                r12 = 1073741824(0x40000000, float:2.0)
                int r8 = r0.f1847g
                r15 = -2
                int r8 = android.view.ViewGroup.getChildMeasureSpec(r8, r9, r15)
                int[] r9 = r1.f16911g
                r16 = 3
                r9[r16] = r15
            L_0x013f:
                r9 = 1
                goto L_0x0150
            L_0x0141:
                r12 = 1073741824(0x40000000, float:2.0)
                r16 = 3
                int r9 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r12)
                int[] r12 = r1.f16911g
                r12[r16] = r8
                r8 = r9
                goto L_0x00cd
            L_0x0150:
                d.e.b.i.e$a r12 = p098d.p113e.p116b.p117i.C4662e.C4663a.MATCH_CONSTRAINT
                if (r4 != r12) goto L_0x0156
                r15 = 1
                goto L_0x0157
            L_0x0156:
                r15 = 0
            L_0x0157:
                if (r5 != r12) goto L_0x015b
                r12 = 1
                goto L_0x015c
            L_0x015b:
                r12 = 0
            L_0x015c:
                d.e.b.i.e$a r13 = p098d.p113e.p116b.p117i.C4662e.C4663a.MATCH_PARENT
                if (r5 == r13) goto L_0x0165
                if (r5 != r3) goto L_0x0163
                goto L_0x0165
            L_0x0163:
                r5 = 0
                goto L_0x0166
            L_0x0165:
                r5 = 1
            L_0x0166:
                if (r4 == r13) goto L_0x016d
                if (r4 != r3) goto L_0x016b
                goto L_0x016d
            L_0x016b:
                r3 = 0
                goto L_0x016e
            L_0x016d:
                r3 = 1
            L_0x016e:
                r4 = 0
                if (r15 == 0) goto L_0x0179
                float r13 = r1.f16888P
                int r13 = (r13 > r4 ? 1 : (r13 == r4 ? 0 : -1))
                if (r13 <= 0) goto L_0x0179
                r13 = 1
                goto L_0x017a
            L_0x0179:
                r13 = 0
            L_0x017a:
                if (r12 == 0) goto L_0x0184
                float r14 = r1.f16888P
                int r4 = (r14 > r4 ? 1 : (r14 == r4 ? 0 : -1))
                if (r4 <= 0) goto L_0x0184
                r4 = 1
                goto L_0x0185
            L_0x0184:
                r4 = 0
            L_0x0185:
                android.view.ViewGroup$LayoutParams r14 = r11.getLayoutParams()
                androidx.constraintlayout.widget.ConstraintLayout$LayoutParams r14 = (androidx.constraintlayout.widget.ConstraintLayout.LayoutParams) r14
                boolean r6 = r2.f17045j
                if (r6 != 0) goto L_0x01a4
                if (r15 == 0) goto L_0x01a4
                int r6 = r1.f16917j
                if (r6 != 0) goto L_0x01a4
                if (r12 == 0) goto L_0x01a4
                int r6 = r1.f16919k
                if (r6 == 0) goto L_0x019c
                goto L_0x01a4
            L_0x019c:
                r0 = -1
                r9 = 0
                r10 = 0
                r15 = 0
                r19 = 0
                goto L_0x0252
            L_0x01a4:
                boolean r6 = r11 instanceof androidx.constraintlayout.widget.VirtualLayout
                if (r6 == 0) goto L_0x01b6
                boolean r6 = r1 instanceof p098d.p113e.p116b.p117i.C4671l
                if (r6 == 0) goto L_0x01b6
                r6 = r1
                d.e.b.i.l r6 = (p098d.p113e.p116b.p117i.C4671l) r6
                r12 = r11
                androidx.constraintlayout.widget.VirtualLayout r12 = (androidx.constraintlayout.widget.VirtualLayout) r12
                r12.mo1813w(r6, r7, r8)
                goto L_0x01b9
            L_0x01b6:
                r11.measure(r7, r8)
            L_0x01b9:
                int r6 = r11.getMeasuredWidth()
                int r12 = r11.getMeasuredHeight()
                int r15 = r11.getBaseline()
                if (r10 == 0) goto L_0x01d2
                int[] r10 = r1.f16911g
                r19 = 0
                r10[r19] = r6
                r18 = 2
                r10[r18] = r12
                goto L_0x01dc
            L_0x01d2:
                r18 = 2
                r19 = 0
                int[] r10 = r1.f16911g
                r10[r19] = r19
                r10[r18] = r19
            L_0x01dc:
                if (r9 == 0) goto L_0x01e8
                int[] r9 = r1.f16911g
                r10 = 1
                r9[r10] = r12
                r17 = 3
                r9[r17] = r6
                goto L_0x01f1
            L_0x01e8:
                r10 = 1
                r17 = 3
                int[] r9 = r1.f16911g
                r9[r10] = r19
                r9[r17] = r19
            L_0x01f1:
                int r9 = r1.f16923m
                if (r9 <= 0) goto L_0x01fa
                int r9 = java.lang.Math.max(r9, r6)
                goto L_0x01fb
            L_0x01fa:
                r9 = r6
            L_0x01fb:
                int r10 = r1.f16925n
                if (r10 <= 0) goto L_0x0203
                int r9 = java.lang.Math.min(r10, r9)
            L_0x0203:
                int r10 = r1.f16929p
                if (r10 <= 0) goto L_0x020c
                int r10 = java.lang.Math.max(r10, r12)
                goto L_0x020d
            L_0x020c:
                r10 = r12
            L_0x020d:
                int r0 = r1.f16931q
                if (r0 <= 0) goto L_0x0215
                int r10 = java.lang.Math.min(r0, r10)
            L_0x0215:
                r0 = 1056964608(0x3f000000, float:0.5)
                if (r13 == 0) goto L_0x0223
                if (r5 == 0) goto L_0x0223
                float r3 = r1.f16888P
                float r4 = (float) r10
                float r4 = r4 * r3
                float r4 = r4 + r0
                int r9 = (int) r4
                goto L_0x022d
            L_0x0223:
                if (r4 == 0) goto L_0x022d
                if (r3 == 0) goto L_0x022d
                float r3 = r1.f16888P
                float r4 = (float) r9
                float r4 = r4 / r3
                float r4 = r4 + r0
                int r10 = (int) r4
            L_0x022d:
                if (r6 != r9) goto L_0x0234
                if (r12 == r10) goto L_0x0232
                goto L_0x0234
            L_0x0232:
                r0 = -1
                goto L_0x0252
            L_0x0234:
                r0 = 1073741824(0x40000000, float:2.0)
                if (r6 == r9) goto L_0x023c
                int r7 = android.view.View.MeasureSpec.makeMeasureSpec(r9, r0)
            L_0x023c:
                if (r12 == r10) goto L_0x0242
                int r8 = android.view.View.MeasureSpec.makeMeasureSpec(r10, r0)
            L_0x0242:
                r11.measure(r7, r8)
                int r9 = r11.getMeasuredWidth()
                int r10 = r11.getMeasuredHeight()
                int r15 = r11.getBaseline()
                goto L_0x0232
            L_0x0252:
                if (r15 == r0) goto L_0x0256
                r0 = 1
                goto L_0x0257
            L_0x0256:
                r0 = 0
            L_0x0257:
                int r3 = r2.f17038c
                if (r9 != r3) goto L_0x0262
                int r3 = r2.f17039d
                if (r10 == r3) goto L_0x0260
                goto L_0x0262
            L_0x0260:
                r6 = 0
                goto L_0x0263
            L_0x0262:
                r6 = 1
            L_0x0263:
                r2.f17044i = r6
                boolean r3 = r14.f1799X
                if (r3 == 0) goto L_0x026a
                r0 = 1
            L_0x026a:
                if (r0 == 0) goto L_0x0278
                r3 = -1
                if (r15 == r3) goto L_0x0278
                int r1 = r21.mo21638m()
                if (r1 == r15) goto L_0x0278
                r1 = 1
                r2.f17044i = r1
            L_0x0278:
                r2.f17040e = r9
                r2.f17041f = r10
                r2.f17043h = r0
                r2.f17042g = r15
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.C0406a.mo2038b(d.e.b.i.e, d.e.b.i.n.b$a):void");
        }
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m1907r(attributeSet, 0, 0);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        m1907r(attributeSet, i, 0);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        m1907r(attributeSet, i, i2);
    }

    /* renamed from: r */
    private void m1907r(AttributeSet attributeSet, int i, int i2) {
        this.f1761c.mo21615U(this);
        this.f1761c.mo21659B0(this.f1775q);
        this.f1759a.put(getId(), this);
        this.f1768j = null;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C0418e.f1992b, i, i2);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i3 = 0; i3 < indexCount; i3++) {
                int index = obtainStyledAttributes.getIndex(i3);
                if (index == 9) {
                    this.f1762d = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1762d);
                } else if (index == 10) {
                    this.f1763e = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1763e);
                } else if (index == 7) {
                    this.f1764f = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1764f);
                } else if (index == 8) {
                    this.f1765g = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1765g);
                } else if (index == 89) {
                    this.f1767i = obtainStyledAttributes.getInt(index, this.f1767i);
                } else if (index == 38) {
                    int resourceId = obtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            mo1864t(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.f1769k = null;
                        }
                    }
                } else if (index == 18) {
                    int resourceId2 = obtainStyledAttributes.getResourceId(index, 0);
                    try {
                        C0411c cVar = new C0411c();
                        this.f1768j = cVar;
                        cVar.mo2077s(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.f1768j = null;
                    }
                    this.f1770l = resourceId2;
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.f1761c.mo21660C0(this.f1767i);
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    /* access modifiers changed from: protected */
    public void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList<ConstraintHelper> arrayList = this.f1760b;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i = 0; i < size; i++) {
                this.f1760b.get(i).mo1816s(this);
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            int childCount = getChildCount();
            float width = (float) getWidth();
            float height = (float) getHeight();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = getChildAt(i2);
                if (!(childAt.getVisibility() == 8 || (tag = childAt.getTag()) == null || !(tag instanceof String))) {
                    String[] split = ((String) tag).split(",");
                    if (split.length == 4) {
                        int parseInt = Integer.parseInt(split[0]);
                        int parseInt2 = Integer.parseInt(split[1]);
                        int parseInt3 = Integer.parseInt(split[2]);
                        int i3 = (int) ((((float) parseInt) / 1080.0f) * width);
                        int i4 = (int) ((((float) parseInt2) / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f = (float) i3;
                        float f2 = (float) (i3 + ((int) ((((float) parseInt3) / 1080.0f) * width)));
                        Canvas canvas2 = canvas;
                        float f3 = (float) i4;
                        float f4 = f;
                        float f5 = f;
                        float f6 = f3;
                        Paint paint2 = paint;
                        float f7 = f2;
                        Paint paint3 = paint2;
                        canvas2.drawLine(f4, f6, f7, f3, paint3);
                        float parseInt4 = (float) (i4 + ((int) ((((float) Integer.parseInt(split[3])) / 1920.0f) * height)));
                        float f8 = f2;
                        float f9 = parseInt4;
                        canvas2.drawLine(f8, f6, f7, f9, paint3);
                        float f10 = parseInt4;
                        float f11 = f5;
                        canvas2.drawLine(f8, f10, f11, f9, paint3);
                        float f12 = f5;
                        canvas2.drawLine(f12, f10, f11, f3, paint3);
                        Paint paint4 = paint2;
                        paint4.setColor(-16711936);
                        Paint paint5 = paint4;
                        float f13 = f2;
                        Paint paint6 = paint5;
                        canvas2.drawLine(f12, f3, f13, parseInt4, paint6);
                        canvas2.drawLine(f12, parseInt4, f13, f3, paint6);
                    }
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x00cc  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00e3 A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00fd  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x0116  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0135  */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x014e  */
    /* JADX WARNING: Removed duplicated region for block: B:64:0x016d  */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x01bd  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x01c8  */
    /* renamed from: f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2015f(boolean r23, android.view.View r24, p098d.p113e.p116b.p117i.C4662e r25, androidx.constraintlayout.widget.ConstraintLayout.LayoutParams r26, android.util.SparseArray<p098d.p113e.p116b.p117i.C4662e> r27) {
        /*
            r22 = this;
            r0 = r22
            r1 = r24
            r2 = r25
            r3 = r26
            r4 = r27
            d.e.b.i.e$a r5 = p098d.p113e.p116b.p117i.C4662e.C4663a.MATCH_PARENT
            d.e.b.i.e$a r6 = p098d.p113e.p116b.p117i.C4662e.C4663a.WRAP_CONTENT
            d.e.b.i.e$a r7 = p098d.p113e.p116b.p117i.C4662e.C4663a.FIXED
            d.e.b.i.e$a r8 = p098d.p113e.p116b.p117i.C4662e.C4663a.MATCH_CONSTRAINT
            d.e.b.i.d$a r9 = p098d.p113e.p116b.p117i.C4660d.C4661a.RIGHT
            d.e.b.i.d$a r10 = p098d.p113e.p116b.p117i.C4660d.C4661a.LEFT
            d.e.b.i.d$a r11 = p098d.p113e.p116b.p117i.C4660d.C4661a.BOTTOM
            d.e.b.i.d$a r12 = p098d.p113e.p116b.p117i.C4660d.C4661a.TOP
            r26.mo2035b()
            int r13 = r24.getVisibility()
            r2.mo21639m0(r13)
            boolean r13 = r3.f1803a0
            r14 = 1
            if (r13 == 0) goto L_0x0031
            r2.mo21624d0(r14)
            r13 = 8
            r2.mo21639m0(r13)
        L_0x0031:
            r2.mo21615U(r1)
            boolean r13 = r1 instanceof androidx.constraintlayout.widget.ConstraintHelper
            if (r13 == 0) goto L_0x0043
            androidx.constraintlayout.widget.ConstraintHelper r1 = (androidx.constraintlayout.widget.ConstraintHelper) r1
            d.e.b.i.f r13 = r0.f1761c
            boolean r13 = r13.mo21669y0()
            r1.mo1811n(r2, r13)
        L_0x0043:
            boolean r1 = r3.f1800Y
            r13 = -1
            if (r1 == 0) goto L_0x006a
            r1 = r2
            d.e.b.i.h r1 = (p098d.p113e.p116b.p117i.C4667h) r1
            int r2 = r3.f1819i0
            int r4 = r3.f1821j0
            float r3 = r3.f1823k0
            r5 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r5 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r5 == 0) goto L_0x005c
            r1.mo21705y0(r3)
            goto L_0x02c5
        L_0x005c:
            if (r2 == r13) goto L_0x0063
            r1.mo21703w0(r2)
            goto L_0x02c5
        L_0x0063:
            if (r4 == r13) goto L_0x02c5
            r1.mo21704x0(r4)
            goto L_0x02c5
        L_0x006a:
            int r1 = r3.f1805b0
            int r15 = r3.f1807c0
            int r14 = r3.f1809d0
            int r13 = r3.f1811e0
            r16 = r6
            int r6 = r3.f1813f0
            r17 = r7
            int r7 = r3.f1815g0
            r18 = r5
            float r5 = r3.f1817h0
            r19 = r8
            int r8 = r3.f1826m
            r20 = 0
            r21 = r5
            r5 = -1
            if (r8 == r5) goto L_0x009a
            java.lang.Object r1 = r4.get(r8)
            d.e.b.i.e r1 = (p098d.p113e.p116b.p117i.C4662e) r1
            if (r1 == 0) goto L_0x01cb
            float r4 = r3.f1828o
            int r6 = r3.f1827n
            r2.mo21631i(r1, r4, r6)
            goto L_0x01cb
        L_0x009a:
            if (r1 == r5) goto L_0x00b3
            java.lang.Object r1 = r4.get(r1)
            d.e.b.i.e r1 = (p098d.p113e.p116b.p117i.C4662e) r1
            if (r1 == 0) goto L_0x00c9
            int r5 = r3.leftMargin
            d.e.b.i.d r8 = r2.mo21636l(r10)
            d.e.b.i.d r1 = r1.mo21636l(r10)
        L_0x00ae:
            r15 = 1
            r8.mo21585b(r1, r5, r6, r15)
            goto L_0x00c9
        L_0x00b3:
            r1 = -1
            if (r15 == r1) goto L_0x00ca
            java.lang.Object r1 = r4.get(r15)
            d.e.b.i.e r1 = (p098d.p113e.p116b.p117i.C4662e) r1
            if (r1 == 0) goto L_0x00c9
            int r5 = r3.leftMargin
            d.e.b.i.d r8 = r2.mo21636l(r10)
            d.e.b.i.d r1 = r1.mo21636l(r9)
            goto L_0x00ae
        L_0x00c9:
            r1 = -1
        L_0x00ca:
            if (r14 == r1) goto L_0x00e3
            java.lang.Object r1 = r4.get(r14)
            d.e.b.i.e r1 = (p098d.p113e.p116b.p117i.C4662e) r1
            if (r1 == 0) goto L_0x00f8
            int r5 = r3.rightMargin
            d.e.b.i.d r6 = r2.mo21636l(r9)
            d.e.b.i.d r1 = r1.mo21636l(r10)
        L_0x00de:
            r8 = 1
            r6.mo21585b(r1, r5, r7, r8)
            goto L_0x00f8
        L_0x00e3:
            if (r13 == r1) goto L_0x00f8
            java.lang.Object r1 = r4.get(r13)
            d.e.b.i.e r1 = (p098d.p113e.p116b.p117i.C4662e) r1
            if (r1 == 0) goto L_0x00f8
            int r5 = r3.rightMargin
            d.e.b.i.d r6 = r2.mo21636l(r9)
            d.e.b.i.d r1 = r1.mo21636l(r9)
            goto L_0x00de
        L_0x00f8:
            int r1 = r3.f1816h
            r5 = -1
            if (r1 == r5) goto L_0x0116
            java.lang.Object r1 = r4.get(r1)
            d.e.b.i.e r1 = (p098d.p113e.p116b.p117i.C4662e) r1
            if (r1 == 0) goto L_0x0130
            int r5 = r3.topMargin
            int r6 = r3.f1834u
            d.e.b.i.d r7 = r2.mo21636l(r12)
            d.e.b.i.d r1 = r1.mo21636l(r12)
        L_0x0111:
            r8 = 1
            r7.mo21585b(r1, r5, r6, r8)
            goto L_0x0130
        L_0x0116:
            int r1 = r3.f1818i
            r5 = -1
            if (r1 == r5) goto L_0x0130
            java.lang.Object r1 = r4.get(r1)
            d.e.b.i.e r1 = (p098d.p113e.p116b.p117i.C4662e) r1
            if (r1 == 0) goto L_0x0130
            int r5 = r3.topMargin
            int r6 = r3.f1834u
            d.e.b.i.d r7 = r2.mo21636l(r12)
            d.e.b.i.d r1 = r1.mo21636l(r11)
            goto L_0x0111
        L_0x0130:
            int r1 = r3.f1820j
            r5 = -1
            if (r1 == r5) goto L_0x014e
            java.lang.Object r1 = r4.get(r1)
            d.e.b.i.e r1 = (p098d.p113e.p116b.p117i.C4662e) r1
            if (r1 == 0) goto L_0x0168
            int r5 = r3.bottomMargin
            int r6 = r3.f1836w
            d.e.b.i.d r7 = r2.mo21636l(r11)
            d.e.b.i.d r1 = r1.mo21636l(r12)
        L_0x0149:
            r8 = 1
            r7.mo21585b(r1, r5, r6, r8)
            goto L_0x0168
        L_0x014e:
            int r1 = r3.f1822k
            r5 = -1
            if (r1 == r5) goto L_0x0168
            java.lang.Object r1 = r4.get(r1)
            d.e.b.i.e r1 = (p098d.p113e.p116b.p117i.C4662e) r1
            if (r1 == 0) goto L_0x0168
            int r5 = r3.bottomMargin
            int r6 = r3.f1836w
            d.e.b.i.d r7 = r2.mo21636l(r11)
            d.e.b.i.d r1 = r1.mo21636l(r11)
            goto L_0x0149
        L_0x0168:
            int r1 = r3.f1824l
            r5 = -1
            if (r1 == r5) goto L_0x01b9
            android.util.SparseArray<android.view.View> r5 = r0.f1759a
            java.lang.Object r1 = r5.get(r1)
            android.view.View r1 = (android.view.View) r1
            int r5 = r3.f1824l
            java.lang.Object r4 = r4.get(r5)
            d.e.b.i.e r4 = (p098d.p113e.p116b.p117i.C4662e) r4
            if (r4 == 0) goto L_0x01b9
            if (r1 == 0) goto L_0x01b9
            android.view.ViewGroup$LayoutParams r5 = r1.getLayoutParams()
            boolean r5 = r5 instanceof androidx.constraintlayout.widget.ConstraintLayout.LayoutParams
            if (r5 == 0) goto L_0x01b9
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.constraintlayout.widget.ConstraintLayout$LayoutParams r1 = (androidx.constraintlayout.widget.ConstraintLayout.LayoutParams) r1
            r5 = 1
            r3.f1799X = r5
            r1.f1799X = r5
            d.e.b.i.d$a r6 = p098d.p113e.p116b.p117i.C4660d.C4661a.BASELINE
            d.e.b.i.d r7 = r2.mo21636l(r6)
            d.e.b.i.d r4 = r4.mo21636l(r6)
            r6 = 0
            r8 = -1
            r7.mo21585b(r4, r6, r8, r5)
            r2.mo21618X(r5)
            d.e.b.i.e r1 = r1.f1825l0
            r1.mo21618X(r5)
            d.e.b.i.d r1 = r2.mo21636l(r12)
            r1.mo21592i()
            d.e.b.i.d r1 = r2.mo21636l(r11)
            r1.mo21592i()
        L_0x01b9:
            int r1 = (r21 > r20 ? 1 : (r21 == r20 ? 0 : -1))
            if (r1 < 0) goto L_0x01c2
            r1 = r21
            r2.mo21620Z(r1)
        L_0x01c2:
            float r1 = r3.f1776A
            int r4 = (r1 > r20 ? 1 : (r1 == r20 ? 0 : -1))
            if (r4 < 0) goto L_0x01cb
            r2.mo21633j0(r1)
        L_0x01cb:
            if (r23 == 0) goto L_0x01db
            int r1 = r3.f1791P
            r4 = -1
            if (r1 != r4) goto L_0x01d6
            int r5 = r3.f1792Q
            if (r5 == r4) goto L_0x01db
        L_0x01d6:
            int r4 = r3.f1792Q
            r2.mo21632i0(r1, r4)
        L_0x01db:
            boolean r1 = r3.f1797V
            r4 = -2
            if (r1 != 0) goto L_0x020e
            int r1 = r3.width
            r5 = -1
            if (r1 != r5) goto L_0x0205
            boolean r1 = r3.f1794S
            if (r1 == 0) goto L_0x01ef
            d.e.b.i.e$a[] r1 = r2.f16884L
            r5 = 0
            r1[r5] = r19
            goto L_0x01f4
        L_0x01ef:
            r5 = 0
            d.e.b.i.e$a[] r1 = r2.f16884L
            r1[r5] = r18
        L_0x01f4:
            d.e.b.i.d r1 = r2.mo21636l(r10)
            int r5 = r3.leftMargin
            r1.f16858e = r5
            d.e.b.i.d r1 = r2.mo21636l(r9)
            int r5 = r3.rightMargin
            r1.f16858e = r5
            goto L_0x0220
        L_0x0205:
            d.e.b.i.e$a[] r1 = r2.f16884L
            r5 = 0
            r1[r5] = r19
            r2.mo21641n0(r5)
            goto L_0x0220
        L_0x020e:
            r5 = 0
            d.e.b.i.e$a[] r1 = r2.f16884L
            r1[r5] = r17
            int r1 = r3.width
            r2.mo21641n0(r1)
            int r1 = r3.width
            if (r1 != r4) goto L_0x0220
            d.e.b.i.e$a[] r1 = r2.f16884L
            r1[r5] = r16
        L_0x0220:
            boolean r1 = r3.f1798W
            if (r1 != 0) goto L_0x0253
            int r1 = r3.height
            r4 = -1
            if (r1 != r4) goto L_0x0249
            boolean r1 = r3.f1795T
            if (r1 == 0) goto L_0x0233
            d.e.b.i.e$a[] r1 = r2.f16884L
            r4 = 1
            r1[r4] = r19
            goto L_0x0238
        L_0x0233:
            r4 = 1
            d.e.b.i.e$a[] r1 = r2.f16884L
            r1[r4] = r18
        L_0x0238:
            d.e.b.i.d r1 = r2.mo21636l(r12)
            int r4 = r3.topMargin
            r1.f16858e = r4
            d.e.b.i.d r1 = r2.mo21636l(r11)
            int r4 = r3.bottomMargin
            r1.f16858e = r4
            goto L_0x0265
        L_0x0249:
            d.e.b.i.e$a[] r1 = r2.f16884L
            r5 = 1
            r1[r5] = r19
            r1 = 0
            r2.mo21619Y(r1)
            goto L_0x0265
        L_0x0253:
            r5 = 1
            d.e.b.i.e$a[] r1 = r2.f16884L
            r1[r5] = r17
            int r1 = r3.height
            r2.mo21619Y(r1)
            int r1 = r3.height
            if (r1 != r4) goto L_0x0265
            d.e.b.i.e$a[] r1 = r2.f16884L
            r1[r5] = r16
        L_0x0265:
            java.lang.String r1 = r3.f1777B
            r2.mo21617W(r1)
            float r1 = r3.f1779D
            float[] r4 = r2.f16946x0
            r6 = 0
            r4[r6] = r1
            float r1 = r3.f1780E
            r5 = 1
            r4[r5] = r1
            int r1 = r3.f1781F
            r2.mo21621a0(r1)
            int r1 = r3.f1782G
            r2.mo21635k0(r1)
            int r1 = r3.f1783H
            int r4 = r3.f1785J
            int r5 = r3.f1787L
            float r7 = r3.f1789N
            r2.f16917j = r1
            r2.f16923m = r4
            r4 = 2147483647(0x7fffffff, float:NaN)
            if (r5 != r4) goto L_0x0292
            r5 = 0
        L_0x0292:
            r2.f16925n = r5
            r2.f16927o = r7
            r5 = 2
            r8 = 1065353216(0x3f800000, float:1.0)
            int r9 = (r7 > r20 ? 1 : (r7 == r20 ? 0 : -1))
            if (r9 <= 0) goto L_0x02a5
            int r7 = (r7 > r8 ? 1 : (r7 == r8 ? 0 : -1))
            if (r7 >= 0) goto L_0x02a5
            if (r1 != 0) goto L_0x02a5
            r2.f16917j = r5
        L_0x02a5:
            int r1 = r3.f1784I
            int r7 = r3.f1786K
            int r9 = r3.f1788M
            float r3 = r3.f1790O
            r2.f16919k = r1
            r2.f16929p = r7
            if (r9 != r4) goto L_0x02b4
            goto L_0x02b5
        L_0x02b4:
            r6 = r9
        L_0x02b5:
            r2.f16931q = r6
            r2.f16933r = r3
            int r4 = (r3 > r20 ? 1 : (r3 == r20 ? 0 : -1))
            if (r4 <= 0) goto L_0x02c5
            int r3 = (r3 > r8 ? 1 : (r3 == r8 ? 0 : -1))
            if (r3 >= 0) goto L_0x02c5
            if (r1 != 0) goto L_0x02c5
            r2.f16919k = r5
        L_0x02c5:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.mo2015f(boolean, android.view.View, d.e.b.i.e, androidx.constraintlayout.widget.ConstraintLayout$LayoutParams, android.util.SparseArray):void");
    }

    public void forceLayout() {
        this.f1766h = true;
        this.f1772n = -1;
        this.f1773o = -1;
        super.forceLayout();
    }

    /* access modifiers changed from: protected */
    /* renamed from: g */
    public LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-2, -2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    /* renamed from: h */
    public Object mo2021h(int i, Object obj) {
        if (i != 0 || !(obj instanceof String)) {
            return null;
        }
        String str = (String) obj;
        HashMap<String, Integer> hashMap = this.f1771m;
        if (hashMap == null || !hashMap.containsKey(str)) {
            return null;
        }
        return this.f1771m.get(str);
    }

    /* renamed from: i */
    public int mo2022i() {
        return this.f1761c.mo21667w0();
    }

    /* renamed from: j */
    public View mo2023j(int i) {
        return this.f1759a.get(i);
    }

    /* renamed from: k */
    public final C4662e mo2024k(View view) {
        if (view == this) {
            return this.f1761c;
        }
        if (view == null) {
            return null;
        }
        return ((LayoutParams) view.getLayoutParams()).f1825l0;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        View a;
        int childCount = getChildCount();
        boolean isInEditMode = isInEditMode();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            C4662e eVar = layoutParams.f1825l0;
            if ((childAt.getVisibility() != 8 || layoutParams.f1800Y || layoutParams.f1801Z || isInEditMode) && !layoutParams.f1803a0) {
                int J = eVar.mo21605J();
                int K = eVar.mo21606K();
                int I = eVar.mo21604I() + J;
                int t = eVar.mo21651t() + K;
                childAt.layout(J, K, I, t);
                if ((childAt instanceof Placeholder) && (a = ((Placeholder) childAt).mo2048a()) != null) {
                    a.setVisibility(0);
                    a.layout(J, K, I, t);
                }
            }
        }
        int size = this.f1760b.size();
        if (size > 0) {
            for (int i6 = 0; i6 < size; i6++) {
                this.f1760b.get(i6).mo1815q(this);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        boolean z;
        C4662e eVar;
        this.f1761c.mo21661D0(mo2026s());
        if (this.f1766h) {
            this.f1766h = false;
            int childCount = getChildCount();
            int i3 = 0;
            while (true) {
                if (i3 >= childCount) {
                    z = false;
                    break;
                } else if (getChildAt(i3).isLayoutRequested()) {
                    z = true;
                    break;
                } else {
                    i3++;
                }
            }
            if (z) {
                boolean isInEditMode = isInEditMode();
                int childCount2 = getChildCount();
                for (int i4 = 0; i4 < childCount2; i4++) {
                    C4662e k = mo2024k(getChildAt(i4));
                    if (k != null) {
                        k.mo21611Q();
                    }
                }
                if (isInEditMode) {
                    for (int i5 = 0; i5 < childCount2; i5++) {
                        View childAt = getChildAt(i5);
                        try {
                            String resourceName = getResources().getResourceName(childAt.getId());
                            mo2032x(0, resourceName, Integer.valueOf(childAt.getId()));
                            int indexOf = resourceName.indexOf(47);
                            if (indexOf != -1) {
                                resourceName = resourceName.substring(indexOf + 1);
                            }
                            int id = childAt.getId();
                            if (id != 0) {
                                View view = this.f1759a.get(id);
                                if (view == null && (view = findViewById(id)) != null && view != this && view.getParent() == this) {
                                    onViewAdded(view);
                                }
                                if (view != this) {
                                    eVar = view == null ? null : ((LayoutParams) view.getLayoutParams()).f1825l0;
                                    eVar.mo21616V(resourceName);
                                }
                            }
                            eVar = this.f1761c;
                            eVar.mo21616V(resourceName);
                        } catch (Resources.NotFoundException unused) {
                        }
                    }
                }
                if (this.f1770l != -1) {
                    for (int i6 = 0; i6 < childCount2; i6++) {
                        View childAt2 = getChildAt(i6);
                        if (childAt2.getId() == this.f1770l && (childAt2 instanceof Constraints)) {
                            Constraints constraints = (Constraints) childAt2;
                            if (constraints.f1848a == null) {
                                constraints.f1848a = new C0411c();
                            }
                            constraints.f1848a.mo2069h(constraints);
                            this.f1768j = constraints.f1848a;
                        }
                    }
                }
                C0411c cVar = this.f1768j;
                if (cVar != null) {
                    cVar.mo2066e(this, true);
                }
                this.f1761c.f17032C0.clear();
                int size = this.f1760b.size();
                if (size > 0) {
                    for (int i7 = 0; i7 < size; i7++) {
                        this.f1760b.get(i7).mo2011u(this);
                    }
                }
                for (int i8 = 0; i8 < childCount2; i8++) {
                    View childAt3 = getChildAt(i8);
                    if (childAt3 instanceof Placeholder) {
                        ((Placeholder) childAt3).mo2050d(this);
                    }
                }
                this.f1774p.clear();
                this.f1774p.put(0, this.f1761c);
                this.f1774p.put(getId(), this.f1761c);
                for (int i9 = 0; i9 < childCount2; i9++) {
                    View childAt4 = getChildAt(i9);
                    this.f1774p.put(childAt4.getId(), mo2024k(childAt4));
                }
                for (int i10 = 0; i10 < childCount2; i10++) {
                    View childAt5 = getChildAt(i10);
                    C4662e k2 = mo2024k(childAt5);
                    if (k2 != null) {
                        this.f1761c.mo21728a(k2);
                        mo2015f(isInEditMode, childAt5, k2, (LayoutParams) childAt5.getLayoutParams(), this.f1774p);
                    }
                }
            }
            if (z) {
                this.f1761c.mo21662E0();
            }
        }
        mo2030v(this.f1761c, this.f1767i, i, i2);
        mo2029u(i, i2, this.f1761c.mo21604I(), this.f1761c.mo21651t(), this.f1761c.mo21670z0(), this.f1761c.mo21668x0());
    }

    public void onViewAdded(View view) {
        super.onViewAdded(view);
        C4662e k = mo2024k(view);
        if ((view instanceof Guideline) && !(k instanceof C4667h)) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            C4667h hVar = new C4667h();
            layoutParams.f1825l0 = hVar;
            layoutParams.f1800Y = true;
            hVar.mo21706z0(layoutParams.f1793R);
        }
        if (view instanceof ConstraintHelper) {
            ConstraintHelper constraintHelper = (ConstraintHelper) view;
            constraintHelper.mo2012v();
            ((LayoutParams) view.getLayoutParams()).f1801Z = true;
            if (!this.f1760b.contains(constraintHelper)) {
                this.f1760b.add(constraintHelper);
            }
        }
        this.f1759a.put(view.getId(), view);
        this.f1766h = true;
    }

    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.f1759a.remove(view.getId());
        C4662e k = mo2024k(view);
        this.f1761c.f17032C0.remove(k);
        k.f16885M = null;
        this.f1760b.remove(view);
        this.f1766h = true;
    }

    public void removeView(View view) {
        super.removeView(view);
    }

    public void requestLayout() {
        this.f1766h = true;
        this.f1772n = -1;
        this.f1773o = -1;
        super.requestLayout();
    }

    /* access modifiers changed from: protected */
    /* renamed from: s */
    public boolean mo2026s() {
        return ((getContext().getApplicationInfo().flags & 4194304) != 0) && 1 == getLayoutDirection();
    }

    public void setId(int i) {
        this.f1759a.remove(getId());
        super.setId(i);
        this.f1759a.put(getId(), this);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    /* access modifiers changed from: protected */
    /* renamed from: t */
    public void mo1864t(int i) {
        this.f1769k = new C0408b(getContext(), this, i);
    }

    /* access modifiers changed from: protected */
    /* renamed from: u */
    public void mo2029u(int i, int i2, int i3, int i4, boolean z, boolean z2) {
        C0406a aVar = this.f1775q;
        int i5 = aVar.f1845e;
        int resolveSizeAndState = ViewGroup.resolveSizeAndState(i3 + aVar.f1844d, i, 0);
        int min = Math.min(this.f1764f, resolveSizeAndState & 16777215);
        int min2 = Math.min(this.f1765g, ViewGroup.resolveSizeAndState(i4 + i5, i2, 0) & 16777215);
        if (z) {
            min |= 16777216;
        }
        if (z2) {
            min2 |= 16777216;
        }
        setMeasuredDimension(min, min2);
        this.f1772n = min;
        this.f1773o = min2;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x00d2, code lost:
        if (r13 == 0) goto L_0x00da;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0080, code lost:
        if (mo2026s() != false) goto L_0x0084;
     */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x00c2  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00d8  */
    /* renamed from: v */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2030v(p098d.p113e.p116b.p117i.C4664f r19, int r20, int r21, int r22) {
        /*
            r18 = this;
            r0 = r18
            r1 = r19
            int r3 = android.view.View.MeasureSpec.getMode(r21)
            int r2 = android.view.View.MeasureSpec.getSize(r21)
            int r5 = android.view.View.MeasureSpec.getMode(r22)
            int r4 = android.view.View.MeasureSpec.getSize(r22)
            int r6 = r18.getPaddingTop()
            r7 = 0
            int r10 = java.lang.Math.max(r7, r6)
            int r6 = r18.getPaddingBottom()
            int r6 = java.lang.Math.max(r7, r6)
            int r8 = r10 + r6
            int r9 = r18.getPaddingLeft()
            int r9 = java.lang.Math.max(r7, r9)
            int r11 = r18.getPaddingRight()
            int r11 = java.lang.Math.max(r7, r11)
            int r11 = r11 + r9
            int r9 = r18.getPaddingStart()
            int r9 = java.lang.Math.max(r7, r9)
            int r12 = r18.getPaddingEnd()
            int r12 = java.lang.Math.max(r7, r12)
            int r12 = r12 + r9
            if (r12 <= 0) goto L_0x004c
            r11 = r12
        L_0x004c:
            androidx.constraintlayout.widget.ConstraintLayout$a r9 = r0.f1775q
            r9.f1842b = r10
            r9.f1843c = r6
            r9.f1844d = r11
            r9.f1845e = r8
            r6 = r21
            r9.f1846f = r6
            r6 = r22
            r9.f1847g = r6
            int r6 = r18.getPaddingStart()
            int r6 = java.lang.Math.max(r7, r6)
            int r9 = r18.getPaddingEnd()
            int r9 = java.lang.Math.max(r7, r9)
            if (r6 > 0) goto L_0x007c
            if (r9 <= 0) goto L_0x0073
            goto L_0x007c
        L_0x0073:
            int r6 = r18.getPaddingLeft()
            int r6 = java.lang.Math.max(r7, r6)
            goto L_0x0083
        L_0x007c:
            boolean r12 = r18.mo2026s()
            if (r12 == 0) goto L_0x0083
            goto L_0x0084
        L_0x0083:
            r9 = r6
        L_0x0084:
            int r6 = r2 - r11
            int r8 = r4 - r8
            d.e.b.i.e$a r2 = p098d.p113e.p116b.p117i.C4662e.C4663a.WRAP_CONTENT
            androidx.constraintlayout.widget.ConstraintLayout$a r4 = r0.f1775q
            int r11 = r4.f1845e
            int r4 = r4.f1844d
            d.e.b.i.e$a r12 = p098d.p113e.p116b.p117i.C4662e.C4663a.FIXED
            int r13 = r18.getChildCount()
            r14 = 1073741824(0x40000000, float:2.0)
            r15 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r3 == r15) goto L_0x00b4
            if (r3 == 0) goto L_0x00ac
            if (r3 == r14) goto L_0x00a2
            r14 = r12
            goto L_0x00b0
        L_0x00a2:
            int r14 = r0.f1764f
            int r14 = r14 - r4
            int r14 = java.lang.Math.min(r14, r6)
            r16 = r12
            goto L_0x00c0
        L_0x00ac:
            if (r13 != 0) goto L_0x00af
            goto L_0x00b6
        L_0x00af:
            r14 = r2
        L_0x00b0:
            r16 = r14
            r14 = 0
            goto L_0x00c0
        L_0x00b4:
            if (r13 != 0) goto L_0x00bd
        L_0x00b6:
            int r14 = r0.f1762d
            int r14 = java.lang.Math.max(r7, r14)
            goto L_0x00be
        L_0x00bd:
            r14 = r6
        L_0x00be:
            r16 = r2
        L_0x00c0:
            if (r5 == r15) goto L_0x00d8
            if (r5 == 0) goto L_0x00d2
            r15 = 1073741824(0x40000000, float:2.0)
            if (r5 == r15) goto L_0x00ca
            r2 = r12
            goto L_0x00d5
        L_0x00ca:
            int r2 = r0.f1765g
            int r2 = r2 - r11
            int r2 = java.lang.Math.min(r2, r8)
            goto L_0x00e8
        L_0x00d2:
            if (r13 != 0) goto L_0x00d5
            goto L_0x00da
        L_0x00d5:
            r12 = r2
            r2 = 0
            goto L_0x00e8
        L_0x00d8:
            if (r13 != 0) goto L_0x00e6
        L_0x00da:
            int r12 = r0.f1763e
            int r12 = java.lang.Math.max(r7, r12)
            r17 = r12
            r12 = r2
            r2 = r17
            goto L_0x00e8
        L_0x00e6:
            r12 = r2
            r2 = r8
        L_0x00e8:
            int r13 = r19.mo21604I()
            if (r14 != r13) goto L_0x00f4
            int r13 = r19.mo21651t()
            if (r2 == r13) goto L_0x00f9
        L_0x00f4:
            d.e.b.i.n.e r13 = r1.f16957E0
            r13.mo21743j()
        L_0x00f9:
            r1.mo21643o0(r7)
            r1.mo21645p0(r7)
            int r13 = r0.f1764f
            int r13 = r13 - r4
            r1.mo21626f0(r13)
            int r13 = r0.f1765g
            int r13 = r13 - r11
            r1.mo21625e0(r13)
            r1.mo21630h0(r7)
            r1.mo21628g0(r7)
            d.e.b.i.e$a[] r13 = r1.f16884L
            r13[r7] = r16
            r1.mo21641n0(r14)
            d.e.b.i.e$a[] r7 = r1.f16884L
            r13 = 1
            r7[r13] = r12
            r1.mo21619Y(r2)
            int r2 = r0.f1762d
            int r2 = r2 - r4
            r1.mo21630h0(r2)
            int r2 = r0.f1763e
            int r2 = r2 - r11
            r1.mo21628g0(r2)
            int r7 = r0.f1772n
            int r11 = r0.f1773o
            r1 = r19
            r2 = r20
            r4 = r6
            r6 = r8
            r8 = r11
            r1.mo21658A0(r2, r3, r4, r5, r6, r7, r8, r9, r10)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.mo2030v(d.e.b.i.f, int, int, int):void");
    }

    /* renamed from: w */
    public void mo2031w(C0411c cVar) {
        this.f1768j = null;
    }

    /* renamed from: x */
    public void mo2032x(int i, Object obj, Object obj2) {
        if (i == 0 && (obj instanceof String) && (obj2 instanceof Integer)) {
            if (this.f1771m == null) {
                this.f1771m = new HashMap<>();
            }
            String str = (String) obj;
            int indexOf = str.indexOf("/");
            if (indexOf != -1) {
                str = str.substring(indexOf + 1);
            }
            this.f1771m.put(str, Integer.valueOf(((Integer) obj2).intValue()));
        }
    }

    /* renamed from: y */
    public void mo2033y(int i) {
        if (i != this.f1762d) {
            this.f1762d = i;
            requestLayout();
        }
    }
}
