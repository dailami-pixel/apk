package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;

public class Constraints extends ViewGroup {

    /* renamed from: a */
    C0411c f1848a;

    public static class LayoutParams extends ConstraintLayout.LayoutParams {

        /* renamed from: m0 */
        public float f1849m0;

        /* renamed from: n0 */
        public boolean f1850n0;

        /* renamed from: o0 */
        public float f1851o0;

        /* renamed from: p0 */
        public float f1852p0;

        /* renamed from: q0 */
        public float f1853q0;

        /* renamed from: r0 */
        public float f1854r0;

        /* renamed from: s0 */
        public float f1855s0;

        /* renamed from: t0 */
        public float f1856t0;

        /* renamed from: u0 */
        public float f1857u0;

        /* renamed from: v0 */
        public float f1858v0;

        /* renamed from: w0 */
        public float f1859w0;

        /* renamed from: x0 */
        public float f1860x0;

        /* renamed from: y0 */
        public float f1861y0;

        public LayoutParams(int i, int i2) {
            super(i, i2);
            this.f1849m0 = 1.0f;
            this.f1850n0 = false;
            this.f1851o0 = 0.0f;
            this.f1852p0 = 0.0f;
            this.f1853q0 = 0.0f;
            this.f1854r0 = 0.0f;
            this.f1855s0 = 1.0f;
            this.f1856t0 = 1.0f;
            this.f1857u0 = 0.0f;
            this.f1858v0 = 0.0f;
            this.f1859w0 = 0.0f;
            this.f1860x0 = 0.0f;
            this.f1861y0 = 0.0f;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f1849m0 = 1.0f;
            this.f1850n0 = false;
            this.f1851o0 = 0.0f;
            this.f1852p0 = 0.0f;
            this.f1853q0 = 0.0f;
            this.f1854r0 = 0.0f;
            this.f1855s0 = 1.0f;
            this.f1856t0 = 1.0f;
            this.f1857u0 = 0.0f;
            this.f1858v0 = 0.0f;
            this.f1859w0 = 0.0f;
            this.f1860x0 = 0.0f;
            this.f1861y0 = 0.0f;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0418e.f1994d);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 15) {
                    this.f1849m0 = obtainStyledAttributes.getFloat(index, this.f1849m0);
                } else if (index == 28) {
                    this.f1851o0 = obtainStyledAttributes.getFloat(index, this.f1851o0);
                    this.f1850n0 = true;
                } else if (index == 23) {
                    this.f1853q0 = obtainStyledAttributes.getFloat(index, this.f1853q0);
                } else if (index == 24) {
                    this.f1854r0 = obtainStyledAttributes.getFloat(index, this.f1854r0);
                } else if (index == 22) {
                    this.f1852p0 = obtainStyledAttributes.getFloat(index, this.f1852p0);
                } else if (index == 20) {
                    this.f1855s0 = obtainStyledAttributes.getFloat(index, this.f1855s0);
                } else if (index == 21) {
                    this.f1856t0 = obtainStyledAttributes.getFloat(index, this.f1856t0);
                } else if (index == 16) {
                    this.f1857u0 = obtainStyledAttributes.getFloat(index, this.f1857u0);
                } else if (index == 17) {
                    this.f1858v0 = obtainStyledAttributes.getFloat(index, this.f1858v0);
                } else if (index == 18) {
                    this.f1859w0 = obtainStyledAttributes.getFloat(index, this.f1859w0);
                } else if (index == 19) {
                    this.f1860x0 = obtainStyledAttributes.getFloat(index, this.f1860x0);
                } else if (index == 27) {
                    this.f1861y0 = obtainStyledAttributes.getFloat(index, this.f1861y0);
                }
            }
        }
    }

    public Constraints(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        Log.v("Constraints", " ################# init");
        super.setVisibility(8);
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-2, -2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new ConstraintLayout.LayoutParams(layoutParams);
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
    }

    public Constraints(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Log.v("Constraints", " ################# init");
        super.setVisibility(8);
    }
}
