package androidx.constraintlayout.widget;

import android.content.Context;
import android.util.AttributeSet;
import androidx.constraintlayout.widget.ConstraintLayout;

public class Group extends ConstraintHelper {
    public Group(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public Group(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* access modifiers changed from: protected */
    /* renamed from: l */
    public void mo1809l(AttributeSet attributeSet) {
        super.mo1809l(attributeSet);
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        mo2003g();
    }

    /* renamed from: q */
    public void mo1815q(ConstraintLayout constraintLayout) {
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) getLayoutParams();
        layoutParams.f1825l0.mo21641n0(0);
        layoutParams.f1825l0.mo21619Y(0);
    }

    public void setElevation(float f) {
        super.setElevation(f);
        mo2003g();
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        mo2003g();
    }
}
