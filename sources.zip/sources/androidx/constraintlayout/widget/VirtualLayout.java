package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import p098d.p113e.p116b.p117i.C4671l;

public abstract class VirtualLayout extends ConstraintHelper {

    /* renamed from: h */
    private boolean f1865h;

    /* renamed from: i */
    private boolean f1866i;

    public VirtualLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public VirtualLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* access modifiers changed from: protected */
    /* renamed from: l */
    public void mo1809l(AttributeSet attributeSet) {
        super.mo1809l(attributeSet);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C0418e.f1992b);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 6) {
                    this.f1865h = true;
                } else if (index == 13) {
                    this.f1866i = true;
                }
            }
        }
    }

    public void onAttachedToWindow() {
        ViewParent parent;
        super.onAttachedToWindow();
        if ((this.f1865h || this.f1866i) && (parent = getParent()) != null && (parent instanceof ConstraintLayout)) {
            ConstraintLayout constraintLayout = (ConstraintLayout) parent;
            int visibility = getVisibility();
            float elevation = getElevation();
            for (int i = 0; i < this.f1753b; i++) {
                View j = constraintLayout.mo2023j(this.f1752a[i]);
                if (j != null) {
                    if (this.f1865h) {
                        j.setVisibility(visibility);
                    }
                    if (this.f1866i && elevation > 0.0f) {
                        j.setTranslationZ(j.getTranslationZ() + elevation);
                    }
                }
            }
        }
    }

    public void setElevation(float f) {
        super.setElevation(f);
        mo2003g();
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        mo2003g();
    }

    /* renamed from: w */
    public void mo1813w(C4671l lVar, int i, int i2) {
    }
}
