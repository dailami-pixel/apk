package androidx.coordinatorlayout.widget;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import p098d.p112d.C4631j;
import p098d.p120g.p129i.C4742b;
import p098d.p120g.p129i.C4743c;

/* renamed from: androidx.coordinatorlayout.widget.a */
public final class C0430a<T> {

    /* renamed from: a */
    private final C4742b<ArrayList<T>> f2073a = new C4743c(10);

    /* renamed from: b */
    private final C4631j<T, ArrayList<T>> f2074b = new C4631j<>();

    /* renamed from: c */
    private final ArrayList<T> f2075c = new ArrayList<>();

    /* renamed from: d */
    private final HashSet<T> f2076d = new HashSet<>();

    /* renamed from: e */
    private void m2052e(T t, ArrayList<T> arrayList, HashSet<T> hashSet) {
        if (!arrayList.contains(t)) {
            if (!hashSet.contains(t)) {
                hashSet.add(t);
                ArrayList orDefault = this.f2074b.getOrDefault(t, null);
                if (orDefault != null) {
                    int size = orDefault.size();
                    for (int i = 0; i < size; i++) {
                        m2052e(orDefault.get(i), arrayList, hashSet);
                    }
                }
                hashSet.remove(t);
                arrayList.add(t);
                return;
            }
            throw new RuntimeException("This graph contains cyclic dependencies");
        }
    }

    /* renamed from: a */
    public void mo2184a(T t, T t2) {
        boolean z = false;
        if (this.f2074b.mo21452f(t) >= 0) {
            if (this.f2074b.mo21452f(t2) >= 0) {
                z = true;
            }
            if (z) {
                ArrayList orDefault = this.f2074b.getOrDefault(t, null);
                if (orDefault == null) {
                    orDefault = this.f2073a.mo7332a();
                    if (orDefault == null) {
                        orDefault = new ArrayList();
                    }
                    this.f2074b.put(t, orDefault);
                }
                orDefault.add(t2);
                return;
            }
        }
        throw new IllegalArgumentException("All nodes must be present in the graph before being added as an edge");
    }

    /* renamed from: b */
    public void mo2185b(T t) {
        if (!(this.f2074b.mo21452f(t) >= 0)) {
            this.f2074b.put(t, null);
        }
    }

    /* renamed from: c */
    public void mo2186c() {
        int size = this.f2074b.size();
        for (int i = 0; i < size; i++) {
            ArrayList m = this.f2074b.mo21459m(i);
            if (m != null) {
                m.clear();
                this.f2073a.mo7333b(m);
            }
        }
        this.f2074b.clear();
    }

    /* renamed from: d */
    public boolean mo2187d(T t) {
        return this.f2074b.mo21452f(t) >= 0;
    }

    /* renamed from: f */
    public List mo2188f(T t) {
        return this.f2074b.getOrDefault(t, null);
    }

    /* renamed from: g */
    public List<T> mo2189g(T t) {
        int size = this.f2074b.size();
        ArrayList arrayList = null;
        for (int i = 0; i < size; i++) {
            ArrayList m = this.f2074b.mo21459m(i);
            if (m != null && m.contains(t)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(this.f2074b.mo21457i(i));
            }
        }
        return arrayList;
    }

    /* renamed from: h */
    public ArrayList<T> mo2190h() {
        this.f2075c.clear();
        this.f2076d.clear();
        int size = this.f2074b.size();
        for (int i = 0; i < size; i++) {
            m2052e(this.f2074b.mo21457i(i), this.f2075c, this.f2076d);
        }
        return this.f2075c;
    }

    /* renamed from: i */
    public boolean mo2191i(T t) {
        int size = this.f2074b.size();
        for (int i = 0; i < size; i++) {
            ArrayList m = this.f2074b.mo21459m(i);
            if (m != null && m.contains(t)) {
                return true;
            }
        }
        return false;
    }
}
