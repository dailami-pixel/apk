package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import androidx.customview.view.AbsSavedState;
import com.vidio.android.p195tv.R;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import p098d.p119f.C4689a;
import p098d.p120g.p129i.C4742b;
import p098d.p120g.p129i.C4744d;
import p098d.p120g.p130j.C4755g;
import p098d.p120g.p130j.C4756h;
import p098d.p120g.p130j.C4757i;
import p098d.p120g.p130j.C4758j;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.C4780v;
import p165e.p166a.p167a.p168a.C4924a;

public class CoordinatorLayout extends ViewGroup implements C4755g, C4756h {

    /* renamed from: a */
    static final String f2027a;

    /* renamed from: b */
    static final Class<?>[] f2028b = {Context.class, AttributeSet.class};

    /* renamed from: c */
    static final ThreadLocal<Map<String, Constructor<Behavior>>> f2029c = new ThreadLocal<>();

    /* renamed from: d */
    static final Comparator<View> f2030d = new C0429g();

    /* renamed from: e */
    private static final C4742b<Rect> f2031e = new C4744d(12);

    /* renamed from: f */
    private final List<View> f2032f;

    /* renamed from: g */
    private final C0430a<View> f2033g;

    /* renamed from: h */
    private final List<View> f2034h;

    /* renamed from: i */
    private final List<View> f2035i;

    /* renamed from: j */
    private Paint f2036j;

    /* renamed from: k */
    private final int[] f2037k;

    /* renamed from: l */
    private final int[] f2038l;

    /* renamed from: m */
    private boolean f2039m;

    /* renamed from: n */
    private boolean f2040n;

    /* renamed from: o */
    private int[] f2041o;

    /* renamed from: p */
    private View f2042p;

    /* renamed from: q */
    private View f2043q;

    /* renamed from: r */
    private C0428f f2044r;

    /* renamed from: s */
    private boolean f2045s;

    /* renamed from: t */
    private C4780v f2046t;

    /* renamed from: u */
    private boolean f2047u;

    /* renamed from: v */
    private Drawable f2048v;

    /* renamed from: w */
    ViewGroup.OnHierarchyChangeListener f2049w;

    /* renamed from: x */
    private C4758j f2050x;

    /* renamed from: y */
    private final C4757i f2051y;

    public static abstract class Behavior<V extends View> {
        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
        }

        /* renamed from: A */
        public boolean mo2138A(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
            return false;
        }

        /* renamed from: a */
        public boolean mo2139a(CoordinatorLayout coordinatorLayout, V v, Rect rect) {
            return false;
        }

        /* renamed from: b */
        public int mo2140b() {
            return -16777216;
        }

        /* renamed from: c */
        public float mo2141c() {
            return 0.0f;
        }

        /* renamed from: d */
        public boolean mo2142d(CoordinatorLayout coordinatorLayout, V v, View view) {
            return false;
        }

        /* renamed from: e */
        public C4780v mo2143e(C4780v vVar) {
            return vVar;
        }

        /* renamed from: f */
        public void mo2144f(C0427e eVar) {
        }

        /* renamed from: g */
        public boolean mo2145g(CoordinatorLayout coordinatorLayout, V v, View view) {
            return false;
        }

        /* renamed from: h */
        public void mo2146h(CoordinatorLayout coordinatorLayout, V v, View view) {
        }

        /* renamed from: i */
        public void mo2147i() {
        }

        /* renamed from: j */
        public boolean mo2148j(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
            return false;
        }

        /* renamed from: k */
        public boolean mo2149k(CoordinatorLayout coordinatorLayout, V v, int i) {
            return false;
        }

        /* renamed from: l */
        public boolean mo2150l(CoordinatorLayout coordinatorLayout, V v, int i, int i2, int i3, int i4) {
            return false;
        }

        /* renamed from: m */
        public boolean mo2151m() {
            return false;
        }

        /* renamed from: n */
        public boolean mo2152n(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2) {
            return false;
        }

        @Deprecated
        /* renamed from: o */
        public void mo2153o() {
        }

        /* renamed from: p */
        public void mo2154p(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int[] iArr, int i3) {
            if (i3 == 0) {
                mo2153o();
            }
        }

        @Deprecated
        /* renamed from: q */
        public void mo2155q() {
        }

        /* renamed from: r */
        public void mo2156r(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
            iArr[0] = iArr[0] + i3;
            iArr[1] = iArr[1] + i4;
            if (i5 == 0) {
                mo2155q();
            }
        }

        @Deprecated
        /* renamed from: s */
        public void mo2157s() {
        }

        /* renamed from: t */
        public boolean mo2158t(CoordinatorLayout coordinatorLayout, V v, Rect rect, boolean z) {
            return false;
        }

        /* renamed from: u */
        public void mo2159u(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
        }

        /* renamed from: v */
        public Parcelable mo2160v(CoordinatorLayout coordinatorLayout, V v) {
            return View.BaseSavedState.EMPTY_STATE;
        }

        @Deprecated
        /* renamed from: w */
        public boolean mo2161w() {
            return false;
        }

        /* renamed from: x */
        public boolean mo2162x(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i, int i2) {
            if (i2 == 0) {
                return mo2161w();
            }
            return false;
        }

        @Deprecated
        /* renamed from: y */
        public void mo2163y() {
        }

        /* renamed from: z */
        public void mo2164z(CoordinatorLayout coordinatorLayout, V v, View view, int i) {
            if (i == 0) {
                mo2163y();
            }
        }
    }

    protected static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0422a();

        /* renamed from: c */
        SparseArray<Parcelable> f2052c;

        /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$SavedState$a */
        static class C0422a implements Parcelable.ClassLoaderCreator<SavedState> {
            C0422a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new SavedState[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            int readInt = parcel.readInt();
            int[] iArr = new int[readInt];
            parcel.readIntArray(iArr);
            Parcelable[] readParcelableArray = parcel.readParcelableArray(classLoader);
            this.f2052c = new SparseArray<>(readInt);
            for (int i = 0; i < readInt; i++) {
                this.f2052c.append(iArr[i], readParcelableArray[i]);
            }
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            SparseArray<Parcelable> sparseArray = this.f2052c;
            int size = sparseArray != null ? sparseArray.size() : 0;
            parcel.writeInt(size);
            int[] iArr = new int[size];
            Parcelable[] parcelableArr = new Parcelable[size];
            for (int i2 = 0; i2 < size; i2++) {
                iArr[i2] = this.f2052c.keyAt(i2);
                parcelableArr[i2] = this.f2052c.valueAt(i2);
            }
            parcel.writeIntArray(iArr);
            parcel.writeParcelableArray(parcelableArr, i);
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$a */
    class C0423a implements C4758j {
        C0423a() {
        }

        /* renamed from: a */
        public C4780v mo555a(View view, C4780v vVar) {
            return CoordinatorLayout.this.mo2099H(vVar);
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$b */
    public interface C0424b {
        /* renamed from: a */
        Behavior mo2168a();
    }

    @Deprecated
    @Retention(RetentionPolicy.RUNTIME)
    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$c */
    public @interface C0425c {
        Class<? extends Behavior> value();
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$d */
    private class C0426d implements ViewGroup.OnHierarchyChangeListener {
        C0426d() {
        }

        public void onChildViewAdded(View view, View view2) {
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f2049w;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewAdded(view, view2);
            }
        }

        public void onChildViewRemoved(View view, View view2) {
            CoordinatorLayout.this.mo2096A(2);
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f2049w;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewRemoved(view, view2);
            }
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$e */
    public static class C0427e extends ViewGroup.MarginLayoutParams {

        /* renamed from: a */
        Behavior f2055a;

        /* renamed from: b */
        boolean f2056b = false;

        /* renamed from: c */
        public int f2057c = 0;

        /* renamed from: d */
        public int f2058d = 0;

        /* renamed from: e */
        public int f2059e = -1;

        /* renamed from: f */
        int f2060f = -1;

        /* renamed from: g */
        public int f2061g = 0;

        /* renamed from: h */
        public int f2062h = 0;

        /* renamed from: i */
        int f2063i;

        /* renamed from: j */
        int f2064j;

        /* renamed from: k */
        View f2065k;

        /* renamed from: l */
        View f2066l;

        /* renamed from: m */
        private boolean f2067m;

        /* renamed from: n */
        private boolean f2068n;

        /* renamed from: o */
        private boolean f2069o;

        /* renamed from: p */
        private boolean f2070p;

        /* renamed from: q */
        final Rect f2071q = new Rect();

        public C0427e(int i, int i2) {
            super(i, i2);
        }

        C0427e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            Behavior behavior;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4689a.f17095b);
            this.f2057c = obtainStyledAttributes.getInteger(0, 0);
            this.f2060f = obtainStyledAttributes.getResourceId(1, -1);
            this.f2058d = obtainStyledAttributes.getInteger(2, 0);
            this.f2059e = obtainStyledAttributes.getInteger(6, -1);
            this.f2061g = obtainStyledAttributes.getInt(5, 0);
            this.f2062h = obtainStyledAttributes.getInt(4, 0);
            boolean hasValue = obtainStyledAttributes.hasValue(3);
            this.f2056b = hasValue;
            if (hasValue) {
                String string = obtainStyledAttributes.getString(3);
                String str = CoordinatorLayout.f2027a;
                if (TextUtils.isEmpty(string)) {
                    behavior = null;
                } else {
                    if (string.startsWith(".")) {
                        string = context.getPackageName() + string;
                    } else if (string.indexOf(46) < 0) {
                        String str2 = CoordinatorLayout.f2027a;
                        if (!TextUtils.isEmpty(str2)) {
                            string = str2 + '.' + string;
                        }
                    }
                    try {
                        ThreadLocal<Map<String, Constructor<Behavior>>> threadLocal = CoordinatorLayout.f2029c;
                        Map map = threadLocal.get();
                        if (map == null) {
                            map = new HashMap();
                            threadLocal.set(map);
                        }
                        Constructor<?> constructor = (Constructor) map.get(string);
                        if (constructor == null) {
                            constructor = Class.forName(string, false, context.getClassLoader()).getConstructor(CoordinatorLayout.f2028b);
                            constructor.setAccessible(true);
                            map.put(string, constructor);
                        }
                        behavior = (Behavior) constructor.newInstance(new Object[]{context, attributeSet});
                    } catch (Exception e) {
                        throw new RuntimeException(C4924a.m17907v("Could not inflate Behavior subclass ", string), e);
                    }
                }
                this.f2055a = behavior;
            }
            obtainStyledAttributes.recycle();
            Behavior behavior2 = this.f2055a;
            if (behavior2 != null) {
                behavior2.mo2144f(this);
            }
        }

        public C0427e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0427e(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public C0427e(C0427e eVar) {
            super(eVar);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public boolean mo2172a() {
            if (this.f2055a == null) {
                this.f2067m = false;
            }
            return this.f2067m;
        }

        /* renamed from: b */
        public int mo2173b() {
            return this.f2060f;
        }

        /* renamed from: c */
        public Behavior mo2174c() {
            return this.f2055a;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: d */
        public boolean mo2175d() {
            return this.f2070p;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: e */
        public boolean mo2176e(CoordinatorLayout coordinatorLayout, View view) {
            boolean z = this.f2067m;
            boolean z2 = true;
            if (z) {
                return true;
            }
            Behavior behavior = this.f2055a;
            boolean z3 = false;
            if (behavior != null) {
                if (behavior.mo2141c() <= 0.0f) {
                    z2 = false;
                }
                z3 = z2;
            }
            boolean z4 = z | z3;
            this.f2067m = z4;
            return z4;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: f */
        public boolean mo2177f(int i) {
            if (i == 0) {
                return this.f2068n;
            }
            if (i != 1) {
                return false;
            }
            return this.f2069o;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: g */
        public void mo2178g() {
            this.f2070p = false;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: h */
        public void mo2179h() {
            this.f2067m = false;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: i */
        public void mo2180i(boolean z) {
            this.f2070p = z;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: j */
        public void mo2181j(int i, boolean z) {
            if (i == 0) {
                this.f2068n = z;
            } else if (i == 1) {
                this.f2069o = z;
            }
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$f */
    class C0428f implements ViewTreeObserver.OnPreDrawListener {
        C0428f() {
        }

        public boolean onPreDraw() {
            CoordinatorLayout.this.mo2096A(0);
            return true;
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$g */
    static class C0429g implements Comparator<View> {
        C0429g() {
        }

        public int compare(Object obj, Object obj2) {
            int i = C4761m.f17241f;
            float z = ((View) obj).getZ();
            float z2 = ((View) obj2).getZ();
            if (z > z2) {
                return -1;
            }
            return z < z2 ? 1 : 0;
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v5, resolved type: java.lang.Class<?>[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            java.lang.Class<androidx.coordinatorlayout.widget.CoordinatorLayout> r0 = androidx.coordinatorlayout.widget.CoordinatorLayout.class
            java.lang.Package r0 = r0.getPackage()
            if (r0 == 0) goto L_0x000d
            java.lang.String r0 = r0.getName()
            goto L_0x000e
        L_0x000d:
            r0 = 0
        L_0x000e:
            f2027a = r0
            androidx.coordinatorlayout.widget.CoordinatorLayout$g r0 = new androidx.coordinatorlayout.widget.CoordinatorLayout$g
            r0.<init>()
            f2030d = r0
            r0 = 2
            java.lang.Class[] r0 = new java.lang.Class[r0]
            r1 = 0
            java.lang.Class<android.content.Context> r2 = android.content.Context.class
            r0[r1] = r2
            r1 = 1
            java.lang.Class<android.util.AttributeSet> r2 = android.util.AttributeSet.class
            r0[r1] = r2
            f2028b = r0
            java.lang.ThreadLocal r0 = new java.lang.ThreadLocal
            r0.<init>()
            f2029c = r0
            d.g.i.d r0 = new d.g.i.d
            r1 = 12
            r0.<init>(r1)
            f2031e = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.<clinit>():void");
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.coordinatorLayoutStyle);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2032f = new ArrayList();
        this.f2033g = new C0430a<>();
        this.f2034h = new ArrayList();
        this.f2035i = new ArrayList();
        this.f2037k = new int[2];
        this.f2038l = new int[2];
        this.f2051y = new C4757i();
        int[] iArr = C4689a.f17094a;
        TypedArray obtainStyledAttributes = i == 0 ? context.obtainStyledAttributes(attributeSet, iArr, 0, 2131821466) : context.obtainStyledAttributes(attributeSet, iArr, i, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            int[] iArr2 = C4689a.f17094a;
            if (i == 0) {
                saveAttributeDataForStyleable(context, iArr2, attributeSet, obtainStyledAttributes, 0, 2131821466);
            } else {
                saveAttributeDataForStyleable(context, iArr2, attributeSet, obtainStyledAttributes, i, 0);
            }
        }
        int resourceId = obtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            this.f2041o = resources.getIntArray(resourceId);
            float f = resources.getDisplayMetrics().density;
            int length = this.f2041o.length;
            for (int i2 = 0; i2 < length; i2++) {
                int[] iArr3 = this.f2041o;
                iArr3[i2] = (int) (((float) iArr3[i2]) * f);
            }
        }
        this.f2048v = obtainStyledAttributes.getDrawable(1);
        obtainStyledAttributes.recycle();
        m1991I();
        super.setOnHierarchyChangeListener(new C0426d());
        int i3 = C4761m.f17241f;
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
    }

    /* renamed from: D */
    private boolean m1987D(MotionEvent motionEvent, int i) {
        MotionEvent motionEvent2 = motionEvent;
        int i2 = i;
        int actionMasked = motionEvent.getActionMasked();
        List<View> list = this.f2034h;
        list.clear();
        boolean isChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i3 = childCount - 1; i3 >= 0; i3--) {
            list.add(getChildAt(isChildrenDrawingOrderEnabled ? getChildDrawingOrder(childCount, i3) : i3));
        }
        Comparator<View> comparator = f2030d;
        if (comparator != null) {
            Collections.sort(list, comparator);
        }
        int size = list.size();
        MotionEvent motionEvent3 = null;
        boolean z = false;
        boolean z2 = false;
        for (int i4 = 0; i4 < size; i4++) {
            View view = list.get(i4);
            C0427e eVar = (C0427e) view.getLayoutParams();
            Behavior behavior = eVar.f2055a;
            if ((!z && !z2) || actionMasked == 0) {
                if (!z && behavior != null) {
                    if (i2 == 0) {
                        z = behavior.mo2148j(this, view, motionEvent2);
                    } else if (i2 == 1) {
                        z = behavior.mo2138A(this, view, motionEvent2);
                    }
                    if (z) {
                        this.f2042p = view;
                    }
                }
                boolean a = eVar.mo2172a();
                boolean e = eVar.mo2176e(this, view);
                z2 = e && !a;
                if (e && !z2) {
                    break;
                }
            } else if (behavior != null) {
                if (motionEvent3 == null) {
                    long uptimeMillis = SystemClock.uptimeMillis();
                    motionEvent3 = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                }
                if (i2 == 0) {
                    behavior.mo2148j(this, view, motionEvent3);
                } else if (i2 == 1) {
                    behavior.mo2138A(this, view, motionEvent3);
                }
            }
        }
        list.clear();
        return z;
    }

    /* renamed from: E */
    private void m1988E(boolean z) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            Behavior behavior = ((C0427e) childAt.getLayoutParams()).f2055a;
            if (behavior != null) {
                long uptimeMillis = SystemClock.uptimeMillis();
                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z) {
                    behavior.mo2148j(this, childAt, obtain);
                } else {
                    behavior.mo2138A(this, childAt, obtain);
                }
                obtain.recycle();
            }
        }
        for (int i2 = 0; i2 < childCount; i2++) {
            ((C0427e) getChildAt(i2).getLayoutParams()).mo2179h();
        }
        this.f2042p = null;
        this.f2039m = false;
    }

    /* renamed from: F */
    private void m1989F(View view, int i) {
        C0427e eVar = (C0427e) view.getLayoutParams();
        int i2 = eVar.f2063i;
        if (i2 != i) {
            C4761m.m17303l(view, i - i2);
            eVar.f2063i = i;
        }
    }

    /* renamed from: G */
    private void m1990G(View view, int i) {
        C0427e eVar = (C0427e) view.getLayoutParams();
        int i2 = eVar.f2064j;
        if (i2 != i) {
            C4761m.m17304m(view, i - i2);
            eVar.f2064j = i;
        }
    }

    /* renamed from: I */
    private void m1991I() {
        int i = C4761m.f17241f;
        if (getFitsSystemWindows()) {
            if (this.f2050x == null) {
                this.f2050x = new C0423a();
            }
            C4761m.m17312u(this, this.f2050x);
            setSystemUiVisibility(1280);
            return;
        }
        C4761m.m17312u(this, (C4758j) null);
    }

    /* renamed from: d */
    private static Rect m1992d() {
        Rect a = f2031e.mo7332a();
        return a == null ? new Rect() : a;
    }

    /* renamed from: k */
    private void m1993k(C0427e eVar, Rect rect, int i, int i2) {
        int width = getWidth();
        int height = getHeight();
        int max = Math.max(getPaddingLeft() + eVar.leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i) - eVar.rightMargin));
        int max2 = Math.max(getPaddingTop() + eVar.topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i2) - eVar.bottomMargin));
        rect.set(max, max2, i + max, i2 + max2);
    }

    /* renamed from: v */
    private void m1994v(int i, Rect rect, Rect rect2, C0427e eVar, int i2, int i3) {
        int i4 = eVar.f2057c;
        if (i4 == 0) {
            i4 = 17;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i4, i);
        int i5 = eVar.f2058d;
        if ((i5 & 7) == 0) {
            i5 |= 8388611;
        }
        if ((i5 & 112) == 0) {
            i5 |= 48;
        }
        int absoluteGravity2 = Gravity.getAbsoluteGravity(i5, i);
        int i6 = absoluteGravity & 7;
        int i7 = absoluteGravity & 112;
        int i8 = absoluteGravity2 & 7;
        int i9 = absoluteGravity2 & 112;
        int width = i8 != 1 ? i8 != 5 ? rect.left : rect.right : rect.left + (rect.width() / 2);
        int height = i9 != 16 ? i9 != 80 ? rect.top : rect.bottom : rect.top + (rect.height() / 2);
        if (i6 == 1) {
            width -= i2 / 2;
        } else if (i6 != 5) {
            width -= i2;
        }
        if (i7 == 16) {
            height -= i3 / 2;
        } else if (i7 != 80) {
            height -= i3;
        }
        rect2.set(width, height, i2 + width, i3 + height);
    }

    /* renamed from: w */
    private int m1995w(int i) {
        StringBuilder sb;
        int[] iArr = this.f2041o;
        if (iArr == null) {
            sb = new StringBuilder();
            sb.append("No keylines defined for ");
            sb.append(this);
            sb.append(" - attempted index lookup ");
            sb.append(i);
        } else if (i >= 0 && i < iArr.length) {
            return iArr[i];
        } else {
            sb = new StringBuilder();
            sb.append("Keyline index ");
            sb.append(i);
            sb.append(" out of range for ");
            sb.append(this);
        }
        Log.e("CoordinatorLayout", sb.toString());
        return 0;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: A */
    public final void mo2096A(int i) {
        int i2;
        Rect rect;
        int i3;
        boolean z;
        boolean z2;
        boolean z3;
        int width;
        int i4;
        int i5;
        int i6;
        int height;
        int i7;
        int i8;
        int i9;
        Rect rect2;
        int i10;
        int i11;
        int i12;
        C0427e eVar;
        Behavior behavior;
        int i13 = i;
        int i14 = C4761m.f17241f;
        int layoutDirection = getLayoutDirection();
        int size = this.f2032f.size();
        Rect d = m1992d();
        Rect d2 = m1992d();
        Rect d3 = m1992d();
        int i15 = 0;
        while (i15 < size) {
            View view = this.f2032f.get(i15);
            C0427e eVar2 = (C0427e) view.getLayoutParams();
            if (i13 == 0 && view.getVisibility() == 8) {
                i3 = size;
                rect = d3;
                i2 = i15;
            } else {
                int i16 = 0;
                while (i16 < i15) {
                    if (eVar2.f2066l == this.f2032f.get(i16)) {
                        C0427e eVar3 = (C0427e) view.getLayoutParams();
                        if (eVar3.f2065k != null) {
                            Rect d4 = m1992d();
                            Rect d5 = m1992d();
                            Rect d6 = m1992d();
                            C0431b.m2061a(this, eVar3.f2065k, d4);
                            mo2128s(view, false, d5);
                            int measuredWidth = view.getMeasuredWidth();
                            i12 = size;
                            int measuredHeight = view.getMeasuredHeight();
                            int i17 = measuredWidth;
                            Rect rect3 = d6;
                            i11 = i15;
                            Rect rect4 = d5;
                            Rect rect5 = d4;
                            C0427e eVar4 = eVar3;
                            i10 = i16;
                            rect2 = d3;
                            eVar = eVar2;
                            m1994v(layoutDirection, d4, rect3, eVar3, i17, measuredHeight);
                            Rect rect6 = rect3;
                            boolean z4 = (rect6.left == rect4.left && rect6.top == rect4.top) ? false : true;
                            C0427e eVar5 = eVar4;
                            m1993k(eVar5, rect6, i17, measuredHeight);
                            int i18 = rect6.left - rect4.left;
                            int i19 = rect6.top - rect4.top;
                            if (i18 != 0) {
                                C4761m.m17303l(view, i18);
                            }
                            if (i19 != 0) {
                                C4761m.m17304m(view, i19);
                            }
                            if (z4 && (behavior = eVar5.f2055a) != null) {
                                behavior.mo2145g(this, view, eVar5.f2065k);
                            }
                            rect5.setEmpty();
                            C4742b<Rect> bVar = f2031e;
                            bVar.mo7333b(rect5);
                            rect4.setEmpty();
                            bVar.mo7333b(rect4);
                            rect6.setEmpty();
                            bVar.mo7333b(rect6);
                            i16 = i10 + 1;
                            eVar2 = eVar;
                            size = i12;
                            i15 = i11;
                            d3 = rect2;
                        }
                    }
                    i10 = i16;
                    i12 = size;
                    rect2 = d3;
                    i11 = i15;
                    eVar = eVar2;
                    i16 = i10 + 1;
                    eVar2 = eVar;
                    size = i12;
                    i15 = i11;
                    d3 = rect2;
                }
                int i20 = size;
                Rect rect7 = d3;
                i2 = i15;
                C0427e eVar6 = eVar2;
                mo2128s(view, true, d2);
                if (eVar6.f2061g != 0 && !d2.isEmpty()) {
                    int absoluteGravity = Gravity.getAbsoluteGravity(eVar6.f2061g, layoutDirection);
                    int i21 = absoluteGravity & 112;
                    if (i21 == 48) {
                        d.top = Math.max(d.top, d2.bottom);
                    } else if (i21 == 80) {
                        d.bottom = Math.max(d.bottom, getHeight() - d2.top);
                    }
                    int i22 = absoluteGravity & 7;
                    if (i22 == 3) {
                        d.left = Math.max(d.left, d2.right);
                    } else if (i22 == 5) {
                        d.right = Math.max(d.right, getWidth() - d2.left);
                    }
                }
                if (eVar6.f2062h != 0 && view.getVisibility() == 0) {
                    int i23 = C4761m.f17241f;
                    if (view.isLaidOut() && view.getWidth() > 0 && view.getHeight() > 0) {
                        C0427e eVar7 = (C0427e) view.getLayoutParams();
                        Behavior behavior2 = eVar7.f2055a;
                        Rect d7 = m1992d();
                        Rect d8 = m1992d();
                        d8.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
                        if (behavior2 == null || !behavior2.mo2139a(this, view, d7)) {
                            d7.set(d8);
                        } else if (!d8.contains(d7)) {
                            StringBuilder P = C4924a.m17863P("Rect should be within the child's bounds. Rect:");
                            P.append(d7.toShortString());
                            P.append(" | Bounds:");
                            P.append(d8.toShortString());
                            throw new IllegalArgumentException(P.toString());
                        }
                        d8.setEmpty();
                        C4742b<Rect> bVar2 = f2031e;
                        bVar2.mo7333b(d8);
                        if (!d7.isEmpty()) {
                            int absoluteGravity2 = Gravity.getAbsoluteGravity(eVar7.f2062h, layoutDirection);
                            if ((absoluteGravity2 & 48) != 48 || (i8 = (d7.top - eVar7.topMargin) - eVar7.f2064j) >= (i9 = d.top)) {
                                z2 = false;
                            } else {
                                m1990G(view, i9 - i8);
                                z2 = true;
                            }
                            if ((absoluteGravity2 & 80) == 80 && (height = ((getHeight() - d7.bottom) - eVar7.bottomMargin) + eVar7.f2064j) < (i7 = d.bottom)) {
                                m1990G(view, height - i7);
                                z2 = true;
                            }
                            if (!z2) {
                                m1990G(view, 0);
                            }
                            if ((absoluteGravity2 & 3) != 3 || (i5 = (d7.left - eVar7.leftMargin) - eVar7.f2063i) >= (i6 = d.left)) {
                                z3 = false;
                            } else {
                                m1989F(view, i6 - i5);
                                z3 = true;
                            }
                            if ((absoluteGravity2 & 5) == 5 && (width = ((getWidth() - d7.right) - eVar7.rightMargin) + eVar7.f2063i) < (i4 = d.right)) {
                                m1989F(view, width - i4);
                                z3 = true;
                            }
                            if (!z3) {
                                m1989F(view, 0);
                            }
                        }
                        d7.setEmpty();
                        bVar2.mo7333b(d7);
                    }
                }
                if (i13 != 2) {
                    rect = rect7;
                    rect.set(((C0427e) view.getLayoutParams()).f2071q);
                    if (rect.equals(d2)) {
                        i3 = i20;
                    } else {
                        ((C0427e) view.getLayoutParams()).f2071q.set(d2);
                    }
                } else {
                    rect = rect7;
                }
                i3 = i20;
                for (int i24 = i2 + 1; i24 < i3; i24++) {
                    View view2 = this.f2032f.get(i24);
                    C0427e eVar8 = (C0427e) view2.getLayoutParams();
                    Behavior behavior3 = eVar8.f2055a;
                    if (behavior3 != null && behavior3.mo2142d(this, view2, view)) {
                        if (i13 != 0 || !eVar8.mo2175d()) {
                            if (i13 != 2) {
                                z = behavior3.mo2145g(this, view2, view);
                            } else {
                                behavior3.mo2146h(this, view2, view);
                                z = true;
                            }
                            if (i13 == 1) {
                                eVar8.mo2180i(z);
                            }
                        } else {
                            eVar8.mo2178g();
                        }
                    }
                }
            }
            i15 = i2 + 1;
            size = i3;
            d3 = rect;
        }
        Rect rect8 = d3;
        d.setEmpty();
        C4742b<Rect> bVar3 = f2031e;
        bVar3.mo7333b(d);
        d2.setEmpty();
        bVar3.mo7333b(d2);
        rect8.setEmpty();
        bVar3.mo7333b(rect8);
    }

    /* renamed from: B */
    public void mo2097B(View view, int i) {
        C0427e eVar = (C0427e) view.getLayoutParams();
        View view2 = eVar.f2065k;
        int i2 = 0;
        if (view2 == null && eVar.f2060f != -1) {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        } else if (view2 != null) {
            Rect d = m1992d();
            Rect d2 = m1992d();
            try {
                C0431b.m2061a(this, view2, d);
                C0427e eVar2 = (C0427e) view.getLayoutParams();
                int measuredWidth = view.getMeasuredWidth();
                int measuredHeight = view.getMeasuredHeight();
                m1994v(i, d, d2, eVar2, measuredWidth, measuredHeight);
                m1993k(eVar2, d2, measuredWidth, measuredHeight);
                view.layout(d2.left, d2.top, d2.right, d2.bottom);
            } finally {
                d.setEmpty();
                C4742b<Rect> bVar = f2031e;
                bVar.mo7333b(d);
                d2.setEmpty();
                bVar.mo7333b(d2);
            }
        } else {
            int i3 = eVar.f2059e;
            if (i3 >= 0) {
                C0427e eVar3 = (C0427e) view.getLayoutParams();
                int i4 = eVar3.f2057c;
                if (i4 == 0) {
                    i4 = 8388661;
                }
                int absoluteGravity = Gravity.getAbsoluteGravity(i4, i);
                int i5 = absoluteGravity & 7;
                int i6 = absoluteGravity & 112;
                int width = getWidth();
                int height = getHeight();
                int measuredWidth2 = view.getMeasuredWidth();
                int measuredHeight2 = view.getMeasuredHeight();
                if (i == 1) {
                    i3 = width - i3;
                }
                int w = m1995w(i3) - measuredWidth2;
                if (i5 == 1) {
                    w += measuredWidth2 / 2;
                } else if (i5 == 5) {
                    w += measuredWidth2;
                }
                if (i6 == 16) {
                    i2 = 0 + (measuredHeight2 / 2);
                } else if (i6 == 80) {
                    i2 = measuredHeight2 + 0;
                }
                int max = Math.max(getPaddingLeft() + eVar3.leftMargin, Math.min(w, ((width - getPaddingRight()) - measuredWidth2) - eVar3.rightMargin));
                int max2 = Math.max(getPaddingTop() + eVar3.topMargin, Math.min(i2, ((height - getPaddingBottom()) - measuredHeight2) - eVar3.bottomMargin));
                view.layout(max, max2, measuredWidth2 + max, measuredHeight2 + max2);
                return;
            }
            C0427e eVar4 = (C0427e) view.getLayoutParams();
            Rect d3 = m1992d();
            d3.set(getPaddingLeft() + eVar4.leftMargin, getPaddingTop() + eVar4.topMargin, (getWidth() - getPaddingRight()) - eVar4.rightMargin, (getHeight() - getPaddingBottom()) - eVar4.bottomMargin);
            if (this.f2046t != null) {
                int i7 = C4761m.f17241f;
                if (getFitsSystemWindows() && !view.getFitsSystemWindows()) {
                    d3.left = this.f2046t.mo21892e() + d3.left;
                    d3.top = this.f2046t.mo21895g() + d3.top;
                    d3.right -= this.f2046t.mo21894f();
                    d3.bottom -= this.f2046t.mo21891d();
                }
            }
            Rect d4 = m1992d();
            int i8 = eVar4.f2057c;
            if ((i8 & 7) == 0) {
                i8 |= 8388611;
            }
            if ((i8 & 112) == 0) {
                i8 |= 48;
            }
            Gravity.apply(i8, view.getMeasuredWidth(), view.getMeasuredHeight(), d3, d4, i);
            view.layout(d4.left, d4.top, d4.right, d4.bottom);
            d3.setEmpty();
            C4742b<Rect> bVar2 = f2031e;
            bVar2.mo7333b(d3);
            d4.setEmpty();
            bVar2.mo7333b(d4);
        }
    }

    /* renamed from: C */
    public void mo2098C(View view, int i, int i2, int i3, int i4) {
        measureChildWithMargins(view, i, i2, i3, i4);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: H */
    public final C4780v mo2099H(C4780v vVar) {
        Behavior behavior;
        if (!Objects.equals(this.f2046t, vVar)) {
            this.f2046t = vVar;
            boolean z = true;
            boolean z2 = vVar != null && vVar.mo21895g() > 0;
            this.f2047u = z2;
            if (z2 || getBackground() != null) {
                z = false;
            }
            setWillNotDraw(z);
            if (!vVar.mo21899k()) {
                int childCount = getChildCount();
                for (int i = 0; i < childCount; i++) {
                    View childAt = getChildAt(i);
                    int i2 = C4761m.f17241f;
                    if (childAt.getFitsSystemWindows() && (behavior = ((C0427e) childAt.getLayoutParams()).f2055a) != null) {
                        vVar = behavior.mo2143e(vVar);
                        if (vVar.mo21899k()) {
                            break;
                        }
                    }
                }
            }
            requestLayout();
        }
        return vVar;
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof C0427e) && super.checkLayoutParams(layoutParams);
    }

    /* access modifiers changed from: protected */
    public boolean drawChild(Canvas canvas, View view, long j) {
        C0427e eVar = (C0427e) view.getLayoutParams();
        Behavior behavior = eVar.f2055a;
        if (behavior != null) {
            float c = behavior.mo2141c();
            if (c > 0.0f) {
                if (this.f2036j == null) {
                    this.f2036j = new Paint();
                }
                this.f2036j.setColor(eVar.f2055a.mo2140b());
                Paint paint = this.f2036j;
                int round = Math.round(c * 255.0f);
                if (round < 0) {
                    round = 0;
                } else if (round > 255) {
                    round = 255;
                }
                paint.setAlpha(round);
                int save = canvas.save();
                if (view.isOpaque()) {
                    canvas.clipRect((float) view.getLeft(), (float) view.getTop(), (float) view.getRight(), (float) view.getBottom(), Region.Op.DIFFERENCE);
                }
                canvas.drawRect((float) getPaddingLeft(), (float) getPaddingTop(), (float) (getWidth() - getPaddingRight()), (float) (getHeight() - getPaddingBottom()), this.f2036j);
                canvas.restoreToCount(save);
            }
        }
        return super.drawChild(canvas, view, j);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f2048v;
        boolean z = false;
        if (drawable != null && drawable.isStateful()) {
            z = false | drawable.setState(drawableState);
        }
        if (z) {
            invalidate();
        }
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0427e(-2, -2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0427e(getContext(), attributeSet);
    }

    public int getNestedScrollAxes() {
        return this.f2051y.mo21852a();
    }

    /* access modifiers changed from: protected */
    public int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingBottom() + getPaddingTop());
    }

    /* access modifiers changed from: protected */
    public int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingRight() + getPaddingLeft());
    }

    /* renamed from: l */
    public void mo1064l(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        Behavior behavior;
        int childCount = getChildCount();
        boolean z = false;
        int i6 = 0;
        int i7 = 0;
        for (int i8 = 0; i8 < childCount; i8++) {
            View childAt = getChildAt(i8);
            if (childAt.getVisibility() != 8) {
                C0427e eVar = (C0427e) childAt.getLayoutParams();
                if (eVar.mo2177f(i5) && (behavior = eVar.f2055a) != null) {
                    int[] iArr2 = this.f2037k;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    behavior.mo2156r(this, childAt, view, i, i2, i3, i4, i5, iArr2);
                    int[] iArr3 = this.f2037k;
                    i6 = i3 > 0 ? Math.max(i6, iArr3[0]) : Math.min(i6, iArr3[0]);
                    i7 = i4 > 0 ? Math.max(i7, this.f2037k[1]) : Math.min(i7, this.f2037k[1]);
                    z = true;
                }
            }
        }
        iArr[0] = iArr[0] + i6;
        iArr[1] = iArr[1] + i7;
        if (z) {
            mo2096A(1);
        }
    }

    /* renamed from: m */
    public void mo1065m(View view, int i, int i2, int i3, int i4, int i5) {
        mo1064l(view, i, i2, i3, i4, 0, this.f2038l);
    }

    /* renamed from: n */
    public boolean mo1066n(View view, View view2, int i, int i2) {
        int i3 = i2;
        int childCount = getChildCount();
        int i4 = 0;
        boolean z = false;
        while (true) {
            if (i4 >= childCount) {
                return z;
            }
            View childAt = getChildAt(i4);
            if (childAt.getVisibility() != 8) {
                C0427e eVar = (C0427e) childAt.getLayoutParams();
                Behavior behavior = eVar.f2055a;
                if (behavior != null) {
                    boolean x = behavior.mo2162x(this, childAt, view, view2, i, i2);
                    z |= x;
                    eVar.mo2181j(i3, x);
                } else {
                    eVar.mo2181j(i3, false);
                }
            }
            i4++;
        }
    }

    /* renamed from: o */
    public void mo1067o(View view, View view2, int i, int i2) {
        Behavior behavior;
        this.f2051y.mo21853b(i, i2);
        this.f2043q = view2;
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            C0427e eVar = (C0427e) getChildAt(i3).getLayoutParams();
            if (eVar.mo2177f(i2) && (behavior = eVar.f2055a) != null && i2 == 0) {
                behavior.mo2157s();
            }
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        m1988E(false);
        if (this.f2045s) {
            if (this.f2044r == null) {
                this.f2044r = new C0428f();
            }
            getViewTreeObserver().addOnPreDrawListener(this.f2044r);
        }
        if (this.f2046t == null) {
            int i = C4761m.f17241f;
            if (getFitsSystemWindows()) {
                requestApplyInsets();
            }
        }
        this.f2040n = true;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        m1988E(false);
        if (this.f2045s && this.f2044r != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f2044r);
        }
        View view = this.f2043q;
        if (view != null) {
            onStopNestedScroll(view);
        }
        this.f2040n = false;
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f2047u && this.f2048v != null) {
            C4780v vVar = this.f2046t;
            int g = vVar != null ? vVar.mo21895g() : 0;
            if (g > 0) {
                this.f2048v.setBounds(0, 0, getWidth(), g);
                this.f2048v.draw(canvas);
            }
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            m1988E(true);
        }
        boolean D = m1987D(motionEvent, 0);
        if (actionMasked == 1 || actionMasked == 3) {
            m1988E(true);
        }
        return D;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        Behavior behavior;
        int i5 = C4761m.f17241f;
        int layoutDirection = getLayoutDirection();
        int size = this.f2032f.size();
        for (int i6 = 0; i6 < size; i6++) {
            View view = this.f2032f.get(i6);
            if (view.getVisibility() != 8 && ((behavior = ((C0427e) view.getLayoutParams()).f2055a) == null || !behavior.mo2149k(this, view, layoutDirection))) {
                mo2097B(view, layoutDirection);
            }
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:140:0x02a0, code lost:
        if (r0.mo2150l(r30, r19, r23, r22, r24, 0) == false) goto L_0x02ae;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0058, code lost:
        if (r5 != false) goto L_0x00a7;
     */
    /* JADX WARNING: Removed duplicated region for block: B:135:0x024f  */
    /* JADX WARNING: Removed duplicated region for block: B:136:0x027a  */
    /* JADX WARNING: Removed duplicated region for block: B:139:0x0282  */
    /* JADX WARNING: Removed duplicated region for block: B:141:0x02a3  */
    /* JADX WARNING: Removed duplicated region for block: B:163:0x00fe A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:64:0x00ec  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r31, int r32) {
        /*
            r30 = this;
            r7 = r30
            java.util.List<android.view.View> r0 = r7.f2032f
            r0.clear()
            androidx.coordinatorlayout.widget.a<android.view.View> r0 = r7.f2033g
            r0.mo2186c()
            int r0 = r30.getChildCount()
            r1 = 0
            r2 = 0
        L_0x0012:
            r3 = 1
            if (r2 >= r0) goto L_0x012a
            android.view.View r3 = r7.getChildAt(r2)
            androidx.coordinatorlayout.widget.CoordinatorLayout$e r4 = r7.mo2136y(r3)
            int r5 = r4.f2060f
            r6 = 0
            r8 = -1
            if (r5 != r8) goto L_0x0029
            r4.f2066l = r6
            r4.f2065k = r6
            goto L_0x00a7
        L_0x0029:
            android.view.View r5 = r4.f2065k
            if (r5 == 0) goto L_0x005a
            int r5 = r5.getId()
            int r8 = r4.f2060f
            if (r5 == r8) goto L_0x0036
            goto L_0x0053
        L_0x0036:
            android.view.View r5 = r4.f2065k
            android.view.ViewParent r8 = r5.getParent()
        L_0x003c:
            if (r8 == r7) goto L_0x0055
            if (r8 == 0) goto L_0x004f
            if (r8 != r3) goto L_0x0043
            goto L_0x004f
        L_0x0043:
            boolean r9 = r8 instanceof android.view.View
            if (r9 == 0) goto L_0x004a
            r5 = r8
            android.view.View r5 = (android.view.View) r5
        L_0x004a:
            android.view.ViewParent r8 = r8.getParent()
            goto L_0x003c
        L_0x004f:
            r4.f2066l = r6
            r4.f2065k = r6
        L_0x0053:
            r5 = 0
            goto L_0x0058
        L_0x0055:
            r4.f2066l = r5
            r5 = 1
        L_0x0058:
            if (r5 != 0) goto L_0x00a7
        L_0x005a:
            int r5 = r4.f2060f
            android.view.View r5 = r7.findViewById(r5)
            r4.f2065k = r5
            if (r5 == 0) goto L_0x009d
            if (r5 != r7) goto L_0x0075
            boolean r5 = r30.isInEditMode()
            if (r5 == 0) goto L_0x006d
            goto L_0x00a3
        L_0x006d:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "View can not be anchored to the the parent CoordinatorLayout"
            r0.<init>(r1)
            throw r0
        L_0x0075:
            android.view.ViewParent r8 = r5.getParent()
        L_0x0079:
            if (r8 == r7) goto L_0x009a
            if (r8 == 0) goto L_0x009a
            if (r8 != r3) goto L_0x008e
            boolean r5 = r30.isInEditMode()
            if (r5 == 0) goto L_0x0086
            goto L_0x00a3
        L_0x0086:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "Anchor must not be a descendant of the anchored view"
            r0.<init>(r1)
            throw r0
        L_0x008e:
            boolean r9 = r8 instanceof android.view.View
            if (r9 == 0) goto L_0x0095
            r5 = r8
            android.view.View r5 = (android.view.View) r5
        L_0x0095:
            android.view.ViewParent r8 = r8.getParent()
            goto L_0x0079
        L_0x009a:
            r4.f2066l = r5
            goto L_0x00a7
        L_0x009d:
            boolean r5 = r30.isInEditMode()
            if (r5 == 0) goto L_0x0105
        L_0x00a3:
            r4.f2066l = r6
            r4.f2065k = r6
        L_0x00a7:
            androidx.coordinatorlayout.widget.a<android.view.View> r5 = r7.f2033g
            r5.mo2185b(r3)
            r5 = 0
        L_0x00ad:
            if (r5 >= r0) goto L_0x0101
            if (r5 != r2) goto L_0x00b2
            goto L_0x00fe
        L_0x00b2:
            android.view.View r6 = r7.getChildAt(r5)
            android.view.View r8 = r4.f2066l
            if (r6 == r8) goto L_0x00e9
            int r8 = p098d.p120g.p130j.C4761m.f17241f
            int r8 = r30.getLayoutDirection()
            android.view.ViewGroup$LayoutParams r9 = r6.getLayoutParams()
            androidx.coordinatorlayout.widget.CoordinatorLayout$e r9 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0427e) r9
            int r9 = r9.f2061g
            int r9 = android.view.Gravity.getAbsoluteGravity(r9, r8)
            if (r9 == 0) goto L_0x00d9
            int r10 = r4.f2062h
            int r8 = android.view.Gravity.getAbsoluteGravity(r10, r8)
            r8 = r8 & r9
            if (r8 != r9) goto L_0x00d9
            r8 = 1
            goto L_0x00da
        L_0x00d9:
            r8 = 0
        L_0x00da:
            if (r8 != 0) goto L_0x00e9
            androidx.coordinatorlayout.widget.CoordinatorLayout$Behavior r8 = r4.f2055a
            if (r8 == 0) goto L_0x00e7
            boolean r8 = r8.mo2142d(r7, r3, r6)
            if (r8 == 0) goto L_0x00e7
            goto L_0x00e9
        L_0x00e7:
            r8 = 0
            goto L_0x00ea
        L_0x00e9:
            r8 = 1
        L_0x00ea:
            if (r8 == 0) goto L_0x00fe
            androidx.coordinatorlayout.widget.a<android.view.View> r8 = r7.f2033g
            boolean r8 = r8.mo2187d(r6)
            if (r8 != 0) goto L_0x00f9
            androidx.coordinatorlayout.widget.a<android.view.View> r8 = r7.f2033g
            r8.mo2185b(r6)
        L_0x00f9:
            androidx.coordinatorlayout.widget.a<android.view.View> r8 = r7.f2033g
            r8.mo2184a(r6, r3)
        L_0x00fe:
            int r5 = r5 + 1
            goto L_0x00ad
        L_0x0101:
            int r2 = r2 + 1
            goto L_0x0012
        L_0x0105:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "Could not find CoordinatorLayout descendant view with id "
            java.lang.StringBuilder r1 = p165e.p166a.p167a.p168a.C4924a.m17863P(r1)
            android.content.res.Resources r2 = r30.getResources()
            int r4 = r4.f2060f
            java.lang.String r2 = r2.getResourceName(r4)
            r1.append(r2)
            java.lang.String r2 = " to anchor view "
            r1.append(r2)
            r1.append(r3)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x012a:
            java.util.List<android.view.View> r0 = r7.f2032f
            androidx.coordinatorlayout.widget.a<android.view.View> r2 = r7.f2033g
            java.util.ArrayList r2 = r2.mo2190h()
            r0.addAll(r2)
            java.util.List<android.view.View> r0 = r7.f2032f
            java.util.Collections.reverse(r0)
            int r0 = r30.getChildCount()
            r2 = 0
        L_0x013f:
            if (r2 >= r0) goto L_0x0152
            android.view.View r4 = r7.getChildAt(r2)
            androidx.coordinatorlayout.widget.a<android.view.View> r5 = r7.f2033g
            boolean r4 = r5.mo2191i(r4)
            if (r4 == 0) goto L_0x014f
            r0 = 1
            goto L_0x0153
        L_0x014f:
            int r2 = r2 + 1
            goto L_0x013f
        L_0x0152:
            r0 = 0
        L_0x0153:
            boolean r2 = r7.f2045s
            if (r0 == r2) goto L_0x0187
            if (r0 == 0) goto L_0x0174
            boolean r0 = r7.f2040n
            if (r0 == 0) goto L_0x0171
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r0 = r7.f2044r
            if (r0 != 0) goto L_0x0168
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r0 = new androidx.coordinatorlayout.widget.CoordinatorLayout$f
            r0.<init>()
            r7.f2044r = r0
        L_0x0168:
            android.view.ViewTreeObserver r0 = r30.getViewTreeObserver()
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r1 = r7.f2044r
            r0.addOnPreDrawListener(r1)
        L_0x0171:
            r7.f2045s = r3
            goto L_0x0187
        L_0x0174:
            boolean r0 = r7.f2040n
            if (r0 == 0) goto L_0x0185
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r0 = r7.f2044r
            if (r0 == 0) goto L_0x0185
            android.view.ViewTreeObserver r0 = r30.getViewTreeObserver()
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r2 = r7.f2044r
            r0.removeOnPreDrawListener(r2)
        L_0x0185:
            r7.f2045s = r1
        L_0x0187:
            int r8 = r30.getPaddingLeft()
            int r0 = r30.getPaddingTop()
            int r9 = r30.getPaddingRight()
            int r1 = r30.getPaddingBottom()
            int r2 = p098d.p120g.p130j.C4761m.f17241f
            int r10 = r30.getLayoutDirection()
            if (r10 != r3) goto L_0x01a2
            r2 = 1
            r11 = 1
            goto L_0x01a4
        L_0x01a2:
            r2 = 0
            r11 = 0
        L_0x01a4:
            int r12 = android.view.View.MeasureSpec.getMode(r31)
            int r13 = android.view.View.MeasureSpec.getSize(r31)
            int r14 = android.view.View.MeasureSpec.getMode(r32)
            int r15 = android.view.View.MeasureSpec.getSize(r32)
            int r16 = r8 + r9
            int r17 = r0 + r1
            int r0 = r30.getSuggestedMinimumWidth()
            int r1 = r30.getSuggestedMinimumHeight()
            d.g.j.v r2 = r7.f2046t
            if (r2 == 0) goto L_0x01ce
            boolean r2 = r30.getFitsSystemWindows()
            if (r2 == 0) goto L_0x01ce
            r2 = 1
            r18 = 1
            goto L_0x01d1
        L_0x01ce:
            r2 = 0
            r18 = 0
        L_0x01d1:
            java.util.List<android.view.View> r2 = r7.f2032f
            int r6 = r2.size()
            r2 = 0
            r3 = 0
            r5 = r0
            r4 = r1
            r2 = 0
            r3 = 0
        L_0x01dd:
            if (r2 >= r6) goto L_0x02f5
            java.util.List<android.view.View> r0 = r7.f2032f
            java.lang.Object r0 = r0.get(r2)
            r19 = r0
            android.view.View r19 = (android.view.View) r19
            int r0 = r19.getVisibility()
            r1 = 8
            if (r0 != r1) goto L_0x01f9
            r20 = r2
            r29 = r6
            r21 = r8
            goto L_0x02ed
        L_0x01f9:
            android.view.ViewGroup$LayoutParams r0 = r19.getLayoutParams()
            r1 = r0
            androidx.coordinatorlayout.widget.CoordinatorLayout$e r1 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0427e) r1
            int r0 = r1.f2059e
            if (r0 < 0) goto L_0x0240
            if (r12 == 0) goto L_0x0240
            int r0 = r7.m1995w(r0)
            r20 = r2
            int r2 = r1.f2057c
            if (r2 != 0) goto L_0x0213
            r2 = 8388661(0x800035, float:1.1755018E-38)
        L_0x0213:
            int r2 = android.view.Gravity.getAbsoluteGravity(r2, r10)
            r2 = r2 & 7
            r21 = r3
            r3 = 3
            if (r2 != r3) goto L_0x0220
            if (r11 == 0) goto L_0x0225
        L_0x0220:
            r3 = 5
            if (r2 != r3) goto L_0x0230
            if (r11 == 0) goto L_0x0230
        L_0x0225:
            int r2 = r13 - r9
            int r2 = r2 - r0
            r0 = 0
            int r0 = java.lang.Math.max(r0, r2)
        L_0x022d:
            r22 = r0
            goto L_0x0247
        L_0x0230:
            if (r2 != r3) goto L_0x0234
            if (r11 == 0) goto L_0x0239
        L_0x0234:
            r3 = 3
            if (r2 != r3) goto L_0x0244
            if (r11 == 0) goto L_0x0244
        L_0x0239:
            int r0 = r0 - r8
            r2 = 0
            int r0 = java.lang.Math.max(r2, r0)
            goto L_0x022d
        L_0x0240:
            r20 = r2
            r21 = r3
        L_0x0244:
            r0 = 0
            r22 = 0
        L_0x0247:
            if (r18 == 0) goto L_0x027a
            boolean r0 = r19.getFitsSystemWindows()
            if (r0 != 0) goto L_0x027a
            d.g.j.v r0 = r7.f2046t
            int r0 = r0.mo21892e()
            d.g.j.v r2 = r7.f2046t
            int r2 = r2.mo21894f()
            int r2 = r2 + r0
            d.g.j.v r0 = r7.f2046t
            int r0 = r0.mo21895g()
            d.g.j.v r3 = r7.f2046t
            int r3 = r3.mo21891d()
            int r3 = r3 + r0
            int r0 = r13 - r2
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r12)
            int r2 = r15 - r3
            int r2 = android.view.View.MeasureSpec.makeMeasureSpec(r2, r14)
            r23 = r0
            r24 = r2
            goto L_0x027e
        L_0x027a:
            r23 = r31
            r24 = r32
        L_0x027e:
            androidx.coordinatorlayout.widget.CoordinatorLayout$Behavior r0 = r1.f2055a
            if (r0 == 0) goto L_0x02a3
            r25 = 0
            r3 = r1
            r1 = r30
            r2 = r19
            r27 = r3
            r26 = r21
            r3 = r23
            r28 = r4
            r4 = r22
            r21 = r8
            r8 = r5
            r5 = r24
            r29 = r6
            r6 = r25
            boolean r0 = r0.mo2150l(r1, r2, r3, r4, r5, r6)
            if (r0 != 0) goto L_0x02bc
            goto L_0x02ae
        L_0x02a3:
            r27 = r1
            r28 = r4
            r29 = r6
            r26 = r21
            r21 = r8
            r8 = r5
        L_0x02ae:
            r5 = 0
            r0 = r30
            r1 = r19
            r2 = r23
            r3 = r22
            r4 = r24
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
        L_0x02bc:
            int r0 = r19.getMeasuredWidth()
            int r0 = r0 + r16
            r1 = r27
            int r2 = r1.leftMargin
            int r0 = r0 + r2
            int r2 = r1.rightMargin
            int r0 = r0 + r2
            int r0 = java.lang.Math.max(r8, r0)
            int r2 = r19.getMeasuredHeight()
            int r2 = r2 + r17
            int r3 = r1.topMargin
            int r2 = r2 + r3
            int r1 = r1.bottomMargin
            int r2 = r2 + r1
            r1 = r28
            int r1 = java.lang.Math.max(r1, r2)
            int r2 = r19.getMeasuredState()
            r3 = r26
            int r2 = android.view.View.combineMeasuredStates(r3, r2)
            r5 = r0
            r4 = r1
            r3 = r2
        L_0x02ed:
            int r2 = r20 + 1
            r8 = r21
            r6 = r29
            goto L_0x01dd
        L_0x02f5:
            r1 = r4
            r8 = r5
            r0 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r0 = r0 & r3
            r2 = r31
            int r0 = android.view.View.resolveSizeAndState(r8, r2, r0)
            int r2 = r3 << 16
            r3 = r32
            int r1 = android.view.View.resolveSizeAndState(r1, r3, r2)
            r7.setMeasuredDimension(r0, r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onMeasure(int, int):void");
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        Behavior behavior;
        int childCount = getChildCount();
        boolean z2 = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                C0427e eVar = (C0427e) childAt.getLayoutParams();
                if (eVar.mo2177f(0) && (behavior = eVar.f2055a) != null) {
                    z2 |= behavior.mo2151m();
                }
            }
        }
        if (z2) {
            mo2096A(1);
        }
        return z2;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        Behavior behavior;
        int childCount = getChildCount();
        boolean z = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                C0427e eVar = (C0427e) childAt.getLayoutParams();
                if (eVar.mo2177f(0) && (behavior = eVar.f2055a) != null) {
                    z |= behavior.mo2152n(this, childAt, view, f, f2);
                }
            }
        }
        return z;
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        mo1083q(view, i, i2, iArr, 0);
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        mo1064l(view, i, i2, i3, i4, 0, this.f2038l);
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        mo1067o(view, view2, i, 0);
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.mo2467a());
        SparseArray<Parcelable> sparseArray = savedState.f2052c;
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            Behavior behavior = mo2136y(childAt).f2055a;
            if (!(id == -1 || behavior == null || (parcelable2 = sparseArray.get(id)) == null)) {
                behavior.mo2159u(this, childAt, parcelable2);
            }
        }
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        Parcelable v;
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            Behavior behavior = ((C0427e) childAt.getLayoutParams()).f2055a;
            if (!(id == -1 || behavior == null || (v = behavior.mo2160v(this, childAt)) == null)) {
                sparseArray.append(id, v);
            }
        }
        savedState.f2052c = sparseArray;
        return savedState;
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        return mo1066n(view, view2, i, 0);
    }

    public void onStopNestedScroll(View view) {
        mo1082p(view, 0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0012, code lost:
        if (r3 != false) goto L_0x0016;
     */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x002f  */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x004a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            int r2 = r18.getActionMasked()
            android.view.View r3 = r0.f2042p
            r4 = 1
            r5 = 0
            if (r3 != 0) goto L_0x0015
            boolean r3 = r0.m1987D(r1, r4)
            if (r3 == 0) goto L_0x0029
            goto L_0x0016
        L_0x0015:
            r3 = 0
        L_0x0016:
            android.view.View r6 = r0.f2042p
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            androidx.coordinatorlayout.widget.CoordinatorLayout$e r6 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0427e) r6
            androidx.coordinatorlayout.widget.CoordinatorLayout$Behavior r6 = r6.f2055a
            if (r6 == 0) goto L_0x0029
            android.view.View r7 = r0.f2042p
            boolean r6 = r6.mo2138A(r0, r7, r1)
            goto L_0x002a
        L_0x0029:
            r6 = 0
        L_0x002a:
            android.view.View r7 = r0.f2042p
            r8 = 0
            if (r7 != 0) goto L_0x0035
            boolean r1 = super.onTouchEvent(r18)
            r6 = r6 | r1
            goto L_0x0048
        L_0x0035:
            if (r3 == 0) goto L_0x0048
            long r11 = android.os.SystemClock.uptimeMillis()
            r13 = 3
            r14 = 0
            r15 = 0
            r16 = 0
            r9 = r11
            android.view.MotionEvent r8 = android.view.MotionEvent.obtain(r9, r11, r13, r14, r15, r16)
            super.onTouchEvent(r8)
        L_0x0048:
            if (r8 == 0) goto L_0x004d
            r8.recycle()
        L_0x004d:
            if (r2 == r4) goto L_0x0052
            r1 = 3
            if (r2 != r1) goto L_0x0055
        L_0x0052:
            r0.m1988E(r5)
        L_0x0055:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onTouchEvent(android.view.MotionEvent):boolean");
    }

    /* renamed from: p */
    public void mo1082p(View view, int i) {
        this.f2051y.mo21855d(i);
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            C0427e eVar = (C0427e) childAt.getLayoutParams();
            if (eVar.mo2177f(i)) {
                Behavior behavior = eVar.f2055a;
                if (behavior != null) {
                    behavior.mo2164z(this, childAt, view, i);
                }
                eVar.mo2181j(i, false);
                eVar.mo2178g();
            }
        }
        this.f2043q = null;
    }

    /* renamed from: q */
    public void mo1083q(View view, int i, int i2, int[] iArr, int i3) {
        Behavior behavior;
        int childCount = getChildCount();
        boolean z = false;
        int i4 = 0;
        int i5 = 0;
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() == 8) {
                int i7 = i3;
            } else {
                C0427e eVar = (C0427e) childAt.getLayoutParams();
                if (eVar.mo2177f(i3) && (behavior = eVar.f2055a) != null) {
                    int[] iArr2 = this.f2037k;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    behavior.mo2154p(this, childAt, view, i, i2, iArr2, i3);
                    int[] iArr3 = this.f2037k;
                    i4 = i > 0 ? Math.max(i4, iArr3[0]) : Math.min(i4, iArr3[0]);
                    int[] iArr4 = this.f2037k;
                    i5 = i2 > 0 ? Math.max(i5, iArr4[1]) : Math.min(i5, iArr4[1]);
                    z = true;
                }
            }
        }
        iArr[0] = i4;
        iArr[1] = i5;
        if (z) {
            mo2096A(1);
        }
    }

    /* renamed from: r */
    public void mo2125r(View view) {
        List f = this.f2033g.mo2188f(view);
        if (f != null && !f.isEmpty()) {
            for (int i = 0; i < f.size(); i++) {
                View view2 = (View) f.get(i);
                Behavior behavior = ((C0427e) view2.getLayoutParams()).f2055a;
                if (behavior != null) {
                    behavior.mo2145g(this, view2, view);
                }
            }
        }
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        Behavior behavior = ((C0427e) view.getLayoutParams()).f2055a;
        if (behavior == null || !behavior.mo2158t(this, view, rect, z)) {
            return super.requestChildRectangleOnScreen(view, rect, z);
        }
        return true;
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        super.requestDisallowInterceptTouchEvent(z);
        if (z && !this.f2039m) {
            m1988E(false);
            this.f2039m = true;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: s */
    public void mo2128s(View view, boolean z, Rect rect) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z) {
            C0431b.m2061a(this, view, rect);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    public void setFitsSystemWindows(boolean z) {
        super.setFitsSystemWindows(z);
        m1991I();
    }

    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f2049w = onHierarchyChangeListener;
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        Drawable drawable = this.f2048v;
        if (drawable != null && drawable.isVisible() != z) {
            this.f2048v.setVisible(z, false);
        }
    }

    /* renamed from: t */
    public List<View> mo2132t(View view) {
        List<View> g = this.f2033g.mo2189g(view);
        this.f2035i.clear();
        if (g != null) {
            this.f2035i.addAll(g);
        }
        return this.f2035i;
    }

    /* renamed from: u */
    public List<View> mo2133u(View view) {
        List f = this.f2033g.mo2188f(view);
        this.f2035i.clear();
        if (f != null) {
            this.f2035i.addAll(f);
        }
        return this.f2035i;
    }

    /* access modifiers changed from: protected */
    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f2048v;
    }

    /* renamed from: x */
    public final C4780v mo2135x() {
        return this.f2046t;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: y */
    public C0427e mo2136y(View view) {
        C0427e eVar = (C0427e) view.getLayoutParams();
        if (!eVar.f2056b) {
            if (view instanceof C0424b) {
                Behavior a = ((C0424b) view).mo2168a();
                if (a == null) {
                    Log.e("CoordinatorLayout", "Attached behavior class is null");
                }
                Behavior behavior = eVar.f2055a;
                if (behavior != a) {
                    if (behavior != null) {
                        behavior.mo2147i();
                    }
                    eVar.f2055a = a;
                    eVar.f2056b = true;
                    if (a != null) {
                        a.mo2144f(eVar);
                    }
                }
            } else {
                C0425c cVar = null;
                for (Class cls = view.getClass(); cls != null; cls = cls.getSuperclass()) {
                    cVar = (C0425c) cls.getAnnotation(C0425c.class);
                    if (cVar != null) {
                        break;
                    }
                }
                if (cVar != null) {
                    try {
                        Behavior behavior2 = (Behavior) cVar.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                        Behavior behavior3 = eVar.f2055a;
                        if (behavior3 != behavior2) {
                            if (behavior3 != null) {
                                behavior3.mo2147i();
                            }
                            eVar.f2055a = behavior2;
                            eVar.f2056b = true;
                            if (behavior2 != null) {
                                behavior2.mo2144f(eVar);
                            }
                        }
                    } catch (Exception e) {
                        StringBuilder P = C4924a.m17863P("Default behavior class ");
                        P.append(cVar.value().getName());
                        P.append(" could not be instantiated. Did you forget a default constructor?");
                        Log.e("CoordinatorLayout", P.toString(), e);
                    }
                }
            }
            eVar.f2056b = true;
        }
        return eVar;
    }

    /* renamed from: z */
    public boolean mo2137z(View view, int i, int i2) {
        Rect d = m1992d();
        C0431b.m2061a(this, view, d);
        try {
            return d.contains(i, i2);
        } finally {
            d.setEmpty();
            f2031e.mo7333b(d);
        }
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof C0427e) {
            return new C0427e((C0427e) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0427e((ViewGroup.MarginLayoutParams) layoutParams) : new C0427e(layoutParams);
    }
}
