package androidx.core.app;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.core.content.C0474a;

/* renamed from: androidx.core.app.a */
public class C0441a extends C0474a {

    /* renamed from: c */
    public static final /* synthetic */ int f2105c = 0;

    /* renamed from: androidx.core.app.a$a */
    class C0442a implements Runnable {

        /* renamed from: a */
        final /* synthetic */ String[] f2106a;

        /* renamed from: b */
        final /* synthetic */ Activity f2107b;

        /* renamed from: c */
        final /* synthetic */ int f2108c;

        C0442a(String[] strArr, Activity activity, int i) {
            this.f2106a = strArr;
            this.f2107b = activity;
            this.f2108c = i;
        }

        public void run() {
            int[] iArr = new int[this.f2106a.length];
            PackageManager packageManager = this.f2107b.getPackageManager();
            String packageName = this.f2107b.getPackageName();
            int length = this.f2106a.length;
            for (int i = 0; i < length; i++) {
                iArr[i] = packageManager.checkPermission(this.f2106a[i], packageName);
            }
            ((C0443b) this.f2107b).onRequestPermissionsResult(this.f2108c, this.f2106a, iArr);
        }
    }

    /* renamed from: androidx.core.app.a$b */
    public interface C0443b {
        void onRequestPermissionsResult(int i, String[] strArr, int[] iArr);
    }

    /* renamed from: androidx.core.app.a$c */
    public interface C0444c {
        /* renamed from: m */
        void mo2219m(int i);
    }

    /* renamed from: d */
    public static void m2079d(Activity activity) {
        if (Build.VERSION.SDK_INT >= 28 || !C0446c.m2084c(activity)) {
            activity.recreate();
        }
    }

    /* renamed from: e */
    public static void m2080e(Activity activity, String[] strArr, int i) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (activity instanceof C0444c) {
                ((C0444c) activity).mo2219m(i);
            }
            activity.requestPermissions(strArr, i);
        } else if (activity instanceof C0443b) {
            new Handler(Looper.getMainLooper()).post(new C0442a(strArr, activity, i));
        }
    }
}
