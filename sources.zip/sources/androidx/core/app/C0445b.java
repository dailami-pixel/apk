package androidx.core.app;

/* renamed from: androidx.core.app.b */
public class C0445b {
}
