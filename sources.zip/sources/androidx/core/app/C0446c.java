package androidx.core.app;

import android.app.Activity;
import android.app.Application;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* renamed from: androidx.core.app.c */
final class C0446c {

    /* renamed from: a */
    protected static final Class<?> f2109a;

    /* renamed from: b */
    protected static final Field f2110b;

    /* renamed from: c */
    protected static final Field f2111c;

    /* renamed from: d */
    protected static final Method f2112d;

    /* renamed from: e */
    protected static final Method f2113e;

    /* renamed from: f */
    protected static final Method f2114f;

    /* renamed from: g */
    private static final Handler f2115g = new Handler(Looper.getMainLooper());

    /* renamed from: androidx.core.app.c$a */
    class C0447a implements Runnable {

        /* renamed from: a */
        final /* synthetic */ C0450d f2116a;

        /* renamed from: b */
        final /* synthetic */ Object f2117b;

        C0447a(C0450d dVar, Object obj) {
            this.f2116a = dVar;
            this.f2117b = obj;
        }

        public void run() {
            this.f2116a.f2122a = this.f2117b;
        }
    }

    /* renamed from: androidx.core.app.c$b */
    class C0448b implements Runnable {

        /* renamed from: a */
        final /* synthetic */ Application f2118a;

        /* renamed from: b */
        final /* synthetic */ C0450d f2119b;

        C0448b(Application application, C0450d dVar) {
            this.f2118a = application;
            this.f2119b = dVar;
        }

        public void run() {
            this.f2118a.unregisterActivityLifecycleCallbacks(this.f2119b);
        }
    }

    /* renamed from: androidx.core.app.c$c */
    class C0449c implements Runnable {

        /* renamed from: a */
        final /* synthetic */ Object f2120a;

        /* renamed from: b */
        final /* synthetic */ Object f2121b;

        C0449c(Object obj, Object obj2) {
            this.f2120a = obj;
            this.f2121b = obj2;
        }

        public void run() {
            try {
                Method method = C0446c.f2112d;
                if (method != null) {
                    method.invoke(this.f2120a, new Object[]{this.f2121b, Boolean.FALSE, "AppCompat recreation"});
                    return;
                }
                C0446c.f2113e.invoke(this.f2120a, new Object[]{this.f2121b, Boolean.FALSE});
            } catch (RuntimeException e) {
                if (e.getClass() == RuntimeException.class && e.getMessage() != null && e.getMessage().startsWith("Unable to stop")) {
                    throw e;
                }
            } catch (Throwable th) {
                Log.e("ActivityRecreator", "Exception while invoking performStopActivity", th);
            }
        }
    }

    /* renamed from: androidx.core.app.c$d */
    private static final class C0450d implements Application.ActivityLifecycleCallbacks {

        /* renamed from: a */
        Object f2122a;

        /* renamed from: b */
        private Activity f2123b;

        /* renamed from: c */
        private boolean f2124c = false;

        /* renamed from: d */
        private boolean f2125d = false;

        /* renamed from: e */
        private boolean f2126e = false;

        C0450d(Activity activity) {
            this.f2123b = activity;
        }

        public void onActivityCreated(Activity activity, Bundle bundle) {
        }

        public void onActivityDestroyed(Activity activity) {
            if (this.f2123b == activity) {
                this.f2123b = null;
                this.f2125d = true;
            }
        }

        public void onActivityPaused(Activity activity) {
            if (this.f2125d && !this.f2126e && !this.f2124c && C0446c.m2083b(this.f2122a, activity)) {
                this.f2126e = true;
                this.f2122a = null;
            }
        }

        public void onActivityResumed(Activity activity) {
        }

        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        }

        public void onActivityStarted(Activity activity) {
            if (this.f2123b == activity) {
                this.f2124c = true;
            }
        }

        public void onActivityStopped(Activity activity) {
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x005d A[SYNTHETIC, Splitter:B:25:0x005d] */
    static {
        /*
            android.os.Handler r0 = new android.os.Handler
            android.os.Looper r1 = android.os.Looper.getMainLooper()
            r0.<init>(r1)
            f2115g = r0
            r0 = 0
            java.lang.String r1 = "android.app.ActivityThread"
            java.lang.Class r1 = java.lang.Class.forName(r1)     // Catch:{ all -> 0x0013 }
            goto L_0x0014
        L_0x0013:
            r1 = r0
        L_0x0014:
            f2109a = r1
            r1 = 1
            java.lang.Class<android.app.Activity> r2 = android.app.Activity.class
            java.lang.String r3 = "mMainThread"
            java.lang.reflect.Field r2 = r2.getDeclaredField(r3)     // Catch:{ all -> 0x0023 }
            r2.setAccessible(r1)     // Catch:{ all -> 0x0023 }
            goto L_0x0024
        L_0x0023:
            r2 = r0
        L_0x0024:
            f2110b = r2
            java.lang.Class<android.app.Activity> r2 = android.app.Activity.class
            java.lang.String r3 = "mToken"
            java.lang.reflect.Field r2 = r2.getDeclaredField(r3)     // Catch:{ all -> 0x0032 }
            r2.setAccessible(r1)     // Catch:{ all -> 0x0032 }
            goto L_0x0033
        L_0x0032:
            r2 = r0
        L_0x0033:
            f2111c = r2
            java.lang.Class<?> r2 = f2109a
            r3 = 3
            java.lang.String r4 = "performStopActivity"
            r5 = 2
            r6 = 0
            if (r2 != 0) goto L_0x0040
        L_0x003e:
            r2 = r0
            goto L_0x0055
        L_0x0040:
            java.lang.Class[] r7 = new java.lang.Class[r3]     // Catch:{ all -> 0x003e }
            java.lang.Class<android.os.IBinder> r8 = android.os.IBinder.class
            r7[r6] = r8     // Catch:{ all -> 0x003e }
            java.lang.Class r8 = java.lang.Boolean.TYPE     // Catch:{ all -> 0x003e }
            r7[r1] = r8     // Catch:{ all -> 0x003e }
            java.lang.Class<java.lang.String> r8 = java.lang.String.class
            r7[r5] = r8     // Catch:{ all -> 0x003e }
            java.lang.reflect.Method r2 = r2.getDeclaredMethod(r4, r7)     // Catch:{ all -> 0x003e }
            r2.setAccessible(r1)     // Catch:{ all -> 0x003e }
        L_0x0055:
            f2112d = r2
            java.lang.Class<?> r2 = f2109a
            if (r2 != 0) goto L_0x005d
        L_0x005b:
            r2 = r0
            goto L_0x006e
        L_0x005d:
            java.lang.Class[] r7 = new java.lang.Class[r5]     // Catch:{ all -> 0x005b }
            java.lang.Class<android.os.IBinder> r8 = android.os.IBinder.class
            r7[r6] = r8     // Catch:{ all -> 0x005b }
            java.lang.Class r8 = java.lang.Boolean.TYPE     // Catch:{ all -> 0x005b }
            r7[r1] = r8     // Catch:{ all -> 0x005b }
            java.lang.reflect.Method r2 = r2.getDeclaredMethod(r4, r7)     // Catch:{ all -> 0x005b }
            r2.setAccessible(r1)     // Catch:{ all -> 0x005b }
        L_0x006e:
            f2113e = r2
            java.lang.Class<?> r2 = f2109a
            boolean r4 = m2082a()
            if (r4 == 0) goto L_0x00af
            if (r2 != 0) goto L_0x007b
            goto L_0x00af
        L_0x007b:
            java.lang.String r4 = "requestRelaunchActivity"
            r7 = 9
            java.lang.Class[] r7 = new java.lang.Class[r7]     // Catch:{ all -> 0x00af }
            java.lang.Class<android.os.IBinder> r8 = android.os.IBinder.class
            r7[r6] = r8     // Catch:{ all -> 0x00af }
            java.lang.Class<java.util.List> r6 = java.util.List.class
            r7[r1] = r6     // Catch:{ all -> 0x00af }
            java.lang.Class<java.util.List> r6 = java.util.List.class
            r7[r5] = r6     // Catch:{ all -> 0x00af }
            java.lang.Class r5 = java.lang.Integer.TYPE     // Catch:{ all -> 0x00af }
            r7[r3] = r5     // Catch:{ all -> 0x00af }
            r3 = 4
            java.lang.Class r5 = java.lang.Boolean.TYPE     // Catch:{ all -> 0x00af }
            r7[r3] = r5     // Catch:{ all -> 0x00af }
            r3 = 5
            java.lang.Class<android.content.res.Configuration> r6 = android.content.res.Configuration.class
            r7[r3] = r6     // Catch:{ all -> 0x00af }
            r3 = 6
            java.lang.Class<android.content.res.Configuration> r6 = android.content.res.Configuration.class
            r7[r3] = r6     // Catch:{ all -> 0x00af }
            r3 = 7
            r7[r3] = r5     // Catch:{ all -> 0x00af }
            r3 = 8
            r7[r3] = r5     // Catch:{ all -> 0x00af }
            java.lang.reflect.Method r2 = r2.getDeclaredMethod(r4, r7)     // Catch:{ all -> 0x00af }
            r2.setAccessible(r1)     // Catch:{ all -> 0x00af }
            r0 = r2
        L_0x00af:
            f2114f = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.app.C0446c.<clinit>():void");
    }

    /* renamed from: a */
    private static boolean m2082a() {
        int i = Build.VERSION.SDK_INT;
        return i == 26 || i == 27;
    }

    /* renamed from: b */
    protected static boolean m2083b(Object obj, Activity activity) {
        try {
            Object obj2 = f2111c.get(activity);
            if (obj2 != obj) {
                return false;
            }
            f2115g.postAtFrontOfQueue(new C0449c(f2110b.get(activity), obj2));
            return true;
        } catch (Throwable th) {
            Log.e("ActivityRecreator", "Exception while fetching field values", th);
            return false;
        }
    }

    /* renamed from: c */
    static boolean m2084c(Activity activity) {
        Object obj;
        Application application;
        C0450d dVar;
        if (Build.VERSION.SDK_INT >= 28) {
            activity.recreate();
            return true;
        } else if (m2082a() && f2114f == null) {
            return false;
        } else {
            if (f2113e == null && f2112d == null) {
                return false;
            }
            try {
                Object obj2 = f2111c.get(activity);
                if (obj2 == null || (obj = f2110b.get(activity)) == null) {
                    return false;
                }
                application = activity.getApplication();
                dVar = new C0450d(activity);
                application.registerActivityLifecycleCallbacks(dVar);
                Handler handler = f2115g;
                handler.post(new C0447a(dVar, obj2));
                if (m2082a()) {
                    Method method = f2114f;
                    Boolean bool = Boolean.FALSE;
                    method.invoke(obj, new Object[]{obj2, null, null, 0, bool, null, null, bool, bool});
                } else {
                    activity.recreate();
                }
                handler.post(new C0448b(application, dVar));
                return true;
            } catch (Throwable unused) {
                return false;
            }
        }
    }
}
