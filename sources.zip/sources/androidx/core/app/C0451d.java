package androidx.core.app;

import android.app.Activity;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.SparseIntArray;
import android.view.FrameMetrics;
import android.view.Window;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;

/* renamed from: androidx.core.app.d */
public class C0451d {

    /* renamed from: a */
    private C0454b f2127a;

    /* renamed from: androidx.core.app.d$a */
    private static class C0452a extends C0454b {

        /* renamed from: a */
        private static HandlerThread f2128a;

        /* renamed from: b */
        private static Handler f2129b;

        /* renamed from: c */
        int f2130c;

        /* renamed from: d */
        SparseIntArray[] f2131d = new SparseIntArray[9];

        /* renamed from: e */
        private ArrayList<WeakReference<Activity>> f2132e = new ArrayList<>();

        /* renamed from: f */
        Window.OnFrameMetricsAvailableListener f2133f = new C0453a();

        /* renamed from: androidx.core.app.d$a$a */
        class C0453a implements Window.OnFrameMetricsAvailableListener {
            C0453a() {
            }

            public void onFrameMetricsAvailable(Window window, FrameMetrics frameMetrics, int i) {
                C0452a aVar = C0452a.this;
                if ((aVar.f2130c & 1) != 0) {
                    aVar.mo2234c(aVar.f2131d[0], frameMetrics.getMetric(8));
                }
                C0452a aVar2 = C0452a.this;
                if ((aVar2.f2130c & 2) != 0) {
                    aVar2.mo2234c(aVar2.f2131d[1], frameMetrics.getMetric(1));
                }
                C0452a aVar3 = C0452a.this;
                if ((aVar3.f2130c & 4) != 0) {
                    aVar3.mo2234c(aVar3.f2131d[2], frameMetrics.getMetric(3));
                }
                C0452a aVar4 = C0452a.this;
                if ((aVar4.f2130c & 8) != 0) {
                    aVar4.mo2234c(aVar4.f2131d[3], frameMetrics.getMetric(4));
                }
                C0452a aVar5 = C0452a.this;
                if ((aVar5.f2130c & 16) != 0) {
                    aVar5.mo2234c(aVar5.f2131d[4], frameMetrics.getMetric(5));
                }
                C0452a aVar6 = C0452a.this;
                if ((aVar6.f2130c & 64) != 0) {
                    aVar6.mo2234c(aVar6.f2131d[6], frameMetrics.getMetric(7));
                }
                C0452a aVar7 = C0452a.this;
                if ((aVar7.f2130c & 32) != 0) {
                    aVar7.mo2234c(aVar7.f2131d[5], frameMetrics.getMetric(6));
                }
                C0452a aVar8 = C0452a.this;
                if ((aVar8.f2130c & 128) != 0) {
                    aVar8.mo2234c(aVar8.f2131d[7], frameMetrics.getMetric(0));
                }
                C0452a aVar9 = C0452a.this;
                if ((aVar9.f2130c & 256) != 0) {
                    aVar9.mo2234c(aVar9.f2131d[8], frameMetrics.getMetric(2));
                }
            }
        }

        C0452a(int i) {
            this.f2130c = i;
        }

        /* renamed from: a */
        public void mo2232a(Activity activity) {
            if (f2128a == null) {
                HandlerThread handlerThread = new HandlerThread("FrameMetricsAggregator");
                f2128a = handlerThread;
                handlerThread.start();
                f2129b = new Handler(f2128a.getLooper());
            }
            for (int i = 0; i <= 8; i++) {
                SparseIntArray[] sparseIntArrayArr = this.f2131d;
                if (sparseIntArrayArr[i] == null && (this.f2130c & (1 << i)) != 0) {
                    sparseIntArrayArr[i] = new SparseIntArray();
                }
            }
            activity.getWindow().addOnFrameMetricsAvailableListener(this.f2133f, f2129b);
            this.f2132e.add(new WeakReference(activity));
        }

        /* renamed from: b */
        public SparseIntArray[] mo2233b(Activity activity) {
            Iterator<WeakReference<Activity>> it = this.f2132e.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                WeakReference next = it.next();
                if (next.get() == activity) {
                    this.f2132e.remove(next);
                    break;
                }
            }
            activity.getWindow().removeOnFrameMetricsAvailableListener(this.f2133f);
            return this.f2131d;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: c */
        public void mo2234c(SparseIntArray sparseIntArray, long j) {
            if (sparseIntArray != null) {
                int i = (int) ((500000 + j) / 1000000);
                if (j >= 0) {
                    sparseIntArray.put(i, sparseIntArray.get(i) + 1);
                }
            }
        }
    }

    /* renamed from: androidx.core.app.d$b */
    private static class C0454b {
        C0454b() {
        }

        /* renamed from: a */
        public void mo2232a(Activity activity) {
        }

        /* renamed from: b */
        public SparseIntArray[] mo2233b(Activity activity) {
            return null;
        }
    }

    public C0451d() {
        this.f2127a = Build.VERSION.SDK_INT >= 24 ? new C0452a(1) : new C0454b();
    }

    /* renamed from: a */
    public void mo2230a(Activity activity) {
        this.f2127a.mo2232a(activity);
    }

    /* renamed from: b */
    public SparseIntArray[] mo2231b(Activity activity) {
        return this.f2127a.mo2233b(activity);
    }
}
