package androidx.core.app;

import android.app.Notification;

/* renamed from: androidx.core.app.e */
public interface C0455e {
    /* renamed from: a */
    Notification.Builder mo2236a();
}
