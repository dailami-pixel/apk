package androidx.core.app;

import android.app.PendingIntent;
import android.content.res.Resources;
import android.os.Bundle;
import androidx.core.graphics.drawable.IconCompat;
import com.appsflyer.oaid.BuildConfig;

/* renamed from: androidx.core.app.f */
public class C0456f {

    /* renamed from: a */
    final Bundle f2135a;

    /* renamed from: b */
    private IconCompat f2136b;

    /* renamed from: c */
    private final C0469n[] f2137c;

    /* renamed from: d */
    private final C0469n[] f2138d;

    /* renamed from: e */
    private boolean f2139e;

    /* renamed from: f */
    boolean f2140f;

    /* renamed from: g */
    private final int f2141g;

    /* renamed from: h */
    private final boolean f2142h;
    @Deprecated

    /* renamed from: i */
    public int f2143i;

    /* renamed from: j */
    public CharSequence f2144j;

    /* renamed from: k */
    public PendingIntent f2145k;

    public C0456f(int i, CharSequence charSequence, PendingIntent pendingIntent) {
        IconCompat b = i == 0 ? null : IconCompat.m2212b((Resources) null, BuildConfig.FLAVOR, i);
        Bundle bundle = new Bundle();
        this.f2140f = true;
        this.f2136b = b;
        if (b != null && b.mo2323e() == 2) {
            this.f2143i = b.mo2321c();
        }
        this.f2144j = C0459i.m2103b(charSequence);
        this.f2145k = pendingIntent;
        this.f2135a = bundle;
        this.f2137c = null;
        this.f2138d = null;
        this.f2139e = true;
        this.f2141g = 0;
        this.f2140f = true;
        this.f2142h = false;
    }

    /* renamed from: a */
    public boolean mo2237a() {
        return this.f2139e;
    }

    /* renamed from: b */
    public IconCompat mo2238b() {
        int i;
        if (this.f2136b == null && (i = this.f2143i) != 0) {
            this.f2136b = IconCompat.m2212b((Resources) null, BuildConfig.FLAVOR, i);
        }
        return this.f2136b;
    }

    /* renamed from: c */
    public C0469n[] mo2239c() {
        return this.f2137c;
    }

    /* renamed from: d */
    public int mo2240d() {
        return this.f2141g;
    }

    /* renamed from: e */
    public boolean mo2241e() {
        return this.f2142h;
    }
}
