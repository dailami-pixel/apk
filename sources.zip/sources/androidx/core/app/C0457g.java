package androidx.core.app;

import android.app.Notification;
import android.graphics.Bitmap;

/* renamed from: androidx.core.app.g */
public class C0457g extends C0460j {

    /* renamed from: b */
    private Bitmap f2146b;

    /* renamed from: c */
    private Bitmap f2147c;

    /* renamed from: d */
    private boolean f2148d;

    /* renamed from: a */
    public void mo2242a(C0455e eVar) {
        Notification.BigPictureStyle bigPicture = new Notification.BigPictureStyle(((C0461k) eVar).mo2236a()).setBigContentTitle((CharSequence) null).bigPicture(this.f2146b);
        if (this.f2148d) {
            bigPicture.bigLargeIcon(this.f2147c);
        }
    }

    /* renamed from: e */
    public C0457g mo2243e(Bitmap bitmap) {
        this.f2147c = null;
        this.f2148d = true;
        return this;
    }

    /* renamed from: f */
    public C0457g mo2244f(Bitmap bitmap) {
        this.f2146b = bitmap;
        return this;
    }
}
