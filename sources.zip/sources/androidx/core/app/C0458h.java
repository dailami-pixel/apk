package androidx.core.app;

import android.app.Notification;

/* renamed from: androidx.core.app.h */
public class C0458h extends C0460j {

    /* renamed from: b */
    private CharSequence f2149b;

    /* renamed from: a */
    public void mo2242a(C0455e eVar) {
        new Notification.BigTextStyle(((C0461k) eVar).mo2236a()).setBigContentTitle((CharSequence) null).bigText(this.f2149b);
    }

    /* renamed from: e */
    public C0458h mo2245e(CharSequence charSequence) {
        this.f2149b = C0459i.m2103b(charSequence);
        return this;
    }
}
