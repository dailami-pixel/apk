package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import com.vidio.android.p195tv.R;
import java.util.ArrayList;

/* renamed from: androidx.core.app.i */
public class C0459i {
    @Deprecated

    /* renamed from: A */
    public ArrayList<String> f2150A;

    /* renamed from: a */
    public Context f2151a;

    /* renamed from: b */
    public ArrayList<C0456f> f2152b = new ArrayList<>();

    /* renamed from: c */
    ArrayList<C0456f> f2153c = new ArrayList<>();

    /* renamed from: d */
    CharSequence f2154d;

    /* renamed from: e */
    CharSequence f2155e;

    /* renamed from: f */
    PendingIntent f2156f;

    /* renamed from: g */
    Bitmap f2157g;

    /* renamed from: h */
    int f2158h;

    /* renamed from: i */
    int f2159i;

    /* renamed from: j */
    boolean f2160j = true;

    /* renamed from: k */
    boolean f2161k;

    /* renamed from: l */
    C0460j f2162l;

    /* renamed from: m */
    CharSequence f2163m;

    /* renamed from: n */
    int f2164n;

    /* renamed from: o */
    int f2165o;

    /* renamed from: p */
    boolean f2166p;

    /* renamed from: q */
    boolean f2167q = false;

    /* renamed from: r */
    boolean f2168r;

    /* renamed from: s */
    boolean f2169s;

    /* renamed from: t */
    Bundle f2170t;

    /* renamed from: u */
    int f2171u = 0;

    /* renamed from: v */
    int f2172v = 0;

    /* renamed from: w */
    String f2173w;

    /* renamed from: x */
    int f2174x = 0;

    /* renamed from: y */
    boolean f2175y;

    /* renamed from: z */
    Notification f2176z;

    public C0459i(Context context, String str) {
        Notification notification = new Notification();
        this.f2176z = notification;
        this.f2151a = context;
        this.f2173w = str;
        notification.when = System.currentTimeMillis();
        this.f2176z.audioStreamType = -1;
        this.f2159i = 0;
        this.f2150A = new ArrayList<>();
        this.f2175y = true;
    }

    /* renamed from: b */
    protected static CharSequence m2103b(CharSequence charSequence) {
        return (charSequence != null && charSequence.length() > 5120) ? charSequence.subSequence(0, 5120) : charSequence;
    }

    /* renamed from: m */
    private void m2104m(int i, boolean z) {
        Notification notification;
        int i2;
        if (z) {
            notification = this.f2176z;
            i2 = i | notification.flags;
        } else {
            notification = this.f2176z;
            i2 = (~i) & notification.flags;
        }
        notification.flags = i2;
    }

    /* renamed from: A */
    public C0459i mo2246A(boolean z) {
        this.f2161k = z;
        return this;
    }

    /* renamed from: B */
    public C0459i mo2247B(long[] jArr) {
        this.f2176z.vibrate = jArr;
        return this;
    }

    /* renamed from: C */
    public C0459i mo2248C(int i) {
        this.f2172v = i;
        return this;
    }

    /* renamed from: D */
    public C0459i mo2249D(long j) {
        this.f2176z.when = j;
        return this;
    }

    /* renamed from: a */
    public Notification mo2250a() {
        return new C0461k(this).mo2277b();
    }

    /* renamed from: c */
    public C0459i mo2251c(boolean z) {
        m2104m(16, z);
        return this;
    }

    /* renamed from: d */
    public C0459i mo2252d(int i) {
        this.f2174x = i;
        return this;
    }

    /* renamed from: e */
    public C0459i mo2253e(String str) {
        this.f2173w = str;
        return this;
    }

    /* renamed from: f */
    public C0459i mo2254f(int i) {
        this.f2171u = i;
        return this;
    }

    /* renamed from: g */
    public C0459i mo2255g(boolean z) {
        this.f2168r = z;
        this.f2169s = true;
        return this;
    }

    /* renamed from: h */
    public C0459i mo2256h(PendingIntent pendingIntent) {
        this.f2156f = pendingIntent;
        return this;
    }

    /* renamed from: i */
    public C0459i mo2257i(CharSequence charSequence) {
        this.f2155e = m2103b(charSequence);
        return this;
    }

    /* renamed from: j */
    public C0459i mo2258j(CharSequence charSequence) {
        this.f2154d = m2103b(charSequence);
        return this;
    }

    /* renamed from: k */
    public C0459i mo2259k(int i) {
        Notification notification = this.f2176z;
        notification.defaults = i;
        if ((i & 4) != 0) {
            notification.flags |= 1;
        }
        return this;
    }

    /* renamed from: l */
    public C0459i mo2260l(PendingIntent pendingIntent) {
        this.f2176z.deleteIntent = pendingIntent;
        return this;
    }

    /* renamed from: n */
    public C0459i mo2261n(Bitmap bitmap) {
        if (bitmap != null && Build.VERSION.SDK_INT < 27) {
            Resources resources = this.f2151a.getResources();
            int dimensionPixelSize = resources.getDimensionPixelSize(R.dimen.compat_notification_large_icon_max_width);
            int dimensionPixelSize2 = resources.getDimensionPixelSize(R.dimen.compat_notification_large_icon_max_height);
            if (bitmap.getWidth() > dimensionPixelSize || bitmap.getHeight() > dimensionPixelSize2) {
                double min = Math.min(((double) dimensionPixelSize) / ((double) Math.max(1, bitmap.getWidth())), ((double) dimensionPixelSize2) / ((double) Math.max(1, bitmap.getHeight())));
                bitmap = Bitmap.createScaledBitmap(bitmap, (int) Math.ceil(((double) bitmap.getWidth()) * min), (int) Math.ceil(((double) bitmap.getHeight()) * min), true);
            }
        }
        this.f2157g = bitmap;
        return this;
    }

    /* renamed from: o */
    public C0459i mo2262o(int i, int i2, int i3) {
        Notification notification = this.f2176z;
        notification.ledARGB = i;
        notification.ledOnMS = i2;
        notification.ledOffMS = i3;
        notification.flags = ((i2 == 0 || i3 == 0) ? 0 : 1) | (notification.flags & -2);
        return this;
    }

    /* renamed from: p */
    public C0459i mo2263p(boolean z) {
        this.f2167q = z;
        return this;
    }

    /* renamed from: q */
    public C0459i mo2264q(int i) {
        this.f2158h = i;
        return this;
    }

    /* renamed from: r */
    public C0459i mo2265r(boolean z) {
        m2104m(2, z);
        return this;
    }

    /* renamed from: s */
    public C0459i mo2266s(int i) {
        this.f2159i = i;
        return this;
    }

    /* renamed from: t */
    public C0459i mo2267t(int i, int i2, boolean z) {
        this.f2164n = i;
        this.f2165o = i2;
        this.f2166p = z;
        return this;
    }

    /* renamed from: u */
    public C0459i mo2268u(boolean z) {
        this.f2160j = z;
        return this;
    }

    /* renamed from: v */
    public C0459i mo2269v(int i) {
        this.f2176z.icon = i;
        return this;
    }

    /* renamed from: w */
    public C0459i mo2270w(Uri uri) {
        Notification notification = this.f2176z;
        notification.sound = uri;
        notification.audioStreamType = -1;
        notification.audioAttributes = new AudioAttributes.Builder().setContentType(4).setUsage(5).build();
        return this;
    }

    /* renamed from: x */
    public C0459i mo2271x(C0460j jVar) {
        if (this.f2162l != jVar) {
            this.f2162l = jVar;
            if (jVar != null) {
                jVar.mo2276d(this);
            }
        }
        return this;
    }

    /* renamed from: y */
    public C0459i mo2272y(CharSequence charSequence) {
        this.f2163m = m2103b(charSequence);
        return this;
    }

    /* renamed from: z */
    public C0459i mo2273z(CharSequence charSequence) {
        this.f2176z.tickerText = m2103b(charSequence);
        return this;
    }
}
