package androidx.core.app;

import android.widget.RemoteViews;

/* renamed from: androidx.core.app.j */
public abstract class C0460j {

    /* renamed from: a */
    protected C0459i f2177a;

    /* renamed from: a */
    public abstract void mo2242a(C0455e eVar);

    /* renamed from: b */
    public RemoteViews mo2274b(C0455e eVar) {
        return null;
    }

    /* renamed from: c */
    public RemoteViews mo2275c(C0455e eVar) {
        return null;
    }

    /* renamed from: d */
    public void mo2276d(C0459i iVar) {
        if (this.f2177a != iVar) {
            this.f2177a = iVar;
            if (iVar.f2162l != this) {
                iVar.f2162l = this;
                mo2276d(iVar);
            }
        }
    }
}
