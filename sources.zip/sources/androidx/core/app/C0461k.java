package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

/* renamed from: androidx.core.app.k */
class C0461k implements C0455e {

    /* renamed from: a */
    private final Notification.Builder f2178a;

    /* renamed from: b */
    private final C0459i f2179b;

    /* renamed from: c */
    private final List<Bundle> f2180c = new ArrayList();

    /* renamed from: d */
    private final Bundle f2181d = new Bundle();

    C0461k(C0459i iVar) {
        Notification.Action.Builder builder;
        RemoteInput[] remoteInputArr;
        this.f2179b = iVar;
        Notification.Builder builder2 = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(iVar.f2151a, iVar.f2173w) : new Notification.Builder(iVar.f2151a);
        this.f2178a = builder2;
        Notification notification = iVar.f2176z;
        builder2.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, (RemoteViews) null).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(iVar.f2154d).setContentText(iVar.f2155e).setContentInfo((CharSequence) null).setContentIntent(iVar.f2156f).setDeleteIntent(notification.deleteIntent).setFullScreenIntent((PendingIntent) null, (notification.flags & 128) == 0 ? false : true).setLargeIcon(iVar.f2157g).setNumber(iVar.f2158h).setProgress(iVar.f2164n, iVar.f2165o, iVar.f2166p);
        builder2.setSubText(iVar.f2163m).setUsesChronometer(iVar.f2161k).setPriority(iVar.f2159i);
        Iterator<C0456f> it = iVar.f2152b.iterator();
        while (it.hasNext()) {
            C0456f next = it.next();
            int i = Build.VERSION.SDK_INT;
            IconCompat b = next.mo2238b();
            if (i >= 23) {
                builder = new Notification.Action.Builder(b != null ? b.mo2325h((Context) null) : null, next.f2144j, next.f2145k);
            } else {
                builder = new Notification.Action.Builder(b != null ? b.mo2321c() : 0, next.f2144j, next.f2145k);
            }
            if (next.mo2239c() != null) {
                C0469n[] c = next.mo2239c();
                if (c == null) {
                    remoteInputArr = null;
                } else {
                    remoteInputArr = new RemoteInput[c.length];
                    if (c.length > 0) {
                        C0469n nVar = c[0];
                        throw null;
                    }
                }
                for (RemoteInput addRemoteInput : remoteInputArr) {
                    builder.addRemoteInput(addRemoteInput);
                }
            }
            Bundle bundle = next.f2135a != null ? new Bundle(next.f2135a) : new Bundle();
            bundle.putBoolean("android.support.allowGeneratedReplies", next.mo2237a());
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 24) {
                builder.setAllowGeneratedReplies(next.mo2237a());
            }
            bundle.putInt("android.support.action.semanticAction", next.mo2240d());
            if (i2 >= 28) {
                builder.setSemanticAction(next.mo2240d());
            }
            if (i2 >= 29) {
                builder.setContextual(next.mo2241e());
            }
            bundle.putBoolean("android.support.action.showsUserInterface", next.f2140f);
            builder.addExtras(bundle);
            this.f2178a.addAction(builder.build());
        }
        Bundle bundle2 = iVar.f2170t;
        if (bundle2 != null) {
            this.f2181d.putAll(bundle2);
        }
        this.f2178a.setShowWhen(iVar.f2160j);
        this.f2178a.setLocalOnly(iVar.f2167q).setGroup((String) null).setGroupSummary(false).setSortKey((String) null);
        this.f2178a.setCategory((String) null).setColor(iVar.f2171u).setVisibility(iVar.f2172v).setPublicVersion((Notification) null).setSound(notification.sound, notification.audioAttributes);
        Iterator<String> it2 = iVar.f2150A.iterator();
        while (it2.hasNext()) {
            this.f2178a.addPerson(it2.next());
        }
        if (iVar.f2153c.size() > 0) {
            if (iVar.f2170t == null) {
                iVar.f2170t = new Bundle();
            }
            Bundle bundle3 = iVar.f2170t.getBundle("android.car.EXTENSIONS");
            bundle3 = bundle3 == null ? new Bundle() : bundle3;
            Bundle bundle4 = new Bundle();
            for (int i3 = 0; i3 < iVar.f2153c.size(); i3++) {
                bundle4.putBundle(Integer.toString(i3), C0462l.m2139a(iVar.f2153c.get(i3)));
            }
            bundle3.putBundle("invisible_actions", bundle4);
            if (iVar.f2170t == null) {
                iVar.f2170t = new Bundle();
            }
            iVar.f2170t.putBundle("android.car.EXTENSIONS", bundle3);
            this.f2181d.putBundle("android.car.EXTENSIONS", bundle3);
        }
        int i4 = Build.VERSION.SDK_INT;
        if (i4 >= 24) {
            this.f2178a.setExtras(iVar.f2170t).setRemoteInputHistory((CharSequence[]) null);
        }
        if (i4 >= 26) {
            this.f2178a.setBadgeIconType(iVar.f2174x).setShortcutId((String) null).setTimeoutAfter(0).setGroupAlertBehavior(0);
            if (iVar.f2169s) {
                this.f2178a.setColorized(iVar.f2168r);
            }
            if (!TextUtils.isEmpty(iVar.f2173w)) {
                this.f2178a.setSound((Uri) null).setDefaults(0).setLights(0, 0, 0).setVibrate((long[]) null);
            }
        }
        if (i4 >= 29) {
            this.f2178a.setAllowSystemGeneratedContextualActions(iVar.f2175y);
            this.f2178a.setBubbleMetadata((Notification.BubbleMetadata) null);
        }
    }

    /* renamed from: a */
    public Notification.Builder mo2236a() {
        return this.f2178a;
    }

    /* renamed from: b */
    public Notification mo2277b() {
        RemoteViews b;
        C0460j jVar = this.f2179b.f2162l;
        if (jVar != null) {
            jVar.mo2242a(this);
        }
        RemoteViews c = jVar != null ? jVar.mo2275c(this) : null;
        int i = Build.VERSION.SDK_INT;
        if (i < 26 && i < 24) {
            this.f2178a.setExtras(this.f2181d);
        }
        Notification build = this.f2178a.build();
        if (c != null) {
            build.contentView = c;
        } else {
            Objects.requireNonNull(this.f2179b);
        }
        if (!(jVar == null || (b = jVar.mo2274b(this)) == null)) {
            build.bigContentView = b;
        }
        if (jVar != null) {
            Objects.requireNonNull(this.f2179b.f2162l);
        }
        if (jVar != null) {
            Bundle bundle = build.extras;
        }
        return build;
    }
}
