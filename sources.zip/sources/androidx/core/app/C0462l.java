package androidx.core.app;

import android.os.Bundle;
import androidx.core.graphics.drawable.IconCompat;

/* renamed from: androidx.core.app.l */
class C0462l {

    /* renamed from: a */
    private static final Object f2182a = new Object();

    /* renamed from: a */
    static Bundle m2139a(C0456f fVar) {
        Bundle bundle = new Bundle();
        IconCompat b = fVar.mo2238b();
        bundle.putInt("icon", b != null ? b.mo2321c() : 0);
        bundle.putCharSequence("title", fVar.f2144j);
        bundle.putParcelable("actionIntent", fVar.f2145k);
        Bundle bundle2 = fVar.f2135a != null ? new Bundle(fVar.f2135a) : new Bundle();
        bundle2.putBoolean("android.support.allowGeneratedReplies", fVar.mo2237a());
        bundle.putBundle("extras", bundle2);
        bundle.putParcelableArray("remoteInputs", m2140b(fVar.mo2239c()));
        bundle.putBoolean("showsUserInterface", fVar.f2140f);
        bundle.putInt("semanticAction", fVar.mo2240d());
        return bundle;
    }

    /* renamed from: b */
    private static Bundle[] m2140b(C0469n[] nVarArr) {
        if (nVarArr == null) {
            return null;
        }
        Bundle[] bundleArr = new Bundle[nVarArr.length];
        if (nVarArr.length <= 0) {
            return bundleArr;
        }
        C0469n nVar = nVarArr[0];
        new Bundle();
        throw null;
    }
}
