package androidx.core.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.provider.Settings;
import android.support.p001v4.app.C0001a;
import android.util.Log;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.core.app.m */
public final class C0463m {

    /* renamed from: a */
    private static final Object f2183a = new Object();

    /* renamed from: b */
    private static String f2184b;

    /* renamed from: c */
    private static Set<String> f2185c = new HashSet();

    /* renamed from: d */
    private static final Object f2186d = new Object();

    /* renamed from: e */
    private static C0466c f2187e;

    /* renamed from: f */
    private final Context f2188f;

    /* renamed from: g */
    private final NotificationManager f2189g;

    /* renamed from: androidx.core.app.m$a */
    private static class C0464a implements C0468d {

        /* renamed from: a */
        final String f2190a;

        /* renamed from: b */
        final int f2191b;

        /* renamed from: c */
        final String f2192c;

        /* renamed from: d */
        final Notification f2193d;

        C0464a(String str, int i, String str2, Notification notification) {
            this.f2190a = str;
            this.f2191b = i;
            this.f2192c = str2;
            this.f2193d = notification;
        }

        /* renamed from: a */
        public void mo2280a(C0001a aVar) throws RemoteException {
            aVar.mo1H0(this.f2190a, this.f2191b, this.f2192c, this.f2193d);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder("NotifyTask[");
            sb.append("packageName:");
            sb.append(this.f2190a);
            sb.append(", id:");
            sb.append(this.f2191b);
            sb.append(", tag:");
            return C4924a.m17852E(sb, this.f2192c, "]");
        }
    }

    /* renamed from: androidx.core.app.m$b */
    private static class C0465b {

        /* renamed from: a */
        final ComponentName f2194a;

        /* renamed from: b */
        final IBinder f2195b;

        C0465b(ComponentName componentName, IBinder iBinder) {
            this.f2194a = componentName;
            this.f2195b = iBinder;
        }
    }

    /* renamed from: androidx.core.app.m$c */
    private static class C0466c implements Handler.Callback, ServiceConnection {

        /* renamed from: a */
        private final Context f2196a;

        /* renamed from: b */
        private final HandlerThread f2197b;

        /* renamed from: c */
        private final Handler f2198c;

        /* renamed from: d */
        private final Map<ComponentName, C0467a> f2199d = new HashMap();

        /* renamed from: e */
        private Set<String> f2200e = new HashSet();

        /* renamed from: androidx.core.app.m$c$a */
        private static class C0467a {

            /* renamed from: a */
            final ComponentName f2201a;

            /* renamed from: b */
            boolean f2202b = false;

            /* renamed from: c */
            C0001a f2203c;

            /* renamed from: d */
            ArrayDeque<C0468d> f2204d = new ArrayDeque<>();

            /* renamed from: e */
            int f2205e = 0;

            C0467a(ComponentName componentName) {
                this.f2201a = componentName;
            }
        }

        C0466c(Context context) {
            this.f2196a = context;
            HandlerThread handlerThread = new HandlerThread("NotificationManagerCompat");
            this.f2197b = handlerThread;
            handlerThread.start();
            this.f2198c = new Handler(handlerThread.getLooper(), this);
        }

        /* renamed from: a */
        private void m2147a(C0467a aVar) {
            boolean z;
            if (Log.isLoggable("NotifManCompat", 3)) {
                StringBuilder P = C4924a.m17863P("Processing component ");
                P.append(aVar.f2201a);
                P.append(", ");
                P.append(aVar.f2204d.size());
                P.append(" queued tasks");
                Log.d("NotifManCompat", P.toString());
            }
            if (!aVar.f2204d.isEmpty()) {
                if (aVar.f2202b) {
                    z = true;
                } else {
                    boolean bindService = this.f2196a.bindService(new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL").setComponent(aVar.f2201a), this, 33);
                    aVar.f2202b = bindService;
                    if (bindService) {
                        aVar.f2205e = 0;
                    } else {
                        StringBuilder P2 = C4924a.m17863P("Unable to bind to listener ");
                        P2.append(aVar.f2201a);
                        Log.w("NotifManCompat", P2.toString());
                        this.f2196a.unbindService(this);
                    }
                    z = aVar.f2202b;
                }
                if (!z || aVar.f2203c == null) {
                    m2148c(aVar);
                    return;
                }
                while (true) {
                    C0468d peek = aVar.f2204d.peek();
                    if (peek == null) {
                        break;
                    }
                    try {
                        if (Log.isLoggable("NotifManCompat", 3)) {
                            Log.d("NotifManCompat", "Sending task " + peek);
                        }
                        peek.mo2280a(aVar.f2203c);
                        aVar.f2204d.remove();
                    } catch (DeadObjectException unused) {
                        if (Log.isLoggable("NotifManCompat", 3)) {
                            StringBuilder P3 = C4924a.m17863P("Remote service has died: ");
                            P3.append(aVar.f2201a);
                            Log.d("NotifManCompat", P3.toString());
                        }
                    } catch (RemoteException e) {
                        StringBuilder P4 = C4924a.m17863P("RemoteException communicating with ");
                        P4.append(aVar.f2201a);
                        Log.w("NotifManCompat", P4.toString(), e);
                    }
                }
                if (!aVar.f2204d.isEmpty()) {
                    m2148c(aVar);
                }
            }
        }

        /* renamed from: c */
        private void m2148c(C0467a aVar) {
            if (!this.f2198c.hasMessages(3, aVar.f2201a)) {
                int i = aVar.f2205e + 1;
                aVar.f2205e = i;
                if (i > 6) {
                    StringBuilder P = C4924a.m17863P("Giving up on delivering ");
                    P.append(aVar.f2204d.size());
                    P.append(" tasks to ");
                    P.append(aVar.f2201a);
                    P.append(" after ");
                    P.append(aVar.f2205e);
                    P.append(" retries");
                    Log.w("NotifManCompat", P.toString());
                    aVar.f2204d.clear();
                    return;
                }
                int i2 = (1 << (i - 1)) * 1000;
                if (Log.isLoggable("NotifManCompat", 3)) {
                    Log.d("NotifManCompat", "Scheduling retry for " + i2 + " ms");
                }
                this.f2198c.sendMessageDelayed(this.f2198c.obtainMessage(3, aVar.f2201a), (long) i2);
            }
        }

        /* renamed from: b */
        public void mo2282b(C0468d dVar) {
            this.f2198c.obtainMessage(0, dVar).sendToTarget();
        }

        public boolean handleMessage(Message message) {
            int i = message.what;
            if (i == 0) {
                C0468d dVar = (C0468d) message.obj;
                Set<String> c = C0463m.m2142c(this.f2196a);
                if (!c.equals(this.f2200e)) {
                    this.f2200e = c;
                    List<ResolveInfo> queryIntentServices = this.f2196a.getPackageManager().queryIntentServices(new Intent().setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 0);
                    HashSet hashSet = new HashSet();
                    for (ResolveInfo next : queryIntentServices) {
                        if (c.contains(next.serviceInfo.packageName)) {
                            ServiceInfo serviceInfo = next.serviceInfo;
                            ComponentName componentName = new ComponentName(serviceInfo.packageName, serviceInfo.name);
                            if (next.serviceInfo.permission != null) {
                                Log.w("NotifManCompat", "Permission present on component " + componentName + ", not adding listener record.");
                            } else {
                                hashSet.add(componentName);
                            }
                        }
                    }
                    Iterator it = hashSet.iterator();
                    while (it.hasNext()) {
                        ComponentName componentName2 = (ComponentName) it.next();
                        if (!this.f2199d.containsKey(componentName2)) {
                            if (Log.isLoggable("NotifManCompat", 3)) {
                                Log.d("NotifManCompat", "Adding listener record for " + componentName2);
                            }
                            this.f2199d.put(componentName2, new C0467a(componentName2));
                        }
                    }
                    Iterator<Map.Entry<ComponentName, C0467a>> it2 = this.f2199d.entrySet().iterator();
                    while (it2.hasNext()) {
                        Map.Entry next2 = it2.next();
                        if (!hashSet.contains(next2.getKey())) {
                            if (Log.isLoggable("NotifManCompat", 3)) {
                                StringBuilder P = C4924a.m17863P("Removing listener record for ");
                                P.append(next2.getKey());
                                Log.d("NotifManCompat", P.toString());
                            }
                            C0467a aVar = (C0467a) next2.getValue();
                            if (aVar.f2202b) {
                                this.f2196a.unbindService(this);
                                aVar.f2202b = false;
                            }
                            aVar.f2203c = null;
                            it2.remove();
                        }
                    }
                }
                for (C0467a next3 : this.f2199d.values()) {
                    next3.f2204d.add(dVar);
                    m2147a(next3);
                }
                return true;
            } else if (i == 1) {
                C0465b bVar = (C0465b) message.obj;
                ComponentName componentName3 = bVar.f2194a;
                IBinder iBinder = bVar.f2195b;
                C0467a aVar2 = this.f2199d.get(componentName3);
                if (aVar2 != null) {
                    aVar2.f2203c = C0001a.C0002a.m3O0(iBinder);
                    aVar2.f2205e = 0;
                    m2147a(aVar2);
                }
                return true;
            } else if (i == 2) {
                C0467a aVar3 = this.f2199d.get((ComponentName) message.obj);
                if (aVar3 != null) {
                    if (aVar3.f2202b) {
                        this.f2196a.unbindService(this);
                        aVar3.f2202b = false;
                    }
                    aVar3.f2203c = null;
                }
                return true;
            } else if (i != 3) {
                return false;
            } else {
                C0467a aVar4 = this.f2199d.get((ComponentName) message.obj);
                if (aVar4 != null) {
                    m2147a(aVar4);
                }
                return true;
            }
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            if (Log.isLoggable("NotifManCompat", 3)) {
                Log.d("NotifManCompat", "Connected to service " + componentName);
            }
            this.f2198c.obtainMessage(1, new C0465b(componentName, iBinder)).sendToTarget();
        }

        public void onServiceDisconnected(ComponentName componentName) {
            if (Log.isLoggable("NotifManCompat", 3)) {
                Log.d("NotifManCompat", "Disconnected from service " + componentName);
            }
            this.f2198c.obtainMessage(2, componentName).sendToTarget();
        }
    }

    /* renamed from: androidx.core.app.m$d */
    private interface C0468d {
        /* renamed from: a */
        void mo2280a(C0001a aVar) throws RemoteException;
    }

    private C0463m(Context context) {
        this.f2188f = context;
        this.f2189g = (NotificationManager) context.getSystemService("notification");
    }

    /* renamed from: b */
    public static C0463m m2141b(Context context) {
        return new C0463m(context);
    }

    /* renamed from: c */
    public static Set<String> m2142c(Context context) {
        Set<String> set;
        String string = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
        synchronized (f2183a) {
            if (string != null) {
                if (!string.equals(f2184b)) {
                    String[] split = string.split(":", -1);
                    HashSet hashSet = new HashSet(split.length);
                    for (String unflattenFromString : split) {
                        ComponentName unflattenFromString2 = ComponentName.unflattenFromString(unflattenFromString);
                        if (unflattenFromString2 != null) {
                            hashSet.add(unflattenFromString2.getPackageName());
                        }
                    }
                    f2185c = hashSet;
                    f2184b = string;
                }
            }
            set = f2185c;
        }
        return set;
    }

    /* renamed from: e */
    private void m2143e(C0468d dVar) {
        synchronized (f2186d) {
            if (f2187e == null) {
                f2187e = new C0466c(this.f2188f.getApplicationContext());
            }
            f2187e.mo2282b(dVar);
        }
    }

    /* renamed from: a */
    public void mo2278a(int i) {
        this.f2189g.cancel((String) null, i);
    }

    /* renamed from: d */
    public void mo2279d(int i, Notification notification) {
        Bundle bundle = notification.extras;
        if (bundle != null && bundle.getBoolean("android.support.useSideChannel")) {
            m2143e(new C0464a(this.f2188f.getPackageName(), i, (String) null, notification));
            this.f2189g.cancel((String) null, i);
            return;
        }
        this.f2189g.notify((String) null, i, notification);
    }
}
