package androidx.core.app;

/* renamed from: androidx.core.app.n */
public final class C0469n {
}
