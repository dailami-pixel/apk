package androidx.core.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import androidx.core.content.C0474a;
import java.util.ArrayList;
import java.util.Iterator;
import p098d.p120g.C4690a;

/* renamed from: androidx.core.app.o */
public final class C0470o implements Iterable<Intent> {

    /* renamed from: a */
    private final ArrayList<Intent> f2206a = new ArrayList<>();

    /* renamed from: b */
    private final Context f2207b;

    /* renamed from: androidx.core.app.o$a */
    public interface C0471a {
        /* renamed from: M */
        Intent mo431M();
    }

    private C0470o(Context context) {
        this.f2207b = context;
    }

    /* renamed from: c */
    public static C0470o m2151c(Context context) {
        return new C0470o(context);
    }

    /* renamed from: a */
    public C0470o mo2286a(Intent intent) {
        this.f2206a.add(intent);
        return this;
    }

    /* renamed from: b */
    public C0470o mo2287b(Activity activity) {
        Intent M = ((C0471a) activity).mo431M();
        if (M == null) {
            M = C4690a.m17116g(activity);
        }
        if (M != null) {
            ComponentName component = M.getComponent();
            if (component == null) {
                component = M.resolveActivity(this.f2207b.getPackageManager());
            }
            int size = this.f2206a.size();
            try {
                Context context = this.f2207b;
                while (true) {
                    Intent h = C4690a.m17117h(context, component);
                    if (h == null) {
                        break;
                    }
                    this.f2206a.add(size, h);
                    context = this.f2207b;
                    component = h.getComponent();
                }
                this.f2206a.add(M);
            } catch (PackageManager.NameNotFoundException e) {
                Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
                throw new IllegalArgumentException(e);
            }
        }
        return this;
    }

    /* renamed from: e */
    public void mo2288e() {
        if (!this.f2206a.isEmpty()) {
            ArrayList<Intent> arrayList = this.f2206a;
            Intent[] intentArr = (Intent[]) arrayList.toArray(new Intent[arrayList.size()]);
            intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
            Context context = this.f2207b;
            int i = C0474a.f2214b;
            context.startActivities(intentArr, (Bundle) null);
            return;
        }
        throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
    }

    @Deprecated
    public Iterator<Intent> iterator() {
        return this.f2206a.iterator();
    }
}
