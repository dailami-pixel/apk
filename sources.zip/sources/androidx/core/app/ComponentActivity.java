package androidx.core.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import androidx.lifecycle.C0903f;
import androidx.lifecycle.C0909j;
import androidx.lifecycle.C0910k;
import androidx.lifecycle.C0918r;
import p098d.p120g.p130j.C4751d;

public class ComponentActivity extends Activity implements C0909j, C4751d.C4752a {

    /* renamed from: a */
    private C0910k f2079a = new C0910k(this);

    /* renamed from: G */
    public C0903f mo341G() {
        return this.f2079a;
    }

    /* renamed from: a0 */
    public boolean mo574a0(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        View decorView = getWindow().getDecorView();
        if (decorView == null || !C4751d.m17261a(decorView, keyEvent)) {
            return C4751d.m17262b(this, decorView, this, keyEvent);
        }
        return true;
    }

    public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        View decorView = getWindow().getDecorView();
        if (decorView == null || !C4751d.m17261a(decorView, keyEvent)) {
            return super.dispatchKeyShortcutEvent(keyEvent);
        }
        return true;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        C0918r.m3873c(this);
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        this.f2079a.mo3945g(C0903f.C0905b.CREATED);
        super.onSaveInstanceState(bundle);
    }
}
