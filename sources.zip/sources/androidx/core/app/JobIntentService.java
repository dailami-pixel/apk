package androidx.core.app;

import android.app.Service;
import android.app.job.JobParameters;
import android.app.job.JobServiceEngine;
import android.app.job.JobWorkItem;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import java.util.ArrayList;
import java.util.HashMap;

public abstract class JobIntentService extends Service {

    /* renamed from: a */
    static final HashMap<ComponentName, C0440g> f2080a = new HashMap<>();

    /* renamed from: b */
    C0434b f2081b;

    /* renamed from: c */
    C0440g f2082c;

    /* renamed from: d */
    C0433a f2083d;

    /* renamed from: e */
    boolean f2084e = false;

    /* renamed from: f */
    final ArrayList<C0436d> f2085f;

    /* renamed from: androidx.core.app.JobIntentService$a */
    final class C0433a extends AsyncTask<Void, Void, Void> {
        C0433a() {
        }

        /* access modifiers changed from: protected */
        /* JADX WARNING: Removed duplicated region for block: B:29:0x004c A[LOOP:0: B:1:0x0002->B:29:0x004c, LOOP_END] */
        /* JADX WARNING: Removed duplicated region for block: B:35:0x0059 A[SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public java.lang.Object doInBackground(java.lang.Object[] r5) {
            /*
                r4 = this;
                java.lang.Void[] r5 = (java.lang.Void[]) r5
            L_0x0002:
                androidx.core.app.JobIntentService r5 = androidx.core.app.JobIntentService.this
                androidx.core.app.JobIntentService$b r0 = r5.f2081b
                r1 = 0
                if (r0 == 0) goto L_0x0031
                androidx.core.app.JobIntentService$f r0 = (androidx.core.app.JobIntentService.C0438f) r0
                java.lang.Object r2 = r0.f2094b
                monitor-enter(r2)
                android.app.job.JobParameters r5 = r0.f2095c     // Catch:{ all -> 0x002e }
                if (r5 != 0) goto L_0x0014
                monitor-exit(r2)     // Catch:{ all -> 0x002e }
                goto L_0x0049
            L_0x0014:
                android.app.job.JobWorkItem r5 = r5.dequeueWork()     // Catch:{ all -> 0x002e }
                monitor-exit(r2)     // Catch:{ all -> 0x002e }
                if (r5 == 0) goto L_0x0049
                android.content.Intent r2 = r5.getIntent()
                androidx.core.app.JobIntentService r3 = r0.f2093a
                java.lang.ClassLoader r3 = r3.getClassLoader()
                r2.setExtrasClassLoader(r3)
                androidx.core.app.JobIntentService$f$a r2 = new androidx.core.app.JobIntentService$f$a
                r2.<init>(r5)
                goto L_0x004a
            L_0x002e:
                r5 = move-exception
                monitor-exit(r2)     // Catch:{ all -> 0x002e }
                throw r5
            L_0x0031:
                java.util.ArrayList<androidx.core.app.JobIntentService$d> r0 = r5.f2085f
                monitor-enter(r0)
                java.util.ArrayList<androidx.core.app.JobIntentService$d> r2 = r5.f2085f     // Catch:{ all -> 0x005a }
                int r2 = r2.size()     // Catch:{ all -> 0x005a }
                if (r2 <= 0) goto L_0x0048
                java.util.ArrayList<androidx.core.app.JobIntentService$d> r5 = r5.f2085f     // Catch:{ all -> 0x005a }
                r2 = 0
                java.lang.Object r5 = r5.remove(r2)     // Catch:{ all -> 0x005a }
                r2 = r5
                androidx.core.app.JobIntentService$e r2 = (androidx.core.app.JobIntentService.C0437e) r2     // Catch:{ all -> 0x005a }
                monitor-exit(r0)     // Catch:{ all -> 0x005a }
                goto L_0x004a
            L_0x0048:
                monitor-exit(r0)     // Catch:{ all -> 0x005a }
            L_0x0049:
                r2 = r1
            L_0x004a:
                if (r2 == 0) goto L_0x0059
                androidx.core.app.JobIntentService r5 = androidx.core.app.JobIntentService.this
                android.content.Intent r0 = r2.getIntent()
                r5.mo2200b(r0)
                r2.mo2212a()
                goto L_0x0002
            L_0x0059:
                return r1
            L_0x005a:
                r5 = move-exception
                monitor-exit(r0)     // Catch:{ all -> 0x005a }
                throw r5
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.core.app.JobIntentService.C0433a.doInBackground(java.lang.Object[]):java.lang.Object");
        }

        /* access modifiers changed from: protected */
        public void onCancelled(Object obj) {
            Void voidR = (Void) obj;
            JobIntentService.this.mo2201c();
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Object obj) {
            Void voidR = (Void) obj;
            JobIntentService.this.mo2201c();
        }
    }

    /* renamed from: androidx.core.app.JobIntentService$b */
    interface C0434b {
    }

    /* renamed from: androidx.core.app.JobIntentService$c */
    static final class C0435c extends C0440g {

        /* renamed from: b */
        private final PowerManager.WakeLock f2087b;

        /* renamed from: c */
        private final PowerManager.WakeLock f2088c;

        /* renamed from: d */
        boolean f2089d;

        C0435c(Context context, ComponentName componentName) {
            super(componentName);
            context.getApplicationContext();
            PowerManager powerManager = (PowerManager) context.getSystemService("power");
            PowerManager.WakeLock newWakeLock = powerManager.newWakeLock(1, componentName.getClassName() + ":launch");
            this.f2087b = newWakeLock;
            newWakeLock.setReferenceCounted(false);
            PowerManager.WakeLock newWakeLock2 = powerManager.newWakeLock(1, componentName.getClassName() + ":run");
            this.f2088c = newWakeLock2;
            newWakeLock2.setReferenceCounted(false);
        }

        /* renamed from: a */
        public void mo2209a() {
            synchronized (this) {
                if (this.f2089d) {
                    this.f2089d = false;
                    this.f2088c.release();
                }
            }
        }

        /* renamed from: b */
        public void mo2210b() {
            synchronized (this) {
                if (!this.f2089d) {
                    this.f2089d = true;
                    this.f2088c.acquire(600000);
                    this.f2087b.release();
                }
            }
        }

        /* renamed from: c */
        public void mo2211c() {
            synchronized (this) {
            }
        }
    }

    /* renamed from: androidx.core.app.JobIntentService$d */
    final class C0436d implements C0437e {

        /* renamed from: a */
        final Intent f2090a;

        /* renamed from: b */
        final int f2091b;

        C0436d(Intent intent, int i) {
            this.f2090a = intent;
            this.f2091b = i;
        }

        /* renamed from: a */
        public void mo2212a() {
            JobIntentService.this.stopSelf(this.f2091b);
        }

        public Intent getIntent() {
            return this.f2090a;
        }
    }

    /* renamed from: androidx.core.app.JobIntentService$e */
    interface C0437e {
        /* renamed from: a */
        void mo2212a();

        Intent getIntent();
    }

    /* renamed from: androidx.core.app.JobIntentService$f */
    static final class C0438f extends JobServiceEngine implements C0434b {

        /* renamed from: a */
        final JobIntentService f2093a;

        /* renamed from: b */
        final Object f2094b = new Object();

        /* renamed from: c */
        JobParameters f2095c;

        /* renamed from: androidx.core.app.JobIntentService$f$a */
        final class C0439a implements C0437e {

            /* renamed from: a */
            final JobWorkItem f2096a;

            C0439a(JobWorkItem jobWorkItem) {
                this.f2096a = jobWorkItem;
            }

            /* renamed from: a */
            public void mo2212a() {
                synchronized (C0438f.this.f2094b) {
                    JobParameters jobParameters = C0438f.this.f2095c;
                    if (jobParameters != null) {
                        jobParameters.completeWork(this.f2096a);
                    }
                }
            }

            public Intent getIntent() {
                return this.f2096a.getIntent();
            }
        }

        C0438f(JobIntentService jobIntentService) {
            super(jobIntentService);
            this.f2093a = jobIntentService;
        }

        public boolean onStartJob(JobParameters jobParameters) {
            this.f2095c = jobParameters;
            this.f2093a.mo2199a(false);
            return true;
        }

        public boolean onStopJob(JobParameters jobParameters) {
            C0433a aVar = this.f2093a.f2083d;
            if (aVar != null) {
                aVar.cancel(false);
            }
            synchronized (this.f2094b) {
                this.f2095c = null;
            }
            return true;
        }
    }

    /* renamed from: androidx.core.app.JobIntentService$g */
    static abstract class C0440g {

        /* renamed from: a */
        final ComponentName f2098a;

        C0440g(ComponentName componentName) {
            this.f2098a = componentName;
        }

        /* renamed from: a */
        public void mo2209a() {
        }

        /* renamed from: b */
        public void mo2210b() {
        }

        /* renamed from: c */
        public void mo2211c() {
        }
    }

    public JobIntentService() {
        this.f2085f = Build.VERSION.SDK_INT >= 26 ? null : new ArrayList<>();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo2199a(boolean z) {
        if (this.f2083d == null) {
            this.f2083d = new C0433a();
            C0440g gVar = this.f2082c;
            if (gVar != null && z) {
                gVar.mo2210b();
            }
            this.f2083d.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract void mo2200b(Intent intent);

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo2201c() {
        ArrayList<C0436d> arrayList = this.f2085f;
        if (arrayList != null) {
            synchronized (arrayList) {
                this.f2083d = null;
                ArrayList<C0436d> arrayList2 = this.f2085f;
                if (arrayList2 != null && arrayList2.size() > 0) {
                    mo2199a(false);
                } else if (!this.f2084e) {
                    this.f2082c.mo2209a();
                }
            }
        }
    }

    public IBinder onBind(Intent intent) {
        C0434b bVar = this.f2081b;
        if (bVar != null) {
            return ((C0438f) bVar).getBinder();
        }
        return null;
    }

    public void onCreate() {
        super.onCreate();
        int i = Build.VERSION.SDK_INT;
        if (i >= 26) {
            this.f2081b = new C0438f(this);
            this.f2082c = null;
            return;
        }
        this.f2081b = null;
        ComponentName componentName = new ComponentName(this, getClass());
        HashMap<ComponentName, C0440g> hashMap = f2080a;
        C0440g gVar = hashMap.get(componentName);
        if (gVar == null) {
            if (i < 26) {
                gVar = new C0435c(this, componentName);
                hashMap.put(componentName, gVar);
            } else {
                throw new IllegalArgumentException("Can't be here without a job id");
            }
        }
        this.f2082c = gVar;
    }

    public void onDestroy() {
        super.onDestroy();
        ArrayList<C0436d> arrayList = this.f2085f;
        if (arrayList != null) {
            synchronized (arrayList) {
                this.f2084e = true;
                this.f2082c.mo2209a();
            }
        }
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        if (this.f2085f == null) {
            return 2;
        }
        this.f2082c.mo2211c();
        synchronized (this.f2085f) {
            ArrayList<C0436d> arrayList = this.f2085f;
            if (intent == null) {
                intent = new Intent();
            }
            arrayList.add(new C0436d(intent, i2));
            mo2199a(true);
        }
        return 3;
    }
}
