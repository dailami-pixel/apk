package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import androidx.versionedparcelable.C1391c;

public final class RemoteActionCompat implements C1391c {

    /* renamed from: a */
    public IconCompat f2099a;

    /* renamed from: b */
    public CharSequence f2100b;

    /* renamed from: c */
    public CharSequence f2101c;

    /* renamed from: d */
    public PendingIntent f2102d;

    /* renamed from: e */
    public boolean f2103e;

    /* renamed from: f */
    public boolean f2104f;
}
