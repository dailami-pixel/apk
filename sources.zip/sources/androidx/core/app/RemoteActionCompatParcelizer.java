package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import androidx.versionedparcelable.C1389a;
import java.util.Objects;

public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(C1389a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        remoteActionCompat.f2099a = (IconCompat) aVar.mo5667t(remoteActionCompat.f2099a, 1);
        remoteActionCompat.f2100b = aVar.mo5658k(remoteActionCompat.f2100b, 2);
        remoteActionCompat.f2101c = aVar.mo5658k(remoteActionCompat.f2101c, 3);
        remoteActionCompat.f2102d = (PendingIntent) aVar.mo5663p(remoteActionCompat.f2102d, 4);
        remoteActionCompat.f2103e = aVar.mo5654g(remoteActionCompat.f2103e, 5);
        remoteActionCompat.f2104f = aVar.mo5654g(remoteActionCompat.f2104f, 6);
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, C1389a aVar) {
        Objects.requireNonNull(aVar);
        aVar.mo5650I(remoteActionCompat.f2099a, 1);
        aVar.mo5642A(remoteActionCompat.f2100b, 2);
        aVar.mo5642A(remoteActionCompat.f2101c, 3);
        aVar.mo5646E(remoteActionCompat.f2102d, 4);
        aVar.mo5670w(remoteActionCompat.f2103e, 5);
        aVar.mo5670w(remoteActionCompat.f2104f, 6);
    }
}
