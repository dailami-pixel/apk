package androidx.core.content.p005b;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Base64;
import android.util.TypedValue;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import p098d.p120g.C4691b;
import p098d.p120g.p127g.C4716a;

/* renamed from: androidx.core.content.b.a */
public final class C0476a {
    /* JADX WARNING: Removed duplicated region for block: B:6:0x0011  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0016  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.content.res.ColorStateList m2163a(android.content.res.Resources r4, org.xmlpull.v1.XmlPullParser r5, android.content.res.Resources.Theme r6) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
            android.util.AttributeSet r0 = android.util.Xml.asAttributeSet(r5)
        L_0x0004:
            int r1 = r5.next()
            r2 = 2
            if (r1 == r2) goto L_0x000f
            r3 = 1
            if (r1 == r3) goto L_0x000f
            goto L_0x0004
        L_0x000f:
            if (r1 != r2) goto L_0x0016
            android.content.res.ColorStateList r4 = m2164b(r4, r5, r0, r6)
            return r4
        L_0x0016:
            org.xmlpull.v1.XmlPullParserException r4 = new org.xmlpull.v1.XmlPullParserException
            java.lang.String r5 = "No start tag found"
            r4.<init>(r5)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.content.p005b.C0476a.m2163a(android.content.res.Resources, org.xmlpull.v1.XmlPullParser, android.content.res.Resources$Theme):android.content.res.ColorStateList");
    }

    /* JADX WARNING: type inference failed for: r8v16, types: [java.lang.Object[], java.lang.Object] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.content.res.ColorStateList m2164b(android.content.res.Resources r17, org.xmlpull.v1.XmlPullParser r18, android.util.AttributeSet r19, android.content.res.Resources.Theme r20) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
            r0 = r19
            r1 = r20
            java.lang.String r2 = r18.getName()
            java.lang.String r3 = "selector"
            boolean r3 = r2.equals(r3)
            if (r3 == 0) goto L_0x0102
            int r2 = r18.getDepth()
            r3 = 1
            int r2 = r2 + r3
            r4 = 20
            int[][] r5 = new int[r4][]
            int[] r4 = new int[r4]
            r6 = 0
            r7 = 0
        L_0x001e:
            int r8 = r18.next()
            if (r8 == r3) goto L_0x00f2
            int r9 = r18.getDepth()
            if (r9 >= r2) goto L_0x002d
            r10 = 3
            if (r8 == r10) goto L_0x00f2
        L_0x002d:
            r10 = 2
            if (r8 != r10) goto L_0x00ed
            if (r9 > r2) goto L_0x00ed
            java.lang.String r8 = r18.getName()
            java.lang.String r9 = "item"
            boolean r8 = r8.equals(r9)
            if (r8 != 0) goto L_0x0040
            goto L_0x00ed
        L_0x0040:
            int[] r8 = p098d.p120g.C4691b.f17096a
            if (r1 != 0) goto L_0x004b
            r9 = r17
            android.content.res.TypedArray r8 = r9.obtainAttributes(r0, r8)
            goto L_0x0051
        L_0x004b:
            r9 = r17
            android.content.res.TypedArray r8 = r1.obtainStyledAttributes(r0, r8, r6, r6)
        L_0x0051:
            r11 = -65281(0xffffffffffff00ff, float:NaN)
            int r11 = r8.getColor(r6, r11)
            r12 = 1065353216(0x3f800000, float:1.0)
            boolean r13 = r8.hasValue(r3)
            if (r13 == 0) goto L_0x0065
            float r12 = r8.getFloat(r3, r12)
            goto L_0x006f
        L_0x0065:
            boolean r13 = r8.hasValue(r10)
            if (r13 == 0) goto L_0x006f
            float r12 = r8.getFloat(r10, r12)
        L_0x006f:
            r8.recycle()
            int r8 = r19.getAttributeCount()
            int[] r10 = new int[r8]
            r13 = 0
            r14 = 0
        L_0x007a:
            if (r13 >= r8) goto L_0x00a0
            int r15 = r0.getAttributeNameResource(r13)
            r3 = 16843173(0x10101a5, float:2.3694738E-38)
            if (r15 == r3) goto L_0x009c
            r3 = 16843551(0x101031f, float:2.3695797E-38)
            if (r15 == r3) goto L_0x009c
            r3 = 2130968629(0x7f040035, float:1.7545917E38)
            if (r15 == r3) goto L_0x009c
            int r3 = r14 + 1
            boolean r16 = r0.getAttributeBooleanValue(r13, r6)
            if (r16 == 0) goto L_0x0098
            goto L_0x0099
        L_0x0098:
            int r15 = -r15
        L_0x0099:
            r10[r14] = r15
            r14 = r3
        L_0x009c:
            int r13 = r13 + 1
            r3 = 1
            goto L_0x007a
        L_0x00a0:
            int[] r3 = android.util.StateSet.trimStateSet(r10, r14)
            int r8 = android.graphics.Color.alpha(r11)
            float r8 = (float) r8
            float r8 = r8 * r12
            int r8 = java.lang.Math.round(r8)
            r10 = 16777215(0xffffff, float:2.3509886E-38)
            r10 = r10 & r11
            int r8 = r8 << 24
            r8 = r8 | r10
            int r10 = r7 + 1
            int r11 = r4.length
            r12 = 4
            r13 = 8
            if (r10 <= r11) goto L_0x00cb
            if (r7 > r12) goto L_0x00c3
            r11 = 8
            goto L_0x00c5
        L_0x00c3:
            int r11 = r7 * 2
        L_0x00c5:
            int[] r11 = new int[r11]
            java.lang.System.arraycopy(r4, r6, r11, r6, r7)
            r4 = r11
        L_0x00cb:
            r4[r7] = r8
            int r8 = r5.length
            if (r10 <= r8) goto L_0x00e7
            java.lang.Class r8 = r5.getClass()
            java.lang.Class r8 = r8.getComponentType()
            if (r7 > r12) goto L_0x00db
            goto L_0x00dd
        L_0x00db:
            int r13 = r7 * 2
        L_0x00dd:
            java.lang.Object r8 = java.lang.reflect.Array.newInstance(r8, r13)
            java.lang.Object[] r8 = (java.lang.Object[]) r8
            java.lang.System.arraycopy(r5, r6, r8, r6, r7)
            r5 = r8
        L_0x00e7:
            r5[r7] = r3
            int[][] r5 = (int[][]) r5
            r7 = r10
            goto L_0x00ef
        L_0x00ed:
            r9 = r17
        L_0x00ef:
            r3 = 1
            goto L_0x001e
        L_0x00f2:
            int[] r0 = new int[r7]
            int[][] r1 = new int[r7][]
            java.lang.System.arraycopy(r4, r6, r0, r6, r7)
            java.lang.System.arraycopy(r5, r6, r1, r6, r7)
            android.content.res.ColorStateList r2 = new android.content.res.ColorStateList
            r2.<init>(r1, r0)
            return r2
        L_0x0102:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = r18.getPositionDescription()
            r1.append(r3)
            java.lang.String r3 = ": invalid color state list tag "
            r1.append(r3)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.content.p005b.C0476a.m2164b(android.content.res.Resources, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.content.res.Resources$Theme):android.content.res.ColorStateList");
    }

    /* renamed from: c */
    public static int m2165c(Context context, int i, int i2) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(i, typedValue, true);
        return typedValue.resourceId != 0 ? i : i2;
    }

    /* renamed from: d */
    public static boolean m2166d(TypedArray typedArray, int i, int i2, boolean z) {
        return typedArray.getBoolean(i, typedArray.getBoolean(i2, z));
    }

    /* renamed from: e */
    public static Typeface m2167e(Context context, int i, TypedValue typedValue, int i2, C0483h hVar) throws Resources.NotFoundException {
        if (context.isRestricted()) {
            return null;
        }
        return m2179q(context, i, typedValue, i2, hVar, (Handler) null, true);
    }

    /* renamed from: f */
    public static void m2168f(Context context, int i, C0483h hVar, Handler handler) throws Resources.NotFoundException {
        if (context.isRestricted()) {
            hVar.mo2317a(-4, (Handler) null);
            return;
        }
        m2179q(context, i, new TypedValue(), 0, hVar, (Handler) null, false);
    }

    /* renamed from: g */
    public static boolean m2169g(TypedArray typedArray, XmlPullParser xmlPullParser, String str, int i, boolean z) {
        return !m2178p(xmlPullParser, str) ? z : typedArray.getBoolean(i, z);
    }

    /* renamed from: h */
    public static C0477b m2170h(TypedArray typedArray, XmlPullParser xmlPullParser, Resources.Theme theme, String str, int i, int i2) {
        if (m2178p(xmlPullParser, str)) {
            TypedValue typedValue = new TypedValue();
            typedArray.getValue(i, typedValue);
            int i3 = typedValue.type;
            if (i3 >= 28 && i3 <= 31) {
                return C0477b.m2187b(typedValue.data);
            }
            C0477b e = C0477b.m2188e(typedArray.getResources(), typedArray.getResourceId(i, 0), theme);
            if (e != null) {
                return e;
            }
        }
        return C0477b.m2187b(i2);
    }

    /* renamed from: i */
    public static float m2171i(TypedArray typedArray, XmlPullParser xmlPullParser, String str, int i, float f) {
        return !m2178p(xmlPullParser, str) ? f : typedArray.getFloat(i, f);
    }

    /* renamed from: j */
    public static int m2172j(TypedArray typedArray, XmlPullParser xmlPullParser, String str, int i, int i2) {
        return !m2178p(xmlPullParser, str) ? i2 : typedArray.getInt(i, i2);
    }

    /* renamed from: k */
    public static int m2173k(TypedArray typedArray, XmlPullParser xmlPullParser, String str, int i, int i2) {
        return !m2178p(xmlPullParser, str) ? i2 : typedArray.getResourceId(i, i2);
    }

    /* renamed from: l */
    public static String m2174l(TypedArray typedArray, XmlPullParser xmlPullParser, String str, int i) {
        if (!m2178p(xmlPullParser, str)) {
            return null;
        }
        return typedArray.getString(i);
    }

    /* renamed from: m */
    public static int m2175m(TypedArray typedArray, int i, int i2, int i3) {
        return typedArray.getResourceId(i, typedArray.getResourceId(i2, i3));
    }

    /* renamed from: n */
    public static String m2176n(TypedArray typedArray, int i, int i2) {
        String string = typedArray.getString(i);
        return string == null ? typedArray.getString(i2) : string;
    }

    /* renamed from: o */
    public static CharSequence[] m2177o(TypedArray typedArray, int i, int i2) {
        CharSequence[] textArray = typedArray.getTextArray(i);
        return textArray == null ? typedArray.getTextArray(i2) : textArray;
    }

    /* renamed from: p */
    public static boolean m2178p(XmlPullParser xmlPullParser, String str) {
        return xmlPullParser.getAttributeValue("http://schemas.android.com/apk/res/android", str) != null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x009a, code lost:
        if (r10 != null) goto L_0x009c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0026, code lost:
        if (r10 != null) goto L_0x009c;
     */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x00a1 A[ADDED_TO_REGION] */
    /* renamed from: q */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static android.graphics.Typeface m2179q(android.content.Context r16, int r17, android.util.TypedValue r18, int r19, androidx.core.content.p005b.C0483h r20, android.os.Handler r21, boolean r22) {
        /*
            r9 = r17
            r0 = r18
            r5 = r19
            r10 = r20
            r11 = r21
            android.content.res.Resources r3 = r16.getResources()
            r1 = 1
            r3.getValue(r9, r0, r1)
            java.lang.String r12 = "ResourcesCompat"
            java.lang.CharSequence r1 = r0.string
            if (r1 == 0) goto L_0x00c1
            java.lang.String r13 = r1.toString()
            java.lang.String r0 = "res/"
            boolean r0 = r13.startsWith(r0)
            r14 = 0
            r15 = -3
            if (r0 != 0) goto L_0x002a
            if (r10 == 0) goto L_0x009f
            goto L_0x009c
        L_0x002a:
            android.graphics.Typeface r0 = p098d.p120g.p121c.C4696e.m17147e(r3, r9, r5)
            if (r0 == 0) goto L_0x0038
            if (r10 == 0) goto L_0x0035
            r10.mo2318b(r0, r11)
        L_0x0035:
            r14 = r0
            goto L_0x009f
        L_0x0038:
            java.lang.String r0 = r13.toLowerCase()     // Catch:{ XmlPullParserException -> 0x0085, IOException -> 0x007c }
            java.lang.String r1 = ".xml"
            boolean r0 = r0.endsWith(r1)     // Catch:{ XmlPullParserException -> 0x0085, IOException -> 0x007c }
            if (r0 == 0) goto L_0x006a
            android.content.res.XmlResourceParser r0 = r3.getXml(r9)     // Catch:{ XmlPullParserException -> 0x0085, IOException -> 0x007c }
            androidx.core.content.b.c r2 = m2181s(r0, r3)     // Catch:{ XmlPullParserException -> 0x0085, IOException -> 0x007c }
            if (r2 != 0) goto L_0x0059
            java.lang.String r0 = "Failed to find font-family tag"
            android.util.Log.e(r12, r0)     // Catch:{ XmlPullParserException -> 0x0085, IOException -> 0x007c }
            if (r10 == 0) goto L_0x009f
            r10.mo2317a(r15, r11)     // Catch:{ XmlPullParserException -> 0x0085, IOException -> 0x007c }
            goto L_0x009f
        L_0x0059:
            r1 = r16
            r4 = r17
            r5 = r19
            r6 = r20
            r7 = r21
            r8 = r22
            android.graphics.Typeface r14 = p098d.p120g.p121c.C4696e.m17144b(r1, r2, r3, r4, r5, r6, r7, r8)     // Catch:{ XmlPullParserException -> 0x0085, IOException -> 0x007c }
            goto L_0x009f
        L_0x006a:
            r0 = r16
            android.graphics.Typeface r0 = p098d.p120g.p121c.C4696e.m17145c(r0, r3, r9, r13, r5)     // Catch:{ XmlPullParserException -> 0x0085, IOException -> 0x007c }
            if (r10 == 0) goto L_0x0035
            if (r0 == 0) goto L_0x0078
            r10.mo2318b(r0, r11)     // Catch:{ XmlPullParserException -> 0x0085, IOException -> 0x007c }
            goto L_0x0035
        L_0x0078:
            r10.mo2317a(r15, r11)     // Catch:{ XmlPullParserException -> 0x0085, IOException -> 0x007c }
            goto L_0x0035
        L_0x007c:
            r0 = move-exception
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Failed to read xml resource "
            goto L_0x008d
        L_0x0085:
            r0 = move-exception
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Failed to parse xml resource "
        L_0x008d:
            r1.append(r2)
            r1.append(r13)
            java.lang.String r1 = r1.toString()
            android.util.Log.e(r12, r1, r0)
            if (r10 == 0) goto L_0x009f
        L_0x009c:
            r10.mo2317a(r15, r11)
        L_0x009f:
            if (r14 != 0) goto L_0x00c0
            if (r10 == 0) goto L_0x00a4
            goto L_0x00c0
        L_0x00a4:
            android.content.res.Resources$NotFoundException r0 = new android.content.res.Resources$NotFoundException
            java.lang.String r1 = "Font resource ID #0x"
            java.lang.StringBuilder r1 = p165e.p166a.p167a.p168a.C4924a.m17863P(r1)
            java.lang.String r2 = java.lang.Integer.toHexString(r17)
            r1.append(r2)
            java.lang.String r2 = " could not be retrieved."
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x00c0:
            return r14
        L_0x00c1:
            android.content.res.Resources$NotFoundException r1 = new android.content.res.Resources$NotFoundException
            java.lang.String r2 = "Resource \""
            java.lang.StringBuilder r2 = p165e.p166a.p167a.p168a.C4924a.m17863P(r2)
            java.lang.String r3 = r3.getResourceName(r9)
            r2.append(r3)
            java.lang.String r3 = "\" ("
            r2.append(r3)
            java.lang.String r3 = java.lang.Integer.toHexString(r17)
            r2.append(r3)
            java.lang.String r3 = ") is not a Font: "
            r2.append(r3)
            r2.append(r0)
            java.lang.String r0 = r2.toString()
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.content.p005b.C0476a.m2179q(android.content.Context, int, android.util.TypedValue, int, androidx.core.content.b.h, android.os.Handler, boolean):android.graphics.Typeface");
    }

    /* renamed from: r */
    public static TypedArray m2180r(Resources resources, Resources.Theme theme, AttributeSet attributeSet, int[] iArr) {
        return theme == null ? resources.obtainAttributes(attributeSet, iArr) : theme.obtainStyledAttributes(attributeSet, iArr, 0, 0);
    }

    /* renamed from: s */
    public static C0478c m2181s(XmlPullParser xmlPullParser, Resources resources) throws XmlPullParserException, IOException {
        int next;
        Resources resources2 = resources;
        do {
            next = xmlPullParser.next();
            if (next == 2) {
                break;
            }
        } while (next != 1);
        if (next == 2) {
            xmlPullParser.require(2, (String) null, "font-family");
            if (xmlPullParser.getName().equals("font-family")) {
                TypedArray obtainAttributes = resources2.obtainAttributes(Xml.asAttributeSet(xmlPullParser), C4691b.f17097b);
                String string = obtainAttributes.getString(0);
                String string2 = obtainAttributes.getString(4);
                String string3 = obtainAttributes.getString(5);
                int resourceId = obtainAttributes.getResourceId(1, 0);
                int integer = obtainAttributes.getInteger(2, 1);
                int integer2 = obtainAttributes.getInteger(3, 500);
                obtainAttributes.recycle();
                if (string == null || string2 == null || string3 == null) {
                    ArrayList arrayList = new ArrayList();
                    while (xmlPullParser.next() != 3) {
                        if (xmlPullParser.getEventType() == 2) {
                            if (xmlPullParser.getName().equals("font")) {
                                TypedArray obtainAttributes2 = resources2.obtainAttributes(Xml.asAttributeSet(xmlPullParser), C4691b.f17098c);
                                int i = 8;
                                if (!obtainAttributes2.hasValue(8)) {
                                    i = 1;
                                }
                                int i2 = obtainAttributes2.getInt(i, 400);
                                int i3 = 6;
                                if (!obtainAttributes2.hasValue(6)) {
                                    i3 = 2;
                                }
                                boolean z = 1 == obtainAttributes2.getInt(i3, 0);
                                int i4 = 9;
                                if (!obtainAttributes2.hasValue(9)) {
                                    i4 = 3;
                                }
                                int i5 = 7;
                                if (!obtainAttributes2.hasValue(7)) {
                                    i5 = 4;
                                }
                                String string4 = obtainAttributes2.getString(i5);
                                int i6 = obtainAttributes2.getInt(i4, 0);
                                int i7 = obtainAttributes2.hasValue(5) ? 5 : 0;
                                int resourceId2 = obtainAttributes2.getResourceId(i7, 0);
                                String string5 = obtainAttributes2.getString(i7);
                                obtainAttributes2.recycle();
                                while (xmlPullParser.next() != 3) {
                                    m2184v(xmlPullParser);
                                }
                                arrayList.add(new C0480e(string5, i2, z, string4, i6, resourceId2));
                            } else {
                                m2184v(xmlPullParser);
                            }
                        }
                    }
                    if (arrayList.isEmpty()) {
                        return null;
                    }
                    return new C0479d((C0480e[]) arrayList.toArray(new C0480e[arrayList.size()]));
                }
                while (xmlPullParser.next() != 3) {
                    m2184v(xmlPullParser);
                }
                return new C0481f(new C4716a(string, string2, string3, m2182t(resources2, resourceId)), integer, integer2);
            }
            m2184v(xmlPullParser);
            return null;
        }
        throw new XmlPullParserException("No start tag found");
    }

    /* renamed from: t */
    public static List<List<byte[]>> m2182t(Resources resources, int i) {
        if (i == 0) {
            return Collections.emptyList();
        }
        TypedArray obtainTypedArray = resources.obtainTypedArray(i);
        try {
            if (obtainTypedArray.length() == 0) {
                return Collections.emptyList();
            }
            ArrayList arrayList = new ArrayList();
            if (obtainTypedArray.getType(0) == 1) {
                for (int i2 = 0; i2 < obtainTypedArray.length(); i2++) {
                    int resourceId = obtainTypedArray.getResourceId(i2, 0);
                    if (resourceId != 0) {
                        arrayList.add(m2185w(resources.getStringArray(resourceId)));
                    }
                }
            } else {
                arrayList.add(m2185w(resources.getStringArray(i)));
            }
            obtainTypedArray.recycle();
            return arrayList;
        } finally {
            obtainTypedArray.recycle();
        }
    }

    /* renamed from: u */
    public static void m2183u(Resources.Theme theme) {
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
            theme.rebase();
        } else if (i >= 23) {
            C0486i.m2210a(theme);
        }
    }

    /* renamed from: v */
    private static void m2184v(XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        int i = 1;
        while (i > 0) {
            int next = xmlPullParser.next();
            if (next == 2) {
                i++;
            } else if (next == 3) {
                i--;
            }
        }
    }

    /* renamed from: w */
    private static List<byte[]> m2185w(String[] strArr) {
        ArrayList arrayList = new ArrayList();
        for (String decode : strArr) {
            arrayList.add(Base64.decode(decode, 0));
        }
        return arrayList;
    }
}
