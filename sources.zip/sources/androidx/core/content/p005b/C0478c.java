package androidx.core.content.p005b;

/* renamed from: androidx.core.content.b.c */
public interface C0478c {
}
