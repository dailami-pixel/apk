package androidx.core.content.p005b;

/* renamed from: androidx.core.content.b.d */
public final class C0479d implements C0478c {

    /* renamed from: a */
    private final C0480e[] f2219a;

    public C0479d(C0480e[] eVarArr) {
        this.f2219a = eVarArr;
    }

    /* renamed from: a */
    public C0480e[] mo2307a() {
        return this.f2219a;
    }
}
