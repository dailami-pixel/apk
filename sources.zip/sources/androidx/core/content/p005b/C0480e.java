package androidx.core.content.p005b;

/* renamed from: androidx.core.content.b.e */
public final class C0480e {

    /* renamed from: a */
    private final String f2220a;

    /* renamed from: b */
    private int f2221b;

    /* renamed from: c */
    private boolean f2222c;

    /* renamed from: d */
    private String f2223d;

    /* renamed from: e */
    private int f2224e;

    /* renamed from: f */
    private int f2225f;

    public C0480e(String str, int i, boolean z, String str2, int i2, int i3) {
        this.f2220a = str;
        this.f2221b = i;
        this.f2222c = z;
        this.f2223d = str2;
        this.f2224e = i2;
        this.f2225f = i3;
    }

    /* renamed from: a */
    public String mo2308a() {
        return this.f2220a;
    }

    /* renamed from: b */
    public int mo2309b() {
        return this.f2225f;
    }

    /* renamed from: c */
    public int mo2310c() {
        return this.f2224e;
    }

    /* renamed from: d */
    public String mo2311d() {
        return this.f2223d;
    }

    /* renamed from: e */
    public int mo2312e() {
        return this.f2221b;
    }

    /* renamed from: f */
    public boolean mo2313f() {
        return this.f2222c;
    }
}
