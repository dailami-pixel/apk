package androidx.core.content.p005b;

import p098d.p120g.p127g.C4716a;

/* renamed from: androidx.core.content.b.f */
public final class C0481f implements C0478c {

    /* renamed from: a */
    private final C4716a f2226a;

    /* renamed from: b */
    private final int f2227b;

    /* renamed from: c */
    private final int f2228c;

    public C0481f(C4716a aVar, int i, int i2) {
        this.f2226a = aVar;
        this.f2228c = i;
        this.f2227b = i2;
    }

    /* renamed from: a */
    public int mo2314a() {
        return this.f2228c;
    }

    /* renamed from: b */
    public C4716a mo2315b() {
        return this.f2226a;
    }

    /* renamed from: c */
    public int mo2316c() {
        return this.f2227b;
    }
}
