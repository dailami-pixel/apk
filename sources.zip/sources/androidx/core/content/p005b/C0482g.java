package androidx.core.content.p005b;

import java.util.List;

/* renamed from: androidx.core.content.b.g */
final class C0482g {

    /* renamed from: a */
    final int[] f2229a;

    /* renamed from: b */
    final float[] f2230b;

    C0482g(int i, int i2) {
        this.f2229a = new int[]{i, i2};
        this.f2230b = new float[]{0.0f, 1.0f};
    }

    C0482g(int i, int i2, int i3) {
        this.f2229a = new int[]{i, i2, i3};
        this.f2230b = new float[]{0.0f, 0.5f, 1.0f};
    }

    C0482g(List<Integer> list, List<Float> list2) {
        int size = list.size();
        this.f2229a = new int[size];
        this.f2230b = new float[size];
        for (int i = 0; i < size; i++) {
            this.f2229a[i] = list.get(i).intValue();
            this.f2230b[i] = list2.get(i).floatValue();
        }
    }
}
