package androidx.core.content.p005b;

import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;

/* renamed from: androidx.core.content.b.h */
public abstract class C0483h {

    /* renamed from: androidx.core.content.b.h$a */
    class C0484a implements Runnable {

        /* renamed from: a */
        final /* synthetic */ Typeface f2231a;

        C0484a(Typeface typeface) {
            this.f2231a = typeface;
        }

        public void run() {
            C0483h.this.mo1682d(this.f2231a);
        }
    }

    /* renamed from: androidx.core.content.b.h$b */
    class C0485b implements Runnable {

        /* renamed from: a */
        final /* synthetic */ int f2233a;

        C0485b(int i) {
            this.f2233a = i;
        }

        public void run() {
            C0483h.this.mo1681c(this.f2233a);
        }
    }

    /* renamed from: a */
    public final void mo2317a(int i, Handler handler) {
        if (handler == null) {
            handler = new Handler(Looper.getMainLooper());
        }
        handler.post(new C0485b(i));
    }

    /* renamed from: b */
    public final void mo2318b(Typeface typeface, Handler handler) {
        if (handler == null) {
            handler = new Handler(Looper.getMainLooper());
        }
        handler.post(new C0484a(typeface));
    }

    /* renamed from: c */
    public abstract void mo1681c(int i);

    /* renamed from: d */
    public abstract void mo1682d(Typeface typeface);
}
