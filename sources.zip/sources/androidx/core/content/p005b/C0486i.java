package androidx.core.content.p005b;

import android.content.res.Resources;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* renamed from: androidx.core.content.b.i */
class C0486i {

    /* renamed from: a */
    private static final Object f2235a = new Object();

    /* renamed from: b */
    private static Method f2236b;

    /* renamed from: c */
    private static boolean f2237c;

    /* renamed from: a */
    static void m2210a(Resources.Theme theme) {
        synchronized (f2235a) {
            if (!f2237c) {
                try {
                    Method declaredMethod = Resources.Theme.class.getDeclaredMethod("rebase", new Class[0]);
                    f2236b = declaredMethod;
                    declaredMethod.setAccessible(true);
                } catch (NoSuchMethodException e) {
                    Log.i("ResourcesCompat", "Failed to retrieve rebase() method", e);
                }
                f2237c = true;
            }
            Method method = f2236b;
            if (method != null) {
                try {
                    method.invoke(theme, new Object[0]);
                } catch (IllegalAccessException | InvocationTargetException e2) {
                    Log.i("ResourcesCompat", "Failed to invoke rebase() method via reflection", e2);
                    f2236b = null;
                }
            }
        }
    }
}
