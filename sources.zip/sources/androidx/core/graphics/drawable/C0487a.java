package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.InsetDrawable;
import android.os.Build;
import android.util.Log;
import java.lang.reflect.Method;

/* renamed from: androidx.core.graphics.drawable.a */
public final class C0487a {

    /* renamed from: a */
    private static Method f2248a;

    /* renamed from: b */
    private static boolean f2249b;

    /* renamed from: c */
    private static Method f2250c;

    /* renamed from: d */
    private static boolean f2251d;

    /* renamed from: a */
    public static void m2219a(Drawable drawable) {
        DrawableContainer.DrawableContainerState drawableContainerState;
        Drawable b;
        int i = Build.VERSION.SDK_INT;
        drawable.clearColorFilter();
        if (i < 23) {
            if (drawable instanceof InsetDrawable) {
                b = ((InsetDrawable) drawable).getDrawable();
            } else if (drawable instanceof C0489c) {
                b = ((C0489c) drawable).mo2328b();
            } else if ((drawable instanceof DrawableContainer) && (drawableContainerState = (DrawableContainer.DrawableContainerState) ((DrawableContainer) drawable).getConstantState()) != null) {
                int childCount = drawableContainerState.getChildCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    Drawable child = drawableContainerState.getChild(i2);
                    if (child != null) {
                        m2219a(child);
                    }
                }
                return;
            } else {
                return;
            }
            m2219a(b);
        }
    }

    /* renamed from: b */
    public static int m2220b(Drawable drawable) {
        if (Build.VERSION.SDK_INT >= 23) {
            return drawable.getLayoutDirection();
        }
        if (!f2251d) {
            try {
                Method declaredMethod = Drawable.class.getDeclaredMethod("getLayoutDirection", new Class[0]);
                f2250c = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException e) {
                Log.i("DrawableCompat", "Failed to retrieve getLayoutDirection() method", e);
            }
            f2251d = true;
        }
        Method method = f2250c;
        if (method != null) {
            try {
                return ((Integer) method.invoke(drawable, new Object[0])).intValue();
            } catch (Exception e2) {
                Log.i("DrawableCompat", "Failed to invoke getLayoutDirection() via reflection", e2);
                f2250c = null;
            }
        }
        return 0;
    }

    /* renamed from: c */
    public static boolean m2221c(Drawable drawable, int i) {
        if (Build.VERSION.SDK_INT >= 23) {
            return drawable.setLayoutDirection(i);
        }
        if (!f2249b) {
            Class<Drawable> cls = Drawable.class;
            try {
                Method declaredMethod = cls.getDeclaredMethod("setLayoutDirection", new Class[]{Integer.TYPE});
                f2248a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException e) {
                Log.i("DrawableCompat", "Failed to retrieve setLayoutDirection(int) method", e);
            }
            f2249b = true;
        }
        Method method = f2248a;
        if (method != null) {
            try {
                method.invoke(drawable, new Object[]{Integer.valueOf(i)});
                return true;
            } catch (Exception e2) {
                Log.i("DrawableCompat", "Failed to invoke setLayoutDirection(int) via reflection", e2);
                f2248a = null;
            }
        }
        return false;
    }

    /* renamed from: d */
    public static void m2222d(Drawable drawable, int i) {
        drawable.setTint(i);
    }

    /* renamed from: e */
    public static void m2223e(Drawable drawable, ColorStateList colorStateList) {
        drawable.setTintList(colorStateList);
    }

    /* renamed from: f */
    public static void m2224f(Drawable drawable, PorterDuff.Mode mode) {
        drawable.setTintMode(mode);
    }

    /* renamed from: g */
    public static <T extends Drawable> T m2225g(Drawable drawable) {
        return drawable instanceof C0489c ? ((C0489c) drawable).mo2328b() : drawable;
    }

    /* renamed from: h */
    public static Drawable m2226h(Drawable drawable) {
        return (Build.VERSION.SDK_INT < 23 && !(drawable instanceof C0488b)) ? new C0491e(drawable) : drawable;
    }
}
