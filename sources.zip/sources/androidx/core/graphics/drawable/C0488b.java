package androidx.core.graphics.drawable;

/* renamed from: androidx.core.graphics.drawable.b */
public interface C0488b {
}
