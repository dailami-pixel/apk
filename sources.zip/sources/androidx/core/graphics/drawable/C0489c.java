package androidx.core.graphics.drawable;

import android.graphics.drawable.Drawable;

/* renamed from: androidx.core.graphics.drawable.c */
public interface C0489c {
    /* renamed from: a */
    void mo2327a(Drawable drawable);

    /* renamed from: b */
    Drawable mo2328b();
}
