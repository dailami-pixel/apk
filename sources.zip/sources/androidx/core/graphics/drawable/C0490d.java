package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;

/* renamed from: androidx.core.graphics.drawable.d */
class C0490d extends Drawable implements Drawable.Callback, C0489c, C0488b {

    /* renamed from: a */
    static final PorterDuff.Mode f2252a = PorterDuff.Mode.SRC_IN;

    /* renamed from: b */
    private int f2253b;

    /* renamed from: c */
    private PorterDuff.Mode f2254c;

    /* renamed from: d */
    private boolean f2255d;

    /* renamed from: e */
    C0492f f2256e;

    /* renamed from: f */
    private boolean f2257f;

    /* renamed from: g */
    Drawable f2258g;

    C0490d(Drawable drawable) {
        this.f2256e = new C0492f(this.f2256e);
        mo2327a(drawable);
    }

    /* renamed from: d */
    private boolean m2229d(int[] iArr) {
        if (!mo2329c()) {
            return false;
        }
        C0492f fVar = this.f2256e;
        ColorStateList colorStateList = fVar.f2262c;
        PorterDuff.Mode mode = fVar.f2263d;
        if (colorStateList == null || mode == null) {
            this.f2255d = false;
            clearColorFilter();
        } else {
            int colorForState = colorStateList.getColorForState(iArr, colorStateList.getDefaultColor());
            if (!(this.f2255d && colorForState == this.f2253b && mode == this.f2254c)) {
                setColorFilter(colorForState, mode);
                this.f2253b = colorForState;
                this.f2254c = mode;
                this.f2255d = true;
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    public final void mo2327a(Drawable drawable) {
        Drawable drawable2 = this.f2258g;
        if (drawable2 != null) {
            drawable2.setCallback((Drawable.Callback) null);
        }
        this.f2258g = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            setVisible(drawable.isVisible(), true);
            setState(drawable.getState());
            setLevel(drawable.getLevel());
            setBounds(drawable.getBounds());
            C0492f fVar = this.f2256e;
            if (fVar != null) {
                fVar.f2261b = drawable.getConstantState();
            }
        }
        invalidateSelf();
    }

    /* renamed from: b */
    public final Drawable mo2328b() {
        return this.f2258g;
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public boolean mo2329c() {
        throw null;
    }

    public void draw(Canvas canvas) {
        this.f2258g.draw(canvas);
    }

    public int getChangingConfigurations() {
        int changingConfigurations = super.getChangingConfigurations();
        C0492f fVar = this.f2256e;
        return changingConfigurations | (fVar != null ? fVar.getChangingConfigurations() : 0) | this.f2258g.getChangingConfigurations();
    }

    public Drawable.ConstantState getConstantState() {
        C0492f fVar = this.f2256e;
        if (fVar == null) {
            return null;
        }
        if (!(fVar.f2261b != null)) {
            return null;
        }
        fVar.f2260a = getChangingConfigurations();
        return this.f2256e;
    }

    public Drawable getCurrent() {
        return this.f2258g.getCurrent();
    }

    public int getIntrinsicHeight() {
        return this.f2258g.getIntrinsicHeight();
    }

    public int getIntrinsicWidth() {
        return this.f2258g.getIntrinsicWidth();
    }

    public int getMinimumHeight() {
        return this.f2258g.getMinimumHeight();
    }

    public int getMinimumWidth() {
        return this.f2258g.getMinimumWidth();
    }

    public int getOpacity() {
        return this.f2258g.getOpacity();
    }

    public boolean getPadding(Rect rect) {
        return this.f2258g.getPadding(rect);
    }

    public int[] getState() {
        return this.f2258g.getState();
    }

    public Region getTransparentRegion() {
        return this.f2258g.getTransparentRegion();
    }

    public void invalidateDrawable(Drawable drawable) {
        invalidateSelf();
    }

    public boolean isAutoMirrored() {
        return this.f2258g.isAutoMirrored();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r1.f2256e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean isStateful() {
        /*
            r1 = this;
            boolean r0 = r1.mo2329c()
            if (r0 == 0) goto L_0x000d
            androidx.core.graphics.drawable.f r0 = r1.f2256e
            if (r0 == 0) goto L_0x000d
            android.content.res.ColorStateList r0 = r0.f2262c
            goto L_0x000e
        L_0x000d:
            r0 = 0
        L_0x000e:
            if (r0 == 0) goto L_0x0016
            boolean r0 = r0.isStateful()
            if (r0 != 0) goto L_0x001e
        L_0x0016:
            android.graphics.drawable.Drawable r0 = r1.f2258g
            boolean r0 = r0.isStateful()
            if (r0 == 0) goto L_0x0020
        L_0x001e:
            r0 = 1
            goto L_0x0021
        L_0x0020:
            r0 = 0
        L_0x0021:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.C0490d.isStateful():boolean");
    }

    public void jumpToCurrentState() {
        this.f2258g.jumpToCurrentState();
    }

    public Drawable mutate() {
        if (!this.f2257f && super.mutate() == this) {
            this.f2256e = new C0492f(this.f2256e);
            Drawable drawable = this.f2258g;
            if (drawable != null) {
                drawable.mutate();
            }
            C0492f fVar = this.f2256e;
            if (fVar != null) {
                Drawable drawable2 = this.f2258g;
                fVar.f2261b = drawable2 != null ? drawable2.getConstantState() : null;
            }
            this.f2257f = true;
        }
        return this;
    }

    /* access modifiers changed from: protected */
    public void onBoundsChange(Rect rect) {
        Drawable drawable = this.f2258g;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    /* access modifiers changed from: protected */
    public boolean onLevelChange(int i) {
        return this.f2258g.setLevel(i);
    }

    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
        scheduleSelf(runnable, j);
    }

    public void setAlpha(int i) {
        this.f2258g.setAlpha(i);
    }

    public void setAutoMirrored(boolean z) {
        this.f2258g.setAutoMirrored(z);
    }

    public void setChangingConfigurations(int i) {
        this.f2258g.setChangingConfigurations(i);
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f2258g.setColorFilter(colorFilter);
    }

    public void setDither(boolean z) {
        this.f2258g.setDither(z);
    }

    public void setFilterBitmap(boolean z) {
        this.f2258g.setFilterBitmap(z);
    }

    public boolean setState(int[] iArr) {
        return m2229d(iArr) || this.f2258g.setState(iArr);
    }

    public void setTint(int i) {
        setTintList(ColorStateList.valueOf(i));
    }

    public void setTintList(ColorStateList colorStateList) {
        this.f2256e.f2262c = colorStateList;
        m2229d(getState());
    }

    public void setTintMode(PorterDuff.Mode mode) {
        this.f2256e.f2263d = mode;
        m2229d(getState());
    }

    public boolean setVisible(boolean z, boolean z2) {
        return super.setVisible(z, z2) || this.f2258g.setVisible(z, z2);
    }

    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        unscheduleSelf(runnable);
    }

    C0490d(C0492f fVar, Resources resources) {
        Drawable.ConstantState constantState;
        this.f2256e = fVar;
        if (fVar != null && (constantState = fVar.f2261b) != null) {
            mo2327a(constantState.newDrawable(resources));
        }
    }
}
