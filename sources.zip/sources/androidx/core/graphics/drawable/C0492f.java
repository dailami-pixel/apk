package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;

/* renamed from: androidx.core.graphics.drawable.f */
final class C0492f extends Drawable.ConstantState {

    /* renamed from: a */
    int f2260a;

    /* renamed from: b */
    Drawable.ConstantState f2261b;

    /* renamed from: c */
    ColorStateList f2262c = null;

    /* renamed from: d */
    PorterDuff.Mode f2263d = C0490d.f2252a;

    C0492f(C0492f fVar) {
        if (fVar != null) {
            this.f2260a = fVar.f2260a;
            this.f2261b = fVar.f2261b;
            this.f2262c = fVar.f2262c;
            this.f2263d = fVar.f2263d;
        }
    }

    public int getChangingConfigurations() {
        int i = this.f2260a;
        Drawable.ConstantState constantState = this.f2261b;
        return i | (constantState != null ? constantState.getChangingConfigurations() : 0);
    }

    public Drawable newDrawable() {
        return new C0491e(this, (Resources) null);
    }

    public Drawable newDrawable(Resources resources) {
        return new C0491e(this, resources);
    }
}
