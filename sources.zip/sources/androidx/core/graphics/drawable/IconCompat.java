package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;

public class IconCompat extends CustomVersionedParcelable {

    /* renamed from: a */
    static final PorterDuff.Mode f2238a = PorterDuff.Mode.SRC_IN;

    /* renamed from: b */
    public int f2239b = -1;

    /* renamed from: c */
    Object f2240c;

    /* renamed from: d */
    public byte[] f2241d = null;

    /* renamed from: e */
    public Parcelable f2242e = null;

    /* renamed from: f */
    public int f2243f = 0;

    /* renamed from: g */
    public int f2244g = 0;

    /* renamed from: h */
    public ColorStateList f2245h = null;

    /* renamed from: i */
    PorterDuff.Mode f2246i = f2238a;

    /* renamed from: j */
    public String f2247j = null;

    public IconCompat() {
    }

    private IconCompat(int i) {
        this.f2239b = i;
    }

    /* renamed from: a */
    static Bitmap m2211a(Bitmap bitmap, boolean z) {
        int min = (int) (((float) Math.min(bitmap.getWidth(), bitmap.getHeight())) * 0.6666667f);
        Bitmap createBitmap = Bitmap.createBitmap(min, min, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Paint paint = new Paint(3);
        float f = (float) min;
        float f2 = 0.5f * f;
        float f3 = 0.9166667f * f2;
        if (z) {
            float f4 = 0.010416667f * f;
            paint.setColor(0);
            paint.setShadowLayer(f4, 0.0f, f * 0.020833334f, 1023410176);
            canvas.drawCircle(f2, f2, f3, paint);
            paint.setShadowLayer(f4, 0.0f, 0.0f, 503316480);
            canvas.drawCircle(f2, f2, f3, paint);
            paint.clearShadowLayer();
        }
        paint.setColor(-16777216);
        Shader.TileMode tileMode = Shader.TileMode.CLAMP;
        BitmapShader bitmapShader = new BitmapShader(bitmap, tileMode, tileMode);
        Matrix matrix = new Matrix();
        matrix.setTranslate((float) ((-(bitmap.getWidth() - min)) / 2), (float) ((-(bitmap.getHeight() - min)) / 2));
        bitmapShader.setLocalMatrix(matrix);
        paint.setShader(bitmapShader);
        canvas.drawCircle(f2, f2, f3, paint);
        canvas.setBitmap((Bitmap) null);
        return createBitmap;
    }

    /* renamed from: b */
    public static IconCompat m2212b(Resources resources, String str, int i) {
        if (str == null) {
            throw new IllegalArgumentException("Package must not be null.");
        } else if (i != 0) {
            IconCompat iconCompat = new IconCompat(2);
            iconCompat.f2243f = i;
            if (resources != null) {
                try {
                    iconCompat.f2240c = resources.getResourceName(i);
                } catch (Resources.NotFoundException unused) {
                    throw new IllegalArgumentException("Icon resource cannot be found");
                }
            } else {
                iconCompat.f2240c = str;
            }
            return iconCompat;
        } else {
            throw new IllegalArgumentException("Drawable resource ID must not be 0");
        }
    }

    /* renamed from: g */
    private InputStream m2213g(Context context) {
        String str;
        StringBuilder sb;
        Uri f = mo2324f();
        String scheme = f.getScheme();
        if ("content".equals(scheme) || "file".equals(scheme)) {
            try {
                return context.getContentResolver().openInputStream(f);
            } catch (Exception e) {
                e = e;
                sb = new StringBuilder();
                str = "Unable to load image from URI: ";
                sb.append(str);
                sb.append(f);
                Log.w("IconCompat", sb.toString(), e);
                return null;
            }
        } else {
            try {
                return new FileInputStream(new File((String) this.f2240c));
            } catch (FileNotFoundException e2) {
                e = e2;
                sb = new StringBuilder();
                str = "Unable to load image from path: ";
                sb.append(str);
                sb.append(f);
                Log.w("IconCompat", sb.toString(), e);
                return null;
            }
        }
    }

    /* renamed from: c */
    public int mo2321c() {
        int i;
        int i2 = this.f2239b;
        if (i2 == -1 && (i = Build.VERSION.SDK_INT) >= 23) {
            Icon icon = (Icon) this.f2240c;
            if (i >= 28) {
                return icon.getResId();
            }
            try {
                return ((Integer) icon.getClass().getMethod("getResId", new Class[0]).invoke(icon, new Object[0])).intValue();
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                Log.e("IconCompat", "Unable to get icon resource", e);
                return 0;
            }
        } else if (i2 == 2) {
            return this.f2243f;
        } else {
            throw new IllegalStateException("called getResId() on " + this);
        }
    }

    /* renamed from: d */
    public String mo2322d() {
        int i;
        int i2 = this.f2239b;
        if (i2 == -1 && (i = Build.VERSION.SDK_INT) >= 23) {
            Icon icon = (Icon) this.f2240c;
            if (i >= 28) {
                return icon.getResPackage();
            }
            try {
                return (String) icon.getClass().getMethod("getResPackage", new Class[0]).invoke(icon, new Object[0]);
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                Log.e("IconCompat", "Unable to get icon package", e);
                return null;
            }
        } else if (i2 == 2) {
            return ((String) this.f2240c).split(":", -1)[0];
        } else {
            throw new IllegalStateException("called getResPackage() on " + this);
        }
    }

    /* renamed from: e */
    public int mo2323e() {
        int i;
        StringBuilder sb;
        int i2 = this.f2239b;
        if (i2 != -1 || (i = Build.VERSION.SDK_INT) < 23) {
            return i2;
        }
        Icon icon = (Icon) this.f2240c;
        if (i >= 28) {
            return icon.getType();
        }
        try {
            return ((Integer) icon.getClass().getMethod("getType", new Class[0]).invoke(icon, new Object[0])).intValue();
        } catch (IllegalAccessException e) {
            e = e;
            sb = new StringBuilder();
            sb.append("Unable to get icon type ");
            sb.append(icon);
            Log.e("IconCompat", sb.toString(), e);
            return -1;
        } catch (InvocationTargetException e2) {
            e = e2;
            sb = new StringBuilder();
            sb.append("Unable to get icon type ");
            sb.append(icon);
            Log.e("IconCompat", sb.toString(), e);
            return -1;
        } catch (NoSuchMethodException e3) {
            e = e3;
            sb = new StringBuilder();
            sb.append("Unable to get icon type ");
            sb.append(icon);
            Log.e("IconCompat", sb.toString(), e);
            return -1;
        }
    }

    /* renamed from: f */
    public Uri mo2324f() {
        int i;
        int i2 = this.f2239b;
        if (i2 == -1 && (i = Build.VERSION.SDK_INT) >= 23) {
            Icon icon = (Icon) this.f2240c;
            if (i >= 28) {
                return icon.getUri();
            }
            try {
                return (Uri) icon.getClass().getMethod("getUri", new Class[0]).invoke(icon, new Object[0]);
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                Log.e("IconCompat", "Unable to get icon uri", e);
                return null;
            }
        } else if (i2 == 4 || i2 == 6) {
            return Uri.parse((String) this.f2240c);
        } else {
            throw new IllegalStateException("called getUri() on " + this);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0057, code lost:
        r4 = android.graphics.drawable.Icon.createWithAdaptiveBitmap(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0060, code lost:
        r4 = m2211a(r4, false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x008a, code lost:
        r4 = android.graphics.drawable.Icon.createWithBitmap(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x008e, code lost:
        r0 = r3.f2245h;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0090, code lost:
        if (r0 == null) goto L_0x0095;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0092, code lost:
        r4.setTintList(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0095, code lost:
        r0 = r3.f2246i;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0099, code lost:
        if (r0 == f2238a) goto L_0x009e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x009b, code lost:
        r4.setTintMode(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x009e, code lost:
        return r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x001e, code lost:
        if (r0 >= 26) goto L_0x0057;
     */
    /* renamed from: h */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.graphics.drawable.Icon mo2325h(android.content.Context r4) {
        /*
            r3 = this;
            int r0 = r3.f2239b
            r1 = 0
            r2 = 26
            switch(r0) {
                case -1: goto L_0x009f;
                case 0: goto L_0x0008;
                case 1: goto L_0x0086;
                case 2: goto L_0x007b;
                case 3: goto L_0x006e;
                case 4: goto L_0x0065;
                case 5: goto L_0x004f;
                case 6: goto L_0x0010;
                default: goto L_0x0008;
            }
        L_0x0008:
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Unknown type"
            r4.<init>(r0)
            throw r4
        L_0x0010:
            if (r4 == 0) goto L_0x0038
            java.io.InputStream r4 = r3.m2213g(r4)
            if (r4 == 0) goto L_0x0021
            int r0 = android.os.Build.VERSION.SDK_INT
            android.graphics.Bitmap r4 = android.graphics.BitmapFactory.decodeStream(r4)
            if (r0 < r2) goto L_0x0060
            goto L_0x0057
        L_0x0021:
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
            java.lang.String r0 = "Cannot load adaptive icon from uri: "
            java.lang.StringBuilder r0 = p165e.p166a.p167a.p168a.C4924a.m17863P(r0)
            android.net.Uri r1 = r3.mo2324f()
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r4.<init>(r0)
            throw r4
        L_0x0038:
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Context is required to resolve the file uri of the icon: "
            java.lang.StringBuilder r0 = p165e.p166a.p167a.p168a.C4924a.m17863P(r0)
            android.net.Uri r1 = r3.mo2324f()
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r4.<init>(r0)
            throw r4
        L_0x004f:
            int r4 = android.os.Build.VERSION.SDK_INT
            if (r4 < r2) goto L_0x005c
            java.lang.Object r4 = r3.f2240c
            android.graphics.Bitmap r4 = (android.graphics.Bitmap) r4
        L_0x0057:
            android.graphics.drawable.Icon r4 = android.graphics.drawable.Icon.createWithAdaptiveBitmap(r4)
            goto L_0x008e
        L_0x005c:
            java.lang.Object r4 = r3.f2240c
            android.graphics.Bitmap r4 = (android.graphics.Bitmap) r4
        L_0x0060:
            android.graphics.Bitmap r4 = m2211a(r4, r1)
            goto L_0x008a
        L_0x0065:
            java.lang.Object r4 = r3.f2240c
            java.lang.String r4 = (java.lang.String) r4
            android.graphics.drawable.Icon r4 = android.graphics.drawable.Icon.createWithContentUri(r4)
            goto L_0x008e
        L_0x006e:
            java.lang.Object r4 = r3.f2240c
            byte[] r4 = (byte[]) r4
            int r0 = r3.f2243f
            int r1 = r3.f2244g
            android.graphics.drawable.Icon r4 = android.graphics.drawable.Icon.createWithData(r4, r0, r1)
            goto L_0x008e
        L_0x007b:
            java.lang.String r4 = r3.mo2322d()
            int r0 = r3.f2243f
            android.graphics.drawable.Icon r4 = android.graphics.drawable.Icon.createWithResource(r4, r0)
            goto L_0x008e
        L_0x0086:
            java.lang.Object r4 = r3.f2240c
            android.graphics.Bitmap r4 = (android.graphics.Bitmap) r4
        L_0x008a:
            android.graphics.drawable.Icon r4 = android.graphics.drawable.Icon.createWithBitmap(r4)
        L_0x008e:
            android.content.res.ColorStateList r0 = r3.f2245h
            if (r0 == 0) goto L_0x0095
            r4.setTintList(r0)
        L_0x0095:
            android.graphics.PorterDuff$Mode r0 = r3.f2246i
            android.graphics.PorterDuff$Mode r1 = f2238a
            if (r0 == r1) goto L_0x009e
            r4.setTintMode(r0)
        L_0x009e:
            return r4
        L_0x009f:
            java.lang.Object r4 = r3.f2240c
            android.graphics.drawable.Icon r4 = (android.graphics.drawable.Icon) r4
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompat.mo2325h(android.content.Context):android.graphics.drawable.Icon");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String toString() {
        /*
            r4 = this;
            int r0 = r4.f2239b
            r1 = -1
            if (r0 != r1) goto L_0x000c
            java.lang.Object r0 = r4.f2240c
            java.lang.String r0 = java.lang.String.valueOf(r0)
            return r0
        L_0x000c:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Icon(typ="
            r0.<init>(r1)
            int r1 = r4.f2239b
            switch(r1) {
                case 1: goto L_0x002a;
                case 2: goto L_0x0027;
                case 3: goto L_0x0024;
                case 4: goto L_0x0021;
                case 5: goto L_0x001e;
                case 6: goto L_0x001b;
                default: goto L_0x0018;
            }
        L_0x0018:
            java.lang.String r1 = "UNKNOWN"
            goto L_0x002c
        L_0x001b:
            java.lang.String r1 = "URI_MASKABLE"
            goto L_0x002c
        L_0x001e:
            java.lang.String r1 = "BITMAP_MASKABLE"
            goto L_0x002c
        L_0x0021:
            java.lang.String r1 = "URI"
            goto L_0x002c
        L_0x0024:
            java.lang.String r1 = "DATA"
            goto L_0x002c
        L_0x0027:
            java.lang.String r1 = "RESOURCE"
            goto L_0x002c
        L_0x002a:
            java.lang.String r1 = "BITMAP"
        L_0x002c:
            r0.append(r1)
            int r1 = r4.f2239b
            switch(r1) {
                case 1: goto L_0x007f;
                case 2: goto L_0x0056;
                case 3: goto L_0x0040;
                case 4: goto L_0x0035;
                case 5: goto L_0x007f;
                case 6: goto L_0x0035;
                default: goto L_0x0034;
            }
        L_0x0034:
            goto L_0x009f
        L_0x0035:
            java.lang.String r1 = " uri="
            r0.append(r1)
            java.lang.Object r1 = r4.f2240c
            r0.append(r1)
            goto L_0x009f
        L_0x0040:
            java.lang.String r1 = " len="
            r0.append(r1)
            int r1 = r4.f2243f
            r0.append(r1)
            int r1 = r4.f2244g
            if (r1 == 0) goto L_0x009f
            java.lang.String r1 = " off="
            r0.append(r1)
            int r1 = r4.f2244g
            goto L_0x009c
        L_0x0056:
            java.lang.String r1 = " pkg="
            r0.append(r1)
            java.lang.String r1 = r4.mo2322d()
            r0.append(r1)
            java.lang.String r1 = " id="
            r0.append(r1)
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = 0
            int r3 = r4.mo2321c()
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r1[r2] = r3
            java.lang.String r2 = "0x%08x"
            java.lang.String r1 = java.lang.String.format(r2, r1)
            r0.append(r1)
            goto L_0x009f
        L_0x007f:
            java.lang.String r1 = " size="
            r0.append(r1)
            java.lang.Object r1 = r4.f2240c
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getWidth()
            r0.append(r1)
            java.lang.String r1 = "x"
            r0.append(r1)
            java.lang.Object r1 = r4.f2240c
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getHeight()
        L_0x009c:
            r0.append(r1)
        L_0x009f:
            android.content.res.ColorStateList r1 = r4.f2245h
            if (r1 == 0) goto L_0x00ad
            java.lang.String r1 = " tint="
            r0.append(r1)
            android.content.res.ColorStateList r1 = r4.f2245h
            r0.append(r1)
        L_0x00ad:
            android.graphics.PorterDuff$Mode r1 = r4.f2246i
            android.graphics.PorterDuff$Mode r2 = f2238a
            if (r1 == r2) goto L_0x00bd
            java.lang.String r1 = " mode="
            r0.append(r1)
            android.graphics.PorterDuff$Mode r1 = r4.f2246i
            r0.append(r1)
        L_0x00bd:
            java.lang.String r1 = ")"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompat.toString():java.lang.String");
    }
}
