package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import androidx.versionedparcelable.C1389a;
import java.nio.charset.Charset;
import java.util.Objects;

public class IconCompatParcelizer {
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static androidx.core.graphics.drawable.IconCompat read(androidx.versionedparcelable.C1389a r4) {
        /*
            androidx.core.graphics.drawable.IconCompat r0 = new androidx.core.graphics.drawable.IconCompat
            r0.<init>()
            int r1 = r0.f2239b
            r2 = 1
            int r1 = r4.mo5661n(r1, r2)
            r0.f2239b = r1
            byte[] r1 = r0.f2241d
            r2 = 2
            byte[] r1 = r4.mo5656i(r1, r2)
            r0.f2241d = r1
            android.os.Parcelable r1 = r0.f2242e
            r2 = 3
            android.os.Parcelable r1 = r4.mo5663p(r1, r2)
            r0.f2242e = r1
            int r1 = r0.f2243f
            r3 = 4
            int r1 = r4.mo5661n(r1, r3)
            r0.f2243f = r1
            int r1 = r0.f2244g
            r3 = 5
            int r1 = r4.mo5661n(r1, r3)
            r0.f2244g = r1
            android.content.res.ColorStateList r1 = r0.f2245h
            r3 = 6
            android.os.Parcelable r1 = r4.mo5663p(r1, r3)
            android.content.res.ColorStateList r1 = (android.content.res.ColorStateList) r1
            r0.f2245h = r1
            java.lang.String r1 = r0.f2247j
            r3 = 7
            java.lang.String r4 = r4.mo5665r(r1, r3)
            r0.f2247j = r4
            android.graphics.PorterDuff$Mode r4 = android.graphics.PorterDuff.Mode.valueOf(r4)
            r0.f2246i = r4
            int r4 = r0.f2239b
            switch(r4) {
                case -1: goto L_0x0079;
                case 0: goto L_0x0051;
                case 1: goto L_0x0067;
                case 2: goto L_0x0057;
                case 3: goto L_0x0052;
                case 4: goto L_0x0057;
                case 5: goto L_0x0067;
                case 6: goto L_0x0057;
                default: goto L_0x0051;
            }
        L_0x0051:
            goto L_0x0088
        L_0x0052:
            byte[] r4 = r0.f2241d
            r0.f2240c = r4
            goto L_0x0088
        L_0x0057:
            java.lang.String r4 = new java.lang.String
            byte[] r1 = r0.f2241d
            java.lang.String r2 = "UTF-16"
            java.nio.charset.Charset r2 = java.nio.charset.Charset.forName(r2)
            r4.<init>(r1, r2)
            r0.f2240c = r4
            goto L_0x0088
        L_0x0067:
            android.os.Parcelable r4 = r0.f2242e
            if (r4 == 0) goto L_0x006c
            goto L_0x007d
        L_0x006c:
            byte[] r4 = r0.f2241d
            r0.f2240c = r4
            r0.f2239b = r2
            r1 = 0
            r0.f2243f = r1
            int r4 = r4.length
            r0.f2244g = r4
            goto L_0x0088
        L_0x0079:
            android.os.Parcelable r4 = r0.f2242e
            if (r4 == 0) goto L_0x0080
        L_0x007d:
            r0.f2240c = r4
            goto L_0x0088
        L_0x0080:
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Invalid icon"
            r4.<init>(r0)
            throw r4
        L_0x0088:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompatParcelizer.read(androidx.versionedparcelable.a):androidx.core.graphics.drawable.IconCompat");
    }

    public static void write(IconCompat iconCompat, C1389a aVar) {
        Objects.requireNonNull(aVar);
        iconCompat.f2247j = iconCompat.f2246i.name();
        switch (iconCompat.f2239b) {
            case -1:
            case 1:
            case 5:
                iconCompat.f2242e = (Parcelable) iconCompat.f2240c;
                break;
            case 2:
                iconCompat.f2241d = ((String) iconCompat.f2240c).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f2241d = (byte[]) iconCompat.f2240c;
                break;
            case 4:
            case 6:
                iconCompat.f2241d = iconCompat.f2240c.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i = iconCompat.f2239b;
        if (-1 != i) {
            aVar.mo5644C(i, 1);
        }
        byte[] bArr = iconCompat.f2241d;
        if (bArr != null) {
            aVar.mo5672y(bArr, 2);
        }
        Parcelable parcelable = iconCompat.f2242e;
        if (parcelable != null) {
            aVar.mo5646E(parcelable, 3);
        }
        int i2 = iconCompat.f2243f;
        if (i2 != 0) {
            aVar.mo5644C(i2, 4);
        }
        int i3 = iconCompat.f2244g;
        if (i3 != 0) {
            aVar.mo5644C(i3, 5);
        }
        ColorStateList colorStateList = iconCompat.f2245h;
        if (colorStateList != null) {
            aVar.mo5646E(colorStateList, 6);
        }
        String str = iconCompat.f2247j;
        if (str != null) {
            aVar.mo5648G(str, 7);
        }
    }
}
