package androidx.core.widget;

import android.content.res.Resources;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import java.util.Objects;
import p098d.p120g.p130j.C4761m;

/* renamed from: androidx.core.widget.a */
public abstract class C0498a implements View.OnTouchListener {

    /* renamed from: a */
    private static final int f2297a = ViewConfiguration.getTapTimeout();

    /* renamed from: b */
    final C0499a f2298b;

    /* renamed from: c */
    private final Interpolator f2299c = new AccelerateInterpolator();

    /* renamed from: d */
    final View f2300d;

    /* renamed from: e */
    private Runnable f2301e;

    /* renamed from: f */
    private float[] f2302f = {0.0f, 0.0f};

    /* renamed from: g */
    private float[] f2303g = {Float.MAX_VALUE, Float.MAX_VALUE};

    /* renamed from: h */
    private int f2304h;

    /* renamed from: i */
    private int f2305i;

    /* renamed from: j */
    private float[] f2306j = {0.0f, 0.0f};

    /* renamed from: k */
    private float[] f2307k = {0.0f, 0.0f};

    /* renamed from: l */
    private float[] f2308l = {Float.MAX_VALUE, Float.MAX_VALUE};

    /* renamed from: m */
    private boolean f2309m;

    /* renamed from: n */
    boolean f2310n;

    /* renamed from: o */
    boolean f2311o;

    /* renamed from: p */
    boolean f2312p;

    /* renamed from: q */
    private boolean f2313q;

    /* renamed from: androidx.core.widget.a$a */
    private static class C0499a {

        /* renamed from: a */
        private int f2314a;

        /* renamed from: b */
        private int f2315b;

        /* renamed from: c */
        private float f2316c;

        /* renamed from: d */
        private float f2317d;

        /* renamed from: e */
        private long f2318e = Long.MIN_VALUE;

        /* renamed from: f */
        private long f2319f = 0;

        /* renamed from: g */
        private int f2320g = 0;

        /* renamed from: h */
        private int f2321h = 0;

        /* renamed from: i */
        private long f2322i = -1;

        /* renamed from: j */
        private float f2323j;

        /* renamed from: k */
        private int f2324k;

        C0499a() {
        }

        /* renamed from: e */
        private float m2279e(long j) {
            long j2 = this.f2318e;
            if (j < j2) {
                return 0.0f;
            }
            long j3 = this.f2322i;
            if (j3 < 0 || j < j3) {
                return C0498a.m2273c(((float) (j - j2)) / ((float) this.f2314a), 0.0f, 1.0f) * 0.5f;
            }
            float f = this.f2323j;
            return (f * C0498a.m2273c(((float) (j - j3)) / ((float) this.f2324k), 0.0f, 1.0f)) + (1.0f - f);
        }

        /* renamed from: a */
        public void mo2451a() {
            if (this.f2319f != 0) {
                long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
                float e = m2279e(currentAnimationTimeMillis);
                this.f2319f = currentAnimationTimeMillis;
                float f = ((float) (currentAnimationTimeMillis - this.f2319f)) * ((e * 4.0f) + (-4.0f * e * e));
                this.f2320g = (int) (this.f2316c * f);
                this.f2321h = (int) (f * this.f2317d);
                return;
            }
            throw new RuntimeException("Cannot compute scroll delta before calling start()");
        }

        /* renamed from: b */
        public int mo2452b() {
            return this.f2320g;
        }

        /* renamed from: c */
        public int mo2453c() {
            return this.f2321h;
        }

        /* renamed from: d */
        public int mo2454d() {
            float f = this.f2316c;
            return (int) (f / Math.abs(f));
        }

        /* renamed from: f */
        public int mo2455f() {
            float f = this.f2317d;
            return (int) (f / Math.abs(f));
        }

        /* renamed from: g */
        public boolean mo2456g() {
            return this.f2322i > 0 && AnimationUtils.currentAnimationTimeMillis() > this.f2322i + ((long) this.f2324k);
        }

        /* renamed from: h */
        public void mo2457h() {
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            int i = (int) (currentAnimationTimeMillis - this.f2318e);
            int i2 = this.f2315b;
            if (i > i2) {
                i = i2;
            } else if (i < 0) {
                i = 0;
            }
            this.f2324k = i;
            this.f2323j = m2279e(currentAnimationTimeMillis);
            this.f2322i = currentAnimationTimeMillis;
        }

        /* renamed from: i */
        public void mo2458i(int i) {
            this.f2315b = i;
        }

        /* renamed from: j */
        public void mo2459j(int i) {
            this.f2314a = i;
        }

        /* renamed from: k */
        public void mo2460k(float f, float f2) {
            this.f2316c = f;
            this.f2317d = f2;
        }

        /* renamed from: l */
        public void mo2461l() {
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            this.f2318e = currentAnimationTimeMillis;
            this.f2322i = -1;
            this.f2319f = currentAnimationTimeMillis;
            this.f2323j = 0.5f;
            this.f2320g = 0;
            this.f2321h = 0;
        }
    }

    /* renamed from: androidx.core.widget.a$b */
    private class C0500b implements Runnable {
        C0500b() {
        }

        public void run() {
            C0498a aVar = C0498a.this;
            if (aVar.f2312p) {
                if (aVar.f2310n) {
                    aVar.f2310n = false;
                    aVar.f2298b.mo2461l();
                }
                C0499a aVar2 = C0498a.this.f2298b;
                if (aVar2.mo2456g() || !C0498a.this.mo2449g()) {
                    C0498a.this.f2312p = false;
                    return;
                }
                C0498a aVar3 = C0498a.this;
                if (aVar3.f2311o) {
                    aVar3.f2311o = false;
                    Objects.requireNonNull(aVar3);
                    long uptimeMillis = SystemClock.uptimeMillis();
                    MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                    aVar3.f2300d.onTouchEvent(obtain);
                    obtain.recycle();
                }
                aVar2.mo2451a();
                C0498a.this.mo2447e(aVar2.mo2452b(), aVar2.mo2453c());
                View view = C0498a.this.f2300d;
                int i = C4761m.f17241f;
                view.postOnAnimation(this);
            }
        }
    }

    public C0498a(View view) {
        C0499a aVar = new C0499a();
        this.f2298b = aVar;
        this.f2300d = view;
        float f = Resources.getSystem().getDisplayMetrics().density;
        float[] fArr = this.f2308l;
        float f2 = ((float) ((int) ((1575.0f * f) + 0.5f))) / 1000.0f;
        fArr[0] = f2;
        fArr[1] = f2;
        float[] fArr2 = this.f2307k;
        float f3 = ((float) ((int) ((f * 315.0f) + 0.5f))) / 1000.0f;
        fArr2[0] = f3;
        fArr2[1] = f3;
        this.f2304h = 1;
        float[] fArr3 = this.f2303g;
        fArr3[0] = Float.MAX_VALUE;
        fArr3[1] = Float.MAX_VALUE;
        float[] fArr4 = this.f2302f;
        fArr4[0] = 0.2f;
        fArr4[1] = 0.2f;
        float[] fArr5 = this.f2306j;
        fArr5[0] = 0.001f;
        fArr5[1] = 0.001f;
        this.f2305i = f2297a;
        aVar.mo2459j(500);
        aVar.mo2458i(500);
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x003e A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x003f  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private float m2272b(int r4, float r5, float r6, float r7) {
        /*
            r3 = this;
            float[] r0 = r3.f2302f
            r0 = r0[r4]
            float[] r1 = r3.f2303g
            r1 = r1[r4]
            float r0 = r0 * r6
            r2 = 0
            float r0 = m2273c(r0, r2, r1)
            float r1 = r3.m2274d(r5, r0)
            float r6 = r6 - r5
            float r5 = r3.m2274d(r6, r0)
            float r5 = r5 - r1
            int r6 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1))
            if (r6 >= 0) goto L_0x0026
            android.view.animation.Interpolator r6 = r3.f2299c
            float r5 = -r5
            float r5 = r6.getInterpolation(r5)
            float r5 = -r5
            goto L_0x0030
        L_0x0026:
            int r6 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1))
            if (r6 <= 0) goto L_0x0039
            android.view.animation.Interpolator r6 = r3.f2299c
            float r5 = r6.getInterpolation(r5)
        L_0x0030:
            r6 = -1082130432(0xffffffffbf800000, float:-1.0)
            r0 = 1065353216(0x3f800000, float:1.0)
            float r5 = m2273c(r5, r6, r0)
            goto L_0x003a
        L_0x0039:
            r5 = 0
        L_0x003a:
            int r6 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1))
            if (r6 != 0) goto L_0x003f
            return r2
        L_0x003f:
            float[] r0 = r3.f2306j
            r0 = r0[r4]
            float[] r1 = r3.f2307k
            r1 = r1[r4]
            float[] r2 = r3.f2308l
            r4 = r2[r4]
            float r0 = r0 * r7
            if (r6 <= 0) goto L_0x0056
            float r5 = r5 * r0
            float r4 = m2273c(r5, r1, r4)
            return r4
        L_0x0056:
            float r5 = -r5
            float r5 = r5 * r0
            float r4 = m2273c(r5, r1, r4)
            float r4 = -r4
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.C0498a.m2272b(int, float, float, float):float");
    }

    /* renamed from: c */
    static float m2273c(float f, float f2, float f3) {
        return f > f3 ? f3 : f < f2 ? f2 : f;
    }

    /* renamed from: d */
    private float m2274d(float f, float f2) {
        if (f2 == 0.0f) {
            return 0.0f;
        }
        int i = this.f2304h;
        if (i == 0 || i == 1) {
            if (f < f2) {
                return f >= 0.0f ? 1.0f - (f / f2) : (!this.f2312p || i != 1) ? 0.0f : 1.0f;
            }
        } else if (i == 2 && f < 0.0f) {
            return f / (-f2);
        }
    }

    /* renamed from: a */
    public abstract boolean mo2446a(int i);

    /* renamed from: e */
    public abstract void mo2447e(int i, int i2);

    /* renamed from: f */
    public C0498a mo2448f(boolean z) {
        if (this.f2313q && !z) {
            if (this.f2310n) {
                this.f2312p = false;
            } else {
                this.f2298b.mo2457h();
            }
        }
        this.f2313q = z;
        return this;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public boolean mo2449g() {
        C0499a aVar = this.f2298b;
        int f = aVar.mo2455f();
        int d = aVar.mo2454d();
        return f != 0 && mo2446a(f);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0013, code lost:
        if (r0 != 3) goto L_0x0088;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouch(android.view.View r6, android.view.MotionEvent r7) {
        /*
            r5 = this;
            boolean r0 = r5.f2313q
            r1 = 0
            if (r0 != 0) goto L_0x0006
            return r1
        L_0x0006:
            int r0 = r7.getActionMasked()
            r2 = 1
            if (r0 == 0) goto L_0x0024
            if (r0 == r2) goto L_0x0017
            r3 = 2
            if (r0 == r3) goto L_0x0028
            r6 = 3
            if (r0 == r6) goto L_0x0017
            goto L_0x0088
        L_0x0017:
            boolean r6 = r5.f2310n
            if (r6 == 0) goto L_0x001e
            r5.f2312p = r1
            goto L_0x0088
        L_0x001e:
            androidx.core.widget.a$a r6 = r5.f2298b
            r6.mo2457h()
            goto L_0x0088
        L_0x0024:
            r5.f2311o = r2
            r5.f2309m = r1
        L_0x0028:
            float r0 = r7.getX()
            int r3 = r6.getWidth()
            float r3 = (float) r3
            android.view.View r4 = r5.f2300d
            int r4 = r4.getWidth()
            float r4 = (float) r4
            float r0 = r5.m2272b(r1, r0, r3, r4)
            float r7 = r7.getY()
            int r6 = r6.getHeight()
            float r6 = (float) r6
            android.view.View r3 = r5.f2300d
            int r3 = r3.getHeight()
            float r3 = (float) r3
            float r6 = r5.m2272b(r2, r7, r6, r3)
            androidx.core.widget.a$a r7 = r5.f2298b
            r7.mo2460k(r0, r6)
            boolean r6 = r5.f2312p
            if (r6 != 0) goto L_0x0088
            boolean r6 = r5.mo2449g()
            if (r6 == 0) goto L_0x0088
            java.lang.Runnable r6 = r5.f2301e
            if (r6 != 0) goto L_0x006a
            androidx.core.widget.a$b r6 = new androidx.core.widget.a$b
            r6.<init>()
            r5.f2301e = r6
        L_0x006a:
            r5.f2312p = r2
            r5.f2310n = r2
            boolean r6 = r5.f2309m
            if (r6 != 0) goto L_0x0081
            int r6 = r5.f2305i
            if (r6 <= 0) goto L_0x0081
            android.view.View r7 = r5.f2300d
            java.lang.Runnable r0 = r5.f2301e
            long r3 = (long) r6
            int r6 = p098d.p120g.p130j.C4761m.f17241f
            r7.postOnAnimationDelayed(r0, r3)
            goto L_0x0086
        L_0x0081:
            java.lang.Runnable r6 = r5.f2301e
            r6.run()
        L_0x0086:
            r5.f2309m = r2
        L_0x0088:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.C0498a.onTouch(android.view.View, android.view.MotionEvent):boolean");
    }
}
