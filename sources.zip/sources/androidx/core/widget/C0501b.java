package androidx.core.widget;

import android.os.Build;

/* renamed from: androidx.core.widget.b */
public interface C0501b {

    /* renamed from: S */
    public static final boolean f2326S = (Build.VERSION.SDK_INT >= 27);
}
