package androidx.core.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ProgressBar;
import java.util.Objects;

public class ContentLoadingProgressBar extends ProgressBar {

    /* renamed from: a */
    private final Runnable f2264a = new C0493a();

    /* renamed from: b */
    private final Runnable f2265b = new C0494b();

    /* renamed from: androidx.core.widget.ContentLoadingProgressBar$a */
    class C0493a implements Runnable {
        C0493a() {
        }

        public void run() {
            Objects.requireNonNull(ContentLoadingProgressBar.this);
            Objects.requireNonNull(ContentLoadingProgressBar.this);
            ContentLoadingProgressBar.this.setVisibility(8);
        }
    }

    /* renamed from: androidx.core.widget.ContentLoadingProgressBar$b */
    class C0494b implements Runnable {
        C0494b() {
        }

        public void run() {
            Objects.requireNonNull(ContentLoadingProgressBar.this);
            Objects.requireNonNull(ContentLoadingProgressBar.this);
            ContentLoadingProgressBar contentLoadingProgressBar = ContentLoadingProgressBar.this;
            System.currentTimeMillis();
            Objects.requireNonNull(contentLoadingProgressBar);
            ContentLoadingProgressBar.this.setVisibility(0);
        }
    }

    public ContentLoadingProgressBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(this.f2264a);
        removeCallbacks(this.f2265b);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f2264a);
        removeCallbacks(this.f2265b);
    }
}
