package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.common.api.C4291a;
import java.util.ArrayList;
import p098d.p120g.p130j.C4745a;
import p098d.p120g.p130j.C4753e;
import p098d.p120g.p130j.C4754f;
import p098d.p120g.p130j.C4756h;
import p098d.p120g.p130j.C4757i;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.p131w.C4791b;
import p165e.p166a.p167a.p168a.C4924a;

public class NestedScrollView extends FrameLayout implements C4756h, C4753e {

    /* renamed from: a */
    private static final C0496a f2268a = new C0496a();

    /* renamed from: b */
    private static final int[] f2269b = {16843130};

    /* renamed from: A */
    private float f2270A;

    /* renamed from: B */
    private C0497b f2271B;

    /* renamed from: c */
    private long f2272c;

    /* renamed from: d */
    private final Rect f2273d;

    /* renamed from: e */
    private OverScroller f2274e;

    /* renamed from: f */
    private EdgeEffect f2275f;

    /* renamed from: g */
    private EdgeEffect f2276g;

    /* renamed from: h */
    private int f2277h;

    /* renamed from: i */
    private boolean f2278i;

    /* renamed from: j */
    private boolean f2279j;

    /* renamed from: k */
    private View f2280k;

    /* renamed from: l */
    private boolean f2281l;

    /* renamed from: m */
    private VelocityTracker f2282m;

    /* renamed from: n */
    private boolean f2283n;

    /* renamed from: o */
    private boolean f2284o;

    /* renamed from: p */
    private int f2285p;

    /* renamed from: q */
    private int f2286q;

    /* renamed from: r */
    private int f2287r;

    /* renamed from: s */
    private int f2288s;

    /* renamed from: t */
    private final int[] f2289t;

    /* renamed from: u */
    private final int[] f2290u;

    /* renamed from: v */
    private int f2291v;

    /* renamed from: w */
    private int f2292w;

    /* renamed from: x */
    private SavedState f2293x;

    /* renamed from: y */
    private final C4757i f2294y;

    /* renamed from: z */
    private final C4754f f2295z;

    static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0495a();

        /* renamed from: a */
        public int f2296a;

        /* renamed from: androidx.core.widget.NestedScrollView$SavedState$a */
        class C0495a implements Parcelable.Creator<SavedState> {
            C0495a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public Object[] newArray(int i) {
                return new SavedState[i];
            }
        }

        SavedState(Parcel parcel) {
            super(parcel);
            this.f2296a = parcel.readInt();
        }

        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder P = C4924a.m17863P("HorizontalScrollView.SavedState{");
            P.append(Integer.toHexString(System.identityHashCode(this)));
            P.append(" scrollPosition=");
            return C4924a.m17911z(P, this.f2296a, "}");
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f2296a);
        }
    }

    /* renamed from: androidx.core.widget.NestedScrollView$a */
    static class C0496a extends C4745a {
        C0496a() {
        }

        /* renamed from: d */
        public void mo2443d(View view, AccessibilityEvent accessibilityEvent) {
            super.mo2443d(view, accessibilityEvent);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            accessibilityEvent.setClassName(ScrollView.class.getName());
            accessibilityEvent.setScrollable(nestedScrollView.mo2427r() > 0);
            accessibilityEvent.setScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setScrollY(nestedScrollView.getScrollY());
            accessibilityEvent.setMaxScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setMaxScrollY(nestedScrollView.mo2427r());
        }

        /* renamed from: e */
        public void mo2444e(View view, C4791b bVar) {
            int r;
            super.mo2444e(view, bVar);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            bVar.mo21933S(ScrollView.class.getName());
            if (nestedScrollView.isEnabled() && (r = nestedScrollView.mo2427r()) > 0) {
                bVar.mo21969o0(true);
                if (nestedScrollView.getScrollY() > 0) {
                    bVar.mo21943b(C4791b.C4792a.f17285e);
                    bVar.mo21943b(C4791b.C4792a.f17289i);
                }
                if (nestedScrollView.getScrollY() < r) {
                    bVar.mo21943b(C4791b.C4792a.f17284d);
                    bVar.mo21943b(C4791b.C4792a.f17291k);
                }
            }
        }

        /* renamed from: h */
        public boolean mo2445h(View view, int i, Bundle bundle) {
            if (super.mo2445h(view, i, bundle)) {
                return true;
            }
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            if (!nestedScrollView.isEnabled()) {
                return false;
            }
            if (i != 4096) {
                if (i == 8192 || i == 16908344) {
                    int max = Math.max(nestedScrollView.getScrollY() - ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), 0);
                    if (max == nestedScrollView.getScrollY()) {
                        return false;
                    }
                    nestedScrollView.mo2375E(0, max, true);
                    return true;
                } else if (i != 16908346) {
                    return false;
                }
            }
            int min = Math.min(nestedScrollView.getScrollY() + ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), nestedScrollView.mo2427r());
            if (min == nestedScrollView.getScrollY()) {
                return false;
            }
            nestedScrollView.mo2375E(0, min, true);
            return true;
        }
    }

    /* renamed from: androidx.core.widget.NestedScrollView$b */
    public interface C0497b {
        /* renamed from: a */
        void mo536a(NestedScrollView nestedScrollView, int i, int i2, int i3, int i4);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2273d = new Rect();
        this.f2278i = true;
        this.f2279j = false;
        this.f2280k = null;
        this.f2281l = false;
        this.f2284o = true;
        this.f2288s = -1;
        this.f2289t = new int[2];
        this.f2290u = new int[2];
        this.f2274e = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f2285p = viewConfiguration.getScaledTouchSlop();
        this.f2286q = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f2287r = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f2269b, i, 0);
        boolean z = obtainStyledAttributes.getBoolean(0, false);
        if (z != this.f2283n) {
            this.f2283n = z;
            requestLayout();
        }
        obtainStyledAttributes.recycle();
        this.f2294y = new C4757i();
        this.f2295z = new C4754f(this);
        setNestedScrollingEnabled(true);
        C4761m.m17310s(this, f2268a);
    }

    /* renamed from: A */
    private boolean m2235A(int i, int i2, int i3) {
        boolean z;
        int i4 = i;
        int i5 = i2;
        int i6 = i3;
        int height = getHeight();
        int scrollY = getScrollY();
        int i7 = height + scrollY;
        boolean z2 = i4 == 33;
        ArrayList focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z3 = false;
        for (int i8 = 0; i8 < size; i8++) {
            View view2 = (View) focusables.get(i8);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i5 < bottom && top < i6) {
                boolean z4 = i5 < top && bottom < i6;
                if (view == null) {
                    view = view2;
                    z3 = z4;
                } else {
                    boolean z5 = (z2 && top < view.getTop()) || (!z2 && bottom > view.getBottom());
                    if (z3) {
                        if (z4) {
                            if (!z5) {
                            }
                        }
                    } else if (z4) {
                        view = view2;
                        z3 = true;
                    } else if (!z5) {
                    }
                    view = view2;
                }
            }
        }
        if (view == null) {
            view = this;
        }
        if (i5 < scrollY || i6 > i7) {
            m2240f(z2 ? i5 - scrollY : i6 - i7);
            z = true;
        } else {
            z = false;
        }
        if (view != findFocus()) {
            view.requestFocus(i4);
        }
        return z;
    }

    /* renamed from: B */
    private void m2236B(View view) {
        view.getDrawingRect(this.f2273d);
        offsetDescendantRectToMyCoords(view, this.f2273d);
        int d = mo2390d(this.f2273d);
        if (d != 0) {
            scrollBy(0, d);
        }
    }

    /* renamed from: D */
    private void m2237D(int i, int i2, int i3, boolean z) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.f2272c > 250) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                int scrollY = getScrollY();
                OverScroller overScroller = this.f2274e;
                int scrollX = getScrollX();
                overScroller.startScroll(scrollX, scrollY, 0, Math.max(0, Math.min(i2 + scrollY, Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom())))) - scrollY, i3);
                m2248z(z);
            } else {
                if (!this.f2274e.isFinished()) {
                    m2238a();
                }
                scrollBy(i, i2);
            }
            this.f2272c = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    /* renamed from: a */
    private void m2238a() {
        this.f2274e.abortAnimation();
        this.f2295z.mo21851m(1);
    }

    /* renamed from: c */
    private static int m2239c(int i, int i2, int i3) {
        if (i2 >= i3 || i < 0) {
            return 0;
        }
        return i2 + i > i3 ? i3 - i2 : i;
    }

    /* renamed from: f */
    private void m2240f(int i) {
        if (i == 0) {
            return;
        }
        if (this.f2284o) {
            m2237D(0, i, 250, false);
        } else {
            scrollBy(0, i);
        }
    }

    /* renamed from: g */
    private void m2241g() {
        this.f2281l = false;
        m2247y();
        this.f2295z.mo21851m(0);
        EdgeEffect edgeEffect = this.f2275f;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            this.f2276g.onRelease();
        }
    }

    /* renamed from: h */
    private void m2242h() {
        if (getOverScrollMode() == 2) {
            this.f2275f = null;
            this.f2276g = null;
        } else if (this.f2275f == null) {
            Context context = getContext();
            this.f2275f = new EdgeEffect(context);
            this.f2276g = new EdgeEffect(context);
        }
    }

    /* renamed from: t */
    private static boolean m2243t(View view, View view2) {
        if (view == view2) {
            return true;
        }
        ViewParent parent = view.getParent();
        return (parent instanceof ViewGroup) && m2243t((View) parent, view2);
    }

    /* renamed from: u */
    private boolean m2244u(View view, int i, int i2) {
        view.getDrawingRect(this.f2273d);
        offsetDescendantRectToMyCoords(view, this.f2273d);
        return this.f2273d.bottom + i >= getScrollY() && this.f2273d.top - i <= getScrollY() + i2;
    }

    /* renamed from: v */
    private void m2245v(int i, int i2, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f2295z.mo21844d(0, scrollY2, 0, i - scrollY2, (int[]) null, i2, iArr);
    }

    /* renamed from: w */
    private void m2246w(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f2288s) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f2277h = (int) motionEvent.getY(i);
            this.f2288s = motionEvent.getPointerId(i);
            VelocityTracker velocityTracker = this.f2282m;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    /* renamed from: y */
    private void m2247y() {
        VelocityTracker velocityTracker = this.f2282m;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f2282m = null;
        }
    }

    /* renamed from: z */
    private void m2248z(boolean z) {
        if (z) {
            mo2376F(2, 1);
        } else {
            this.f2295z.mo21851m(1);
        }
        this.f2292w = getScrollY();
        int i = C4761m.f17241f;
        postInvalidateOnAnimation();
    }

    /* renamed from: C */
    public void mo2374C(C0497b bVar) {
        this.f2271B = bVar;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: E */
    public void mo2375E(int i, int i2, boolean z) {
        m2237D(i - getScrollX(), i2 - getScrollY(), 250, z);
    }

    /* renamed from: F */
    public boolean mo2376F(int i, int i2) {
        return this.f2295z.mo21850l(i, i2);
    }

    /* renamed from: G */
    public void mo2377G(int i) {
        this.f2295z.mo21851m(i);
    }

    public void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, int i) {
        if (getChildCount() <= 0) {
            super.addView(view, i);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    /* renamed from: b */
    public boolean mo2382b(int i) {
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i);
        int height = (int) (((float) getHeight()) * 0.5f);
        if (findNextFocus == null || !m2244u(findNextFocus, height, getHeight())) {
            if (i == 33 && getScrollY() < height) {
                height = getScrollY();
            } else if (i == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                height = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), height);
            }
            if (height == 0) {
                return false;
            }
            if (i != 130) {
                height = -height;
            }
            m2240f(height);
        } else {
            findNextFocus.getDrawingRect(this.f2273d);
            offsetDescendantRectToMyCoords(findNextFocus, this.f2273d);
            m2240f(mo2390d(this.f2273d));
            findNextFocus.requestFocus(i);
        }
        if (findFocus != null && findFocus.isFocused() && (!m2244u(findFocus, 0, getHeight()))) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    public void computeScroll() {
        EdgeEffect edgeEffect;
        if (!this.f2274e.isFinished()) {
            this.f2274e.computeScrollOffset();
            int currY = this.f2274e.getCurrY();
            int i = currY - this.f2292w;
            this.f2292w = currY;
            int[] iArr = this.f2290u;
            boolean z = false;
            iArr[1] = 0;
            mo2397e(0, i, iArr, (int[]) null, 1);
            int i2 = i - this.f2290u[1];
            int r = mo2427r();
            if (i2 != 0) {
                int scrollY = getScrollY();
                mo2438x(0, i2, getScrollX(), scrollY, 0, r, 0, 0);
                int scrollY2 = getScrollY() - scrollY;
                int i3 = i2 - scrollY2;
                int[] iArr2 = this.f2290u;
                iArr2[1] = 0;
                this.f2295z.mo21844d(0, scrollY2, 0, i3, this.f2289t, 1, iArr2);
                i2 = i3 - this.f2290u[1];
            }
            if (i2 != 0) {
                int overScrollMode = getOverScrollMode();
                if (overScrollMode == 0 || (overScrollMode == 1 && r > 0)) {
                    z = true;
                }
                if (z) {
                    m2242h();
                    if (i2 < 0) {
                        if (this.f2275f.isFinished()) {
                            edgeEffect = this.f2275f;
                        }
                    } else if (this.f2276g.isFinished()) {
                        edgeEffect = this.f2276g;
                    }
                    edgeEffect.onAbsorb((int) this.f2274e.getCurrVelocity());
                }
                m2238a();
            }
            if (!this.f2274e.isFinished()) {
                int i4 = C4761m.f17241f;
                postInvalidateOnAnimation();
                return;
            }
            this.f2295z.mo21851m(1);
        }
    }

    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        return scrollY < 0 ? bottom - scrollY : scrollY > max ? bottom + (scrollY - max) : bottom;
    }

    /* access modifiers changed from: protected */
    /* renamed from: d */
    public int mo2390d(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i2 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i - verticalFadingEdgeLength : i;
        int i3 = rect.bottom;
        if (i3 > i2 && rect.top > scrollY) {
            return Math.min((rect.height() > height ? rect.top - scrollY : rect.bottom - i2) + 0, (childAt.getBottom() + layoutParams.bottomMargin) - i);
        } else if (rect.top >= scrollY || i3 >= i2) {
            return 0;
        } else {
            return Math.max(rect.height() > height ? 0 - (i2 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || mo2402i(keyEvent);
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.f2295z.mo21841a(f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return this.f2295z.mo21842b(f, f2);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return mo2397e(i, i2, iArr, iArr2, 0);
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.f2295z.mo21845e(i, i2, i3, i4, iArr);
    }

    public void draw(Canvas canvas) {
        int i;
        super.draw(canvas);
        if (this.f2275f != null) {
            int scrollY = getScrollY();
            int i2 = 0;
            if (!this.f2275f.isFinished()) {
                int save = canvas.save();
                int width = getWidth();
                int height = getHeight();
                int min = Math.min(0, scrollY);
                if (getClipToPadding()) {
                    width -= getPaddingRight() + getPaddingLeft();
                    i = getPaddingLeft() + 0;
                } else {
                    i = 0;
                }
                if (getClipToPadding()) {
                    height -= getPaddingBottom() + getPaddingTop();
                    min += getPaddingTop();
                }
                canvas.translate((float) i, (float) min);
                this.f2275f.setSize(width, height);
                if (this.f2275f.draw(canvas)) {
                    int i3 = C4761m.f17241f;
                    postInvalidateOnAnimation();
                }
                canvas.restoreToCount(save);
            }
            if (!this.f2276g.isFinished()) {
                int save2 = canvas.save();
                int width2 = getWidth();
                int height2 = getHeight();
                int max = Math.max(mo2427r(), scrollY) + height2;
                if (getClipToPadding()) {
                    width2 -= getPaddingRight() + getPaddingLeft();
                    i2 = 0 + getPaddingLeft();
                }
                if (getClipToPadding()) {
                    height2 -= getPaddingBottom() + getPaddingTop();
                    max -= getPaddingBottom();
                }
                canvas.translate((float) (i2 - width2), (float) max);
                canvas.rotate(180.0f, (float) width2, 0.0f);
                this.f2276g.setSize(width2, height2);
                if (this.f2276g.draw(canvas)) {
                    int i4 = C4761m.f17241f;
                    postInvalidateOnAnimation();
                }
                canvas.restoreToCount(save2);
            }
        }
    }

    /* renamed from: e */
    public boolean mo2397e(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        return this.f2295z.mo21843c(i, i2, iArr, iArr2, i3);
    }

    /* access modifiers changed from: protected */
    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return ((float) bottom) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public int getNestedScrollAxes() {
        return this.f2294y.mo21852a();
    }

    /* access modifiers changed from: protected */
    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return ((float) scrollY) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public boolean hasNestedScrollingParent() {
        return mo2432s(0);
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x0062  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0038  */
    /* renamed from: i */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo2402i(android.view.KeyEvent r7) {
        /*
            r6 = this;
            android.graphics.Rect r0 = r6.f2273d
            r0.setEmpty()
            int r0 = r6.getChildCount()
            r1 = 1
            r2 = 0
            if (r0 <= 0) goto L_0x0033
            android.view.View r0 = r6.getChildAt(r2)
            android.view.ViewGroup$LayoutParams r3 = r0.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r3 = (android.widget.FrameLayout.LayoutParams) r3
            int r0 = r0.getHeight()
            int r4 = r3.topMargin
            int r0 = r0 + r4
            int r3 = r3.bottomMargin
            int r0 = r0 + r3
            int r3 = r6.getHeight()
            int r4 = r6.getPaddingTop()
            int r3 = r3 - r4
            int r4 = r6.getPaddingBottom()
            int r3 = r3 - r4
            if (r0 <= r3) goto L_0x0033
            r0 = 1
            goto L_0x0034
        L_0x0033:
            r0 = 0
        L_0x0034:
            r3 = 130(0x82, float:1.82E-43)
            if (r0 != 0) goto L_0x0062
            boolean r0 = r6.isFocused()
            if (r0 == 0) goto L_0x0061
            int r7 = r7.getKeyCode()
            r0 = 4
            if (r7 == r0) goto L_0x0061
            android.view.View r7 = r6.findFocus()
            if (r7 != r6) goto L_0x004c
            r7 = 0
        L_0x004c:
            android.view.FocusFinder r0 = android.view.FocusFinder.getInstance()
            android.view.View r7 = r0.findNextFocus(r6, r7, r3)
            if (r7 == 0) goto L_0x005f
            if (r7 == r6) goto L_0x005f
            boolean r7 = r7.requestFocus(r3)
            if (r7 == 0) goto L_0x005f
            goto L_0x0060
        L_0x005f:
            r1 = 0
        L_0x0060:
            return r1
        L_0x0061:
            return r2
        L_0x0062:
            int r0 = r7.getAction()
            if (r0 != 0) goto L_0x00fb
            int r0 = r7.getKeyCode()
            r4 = 19
            r5 = 33
            if (r0 == r4) goto L_0x00ec
            r4 = 20
            if (r0 == r4) goto L_0x00dc
            r4 = 62
            if (r0 == r4) goto L_0x007c
            goto L_0x00fb
        L_0x007c:
            boolean r7 = r7.isShiftPressed()
            if (r7 == 0) goto L_0x0083
            goto L_0x0085
        L_0x0083:
            r5 = 130(0x82, float:1.82E-43)
        L_0x0085:
            if (r5 != r3) goto L_0x0089
            r7 = 1
            goto L_0x008a
        L_0x0089:
            r7 = 0
        L_0x008a:
            int r0 = r6.getHeight()
            if (r7 == 0) goto L_0x00bf
            android.graphics.Rect r7 = r6.f2273d
            int r3 = r6.getScrollY()
            int r3 = r3 + r0
            r7.top = r3
            int r7 = r6.getChildCount()
            if (r7 <= 0) goto L_0x00d1
            int r7 = r7 - r1
            android.view.View r7 = r6.getChildAt(r7)
            android.view.ViewGroup$LayoutParams r1 = r7.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r1 = (android.widget.FrameLayout.LayoutParams) r1
            int r7 = r7.getBottom()
            int r1 = r1.bottomMargin
            int r7 = r7 + r1
            int r1 = r6.getPaddingBottom()
            int r1 = r1 + r7
            android.graphics.Rect r7 = r6.f2273d
            int r3 = r7.top
            int r3 = r3 + r0
            if (r3 <= r1) goto L_0x00d1
            int r1 = r1 - r0
            goto L_0x00cf
        L_0x00bf:
            android.graphics.Rect r7 = r6.f2273d
            int r1 = r6.getScrollY()
            int r1 = r1 - r0
            r7.top = r1
            android.graphics.Rect r7 = r6.f2273d
            int r1 = r7.top
            if (r1 >= 0) goto L_0x00d1
            r1 = 0
        L_0x00cf:
            r7.top = r1
        L_0x00d1:
            android.graphics.Rect r7 = r6.f2273d
            int r1 = r7.top
            int r0 = r0 + r1
            r7.bottom = r0
            r6.m2235A(r5, r1, r0)
            goto L_0x00fb
        L_0x00dc:
            boolean r7 = r7.isAltPressed()
            if (r7 != 0) goto L_0x00e7
            boolean r2 = r6.mo2382b(r3)
            goto L_0x00fb
        L_0x00e7:
            boolean r2 = r6.mo2405k(r3)
            goto L_0x00fb
        L_0x00ec:
            boolean r7 = r7.isAltPressed()
            if (r7 != 0) goto L_0x00f7
            boolean r2 = r6.mo2382b(r5)
            goto L_0x00fb
        L_0x00f7:
            boolean r2 = r6.mo2405k(r5)
        L_0x00fb:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.mo2402i(android.view.KeyEvent):boolean");
    }

    public boolean isNestedScrollingEnabled() {
        return this.f2295z.mo21848j();
    }

    /* renamed from: j */
    public void mo2404j(int i) {
        if (getChildCount() > 0) {
            this.f2274e.fling(getScrollX(), getScrollY(), 0, i, 0, 0, RecyclerView.UNDEFINED_DURATION, C4291a.C4299e.API_PRIORITY_OTHER, 0, 0);
            m2248z(true);
        }
    }

    /* renamed from: k */
    public boolean mo2405k(int i) {
        int childCount;
        boolean z = i == 130;
        int height = getHeight();
        Rect rect = this.f2273d;
        rect.top = 0;
        rect.bottom = height;
        if (z && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            this.f2273d.bottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            Rect rect2 = this.f2273d;
            rect2.top = rect2.bottom - height;
        }
        Rect rect3 = this.f2273d;
        return m2235A(i, rect3.top, rect3.bottom);
    }

    /* renamed from: l */
    public void mo1064l(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        m2245v(i4, i5, iArr);
    }

    /* renamed from: m */
    public void mo1065m(View view, int i, int i2, int i3, int i4, int i5) {
        m2245v(i4, i5, (int[]) null);
    }

    /* access modifiers changed from: protected */
    public void measureChild(View view, int i, int i2) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(FrameLayout.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    /* access modifiers changed from: protected */
    public void measureChildWithMargins(View view, int i, int i2, int i3, int i4) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(FrameLayout.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    /* renamed from: n */
    public boolean mo1066n(View view, View view2, int i, int i2) {
        return (i & 2) != 0;
    }

    /* renamed from: o */
    public void mo1067o(View view, View view2, int i, int i2) {
        this.f2294y.mo21853b(i, i2);
        mo2376F(2, i2);
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f2279j = false;
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if ((motionEvent.getSource() & 2) != 0 && motionEvent.getAction() == 8 && !this.f2281l) {
            float axisValue = motionEvent.getAxisValue(9);
            if (axisValue != 0.0f) {
                if (this.f2270A == 0.0f) {
                    TypedValue typedValue = new TypedValue();
                    Context context = getContext();
                    if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
                        this.f2270A = typedValue.getDimension(context.getResources().getDisplayMetrics());
                    } else {
                        throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
                    }
                }
                int r = mo2427r();
                int scrollY = getScrollY();
                int i = scrollY - ((int) (axisValue * this.f2270A));
                if (i < 0) {
                    r = 0;
                } else if (i <= r) {
                    r = i;
                }
                if (r != scrollY) {
                    super.scrollTo(getScrollX(), r);
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:47:0x00e5  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00eb  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onInterceptTouchEvent(android.view.MotionEvent r12) {
        /*
            r11 = this;
            int r0 = r12.getAction()
            r1 = 1
            r2 = 2
            if (r0 != r2) goto L_0x000d
            boolean r3 = r11.f2281l
            if (r3 == 0) goto L_0x000d
            return r1
        L_0x000d:
            r0 = r0 & 255(0xff, float:3.57E-43)
            r3 = 0
            if (r0 == 0) goto L_0x00ae
            r4 = -1
            if (r0 == r1) goto L_0x0085
            if (r0 == r2) goto L_0x0024
            r1 = 3
            if (r0 == r1) goto L_0x0085
            r1 = 6
            if (r0 == r1) goto L_0x001f
            goto L_0x0117
        L_0x001f:
            r11.m2246w(r12)
            goto L_0x0117
        L_0x0024:
            int r0 = r11.f2288s
            if (r0 != r4) goto L_0x002a
            goto L_0x0117
        L_0x002a:
            int r5 = r12.findPointerIndex(r0)
            if (r5 != r4) goto L_0x004d
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            r12.<init>()
            java.lang.String r1 = "Invalid pointerId="
            r12.append(r1)
            r12.append(r0)
            java.lang.String r0 = " in onInterceptTouchEvent"
            r12.append(r0)
            java.lang.String r12 = r12.toString()
            java.lang.String r0 = "NestedScrollView"
            android.util.Log.e(r0, r12)
            goto L_0x0117
        L_0x004d:
            float r0 = r12.getY(r5)
            int r0 = (int) r0
            int r4 = r11.f2277h
            int r4 = r0 - r4
            int r4 = java.lang.Math.abs(r4)
            int r5 = r11.f2285p
            if (r4 <= r5) goto L_0x0117
            int r4 = r11.getNestedScrollAxes()
            r2 = r2 & r4
            if (r2 != 0) goto L_0x0117
            r11.f2281l = r1
            r11.f2277h = r0
            android.view.VelocityTracker r0 = r11.f2282m
            if (r0 != 0) goto L_0x0073
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r11.f2282m = r0
        L_0x0073:
            android.view.VelocityTracker r0 = r11.f2282m
            r0.addMovement(r12)
            r11.f2291v = r3
            android.view.ViewParent r12 = r11.getParent()
            if (r12 == 0) goto L_0x0117
            r12.requestDisallowInterceptTouchEvent(r1)
            goto L_0x0117
        L_0x0085:
            r11.f2281l = r3
            r11.f2288s = r4
            r11.m2247y()
            android.widget.OverScroller r4 = r11.f2274e
            int r5 = r11.getScrollX()
            int r6 = r11.getScrollY()
            r7 = 0
            r8 = 0
            r9 = 0
            int r10 = r11.mo2427r()
            boolean r12 = r4.springBack(r5, r6, r7, r8, r9, r10)
            if (r12 == 0) goto L_0x00a8
            int r12 = p098d.p120g.p130j.C4761m.f17241f
            r11.postInvalidateOnAnimation()
        L_0x00a8:
            d.g.j.f r12 = r11.f2295z
            r12.mo21851m(r3)
            goto L_0x0117
        L_0x00ae:
            float r0 = r12.getY()
            int r0 = (int) r0
            float r4 = r12.getX()
            int r4 = (int) r4
            int r5 = r11.getChildCount()
            if (r5 <= 0) goto L_0x00e2
            int r5 = r11.getScrollY()
            android.view.View r6 = r11.getChildAt(r3)
            int r7 = r6.getTop()
            int r7 = r7 - r5
            if (r0 < r7) goto L_0x00e2
            int r7 = r6.getBottom()
            int r7 = r7 - r5
            if (r0 >= r7) goto L_0x00e2
            int r5 = r6.getLeft()
            if (r4 < r5) goto L_0x00e2
            int r5 = r6.getRight()
            if (r4 >= r5) goto L_0x00e2
            r4 = 1
            goto L_0x00e3
        L_0x00e2:
            r4 = 0
        L_0x00e3:
            if (r4 != 0) goto L_0x00eb
            r11.f2281l = r3
            r11.m2247y()
            goto L_0x0117
        L_0x00eb:
            r11.f2277h = r0
            int r0 = r12.getPointerId(r3)
            r11.f2288s = r0
            android.view.VelocityTracker r0 = r11.f2282m
            if (r0 != 0) goto L_0x00fe
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r11.f2282m = r0
            goto L_0x0101
        L_0x00fe:
            r0.clear()
        L_0x0101:
            android.view.VelocityTracker r0 = r11.f2282m
            r0.addMovement(r12)
            android.widget.OverScroller r12 = r11.f2274e
            r12.computeScrollOffset()
            android.widget.OverScroller r12 = r11.f2274e
            boolean r12 = r12.isFinished()
            r12 = r12 ^ r1
            r11.f2281l = r12
            r11.mo2376F(r2, r3)
        L_0x0117:
            boolean r12 = r11.f2281l
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        int i5 = 0;
        this.f2278i = false;
        View view = this.f2280k;
        if (view != null && m2243t(view, this)) {
            m2236B(this.f2280k);
        }
        this.f2280k = null;
        if (!this.f2279j) {
            if (this.f2293x != null) {
                scrollTo(getScrollX(), this.f2293x.f2296a);
                this.f2293x = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                i5 = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            }
            int paddingTop = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int c = m2239c(scrollY, paddingTop, i5);
            if (c != scrollY) {
                scrollTo(getScrollX(), c);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f2279j = true;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f2283n && View.MeasureSpec.getMode(i2) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(FrameLayout.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (z) {
            return false;
        }
        dispatchNestedFling(0.0f, f2, true);
        mo2404j((int) f2);
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return dispatchNestedPreFling(f, f2);
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        mo2397e(i, i2, iArr, (int[]) null, 0);
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        m2245v(i4, 0, (int[]) null);
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.f2294y.mo21853b(i, 0);
        mo2376F(2, 0);
    }

    /* access modifiers changed from: protected */
    public void onOverScrolled(int i, int i2, boolean z, boolean z2) {
        super.scrollTo(i, i2);
    }

    /* access modifiers changed from: protected */
    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        FocusFinder instance = FocusFinder.getInstance();
        View findNextFocus = rect == null ? instance.findNextFocus(this, (View) null, i) : instance.findNextFocusFromRect(this, rect, i);
        if (findNextFocus != null && !(true ^ m2244u(findNextFocus, 0, getHeight()))) {
            return findNextFocus.requestFocus(i, rect);
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.f2293x = savedState;
        requestLayout();
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.f2296a = getScrollY();
        return savedState;
    }

    /* access modifiers changed from: protected */
    public void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
        C0497b bVar = this.f2271B;
        if (bVar != null) {
            bVar.mo536a(this, i, i2, i3, i4);
        }
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && m2244u(findFocus, 0, i4)) {
            findFocus.getDrawingRect(this.f2273d);
            offsetDescendantRectToMyCoords(findFocus, this.f2273d);
            m2240f(mo2390d(this.f2273d));
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        return (i & 2) != 0;
    }

    public void onStopNestedScroll(View view) {
        this.f2294y.mo21855d(0);
        mo2377G(0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:24:0x007d, code lost:
        if (r9.f2274e.springBack(getScrollX(), getScrollY(), 0, 0, 0, mo2427r()) != false) goto L_0x020b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:81:0x0209, code lost:
        if (r9.f2274e.springBack(getScrollX(), getScrollY(), 0, 0, 0, mo2427r()) != false) goto L_0x020b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r23) {
        /*
            r22 = this;
            r9 = r22
            r10 = r23
            android.view.VelocityTracker r0 = r9.f2282m
            if (r0 != 0) goto L_0x000e
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r9.f2282m = r0
        L_0x000e:
            int r0 = r23.getActionMasked()
            r11 = 0
            if (r0 != 0) goto L_0x0017
            r9.f2291v = r11
        L_0x0017:
            android.view.MotionEvent r12 = android.view.MotionEvent.obtain(r23)
            int r1 = r9.f2291v
            float r1 = (float) r1
            r2 = 0
            r12.offsetLocation(r2, r1)
            r1 = 2
            r13 = 1
            if (r0 == 0) goto L_0x0216
            r3 = -1
            if (r0 == r13) goto L_0x01c9
            if (r0 == r1) goto L_0x0081
            r1 = 3
            if (r0 == r1) goto L_0x005b
            r1 = 5
            if (r0 == r1) goto L_0x0048
            r1 = 6
            if (r0 == r1) goto L_0x0036
            goto L_0x024c
        L_0x0036:
            r22.m2246w(r23)
            int r0 = r9.f2288s
            int r0 = r10.findPointerIndex(r0)
            float r0 = r10.getY(r0)
            int r0 = (int) r0
            r9.f2277h = r0
            goto L_0x024c
        L_0x0048:
            int r0 = r23.getActionIndex()
            float r1 = r10.getY(r0)
            int r1 = (int) r1
            r9.f2277h = r1
            int r0 = r10.getPointerId(r0)
            r9.f2288s = r0
            goto L_0x024c
        L_0x005b:
            boolean r0 = r9.f2281l
            if (r0 == 0) goto L_0x0210
            int r0 = r22.getChildCount()
            if (r0 <= 0) goto L_0x0210
            android.widget.OverScroller r14 = r9.f2274e
            int r15 = r22.getScrollX()
            int r16 = r22.getScrollY()
            r17 = 0
            r18 = 0
            r19 = 0
            int r20 = r22.mo2427r()
            boolean r0 = r14.springBack(r15, r16, r17, r18, r19, r20)
            if (r0 == 0) goto L_0x0210
            goto L_0x020b
        L_0x0081:
            int r0 = r9.f2288s
            int r14 = r10.findPointerIndex(r0)
            if (r14 != r3) goto L_0x00a4
            java.lang.String r0 = "Invalid pointerId="
            java.lang.StringBuilder r0 = p165e.p166a.p167a.p168a.C4924a.m17863P(r0)
            int r1 = r9.f2288s
            r0.append(r1)
            java.lang.String r1 = " in onTouchEvent"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            java.lang.String r1 = "NestedScrollView"
            android.util.Log.e(r1, r0)
            goto L_0x024c
        L_0x00a4:
            float r0 = r10.getY(r14)
            int r6 = (int) r0
            int r0 = r9.f2277h
            int r0 = r0 - r6
            boolean r1 = r9.f2281l
            if (r1 != 0) goto L_0x00ca
            int r1 = java.lang.Math.abs(r0)
            int r2 = r9.f2285p
            if (r1 <= r2) goto L_0x00ca
            android.view.ViewParent r1 = r22.getParent()
            if (r1 == 0) goto L_0x00c1
            r1.requestDisallowInterceptTouchEvent(r13)
        L_0x00c1:
            r9.f2281l = r13
            int r1 = r9.f2285p
            if (r0 <= 0) goto L_0x00c9
            int r0 = r0 - r1
            goto L_0x00ca
        L_0x00c9:
            int r0 = r0 + r1
        L_0x00ca:
            r7 = r0
            boolean r0 = r9.f2281l
            if (r0 == 0) goto L_0x024c
            r1 = 0
            int[] r3 = r9.f2290u
            int[] r4 = r9.f2289t
            r5 = 0
            r0 = r22
            r2 = r7
            boolean r0 = r0.mo2397e(r1, r2, r3, r4, r5)
            if (r0 == 0) goto L_0x00ec
            int[] r0 = r9.f2290u
            r0 = r0[r13]
            int r7 = r7 - r0
            int r0 = r9.f2291v
            int[] r1 = r9.f2289t
            r1 = r1[r13]
            int r0 = r0 + r1
            r9.f2291v = r0
        L_0x00ec:
            r15 = r7
            int[] r0 = r9.f2289t
            r0 = r0[r13]
            int r6 = r6 - r0
            r9.f2277h = r6
            int r16 = r22.getScrollY()
            int r8 = r22.mo2427r()
            int r0 = r22.getOverScrollMode()
            if (r0 == 0) goto L_0x010b
            if (r0 != r13) goto L_0x0107
            if (r8 <= 0) goto L_0x0107
            goto L_0x010b
        L_0x0107:
            r0 = 0
            r17 = 0
            goto L_0x010e
        L_0x010b:
            r0 = 1
            r17 = 1
        L_0x010e:
            r1 = 0
            r3 = 0
            int r4 = r22.getScrollY()
            r5 = 0
            r7 = 0
            r18 = 0
            r0 = r22
            r2 = r15
            r6 = r8
            r21 = r8
            r8 = r18
            boolean r0 = r0.mo2438x(r1, r2, r3, r4, r5, r6, r7, r8)
            if (r0 == 0) goto L_0x0131
            boolean r0 = r9.mo2432s(r11)
            if (r0 != 0) goto L_0x0131
            android.view.VelocityTracker r0 = r9.f2282m
            r0.clear()
        L_0x0131:
            int r0 = r22.getScrollY()
            int r3 = r0 - r16
            int r5 = r15 - r3
            int[] r8 = r9.f2290u
            r8[r13] = r11
            r2 = 0
            r4 = 0
            int[] r6 = r9.f2289t
            r7 = 0
            d.g.j.f r1 = r9.f2295z
            r1.mo21844d(r2, r3, r4, r5, r6, r7, r8)
            int r0 = r9.f2277h
            int[] r1 = r9.f2289t
            r2 = r1[r13]
            int r0 = r0 - r2
            r9.f2277h = r0
            int r0 = r9.f2291v
            r1 = r1[r13]
            int r0 = r0 + r1
            r9.f2291v = r0
            if (r17 == 0) goto L_0x024c
            int[] r0 = r9.f2290u
            r0 = r0[r13]
            int r15 = r15 - r0
            r22.m2242h()
            int r0 = r16 + r15
            if (r0 >= 0) goto L_0x0186
            android.widget.EdgeEffect r0 = r9.f2275f
            float r1 = (float) r15
            int r2 = r22.getHeight()
            float r2 = (float) r2
            float r1 = r1 / r2
            float r2 = r10.getX(r14)
            int r3 = r22.getWidth()
            float r3 = (float) r3
            float r2 = r2 / r3
            r0.onPull(r1, r2)
            android.widget.EdgeEffect r0 = r9.f2276g
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x01b0
            android.widget.EdgeEffect r0 = r9.f2276g
            goto L_0x01ad
        L_0x0186:
            r1 = r21
            if (r0 <= r1) goto L_0x01b0
            android.widget.EdgeEffect r0 = r9.f2276g
            float r1 = (float) r15
            int r2 = r22.getHeight()
            float r2 = (float) r2
            float r1 = r1 / r2
            r2 = 1065353216(0x3f800000, float:1.0)
            float r3 = r10.getX(r14)
            int r4 = r22.getWidth()
            float r4 = (float) r4
            float r3 = r3 / r4
            float r2 = r2 - r3
            r0.onPull(r1, r2)
            android.widget.EdgeEffect r0 = r9.f2275f
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x01b0
            android.widget.EdgeEffect r0 = r9.f2275f
        L_0x01ad:
            r0.onRelease()
        L_0x01b0:
            android.widget.EdgeEffect r0 = r9.f2275f
            if (r0 == 0) goto L_0x024c
            boolean r0 = r0.isFinished()
            if (r0 == 0) goto L_0x01c2
            android.widget.EdgeEffect r0 = r9.f2276g
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x024c
        L_0x01c2:
            int r0 = p098d.p120g.p130j.C4761m.f17241f
            r22.postInvalidateOnAnimation()
            goto L_0x024c
        L_0x01c9:
            android.view.VelocityTracker r0 = r9.f2282m
            r1 = 1000(0x3e8, float:1.401E-42)
            int r4 = r9.f2287r
            float r4 = (float) r4
            r0.computeCurrentVelocity(r1, r4)
            int r1 = r9.f2288s
            float r0 = r0.getYVelocity(r1)
            int r0 = (int) r0
            int r1 = java.lang.Math.abs(r0)
            int r4 = r9.f2286q
            if (r1 < r4) goto L_0x01f1
            int r0 = -r0
            float r1 = (float) r0
            boolean r4 = r9.dispatchNestedPreFling(r2, r1)
            if (r4 != 0) goto L_0x0210
            r9.dispatchNestedFling(r2, r1, r13)
            r9.mo2404j(r0)
            goto L_0x0210
        L_0x01f1:
            android.widget.OverScroller r14 = r9.f2274e
            int r15 = r22.getScrollX()
            int r16 = r22.getScrollY()
            r17 = 0
            r18 = 0
            r19 = 0
            int r20 = r22.mo2427r()
            boolean r0 = r14.springBack(r15, r16, r17, r18, r19, r20)
            if (r0 == 0) goto L_0x0210
        L_0x020b:
            int r0 = p098d.p120g.p130j.C4761m.f17241f
            r22.postInvalidateOnAnimation()
        L_0x0210:
            r9.f2288s = r3
            r22.m2241g()
            goto L_0x024c
        L_0x0216:
            int r0 = r22.getChildCount()
            if (r0 != 0) goto L_0x021d
            return r11
        L_0x021d:
            android.widget.OverScroller r0 = r9.f2274e
            boolean r0 = r0.isFinished()
            r0 = r0 ^ r13
            r9.f2281l = r0
            if (r0 == 0) goto L_0x0231
            android.view.ViewParent r0 = r22.getParent()
            if (r0 == 0) goto L_0x0231
            r0.requestDisallowInterceptTouchEvent(r13)
        L_0x0231:
            android.widget.OverScroller r0 = r9.f2274e
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x023c
            r22.m2238a()
        L_0x023c:
            float r0 = r23.getY()
            int r0 = (int) r0
            r9.f2277h = r0
            int r0 = r10.getPointerId(r11)
            r9.f2288s = r0
            r9.mo2376F(r1, r11)
        L_0x024c:
            android.view.VelocityTracker r0 = r9.f2282m
            if (r0 == 0) goto L_0x0253
            r0.addMovement(r12)
        L_0x0253:
            r12.recycle()
            return r13
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    /* renamed from: p */
    public void mo1082p(View view, int i) {
        this.f2294y.mo21855d(i);
        mo2377G(i);
    }

    /* renamed from: q */
    public void mo1083q(View view, int i, int i2, int[] iArr, int i3) {
        mo2397e(i, i2, iArr, (int[]) null, i3);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: r */
    public int mo2427r() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    public void requestChildFocus(View view, View view2) {
        if (!this.f2278i) {
            m2236B(view2);
        } else {
            this.f2280k = view2;
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int d = mo2390d(rect);
        boolean z2 = d != 0;
        if (z2) {
            if (z) {
                scrollBy(0, d);
            } else {
                m2237D(0, d, 250, false);
            }
        }
        return z2;
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        if (z) {
            m2247y();
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public void requestLayout() {
        this.f2278i = true;
        super.requestLayout();
    }

    /* renamed from: s */
    public boolean mo2432s(int i) {
        return this.f2295z.mo21847i(i);
    }

    public void scrollTo(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int c = m2239c(i, (getWidth() - getPaddingLeft()) - getPaddingRight(), childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin);
            int c2 = m2239c(i2, (getHeight() - getPaddingTop()) - getPaddingBottom(), childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin);
            if (c != getScrollX() || c2 != getScrollY()) {
                super.scrollTo(c, c2);
            }
        }
    }

    public void setNestedScrollingEnabled(boolean z) {
        this.f2295z.mo21849k(z);
    }

    public boolean shouldDelayChildPressedState() {
        return true;
    }

    public boolean startNestedScroll(int i) {
        return this.f2295z.mo21850l(i, 0);
    }

    public void stopNestedScroll() {
        this.f2295z.mo21851m(0);
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0057  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0083 A[ADDED_TO_REGION] */
    /* renamed from: x */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo2438x(int r13, int r14, int r15, int r16, int r17, int r18, int r19, int r20) {
        /*
            r12 = this;
            r0 = r12
            int r1 = r12.getOverScrollMode()
            int r2 = r12.computeHorizontalScrollRange()
            int r3 = r12.computeHorizontalScrollExtent()
            r4 = 0
            r5 = 1
            if (r2 <= r3) goto L_0x0013
            r2 = 1
            goto L_0x0014
        L_0x0013:
            r2 = 0
        L_0x0014:
            int r3 = r12.computeVerticalScrollRange()
            int r6 = r12.computeVerticalScrollExtent()
            if (r3 <= r6) goto L_0x0020
            r3 = 1
            goto L_0x0021
        L_0x0020:
            r3 = 0
        L_0x0021:
            if (r1 == 0) goto L_0x002a
            if (r1 != r5) goto L_0x0028
            if (r2 == 0) goto L_0x0028
            goto L_0x002a
        L_0x0028:
            r2 = 0
            goto L_0x002b
        L_0x002a:
            r2 = 1
        L_0x002b:
            if (r1 == 0) goto L_0x0034
            if (r1 != r5) goto L_0x0032
            if (r3 == 0) goto L_0x0032
            goto L_0x0034
        L_0x0032:
            r1 = 0
            goto L_0x0035
        L_0x0034:
            r1 = 1
        L_0x0035:
            int r3 = r15 + r13
            if (r2 != 0) goto L_0x003b
            r2 = 0
            goto L_0x003d
        L_0x003b:
            r2 = r19
        L_0x003d:
            int r6 = r16 + r14
            if (r1 != 0) goto L_0x0043
            r1 = 0
            goto L_0x0045
        L_0x0043:
            r1 = r20
        L_0x0045:
            int r7 = -r2
            int r2 = r2 + r17
            int r8 = -r1
            int r1 = r1 + r18
            if (r3 <= r2) goto L_0x0050
            r3 = r2
        L_0x004e:
            r2 = 1
            goto L_0x0055
        L_0x0050:
            if (r3 >= r7) goto L_0x0054
            r3 = r7
            goto L_0x004e
        L_0x0054:
            r2 = 0
        L_0x0055:
            if (r6 <= r1) goto L_0x005a
            r6 = r1
        L_0x0058:
            r1 = 1
            goto L_0x005f
        L_0x005a:
            if (r6 >= r8) goto L_0x005e
            r6 = r8
            goto L_0x0058
        L_0x005e:
            r1 = 0
        L_0x005f:
            if (r1 == 0) goto L_0x007e
            boolean r7 = r12.mo2432s(r5)
            if (r7 != 0) goto L_0x007e
            android.widget.OverScroller r7 = r0.f2274e
            r8 = 0
            r9 = 0
            r10 = 0
            int r11 = r12.mo2427r()
            r13 = r7
            r14 = r3
            r15 = r6
            r16 = r8
            r17 = r9
            r18 = r10
            r19 = r11
            r13.springBack(r14, r15, r16, r17, r18, r19)
        L_0x007e:
            r12.onOverScrolled(r3, r6, r2, r1)
            if (r2 != 0) goto L_0x0085
            if (r1 == 0) goto L_0x0086
        L_0x0085:
            r4 = 1
        L_0x0086:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.mo2438x(int, int, int, int, int, int, int, int):boolean");
    }
}
