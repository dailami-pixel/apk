package androidx.customview.view;

import android.os.Parcel;
import android.os.Parcelable;

public abstract class AbsSavedState implements Parcelable {
    public static final Parcelable.Creator<AbsSavedState> CREATOR = new C0507a();

    /* renamed from: a */
    public static final AbsSavedState f2340a = new AbsSavedState() {
    };

    /* renamed from: b */
    private final Parcelable f2341b;

    /* renamed from: androidx.customview.view.AbsSavedState$a */
    static class C0507a implements Parcelable.ClassLoaderCreator<AbsSavedState> {
        C0507a() {
        }

        public Object createFromParcel(Parcel parcel) {
            if (parcel.readParcelable((ClassLoader) null) == null) {
                return AbsSavedState.f2340a;
            }
            throw new IllegalStateException("superState must be null");
        }

        public Object[] newArray(int i) {
            return new AbsSavedState[i];
        }

        public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
            if (parcel.readParcelable(classLoader) == null) {
                return AbsSavedState.f2340a;
            }
            throw new IllegalStateException("superState must be null");
        }
    }

    private AbsSavedState() {
        this.f2341b = null;
    }

    protected AbsSavedState(Parcel parcel, ClassLoader classLoader) {
        Parcelable readParcelable = parcel.readParcelable(classLoader);
        this.f2341b = readParcelable == null ? f2340a : readParcelable;
    }

    protected AbsSavedState(Parcelable parcelable) {
        if (parcelable != null) {
            this.f2341b = parcelable == f2340a ? null : parcelable;
            return;
        }
        throw new IllegalArgumentException("superState must not be null");
    }

    AbsSavedState(C05061 r1) {
        this.f2341b = null;
    }

    /* renamed from: a */
    public final Parcelable mo2467a() {
        return this.f2341b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.f2341b, i);
    }
}
