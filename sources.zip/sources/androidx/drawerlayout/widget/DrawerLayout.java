package androidx.drawerlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import androidx.customview.view.AbsSavedState;
import java.util.ArrayList;
import java.util.Objects;
import p098d.p120g.p130j.C4745a;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.p131w.C4791b;
import p098d.p132h.p133a.C4810c;

public class DrawerLayout extends ViewGroup {

    /* renamed from: a */
    private static final int[] f2342a = {16843828};

    /* renamed from: b */
    static final int[] f2343b = {16842931};

    /* renamed from: A */
    private Rect f2344A;

    /* renamed from: B */
    private Matrix f2345B;

    /* renamed from: c */
    private final C0511c f2346c;

    /* renamed from: d */
    private float f2347d;

    /* renamed from: e */
    private int f2348e;

    /* renamed from: f */
    private int f2349f;

    /* renamed from: g */
    private float f2350g;

    /* renamed from: h */
    private Paint f2351h;

    /* renamed from: i */
    private final C4810c f2352i;

    /* renamed from: j */
    private final C4810c f2353j;

    /* renamed from: k */
    private final C0512d f2354k;

    /* renamed from: l */
    private final C0512d f2355l;

    /* renamed from: m */
    private int f2356m;

    /* renamed from: n */
    private boolean f2357n;

    /* renamed from: o */
    private boolean f2358o;

    /* renamed from: p */
    private int f2359p;

    /* renamed from: q */
    private int f2360q;

    /* renamed from: r */
    private int f2361r;

    /* renamed from: s */
    private int f2362s;

    /* renamed from: t */
    private boolean f2363t;

    /* renamed from: u */
    private float f2364u;

    /* renamed from: v */
    private float f2365v;

    /* renamed from: w */
    private Drawable f2366w;

    /* renamed from: x */
    private Object f2367x;

    /* renamed from: y */
    private boolean f2368y;

    /* renamed from: z */
    private final ArrayList<View> f2369z;

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {

        /* renamed from: a */
        public int f2370a = 0;

        /* renamed from: b */
        float f2371b;

        /* renamed from: c */
        boolean f2372c;

        /* renamed from: d */
        int f2373d;

        public LayoutParams(int i, int i2) {
            super(i, i2);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, DrawerLayout.f2343b);
            this.f2370a = obtainStyledAttributes.getInt(0, 0);
            obtainStyledAttributes.recycle();
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public LayoutParams(LayoutParams layoutParams) {
            super(layoutParams);
            this.f2370a = layoutParams.f2370a;
        }
    }

    protected static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0508a();

        /* renamed from: c */
        int f2374c = 0;

        /* renamed from: d */
        int f2375d;

        /* renamed from: e */
        int f2376e;

        /* renamed from: f */
        int f2377f;

        /* renamed from: g */
        int f2378g;

        /* renamed from: androidx.drawerlayout.widget.DrawerLayout$SavedState$a */
        static class C0508a implements Parcelable.ClassLoaderCreator<SavedState> {
            C0508a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new SavedState[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f2374c = parcel.readInt();
            this.f2375d = parcel.readInt();
            this.f2376e = parcel.readInt();
            this.f2377f = parcel.readInt();
            this.f2378g = parcel.readInt();
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f2374c);
            parcel.writeInt(this.f2375d);
            parcel.writeInt(this.f2376e);
            parcel.writeInt(this.f2377f);
            parcel.writeInt(this.f2378g);
        }
    }

    /* renamed from: androidx.drawerlayout.widget.DrawerLayout$a */
    class C0509a implements View.OnApplyWindowInsetsListener {
        C0509a(DrawerLayout drawerLayout) {
        }

        public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
            ((DrawerLayout) view).mo2493n(windowInsets, windowInsets.getSystemWindowInsetTop() > 0);
            return windowInsets.consumeSystemWindowInsets();
        }
    }

    /* renamed from: androidx.drawerlayout.widget.DrawerLayout$b */
    class C0510b extends C4745a {

        /* renamed from: d */
        private final Rect f2379d = new Rect();

        C0510b() {
        }

        /* renamed from: a */
        public boolean mo2515a(View view, AccessibilityEvent accessibilityEvent) {
            if (accessibilityEvent.getEventType() != 32) {
                return super.mo2515a(view, accessibilityEvent);
            }
            accessibilityEvent.getText();
            View g = DrawerLayout.this.mo2484g();
            if (g == null) {
                return true;
            }
            int i = DrawerLayout.this.mo2489i(g);
            DrawerLayout drawerLayout = DrawerLayout.this;
            Objects.requireNonNull(drawerLayout);
            int i2 = C4761m.f17241f;
            int absoluteGravity = Gravity.getAbsoluteGravity(i, drawerLayout.getLayoutDirection());
            return true;
        }

        /* renamed from: d */
        public void mo2443d(View view, AccessibilityEvent accessibilityEvent) {
            super.mo2443d(view, accessibilityEvent);
            accessibilityEvent.setClassName(DrawerLayout.class.getName());
        }

        /* renamed from: e */
        public void mo2444e(View view, C4791b bVar) {
            int[] iArr = DrawerLayout.f2343b;
            super.mo2444e(view, bVar);
            bVar.mo21933S(DrawerLayout.class.getName());
            bVar.mo21942a0(false);
            bVar.mo21944b0(false);
            bVar.mo21926K(C4791b.C4792a.f17281a);
            bVar.mo21926K(C4791b.C4792a.f17282b);
        }

        /* renamed from: g */
        public boolean mo2516g(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            int[] iArr = DrawerLayout.f2343b;
            return super.mo2516g(viewGroup, view, accessibilityEvent);
        }
    }

    /* renamed from: androidx.drawerlayout.widget.DrawerLayout$c */
    static final class C0511c extends C4745a {
        C0511c() {
        }

        /* renamed from: e */
        public void mo2444e(View view, C4791b bVar) {
            super.mo2444e(view, bVar);
            if (!DrawerLayout.m2302j(view)) {
                bVar.mo21960j0((View) null);
            }
        }
    }

    /* renamed from: androidx.drawerlayout.widget.DrawerLayout$d */
    private class C0512d extends C4810c.C4813c {

        /* renamed from: a */
        private final int f2381a;

        /* renamed from: b */
        private C4810c f2382b;

        /* renamed from: c */
        private final Runnable f2383c = new C0513a();

        /* renamed from: androidx.drawerlayout.widget.DrawerLayout$d$a */
        class C0513a implements Runnable {
            C0513a() {
            }

            public void run() {
                C0512d.this.mo2527m();
            }
        }

        C0512d(int i) {
            this.f2381a = i;
        }

        /* renamed from: l */
        private void m2325l() {
            int i = 3;
            if (this.f2381a == 3) {
                i = 5;
            }
            View e = DrawerLayout.this.mo2482e(i);
            if (e != null) {
                DrawerLayout.this.mo2476c(e);
            }
        }

        /* renamed from: a */
        public int mo2517a(View view, int i, int i2) {
            int width;
            int width2;
            if (DrawerLayout.this.mo2475b(view, 3)) {
                width2 = -view.getWidth();
                width = 0;
            } else {
                width = DrawerLayout.this.getWidth();
                width2 = width - view.getWidth();
            }
            return Math.max(width2, Math.min(i, width));
        }

        /* renamed from: b */
        public int mo2518b(View view, int i, int i2) {
            return view.getTop();
        }

        /* renamed from: c */
        public int mo2519c(View view) {
            if (DrawerLayout.this.mo2491l(view)) {
                return view.getWidth();
            }
            return 0;
        }

        /* renamed from: e */
        public void mo2520e(int i, int i2) {
            DrawerLayout drawerLayout;
            int i3;
            if ((i & 1) == 1) {
                drawerLayout = DrawerLayout.this;
                i3 = 3;
            } else {
                drawerLayout = DrawerLayout.this;
                i3 = 5;
            }
            View e = drawerLayout.mo2482e(i3);
            if (e != null && DrawerLayout.this.mo2488h(e) == 0) {
                this.f2382b.mo22034c(e, i2);
            }
        }

        /* renamed from: f */
        public void mo2521f(int i, int i2) {
            DrawerLayout.this.postDelayed(this.f2383c, 160);
        }

        /* renamed from: g */
        public void mo2522g(View view, int i) {
            ((LayoutParams) view.getLayoutParams()).f2372c = false;
            m2325l();
        }

        /* renamed from: h */
        public void mo2523h(int i) {
            DrawerLayout.this.mo2508r(i, this.f2382b.mo22038q());
        }

        /* renamed from: i */
        public void mo2524i(View view, int i, int i2, int i3, int i4) {
            int width = view.getWidth();
            float width2 = (DrawerLayout.this.mo2475b(view, 3) ? (float) (i + width) : (float) (DrawerLayout.this.getWidth() - i)) / ((float) width);
            DrawerLayout.this.mo2507p(view, width2);
            view.setVisibility(width2 == 0.0f ? 4 : 0);
            DrawerLayout.this.invalidate();
        }

        /* renamed from: j */
        public void mo2525j(View view, float f, float f2) {
            int i;
            Objects.requireNonNull(DrawerLayout.this);
            float f3 = ((LayoutParams) view.getLayoutParams()).f2371b;
            int width = view.getWidth();
            if (DrawerLayout.this.mo2475b(view, 3)) {
                int i2 = (f > 0.0f ? 1 : (f == 0.0f ? 0 : -1));
                i = (i2 > 0 || (i2 == 0 && f3 > 0.5f)) ? 0 : -width;
            } else {
                int width2 = DrawerLayout.this.getWidth();
                if (f < 0.0f || (f == 0.0f && f3 > 0.5f)) {
                    width2 -= width;
                }
                i = width2;
            }
            this.f2382b.mo22028F(i, view.getTop());
            DrawerLayout.this.invalidate();
        }

        /* renamed from: k */
        public boolean mo2526k(View view, int i) {
            return DrawerLayout.this.mo2491l(view) && DrawerLayout.this.mo2475b(view, this.f2381a) && DrawerLayout.this.mo2488h(view) == 0;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: m */
        public void mo2527m() {
            View view;
            int i;
            int r = this.f2382b.mo22039r();
            int i2 = 0;
            boolean z = this.f2381a == 3;
            if (z) {
                view = DrawerLayout.this.mo2482e(3);
                if (view != null) {
                    i2 = -view.getWidth();
                }
                i = i2 + r;
            } else {
                view = DrawerLayout.this.mo2482e(5);
                i = DrawerLayout.this.getWidth() - r;
            }
            if (view == null) {
                return;
            }
            if (((z && view.getLeft() < i) || (!z && view.getLeft() > i)) && DrawerLayout.this.mo2488h(view) == 0) {
                this.f2382b.mo22030H(view, i, view.getTop());
                ((LayoutParams) view.getLayoutParams()).f2372c = true;
                DrawerLayout.this.invalidate();
                m2325l();
                DrawerLayout.this.mo2472a();
            }
        }

        /* renamed from: n */
        public void mo2528n() {
            DrawerLayout.this.removeCallbacks(this.f2383c);
        }

        /* renamed from: o */
        public void mo2529o(C4810c cVar) {
            this.f2382b = cVar;
        }
    }

    public DrawerLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public DrawerLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2346c = new C0511c();
        this.f2349f = -1728053248;
        this.f2351h = new Paint();
        this.f2358o = true;
        this.f2359p = 3;
        this.f2360q = 3;
        this.f2361r = 3;
        this.f2362s = 3;
        setDescendantFocusability(262144);
        float f = getResources().getDisplayMetrics().density;
        this.f2348e = (int) ((64.0f * f) + 0.5f);
        float f2 = 400.0f * f;
        C0512d dVar = new C0512d(3);
        this.f2354k = dVar;
        C0512d dVar2 = new C0512d(5);
        this.f2355l = dVar2;
        C4810c l = C4810c.m17536l(this, 1.0f, dVar);
        this.f2352i = l;
        l.mo22026D(1);
        l.mo22027E(f2);
        dVar.mo2529o(l);
        C4810c l2 = C4810c.m17536l(this, 1.0f, dVar2);
        this.f2353j = l2;
        l2.mo22026D(2);
        l2.mo22027E(f2);
        dVar2.mo2529o(l2);
        setFocusableInTouchMode(true);
        int i2 = C4761m.f17241f;
        setImportantForAccessibility(1);
        C4761m.m17310s(this, new C0510b());
        setMotionEventSplittingEnabled(false);
        if (getFitsSystemWindows()) {
            setOnApplyWindowInsetsListener(new C0509a(this));
            setSystemUiVisibility(1280);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(f2342a);
            try {
                this.f2366w = obtainStyledAttributes.getDrawable(0);
            } finally {
                obtainStyledAttributes.recycle();
            }
        }
        this.f2347d = f * 10.0f;
        this.f2369z = new ArrayList<>();
    }

    /* renamed from: j */
    static boolean m2302j(View view) {
        int i = C4761m.f17241f;
        return (view.getImportantForAccessibility() == 4 || view.getImportantForAccessibility() == 2) ? false : true;
    }

    /* renamed from: q */
    private void m2303q(View view, boolean z) {
        int i;
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if ((z || mo2491l(childAt)) && (!z || childAt != view)) {
                i = 4;
                int i3 = C4761m.f17241f;
            } else {
                int i4 = C4761m.f17241f;
                i = 1;
            }
            childAt.setImportantForAccessibility(i);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo2472a() {
        if (!this.f2363t) {
            long uptimeMillis = SystemClock.uptimeMillis();
            MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                getChildAt(i).dispatchTouchEvent(obtain);
            }
            obtain.recycle();
            this.f2363t = true;
        }
    }

    public void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        if (getDescendantFocusability() != 393216) {
            int childCount = getChildCount();
            boolean z = false;
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                if (!mo2491l(childAt)) {
                    this.f2369z.add(childAt);
                } else if (mo2491l(childAt)) {
                    if ((((LayoutParams) childAt.getLayoutParams()).f2373d & 1) == 1) {
                        childAt.addFocusables(arrayList, i, i2);
                        z = true;
                    }
                } else {
                    throw new IllegalArgumentException("View " + childAt + " is not a drawer");
                }
            }
            if (!z) {
                int size = this.f2369z.size();
                for (int i4 = 0; i4 < size; i4++) {
                    View view = this.f2369z.get(i4);
                    if (view.getVisibility() == 0) {
                        view.addFocusables(arrayList, i, i2);
                    }
                }
            }
            this.f2369z.clear();
        }
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
        int i2 = (mo2483f() != null || mo2491l(view)) ? 4 : 1;
        int i3 = C4761m.f17241f;
        view.setImportantForAccessibility(i2);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public boolean mo2475b(View view, int i) {
        return (mo2489i(view) & i) == i;
    }

    /* renamed from: c */
    public void mo2476c(View view) {
        int i;
        C4810c cVar;
        if (mo2491l(view)) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            if (this.f2358o) {
                layoutParams.f2371b = 0.0f;
                layoutParams.f2373d = 0;
            } else {
                layoutParams.f2373d |= 4;
                if (mo2475b(view, 3)) {
                    cVar = this.f2352i;
                    i = -view.getWidth();
                } else {
                    cVar = this.f2353j;
                    i = getWidth();
                }
                cVar.mo22030H(view, i, view.getTop());
            }
            invalidate();
            return;
        }
        throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof LayoutParams) && super.checkLayoutParams(layoutParams);
    }

    public void computeScroll() {
        int childCount = getChildCount();
        float f = 0.0f;
        for (int i = 0; i < childCount; i++) {
            f = Math.max(f, ((LayoutParams) getChildAt(i).getLayoutParams()).f2371b);
        }
        this.f2350g = f;
        boolean k = this.f2352i.mo22036k(true);
        boolean k2 = this.f2353j.mo22036k(true);
        if (k || k2) {
            int i2 = C4761m.f17241f;
            postInvalidateOnAnimation();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public void mo2479d(boolean z) {
        int childCount = getChildCount();
        boolean z2 = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            if (mo2491l(childAt) && (!z || layoutParams.f2372c)) {
                z2 |= mo2475b(childAt, 3) ? this.f2352i.mo22030H(childAt, -childAt.getWidth(), childAt.getTop()) : this.f2353j.mo22030H(childAt, getWidth(), childAt.getTop());
                layoutParams.f2372c = false;
            }
        }
        this.f2354k.mo2528n();
        this.f2355l.mo2528n();
        if (z2) {
            invalidate();
        }
    }

    public boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        boolean z;
        if ((motionEvent.getSource() & 2) == 0 || motionEvent.getAction() == 10 || this.f2350g <= 0.0f) {
            return super.dispatchGenericMotionEvent(motionEvent);
        }
        int childCount = getChildCount();
        if (childCount == 0) {
            return false;
        }
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        for (int i = childCount - 1; i >= 0; i--) {
            View childAt = getChildAt(i);
            if (this.f2344A == null) {
                this.f2344A = new Rect();
            }
            childAt.getHitRect(this.f2344A);
            if (this.f2344A.contains((int) x, (int) y) && !mo2490k(childAt)) {
                if (!childAt.getMatrix().isIdentity()) {
                    MotionEvent obtain = MotionEvent.obtain(motionEvent);
                    obtain.offsetLocation((float) (getScrollX() - childAt.getLeft()), (float) (getScrollY() - childAt.getTop()));
                    Matrix matrix = childAt.getMatrix();
                    if (!matrix.isIdentity()) {
                        if (this.f2345B == null) {
                            this.f2345B = new Matrix();
                        }
                        matrix.invert(this.f2345B);
                        obtain.transform(this.f2345B);
                    }
                    z = childAt.dispatchGenericMotionEvent(obtain);
                    obtain.recycle();
                } else {
                    float scrollX = (float) (getScrollX() - childAt.getLeft());
                    float scrollY = (float) (getScrollY() - childAt.getTop());
                    motionEvent.offsetLocation(scrollX, scrollY);
                    z = childAt.dispatchGenericMotionEvent(motionEvent);
                    motionEvent.offsetLocation(-scrollX, -scrollY);
                }
                if (z) {
                    return true;
                }
            }
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public boolean drawChild(Canvas canvas, View view, long j) {
        int height = getHeight();
        boolean k = mo2490k(view);
        int width = getWidth();
        int save = canvas.save();
        int i = 0;
        if (k) {
            int childCount = getChildCount();
            int i2 = 0;
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                if (childAt != view && childAt.getVisibility() == 0) {
                    Drawable background = childAt.getBackground();
                    if ((background != null && background.getOpacity() == -1) && mo2491l(childAt) && childAt.getHeight() >= height) {
                        if (mo2475b(childAt, 3)) {
                            int right = childAt.getRight();
                            if (right > i2) {
                                i2 = right;
                            }
                        } else {
                            int left = childAt.getLeft();
                            if (left < width) {
                                width = left;
                            }
                        }
                    }
                }
            }
            canvas.clipRect(i2, 0, width, getHeight());
            i = i2;
        }
        boolean drawChild = super.drawChild(canvas, view, j);
        canvas.restoreToCount(save);
        float f = this.f2350g;
        if (f > 0.0f && k) {
            int i4 = this.f2349f;
            this.f2351h.setColor((((int) (((float) ((-16777216 & i4) >>> 24)) * f)) << 24) | (i4 & 16777215));
            canvas.drawRect((float) i, 0.0f, (float) width, (float) getHeight(), this.f2351h);
        }
        return drawChild;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public View mo2482e(int i) {
        int i2 = C4761m.f17241f;
        int absoluteGravity = Gravity.getAbsoluteGravity(i, getLayoutDirection()) & 7;
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if ((mo2489i(childAt) & 7) == absoluteGravity) {
                return childAt;
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public View mo2483f() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if ((((LayoutParams) childAt.getLayoutParams()).f2373d & 1) == 1) {
                return childAt;
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public View mo2484g() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (mo2491l(childAt)) {
                if (mo2491l(childAt)) {
                    if (((LayoutParams) childAt.getLayoutParams()).f2371b > 0.0f) {
                        return childAt;
                    }
                } else {
                    throw new IllegalArgumentException("View " + childAt + " is not a drawer");
                }
            }
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-1, -1);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams ? new LayoutParams((LayoutParams) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams) : new LayoutParams(layoutParams);
    }

    /* renamed from: h */
    public int mo2488h(View view) {
        if (mo2491l(view)) {
            int i = ((LayoutParams) view.getLayoutParams()).f2370a;
            int i2 = C4761m.f17241f;
            int layoutDirection = getLayoutDirection();
            if (i == 3) {
                int i3 = this.f2359p;
                if (i3 != 3) {
                    return i3;
                }
                int i4 = layoutDirection == 0 ? this.f2361r : this.f2362s;
                if (i4 != 3) {
                    return i4;
                }
            } else if (i == 5) {
                int i5 = this.f2360q;
                if (i5 != 3) {
                    return i5;
                }
                int i6 = layoutDirection == 0 ? this.f2362s : this.f2361r;
                if (i6 != 3) {
                    return i6;
                }
            } else if (i == 8388611) {
                int i7 = this.f2361r;
                if (i7 != 3) {
                    return i7;
                }
                int i8 = layoutDirection == 0 ? this.f2359p : this.f2360q;
                if (i8 != 3) {
                    return i8;
                }
            } else if (i == 8388613) {
                int i9 = this.f2362s;
                if (i9 != 3) {
                    return i9;
                }
                int i10 = layoutDirection == 0 ? this.f2360q : this.f2359p;
                if (i10 != 3) {
                    return i10;
                }
            }
            return 0;
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public int mo2489i(View view) {
        int i = ((LayoutParams) view.getLayoutParams()).f2370a;
        int i2 = C4761m.f17241f;
        return Gravity.getAbsoluteGravity(i, getLayoutDirection());
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k */
    public boolean mo2490k(View view) {
        return ((LayoutParams) view.getLayoutParams()).f2370a == 0;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l */
    public boolean mo2491l(View view) {
        int i = ((LayoutParams) view.getLayoutParams()).f2370a;
        int i2 = C4761m.f17241f;
        int absoluteGravity = Gravity.getAbsoluteGravity(i, view.getLayoutDirection());
        return ((absoluteGravity & 3) == 0 && (absoluteGravity & 5) == 0) ? false : true;
    }

    /* renamed from: m */
    public void mo2492m(View view) {
        C4810c cVar;
        if (mo2491l(view)) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            if (this.f2358o) {
                layoutParams.f2371b = 1.0f;
                layoutParams.f2373d = 1;
                m2303q(view, true);
            } else {
                int i = 0;
                layoutParams.f2373d |= 2;
                if (mo2475b(view, 3)) {
                    cVar = this.f2352i;
                } else {
                    cVar = this.f2353j;
                    i = getWidth() - view.getWidth();
                }
                cVar.mo22030H(view, i, view.getTop());
            }
            invalidate();
            return;
        }
        throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
    }

    /* renamed from: n */
    public void mo2493n(Object obj, boolean z) {
        this.f2367x = obj;
        this.f2368y = z;
        setWillNotDraw(!z && getBackground() == null);
        requestLayout();
    }

    /* renamed from: o */
    public void mo2494o(int i, int i2) {
        View e;
        int i3 = C4761m.f17241f;
        int absoluteGravity = Gravity.getAbsoluteGravity(i2, getLayoutDirection());
        if (i2 == 3) {
            this.f2359p = i;
        } else if (i2 == 5) {
            this.f2360q = i;
        } else if (i2 == 8388611) {
            this.f2361r = i;
        } else if (i2 == 8388613) {
            this.f2362s = i;
        }
        if (i != 0) {
            (absoluteGravity == 3 ? this.f2352i : this.f2353j).mo22033b();
        }
        if (i == 1) {
            View e2 = mo2482e(absoluteGravity);
            if (e2 != null) {
                mo2476c(e2);
            }
        } else if (i == 2 && (e = mo2482e(absoluteGravity)) != null) {
            mo2492m(e);
        }
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f2358o = true;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f2358o = true;
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f2368y && this.f2366w != null) {
            Object obj = this.f2367x;
            int systemWindowInsetTop = obj != null ? ((WindowInsets) obj).getSystemWindowInsetTop() : 0;
            if (systemWindowInsetTop > 0) {
                this.f2366w.setBounds(0, 0, getWidth(), systemWindowInsetTop);
                this.f2366w.draw(canvas);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x004b, code lost:
        r7 = r6.f2352i.mo22037o((int) r0, (int) r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:5:0x001b, code lost:
        if (r0 != 3) goto L_0x0036;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onInterceptTouchEvent(android.view.MotionEvent r7) {
        /*
            r6 = this;
            int r0 = r7.getActionMasked()
            d.h.a.c r1 = r6.f2352i
            boolean r1 = r1.mo22029G(r7)
            d.h.a.c r2 = r6.f2353j
            boolean r2 = r2.mo22029G(r7)
            r1 = r1 | r2
            r2 = 1
            r3 = 0
            if (r0 == 0) goto L_0x0038
            if (r0 == r2) goto L_0x0031
            r7 = 2
            r4 = 3
            if (r0 == r7) goto L_0x001e
            if (r0 == r4) goto L_0x0031
            goto L_0x0036
        L_0x001e:
            d.h.a.c r7 = r6.f2352i
            boolean r7 = r7.mo22035e(r4)
            if (r7 == 0) goto L_0x0036
            androidx.drawerlayout.widget.DrawerLayout$d r7 = r6.f2354k
            r7.mo2528n()
            androidx.drawerlayout.widget.DrawerLayout$d r7 = r6.f2355l
            r7.mo2528n()
            goto L_0x0036
        L_0x0031:
            r6.mo2479d(r2)
            r6.f2363t = r3
        L_0x0036:
            r7 = 0
            goto L_0x0060
        L_0x0038:
            float r0 = r7.getX()
            float r7 = r7.getY()
            r6.f2364u = r0
            r6.f2365v = r7
            float r4 = r6.f2350g
            r5 = 0
            int r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r4 <= 0) goto L_0x005d
            d.h.a.c r4 = r6.f2352i
            int r0 = (int) r0
            int r7 = (int) r7
            android.view.View r7 = r4.mo22037o(r0, r7)
            if (r7 == 0) goto L_0x005d
            boolean r7 = r6.mo2490k(r7)
            if (r7 == 0) goto L_0x005d
            r7 = 1
            goto L_0x005e
        L_0x005d:
            r7 = 0
        L_0x005e:
            r6.f2363t = r3
        L_0x0060:
            if (r1 != 0) goto L_0x0087
            if (r7 != 0) goto L_0x0087
            int r7 = r6.getChildCount()
            r0 = 0
        L_0x0069:
            if (r0 >= r7) goto L_0x007e
            android.view.View r1 = r6.getChildAt(r0)
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.drawerlayout.widget.DrawerLayout$LayoutParams r1 = (androidx.drawerlayout.widget.DrawerLayout.LayoutParams) r1
            boolean r1 = r1.f2372c
            if (r1 == 0) goto L_0x007b
            r7 = 1
            goto L_0x007f
        L_0x007b:
            int r0 = r0 + 1
            goto L_0x0069
        L_0x007e:
            r7 = 0
        L_0x007f:
            if (r7 != 0) goto L_0x0087
            boolean r7 = r6.f2363t
            if (r7 == 0) goto L_0x0086
            goto L_0x0087
        L_0x0086:
            r2 = 0
        L_0x0087:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.drawerlayout.widget.DrawerLayout.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 4) {
            if (mo2484g() != null) {
                keyEvent.startTracking();
                return true;
            }
        }
        return super.onKeyDown(i, keyEvent);
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (i != 4) {
            return super.onKeyUp(i, keyEvent);
        }
        View g = mo2484g();
        if (g != null && mo2488h(g) == 0) {
            mo2479d(false);
        }
        return g != null;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        float f;
        int i5;
        int measuredHeight;
        int i6;
        int i7;
        this.f2357n = true;
        int i8 = i3 - i;
        int childCount = getChildCount();
        for (int i9 = 0; i9 < childCount; i9++) {
            View childAt = getChildAt(i9);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (mo2490k(childAt)) {
                    int i10 = layoutParams.leftMargin;
                    childAt.layout(i10, layoutParams.topMargin, childAt.getMeasuredWidth() + i10, childAt.getMeasuredHeight() + layoutParams.topMargin);
                } else {
                    int measuredWidth = childAt.getMeasuredWidth();
                    int measuredHeight2 = childAt.getMeasuredHeight();
                    if (mo2475b(childAt, 3)) {
                        float f2 = (float) measuredWidth;
                        i5 = (-measuredWidth) + ((int) (layoutParams.f2371b * f2));
                        f = ((float) (measuredWidth + i5)) / f2;
                    } else {
                        float f3 = (float) measuredWidth;
                        int i11 = i8 - ((int) (layoutParams.f2371b * f3));
                        f = ((float) (i8 - i11)) / f3;
                        i5 = i11;
                    }
                    boolean z2 = f != layoutParams.f2371b;
                    int i12 = layoutParams.f2370a & 112;
                    if (i12 != 16) {
                        if (i12 != 80) {
                            measuredHeight = layoutParams.topMargin;
                            i6 = measuredWidth + i5;
                            i7 = measuredHeight2 + measuredHeight;
                        } else {
                            int i13 = i4 - i2;
                            measuredHeight = (i13 - layoutParams.bottomMargin) - childAt.getMeasuredHeight();
                            i6 = measuredWidth + i5;
                            i7 = i13 - layoutParams.bottomMargin;
                        }
                        childAt.layout(i5, measuredHeight, i6, i7);
                    } else {
                        int i14 = i4 - i2;
                        int i15 = (i14 - measuredHeight2) / 2;
                        int i16 = layoutParams.topMargin;
                        if (i15 < i16) {
                            i15 = i16;
                        } else {
                            int i17 = i15 + measuredHeight2;
                            int i18 = layoutParams.bottomMargin;
                            if (i17 > i14 - i18) {
                                i15 = (i14 - i18) - measuredHeight2;
                            }
                        }
                        childAt.layout(i5, i15, measuredWidth + i5, measuredHeight2 + i15);
                    }
                    if (z2) {
                        mo2507p(childAt, f);
                    }
                    int i19 = layoutParams.f2371b > 0.0f ? 0 : 4;
                    if (childAt.getVisibility() != i19) {
                        childAt.setVisibility(i19);
                    }
                }
            }
        }
        this.f2357n = false;
        this.f2358o = false;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0050  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r17, int r18) {
        /*
            r16 = this;
            r0 = r16
            int r1 = android.view.View.MeasureSpec.getMode(r17)
            int r2 = android.view.View.MeasureSpec.getMode(r18)
            int r3 = android.view.View.MeasureSpec.getSize(r17)
            int r4 = android.view.View.MeasureSpec.getSize(r18)
            r5 = 1073741824(0x40000000, float:2.0)
            if (r1 != r5) goto L_0x0018
            if (r2 == r5) goto L_0x002e
        L_0x0018:
            boolean r5 = r16.isInEditMode()
            if (r5 == 0) goto L_0x01b4
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r1 != r5) goto L_0x0023
            goto L_0x0027
        L_0x0023:
            if (r1 != 0) goto L_0x0027
            r3 = 300(0x12c, float:4.2E-43)
        L_0x0027:
            if (r2 != r5) goto L_0x002a
            goto L_0x002e
        L_0x002a:
            if (r2 != 0) goto L_0x002e
            r4 = 300(0x12c, float:4.2E-43)
        L_0x002e:
            r0.setMeasuredDimension(r3, r4)
            java.lang.Object r1 = r0.f2367x
            r2 = 0
            if (r1 == 0) goto L_0x0040
            int r1 = p098d.p120g.p130j.C4761m.f17241f
            boolean r1 = r16.getFitsSystemWindows()
            if (r1 == 0) goto L_0x0040
            r1 = 1
            goto L_0x0041
        L_0x0040:
            r1 = 0
        L_0x0041:
            int r5 = p098d.p120g.p130j.C4761m.f17241f
            int r5 = r16.getLayoutDirection()
            int r6 = r16.getChildCount()
            r7 = 0
            r8 = 0
            r9 = 0
        L_0x004e:
            if (r7 >= r6) goto L_0x01b3
            android.view.View r10 = r0.getChildAt(r7)
            int r11 = r10.getVisibility()
            r12 = 8
            if (r11 != r12) goto L_0x005e
            goto L_0x0101
        L_0x005e:
            android.view.ViewGroup$LayoutParams r11 = r10.getLayoutParams()
            androidx.drawerlayout.widget.DrawerLayout$LayoutParams r11 = (androidx.drawerlayout.widget.DrawerLayout.LayoutParams) r11
            r12 = 3
            if (r1 == 0) goto L_0x00e0
            int r13 = r11.f2370a
            int r13 = android.view.Gravity.getAbsoluteGravity(r13, r5)
            boolean r14 = r10.getFitsSystemWindows()
            java.lang.Object r15 = r0.f2367x
            android.view.WindowInsets r15 = (android.view.WindowInsets) r15
            if (r14 == 0) goto L_0x00a1
            if (r13 != r12) goto L_0x008a
            int r12 = r15.getSystemWindowInsetLeft()
            int r13 = r15.getSystemWindowInsetTop()
            int r14 = r15.getSystemWindowInsetBottom()
            android.view.WindowInsets r15 = r15.replaceSystemWindowInsets(r12, r13, r2, r14)
            goto L_0x009d
        L_0x008a:
            r12 = 5
            if (r13 != r12) goto L_0x009d
            int r12 = r15.getSystemWindowInsetTop()
            int r13 = r15.getSystemWindowInsetRight()
            int r14 = r15.getSystemWindowInsetBottom()
            android.view.WindowInsets r15 = r15.replaceSystemWindowInsets(r2, r12, r13, r14)
        L_0x009d:
            r10.dispatchApplyWindowInsets(r15)
            goto L_0x00e0
        L_0x00a1:
            r12 = 3
            if (r13 != r12) goto L_0x00b5
            int r12 = r15.getSystemWindowInsetLeft()
            int r13 = r15.getSystemWindowInsetTop()
            int r14 = r15.getSystemWindowInsetBottom()
            android.view.WindowInsets r15 = r15.replaceSystemWindowInsets(r12, r13, r2, r14)
            goto L_0x00c8
        L_0x00b5:
            r12 = 5
            if (r13 != r12) goto L_0x00c8
            int r12 = r15.getSystemWindowInsetTop()
            int r13 = r15.getSystemWindowInsetRight()
            int r14 = r15.getSystemWindowInsetBottom()
            android.view.WindowInsets r15 = r15.replaceSystemWindowInsets(r2, r12, r13, r14)
        L_0x00c8:
            int r2 = r15.getSystemWindowInsetLeft()
            r11.leftMargin = r2
            int r2 = r15.getSystemWindowInsetTop()
            r11.topMargin = r2
            int r2 = r15.getSystemWindowInsetRight()
            r11.rightMargin = r2
            int r2 = r15.getSystemWindowInsetBottom()
            r11.bottomMargin = r2
        L_0x00e0:
            boolean r2 = r0.mo2490k(r10)
            if (r2 == 0) goto L_0x0107
            int r2 = r11.leftMargin
            int r2 = r3 - r2
            int r12 = r11.rightMargin
            int r2 = r2 - r12
            r12 = 1073741824(0x40000000, float:2.0)
            int r2 = android.view.View.MeasureSpec.makeMeasureSpec(r2, r12)
            int r13 = r11.topMargin
            int r13 = r4 - r13
            int r11 = r11.bottomMargin
            int r13 = r13 - r11
            int r11 = android.view.View.MeasureSpec.makeMeasureSpec(r13, r12)
            r10.measure(r2, r11)
        L_0x0101:
            r13 = r17
            r14 = r18
            goto L_0x0185
        L_0x0107:
            boolean r2 = r0.mo2491l(r10)
            if (r2 == 0) goto L_0x018a
            float r2 = r10.getElevation()
            float r12 = r0.f2347d
            int r2 = (r2 > r12 ? 1 : (r2 == r12 ? 0 : -1))
            if (r2 == 0) goto L_0x011a
            r10.setElevation(r12)
        L_0x011a:
            int r2 = r0.mo2489i(r10)
            r2 = r2 & 7
            r12 = 3
            if (r2 != r12) goto L_0x0125
            r12 = 1
            goto L_0x0126
        L_0x0125:
            r12 = 0
        L_0x0126:
            if (r12 == 0) goto L_0x012a
            if (r8 != 0) goto L_0x012e
        L_0x012a:
            if (r12 != 0) goto L_0x0160
            if (r9 == 0) goto L_0x0160
        L_0x012e:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r3 = "Child drawer has absolute gravity "
            java.lang.StringBuilder r3 = p165e.p166a.p167a.p168a.C4924a.m17863P(r3)
            r4 = r2 & 3
            r5 = 3
            if (r4 == r5) goto L_0x0148
            r4 = r2 & 5
            r5 = 5
            if (r4 != r5) goto L_0x0143
            java.lang.String r2 = "RIGHT"
            goto L_0x014a
        L_0x0143:
            java.lang.String r2 = java.lang.Integer.toHexString(r2)
            goto L_0x014a
        L_0x0148:
            java.lang.String r2 = "LEFT"
        L_0x014a:
            java.lang.String r4 = " but this "
            java.lang.String r5 = "DrawerLayout"
            java.lang.String r6 = " already has a "
            p165e.p166a.p167a.p168a.C4924a.m17885f0(r3, r2, r4, r5, r6)
            java.lang.String r2 = "drawer view along that edge"
            r3.append(r2)
            java.lang.String r2 = r3.toString()
            r1.<init>(r2)
            throw r1
        L_0x0160:
            if (r12 == 0) goto L_0x0164
            r8 = 1
            goto L_0x0165
        L_0x0164:
            r9 = 1
        L_0x0165:
            int r2 = r0.f2348e
            int r12 = r11.leftMargin
            int r2 = r2 + r12
            int r12 = r11.rightMargin
            int r2 = r2 + r12
            int r12 = r11.width
            r13 = r17
            int r2 = android.view.ViewGroup.getChildMeasureSpec(r13, r2, r12)
            int r12 = r11.topMargin
            int r14 = r11.bottomMargin
            int r12 = r12 + r14
            int r11 = r11.height
            r14 = r18
            int r11 = android.view.ViewGroup.getChildMeasureSpec(r14, r12, r11)
            r10.measure(r2, r11)
        L_0x0185:
            int r7 = r7 + 1
            r2 = 0
            goto L_0x004e
        L_0x018a:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "Child "
            r2.append(r3)
            r2.append(r10)
            java.lang.String r3 = " at index "
            r2.append(r3)
            r2.append(r7)
            java.lang.String r3 = " does not have a valid layout_gravity - must be Gravity.LEFT, "
            r2.append(r3)
            java.lang.String r3 = "Gravity.RIGHT or Gravity.NO_GRAVITY"
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x01b3:
            return
        L_0x01b4:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "DrawerLayout must be measured with MeasureSpec.EXACTLY."
            r1.<init>(r2)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.drawerlayout.widget.DrawerLayout.onMeasure(int, int):void");
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        View e;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.mo2467a());
        int i = savedState.f2374c;
        if (!(i == 0 || (e = mo2482e(i)) == null)) {
            mo2492m(e);
        }
        int i2 = savedState.f2375d;
        if (i2 != 3) {
            mo2494o(i2, 3);
        }
        int i3 = savedState.f2376e;
        if (i3 != 3) {
            mo2494o(i3, 5);
        }
        int i4 = savedState.f2377f;
        if (i4 != 3) {
            mo2494o(i4, 8388611);
        }
        int i5 = savedState.f2378g;
        if (i5 != 3) {
            mo2494o(i5, 8388613);
        }
    }

    public void onRtlPropertiesChanged(int i) {
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        int childCount = getChildCount();
        int i = 0;
        while (true) {
            if (i >= childCount) {
                break;
            }
            LayoutParams layoutParams = (LayoutParams) getChildAt(i).getLayoutParams();
            int i2 = layoutParams.f2373d;
            boolean z = true;
            boolean z2 = i2 == 1;
            if (i2 != 2) {
                z = false;
            }
            if (z2 || z) {
                savedState.f2374c = layoutParams.f2370a;
            } else {
                i++;
            }
        }
        savedState.f2375d = this.f2359p;
        savedState.f2376e = this.f2360q;
        savedState.f2377f = this.f2361r;
        savedState.f2378g = this.f2362s;
        return savedState;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0059, code lost:
        if (mo2488h(r7) != 2) goto L_0x005c;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r7) {
        /*
            r6 = this;
            d.h.a.c r0 = r6.f2352i
            r0.mo22044x(r7)
            d.h.a.c r0 = r6.f2353j
            r0.mo22044x(r7)
            int r0 = r7.getAction()
            r0 = r0 & 255(0xff, float:3.57E-43)
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x0060
            if (r0 == r2) goto L_0x001e
            r7 = 3
            if (r0 == r7) goto L_0x001a
            goto L_0x006e
        L_0x001a:
            r6.mo2479d(r2)
            goto L_0x006c
        L_0x001e:
            float r0 = r7.getX()
            float r7 = r7.getY()
            d.h.a.c r3 = r6.f2352i
            int r4 = (int) r0
            int r5 = (int) r7
            android.view.View r3 = r3.mo22037o(r4, r5)
            if (r3 == 0) goto L_0x005b
            boolean r3 = r6.mo2490k(r3)
            if (r3 == 0) goto L_0x005b
            float r3 = r6.f2364u
            float r0 = r0 - r3
            float r3 = r6.f2365v
            float r7 = r7 - r3
            d.h.a.c r3 = r6.f2352i
            int r3 = r3.mo22040s()
            float r0 = r0 * r0
            float r7 = r7 * r7
            float r7 = r7 + r0
            int r3 = r3 * r3
            float r0 = (float) r3
            int r7 = (r7 > r0 ? 1 : (r7 == r0 ? 0 : -1))
            if (r7 >= 0) goto L_0x005b
            android.view.View r7 = r6.mo2483f()
            if (r7 == 0) goto L_0x005b
            int r7 = r6.mo2488h(r7)
            r0 = 2
            if (r7 != r0) goto L_0x005c
        L_0x005b:
            r1 = 1
        L_0x005c:
            r6.mo2479d(r1)
            goto L_0x006e
        L_0x0060:
            float r0 = r7.getX()
            float r7 = r7.getY()
            r6.f2364u = r0
            r6.f2365v = r7
        L_0x006c:
            r6.f2363t = r1
        L_0x006e:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.drawerlayout.widget.DrawerLayout.onTouchEvent(android.view.MotionEvent):boolean");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p */
    public void mo2507p(View view, float f) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (f != layoutParams.f2371b) {
            layoutParams.f2371b = f;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: r */
    public void mo2508r(int i, View view) {
        View rootView;
        int t = this.f2352i.mo22041t();
        int t2 = this.f2353j.mo22041t();
        int i2 = 2;
        if (t == 1 || t2 == 1) {
            i2 = 1;
        } else if (!(t == 2 || t2 == 2)) {
            i2 = 0;
        }
        if (view != null && i == 0) {
            float f = ((LayoutParams) view.getLayoutParams()).f2371b;
            if (f == 0.0f) {
                LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
                if ((layoutParams.f2373d & 1) == 1) {
                    layoutParams.f2373d = 0;
                    m2303q(view, false);
                    if (hasWindowFocus() && (rootView = getRootView()) != null) {
                        rootView.sendAccessibilityEvent(32);
                    }
                }
            } else if (f == 1.0f) {
                LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
                if ((layoutParams2.f2373d & 1) == 0) {
                    layoutParams2.f2373d = 1;
                    m2303q(view, true);
                    if (hasWindowFocus()) {
                        sendAccessibilityEvent(32);
                    }
                }
            }
        }
        if (i2 != this.f2356m) {
            this.f2356m = i2;
        }
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        super.requestDisallowInterceptTouchEvent(z);
        if (z) {
            mo2479d(true);
        }
    }

    public void requestLayout() {
        if (!this.f2357n) {
            super.requestLayout();
        }
    }
}
