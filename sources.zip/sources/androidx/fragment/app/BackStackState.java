package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.fragment.app.C0553c0;
import java.util.ArrayList;

final class BackStackState implements Parcelable {
    public static final Parcelable.Creator<BackStackState> CREATOR = new C0514a();

    /* renamed from: a */
    final int[] f2386a;

    /* renamed from: b */
    final ArrayList<String> f2387b;

    /* renamed from: c */
    final int[] f2388c;

    /* renamed from: d */
    final int[] f2389d;

    /* renamed from: e */
    final int f2390e;

    /* renamed from: f */
    final String f2391f;

    /* renamed from: g */
    final int f2392g;

    /* renamed from: h */
    final int f2393h;

    /* renamed from: i */
    final CharSequence f2394i;

    /* renamed from: j */
    final int f2395j;

    /* renamed from: k */
    final CharSequence f2396k;

    /* renamed from: l */
    final ArrayList<String> f2397l;

    /* renamed from: m */
    final ArrayList<String> f2398m;

    /* renamed from: n */
    final boolean f2399n;

    /* renamed from: androidx.fragment.app.BackStackState$a */
    class C0514a implements Parcelable.Creator<BackStackState> {
        C0514a() {
        }

        public Object createFromParcel(Parcel parcel) {
            return new BackStackState(parcel);
        }

        public Object[] newArray(int i) {
            return new BackStackState[i];
        }
    }

    public BackStackState(Parcel parcel) {
        this.f2386a = parcel.createIntArray();
        this.f2387b = parcel.createStringArrayList();
        this.f2388c = parcel.createIntArray();
        this.f2389d = parcel.createIntArray();
        this.f2390e = parcel.readInt();
        this.f2391f = parcel.readString();
        this.f2392g = parcel.readInt();
        this.f2393h = parcel.readInt();
        this.f2394i = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f2395j = parcel.readInt();
        this.f2396k = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f2397l = parcel.createStringArrayList();
        this.f2398m = parcel.createStringArrayList();
        this.f2399n = parcel.readInt() != 0;
    }

    public BackStackState(C0543a aVar) {
        int size = aVar.f2582a.size();
        this.f2386a = new int[(size * 5)];
        if (aVar.f2588g) {
            this.f2387b = new ArrayList<>(size);
            this.f2388c = new int[size];
            this.f2389d = new int[size];
            int i = 0;
            int i2 = 0;
            while (i < size) {
                C0553c0.C0554a aVar2 = aVar.f2582a.get(i);
                int i3 = i2 + 1;
                this.f2386a[i2] = aVar2.f2598a;
                ArrayList<String> arrayList = this.f2387b;
                Fragment fragment = aVar2.f2599b;
                arrayList.add(fragment != null ? fragment.f2424f : null);
                int[] iArr = this.f2386a;
                int i4 = i3 + 1;
                iArr[i3] = aVar2.f2600c;
                int i5 = i4 + 1;
                iArr[i4] = aVar2.f2601d;
                int i6 = i5 + 1;
                iArr[i5] = aVar2.f2602e;
                iArr[i6] = aVar2.f2603f;
                this.f2388c[i] = aVar2.f2604g.ordinal();
                this.f2389d[i] = aVar2.f2605h.ordinal();
                i++;
                i2 = i6 + 1;
            }
            this.f2390e = aVar.f2587f;
            this.f2391f = aVar.f2590i;
            this.f2392g = aVar.f2556s;
            this.f2393h = aVar.f2591j;
            this.f2394i = aVar.f2592k;
            this.f2395j = aVar.f2593l;
            this.f2396k = aVar.f2594m;
            this.f2397l = aVar.f2595n;
            this.f2398m = aVar.f2596o;
            this.f2399n = aVar.f2597p;
            return;
        }
        throw new IllegalStateException("Not on back stack");
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeIntArray(this.f2386a);
        parcel.writeStringList(this.f2387b);
        parcel.writeIntArray(this.f2388c);
        parcel.writeIntArray(this.f2389d);
        parcel.writeInt(this.f2390e);
        parcel.writeString(this.f2391f);
        parcel.writeInt(this.f2392g);
        parcel.writeInt(this.f2393h);
        TextUtils.writeToParcel(this.f2394i, parcel, 0);
        parcel.writeInt(this.f2395j);
        TextUtils.writeToParcel(this.f2396k, parcel, 0);
        parcel.writeStringList(this.f2397l);
        parcel.writeStringList(this.f2398m);
        parcel.writeInt(this.f2399n ? 1 : 0);
    }
}
