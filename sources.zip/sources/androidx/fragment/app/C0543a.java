package androidx.fragment.app;

import android.util.Log;
import androidx.fragment.app.C0553c0;
import androidx.fragment.app.FragmentManager;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.fragment.app.a */
final class C0543a extends C0553c0 implements FragmentManager.C0533j, FragmentManager.C0536m {

    /* renamed from: q */
    final FragmentManager f2554q;

    /* renamed from: r */
    boolean f2555r;

    /* renamed from: s */
    int f2556s;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    C0543a(FragmentManager fragmentManager) {
        super(fragmentManager.mo2724f0(), fragmentManager.mo2730i0() != null ? fragmentManager.mo2730i0().mo3013e().getClassLoader() : null);
        this.f2556s = -1;
        this.f2554q = fragmentManager;
    }

    /* renamed from: a */
    public boolean mo2770a(ArrayList<C0543a> arrayList, ArrayList<Boolean> arrayList2) {
        if (FragmentManager.m2484s0(2)) {
            Log.v("FragmentManager", "Run: " + this);
        }
        arrayList.add(this);
        arrayList2.add(Boolean.FALSE);
        if (!this.f2588g) {
            return true;
        }
        FragmentManager fragmentManager = this.f2554q;
        if (fragmentManager.f2489d == null) {
            fragmentManager.f2489d = new ArrayList<>();
        }
        fragmentManager.f2489d.add(this);
        return true;
    }

    /* renamed from: e */
    public int mo2794e() {
        return mo2800m(false);
    }

    /* renamed from: f */
    public int mo2795f() {
        return mo2800m(true);
    }

    /* renamed from: g */
    public void mo2796g() {
        mo2872h();
        this.f2554q.mo2712T(this, false);
    }

    public int getId() {
        return this.f2556s;
    }

    public String getName() {
        return this.f2590i;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public void mo2797i(int i, Fragment fragment, String str, int i2) {
        Class<?> cls = fragment.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            StringBuilder P = C4924a.m17863P("Fragment ");
            P.append(cls.getCanonicalName());
            P.append(" must be a public static class to be  properly recreated from instance state.");
            throw new IllegalStateException(P.toString());
        }
        if (str != null) {
            String str2 = fragment.f2443y;
            if (str2 == null || str.equals(str2)) {
                fragment.f2443y = str;
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("Can't change tag of fragment ");
                sb.append(fragment);
                sb.append(": was ");
                throw new IllegalStateException(C4924a.m17853F(sb, fragment.f2443y, " now ", str));
            }
        }
        if (i != 0) {
            if (i != -1) {
                int i3 = fragment.f2441w;
                if (i3 == 0 || i3 == i) {
                    fragment.f2441w = i;
                    fragment.f2442x = i;
                } else {
                    throw new IllegalStateException("Can't change container ID of fragment " + fragment + ": was " + fragment.f2441w + " now " + i);
                }
            } else {
                throw new IllegalArgumentException("Can't add fragment " + fragment + " with tag " + str + " to container view with no id");
            }
        }
        mo2870c(new C0553c0.C0554a(i2, fragment));
        fragment.f2437s = this.f2554q;
    }

    /* renamed from: j */
    public C0553c0 mo2798j(Fragment fragment) {
        FragmentManager fragmentManager = fragment.f2437s;
        if (fragmentManager == null || fragmentManager == this.f2554q) {
            mo2870c(new C0553c0.C0554a(3, fragment));
            return this;
        }
        StringBuilder P = C4924a.m17863P("Cannot remove Fragment attached to a different FragmentManager. Fragment ");
        P.append(fragment.toString());
        P.append(" is already attached to a FragmentManager.");
        throw new IllegalStateException(P.toString());
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l */
    public void mo2799l(int i) {
        if (this.f2588g) {
            if (FragmentManager.m2484s0(2)) {
                Log.v("FragmentManager", "Bump nesting in " + this + " by " + i);
            }
            int size = this.f2582a.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0553c0.C0554a aVar = this.f2582a.get(i2);
                Fragment fragment = aVar.f2599b;
                if (fragment != null) {
                    fragment.f2436r += i;
                    if (FragmentManager.m2484s0(2)) {
                        StringBuilder P = C4924a.m17863P("Bump nesting of ");
                        P.append(aVar.f2599b);
                        P.append(" to ");
                        P.append(aVar.f2599b.f2436r);
                        Log.v("FragmentManager", P.toString());
                    }
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: m */
    public int mo2800m(boolean z) {
        if (!this.f2555r) {
            if (FragmentManager.m2484s0(2)) {
                Log.v("FragmentManager", "Commit: " + this);
                PrintWriter printWriter = new PrintWriter(new C0595p0("FragmentManager"));
                mo2801n("  ", printWriter, true);
                printWriter.close();
            }
            this.f2555r = true;
            this.f2556s = this.f2588g ? this.f2554q.mo2723f() : -1;
            this.f2554q.mo2709Q(this, z);
            return this.f2556s;
        }
        throw new IllegalStateException("commit already called");
    }

    /* renamed from: n */
    public void mo2801n(String str, PrintWriter printWriter, boolean z) {
        String str2;
        if (z) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f2590i);
            printWriter.print(" mIndex=");
            printWriter.print(this.f2556s);
            printWriter.print(" mCommitted=");
            printWriter.println(this.f2555r);
            if (this.f2587f != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f2587f));
            }
            if (!(this.f2583b == 0 && this.f2584c == 0)) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f2583b));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f2584c));
            }
            if (!(this.f2585d == 0 && this.f2586e == 0)) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f2585d));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f2586e));
            }
            if (!(this.f2591j == 0 && this.f2592k == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f2591j));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f2592k);
            }
            if (!(this.f2593l == 0 && this.f2594m == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f2593l));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.f2594m);
            }
        }
        if (!this.f2582a.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Operations:");
            int size = this.f2582a.size();
            for (int i = 0; i < size; i++) {
                C0553c0.C0554a aVar = this.f2582a.get(i);
                switch (aVar.f2598a) {
                    case 0:
                        str2 = "NULL";
                        break;
                    case 1:
                        str2 = "ADD";
                        break;
                    case 2:
                        str2 = "REPLACE";
                        break;
                    case 3:
                        str2 = "REMOVE";
                        break;
                    case 4:
                        str2 = "HIDE";
                        break;
                    case 5:
                        str2 = "SHOW";
                        break;
                    case 6:
                        str2 = "DETACH";
                        break;
                    case 7:
                        str2 = "ATTACH";
                        break;
                    case 8:
                        str2 = "SET_PRIMARY_NAV";
                        break;
                    case 9:
                        str2 = "UNSET_PRIMARY_NAV";
                        break;
                    case 10:
                        str2 = "OP_SET_MAX_LIFECYCLE";
                        break;
                    default:
                        StringBuilder P = C4924a.m17863P("cmd=");
                        P.append(aVar.f2598a);
                        str2 = P.toString();
                        break;
                }
                printWriter.print(str);
                printWriter.print("  Op #");
                printWriter.print(i);
                printWriter.print(": ");
                printWriter.print(str2);
                printWriter.print(" ");
                printWriter.println(aVar.f2599b);
                if (z) {
                    if (!(aVar.f2600c == 0 && aVar.f2601d == 0)) {
                        printWriter.print(str);
                        printWriter.print("enterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.f2600c));
                        printWriter.print(" exitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f2601d));
                    }
                    if (aVar.f2602e != 0 || aVar.f2603f != 0) {
                        printWriter.print(str);
                        printWriter.print("popEnterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.f2602e));
                        printWriter.print(" popExitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f2603f));
                    }
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: o */
    public void mo2802o() {
        int size = this.f2582a.size();
        for (int i = 0; i < size; i++) {
            C0553c0.C0554a aVar = this.f2582a.get(i);
            Fragment fragment = aVar.f2599b;
            if (fragment != null) {
                fragment.mo2554J4(false);
                fragment.mo2540C4(aVar.f2600c, aVar.f2601d, aVar.f2602e, aVar.f2603f);
                fragment.mo2550H4(this.f2587f);
                fragment.mo2558L4(this.f2595n, this.f2596o);
            }
            switch (aVar.f2598a) {
                case 1:
                    this.f2554q.mo2705N0(fragment, false);
                    this.f2554q.mo2720d(fragment);
                    break;
                case 3:
                    this.f2554q.mo2696H0(fragment);
                    break;
                case 4:
                    this.f2554q.mo2740p0(fragment);
                    break;
                case 5:
                    this.f2554q.mo2705N0(fragment, false);
                    this.f2554q.mo2710R0(fragment);
                    break;
                case 6:
                    this.f2554q.mo2739p(fragment);
                    break;
                case 7:
                    this.f2554q.mo2705N0(fragment, false);
                    this.f2554q.mo2727h(fragment);
                    break;
                case 8:
                    this.f2554q.mo2708P0(fragment);
                    break;
                case 9:
                    this.f2554q.mo2708P0((Fragment) null);
                    break;
                case 10:
                    this.f2554q.mo2707O0(fragment, aVar.f2605h);
                    break;
                default:
                    StringBuilder P = C4924a.m17863P("Unknown cmd: ");
                    P.append(aVar.f2598a);
                    throw new IllegalArgumentException(P.toString());
            }
            if (!this.f2597p) {
                int i2 = aVar.f2598a;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p */
    public void mo2803p(boolean z) {
        for (int size = this.f2582a.size() - 1; size >= 0; size--) {
            C0553c0.C0554a aVar = this.f2582a.get(size);
            Fragment fragment = aVar.f2599b;
            if (fragment != null) {
                fragment.mo2554J4(true);
                fragment.mo2540C4(aVar.f2600c, aVar.f2601d, aVar.f2602e, aVar.f2603f);
                int i = this.f2587f;
                int i2 = 8194;
                if (i != 4097) {
                    i2 = i != 4099 ? i != 8194 ? 0 : 4097 : 4099;
                }
                fragment.mo2550H4(i2);
                fragment.mo2558L4(this.f2596o, this.f2595n);
            }
            switch (aVar.f2598a) {
                case 1:
                    this.f2554q.mo2705N0(fragment, true);
                    this.f2554q.mo2696H0(fragment);
                    break;
                case 3:
                    this.f2554q.mo2720d(fragment);
                    break;
                case 4:
                    this.f2554q.mo2710R0(fragment);
                    break;
                case 5:
                    this.f2554q.mo2705N0(fragment, true);
                    this.f2554q.mo2740p0(fragment);
                    break;
                case 6:
                    this.f2554q.mo2727h(fragment);
                    break;
                case 7:
                    this.f2554q.mo2705N0(fragment, true);
                    this.f2554q.mo2739p(fragment);
                    break;
                case 8:
                    this.f2554q.mo2708P0((Fragment) null);
                    break;
                case 9:
                    this.f2554q.mo2708P0(fragment);
                    break;
                case 10:
                    this.f2554q.mo2707O0(fragment, aVar.f2604g);
                    break;
                default:
                    StringBuilder P = C4924a.m17863P("Unknown cmd: ");
                    P.append(aVar.f2598a);
                    throw new IllegalArgumentException(P.toString());
            }
            if (!this.f2597p) {
                int i3 = aVar.f2598a;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q */
    public boolean mo2804q(int i) {
        int size = this.f2582a.size();
        for (int i2 = 0; i2 < size; i2++) {
            Fragment fragment = this.f2582a.get(i2).f2599b;
            int i3 = fragment != null ? fragment.f2442x : 0;
            if (i3 != 0 && i3 == i) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: r */
    public boolean mo2805r(ArrayList<C0543a> arrayList, int i, int i2) {
        if (i2 == i) {
            return false;
        }
        int size = this.f2582a.size();
        int i3 = -1;
        for (int i4 = 0; i4 < size; i4++) {
            Fragment fragment = this.f2582a.get(i4).f2599b;
            int i5 = fragment != null ? fragment.f2442x : 0;
            if (!(i5 == 0 || i5 == i3)) {
                for (int i6 = i; i6 < i2; i6++) {
                    C0543a aVar = arrayList.get(i6);
                    int size2 = aVar.f2582a.size();
                    for (int i7 = 0; i7 < size2; i7++) {
                        Fragment fragment2 = aVar.f2582a.get(i7).f2599b;
                        if ((fragment2 != null ? fragment2.f2442x : 0) == i5) {
                            return true;
                        }
                    }
                }
                i3 = i5;
            }
        }
        return false;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f2556s >= 0) {
            sb.append(" #");
            sb.append(this.f2556s);
        }
        if (this.f2590i != null) {
            sb.append(" ");
            sb.append(this.f2590i);
        }
        sb.append("}");
        return sb.toString();
    }
}
