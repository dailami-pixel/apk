package androidx.fragment.app;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.fragment.app.C0599q0;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.C0903f;
import androidx.lifecycle.C0910k;
import androidx.lifecycle.C0926v;
import androidx.savedstate.C1284a;
import com.vidio.android.p195tv.R;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.UUID;
import p098d.p120g.p130j.C4761m;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.fragment.app.a0 */
class C0544a0 {

    /* renamed from: a */
    private final C0614w f2557a;

    /* renamed from: b */
    private final C0551b0 f2558b;

    /* renamed from: c */
    private final Fragment f2559c;

    /* renamed from: d */
    private boolean f2560d = false;

    /* renamed from: e */
    private int f2561e = -1;

    /* renamed from: androidx.fragment.app.a0$a */
    class C0545a implements View.OnAttachStateChangeListener {

        /* renamed from: a */
        final /* synthetic */ View f2562a;

        C0545a(C0544a0 a0Var, View view) {
            this.f2562a = view;
        }

        public void onViewAttachedToWindow(View view) {
            this.f2562a.removeOnAttachStateChangeListener(this);
            View view2 = this.f2562a;
            int i = C4761m.f17241f;
            view2.requestApplyInsets();
        }

        public void onViewDetachedFromWindow(View view) {
        }
    }

    C0544a0(C0614w wVar, C0551b0 b0Var, Fragment fragment) {
        this.f2557a = wVar;
        this.f2558b = b0Var;
        this.f2559c = fragment;
    }

    C0544a0(C0614w wVar, C0551b0 b0Var, Fragment fragment, FragmentState fragmentState) {
        this.f2557a = wVar;
        this.f2558b = b0Var;
        this.f2559c = fragment;
        fragment.f2422d = null;
        fragment.f2423e = null;
        fragment.f2436r = 0;
        fragment.f2433o = false;
        fragment.f2430l = false;
        Fragment fragment2 = fragment.f2426h;
        fragment.f2427i = fragment2 != null ? fragment2.f2424f : null;
        fragment.f2426h = null;
        Bundle bundle = fragmentState.f2548m;
        fragment.f2421c = bundle == null ? new Bundle() : bundle;
    }

    C0544a0(C0614w wVar, C0551b0 b0Var, ClassLoader classLoader, C0610t tVar, FragmentState fragmentState) {
        this.f2557a = wVar;
        this.f2558b = b0Var;
        Fragment a = tVar.mo2765a(classLoader, fragmentState.f2536a);
        this.f2559c = a;
        Bundle bundle = fragmentState.f2545j;
        if (bundle != null) {
            bundle.setClassLoader(classLoader);
        }
        a.mo2544E4(fragmentState.f2545j);
        a.f2424f = fragmentState.f2537b;
        a.f2432n = fragmentState.f2538c;
        a.f2434p = true;
        a.f2441w = fragmentState.f2539d;
        a.f2442x = fragmentState.f2540e;
        a.f2443y = fragmentState.f2541f;
        a.f2402B = fragmentState.f2542g;
        a.f2431m = fragmentState.f2543h;
        a.f2401A = fragmentState.f2544i;
        a.f2444z = fragmentState.f2546k;
        a.f2414N = C0903f.C0905b.values()[fragmentState.f2547l];
        Bundle bundle2 = fragmentState.f2548m;
        a.f2421c = bundle2 == null ? new Bundle() : bundle2;
        if (FragmentManager.m2484s0(2)) {
            Log.v("FragmentManager", "Instantiated fragment " + a);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo2807a() {
        if (FragmentManager.m2484s0(3)) {
            StringBuilder P = C4924a.m17863P("moveto ACTIVITY_CREATED: ");
            P.append(this.f2559c);
            Log.d("FragmentManager", P.toString());
        }
        Fragment fragment = this.f2559c;
        fragment.mo2600i4(fragment.f2421c);
        C0614w wVar = this.f2557a;
        Fragment fragment2 = this.f2559c;
        wVar.mo3020a(fragment2, fragment2.f2421c, false);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo2808b() {
        int j = this.f2558b.mo2853j(this.f2559c);
        Fragment fragment = this.f2559c;
        fragment.f2405E.addView(fragment.f2406F, j);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo2809c() {
        if (FragmentManager.m2484s0(3)) {
            StringBuilder P = C4924a.m17863P("moveto ATTACHED: ");
            P.append(this.f2559c);
            Log.d("FragmentManager", P.toString());
        }
        Fragment fragment = this.f2559c;
        Fragment fragment2 = fragment.f2426h;
        C0544a0 a0Var = null;
        if (fragment2 != null) {
            C0544a0 m = this.f2558b.mo2856m(fragment2.f2424f);
            if (m != null) {
                Fragment fragment3 = this.f2559c;
                fragment3.f2427i = fragment3.f2426h.f2424f;
                fragment3.f2426h = null;
                a0Var = m;
            } else {
                StringBuilder P2 = C4924a.m17863P("Fragment ");
                P2.append(this.f2559c);
                P2.append(" declared target fragment ");
                P2.append(this.f2559c.f2426h);
                P2.append(" that does not belong to this FragmentManager!");
                throw new IllegalStateException(P2.toString());
            }
        } else {
            String str = fragment.f2427i;
            if (str != null && (a0Var = this.f2558b.mo2856m(str)) == null) {
                StringBuilder P3 = C4924a.m17863P("Fragment ");
                P3.append(this.f2559c);
                P3.append(" declared target fragment ");
                throw new IllegalStateException(C4924a.m17852E(P3, this.f2559c.f2427i, " that does not belong to this FragmentManager!"));
            }
        }
        if (a0Var != null) {
            a0Var.mo2818l();
        }
        Fragment fragment4 = this.f2559c;
        fragment4.f2438t = fragment4.f2437s.mo2730i0();
        Fragment fragment5 = this.f2559c;
        fragment5.f2440v = fragment5.f2437s.mo2733l0();
        this.f2557a.mo3026g(this.f2559c, false);
        this.f2559c.mo2602j4();
        this.f2557a.mo3021b(this.f2559c, false);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public int mo2810d() {
        Fragment fragment = this.f2559c;
        if (fragment.f2437s == null) {
            return fragment.f2420b;
        }
        int i = this.f2561e;
        int ordinal = fragment.f2414N.ordinal();
        if (ordinal == 1) {
            i = Math.min(i, 0);
        } else if (ordinal == 2) {
            i = Math.min(i, 1);
        } else if (ordinal == 3) {
            i = Math.min(i, 5);
        } else if (ordinal != 4) {
            i = Math.min(i, -1);
        }
        Fragment fragment2 = this.f2559c;
        if (fragment2.f2432n) {
            if (fragment2.f2433o) {
                i = Math.max(this.f2561e, 2);
                View view = this.f2559c.f2406F;
                if (view != null && view.getParent() == null) {
                    i = Math.min(i, 2);
                }
            } else {
                i = this.f2561e < 4 ? Math.min(i, fragment2.f2420b) : Math.min(i, 1);
            }
        }
        if (!this.f2559c.f2430l) {
            i = Math.min(i, 1);
        }
        C0599q0.C0603d.C0605b bVar = null;
        Fragment fragment3 = this.f2559c;
        ViewGroup viewGroup = fragment3.f2405E;
        if (viewGroup != null) {
            bVar = C0599q0.m2765m(viewGroup, fragment3.mo2606m3().mo2735m0()).mo2970j(this);
        }
        if (bVar == C0599q0.C0603d.C0605b.ADDING) {
            i = Math.min(i, 6);
        } else if (bVar == C0599q0.C0603d.C0605b.REMOVING) {
            i = Math.max(i, 3);
        } else {
            Fragment fragment4 = this.f2559c;
            if (fragment4.f2431m) {
                i = fragment4.mo2637z3() ? Math.min(i, 1) : Math.min(i, -1);
            }
        }
        Fragment fragment5 = this.f2559c;
        if (fragment5.f2407G && fragment5.f2420b < 5) {
            i = Math.min(i, 4);
        }
        if (FragmentManager.m2484s0(2)) {
            StringBuilder Q = C4924a.m17864Q("computeExpectedState() of ", i, " for ");
            Q.append(this.f2559c);
            Log.v("FragmentManager", Q.toString());
        }
        return i;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo2811e() {
        if (FragmentManager.m2484s0(3)) {
            StringBuilder P = C4924a.m17863P("moveto CREATED: ");
            P.append(this.f2559c);
            Log.d("FragmentManager", P.toString());
        }
        Fragment fragment = this.f2559c;
        if (!fragment.f2413M) {
            this.f2557a.mo3027h(fragment, fragment.f2421c, false);
            Fragment fragment2 = this.f2559c;
            fragment2.mo2603k4(fragment2.f2421c);
            C0614w wVar = this.f2557a;
            Fragment fragment3 = this.f2559c;
            wVar.mo3022c(fragment3, fragment3.f2421c, false);
            return;
        }
        fragment.mo2536A4(fragment.f2421c);
        this.f2559c.f2420b = 1;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public void mo2812f() {
        String str;
        if (!this.f2559c.f2432n) {
            if (FragmentManager.m2484s0(3)) {
                StringBuilder P = C4924a.m17863P("moveto CREATE_VIEW: ");
                P.append(this.f2559c);
                Log.d("FragmentManager", P.toString());
            }
            Fragment fragment = this.f2559c;
            LayoutInflater T3 = fragment.mo2569T3(fragment.f2421c);
            fragment.f2412L = T3;
            ViewGroup viewGroup = null;
            Fragment fragment2 = this.f2559c;
            ViewGroup viewGroup2 = fragment2.f2405E;
            if (viewGroup2 != null) {
                viewGroup = viewGroup2;
            } else {
                int i = fragment2.f2442x;
                if (i != 0) {
                    if (i != -1) {
                        viewGroup = (ViewGroup) fragment2.f2437s.mo2721d0().mo2644b(this.f2559c.f2442x);
                        if (viewGroup == null) {
                            Fragment fragment3 = this.f2559c;
                            if (!fragment3.f2434p) {
                                try {
                                    str = fragment3.mo2619r3().getResourceName(this.f2559c.f2442x);
                                } catch (Resources.NotFoundException unused) {
                                    str = "unknown";
                                }
                                StringBuilder P2 = C4924a.m17863P("No view found for id 0x");
                                P2.append(Integer.toHexString(this.f2559c.f2442x));
                                P2.append(" (");
                                P2.append(str);
                                P2.append(") for fragment ");
                                P2.append(this.f2559c);
                                throw new IllegalArgumentException(P2.toString());
                            }
                        }
                    } else {
                        StringBuilder P3 = C4924a.m17863P("Cannot create fragment ");
                        P3.append(this.f2559c);
                        P3.append(" for a container view with no id");
                        throw new IllegalArgumentException(P3.toString());
                    }
                }
            }
            Fragment fragment4 = this.f2559c;
            fragment4.f2405E = viewGroup;
            fragment4.mo2605l4(T3, viewGroup, fragment4.f2421c);
            View view = this.f2559c.f2406F;
            if (view != null) {
                view.setSaveFromParentEnabled(false);
                Fragment fragment5 = this.f2559c;
                fragment5.f2406F.setTag(R.id.fragment_container_view_tag, fragment5);
                if (viewGroup != null) {
                    mo2808b();
                }
                Fragment fragment6 = this.f2559c;
                if (fragment6.f2444z) {
                    fragment6.f2406F.setVisibility(8);
                }
                View view2 = this.f2559c.f2406F;
                int i2 = C4761m.f17241f;
                if (view2.isAttachedToWindow()) {
                    this.f2559c.f2406F.requestApplyInsets();
                } else {
                    View view3 = this.f2559c.f2406F;
                    view3.addOnAttachStateChangeListener(new C0545a(this, view3));
                }
                Fragment fragment7 = this.f2559c;
                fragment7.mo2595g4(fragment7.f2406F, fragment7.f2421c);
                fragment7.f2439u.mo2703M();
                C0614w wVar = this.f2557a;
                Fragment fragment8 = this.f2559c;
                wVar.mo3032m(fragment8, fragment8.f2406F, fragment8.f2421c, false);
                int visibility = this.f2559c.f2406F.getVisibility();
                this.f2559c.mo2556K4(this.f2559c.f2406F.getAlpha());
                Fragment fragment9 = this.f2559c;
                if (fragment9.f2405E != null && visibility == 0) {
                    View findFocus = fragment9.f2406F.findFocus();
                    if (findFocus != null) {
                        this.f2559c.mo2546F4(findFocus);
                        if (FragmentManager.m2484s0(2)) {
                            Log.v("FragmentManager", "requestFocus: Saved focused view " + findFocus + " for Fragment " + this.f2559c);
                        }
                    }
                    this.f2559c.f2406F.setAlpha(0.0f);
                }
            }
            this.f2559c.f2420b = 2;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public void mo2813g() {
        Fragment f;
        if (FragmentManager.m2484s0(3)) {
            StringBuilder P = C4924a.m17863P("movefrom CREATED: ");
            P.append(this.f2559c);
            Log.d("FragmentManager", P.toString());
        }
        Fragment fragment = this.f2559c;
        boolean z = true;
        boolean z2 = fragment.f2431m && !fragment.mo2637z3();
        if (z2 || this.f2558b.mo2858o().mo3045m(this.f2559c)) {
            C0611u<?> uVar = this.f2559c.f2438t;
            if (uVar instanceof C0926v) {
                z = this.f2558b.mo2858o().mo3042j();
            } else if (uVar.mo3013e() instanceof Activity) {
                z = true ^ ((Activity) uVar.mo3013e()).isChangingConfigurations();
            }
            if (z2 || z) {
                this.f2558b.mo2858o().mo3035d(this.f2559c);
            }
            this.f2559c.mo2607m4();
            this.f2557a.mo3023d(this.f2559c, false);
            Iterator it = ((ArrayList) this.f2558b.mo2854k()).iterator();
            while (it.hasNext()) {
                C0544a0 a0Var = (C0544a0) it.next();
                if (a0Var != null) {
                    Fragment fragment2 = a0Var.f2559c;
                    if (this.f2559c.f2424f.equals(fragment2.f2427i)) {
                        fragment2.f2426h = this.f2559c;
                        fragment2.f2427i = null;
                    }
                }
            }
            Fragment fragment3 = this.f2559c;
            String str = fragment3.f2427i;
            if (str != null) {
                fragment3.f2426h = this.f2558b.mo2849f(str);
            }
            this.f2558b.mo2860q(this);
            return;
        }
        String str2 = this.f2559c.f2427i;
        if (!(str2 == null || (f = this.f2558b.mo2849f(str2)) == null || !f.f2402B)) {
            this.f2559c.f2426h = f;
        }
        this.f2559c.f2420b = 0;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public void mo2814h() {
        View view;
        if (FragmentManager.m2484s0(3)) {
            StringBuilder P = C4924a.m17863P("movefrom CREATE_VIEW: ");
            P.append(this.f2559c);
            Log.d("FragmentManager", P.toString());
        }
        Fragment fragment = this.f2559c;
        ViewGroup viewGroup = fragment.f2405E;
        if (!(viewGroup == null || (view = fragment.f2406F) == null)) {
            viewGroup.removeView(view);
        }
        this.f2559c.mo2609n4();
        this.f2557a.mo3033n(this.f2559c, false);
        Fragment fragment2 = this.f2559c;
        fragment2.f2405E = null;
        fragment2.f2406F = null;
        fragment2.f2416P = null;
        fragment2.f2417Q.mo3923i(null);
        this.f2559c.f2433o = false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public void mo2815i() {
        if (FragmentManager.m2484s0(3)) {
            StringBuilder P = C4924a.m17863P("movefrom ATTACHED: ");
            P.append(this.f2559c);
            Log.d("FragmentManager", P.toString());
        }
        this.f2559c.mo2611o4();
        this.f2557a.mo3024e(this.f2559c, false);
        Fragment fragment = this.f2559c;
        fragment.f2420b = -1;
        fragment.f2438t = null;
        fragment.f2440v = null;
        fragment.f2437s = null;
        if ((fragment.f2431m && !fragment.mo2637z3()) || this.f2558b.mo2858o().mo3045m(this.f2559c)) {
            if (FragmentManager.m2484s0(3)) {
                StringBuilder P2 = C4924a.m17863P("initState called for fragment: ");
                P2.append(this.f2559c);
                Log.d("FragmentManager", P2.toString());
            }
            Fragment fragment2 = this.f2559c;
            Objects.requireNonNull(fragment2);
            fragment2.f2415O = new C0910k(fragment2);
            fragment2.f2418R = C1284a.m5335a(fragment2);
            fragment2.f2424f = UUID.randomUUID().toString();
            fragment2.f2430l = false;
            fragment2.f2431m = false;
            fragment2.f2432n = false;
            fragment2.f2433o = false;
            fragment2.f2434p = false;
            fragment2.f2436r = 0;
            fragment2.f2437s = null;
            fragment2.f2439u = new C0616x();
            fragment2.f2438t = null;
            fragment2.f2441w = 0;
            fragment2.f2442x = 0;
            fragment2.f2443y = null;
            fragment2.f2444z = false;
            fragment2.f2401A = false;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j */
    public void mo2816j() {
        Fragment fragment = this.f2559c;
        if (fragment.f2432n && fragment.f2433o && !fragment.f2435q) {
            if (FragmentManager.m2484s0(3)) {
                StringBuilder P = C4924a.m17863P("moveto CREATE_VIEW: ");
                P.append(this.f2559c);
                Log.d("FragmentManager", P.toString());
            }
            Fragment fragment2 = this.f2559c;
            LayoutInflater T3 = fragment2.mo2569T3(fragment2.f2421c);
            fragment2.f2412L = T3;
            fragment2.mo2605l4(T3, (ViewGroup) null, this.f2559c.f2421c);
            View view = this.f2559c.f2406F;
            if (view != null) {
                view.setSaveFromParentEnabled(false);
                Fragment fragment3 = this.f2559c;
                fragment3.f2406F.setTag(R.id.fragment_container_view_tag, fragment3);
                Fragment fragment4 = this.f2559c;
                if (fragment4.f2444z) {
                    fragment4.f2406F.setVisibility(8);
                }
                Fragment fragment5 = this.f2559c;
                fragment5.mo2595g4(fragment5.f2406F, fragment5.f2421c);
                fragment5.f2439u.mo2703M();
                C0614w wVar = this.f2557a;
                Fragment fragment6 = this.f2559c;
                wVar.mo3032m(fragment6, fragment6.f2406F, fragment6.f2421c, false);
                this.f2559c.f2420b = 2;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k */
    public Fragment mo2817k() {
        return this.f2559c;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l */
    public void mo2818l() {
        ViewGroup viewGroup;
        ViewGroup viewGroup2;
        ViewGroup viewGroup3;
        if (!this.f2560d) {
            boolean z = false;
            z = true;
            try {
                while (true) {
                    int d = mo2810d();
                    Fragment fragment = this.f2559c;
                    int i = fragment.f2420b;
                    if (d != i) {
                        if (d <= i) {
                            switch (i - 1) {
                                case -1:
                                    mo2815i();
                                    break;
                                case 0:
                                    mo2813g();
                                    break;
                                case 1:
                                    mo2814h();
                                    this.f2559c.f2420b = z ? 1 : 0;
                                    break;
                                case 2:
                                    fragment.f2433o = z;
                                    fragment.f2420b = 2;
                                    break;
                                case 3:
                                    if (FragmentManager.m2484s0(3)) {
                                        Log.d("FragmentManager", "movefrom ACTIVITY_CREATED: " + this.f2559c);
                                    }
                                    Fragment fragment2 = this.f2559c;
                                    if (fragment2.f2406F != null && fragment2.f2422d == null) {
                                        mo2823q();
                                    }
                                    Fragment fragment3 = this.f2559c;
                                    if (!(fragment3.f2406F == null || (viewGroup2 = fragment3.f2405E) == null)) {
                                        C0599q0.m2765m(viewGroup2, fragment3.mo2606m3().mo2735m0()).mo2966d(this);
                                    }
                                    this.f2559c.f2420b = 3;
                                    break;
                                case 4:
                                    mo2826t();
                                    break;
                                case 5:
                                    fragment.f2420b = 5;
                                    break;
                                case 6:
                                    mo2819m();
                                    break;
                            }
                        } else {
                            switch (i + 1) {
                                case 0:
                                    mo2809c();
                                    break;
                                case 1:
                                    mo2811e();
                                    break;
                                case 2:
                                    mo2816j();
                                    mo2812f();
                                    break;
                                case 3:
                                    mo2807a();
                                    break;
                                case 4:
                                    if (!(fragment.f2406F == null || (viewGroup3 = fragment.f2405E) == null)) {
                                        C0599q0.m2765m(viewGroup3, fragment.mo2606m3().mo2735m0()).mo2964b(C0599q0.C0603d.C0606c.m2792b(this.f2559c.f2406F.getVisibility()), this);
                                    }
                                    this.f2559c.f2420b = 4;
                                    break;
                                case 5:
                                    mo2825s();
                                    break;
                                case 6:
                                    fragment.f2420b = 6;
                                    break;
                                case 7:
                                    mo2821o();
                                    break;
                            }
                        }
                    } else {
                        if (fragment.f2410J) {
                            if (!(fragment.f2406F == null || (viewGroup = fragment.f2405E) == null)) {
                                C0599q0 m = C0599q0.m2765m(viewGroup, fragment.mo2606m3().mo2735m0());
                                if (this.f2559c.f2444z) {
                                    m.mo2965c(this);
                                } else {
                                    m.mo2967e(this);
                                }
                            }
                            Fragment fragment4 = this.f2559c;
                            FragmentManager fragmentManager = fragment4.f2437s;
                            if (fragmentManager != null) {
                                fragmentManager.mo2742q0(fragment4);
                            }
                            Fragment fragment5 = this.f2559c;
                            fragment5.f2410J = z;
                            boolean z2 = fragment5.f2444z;
                            fragment5.mo2571U3();
                        }
                        this.f2560d = z;
                        return;
                    }
                }
            } finally {
                this.f2560d = z;
            }
        } else if (FragmentManager.m2484s0(2)) {
            StringBuilder P = C4924a.m17863P("Ignoring re-entrant call to moveToExpectedState() for ");
            P.append(this.f2559c);
            Log.v("FragmentManager", P.toString());
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: m */
    public void mo2819m() {
        if (FragmentManager.m2484s0(3)) {
            StringBuilder P = C4924a.m17863P("movefrom RESUMED: ");
            P.append(this.f2559c);
            Log.d("FragmentManager", P.toString());
        }
        this.f2559c.mo2618q4();
        this.f2557a.mo3025f(this.f2559c, false);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n */
    public void mo2820n(ClassLoader classLoader) {
        Bundle bundle = this.f2559c.f2421c;
        if (bundle != null) {
            bundle.setClassLoader(classLoader);
            Fragment fragment = this.f2559c;
            fragment.f2422d = fragment.f2421c.getSparseParcelableArray("android:view_state");
            Fragment fragment2 = this.f2559c;
            fragment2.f2423e = fragment2.f2421c.getBundle("android:view_registry_state");
            Fragment fragment3 = this.f2559c;
            fragment3.f2427i = fragment3.f2421c.getString("android:target_state");
            Fragment fragment4 = this.f2559c;
            if (fragment4.f2427i != null) {
                fragment4.f2428j = fragment4.f2421c.getInt("android:target_req_state", 0);
            }
            Fragment fragment5 = this.f2559c;
            Objects.requireNonNull(fragment5);
            fragment5.f2408H = fragment5.f2421c.getBoolean("android:user_visible_hint", true);
            Fragment fragment6 = this.f2559c;
            if (!fragment6.f2408H) {
                fragment6.f2407G = true;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: o */
    public void mo2821o() {
        if (FragmentManager.m2484s0(3)) {
            StringBuilder P = C4924a.m17863P("moveto RESUMED: ");
            P.append(this.f2559c);
            Log.d("FragmentManager", P.toString());
        }
        Fragment fragment = this.f2559c;
        Fragment.C0518b bVar = fragment.f2409I;
        View view = bVar == null ? null : bVar.f2462o;
        if (view != null) {
            boolean z = true;
            if (view != fragment.f2406F) {
                ViewParent parent = view.getParent();
                while (true) {
                    if (parent == null) {
                        z = false;
                        break;
                    } else if (parent == this.f2559c.f2406F) {
                        break;
                    } else {
                        parent = parent.getParent();
                    }
                }
            }
            if (z) {
                boolean requestFocus = view.requestFocus();
                if (FragmentManager.m2484s0(2)) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("requestFocus: Restoring focused view ");
                    sb.append(view);
                    sb.append(" ");
                    sb.append(requestFocus ? "succeeded" : "failed");
                    sb.append(" on Fragment ");
                    sb.append(this.f2559c);
                    sb.append(" resulting in focused view ");
                    sb.append(this.f2559c.f2406F.findFocus());
                    Log.v("FragmentManager", sb.toString());
                }
            }
        }
        this.f2559c.mo2546F4((View) null);
        this.f2559c.mo2625t4();
        this.f2557a.mo3028i(this.f2559c, false);
        Fragment fragment2 = this.f2559c;
        fragment2.f2421c = null;
        fragment2.f2422d = null;
        fragment2.f2423e = null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p */
    public FragmentState mo2822p() {
        FragmentState fragmentState = new FragmentState(this.f2559c);
        Fragment fragment = this.f2559c;
        if (fragment.f2420b <= -1 || fragmentState.f2548m != null) {
            fragmentState.f2548m = fragment.f2421c;
        } else {
            Bundle bundle = new Bundle();
            Fragment fragment2 = this.f2559c;
            fragment2.mo2588d4(bundle);
            fragment2.f2418R.mo5356d(bundle);
            Parcelable L0 = fragment2.f2439u.mo2702L0();
            if (L0 != null) {
                bundle.putParcelable("android:support:fragments", L0);
            }
            this.f2557a.mo3029j(this.f2559c, bundle, false);
            if (bundle.isEmpty()) {
                bundle = null;
            }
            if (this.f2559c.f2406F != null) {
                mo2823q();
            }
            if (this.f2559c.f2422d != null) {
                if (bundle == null) {
                    bundle = new Bundle();
                }
                bundle.putSparseParcelableArray("android:view_state", this.f2559c.f2422d);
            }
            if (this.f2559c.f2423e != null) {
                if (bundle == null) {
                    bundle = new Bundle();
                }
                bundle.putBundle("android:view_registry_state", this.f2559c.f2423e);
            }
            if (!this.f2559c.f2408H) {
                if (bundle == null) {
                    bundle = new Bundle();
                }
                bundle.putBoolean("android:user_visible_hint", this.f2559c.f2408H);
            }
            fragmentState.f2548m = bundle;
            if (this.f2559c.f2427i != null) {
                if (bundle == null) {
                    fragmentState.f2548m = new Bundle();
                }
                fragmentState.f2548m.putString("android:target_state", this.f2559c.f2427i);
                int i = this.f2559c.f2428j;
                if (i != 0) {
                    fragmentState.f2548m.putInt("android:target_req_state", i);
                }
            }
        }
        return fragmentState;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q */
    public void mo2823q() {
        if (this.f2559c.f2406F != null) {
            SparseArray<Parcelable> sparseArray = new SparseArray<>();
            this.f2559c.f2406F.saveHierarchyState(sparseArray);
            if (sparseArray.size() > 0) {
                this.f2559c.f2422d = sparseArray;
            }
            Bundle bundle = new Bundle();
            this.f2559c.f2416P.mo2955e(bundle);
            if (!bundle.isEmpty()) {
                this.f2559c.f2423e = bundle;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: r */
    public void mo2824r(int i) {
        this.f2561e = i;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: s */
    public void mo2825s() {
        if (FragmentManager.m2484s0(3)) {
            StringBuilder P = C4924a.m17863P("moveto STARTED: ");
            P.append(this.f2559c);
            Log.d("FragmentManager", P.toString());
        }
        this.f2559c.mo2628u4();
        this.f2557a.mo3030k(this.f2559c, false);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: t */
    public void mo2826t() {
        if (FragmentManager.m2484s0(3)) {
            StringBuilder P = C4924a.m17863P("movefrom STARTED: ");
            P.append(this.f2559c);
            Log.d("FragmentManager", P.toString());
        }
        this.f2559c.mo2630v4();
        this.f2557a.mo3031l(this.f2559c, false);
    }
}
