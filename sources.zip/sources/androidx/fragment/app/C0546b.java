package androidx.fragment.app;

import android.animation.Animator;
import android.content.Context;
import android.graphics.Rect;
import android.transition.Transition;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.fragment.app.C0596q;
import androidx.fragment.app.C0599q0;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import p098d.p112d.C4616a;
import p098d.p120g.p126f.C4709a;
import p098d.p120g.p130j.C4759k;
import p098d.p120g.p130j.C4761m;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.fragment.app.b */
class C0546b extends C0599q0 {

    /* renamed from: androidx.fragment.app.b$a */
    class C0547a implements Runnable {

        /* renamed from: a */
        final /* synthetic */ List f2563a;

        /* renamed from: b */
        final /* synthetic */ C0599q0.C0603d f2564b;

        C0547a(List list, C0599q0.C0603d dVar) {
            this.f2563a = list;
            this.f2564b = dVar;
        }

        public void run() {
            if (this.f2563a.contains(this.f2564b)) {
                this.f2563a.remove(this.f2564b);
                C0546b bVar = C0546b.this;
                C0599q0.C0603d dVar = this.f2564b;
                Objects.requireNonNull(bVar);
                dVar.mo2980e().mo2988a(dVar.mo2981f().f2406F);
            }
        }
    }

    /* renamed from: androidx.fragment.app.b$b */
    private static class C0548b extends C0549c {

        /* renamed from: c */
        private boolean f2566c;

        /* renamed from: d */
        private boolean f2567d = false;

        /* renamed from: e */
        private C0596q.C0597a f2568e;

        C0548b(C0599q0.C0603d dVar, C4709a aVar, boolean z) {
            super(dVar, aVar);
            this.f2566c = z;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: e */
        public C0596q.C0597a mo2834e(Context context) {
            if (this.f2567d) {
                return this.f2568e;
            }
            C0596q.C0597a a = C0596q.m2761a(context, mo2836b().mo2981f(), mo2836b().mo2980e() == C0599q0.C0603d.C0606c.VISIBLE, this.f2566c);
            this.f2568e = a;
            this.f2567d = true;
            return a;
        }
    }

    /* renamed from: androidx.fragment.app.b$c */
    private static class C0549c {

        /* renamed from: a */
        private final C0599q0.C0603d f2569a;

        /* renamed from: b */
        private final C4709a f2570b;

        C0549c(C0599q0.C0603d dVar, C4709a aVar) {
            this.f2569a = dVar;
            this.f2570b = aVar;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo2835a() {
            this.f2569a.mo2979d(this.f2570b);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public C0599q0.C0603d mo2836b() {
            return this.f2569a;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: c */
        public C4709a mo2837c() {
            return this.f2570b;
        }

        /* access modifiers changed from: package-private */
        /* JADX WARNING: Code restructure failed: missing block: B:2:0x0014, code lost:
            r2 = androidx.fragment.app.C0599q0.C0603d.C0606c.f2756b;
         */
        /* renamed from: d */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo2838d() {
            /*
                r3 = this;
                androidx.fragment.app.q0$d r0 = r3.f2569a
                androidx.fragment.app.Fragment r0 = r0.mo2981f()
                android.view.View r0 = r0.f2406F
                androidx.fragment.app.q0$d$c r0 = androidx.fragment.app.C0599q0.C0603d.C0606c.m2793f(r0)
                androidx.fragment.app.q0$d r1 = r3.f2569a
                androidx.fragment.app.q0$d$c r1 = r1.mo2980e()
                if (r0 == r1) goto L_0x001d
                androidx.fragment.app.q0$d$c r2 = androidx.fragment.app.C0599q0.C0603d.C0606c.VISIBLE
                if (r0 == r2) goto L_0x001b
                if (r1 == r2) goto L_0x001b
                goto L_0x001d
            L_0x001b:
                r0 = 0
                goto L_0x001e
            L_0x001d:
                r0 = 1
            L_0x001e:
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.C0546b.C0549c.mo2838d():boolean");
        }
    }

    /* renamed from: androidx.fragment.app.b$d */
    private static class C0550d extends C0549c {

        /* renamed from: c */
        private final Object f2571c;

        /* renamed from: d */
        private final boolean f2572d;

        /* renamed from: e */
        private final Object f2573e;

        C0550d(C0599q0.C0603d dVar, C4709a aVar, boolean z, boolean z2) {
            super(dVar, aVar);
            Object obj;
            Object obj2;
            if (dVar.mo2980e() == C0599q0.C0603d.C0606c.VISIBLE) {
                Fragment f = dVar.mo2981f();
                if (z) {
                    obj2 = f.mo2617q3();
                } else {
                    f.mo2587d3();
                    obj2 = null;
                }
                this.f2571c = obj2;
                Fragment f2 = dVar.mo2981f();
                if (z) {
                    Fragment.C0518b bVar = f2.f2409I;
                } else {
                    Fragment.C0518b bVar2 = f2.f2409I;
                }
            } else {
                Fragment f3 = dVar.mo2981f();
                if (z) {
                    obj = f3.mo2621s3();
                } else {
                    f3.mo2594g3();
                    obj = null;
                }
                this.f2571c = obj;
            }
            this.f2572d = true;
            if (z2) {
                Fragment f4 = dVar.mo2981f();
                if (z) {
                    this.f2573e = f4.mo2627u3();
                    return;
                }
                f4.mo2624t3();
            }
            this.f2573e = null;
        }

        /* renamed from: f */
        private C0585l0 m2621f(Object obj) {
            if (obj == null) {
                return null;
            }
            C0585l0 l0Var = C0569j0.f2658b;
            if (obj instanceof Transition) {
                return l0Var;
            }
            C0585l0 l0Var2 = C0569j0.f2659c;
            if (l0Var2 != null && l0Var2.mo2907e(obj)) {
                return l0Var2;
            }
            throw new IllegalArgumentException("Transition " + obj + " for fragment " + mo2836b().mo2981f() + " is not a valid framework Transition or AndroidX Transition");
        }

        /* access modifiers changed from: package-private */
        /* renamed from: e */
        public C0585l0 mo2839e() {
            C0585l0 f = m2621f(this.f2571c);
            C0585l0 f2 = m2621f(this.f2573e);
            if (f == null || f2 == null || f == f2) {
                return f != null ? f : f2;
            }
            StringBuilder P = C4924a.m17863P("Mixing framework transitions and AndroidX transitions is not allowed. Fragment ");
            P.append(mo2836b().mo2981f());
            P.append(" returned Transition ");
            P.append(this.f2571c);
            P.append(" which uses a different Transition  type than its shared element transition ");
            P.append(this.f2573e);
            throw new IllegalArgumentException(P.toString());
        }

        /* renamed from: g */
        public Object mo2840g() {
            return this.f2573e;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: h */
        public Object mo2841h() {
            return this.f2571c;
        }

        /* renamed from: i */
        public boolean mo2842i() {
            return this.f2573e != null;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: j */
        public boolean mo2843j() {
            return this.f2572d;
        }
    }

    C0546b(ViewGroup viewGroup) {
        super(viewGroup);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public void mo2829f(List<C0599q0.C0603d> list, boolean z) {
        C0599q0.C0603d.C0606c cVar;
        ArrayList arrayList;
        ArrayList arrayList2;
        String str;
        HashMap hashMap;
        String str2;
        StringBuilder sb;
        C0596q.C0597a e;
        String str3;
        Iterator it;
        View view;
        Object obj;
        C0599q0.C0603d dVar;
        C0599q0.C0603d.C0606c cVar2;
        View view2;
        C0599q0.C0603d dVar2;
        String str4;
        ArrayList arrayList3;
        C4616a aVar;
        C0599q0.C0603d.C0606c cVar3;
        C0599q0.C0603d.C0606c cVar4;
        ArrayList arrayList4;
        C0585l0 l0Var;
        C0599q0.C0603d dVar3;
        HashMap hashMap2;
        ArrayList arrayList5;
        Rect rect;
        View view3;
        View view4;
        Rect rect2;
        ArrayList<String> arrayList6;
        ArrayList<String> arrayList7;
        ArrayList<String> arrayList8;
        ArrayList<String> arrayList9;
        View view5;
        View view6;
        boolean z2 = z;
        C0599q0.C0603d.C0606c cVar5 = C0599q0.C0603d.C0606c.GONE;
        C0599q0.C0603d.C0606c cVar6 = C0599q0.C0603d.C0606c.VISIBLE;
        C0599q0.C0603d dVar4 = null;
        C0599q0.C0603d dVar5 = null;
        for (C0599q0.C0603d next : list) {
            C0599q0.C0603d.C0606c f = C0599q0.C0603d.C0606c.m2793f(next.mo2981f().f2406F);
            int ordinal = next.mo2980e().ordinal();
            if (ordinal != 0) {
                if (ordinal != 1) {
                    if (!(ordinal == 2 || ordinal == 3)) {
                    }
                } else if (f != cVar6) {
                    dVar5 = next;
                }
            }
            if (f == cVar6 && dVar4 == null) {
                dVar4 = next;
            }
        }
        ArrayList arrayList10 = new ArrayList();
        ArrayList arrayList11 = new ArrayList();
        ArrayList arrayList12 = new ArrayList(list);
        Iterator<C0599q0.C0603d> it2 = list.iterator();
        while (it2.hasNext()) {
            C0599q0.C0603d next2 = it2.next();
            C4709a aVar2 = new C4709a();
            next2.mo2985j(aVar2);
            arrayList10.add(new C0548b(next2, aVar2, z2));
            C4709a aVar3 = new C4709a();
            next2.mo2985j(aVar3);
            arrayList11.add(new C0550d(next2, aVar3, z2, !z2 ? next2 == dVar5 : next2 == dVar4));
            next2.mo2977a(new C0547a(arrayList12, next2));
        }
        HashMap hashMap3 = new HashMap();
        Iterator it3 = arrayList11.iterator();
        C0585l0 l0Var2 = null;
        while (it3.hasNext()) {
            C0550d dVar6 = (C0550d) it3.next();
            if (!dVar6.mo2838d()) {
                C0585l0 e2 = dVar6.mo2839e();
                if (l0Var2 == null) {
                    l0Var2 = e2;
                } else if (!(e2 == null || l0Var2 == e2)) {
                    StringBuilder P = C4924a.m17863P("Mixing framework transitions and AndroidX transitions is not allowed. Fragment ");
                    P.append(dVar6.mo2836b().mo2981f());
                    P.append(" returned Transition ");
                    P.append(dVar6.mo2841h());
                    P.append(" which uses a different Transition  type than other Fragments.");
                    throw new IllegalArgumentException(P.toString());
                }
            }
        }
        if (l0Var2 == null) {
            Iterator it4 = arrayList11.iterator();
            while (it4.hasNext()) {
                C0550d dVar7 = (C0550d) it4.next();
                hashMap3.put(dVar7.mo2836b(), Boolean.FALSE);
                dVar7.mo2835a();
            }
            str = "FragmentManager";
            cVar = cVar5;
            arrayList = arrayList10;
            arrayList2 = arrayList12;
            hashMap = hashMap3;
        } else {
            View view7 = new View(mo2971k().getContext());
            Rect rect3 = new Rect();
            ArrayList arrayList13 = new ArrayList();
            ArrayList arrayList14 = new ArrayList();
            arrayList2 = arrayList12;
            C4616a aVar4 = new C4616a();
            Iterator it5 = arrayList11.iterator();
            Rect rect4 = rect3;
            arrayList = arrayList10;
            Object obj2 = null;
            View view8 = null;
            boolean z3 = false;
            View view9 = view7;
            String str5 = "FragmentManager";
            C0599q0.C0603d dVar8 = dVar4;
            C0599q0.C0603d dVar9 = dVar5;
            while (it5.hasNext()) {
                C0550d dVar10 = (C0550d) it5.next();
                if (!dVar10.mo2842i() || dVar8 == null || dVar9 == null) {
                    arrayList5 = arrayList14;
                    cVar3 = cVar5;
                    cVar4 = cVar6;
                    dVar3 = dVar4;
                    view4 = view8;
                    arrayList3 = arrayList11;
                    aVar = aVar4;
                    hashMap2 = hashMap3;
                    str4 = str5;
                    arrayList4 = arrayList13;
                    l0Var = l0Var2;
                    view3 = view9;
                    rect2 = rect4;
                } else {
                    Object y = l0Var2.mo2920y(l0Var2.mo2908g(dVar10.mo2840g()));
                    Fragment.C0518b bVar = dVar5.mo2981f().f2409I;
                    if (bVar == null || (arrayList6 = bVar.f2456i) == null) {
                        arrayList6 = new ArrayList<>();
                    }
                    C0585l0 l0Var3 = l0Var2;
                    Fragment.C0518b bVar2 = dVar4.mo2981f().f2409I;
                    if (bVar2 == null || (arrayList7 = bVar2.f2456i) == null) {
                        arrayList7 = new ArrayList<>();
                    }
                    view4 = view8;
                    Fragment.C0518b bVar3 = dVar4.mo2981f().f2409I;
                    if (bVar3 == null || (arrayList8 = bVar3.f2457j) == null) {
                        arrayList8 = new ArrayList<>();
                    }
                    cVar3 = cVar5;
                    cVar4 = cVar6;
                    int i = 0;
                    while (i < arrayList8.size()) {
                        int indexOf = arrayList6.indexOf(arrayList8.get(i));
                        ArrayList<String> arrayList15 = arrayList8;
                        if (indexOf != -1) {
                            arrayList6.set(indexOf, arrayList7.get(i));
                        }
                        i++;
                        arrayList8 = arrayList15;
                    }
                    Fragment.C0518b bVar4 = dVar5.mo2981f().f2409I;
                    if (bVar4 == null || (arrayList9 = bVar4.f2457j) == null) {
                        arrayList9 = new ArrayList<>();
                    }
                    ArrayList<String> arrayList16 = arrayList9;
                    Fragment f2 = dVar4.mo2981f();
                    if (!z2) {
                        f2.mo2596h3();
                        dVar5.mo2981f().mo2589e3();
                    } else {
                        f2.mo2589e3();
                        dVar5.mo2981f().mo2596h3();
                    }
                    int i2 = 0;
                    for (int size = arrayList6.size(); i2 < size; size = size) {
                        aVar4.put(arrayList6.get(i2), arrayList16.get(i2));
                        i2++;
                    }
                    C4616a aVar5 = new C4616a();
                    mo2831q(aVar5, dVar4.mo2981f().f2406F);
                    aVar5.mo21315o(arrayList6);
                    aVar4.mo21315o(aVar5.keySet());
                    C4616a aVar6 = new C4616a();
                    mo2831q(aVar6, dVar5.mo2981f().f2406F);
                    aVar6.mo21315o(arrayList16);
                    aVar6.mo21315o(aVar4.values());
                    C0569j0.m2675m(aVar4, aVar6);
                    mo2832r(aVar5, aVar4.keySet());
                    mo2832r(aVar6, aVar4.values());
                    if (aVar4.isEmpty()) {
                        arrayList13.clear();
                        arrayList14.clear();
                        obj2 = null;
                        rect2 = rect4;
                        arrayList5 = arrayList14;
                        dVar3 = dVar4;
                        arrayList3 = arrayList11;
                        aVar = aVar4;
                        hashMap2 = hashMap3;
                        str4 = str5;
                        l0Var = l0Var3;
                        arrayList4 = arrayList13;
                        view3 = view9;
                    } else {
                        C0569j0.m2665c(dVar5.mo2981f(), dVar4.mo2981f(), z2, aVar5, true);
                        arrayList5 = arrayList14;
                        aVar = aVar4;
                        arrayList4 = arrayList13;
                        arrayList3 = arrayList11;
                        Rect rect5 = rect4;
                        HashMap hashMap4 = hashMap3;
                        Object obj3 = y;
                        ArrayList<String> arrayList17 = arrayList6;
                        C0599q0.C0603d dVar11 = dVar5;
                        View view10 = view9;
                        C0562g gVar = r0;
                        str4 = str5;
                        C0599q0.C0603d dVar12 = dVar4;
                        Rect rect6 = rect5;
                        l0Var = l0Var3;
                        ViewGroup k = mo2971k();
                        C0562g gVar2 = new C0562g(this, dVar5, dVar4, z, aVar6);
                        C4759k.m17288a(k, gVar);
                        for (View p : aVar5.values()) {
                            mo2830p(arrayList4, p);
                        }
                        if (!arrayList17.isEmpty()) {
                            view5 = (View) aVar5.get(arrayList17.get(0));
                            l0Var.mo2916t(obj3, view5);
                        } else {
                            view5 = view4;
                        }
                        for (View p2 : aVar6.values()) {
                            mo2830p(arrayList5, p2);
                        }
                        if (arrayList16.isEmpty() || (view6 = (View) aVar6.get(arrayList16.get(0))) == null) {
                            rect = rect6;
                        } else {
                            rect = rect6;
                            C4759k.m17288a(mo2971k(), new C0564h(this, l0Var, view6, rect));
                            z3 = true;
                        }
                        view3 = view10;
                        l0Var.mo2918w(obj3, view3, arrayList4);
                        l0Var.mo2914r(obj3, (Object) null, (ArrayList<View>) null, (Object) null, (ArrayList<View>) null, obj3, arrayList5);
                        Boolean bool = Boolean.TRUE;
                        hashMap2 = hashMap4;
                        dVar3 = dVar12;
                        hashMap2.put(dVar3, bool);
                        dVar5 = dVar11;
                        hashMap2.put(dVar5, bool);
                        view8 = view5;
                        dVar8 = dVar3;
                        dVar9 = dVar5;
                        obj2 = obj3;
                        view9 = view3;
                        rect4 = rect;
                        arrayList14 = arrayList5;
                        hashMap3 = hashMap2;
                        l0Var2 = l0Var;
                        arrayList13 = arrayList4;
                        cVar5 = cVar3;
                        aVar4 = aVar;
                        arrayList11 = arrayList3;
                        str5 = str4;
                        z2 = z;
                        dVar4 = dVar3;
                        cVar6 = cVar4;
                    }
                }
                view8 = view4;
                view9 = view3;
                rect4 = rect;
                arrayList14 = arrayList5;
                hashMap3 = hashMap2;
                l0Var2 = l0Var;
                arrayList13 = arrayList4;
                cVar5 = cVar3;
                aVar4 = aVar;
                arrayList11 = arrayList3;
                str5 = str4;
                z2 = z;
                dVar4 = dVar3;
                cVar6 = cVar4;
            }
            ArrayList arrayList18 = arrayList14;
            C0585l0 l0Var4 = l0Var2;
            cVar = cVar5;
            C0599q0.C0603d.C0606c cVar7 = cVar6;
            View view11 = view8;
            ArrayList arrayList19 = arrayList11;
            C4616a aVar7 = aVar4;
            hashMap = hashMap3;
            String str6 = str5;
            Rect rect7 = rect4;
            ArrayList arrayList20 = arrayList13;
            View view12 = view9;
            ArrayList arrayList21 = new ArrayList();
            Iterator it6 = arrayList19.iterator();
            Object obj4 = null;
            Object obj5 = null;
            while (it6.hasNext()) {
                C0550d dVar13 = (C0550d) it6.next();
                if (dVar13.mo2838d()) {
                    dVar2 = dVar13.mo2836b();
                    it = it6;
                } else {
                    Object g = l0Var4.mo2908g(dVar13.mo2841h());
                    it = it6;
                    C0599q0.C0603d b = dVar13.mo2836b();
                    boolean z4 = obj2 != null && (b == dVar8 || b == dVar9);
                    if (g == null) {
                        if (!z4) {
                            dVar2 = b;
                        }
                        view = view12;
                        obj = obj2;
                        dVar = dVar9;
                        view2 = view11;
                        cVar2 = cVar7;
                        it6 = it;
                        view11 = view2;
                        cVar7 = cVar2;
                        dVar9 = dVar;
                        obj2 = obj;
                        view12 = view;
                    } else {
                        dVar = dVar9;
                        ArrayList arrayList22 = new ArrayList();
                        obj = obj2;
                        mo2830p(arrayList22, b.mo2981f().f2406F);
                        if (z4) {
                            if (b == dVar8) {
                                arrayList22.removeAll(arrayList20);
                            } else {
                                arrayList22.removeAll(arrayList18);
                            }
                        }
                        if (arrayList22.isEmpty()) {
                            l0Var4.mo2904a(g, view12);
                            view = view12;
                        } else {
                            l0Var4.mo2905b(g, arrayList22);
                            l0Var4.mo2914r(g, g, arrayList22, (Object) null, (ArrayList<View>) null, (Object) null, (ArrayList<View>) null);
                            view = view12;
                            C0599q0.C0603d.C0606c cVar8 = cVar;
                            if (b.mo2980e() == cVar8) {
                                l0Var4.mo2913q(g, b.mo2981f().f2406F, arrayList22);
                                cVar = cVar8;
                                C4759k.m17288a(mo2971k(), new C0566i(this, arrayList22));
                            } else {
                                cVar = cVar8;
                            }
                        }
                        cVar2 = cVar7;
                        if (b.mo2980e() == cVar2) {
                            arrayList21.addAll(arrayList22);
                            if (z3) {
                                l0Var4.mo2915s(g, rect7);
                            }
                            view2 = view11;
                        } else {
                            view2 = view11;
                            l0Var4.mo2916t(g, view2);
                        }
                        hashMap.put(b, Boolean.TRUE);
                        if (dVar13.mo2843j()) {
                            obj4 = l0Var4.mo2910m(obj4, g, (Object) null);
                        } else {
                            obj5 = l0Var4.mo2910m(obj5, g, (Object) null);
                        }
                        it6 = it;
                        view11 = view2;
                        cVar7 = cVar2;
                        dVar9 = dVar;
                        obj2 = obj;
                        view12 = view;
                    }
                }
                hashMap.put(dVar2, Boolean.FALSE);
                dVar13.mo2835a();
                view = view12;
                obj = obj2;
                dVar = dVar9;
                view2 = view11;
                cVar2 = cVar7;
                it6 = it;
                view11 = view2;
                cVar7 = cVar2;
                dVar9 = dVar;
                obj2 = obj;
                view12 = view;
            }
            C0599q0.C0603d dVar14 = dVar9;
            Object obj6 = obj2;
            Object l = l0Var4.mo2909l(obj4, obj5, obj6);
            Iterator it7 = arrayList19.iterator();
            while (it7.hasNext()) {
                C0550d dVar15 = (C0550d) it7.next();
                if (!dVar15.mo2838d()) {
                    Object h = dVar15.mo2841h();
                    C0599q0.C0603d b2 = dVar15.mo2836b();
                    C0599q0.C0603d dVar16 = dVar14;
                    boolean z5 = obj6 != null && (b2 == dVar8 || b2 == dVar16);
                    if (h != null || z5) {
                        ViewGroup k2 = mo2971k();
                        int i3 = C4761m.f17241f;
                        if (!k2.isLaidOut()) {
                            if (FragmentManager.m2484s0(2)) {
                                StringBuilder P2 = C4924a.m17863P("SpecialEffectsController: Container ");
                                P2.append(mo2971k());
                                P2.append(" has not been laid out. Completing operation ");
                                P2.append(b2);
                                str3 = str6;
                                Log.v(str3, P2.toString());
                            } else {
                                str3 = str6;
                            }
                            dVar15.mo2835a();
                        } else {
                            str3 = str6;
                            l0Var4.mo2917u(dVar15.mo2836b().mo2981f(), l, dVar15.mo2837c(), new C0568j(this, dVar15));
                        }
                    } else {
                        str3 = str6;
                    }
                    str6 = str3;
                    dVar14 = dVar16;
                }
            }
            str = str6;
            ViewGroup k3 = mo2971k();
            int i4 = C4761m.f17241f;
            if (k3.isLaidOut()) {
                C0569j0.m2677o(arrayList21, 4);
                ArrayList<String> n = l0Var4.mo2942n(arrayList18);
                l0Var4.mo2906c(mo2971k(), l);
                l0Var4.mo2943v(mo2971k(), arrayList20, arrayList18, n, aVar7);
                C0569j0.m2677o(arrayList21, 0);
                l0Var4.mo2919x(obj6, arrayList20, arrayList18);
            }
        }
        boolean containsValue = hashMap.containsValue(Boolean.TRUE);
        ViewGroup k4 = mo2971k();
        Context context = k4.getContext();
        ArrayList arrayList23 = new ArrayList();
        Iterator it8 = arrayList.iterator();
        boolean z6 = false;
        while (it8.hasNext()) {
            C0548b bVar5 = (C0548b) it8.next();
            if (!bVar5.mo2838d() && (e = bVar5.mo2834e(context)) != null) {
                Animator animator = e.f2727b;
                if (animator == null) {
                    arrayList23.add(bVar5);
                } else {
                    C0599q0.C0603d b3 = bVar5.mo2836b();
                    Fragment f3 = b3.mo2981f();
                    if (!Boolean.TRUE.equals(hashMap.get(b3))) {
                        C0599q0.C0603d.C0606c cVar9 = cVar;
                        boolean z7 = b3.mo2980e() == cVar9;
                        ArrayList arrayList24 = arrayList2;
                        if (z7) {
                            arrayList24.remove(b3);
                        }
                        View view13 = f3.f2406F;
                        k4.startViewTransition(view13);
                        C0552c cVar10 = r0;
                        View view14 = view13;
                        HashMap hashMap5 = hashMap;
                        Animator animator2 = animator;
                        C0552c cVar11 = new C0552c(this, k4, view14, z7, b3, bVar5);
                        animator2.addListener(cVar11);
                        animator2.setTarget(view14);
                        animator2.start();
                        bVar5.mo2837c().mo21777c(new C0555d(this, animator2));
                        z6 = true;
                        cVar = cVar9;
                        arrayList2 = arrayList24;
                        hashMap = hashMap5;
                    } else if (FragmentManager.m2484s0(2)) {
                        Log.v(str, "Ignoring Animator set on " + f3 + " as this Fragment was involved in a Transition.");
                    }
                }
            }
            bVar5.mo2835a();
        }
        ArrayList arrayList25 = arrayList2;
        Iterator it9 = arrayList23.iterator();
        while (it9.hasNext()) {
            C0548b bVar6 = (C0548b) it9.next();
            C0599q0.C0603d b4 = bVar6.mo2836b();
            Fragment f4 = b4.mo2981f();
            if (containsValue) {
                if (FragmentManager.m2484s0(2)) {
                    sb = new StringBuilder();
                    sb.append("Ignoring Animation set on ");
                    sb.append(f4);
                    str2 = " as Animations cannot run alongside Transitions.";
                }
                bVar6.mo2835a();
            } else if (z6) {
                if (FragmentManager.m2484s0(2)) {
                    sb = new StringBuilder();
                    sb.append("Ignoring Animation set on ");
                    sb.append(f4);
                    str2 = " as Animations cannot run alongside Animators.";
                }
                bVar6.mo2835a();
            } else {
                View view15 = f4.f2406F;
                C0596q.C0597a e3 = bVar6.mo2834e(context);
                Objects.requireNonNull(e3);
                Animation animation = e3.f2726a;
                Objects.requireNonNull(animation);
                if (b4.mo2980e() != C0599q0.C0603d.C0606c.REMOVED) {
                    view15.startAnimation(animation);
                    bVar6.mo2835a();
                } else {
                    k4.startViewTransition(view15);
                    C0596q.C0598b bVar7 = new C0596q.C0598b(animation, k4, view15);
                    bVar7.setAnimationListener(new C0557e(this, k4, view15, bVar6));
                    view15.startAnimation(bVar7);
                }
                bVar6.mo2837c().mo21777c(new C0560f(this, view15, k4, bVar6));
            }
            sb.append(str2);
            Log.v(str, sb.toString());
            bVar6.mo2835a();
        }
        Iterator it10 = arrayList25.iterator();
        while (it10.hasNext()) {
            C0599q0.C0603d dVar17 = (C0599q0.C0603d) it10.next();
            dVar17.mo2980e().mo2988a(dVar17.mo2981f().f2406F);
        }
        arrayList25.clear();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p */
    public void mo2830p(ArrayList<View> arrayList, View view) {
        ViewGroup viewGroup;
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup2 = (ViewGroup) view;
            boolean isTransitionGroup = viewGroup2.isTransitionGroup();
            viewGroup = viewGroup2;
            if (!isTransitionGroup) {
                int childCount = viewGroup2.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    View childAt = viewGroup2.getChildAt(i);
                    if (childAt.getVisibility() == 0) {
                        mo2830p(arrayList, childAt);
                    }
                }
                return;
            }
        } else {
            boolean contains = arrayList.contains(view);
            viewGroup = view;
            if (contains) {
                return;
            }
        }
        arrayList.add(viewGroup);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q */
    public void mo2831q(Map<String, View> map, View view) {
        int i = C4761m.f17241f;
        String transitionName = view.getTransitionName();
        if (transitionName != null) {
            map.put(transitionName, view);
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = viewGroup.getChildAt(i2);
                if (childAt.getVisibility() == 0) {
                    mo2831q(map, childAt);
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: r */
    public void mo2832r(C4616a<String, View> aVar, Collection<String> collection) {
        Iterator<Map.Entry<String, View>> it = aVar.entrySet().iterator();
        while (it.hasNext()) {
            int i = C4761m.f17241f;
            if (!collection.contains(((View) it.next().getValue()).getTransitionName())) {
                it.remove();
            }
        }
    }
}
