package androidx.fragment.app;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.fragment.app.b0 */
class C0551b0 {

    /* renamed from: a */
    private final ArrayList<Fragment> f2574a = new ArrayList<>();

    /* renamed from: b */
    private final HashMap<String, C0544a0> f2575b = new HashMap<>();

    /* renamed from: c */
    private C0617y f2576c;

    C0551b0() {
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo2844a(Fragment fragment) {
        if (!this.f2574a.contains(fragment)) {
            synchronized (this.f2574a) {
                this.f2574a.add(fragment);
            }
            fragment.f2430l = true;
            return;
        }
        throw new IllegalStateException("Fragment already added: " + fragment);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo2845b() {
        this.f2575b.values().removeAll(Collections.singleton((Object) null));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public boolean mo2846c(String str) {
        return this.f2575b.get(str) != null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public void mo2847d(int i) {
        for (C0544a0 next : this.f2575b.values()) {
            if (next != null) {
                next.mo2824r(i);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo2848e(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        String v = C4924a.m17907v(str, "    ");
        if (!this.f2575b.isEmpty()) {
            printWriter.print(str);
            printWriter.print("Active Fragments:");
            for (C0544a0 next : this.f2575b.values()) {
                printWriter.print(str);
                if (next != null) {
                    Fragment k = next.mo2817k();
                    printWriter.println(k);
                    k.mo2572V2(v, fileDescriptor, printWriter, strArr);
                } else {
                    printWriter.println("null");
                }
            }
        }
        int size = this.f2574a.size();
        if (size > 0) {
            printWriter.print(str);
            printWriter.println("Added Fragments:");
            for (int i = 0; i < size; i++) {
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i);
                printWriter.print(": ");
                printWriter.println(this.f2574a.get(i).toString());
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public Fragment mo2849f(String str) {
        C0544a0 a0Var = this.f2575b.get(str);
        if (a0Var != null) {
            return a0Var.mo2817k();
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public Fragment mo2850g(int i) {
        for (int size = this.f2574a.size() - 1; size >= 0; size--) {
            Fragment fragment = this.f2574a.get(size);
            if (fragment != null && fragment.f2441w == i) {
                return fragment;
            }
        }
        for (C0544a0 next : this.f2575b.values()) {
            if (next != null) {
                Fragment k = next.mo2817k();
                if (k.f2441w == i) {
                    return k;
                }
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public Fragment mo2851h(String str) {
        if (str != null) {
            for (int size = this.f2574a.size() - 1; size >= 0; size--) {
                Fragment fragment = this.f2574a.get(size);
                if (fragment != null && str.equals(fragment.f2443y)) {
                    return fragment;
                }
            }
        }
        if (str == null) {
            return null;
        }
        for (C0544a0 next : this.f2575b.values()) {
            if (next != null) {
                Fragment k = next.mo2817k();
                if (str.equals(k.f2443y)) {
                    return k;
                }
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public Fragment mo2852i(String str) {
        for (C0544a0 next : this.f2575b.values()) {
            if (next != null) {
                Fragment k = next.mo2817k();
                if (!str.equals(k.f2424f)) {
                    k = k.f2439u.mo2716Z(str);
                }
                if (k != null) {
                    return k;
                }
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j */
    public int mo2853j(Fragment fragment) {
        View view;
        View view2;
        ViewGroup viewGroup = fragment.f2405E;
        if (viewGroup == null) {
            return -1;
        }
        int indexOf = this.f2574a.indexOf(fragment);
        for (int i = indexOf - 1; i >= 0; i--) {
            Fragment fragment2 = this.f2574a.get(i);
            if (fragment2.f2405E == viewGroup && (view2 = fragment2.f2406F) != null) {
                return viewGroup.indexOfChild(view2) + 1;
            }
        }
        while (true) {
            indexOf++;
            if (indexOf >= this.f2574a.size()) {
                return -1;
            }
            Fragment fragment3 = this.f2574a.get(indexOf);
            if (fragment3.f2405E == viewGroup && (view = fragment3.f2406F) != null) {
                return viewGroup.indexOfChild(view);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k */
    public List<C0544a0> mo2854k() {
        ArrayList arrayList = new ArrayList();
        for (C0544a0 next : this.f2575b.values()) {
            if (next != null) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l */
    public List<Fragment> mo2855l() {
        ArrayList arrayList = new ArrayList();
        Iterator<C0544a0> it = this.f2575b.values().iterator();
        while (it.hasNext()) {
            C0544a0 next = it.next();
            arrayList.add(next != null ? next.mo2817k() : null);
        }
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: m */
    public C0544a0 mo2856m(String str) {
        return this.f2575b.get(str);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n */
    public List<Fragment> mo2857n() {
        ArrayList arrayList;
        if (this.f2574a.isEmpty()) {
            return Collections.emptyList();
        }
        synchronized (this.f2574a) {
            arrayList = new ArrayList(this.f2574a);
        }
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: o */
    public C0617y mo2858o() {
        return this.f2576c;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p */
    public void mo2859p(C0544a0 a0Var) {
        Fragment k = a0Var.mo2817k();
        if (!mo2846c(k.f2424f)) {
            this.f2575b.put(k.f2424f, a0Var);
            if (FragmentManager.m2484s0(2)) {
                Log.v("FragmentManager", "Added fragment to active set " + k);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q */
    public void mo2860q(C0544a0 a0Var) {
        Fragment k = a0Var.mo2817k();
        if (k.f2402B) {
            this.f2576c.mo3043k(k);
        }
        if (this.f2575b.put(k.f2424f, (Object) null) != null && FragmentManager.m2484s0(2)) {
            Log.v("FragmentManager", "Removed fragment from active set " + k);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: r */
    public void mo2861r() {
        Iterator<Fragment> it = this.f2574a.iterator();
        while (it.hasNext()) {
            C0544a0 a0Var = this.f2575b.get(it.next().f2424f);
            if (a0Var != null) {
                a0Var.mo2818l();
            }
        }
        for (C0544a0 next : this.f2575b.values()) {
            if (next != null) {
                next.mo2818l();
                Fragment k = next.mo2817k();
                if (k.f2431m && !k.mo2637z3()) {
                    mo2860q(next);
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: s */
    public void mo2862s(Fragment fragment) {
        synchronized (this.f2574a) {
            this.f2574a.remove(fragment);
        }
        fragment.f2430l = false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: t */
    public void mo2863t() {
        this.f2575b.clear();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: u */
    public void mo2864u(List<String> list) {
        this.f2574a.clear();
        if (list != null) {
            for (String next : list) {
                Fragment f = mo2849f(next);
                if (f != null) {
                    if (FragmentManager.m2484s0(2)) {
                        Log.v("FragmentManager", "restoreSaveState: added (" + next + "): " + f);
                    }
                    mo2844a(f);
                } else {
                    throw new IllegalStateException(C4924a.m17909x("No instantiated fragment for (", next, ")"));
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: v */
    public ArrayList<FragmentState> mo2865v() {
        ArrayList<FragmentState> arrayList = new ArrayList<>(this.f2575b.size());
        for (C0544a0 next : this.f2575b.values()) {
            if (next != null) {
                Fragment k = next.mo2817k();
                FragmentState p = next.mo2822p();
                arrayList.add(p);
                if (FragmentManager.m2484s0(2)) {
                    Log.v("FragmentManager", "Saved state of " + k + ": " + p.f2548m);
                }
            }
        }
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: w */
    public ArrayList<String> mo2866w() {
        synchronized (this.f2574a) {
            if (this.f2574a.isEmpty()) {
                return null;
            }
            ArrayList<String> arrayList = new ArrayList<>(this.f2574a.size());
            Iterator<Fragment> it = this.f2574a.iterator();
            while (it.hasNext()) {
                Fragment next = it.next();
                arrayList.add(next.f2424f);
                if (FragmentManager.m2484s0(2)) {
                    Log.v("FragmentManager", "saveAllState: adding fragment (" + next.f2424f + "): " + next);
                }
            }
            return arrayList;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: x */
    public void mo2867x(C0617y yVar) {
        this.f2576c = yVar;
    }
}
