package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.C0546b;
import androidx.fragment.app.C0599q0;

/* renamed from: androidx.fragment.app.c */
class C0552c extends AnimatorListenerAdapter {

    /* renamed from: a */
    final /* synthetic */ ViewGroup f2577a;

    /* renamed from: b */
    final /* synthetic */ View f2578b;

    /* renamed from: c */
    final /* synthetic */ boolean f2579c;

    /* renamed from: d */
    final /* synthetic */ C0599q0.C0603d f2580d;

    /* renamed from: e */
    final /* synthetic */ C0546b.C0548b f2581e;

    C0552c(C0546b bVar, ViewGroup viewGroup, View view, boolean z, C0599q0.C0603d dVar, C0546b.C0548b bVar2) {
        this.f2577a = viewGroup;
        this.f2578b = view;
        this.f2579c = z;
        this.f2580d = dVar;
        this.f2581e = bVar2;
    }

    public void onAnimationEnd(Animator animator) {
        this.f2577a.endViewTransition(this.f2578b);
        if (this.f2579c) {
            this.f2580d.mo2980e().mo2988a(this.f2578b);
        }
        this.f2581e.mo2835a();
    }
}
