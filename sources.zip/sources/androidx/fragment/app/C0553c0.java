package androidx.fragment.app;

import androidx.lifecycle.C0903f;
import java.util.ArrayList;

/* renamed from: androidx.fragment.app.c0 */
public abstract class C0553c0 {

    /* renamed from: a */
    ArrayList<C0554a> f2582a = new ArrayList<>();

    /* renamed from: b */
    int f2583b;

    /* renamed from: c */
    int f2584c;

    /* renamed from: d */
    int f2585d;

    /* renamed from: e */
    int f2586e;

    /* renamed from: f */
    int f2587f;

    /* renamed from: g */
    boolean f2588g;

    /* renamed from: h */
    boolean f2589h = true;

    /* renamed from: i */
    String f2590i;

    /* renamed from: j */
    int f2591j;

    /* renamed from: k */
    CharSequence f2592k;

    /* renamed from: l */
    int f2593l;

    /* renamed from: m */
    CharSequence f2594m;

    /* renamed from: n */
    ArrayList<String> f2595n;

    /* renamed from: o */
    ArrayList<String> f2596o;

    /* renamed from: p */
    boolean f2597p = false;

    /* renamed from: androidx.fragment.app.c0$a */
    static final class C0554a {

        /* renamed from: a */
        int f2598a;

        /* renamed from: b */
        Fragment f2599b;

        /* renamed from: c */
        int f2600c;

        /* renamed from: d */
        int f2601d;

        /* renamed from: e */
        int f2602e;

        /* renamed from: f */
        int f2603f;

        /* renamed from: g */
        C0903f.C0905b f2604g;

        /* renamed from: h */
        C0903f.C0905b f2605h;

        C0554a() {
        }

        C0554a(int i, Fragment fragment) {
            this.f2598a = i;
            this.f2599b = fragment;
            C0903f.C0905b bVar = C0903f.C0905b.RESUMED;
            this.f2604g = bVar;
            this.f2605h = bVar;
        }
    }

    C0553c0(C0610t tVar, ClassLoader classLoader) {
    }

    /* renamed from: b */
    public C0553c0 mo2869b(Fragment fragment, String str) {
        mo2797i(0, fragment, str, 1);
        return this;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo2870c(C0554a aVar) {
        this.f2582a.add(aVar);
        aVar.f2600c = this.f2583b;
        aVar.f2601d = this.f2584c;
        aVar.f2602e = this.f2585d;
        aVar.f2603f = this.f2586e;
    }

    /* renamed from: d */
    public C0553c0 mo2871d(String str) {
        if (this.f2589h) {
            this.f2588g = true;
            this.f2590i = str;
            return this;
        }
        throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
    }

    /* renamed from: e */
    public abstract int mo2794e();

    /* renamed from: f */
    public abstract int mo2795f();

    /* renamed from: g */
    public abstract void mo2796g();

    /* renamed from: h */
    public C0553c0 mo2872h() {
        if (!this.f2588g) {
            this.f2589h = false;
            return this;
        }
        throw new IllegalStateException("This transaction is already being added to the back stack");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public abstract void mo2797i(int i, Fragment fragment, String str, int i2);

    /* renamed from: j */
    public abstract C0553c0 mo2798j(Fragment fragment);

    /* renamed from: k */
    public C0553c0 mo2873k(int i, Fragment fragment, String str) {
        if (i != 0) {
            mo2797i(i, fragment, str, 2);
            return this;
        }
        throw new IllegalArgumentException("Must use non-zero containerViewId");
    }
}
