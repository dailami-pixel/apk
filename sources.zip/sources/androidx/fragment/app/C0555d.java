package androidx.fragment.app;

import android.animation.Animator;
import p098d.p120g.p126f.C4709a;

/* renamed from: androidx.fragment.app.d */
class C0555d implements C4709a.C4710a {

    /* renamed from: a */
    final /* synthetic */ Animator f2606a;

    C0555d(C0546b bVar, Animator animator) {
        this.f2606a = animator;
    }

    /* renamed from: a */
    public void mo2874a() {
        this.f2606a.end();
    }
}
