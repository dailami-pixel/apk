package androidx.fragment.app;

import androidx.fragment.app.C0569j0;
import androidx.fragment.app.FragmentManager;
import p098d.p120g.p126f.C4709a;

/* renamed from: androidx.fragment.app.d0 */
class C0556d0 implements Runnable {

    /* renamed from: a */
    final /* synthetic */ C0569j0.C0570a f2607a;

    /* renamed from: b */
    final /* synthetic */ Fragment f2608b;

    /* renamed from: c */
    final /* synthetic */ C4709a f2609c;

    C0556d0(C0569j0.C0570a aVar, Fragment fragment, C4709a aVar2) {
        this.f2607a = aVar;
        this.f2608b = fragment;
        this.f2609c = aVar2;
    }

    public void run() {
        ((FragmentManager.C0527d) this.f2607a).mo2764a(this.f2608b, this.f2609c);
    }
}
