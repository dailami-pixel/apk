package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.fragment.app.C0546b;

/* renamed from: androidx.fragment.app.e */
class C0557e implements Animation.AnimationListener {

    /* renamed from: a */
    final /* synthetic */ ViewGroup f2610a;

    /* renamed from: b */
    final /* synthetic */ View f2611b;

    /* renamed from: c */
    final /* synthetic */ C0546b.C0548b f2612c;

    /* renamed from: androidx.fragment.app.e$a */
    class C0558a implements Runnable {
        C0558a() {
        }

        public void run() {
            C0557e eVar = C0557e.this;
            eVar.f2610a.endViewTransition(eVar.f2611b);
            C0557e.this.f2612c.mo2835a();
        }
    }

    C0557e(C0546b bVar, ViewGroup viewGroup, View view, C0546b.C0548b bVar2) {
        this.f2610a = viewGroup;
        this.f2611b = view;
        this.f2612c = bVar2;
    }

    public void onAnimationEnd(Animation animation) {
        this.f2610a.post(new C0558a());
    }

    public void onAnimationRepeat(Animation animation) {
    }

    public void onAnimationStart(Animation animation) {
    }
}
