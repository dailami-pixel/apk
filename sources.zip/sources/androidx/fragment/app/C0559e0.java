package androidx.fragment.app;

import java.util.ArrayList;

/* renamed from: androidx.fragment.app.e0 */
class C0559e0 implements Runnable {

    /* renamed from: a */
    final /* synthetic */ ArrayList f2614a;

    C0559e0(ArrayList arrayList) {
        this.f2614a = arrayList;
    }

    public void run() {
        C0569j0.m2677o(this.f2614a, 4);
    }
}
