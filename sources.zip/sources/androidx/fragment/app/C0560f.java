package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.C0546b;
import p098d.p120g.p126f.C4709a;

/* renamed from: androidx.fragment.app.f */
class C0560f implements C4709a.C4710a {

    /* renamed from: a */
    final /* synthetic */ View f2615a;

    /* renamed from: b */
    final /* synthetic */ ViewGroup f2616b;

    /* renamed from: c */
    final /* synthetic */ C0546b.C0548b f2617c;

    C0560f(C0546b bVar, View view, ViewGroup viewGroup, C0546b.C0548b bVar2) {
        this.f2615a = view;
        this.f2616b = viewGroup;
        this.f2617c = bVar2;
    }

    /* renamed from: a */
    public void mo2874a() {
        this.f2615a.clearAnimation();
        this.f2616b.endViewTransition(this.f2615a);
        this.f2617c.mo2835a();
    }
}
