package androidx.fragment.app;

import androidx.fragment.app.C0569j0;
import androidx.fragment.app.FragmentManager;
import p098d.p120g.p126f.C4709a;

/* renamed from: androidx.fragment.app.f0 */
class C0561f0 implements Runnable {

    /* renamed from: a */
    final /* synthetic */ C0569j0.C0570a f2618a;

    /* renamed from: b */
    final /* synthetic */ Fragment f2619b;

    /* renamed from: c */
    final /* synthetic */ C4709a f2620c;

    C0561f0(C0569j0.C0570a aVar, Fragment fragment, C4709a aVar2) {
        this.f2618a = aVar;
        this.f2619b = fragment;
        this.f2620c = aVar2;
    }

    public void run() {
        ((FragmentManager.C0527d) this.f2618a).mo2764a(this.f2619b, this.f2620c);
    }
}
