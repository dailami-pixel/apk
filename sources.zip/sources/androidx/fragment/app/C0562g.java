package androidx.fragment.app;

import androidx.fragment.app.C0599q0;
import p098d.p112d.C4616a;

/* renamed from: androidx.fragment.app.g */
class C0562g implements Runnable {

    /* renamed from: a */
    final /* synthetic */ C0599q0.C0603d f2621a;

    /* renamed from: b */
    final /* synthetic */ C0599q0.C0603d f2622b;

    /* renamed from: c */
    final /* synthetic */ boolean f2623c;

    /* renamed from: d */
    final /* synthetic */ C4616a f2624d;

    C0562g(C0546b bVar, C0599q0.C0603d dVar, C0599q0.C0603d dVar2, boolean z, C4616a aVar) {
        this.f2621a = dVar;
        this.f2622b = dVar2;
        this.f2623c = z;
        this.f2624d = aVar;
    }

    public void run() {
        C0569j0.m2665c(this.f2621a.mo2981f(), this.f2622b.mo2981f(), this.f2623c, this.f2624d, false);
    }
}
