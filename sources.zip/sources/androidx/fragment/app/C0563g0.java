package androidx.fragment.app;

import android.view.View;
import java.util.ArrayList;

/* renamed from: androidx.fragment.app.g0 */
class C0563g0 implements Runnable {

    /* renamed from: a */
    final /* synthetic */ Object f2625a;

    /* renamed from: b */
    final /* synthetic */ C0585l0 f2626b;

    /* renamed from: c */
    final /* synthetic */ View f2627c;

    /* renamed from: d */
    final /* synthetic */ Fragment f2628d;

    /* renamed from: e */
    final /* synthetic */ ArrayList f2629e;

    /* renamed from: f */
    final /* synthetic */ ArrayList f2630f;

    /* renamed from: g */
    final /* synthetic */ ArrayList f2631g;

    /* renamed from: h */
    final /* synthetic */ Object f2632h;

    C0563g0(Object obj, C0585l0 l0Var, View view, Fragment fragment, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, Object obj2) {
        this.f2625a = obj;
        this.f2626b = l0Var;
        this.f2627c = view;
        this.f2628d = fragment;
        this.f2629e = arrayList;
        this.f2630f = arrayList2;
        this.f2631g = arrayList3;
        this.f2632h = obj2;
    }

    public void run() {
        Object obj = this.f2625a;
        if (obj != null) {
            this.f2626b.mo2911o(obj, this.f2627c);
            this.f2630f.addAll(C0569j0.m2670h(this.f2626b, this.f2625a, this.f2628d, this.f2629e, this.f2627c));
        }
        if (this.f2631g != null) {
            if (this.f2632h != null) {
                ArrayList arrayList = new ArrayList();
                arrayList.add(this.f2627c);
                this.f2626b.mo2912p(this.f2632h, this.f2631g, arrayList);
            }
            this.f2631g.clear();
            this.f2631g.add(this.f2627c);
        }
    }
}
