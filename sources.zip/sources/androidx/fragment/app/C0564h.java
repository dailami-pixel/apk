package androidx.fragment.app;

import android.graphics.Rect;
import android.view.View;

/* renamed from: androidx.fragment.app.h */
class C0564h implements Runnable {

    /* renamed from: a */
    final /* synthetic */ C0585l0 f2633a;

    /* renamed from: b */
    final /* synthetic */ View f2634b;

    /* renamed from: c */
    final /* synthetic */ Rect f2635c;

    C0564h(C0546b bVar, C0585l0 l0Var, View view, Rect rect) {
        this.f2633a = l0Var;
        this.f2634b = view;
        this.f2635c = rect;
    }

    public void run() {
        this.f2633a.mo2941j(this.f2634b, this.f2635c);
    }
}
