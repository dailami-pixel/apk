package androidx.fragment.app;

import android.graphics.Rect;
import android.view.View;
import p098d.p112d.C4616a;

/* renamed from: androidx.fragment.app.h0 */
class C0565h0 implements Runnable {

    /* renamed from: a */
    final /* synthetic */ Fragment f2636a;

    /* renamed from: b */
    final /* synthetic */ Fragment f2637b;

    /* renamed from: c */
    final /* synthetic */ boolean f2638c;

    /* renamed from: d */
    final /* synthetic */ C4616a f2639d;

    /* renamed from: e */
    final /* synthetic */ View f2640e;

    /* renamed from: f */
    final /* synthetic */ C0585l0 f2641f;

    /* renamed from: g */
    final /* synthetic */ Rect f2642g;

    C0565h0(Fragment fragment, Fragment fragment2, boolean z, C4616a aVar, View view, C0585l0 l0Var, Rect rect) {
        this.f2636a = fragment;
        this.f2637b = fragment2;
        this.f2638c = z;
        this.f2639d = aVar;
        this.f2640e = view;
        this.f2641f = l0Var;
        this.f2642g = rect;
    }

    public void run() {
        C0569j0.m2665c(this.f2636a, this.f2637b, this.f2638c, this.f2639d, false);
        View view = this.f2640e;
        if (view != null) {
            this.f2641f.mo2941j(view, this.f2642g);
        }
    }
}
