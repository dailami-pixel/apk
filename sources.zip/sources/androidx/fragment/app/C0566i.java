package androidx.fragment.app;

import java.util.ArrayList;

/* renamed from: androidx.fragment.app.i */
class C0566i implements Runnable {

    /* renamed from: a */
    final /* synthetic */ ArrayList f2643a;

    C0566i(C0546b bVar, ArrayList arrayList) {
        this.f2643a = arrayList;
    }

    public void run() {
        C0569j0.m2677o(this.f2643a, 4);
    }
}
