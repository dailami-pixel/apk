package androidx.fragment.app;

import android.graphics.Rect;
import android.view.View;
import androidx.fragment.app.C0569j0;
import java.util.ArrayList;
import p098d.p112d.C4616a;

/* renamed from: androidx.fragment.app.i0 */
class C0567i0 implements Runnable {

    /* renamed from: a */
    final /* synthetic */ C0585l0 f2644a;

    /* renamed from: b */
    final /* synthetic */ C4616a f2645b;

    /* renamed from: c */
    final /* synthetic */ Object f2646c;

    /* renamed from: d */
    final /* synthetic */ C0569j0.C0571b f2647d;

    /* renamed from: e */
    final /* synthetic */ ArrayList f2648e;

    /* renamed from: f */
    final /* synthetic */ View f2649f;

    /* renamed from: g */
    final /* synthetic */ Fragment f2650g;

    /* renamed from: h */
    final /* synthetic */ Fragment f2651h;

    /* renamed from: i */
    final /* synthetic */ boolean f2652i;

    /* renamed from: j */
    final /* synthetic */ ArrayList f2653j;

    /* renamed from: k */
    final /* synthetic */ Object f2654k;

    /* renamed from: l */
    final /* synthetic */ Rect f2655l;

    C0567i0(C0585l0 l0Var, C4616a aVar, Object obj, C0569j0.C0571b bVar, ArrayList arrayList, View view, Fragment fragment, Fragment fragment2, boolean z, ArrayList arrayList2, Object obj2, Rect rect) {
        this.f2644a = l0Var;
        this.f2645b = aVar;
        this.f2646c = obj;
        this.f2647d = bVar;
        this.f2648e = arrayList;
        this.f2649f = view;
        this.f2650g = fragment;
        this.f2651h = fragment2;
        this.f2652i = z;
        this.f2653j = arrayList2;
        this.f2654k = obj2;
        this.f2655l = rect;
    }

    public void run() {
        C4616a<String, View> e = C0569j0.m2667e(this.f2644a, this.f2645b, this.f2646c, this.f2647d);
        if (e != null) {
            this.f2648e.addAll(e.values());
            this.f2648e.add(this.f2649f);
        }
        C0569j0.m2665c(this.f2650g, this.f2651h, this.f2652i, e, false);
        Object obj = this.f2646c;
        if (obj != null) {
            this.f2644a.mo2919x(obj, this.f2653j, this.f2648e);
            View k = C0569j0.m2673k(e, this.f2647d, this.f2654k, this.f2652i);
            if (k != null) {
                this.f2644a.mo2941j(k, this.f2655l);
            }
        }
    }
}
