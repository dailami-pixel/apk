package androidx.fragment.app;

import androidx.fragment.app.C0546b;

/* renamed from: androidx.fragment.app.j */
class C0568j implements Runnable {

    /* renamed from: a */
    final /* synthetic */ C0546b.C0550d f2656a;

    C0568j(C0546b bVar, C0546b.C0550d dVar) {
        this.f2656a = dVar;
    }

    public void run() {
        this.f2656a.mo2835a();
    }
}
