package androidx.fragment.app;

import android.view.View;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import p098d.p112d.C4616a;
import p098d.p120g.p130j.C4761m;

/* renamed from: androidx.fragment.app.j0 */
class C0569j0 {

    /* renamed from: a */
    private static final int[] f2657a = {0, 3, 0, 1, 5, 4, 7, 6, 9, 8, 10};

    /* renamed from: b */
    static final C0585l0 f2658b = new C0578k0();

    /* renamed from: c */
    static final C0585l0 f2659c;

    /* renamed from: androidx.fragment.app.j0$a */
    interface C0570a {
    }

    /* renamed from: androidx.fragment.app.j0$b */
    static class C0571b {

        /* renamed from: a */
        public Fragment f2660a;

        /* renamed from: b */
        public boolean f2661b;

        /* renamed from: c */
        public C0543a f2662c;

        /* renamed from: d */
        public Fragment f2663d;

        /* renamed from: e */
        public boolean f2664e;

        /* renamed from: f */
        public C0543a f2665f;

        C0571b() {
        }
    }

    static {
        C0585l0 l0Var;
        try {
            l0Var = (C0585l0) Class.forName("androidx.transition.e").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception unused) {
            l0Var = null;
        }
        f2659c = l0Var;
    }

    /* renamed from: a */
    private static void m2663a(ArrayList<View> arrayList, C4616a<String, View> aVar, Collection<String> collection) {
        for (int size = aVar.size() - 1; size >= 0; size--) {
            View m = aVar.mo21459m(size);
            int i = C4761m.f17241f;
            if (collection.contains(m.getTransitionName())) {
                arrayList.add(m);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0038, code lost:
        if (r0.f2430l != false) goto L_0x0086;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x0074, code lost:
        r9 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x0084, code lost:
        if (r0.f2444z != false) goto L_0x007c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:62:0x0086, code lost:
        r9 = true;
     */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x0093  */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x00b5  */
    /* JADX WARNING: Removed duplicated region for block: B:84:0x00d1  */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x00e2 A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:93:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void m2664b(androidx.fragment.app.C0543a r8, androidx.fragment.app.C0553c0.C0554a r9, android.util.SparseArray<androidx.fragment.app.C0569j0.C0571b> r10, boolean r11, boolean r12) {
        /*
            androidx.fragment.app.Fragment r0 = r9.f2599b
            if (r0 != 0) goto L_0x0005
            return
        L_0x0005:
            int r1 = r0.f2442x
            if (r1 != 0) goto L_0x000a
            return
        L_0x000a:
            if (r11 == 0) goto L_0x0013
            int[] r2 = f2657a
            int r9 = r9.f2598a
            r9 = r2[r9]
            goto L_0x0015
        L_0x0013:
            int r9 = r9.f2598a
        L_0x0015:
            r2 = 1
            r3 = 0
            if (r9 == r2) goto L_0x007a
            r4 = 3
            if (r9 == r4) goto L_0x0056
            r4 = 4
            if (r9 == r4) goto L_0x003e
            r4 = 5
            if (r9 == r4) goto L_0x002c
            r4 = 6
            if (r9 == r4) goto L_0x0056
            r4 = 7
            if (r9 == r4) goto L_0x007a
            r9 = 0
            r2 = 0
            goto L_0x0087
        L_0x002c:
            if (r12 == 0) goto L_0x003b
            boolean r9 = r0.f2410J
            if (r9 == 0) goto L_0x007c
            boolean r9 = r0.f2444z
            if (r9 != 0) goto L_0x007c
            boolean r9 = r0.f2430l
            if (r9 == 0) goto L_0x007c
            goto L_0x0086
        L_0x003b:
            boolean r9 = r0.f2444z
            goto L_0x0087
        L_0x003e:
            if (r12 == 0) goto L_0x004d
            boolean r9 = r0.f2410J
            if (r9 == 0) goto L_0x0076
            boolean r9 = r0.f2430l
            if (r9 == 0) goto L_0x0076
            boolean r9 = r0.f2444z
            if (r9 == 0) goto L_0x0076
            goto L_0x0074
        L_0x004d:
            boolean r9 = r0.f2430l
            if (r9 == 0) goto L_0x0076
            boolean r9 = r0.f2444z
            if (r9 != 0) goto L_0x0076
            goto L_0x0074
        L_0x0056:
            boolean r9 = r0.f2430l
            if (r12 == 0) goto L_0x006e
            if (r9 != 0) goto L_0x0076
            android.view.View r9 = r0.f2406F
            if (r9 == 0) goto L_0x0076
            int r9 = r9.getVisibility()
            if (r9 != 0) goto L_0x0076
            float r9 = r0.f2411K
            r4 = 0
            int r9 = (r9 > r4 ? 1 : (r9 == r4 ? 0 : -1))
            if (r9 < 0) goto L_0x0076
            goto L_0x0074
        L_0x006e:
            if (r9 == 0) goto L_0x0076
            boolean r9 = r0.f2444z
            if (r9 != 0) goto L_0x0076
        L_0x0074:
            r9 = 1
            goto L_0x0077
        L_0x0076:
            r9 = 0
        L_0x0077:
            r4 = r9
            r9 = 0
            goto L_0x008b
        L_0x007a:
            if (r12 == 0) goto L_0x007e
        L_0x007c:
            r9 = 0
            goto L_0x0087
        L_0x007e:
            boolean r9 = r0.f2430l
            if (r9 != 0) goto L_0x007c
            boolean r9 = r0.f2444z
            if (r9 != 0) goto L_0x007c
        L_0x0086:
            r9 = 1
        L_0x0087:
            r3 = r9
            r9 = r2
            r2 = 0
            r4 = 0
        L_0x008b:
            java.lang.Object r5 = r10.get(r1)
            androidx.fragment.app.j0$b r5 = (androidx.fragment.app.C0569j0.C0571b) r5
            if (r3 == 0) goto L_0x00a4
            if (r5 != 0) goto L_0x009e
            androidx.fragment.app.j0$b r3 = new androidx.fragment.app.j0$b
            r3.<init>()
            r10.put(r1, r3)
            r5 = r3
        L_0x009e:
            r5.f2660a = r0
            r5.f2661b = r11
            r5.f2662c = r8
        L_0x00a4:
            r3 = 0
            if (r12 != 0) goto L_0x00c7
            if (r9 == 0) goto L_0x00c7
            if (r5 == 0) goto L_0x00b1
            androidx.fragment.app.Fragment r9 = r5.f2663d
            if (r9 != r0) goto L_0x00b1
            r5.f2663d = r3
        L_0x00b1:
            boolean r9 = r8.f2597p
            if (r9 != 0) goto L_0x00c7
            androidx.fragment.app.FragmentManager r9 = r8.f2554q
            androidx.fragment.app.a0 r6 = r9.mo2736n(r0)
            androidx.fragment.app.b0 r7 = r9.mo2726g0()
            r7.mo2859p(r6)
            int r6 = r9.f2502q
            r9.mo2759z0(r0, r6)
        L_0x00c7:
            if (r4 == 0) goto L_0x00e0
            if (r5 == 0) goto L_0x00cf
            androidx.fragment.app.Fragment r9 = r5.f2663d
            if (r9 != 0) goto L_0x00e0
        L_0x00cf:
            if (r5 != 0) goto L_0x00da
            androidx.fragment.app.j0$b r9 = new androidx.fragment.app.j0$b
            r9.<init>()
            r10.put(r1, r9)
            r5 = r9
        L_0x00da:
            r5.f2663d = r0
            r5.f2664e = r11
            r5.f2665f = r8
        L_0x00e0:
            if (r12 != 0) goto L_0x00ec
            if (r2 == 0) goto L_0x00ec
            if (r5 == 0) goto L_0x00ec
            androidx.fragment.app.Fragment r8 = r5.f2660a
            if (r8 != r0) goto L_0x00ec
            r5.f2660a = r3
        L_0x00ec:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.C0569j0.m2664b(androidx.fragment.app.a, androidx.fragment.app.c0$a, android.util.SparseArray, boolean, boolean):void");
    }

    /* renamed from: c */
    static void m2665c(Fragment fragment, Fragment fragment2, boolean z, C4616a<String, View> aVar, boolean z2) {
        if (z) {
            fragment2.mo2589e3();
        } else {
            fragment.mo2589e3();
        }
    }

    /* renamed from: d */
    private static boolean m2666d(C0585l0 l0Var, List<Object> list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            if (!l0Var.mo2907e(list.get(i))) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: e */
    static C4616a<String, View> m2667e(C0585l0 l0Var, C4616a<String, String> aVar, Object obj, C0571b bVar) {
        ArrayList<String> arrayList;
        Fragment fragment = bVar.f2660a;
        View view = fragment.f2406F;
        if (aVar.isEmpty() || obj == null || view == null) {
            aVar.clear();
            return null;
        }
        C4616a<String, View> aVar2 = new C4616a<>();
        l0Var.mo2940i(aVar2, view);
        C0543a aVar3 = bVar.f2662c;
        if (bVar.f2661b) {
            fragment.mo2596h3();
            arrayList = aVar3.f2595n;
        } else {
            fragment.mo2589e3();
            arrayList = aVar3.f2596o;
        }
        if (arrayList != null) {
            aVar2.mo21315o(arrayList);
            aVar2.mo21315o(aVar.values());
        }
        m2675m(aVar, aVar2);
        return aVar2;
    }

    /* renamed from: f */
    private static C4616a<String, View> m2668f(C0585l0 l0Var, C4616a<String, String> aVar, Object obj, C0571b bVar) {
        ArrayList<String> arrayList;
        if (aVar.isEmpty() || obj == null) {
            aVar.clear();
            return null;
        }
        Fragment fragment = bVar.f2663d;
        C4616a<String, View> aVar2 = new C4616a<>();
        l0Var.mo2940i(aVar2, fragment.mo2638z4());
        C0543a aVar3 = bVar.f2665f;
        if (bVar.f2664e) {
            fragment.mo2589e3();
            arrayList = aVar3.f2596o;
        } else {
            fragment.mo2596h3();
            arrayList = aVar3.f2595n;
        }
        if (arrayList != null) {
            aVar2.mo21315o(arrayList);
        }
        aVar.mo21315o(aVar2.keySet());
        return aVar2;
    }

    /* renamed from: g */
    private static C0585l0 m2669g(Fragment fragment, Fragment fragment2) {
        ArrayList arrayList = new ArrayList();
        if (fragment != null) {
            fragment.mo2594g3();
            Object s3 = fragment.mo2621s3();
            if (s3 != null) {
                arrayList.add(s3);
            }
            Object u3 = fragment.mo2627u3();
            if (u3 != null) {
                arrayList.add(u3);
            }
        }
        if (fragment2 != null) {
            fragment2.mo2587d3();
            Object q3 = fragment2.mo2617q3();
            if (q3 != null) {
                arrayList.add(q3);
            }
            fragment2.mo2624t3();
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        C0585l0 l0Var = f2658b;
        if (m2666d(l0Var, arrayList)) {
            return l0Var;
        }
        C0585l0 l0Var2 = f2659c;
        if (l0Var2 != null && m2666d(l0Var2, arrayList)) {
            return l0Var2;
        }
        throw new IllegalArgumentException("Invalid Transition types");
    }

    /* renamed from: h */
    static ArrayList<View> m2670h(C0585l0 l0Var, Object obj, Fragment fragment, ArrayList<View> arrayList, View view) {
        if (obj == null) {
            return null;
        }
        ArrayList<View> arrayList2 = new ArrayList<>();
        View view2 = fragment.f2406F;
        if (view2 != null) {
            l0Var.mo2939f(arrayList2, view2);
        }
        if (arrayList != null) {
            arrayList2.removeAll(arrayList);
        }
        if (arrayList2.isEmpty()) {
            return arrayList2;
        }
        arrayList2.add(view);
        l0Var.mo2905b(obj, arrayList2);
        return arrayList2;
    }

    /* renamed from: i */
    private static Object m2671i(C0585l0 l0Var, Fragment fragment, boolean z) {
        Object obj = null;
        if (fragment == null) {
            return null;
        }
        if (z) {
            obj = fragment.mo2617q3();
        } else {
            fragment.mo2587d3();
        }
        return l0Var.mo2908g(obj);
    }

    /* renamed from: j */
    private static Object m2672j(C0585l0 l0Var, Fragment fragment, boolean z) {
        Object obj = null;
        if (fragment == null) {
            return null;
        }
        if (z) {
            obj = fragment.mo2621s3();
        } else {
            fragment.mo2594g3();
        }
        return l0Var.mo2908g(obj);
    }

    /* renamed from: k */
    static View m2673k(C4616a<String, View> aVar, C0571b bVar, Object obj, boolean z) {
        ArrayList<String> arrayList;
        C0543a aVar2 = bVar.f2662c;
        if (obj == null || aVar == null || (arrayList = aVar2.f2595n) == null || arrayList.isEmpty()) {
            return null;
        }
        return aVar.get((z ? aVar2.f2595n : aVar2.f2596o).get(0));
    }

    /* renamed from: l */
    private static Object m2674l(C0585l0 l0Var, Fragment fragment, Fragment fragment2, boolean z) {
        Object obj;
        if (z) {
            obj = fragment2.mo2627u3();
        } else {
            fragment.mo2624t3();
            obj = null;
        }
        return l0Var.mo2920y(l0Var.mo2908g(obj));
    }

    /* renamed from: m */
    static void m2675m(C4616a<String, String> aVar, C4616a<String, View> aVar2) {
        int size = aVar.size();
        while (true) {
            size--;
            if (size < 0) {
                return;
            }
            if (!aVar2.containsKey(aVar.mo21459m(size))) {
                aVar.mo7295k(size);
            }
        }
    }

    /* renamed from: n */
    private static void m2676n(C0585l0 l0Var, Object obj, Object obj2, C4616a<String, View> aVar, boolean z, C0543a aVar2) {
        ArrayList<String> arrayList = aVar2.f2595n;
        if (arrayList != null && !arrayList.isEmpty()) {
            View view = aVar.get((z ? aVar2.f2596o : aVar2.f2595n).get(0));
            l0Var.mo2916t(obj, view);
            if (obj2 != null) {
                l0Var.mo2916t(obj2, view);
            }
        }
    }

    /* renamed from: o */
    static void m2677o(ArrayList<View> arrayList, int i) {
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                arrayList.get(size).setVisibility(i);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:135:0x0392  */
    /* JADX WARNING: Removed duplicated region for block: B:136:0x0394  */
    /* JADX WARNING: Removed duplicated region for block: B:146:0x03c3  */
    /* JADX WARNING: Removed duplicated region for block: B:156:0x0404 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x0235 A[ADDED_TO_REGION] */
    /* renamed from: p */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void m2678p(android.content.Context r37, androidx.fragment.app.C0607r r38, java.util.ArrayList<androidx.fragment.app.C0543a> r39, java.util.ArrayList<java.lang.Boolean> r40, int r41, int r42, boolean r43, androidx.fragment.app.C0569j0.C0570a r44) {
        /*
            r0 = r39
            r1 = r40
            r2 = r42
            r3 = r43
            r4 = r44
            android.util.SparseArray r5 = new android.util.SparseArray
            r5.<init>()
            r6 = r41
        L_0x0011:
            r7 = 0
            r8 = 1
            if (r6 >= r2) goto L_0x0065
            java.lang.Object r9 = r0.get(r6)
            androidx.fragment.app.a r9 = (androidx.fragment.app.C0543a) r9
            java.lang.Object r10 = r1.get(r6)
            java.lang.Boolean r10 = (java.lang.Boolean) r10
            boolean r10 = r10.booleanValue()
            if (r10 == 0) goto L_0x004b
            androidx.fragment.app.FragmentManager r7 = r9.f2554q
            androidx.fragment.app.r r7 = r7.mo2721d0()
            boolean r7 = r7.mo2645c()
            if (r7 != 0) goto L_0x0034
            goto L_0x0062
        L_0x0034:
            java.util.ArrayList<androidx.fragment.app.c0$a> r7 = r9.f2582a
            int r7 = r7.size()
            int r7 = r7 - r8
        L_0x003b:
            if (r7 < 0) goto L_0x0062
            java.util.ArrayList<androidx.fragment.app.c0$a> r10 = r9.f2582a
            java.lang.Object r10 = r10.get(r7)
            androidx.fragment.app.c0$a r10 = (androidx.fragment.app.C0553c0.C0554a) r10
            m2664b(r9, r10, r5, r8, r3)
            int r7 = r7 + -1
            goto L_0x003b
        L_0x004b:
            java.util.ArrayList<androidx.fragment.app.c0$a> r8 = r9.f2582a
            int r8 = r8.size()
            r10 = 0
        L_0x0052:
            if (r10 >= r8) goto L_0x0062
            java.util.ArrayList<androidx.fragment.app.c0$a> r11 = r9.f2582a
            java.lang.Object r11 = r11.get(r10)
            androidx.fragment.app.c0$a r11 = (androidx.fragment.app.C0553c0.C0554a) r11
            m2664b(r9, r11, r5, r7, r3)
            int r10 = r10 + 1
            goto L_0x0052
        L_0x0062:
            int r6 = r6 + 1
            goto L_0x0011
        L_0x0065:
            int r6 = r5.size()
            if (r6 == 0) goto L_0x0418
            android.view.View r6 = new android.view.View
            r9 = r37
            r6.<init>(r9)
            int r15 = r5.size()
            r14 = 0
        L_0x0077:
            if (r14 >= r15) goto L_0x0418
            int r9 = r5.keyAt(r14)
            d.d.a r13 = new d.d.a
            r13.<init>()
            int r10 = r2 + -1
            r12 = r41
        L_0x0086:
            if (r10 < r12) goto L_0x00ed
            java.lang.Object r11 = r0.get(r10)
            androidx.fragment.app.a r11 = (androidx.fragment.app.C0543a) r11
            boolean r16 = r11.mo2804q(r9)
            if (r16 != 0) goto L_0x0095
            goto L_0x00e2
        L_0x0095:
            java.lang.Object r16 = r1.get(r10)
            java.lang.Boolean r16 = (java.lang.Boolean) r16
            boolean r16 = r16.booleanValue()
            java.util.ArrayList<java.lang.String> r8 = r11.f2595n
            if (r8 == 0) goto L_0x00e2
            int r8 = r8.size()
            java.util.ArrayList<java.lang.String> r7 = r11.f2595n
            java.util.ArrayList<java.lang.String> r11 = r11.f2596o
            if (r16 == 0) goto L_0x00ae
            goto L_0x00b3
        L_0x00ae:
            r36 = r11
            r11 = r7
            r7 = r36
        L_0x00b3:
            r0 = 0
        L_0x00b4:
            if (r0 >= r8) goto L_0x00e2
            java.lang.Object r16 = r11.get(r0)
            r1 = r16
            java.lang.String r1 = (java.lang.String) r1
            java.lang.Object r16 = r7.get(r0)
            r2 = r16
            java.lang.String r2 = (java.lang.String) r2
            java.lang.Object r16 = r13.remove(r2)
            r17 = r7
            r7 = r16
            java.lang.String r7 = (java.lang.String) r7
            if (r7 == 0) goto L_0x00d6
            r13.put(r1, r7)
            goto L_0x00d9
        L_0x00d6:
            r13.put(r1, r2)
        L_0x00d9:
            int r0 = r0 + 1
            r1 = r40
            r2 = r42
            r7 = r17
            goto L_0x00b4
        L_0x00e2:
            int r10 = r10 + -1
            r0 = r39
            r1 = r40
            r2 = r42
            r7 = 0
            r8 = 1
            goto L_0x0086
        L_0x00ed:
            java.lang.Object r0 = r5.valueAt(r14)
            androidx.fragment.app.j0$b r0 = (androidx.fragment.app.C0569j0.C0571b) r0
            boolean r1 = r38.mo2645c()
            if (r1 == 0) goto L_0x03fe
            r1 = r38
            android.view.View r2 = r1.mo2644b(r9)
            android.view.ViewGroup r2 = (android.view.ViewGroup) r2
            if (r2 != 0) goto L_0x0105
            goto L_0x03fe
        L_0x0105:
            if (r3 == 0) goto L_0x0289
            androidx.fragment.app.Fragment r8 = r0.f2660a
            androidx.fragment.app.Fragment r9 = r0.f2663d
            androidx.fragment.app.l0 r10 = m2669g(r9, r8)
            if (r10 != 0) goto L_0x011b
            r30 = r5
            r31 = r14
            r32 = r15
            r5 = 0
            r14 = r4
            goto L_0x029d
        L_0x011b:
            boolean r11 = r0.f2661b
            boolean r7 = r0.f2664e
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            java.lang.Object r11 = m2671i(r10, r8, r11)
            java.lang.Object r7 = m2672j(r10, r9, r7)
            r30 = r5
            androidx.fragment.app.Fragment r5 = r0.f2660a
            androidx.fragment.app.Fragment r12 = r0.f2663d
            r31 = r14
            if (r5 == 0) goto L_0x0146
            android.view.View r14 = r5.mo2638z4()
            r32 = r15
            r15 = 0
            r14.setVisibility(r15)
            goto L_0x0148
        L_0x0146:
            r32 = r15
        L_0x0148:
            if (r5 == 0) goto L_0x01e4
            if (r12 != 0) goto L_0x014e
            goto L_0x01e4
        L_0x014e:
            boolean r14 = r0.f2661b
            boolean r15 = r13.isEmpty()
            if (r15 == 0) goto L_0x0158
            r15 = 0
            goto L_0x015c
        L_0x0158:
            java.lang.Object r15 = m2674l(r10, r5, r12, r14)
        L_0x015c:
            d.d.a r4 = m2668f(r10, r13, r15, r0)
            r33 = r8
            d.d.a r8 = m2667e(r10, r13, r15, r0)
            boolean r16 = r13.isEmpty()
            if (r16 == 0) goto L_0x0178
            if (r4 == 0) goto L_0x0171
            r4.clear()
        L_0x0171:
            if (r8 == 0) goto L_0x0176
            r8.clear()
        L_0x0176:
            r15 = 0
            goto L_0x018a
        L_0x0178:
            r16 = r15
            java.util.Set r15 = r13.keySet()
            m2663a(r3, r4, r15)
            java.util.Collection r15 = r13.values()
            m2663a(r1, r8, r15)
            r15 = r16
        L_0x018a:
            if (r11 != 0) goto L_0x0193
            if (r7 != 0) goto L_0x0193
            if (r15 != 0) goto L_0x0193
            r35 = r1
            goto L_0x01e8
        L_0x0193:
            r34 = r13
            r13 = 1
            m2665c(r5, r12, r14, r4, r13)
            if (r15 == 0) goto L_0x01c9
            r1.add(r6)
            r10.mo2918w(r15, r6, r3)
            boolean r13 = r0.f2664e
            r35 = r1
            androidx.fragment.app.a r1 = r0.f2665f
            r16 = r10
            r17 = r15
            r18 = r7
            r19 = r4
            r20 = r13
            r21 = r1
            m2676n(r16, r17, r18, r19, r20, r21)
            android.graphics.Rect r1 = new android.graphics.Rect
            r1.<init>()
            android.view.View r0 = m2673k(r8, r0, r11, r14)
            if (r0 == 0) goto L_0x01c4
            r10.mo2915s(r11, r1)
        L_0x01c4:
            r27 = r0
            r29 = r1
            goto L_0x01cf
        L_0x01c9:
            r35 = r1
            r27 = 0
            r29 = 0
        L_0x01cf:
            androidx.fragment.app.h0 r0 = new androidx.fragment.app.h0
            r22 = r0
            r23 = r5
            r24 = r12
            r25 = r14
            r26 = r8
            r28 = r10
            r22.<init>(r23, r24, r25, r26, r27, r28, r29)
            p098d.p120g.p130j.C4759k.m17288a(r2, r0)
            goto L_0x01eb
        L_0x01e4:
            r35 = r1
            r33 = r8
        L_0x01e8:
            r34 = r13
            r15 = 0
        L_0x01eb:
            if (r11 != 0) goto L_0x01f5
            if (r15 != 0) goto L_0x01f5
            if (r7 != 0) goto L_0x01f5
            r14 = r44
            goto L_0x0287
        L_0x01f5:
            java.util.ArrayList r0 = m2670h(r10, r7, r9, r3, r6)
            r1 = r33
            r4 = r35
            java.util.ArrayList r1 = m2670h(r10, r11, r1, r4, r6)
            r5 = 4
            m2677o(r1, r5)
            java.lang.Object r5 = r10.mo2910m(r7, r11, r15)
            if (r9 == 0) goto L_0x0231
            if (r0 == 0) goto L_0x0231
            int r8 = r0.size()
            if (r8 > 0) goto L_0x0219
            int r8 = r3.size()
            if (r8 <= 0) goto L_0x0231
        L_0x0219:
            d.g.f.a r8 = new d.g.f.a
            r8.<init>()
            r14 = r44
            r12 = r14
            androidx.fragment.app.FragmentManager$d r12 = (androidx.fragment.app.FragmentManager.C0527d) r12
            androidx.fragment.app.FragmentManager r12 = androidx.fragment.app.FragmentManager.this
            r12.mo2718c(r9, r8)
            androidx.fragment.app.d0 r12 = new androidx.fragment.app.d0
            r12.<init>(r14, r9, r8)
            r10.mo2917u(r9, r5, r8, r12)
            goto L_0x0233
        L_0x0231:
            r14 = r44
        L_0x0233:
            if (r5 == 0) goto L_0x0287
            if (r9 == 0) goto L_0x0258
            if (r7 == 0) goto L_0x0258
            boolean r8 = r9.f2430l
            if (r8 == 0) goto L_0x0258
            boolean r8 = r9.f2444z
            if (r8 == 0) goto L_0x0258
            boolean r8 = r9.f2410J
            if (r8 == 0) goto L_0x0258
            r8 = 1
            r9.mo2548G4(r8)
            android.view.View r8 = r9.f2406F
            r10.mo2913q(r7, r8, r0)
            android.view.ViewGroup r8 = r9.f2405E
            androidx.fragment.app.e0 r9 = new androidx.fragment.app.e0
            r9.<init>(r0)
            p098d.p120g.p130j.C4759k.m17288a(r8, r9)
        L_0x0258:
            java.util.ArrayList r20 = r10.mo2942n(r4)
            r22 = r10
            r23 = r5
            r24 = r11
            r25 = r1
            r26 = r7
            r27 = r0
            r28 = r15
            r29 = r4
            r22.mo2914r(r23, r24, r25, r26, r27, r28, r29)
            r10.mo2906c(r2, r5)
            r16 = r10
            r17 = r2
            r18 = r3
            r19 = r4
            r21 = r34
            r16.mo2943v(r17, r18, r19, r20, r21)
            r5 = 0
            m2677o(r1, r5)
            r10.mo2919x(r15, r3, r4)
            goto L_0x029d
        L_0x0287:
            r5 = 0
            goto L_0x029d
        L_0x0289:
            r30 = r5
            r34 = r13
            r31 = r14
            r32 = r15
            r5 = 0
            r14 = r4
            androidx.fragment.app.Fragment r1 = r0.f2660a
            androidx.fragment.app.Fragment r3 = r0.f2663d
            androidx.fragment.app.l0 r4 = m2669g(r3, r1)
            if (r4 != 0) goto L_0x02a3
        L_0x029d:
            r26 = r31
            r27 = r32
            goto L_0x0404
        L_0x02a3:
            boolean r7 = r0.f2661b
            boolean r8 = r0.f2664e
            java.lang.Object r15 = m2671i(r4, r1, r7)
            java.lang.Object r13 = m2672j(r4, r3, r8)
            java.util.ArrayList r12 = new java.util.ArrayList
            r12.<init>()
            java.util.ArrayList r11 = new java.util.ArrayList
            r11.<init>()
            androidx.fragment.app.Fragment r10 = r0.f2660a
            androidx.fragment.app.Fragment r9 = r0.f2663d
            if (r10 == 0) goto L_0x036b
            if (r9 != 0) goto L_0x02c3
            goto L_0x036b
        L_0x02c3:
            boolean r8 = r0.f2661b
            boolean r7 = r34.isEmpty()
            if (r7 == 0) goto L_0x02d1
            r16 = r11
            r5 = r34
            r7 = 0
            goto L_0x02d9
        L_0x02d1:
            java.lang.Object r7 = m2674l(r4, r10, r9, r8)
            r16 = r11
            r5 = r34
        L_0x02d9:
            d.d.a r11 = m2668f(r4, r5, r7, r0)
            boolean r17 = r5.isEmpty()
            if (r17 == 0) goto L_0x02e5
            r7 = 0
            goto L_0x02f0
        L_0x02e5:
            r17 = r7
            java.util.Collection r7 = r11.values()
            r12.addAll(r7)
            r7 = r17
        L_0x02f0:
            if (r15 != 0) goto L_0x0305
            if (r13 != 0) goto L_0x0305
            if (r7 != 0) goto L_0x0305
            r22 = r1
            r25 = r12
            r7 = r13
            r0 = r14
            r8 = r15
            r24 = r16
            r26 = r31
            r27 = r32
            goto L_0x037a
        L_0x0305:
            r22 = r1
            r1 = 1
            m2665c(r10, r9, r8, r11, r1)
            if (r7 == 0) goto L_0x0339
            android.graphics.Rect r1 = new android.graphics.Rect
            r1.<init>()
            r4.mo2918w(r7, r6, r12)
            r17 = r12
            boolean r12 = r0.f2664e
            androidx.fragment.app.a r14 = r0.f2665f
            r23 = r7
            r7 = r4
            r18 = r8
            r8 = r23
            r19 = r9
            r9 = r13
            r20 = r10
            r10 = r11
            r24 = r16
            r11 = r12
            r25 = r17
            r12 = r14
            m2676n(r7, r8, r9, r10, r11, r12)
            if (r15 == 0) goto L_0x0336
            r4.mo2915s(r15, r1)
        L_0x0336:
            r21 = r1
            goto L_0x0347
        L_0x0339:
            r23 = r7
            r18 = r8
            r19 = r9
            r20 = r10
            r25 = r12
            r24 = r16
            r21 = 0
        L_0x0347:
            androidx.fragment.app.i0 r1 = new androidx.fragment.app.i0
            r9 = r1
            r10 = r4
            r11 = r5
            r12 = r23
            r7 = r13
            r13 = r0
            r0 = r44
            r26 = r31
            r14 = r24
            r8 = r15
            r27 = r32
            r15 = r6
            r16 = r20
            r17 = r19
            r19 = r25
            r20 = r8
            r9.<init>(r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21)
            p098d.p120g.p130j.C4759k.m17288a(r2, r1)
            r13 = r23
            goto L_0x037b
        L_0x036b:
            r22 = r1
            r24 = r11
            r25 = r12
            r7 = r13
            r0 = r14
            r8 = r15
            r26 = r31
            r27 = r32
            r5 = r34
        L_0x037a:
            r13 = 0
        L_0x037b:
            if (r8 != 0) goto L_0x0383
            if (r13 != 0) goto L_0x0383
            if (r7 != 0) goto L_0x0383
            goto L_0x0404
        L_0x0383:
            r1 = r25
            java.util.ArrayList r16 = m2670h(r4, r7, r3, r1, r6)
            if (r16 == 0) goto L_0x0394
            boolean r9 = r16.isEmpty()
            if (r9 == 0) goto L_0x0392
            goto L_0x0394
        L_0x0392:
            r15 = r7
            goto L_0x0395
        L_0x0394:
            r15 = 0
        L_0x0395:
            r4.mo2904a(r8, r6)
            java.lang.Object r14 = r4.mo2910m(r15, r8, r13)
            if (r3 == 0) goto L_0x03c1
            if (r16 == 0) goto L_0x03c1
            int r7 = r16.size()
            if (r7 > 0) goto L_0x03ac
            int r1 = r1.size()
            if (r1 <= 0) goto L_0x03c1
        L_0x03ac:
            d.g.f.a r1 = new d.g.f.a
            r1.<init>()
            r7 = r0
            androidx.fragment.app.FragmentManager$d r7 = (androidx.fragment.app.FragmentManager.C0527d) r7
            androidx.fragment.app.FragmentManager r7 = androidx.fragment.app.FragmentManager.this
            r7.mo2718c(r3, r1)
            androidx.fragment.app.f0 r7 = new androidx.fragment.app.f0
            r7.<init>(r0, r3, r1)
            r4.mo2917u(r3, r14, r1, r7)
        L_0x03c1:
            if (r14 == 0) goto L_0x0404
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r7 = r4
            r3 = r8
            r8 = r14
            r9 = r3
            r10 = r1
            r11 = r15
            r12 = r16
            r0 = r14
            r14 = r24
            r7.mo2914r(r8, r9, r10, r11, r12, r13, r14)
            androidx.fragment.app.g0 r7 = new androidx.fragment.app.g0
            r9 = r7
            r10 = r3
            r11 = r4
            r12 = r6
            r13 = r22
            r3 = r15
            r15 = r1
            r17 = r3
            r9.<init>(r10, r11, r12, r13, r14, r15, r16, r17)
            p098d.p120g.p130j.C4759k.m17288a(r2, r7)
            androidx.fragment.app.m0 r1 = new androidx.fragment.app.m0
            r3 = r24
            r1.<init>(r4, r3, r5)
            p098d.p120g.p130j.C4759k.m17288a(r2, r1)
            r4.mo2906c(r2, r0)
            androidx.fragment.app.n0 r0 = new androidx.fragment.app.n0
            r0.<init>(r4, r3, r5)
            p098d.p120g.p130j.C4759k.m17288a(r2, r0)
            goto L_0x0404
        L_0x03fe:
            r30 = r5
            r26 = r14
            r27 = r15
        L_0x0404:
            int r14 = r26 + 1
            r0 = r39
            r1 = r40
            r2 = r42
            r3 = r43
            r4 = r44
            r15 = r27
            r5 = r30
            r7 = 0
            r8 = 1
            goto L_0x0077
        L_0x0418:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.C0569j0.m2678p(android.content.Context, androidx.fragment.app.r, java.util.ArrayList, java.util.ArrayList, int, int, boolean, androidx.fragment.app.j0$a):void");
    }
}
