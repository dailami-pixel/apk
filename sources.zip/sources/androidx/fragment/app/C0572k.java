package androidx.fragment.app;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.C0909j;
import androidx.lifecycle.C0916p;
import com.vidio.android.p195tv.R;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.fragment.app.k */
public class C0572k extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {

    /* renamed from: a0 */
    private Handler f2666a0;

    /* renamed from: b0 */
    private Runnable f2667b0 = new C0573a();

    /* renamed from: c0 */
    private DialogInterface.OnCancelListener f2668c0 = new C0574b();
    /* access modifiers changed from: private */

    /* renamed from: d0 */
    public DialogInterface.OnDismissListener f2669d0 = new C0575c();

    /* renamed from: e0 */
    private int f2670e0 = 0;

    /* renamed from: f0 */
    private int f2671f0 = 0;

    /* renamed from: g0 */
    private boolean f2672g0 = true;
    /* access modifiers changed from: private */

    /* renamed from: h0 */
    public boolean f2673h0 = true;

    /* renamed from: i0 */
    private int f2674i0 = -1;

    /* renamed from: j0 */
    private boolean f2675j0;

    /* renamed from: k0 */
    private C0916p<C0909j> f2676k0 = new C0576d();
    /* access modifiers changed from: private */

    /* renamed from: l0 */
    public Dialog f2677l0;

    /* renamed from: m0 */
    private boolean f2678m0;

    /* renamed from: n0 */
    private boolean f2679n0;

    /* renamed from: o0 */
    private boolean f2680o0;

    /* renamed from: p0 */
    private boolean f2681p0 = false;

    /* renamed from: androidx.fragment.app.k$a */
    class C0573a implements Runnable {
        C0573a() {
        }

        public void run() {
            C0572k.this.f2669d0.onDismiss(C0572k.this.f2677l0);
        }
    }

    /* renamed from: androidx.fragment.app.k$b */
    class C0574b implements DialogInterface.OnCancelListener {
        C0574b() {
        }

        public void onCancel(DialogInterface dialogInterface) {
            if (C0572k.this.f2677l0 != null) {
                C0572k kVar = C0572k.this;
                kVar.onCancel(kVar.f2677l0);
            }
        }
    }

    /* renamed from: androidx.fragment.app.k$c */
    class C0575c implements DialogInterface.OnDismissListener {
        C0575c() {
        }

        public void onDismiss(DialogInterface dialogInterface) {
            if (C0572k.this.f2677l0 != null) {
                C0572k kVar = C0572k.this;
                kVar.onDismiss(kVar.f2677l0);
            }
        }
    }

    /* renamed from: androidx.fragment.app.k$d */
    class C0576d implements C0916p<C0909j> {
        C0576d() {
        }

        /* renamed from: a */
        public void mo2903a(Object obj) {
            if (((C0909j) obj) != null && C0572k.this.f2673h0) {
                View z4 = C0572k.this.mo2638z4();
                if (z4.getParent() != null) {
                    throw new IllegalStateException("DialogFragment can not be attached to a container view");
                } else if (C0572k.this.f2677l0 != null) {
                    if (FragmentManager.m2484s0(3)) {
                        Log.d("FragmentManager", "DialogFragment " + this + " setting the content view on " + C0572k.this.f2677l0);
                    }
                    C0572k.this.f2677l0.setContentView(z4);
                }
            }
        }
    }

    /* renamed from: androidx.fragment.app.k$e */
    class C0577e extends C0607r {

        /* renamed from: a */
        final /* synthetic */ C0607r f2686a;

        C0577e(C0607r rVar) {
            this.f2686a = rVar;
        }

        /* renamed from: b */
        public View mo2644b(int i) {
            View V4 = C0572k.this.mo2891V4(i);
            if (V4 != null) {
                return V4;
            }
            if (this.f2686a.mo2645c()) {
                return this.f2686a.mo2644b(i);
            }
            return null;
        }

        /* renamed from: c */
        public boolean mo2645c() {
            return C0572k.this.mo2892W4() || this.f2686a.mo2645c();
        }
    }

    /* renamed from: T4 */
    private void m2682T4(boolean z, boolean z2) {
        if (!this.f2679n0) {
            this.f2679n0 = true;
            this.f2680o0 = false;
            Dialog dialog = this.f2677l0;
            if (dialog != null) {
                dialog.setOnDismissListener((DialogInterface.OnDismissListener) null);
                this.f2677l0.dismiss();
                if (!z2) {
                    if (Looper.myLooper() == this.f2666a0.getLooper()) {
                        onDismiss(this.f2677l0);
                    } else {
                        this.f2666a0.post(this.f2667b0);
                    }
                }
            }
            this.f2678m0 = true;
            if (this.f2674i0 >= 0) {
                FragmentManager m3 = mo2606m3();
                int i = this.f2674i0;
                if (i >= 0) {
                    m3.mo2709Q(new FragmentManager.C0537n((String) null, i, 1), false);
                    this.f2674i0 = -1;
                    return;
                }
                throw new IllegalArgumentException(C4924a.m17900o("Bad id: ", i));
            }
            C0543a aVar = new C0543a(mo2606m3());
            aVar.mo2798j(this);
            if (z) {
                aVar.mo2795f();
            } else {
                aVar.mo2794e();
            }
        }
    }

    /* renamed from: J3 */
    public void mo2553J3(Context context) {
        super.mo2553J3(context);
        this.f2417Q.mo3919e(this.f2676k0);
        if (!this.f2680o0) {
            this.f2679n0 = false;
        }
    }

    /* renamed from: M3 */
    public void mo2559M3(Bundle bundle) {
        super.mo2559M3(bundle);
        this.f2666a0 = new Handler();
        this.f2673h0 = this.f2442x == 0;
        if (bundle != null) {
            this.f2670e0 = bundle.getInt("android:style", 0);
            this.f2671f0 = bundle.getInt("android:theme", 0);
            this.f2672g0 = bundle.getBoolean("android:cancelable", true);
            this.f2673h0 = bundle.getBoolean("android:showsDialog", this.f2673h0);
            this.f2674i0 = bundle.getInt("android:backStackId", -1);
        }
    }

    /* renamed from: R3 */
    public void mo2567R3() {
        super.mo2567R3();
        Dialog dialog = this.f2677l0;
        if (dialog != null) {
            this.f2678m0 = true;
            dialog.setOnDismissListener((DialogInterface.OnDismissListener) null);
            this.f2677l0.dismiss();
            if (!this.f2679n0) {
                onDismiss(this.f2677l0);
            }
            this.f2677l0 = null;
            this.f2681p0 = false;
        }
    }

    /* renamed from: S3 */
    public void mo2568S3() {
        super.mo2568S3();
        if (!this.f2680o0 && !this.f2679n0) {
            this.f2679n0 = true;
        }
        this.f2417Q.mo3922h(this.f2676k0);
    }

    /* renamed from: S4 */
    public void mo2889S4() {
        m2682T4(false, false);
    }

    /* JADX INFO: finally extract failed */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0046 A[Catch:{ all -> 0x006b }] */
    /* renamed from: T3 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.LayoutInflater mo2569T3(android.os.Bundle r8) {
        /*
            r7 = this;
            android.view.LayoutInflater r0 = r7.mo2601j3()
            boolean r1 = r7.f2673h0
            java.lang.String r2 = "FragmentManager"
            r3 = 2
            if (r1 == 0) goto L_0x009b
            boolean r4 = r7.f2675j0
            if (r4 == 0) goto L_0x0011
            goto L_0x009b
        L_0x0011:
            if (r1 != 0) goto L_0x0014
            goto L_0x006f
        L_0x0014:
            boolean r1 = r7.f2681p0
            if (r1 != 0) goto L_0x006f
            r1 = 0
            r4 = 1
            r7.f2675j0 = r4     // Catch:{ all -> 0x006b }
            android.app.Dialog r8 = r7.mo2890U4(r8)     // Catch:{ all -> 0x006b }
            r7.f2677l0 = r8     // Catch:{ all -> 0x006b }
            boolean r5 = r7.f2673h0     // Catch:{ all -> 0x006b }
            if (r5 == 0) goto L_0x0065
            int r5 = r7.f2670e0     // Catch:{ all -> 0x006b }
            if (r5 == r4) goto L_0x003b
            if (r5 == r3) goto L_0x003b
            r6 = 3
            if (r5 == r6) goto L_0x0030
            goto L_0x003e
        L_0x0030:
            android.view.Window r5 = r8.getWindow()     // Catch:{ all -> 0x006b }
            if (r5 == 0) goto L_0x003b
            r6 = 24
            r5.addFlags(r6)     // Catch:{ all -> 0x006b }
        L_0x003b:
            r8.requestWindowFeature(r4)     // Catch:{ all -> 0x006b }
        L_0x003e:
            android.content.Context r8 = r7.mo2583b3()     // Catch:{ all -> 0x006b }
            boolean r5 = r8 instanceof android.app.Activity     // Catch:{ all -> 0x006b }
            if (r5 == 0) goto L_0x004d
            android.app.Dialog r5 = r7.f2677l0     // Catch:{ all -> 0x006b }
            android.app.Activity r8 = (android.app.Activity) r8     // Catch:{ all -> 0x006b }
            r5.setOwnerActivity(r8)     // Catch:{ all -> 0x006b }
        L_0x004d:
            android.app.Dialog r8 = r7.f2677l0     // Catch:{ all -> 0x006b }
            boolean r5 = r7.f2672g0     // Catch:{ all -> 0x006b }
            r8.setCancelable(r5)     // Catch:{ all -> 0x006b }
            android.app.Dialog r8 = r7.f2677l0     // Catch:{ all -> 0x006b }
            android.content.DialogInterface$OnCancelListener r5 = r7.f2668c0     // Catch:{ all -> 0x006b }
            r8.setOnCancelListener(r5)     // Catch:{ all -> 0x006b }
            android.app.Dialog r8 = r7.f2677l0     // Catch:{ all -> 0x006b }
            android.content.DialogInterface$OnDismissListener r5 = r7.f2669d0     // Catch:{ all -> 0x006b }
            r8.setOnDismissListener(r5)     // Catch:{ all -> 0x006b }
            r7.f2681p0 = r4     // Catch:{ all -> 0x006b }
            goto L_0x0068
        L_0x0065:
            r8 = 0
            r7.f2677l0 = r8     // Catch:{ all -> 0x006b }
        L_0x0068:
            r7.f2675j0 = r1
            goto L_0x006f
        L_0x006b:
            r8 = move-exception
            r7.f2675j0 = r1
            throw r8
        L_0x006f:
            boolean r8 = androidx.fragment.app.FragmentManager.m2484s0(r3)
            if (r8 == 0) goto L_0x008e
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.String r1 = "get layout inflater for DialogFragment "
            r8.append(r1)
            r8.append(r7)
            java.lang.String r1 = " from dialog context"
            r8.append(r1)
            java.lang.String r8 = r8.toString()
            android.util.Log.d(r2, r8)
        L_0x008e:
            android.app.Dialog r8 = r7.f2677l0
            if (r8 == 0) goto L_0x009a
            android.content.Context r8 = r8.getContext()
            android.view.LayoutInflater r0 = r0.cloneInContext(r8)
        L_0x009a:
            return r0
        L_0x009b:
            boolean r8 = androidx.fragment.app.FragmentManager.m2484s0(r3)
            if (r8 == 0) goto L_0x00d2
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.String r1 = "getting layout inflater for DialogFragment "
            r8.append(r1)
            r8.append(r7)
            java.lang.String r8 = r8.toString()
            boolean r1 = r7.f2673h0
            if (r1 != 0) goto L_0x00be
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = "mShowsDialog = false: "
            goto L_0x00c5
        L_0x00be:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = "mCreatingDialog = true: "
        L_0x00c5:
            r1.append(r3)
            r1.append(r8)
            java.lang.String r8 = r1.toString()
            android.util.Log.d(r2, r8)
        L_0x00d2:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.C0572k.mo2569T3(android.os.Bundle):android.view.LayoutInflater");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: U2 */
    public C0607r mo2570U2() {
        return new C0577e(new Fragment.C0517a());
    }

    /* renamed from: U4 */
    public Dialog mo2890U4(Bundle bundle) {
        if (FragmentManager.m2484s0(3)) {
            Log.d("FragmentManager", "onCreateDialog called for DialogFragment " + this);
        }
        return new Dialog(mo2636y4(), this.f2671f0);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: V4 */
    public View mo2891V4(int i) {
        Dialog dialog = this.f2677l0;
        if (dialog != null) {
            return dialog.findViewById(i);
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: W4 */
    public boolean mo2892W4() {
        return this.f2681p0;
    }

    /* renamed from: X4 */
    public final Dialog mo2893X4() {
        Dialog dialog = this.f2677l0;
        if (dialog != null) {
            return dialog;
        }
        throw new IllegalStateException("DialogFragment " + this + " does not have a Dialog.");
    }

    /* renamed from: Y4 */
    public void mo2894Y4(boolean z) {
        this.f2672g0 = z;
        Dialog dialog = this.f2677l0;
        if (dialog != null) {
            dialog.setCancelable(z);
        }
    }

    /* renamed from: Z4 */
    public void mo2895Z4(boolean z) {
        this.f2673h0 = z;
    }

    /* renamed from: a5 */
    public void mo2896a5(int i, int i2) {
        if (FragmentManager.m2484s0(2)) {
            Log.d("FragmentManager", "Setting style and theme for DialogFragment " + this + " to " + i + ", " + i2);
        }
        this.f2670e0 = i;
        if (i == 2 || i == 3) {
            this.f2671f0 = 16973913;
        }
        if (i2 != 0) {
            this.f2671f0 = i2;
        }
    }

    /* renamed from: b5 */
    public void mo2897b5(FragmentManager fragmentManager, String str) {
        this.f2679n0 = false;
        this.f2680o0 = true;
        C0543a aVar = new C0543a(fragmentManager);
        aVar.mo2797i(0, this, str, 1);
        aVar.mo2794e();
    }

    /* renamed from: d4 */
    public void mo2588d4(Bundle bundle) {
        Dialog dialog = this.f2677l0;
        if (dialog != null) {
            Bundle onSaveInstanceState = dialog.onSaveInstanceState();
            onSaveInstanceState.putBoolean("android:dialogShowing", false);
            bundle.putBundle("android:savedDialogState", onSaveInstanceState);
        }
        int i = this.f2670e0;
        if (i != 0) {
            bundle.putInt("android:style", i);
        }
        int i2 = this.f2671f0;
        if (i2 != 0) {
            bundle.putInt("android:theme", i2);
        }
        boolean z = this.f2672g0;
        if (!z) {
            bundle.putBoolean("android:cancelable", z);
        }
        boolean z2 = this.f2673h0;
        if (!z2) {
            bundle.putBoolean("android:showsDialog", z2);
        }
        int i3 = this.f2674i0;
        if (i3 != -1) {
            bundle.putInt("android:backStackId", i3);
        }
    }

    /* renamed from: e4 */
    public void mo2590e4() {
        super.mo2590e4();
        Dialog dialog = this.f2677l0;
        if (dialog != null) {
            this.f2678m0 = false;
            dialog.show();
            View decorView = this.f2677l0.getWindow().getDecorView();
            decorView.setTag(R.id.view_tree_lifecycle_owner, this);
            decorView.setTag(R.id.view_tree_view_model_store_owner, this);
            decorView.setTag(R.id.view_tree_saved_state_registry_owner, this);
        }
    }

    /* renamed from: f4 */
    public void mo2593f4() {
        super.mo2593f4();
        Dialog dialog = this.f2677l0;
        if (dialog != null) {
            dialog.hide();
        }
    }

    /* renamed from: h4 */
    public void mo2597h4(Bundle bundle) {
        Bundle bundle2;
        super.mo2597h4(bundle);
        if (this.f2677l0 != null && bundle != null && (bundle2 = bundle.getBundle("android:savedDialogState")) != null) {
            this.f2677l0.onRestoreInstanceState(bundle2);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l4 */
    public void mo2605l4(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Bundle bundle2;
        super.mo2605l4(layoutInflater, viewGroup, bundle);
        if (this.f2406F == null && this.f2677l0 != null && bundle != null && (bundle2 = bundle.getBundle("android:savedDialogState")) != null) {
            this.f2677l0.onRestoreInstanceState(bundle2);
        }
    }

    public void onCancel(DialogInterface dialogInterface) {
    }

    public void onDismiss(DialogInterface dialogInterface) {
        if (!this.f2678m0) {
            if (FragmentManager.m2484s0(3)) {
                Log.d("FragmentManager", "onDismiss called for DialogFragment " + this);
            }
            m2682T4(true, true);
        }
    }
}
