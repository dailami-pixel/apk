package androidx.fragment.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;
import p098d.p120g.p126f.C4709a;

/* renamed from: androidx.fragment.app.k0 */
class C0578k0 extends C0585l0 {

    /* renamed from: androidx.fragment.app.k0$a */
    class C0579a extends Transition.EpicenterCallback {

        /* renamed from: a */
        final /* synthetic */ Rect f2688a;

        C0579a(C0578k0 k0Var, Rect rect) {
            this.f2688a = rect;
        }

        public Rect onGetEpicenter(Transition transition) {
            return this.f2688a;
        }
    }

    /* renamed from: androidx.fragment.app.k0$b */
    class C0580b implements Transition.TransitionListener {

        /* renamed from: a */
        final /* synthetic */ View f2689a;

        /* renamed from: b */
        final /* synthetic */ ArrayList f2690b;

        C0580b(C0578k0 k0Var, View view, ArrayList arrayList) {
            this.f2689a = view;
            this.f2690b = arrayList;
        }

        public void onTransitionCancel(Transition transition) {
        }

        public void onTransitionEnd(Transition transition) {
            transition.removeListener(this);
            this.f2689a.setVisibility(8);
            int size = this.f2690b.size();
            for (int i = 0; i < size; i++) {
                ((View) this.f2690b.get(i)).setVisibility(0);
            }
        }

        public void onTransitionPause(Transition transition) {
        }

        public void onTransitionResume(Transition transition) {
        }

        public void onTransitionStart(Transition transition) {
            transition.removeListener(this);
            transition.addListener(this);
        }
    }

    /* renamed from: androidx.fragment.app.k0$c */
    class C0581c implements Transition.TransitionListener {

        /* renamed from: a */
        final /* synthetic */ Object f2691a;

        /* renamed from: b */
        final /* synthetic */ ArrayList f2692b;

        /* renamed from: c */
        final /* synthetic */ Object f2693c;

        /* renamed from: d */
        final /* synthetic */ ArrayList f2694d;

        /* renamed from: e */
        final /* synthetic */ Object f2695e;

        /* renamed from: f */
        final /* synthetic */ ArrayList f2696f;

        C0581c(Object obj, ArrayList arrayList, Object obj2, ArrayList arrayList2, Object obj3, ArrayList arrayList3) {
            this.f2691a = obj;
            this.f2692b = arrayList;
            this.f2693c = obj2;
            this.f2694d = arrayList2;
            this.f2695e = obj3;
            this.f2696f = arrayList3;
        }

        public void onTransitionCancel(Transition transition) {
        }

        public void onTransitionEnd(Transition transition) {
            transition.removeListener(this);
        }

        public void onTransitionPause(Transition transition) {
        }

        public void onTransitionResume(Transition transition) {
        }

        public void onTransitionStart(Transition transition) {
            Object obj = this.f2691a;
            if (obj != null) {
                C0578k0.this.mo2912p(obj, this.f2692b, (ArrayList<View>) null);
            }
            Object obj2 = this.f2693c;
            if (obj2 != null) {
                C0578k0.this.mo2912p(obj2, this.f2694d, (ArrayList<View>) null);
            }
            Object obj3 = this.f2695e;
            if (obj3 != null) {
                C0578k0.this.mo2912p(obj3, this.f2696f, (ArrayList<View>) null);
            }
        }
    }

    /* renamed from: androidx.fragment.app.k0$d */
    class C0582d implements Transition.TransitionListener {

        /* renamed from: a */
        final /* synthetic */ Runnable f2698a;

        C0582d(C0578k0 k0Var, Runnable runnable) {
            this.f2698a = runnable;
        }

        public void onTransitionCancel(Transition transition) {
        }

        public void onTransitionEnd(Transition transition) {
            this.f2698a.run();
        }

        public void onTransitionPause(Transition transition) {
        }

        public void onTransitionResume(Transition transition) {
        }

        public void onTransitionStart(Transition transition) {
        }
    }

    /* renamed from: androidx.fragment.app.k0$e */
    class C0583e extends Transition.EpicenterCallback {

        /* renamed from: a */
        final /* synthetic */ Rect f2699a;

        C0583e(C0578k0 k0Var, Rect rect) {
            this.f2699a = rect;
        }

        public Rect onGetEpicenter(Transition transition) {
            Rect rect = this.f2699a;
            if (rect == null || rect.isEmpty()) {
                return null;
            }
            return this.f2699a;
        }
    }

    C0578k0() {
    }

    /* renamed from: z */
    private static boolean m2706z(Transition transition) {
        return !C0585l0.m2727k(transition.getTargetIds()) || !C0585l0.m2727k(transition.getTargetNames()) || !C0585l0.m2727k(transition.getTargetTypes());
    }

    /* renamed from: a */
    public void mo2904a(Object obj, View view) {
        if (obj != null) {
            ((Transition) obj).addTarget(view);
        }
    }

    /* renamed from: b */
    public void mo2905b(Object obj, ArrayList<View> arrayList) {
        Transition transition = (Transition) obj;
        if (transition != null) {
            int i = 0;
            if (transition instanceof TransitionSet) {
                TransitionSet transitionSet = (TransitionSet) transition;
                int transitionCount = transitionSet.getTransitionCount();
                while (i < transitionCount) {
                    mo2905b(transitionSet.getTransitionAt(i), arrayList);
                    i++;
                }
            } else if (!m2706z(transition) && C0585l0.m2727k(transition.getTargets())) {
                int size = arrayList.size();
                while (i < size) {
                    transition.addTarget(arrayList.get(i));
                    i++;
                }
            }
        }
    }

    /* renamed from: c */
    public void mo2906c(ViewGroup viewGroup, Object obj) {
        TransitionManager.beginDelayedTransition(viewGroup, (Transition) obj);
    }

    /* renamed from: e */
    public boolean mo2907e(Object obj) {
        return obj instanceof Transition;
    }

    /* renamed from: g */
    public Object mo2908g(Object obj) {
        if (obj != null) {
            return ((Transition) obj).clone();
        }
        return null;
    }

    /* renamed from: l */
    public Object mo2909l(Object obj, Object obj2, Object obj3) {
        Transition transition = (Transition) obj;
        Transition transition2 = (Transition) obj2;
        Transition transition3 = (Transition) obj3;
        if (transition != null && transition2 != null) {
            transition = new TransitionSet().addTransition(transition).addTransition(transition2).setOrdering(1);
        } else if (transition == null) {
            transition = transition2 != null ? transition2 : null;
        }
        if (transition3 == null) {
            return transition;
        }
        TransitionSet transitionSet = new TransitionSet();
        if (transition != null) {
            transitionSet.addTransition(transition);
        }
        transitionSet.addTransition(transition3);
        return transitionSet;
    }

    /* renamed from: m */
    public Object mo2910m(Object obj, Object obj2, Object obj3) {
        TransitionSet transitionSet = new TransitionSet();
        if (obj != null) {
            transitionSet.addTransition((Transition) obj);
        }
        if (obj2 != null) {
            transitionSet.addTransition((Transition) obj2);
        }
        if (obj3 != null) {
            transitionSet.addTransition((Transition) obj3);
        }
        return transitionSet;
    }

    /* renamed from: o */
    public void mo2911o(Object obj, View view) {
        if (obj != null) {
            ((Transition) obj).removeTarget(view);
        }
    }

    /* renamed from: p */
    public void mo2912p(Object obj, ArrayList<View> arrayList, ArrayList<View> arrayList2) {
        List<View> targets;
        Transition transition = (Transition) obj;
        int i = 0;
        if (transition instanceof TransitionSet) {
            TransitionSet transitionSet = (TransitionSet) transition;
            int transitionCount = transitionSet.getTransitionCount();
            while (i < transitionCount) {
                mo2912p(transitionSet.getTransitionAt(i), arrayList, arrayList2);
                i++;
            }
        } else if (!m2706z(transition) && (targets = transition.getTargets()) != null && targets.size() == arrayList.size() && targets.containsAll(arrayList)) {
            int size = arrayList2 == null ? 0 : arrayList2.size();
            while (i < size) {
                transition.addTarget(arrayList2.get(i));
                i++;
            }
            for (int size2 = arrayList.size() - 1; size2 >= 0; size2--) {
                transition.removeTarget(arrayList.get(size2));
            }
        }
    }

    /* renamed from: q */
    public void mo2913q(Object obj, View view, ArrayList<View> arrayList) {
        ((Transition) obj).addListener(new C0580b(this, view, arrayList));
    }

    /* renamed from: r */
    public void mo2914r(Object obj, Object obj2, ArrayList<View> arrayList, Object obj3, ArrayList<View> arrayList2, Object obj4, ArrayList<View> arrayList3) {
        ((Transition) obj).addListener(new C0581c(obj2, arrayList, obj3, arrayList2, obj4, arrayList3));
    }

    /* renamed from: s */
    public void mo2915s(Object obj, Rect rect) {
        if (obj != null) {
            ((Transition) obj).setEpicenterCallback(new C0583e(this, rect));
        }
    }

    /* renamed from: t */
    public void mo2916t(Object obj, View view) {
        if (view != null) {
            Rect rect = new Rect();
            mo2941j(view, rect);
            ((Transition) obj).setEpicenterCallback(new C0579a(this, rect));
        }
    }

    /* renamed from: u */
    public void mo2917u(Fragment fragment, Object obj, C4709a aVar, Runnable runnable) {
        ((Transition) obj).addListener(new C0582d(this, runnable));
    }

    /* renamed from: w */
    public void mo2918w(Object obj, View view, ArrayList<View> arrayList) {
        TransitionSet transitionSet = (TransitionSet) obj;
        List targets = transitionSet.getTargets();
        targets.clear();
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            C0585l0.m2725d(targets, arrayList.get(i));
        }
        targets.add(view);
        arrayList.add(view);
        mo2905b(transitionSet, arrayList);
    }

    /* renamed from: x */
    public void mo2919x(Object obj, ArrayList<View> arrayList, ArrayList<View> arrayList2) {
        TransitionSet transitionSet = (TransitionSet) obj;
        if (transitionSet != null) {
            transitionSet.getTargets().clear();
            transitionSet.getTargets().addAll(arrayList2);
            mo2912p(transitionSet, arrayList, arrayList2);
        }
    }

    /* renamed from: y */
    public Object mo2920y(Object obj) {
        if (obj == null) {
            return null;
        }
        TransitionSet transitionSet = new TransitionSet();
        transitionSet.addTransition((Transition) obj);
        return transitionSet;
    }
}
