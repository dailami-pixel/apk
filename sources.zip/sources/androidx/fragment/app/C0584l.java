package androidx.fragment.app;

import android.os.Bundle;
import android.os.Parcelable;
import androidx.lifecycle.C0903f;
import androidx.savedstate.SavedStateRegistry;

/* renamed from: androidx.fragment.app.l */
class C0584l implements SavedStateRegistry.C1283b {

    /* renamed from: a */
    final /* synthetic */ FragmentActivity f2700a;

    C0584l(FragmentActivity fragmentActivity) {
        this.f2700a = fragmentActivity;
    }

    /* renamed from: a */
    public Bundle mo2938a() {
        Bundle bundle = new Bundle();
        this.f2700a.mo2648F0();
        this.f2700a.f2466i.mo3944f(C0903f.C0904a.ON_STOP);
        Parcelable x = this.f2700a.f2465h.mo3011x();
        if (x != null) {
            bundle.putParcelable("android:support:fragments", x);
        }
        return bundle;
    }
}
