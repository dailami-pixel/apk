package androidx.fragment.app;

import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import p098d.p112d.C4631j;
import p098d.p120g.p126f.C4709a;
import p098d.p120g.p130j.C4759k;
import p098d.p120g.p130j.C4761m;

/* renamed from: androidx.fragment.app.l0 */
public abstract class C0585l0 {

    /* renamed from: androidx.fragment.app.l0$a */
    class C0586a implements Runnable {

        /* renamed from: a */
        final /* synthetic */ int f2701a;

        /* renamed from: b */
        final /* synthetic */ ArrayList f2702b;

        /* renamed from: c */
        final /* synthetic */ ArrayList f2703c;

        /* renamed from: d */
        final /* synthetic */ ArrayList f2704d;

        /* renamed from: e */
        final /* synthetic */ ArrayList f2705e;

        C0586a(C0585l0 l0Var, int i, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, ArrayList arrayList4) {
            this.f2701a = i;
            this.f2702b = arrayList;
            this.f2703c = arrayList2;
            this.f2704d = arrayList3;
            this.f2705e = arrayList4;
        }

        public void run() {
            for (int i = 0; i < this.f2701a; i++) {
                int i2 = C4761m.f17241f;
                ((View) this.f2702b.get(i)).setTransitionName((String) this.f2703c.get(i));
                ((View) this.f2704d.get(i)).setTransitionName((String) this.f2705e.get(i));
            }
        }
    }

    /* renamed from: d */
    protected static void m2725d(List<View> list, View view) {
        int size = list.size();
        if (!m2726h(list, view, size)) {
            list.add(view);
            for (int i = size; i < list.size(); i++) {
                View view2 = list.get(i);
                if (view2 instanceof ViewGroup) {
                    ViewGroup viewGroup = (ViewGroup) view2;
                    int childCount = viewGroup.getChildCount();
                    for (int i2 = 0; i2 < childCount; i2++) {
                        View childAt = viewGroup.getChildAt(i2);
                        if (!m2726h(list, childAt, size)) {
                            list.add(childAt);
                        }
                    }
                }
            }
        }
    }

    /* renamed from: h */
    private static boolean m2726h(List<View> list, View view, int i) {
        for (int i2 = 0; i2 < i; i2++) {
            if (list.get(i2) == view) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: k */
    protected static boolean m2727k(List list) {
        return list == null || list.isEmpty();
    }

    /* renamed from: a */
    public abstract void mo2904a(Object obj, View view);

    /* renamed from: b */
    public abstract void mo2905b(Object obj, ArrayList<View> arrayList);

    /* renamed from: c */
    public abstract void mo2906c(ViewGroup viewGroup, Object obj);

    /* renamed from: e */
    public abstract boolean mo2907e(Object obj);

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public void mo2939f(ArrayList<View> arrayList, View view) {
        if (view.getVisibility() == 0) {
            boolean z = view instanceof ViewGroup;
            ViewGroup viewGroup = view;
            if (z) {
                ViewGroup viewGroup2 = (ViewGroup) view;
                boolean isTransitionGroup = viewGroup2.isTransitionGroup();
                viewGroup = viewGroup2;
                if (!isTransitionGroup) {
                    int childCount = viewGroup2.getChildCount();
                    for (int i = 0; i < childCount; i++) {
                        mo2939f(arrayList, viewGroup2.getChildAt(i));
                    }
                    return;
                }
            }
            arrayList.add(viewGroup);
        }
    }

    /* renamed from: g */
    public abstract Object mo2908g(Object obj);

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public void mo2940i(Map<String, View> map, View view) {
        if (view.getVisibility() == 0) {
            int i = C4761m.f17241f;
            String transitionName = view.getTransitionName();
            if (transitionName != null) {
                map.put(transitionName, view);
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                int childCount = viewGroup.getChildCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    mo2940i(map, viewGroup.getChildAt(i2));
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: j */
    public void mo2941j(View view, Rect rect) {
        int i = C4761m.f17241f;
        if (view.isAttachedToWindow()) {
            RectF rectF = new RectF();
            rectF.set(0.0f, 0.0f, (float) view.getWidth(), (float) view.getHeight());
            view.getMatrix().mapRect(rectF);
            rectF.offset((float) view.getLeft(), (float) view.getTop());
            ViewParent parent = view.getParent();
            while (parent instanceof View) {
                View view2 = (View) parent;
                rectF.offset((float) (-view2.getScrollX()), (float) (-view2.getScrollY()));
                view2.getMatrix().mapRect(rectF);
                rectF.offset((float) view2.getLeft(), (float) view2.getTop());
                parent = view2.getParent();
            }
            int[] iArr = new int[2];
            view.getRootView().getLocationOnScreen(iArr);
            rectF.offset((float) iArr[0], (float) iArr[1]);
            rect.set(Math.round(rectF.left), Math.round(rectF.top), Math.round(rectF.right), Math.round(rectF.bottom));
        }
    }

    /* renamed from: l */
    public abstract Object mo2909l(Object obj, Object obj2, Object obj3);

    /* renamed from: m */
    public abstract Object mo2910m(Object obj, Object obj2, Object obj3);

    /* access modifiers changed from: package-private */
    /* renamed from: n */
    public ArrayList<String> mo2942n(ArrayList<View> arrayList) {
        ArrayList<String> arrayList2 = new ArrayList<>();
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            View view = arrayList.get(i);
            int i2 = C4761m.f17241f;
            arrayList2.add(view.getTransitionName());
            view.setTransitionName((String) null);
        }
        return arrayList2;
    }

    /* renamed from: o */
    public abstract void mo2911o(Object obj, View view);

    /* renamed from: p */
    public abstract void mo2912p(Object obj, ArrayList<View> arrayList, ArrayList<View> arrayList2);

    /* renamed from: q */
    public abstract void mo2913q(Object obj, View view, ArrayList<View> arrayList);

    /* renamed from: r */
    public abstract void mo2914r(Object obj, Object obj2, ArrayList<View> arrayList, Object obj3, ArrayList<View> arrayList2, Object obj4, ArrayList<View> arrayList3);

    /* renamed from: s */
    public abstract void mo2915s(Object obj, Rect rect);

    /* renamed from: t */
    public abstract void mo2916t(Object obj, View view);

    /* renamed from: u */
    public void mo2917u(Fragment fragment, Object obj, C4709a aVar, Runnable runnable) {
        runnable.run();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: v */
    public void mo2943v(View view, ArrayList<View> arrayList, ArrayList<View> arrayList2, ArrayList<String> arrayList3, Map<String, String> map) {
        int size = arrayList2.size();
        ArrayList arrayList4 = new ArrayList();
        for (int i = 0; i < size; i++) {
            View view2 = arrayList.get(i);
            int i2 = C4761m.f17241f;
            String transitionName = view2.getTransitionName();
            arrayList4.add(transitionName);
            if (transitionName != null) {
                view2.setTransitionName((String) null);
                String str = (String) ((C4631j) map).getOrDefault(transitionName, null);
                int i3 = 0;
                while (true) {
                    if (i3 >= size) {
                        break;
                    } else if (str.equals(arrayList3.get(i3))) {
                        arrayList2.get(i3).setTransitionName(transitionName);
                        break;
                    } else {
                        i3++;
                    }
                }
            }
        }
        C4759k.m17288a(view, new C0586a(this, size, arrayList2, arrayList3, arrayList, arrayList4));
    }

    /* renamed from: w */
    public abstract void mo2918w(Object obj, View view, ArrayList<View> arrayList);

    /* renamed from: x */
    public abstract void mo2919x(Object obj, ArrayList<View> arrayList, ArrayList<View> arrayList2);

    /* renamed from: y */
    public abstract Object mo2920y(Object obj);
}
