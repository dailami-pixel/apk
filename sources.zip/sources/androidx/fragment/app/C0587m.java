package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import androidx.activity.p003d.C0089b;

/* renamed from: androidx.fragment.app.m */
class C0587m implements C0089b {

    /* renamed from: a */
    final /* synthetic */ FragmentActivity f2706a;

    C0587m(FragmentActivity fragmentActivity) {
        this.f2706a = fragmentActivity;
    }

    /* renamed from: a */
    public void mo377a(Context context) {
        this.f2706a.f2465h.mo2989a((Fragment) null);
        Bundle a = this.f2706a.mo340F1().mo5349a("android:support:fragments");
        if (a != null) {
            this.f2706a.f2465h.mo3010w(a.getParcelable("android:support:fragments"));
        }
    }
}
