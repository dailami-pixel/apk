package androidx.fragment.app;

import android.view.View;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import p098d.p120g.p130j.C4761m;

/* renamed from: androidx.fragment.app.m0 */
class C0588m0 implements Runnable {

    /* renamed from: a */
    final /* synthetic */ ArrayList f2707a;

    /* renamed from: b */
    final /* synthetic */ Map f2708b;

    C0588m0(C0585l0 l0Var, ArrayList arrayList, Map map) {
        this.f2707a = arrayList;
        this.f2708b = map;
    }

    public void run() {
        String str;
        int size = this.f2707a.size();
        for (int i = 0; i < size; i++) {
            View view = (View) this.f2707a.get(i);
            int i2 = C4761m.f17241f;
            String transitionName = view.getTransitionName();
            if (transitionName != null) {
                Iterator it = this.f2708b.entrySet().iterator();
                while (true) {
                    if (!it.hasNext()) {
                        str = null;
                        break;
                    }
                    Map.Entry entry = (Map.Entry) it.next();
                    if (transitionName.equals(entry.getValue())) {
                        str = (String) entry.getKey();
                        break;
                    }
                }
                view.setTransitionName(str);
            }
        }
    }
}
