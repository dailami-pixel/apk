package androidx.fragment.app;

import android.animation.Animator;
import android.view.View;
import p098d.p120g.p126f.C4709a;

/* renamed from: androidx.fragment.app.n */
class C0589n implements C4709a.C4710a {

    /* renamed from: a */
    final /* synthetic */ Fragment f2709a;

    C0589n(Fragment fragment) {
        this.f2709a = fragment;
    }

    /* renamed from: a */
    public void mo2874a() {
        if (this.f2709a.mo2577Y2() != null) {
            View Y2 = this.f2709a.mo2577Y2();
            this.f2709a.mo2538B4((View) null);
            Y2.clearAnimation();
        }
        this.f2709a.mo2542D4((Animator) null);
    }
}
