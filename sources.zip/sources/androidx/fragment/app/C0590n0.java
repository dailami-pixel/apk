package androidx.fragment.app;

import android.view.View;
import java.util.ArrayList;
import java.util.Map;
import p098d.p120g.p130j.C4761m;

/* renamed from: androidx.fragment.app.n0 */
class C0590n0 implements Runnable {

    /* renamed from: a */
    final /* synthetic */ ArrayList f2710a;

    /* renamed from: b */
    final /* synthetic */ Map f2711b;

    C0590n0(C0585l0 l0Var, ArrayList arrayList, Map map) {
        this.f2710a = arrayList;
        this.f2711b = map;
    }

    public void run() {
        int size = this.f2710a.size();
        for (int i = 0; i < size; i++) {
            View view = (View) this.f2710a.get(i);
            int i2 = C4761m.f17241f;
            view.setTransitionName((String) this.f2711b.get(view.getTransitionName()));
        }
    }
}
