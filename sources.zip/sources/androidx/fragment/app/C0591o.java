package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.fragment.app.C0569j0;
import androidx.fragment.app.FragmentManager;
import p098d.p120g.p126f.C4709a;

/* renamed from: androidx.fragment.app.o */
class C0591o implements Animation.AnimationListener {

    /* renamed from: a */
    final /* synthetic */ ViewGroup f2712a;

    /* renamed from: b */
    final /* synthetic */ Fragment f2713b;

    /* renamed from: c */
    final /* synthetic */ C0569j0.C0570a f2714c;

    /* renamed from: d */
    final /* synthetic */ C4709a f2715d;

    /* renamed from: androidx.fragment.app.o$a */
    class C0592a implements Runnable {
        C0592a() {
        }

        public void run() {
            if (C0591o.this.f2713b.mo2577Y2() != null) {
                C0591o.this.f2713b.mo2538B4((View) null);
                C0591o oVar = C0591o.this;
                ((FragmentManager.C0527d) oVar.f2714c).mo2764a(oVar.f2713b, oVar.f2715d);
            }
        }
    }

    C0591o(ViewGroup viewGroup, Fragment fragment, C0569j0.C0570a aVar, C4709a aVar2) {
        this.f2712a = viewGroup;
        this.f2713b = fragment;
        this.f2714c = aVar;
        this.f2715d = aVar2;
    }

    public void onAnimationEnd(Animation animation) {
        this.f2712a.post(new C0592a());
    }

    public void onAnimationRepeat(Animation animation) {
    }

    public void onAnimationStart(Animation animation) {
    }
}
