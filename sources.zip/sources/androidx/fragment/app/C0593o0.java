package androidx.fragment.app;

import android.os.Bundle;
import androidx.lifecycle.C0903f;
import androidx.lifecycle.C0910k;
import androidx.savedstate.C1284a;
import androidx.savedstate.C1285b;
import androidx.savedstate.SavedStateRegistry;

/* renamed from: androidx.fragment.app.o0 */
class C0593o0 implements C1285b {

    /* renamed from: a */
    private C0910k f2717a = null;

    /* renamed from: b */
    private C1284a f2718b = null;

    C0593o0() {
    }

    /* renamed from: F1 */
    public SavedStateRegistry mo340F1() {
        return this.f2718b.mo5354b();
    }

    /* renamed from: G */
    public C0903f mo341G() {
        if (this.f2717a == null) {
            this.f2717a = new C0910k(this);
            this.f2718b = C1284a.m5335a(this);
        }
        return this.f2717a;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo2951a(C0903f.C0904a aVar) {
        this.f2717a.mo3944f(aVar);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo2952b() {
        if (this.f2717a == null) {
            this.f2717a = new C0910k(this);
            this.f2718b = C1284a.m5335a(this);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public boolean mo2953c() {
        return this.f2717a != null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public void mo2954d(Bundle bundle) {
        this.f2718b.mo5355c(bundle);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo2955e(Bundle bundle) {
        this.f2718b.mo5356d(bundle);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public void mo2956f(C0903f.C0905b bVar) {
        this.f2717a.mo3946k(bVar);
    }
}
