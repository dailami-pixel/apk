package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.C0569j0;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import p098d.p120g.p126f.C4709a;

/* renamed from: androidx.fragment.app.p */
class C0594p extends AnimatorListenerAdapter {

    /* renamed from: a */
    final /* synthetic */ ViewGroup f2719a;

    /* renamed from: b */
    final /* synthetic */ View f2720b;

    /* renamed from: c */
    final /* synthetic */ Fragment f2721c;

    /* renamed from: d */
    final /* synthetic */ C0569j0.C0570a f2722d;

    /* renamed from: e */
    final /* synthetic */ C4709a f2723e;

    C0594p(ViewGroup viewGroup, View view, Fragment fragment, C0569j0.C0570a aVar, C4709a aVar2) {
        this.f2719a = viewGroup;
        this.f2720b = view;
        this.f2721c = fragment;
        this.f2722d = aVar;
        this.f2723e = aVar2;
    }

    public void onAnimationEnd(Animator animator) {
        this.f2719a.endViewTransition(this.f2720b);
        Fragment fragment = this.f2721c;
        Fragment.C0518b bVar = fragment.f2409I;
        Animator animator2 = bVar == null ? null : bVar.f2449b;
        fragment.mo2542D4((Animator) null);
        if (animator2 != null && this.f2719a.indexOfChild(this.f2720b) < 0) {
            ((FragmentManager.C0527d) this.f2722d).mo2764a(this.f2721c, this.f2723e);
        }
    }
}
