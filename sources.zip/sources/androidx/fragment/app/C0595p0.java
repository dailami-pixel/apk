package androidx.fragment.app;

import android.util.Log;
import java.io.Writer;

/* renamed from: androidx.fragment.app.p0 */
final class C0595p0 extends Writer {

    /* renamed from: a */
    private final String f2724a;

    /* renamed from: b */
    private StringBuilder f2725b = new StringBuilder(128);

    C0595p0(String str) {
        this.f2724a = str;
    }

    /* renamed from: b */
    private void m2760b() {
        if (this.f2725b.length() > 0) {
            Log.d(this.f2724a, this.f2725b.toString());
            StringBuilder sb = this.f2725b;
            sb.delete(0, sb.length());
        }
    }

    public void close() {
        m2760b();
    }

    public void flush() {
        m2760b();
    }

    public void write(char[] cArr, int i, int i2) {
        for (int i3 = 0; i3 < i2; i3++) {
            char c = cArr[i + i3];
            if (c == 10) {
                m2760b();
            } else {
                this.f2725b.append(c);
            }
        }
    }
}
