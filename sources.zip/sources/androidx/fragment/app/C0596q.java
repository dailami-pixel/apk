package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.Transformation;
import androidx.fragment.app.Fragment;
import com.vidio.android.p195tv.R;
import p098d.p120g.p130j.C4759k;

/* renamed from: androidx.fragment.app.q */
class C0596q {

    /* renamed from: androidx.fragment.app.q$a */
    static class C0597a {

        /* renamed from: a */
        public final Animation f2726a;

        /* renamed from: b */
        public final Animator f2727b;

        C0597a(Animator animator) {
            this.f2726a = null;
            this.f2727b = animator;
        }

        C0597a(Animation animation) {
            this.f2726a = animation;
            this.f2727b = null;
        }
    }

    /* renamed from: androidx.fragment.app.q$b */
    static class C0598b extends AnimationSet implements Runnable {

        /* renamed from: a */
        private final ViewGroup f2728a;

        /* renamed from: b */
        private final View f2729b;

        /* renamed from: c */
        private boolean f2730c;

        /* renamed from: d */
        private boolean f2731d;

        /* renamed from: e */
        private boolean f2732e = true;

        C0598b(Animation animation, ViewGroup viewGroup, View view) {
            super(false);
            this.f2728a = viewGroup;
            this.f2729b = view;
            addAnimation(animation);
            viewGroup.post(this);
        }

        public boolean getTransformation(long j, Transformation transformation) {
            this.f2732e = true;
            if (this.f2730c) {
                return !this.f2731d;
            }
            if (!super.getTransformation(j, transformation)) {
                this.f2730c = true;
                C4759k.m17288a(this.f2728a, this);
            }
            return true;
        }

        public boolean getTransformation(long j, Transformation transformation, float f) {
            this.f2732e = true;
            if (this.f2730c) {
                return !this.f2731d;
            }
            if (!super.getTransformation(j, transformation, f)) {
                this.f2730c = true;
                C4759k.m17288a(this.f2728a, this);
            }
            return true;
        }

        public void run() {
            if (this.f2730c || !this.f2732e) {
                this.f2728a.endViewTransition(this.f2729b);
                this.f2731d = true;
                return;
            }
            this.f2732e = false;
            this.f2728a.post(this);
        }
    }

    /* renamed from: a */
    static C0597a m2761a(Context context, Fragment fragment, boolean z, boolean z2) {
        Fragment.C0518b bVar = fragment.f2409I;
        boolean z3 = false;
        int i = bVar == null ? 0 : bVar.f2455h;
        int o3 = z2 ? z ? fragment.mo2610o3() : fragment.mo2615p3() : z ? fragment.mo2585c3() : fragment.mo2592f3();
        fragment.mo2540C4(0, 0, 0, 0);
        ViewGroup viewGroup = fragment.f2405E;
        if (!(viewGroup == null || viewGroup.getTag(R.id.visible_removing_fragment_view_tag) == null)) {
            fragment.f2405E.setTag(R.id.visible_removing_fragment_view_tag, (Object) null);
        }
        ViewGroup viewGroup2 = fragment.f2405E;
        if (viewGroup2 != null && viewGroup2.getLayoutTransition() != null) {
            return null;
        }
        Animation N3 = fragment.mo2561N3();
        if (N3 != null) {
            return new C0597a(N3);
        }
        Animator O3 = fragment.mo2563O3();
        if (O3 != null) {
            return new C0597a(O3);
        }
        if (o3 == 0 && i != 0) {
            o3 = i != 4097 ? i != 4099 ? i != 8194 ? -1 : z ? R.animator.fragment_close_enter : R.animator.fragment_close_exit : z ? R.animator.fragment_fade_enter : R.animator.fragment_fade_exit : z ? R.animator.fragment_open_enter : R.animator.fragment_open_exit;
        }
        if (o3 != 0) {
            boolean equals = "anim".equals(context.getResources().getResourceTypeName(o3));
            if (equals) {
                try {
                    Animation loadAnimation = AnimationUtils.loadAnimation(context, o3);
                    if (loadAnimation != null) {
                        return new C0597a(loadAnimation);
                    }
                    z3 = true;
                } catch (Resources.NotFoundException e) {
                    throw e;
                } catch (RuntimeException unused) {
                }
            }
            if (!z3) {
                try {
                    Animator loadAnimator = AnimatorInflater.loadAnimator(context, o3);
                    if (loadAnimator != null) {
                        return new C0597a(loadAnimator);
                    }
                } catch (RuntimeException e2) {
                    if (!equals) {
                        Animation loadAnimation2 = AnimationUtils.loadAnimation(context, o3);
                        if (loadAnimation2 != null) {
                            return new C0597a(loadAnimation2);
                        }
                    } else {
                        throw e2;
                    }
                }
            }
        }
        return null;
    }
}
