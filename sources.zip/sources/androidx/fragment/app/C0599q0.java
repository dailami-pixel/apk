package androidx.fragment.app;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.appsflyer.oaid.BuildConfig;
import com.vidio.android.p195tv.R;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import p098d.p120g.p126f.C4709a;
import p098d.p120g.p130j.C4761m;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.fragment.app.q0 */
abstract class C0599q0 {

    /* renamed from: a */
    private final ViewGroup f2733a;

    /* renamed from: b */
    final ArrayList<C0603d> f2734b = new ArrayList<>();

    /* renamed from: c */
    final ArrayList<C0603d> f2735c = new ArrayList<>();

    /* renamed from: d */
    boolean f2736d = false;

    /* renamed from: e */
    boolean f2737e = false;

    /* renamed from: androidx.fragment.app.q0$a */
    class C0600a implements Runnable {

        /* renamed from: a */
        final /* synthetic */ C0602c f2738a;

        C0600a(C0602c cVar) {
            this.f2738a = cVar;
        }

        public void run() {
            if (C0599q0.this.f2734b.contains(this.f2738a)) {
                this.f2738a.mo2980e().mo2988a(this.f2738a.mo2981f().f2406F);
            }
        }
    }

    /* renamed from: androidx.fragment.app.q0$b */
    class C0601b implements Runnable {

        /* renamed from: a */
        final /* synthetic */ C0602c f2740a;

        C0601b(C0602c cVar) {
            this.f2740a = cVar;
        }

        public void run() {
            C0599q0.this.f2734b.remove(this.f2740a);
            C0599q0.this.f2735c.remove(this.f2740a);
        }
    }

    /* renamed from: androidx.fragment.app.q0$c */
    private static class C0602c extends C0603d {

        /* renamed from: h */
        private final C0544a0 f2742h;

        C0602c(C0603d.C0606c cVar, C0603d.C0605b bVar, C0544a0 a0Var, C4709a aVar) {
            super(cVar, bVar, a0Var.mo2817k(), aVar);
            this.f2742h = a0Var;
        }

        /* renamed from: c */
        public void mo2975c() {
            super.mo2975c();
            this.f2742h.mo2818l();
        }

        /* access modifiers changed from: package-private */
        /* renamed from: l */
        public void mo2976l() {
            if (mo2982g() == C0603d.C0605b.ADDING) {
                Fragment k = this.f2742h.mo2817k();
                View findFocus = k.f2406F.findFocus();
                if (findFocus != null) {
                    k.mo2546F4(findFocus);
                    if (FragmentManager.m2484s0(2)) {
                        Log.v("FragmentManager", "requestFocus: Saved focused view " + findFocus + " for Fragment " + k);
                    }
                }
                View z4 = mo2981f().mo2638z4();
                if (z4.getParent() == null) {
                    this.f2742h.mo2808b();
                    z4.setAlpha(0.0f);
                }
                if (z4.getAlpha() == 0.0f && z4.getVisibility() == 0) {
                    z4.setVisibility(4);
                }
                Fragment.C0518b bVar = k.f2409I;
                z4.setAlpha(bVar == null ? 1.0f : bVar.f2461n);
            }
        }
    }

    /* renamed from: androidx.fragment.app.q0$d */
    static class C0603d {

        /* renamed from: a */
        private C0606c f2743a;

        /* renamed from: b */
        private C0605b f2744b;

        /* renamed from: c */
        private final Fragment f2745c;

        /* renamed from: d */
        private final List<Runnable> f2746d = new ArrayList();

        /* renamed from: e */
        private final HashSet<C4709a> f2747e = new HashSet<>();

        /* renamed from: f */
        private boolean f2748f = false;

        /* renamed from: g */
        private boolean f2749g = false;

        /* renamed from: androidx.fragment.app.q0$d$a */
        class C0604a implements C4709a.C4710a {
            C0604a() {
            }

            /* renamed from: a */
            public void mo2874a() {
                C0603d.this.mo2978b();
            }
        }

        /* renamed from: androidx.fragment.app.q0$d$b */
        enum C0605b {
            NONE,
            ADDING,
            REMOVING
        }

        /* renamed from: androidx.fragment.app.q0$d$c */
        enum C0606c {
            REMOVED,
            VISIBLE,
            GONE,
            INVISIBLE;

            /* renamed from: b */
            static C0606c m2792b(int i) {
                if (i == 0) {
                    return VISIBLE;
                }
                if (i == 4) {
                    return INVISIBLE;
                }
                if (i == 8) {
                    return GONE;
                }
                throw new IllegalArgumentException(C4924a.m17900o("Unknown visibility ", i));
            }

            /* renamed from: f */
            static C0606c m2793f(View view) {
                return (view.getAlpha() == 0.0f && view.getVisibility() == 0) ? INVISIBLE : m2792b(view.getVisibility());
            }

            /* access modifiers changed from: package-private */
            /* renamed from: a */
            public void mo2988a(View view) {
                int i;
                int ordinal = ordinal();
                if (ordinal != 0) {
                    if (ordinal == 1) {
                        if (FragmentManager.m2484s0(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to VISIBLE");
                        }
                        i = 0;
                    } else if (ordinal == 2) {
                        if (FragmentManager.m2484s0(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to GONE");
                        }
                        i = 8;
                    } else if (ordinal == 3) {
                        if (FragmentManager.m2484s0(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to INVISIBLE");
                        }
                        i = 4;
                    } else {
                        return;
                    }
                    view.setVisibility(i);
                    return;
                }
                ViewGroup viewGroup = (ViewGroup) view.getParent();
                if (viewGroup != null) {
                    if (FragmentManager.m2484s0(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: Removing view " + view + " from container " + viewGroup);
                    }
                    viewGroup.removeView(view);
                }
            }
        }

        C0603d(C0606c cVar, C0605b bVar, Fragment fragment, C4709a aVar) {
            this.f2743a = cVar;
            this.f2744b = bVar;
            this.f2745c = fragment;
            aVar.mo21777c(new C0604a());
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public final void mo2977a(Runnable runnable) {
            this.f2746d.add(runnable);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public final void mo2978b() {
            if (!this.f2748f) {
                this.f2748f = true;
                if (this.f2747e.isEmpty()) {
                    mo2975c();
                    return;
                }
                Iterator it = new ArrayList(this.f2747e).iterator();
                while (it.hasNext()) {
                    ((C4709a) it.next()).mo21775a();
                }
            }
        }

        /* renamed from: c */
        public void mo2975c() {
            if (!this.f2749g) {
                if (FragmentManager.m2484s0(2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: " + this + " has called complete.");
                }
                this.f2749g = true;
                for (Runnable run : this.f2746d) {
                    run.run();
                }
            }
        }

        /* renamed from: d */
        public final void mo2979d(C4709a aVar) {
            if (this.f2747e.remove(aVar) && this.f2747e.isEmpty()) {
                mo2975c();
            }
        }

        /* renamed from: e */
        public C0606c mo2980e() {
            return this.f2743a;
        }

        /* renamed from: f */
        public final Fragment mo2981f() {
            return this.f2745c;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: g */
        public C0605b mo2982g() {
            return this.f2744b;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: h */
        public final boolean mo2983h() {
            return this.f2748f;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: i */
        public final boolean mo2984i() {
            return this.f2749g;
        }

        /* renamed from: j */
        public final void mo2985j(C4709a aVar) {
            mo2976l();
            this.f2747e.add(aVar);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: k */
        public final void mo2986k(C0606c cVar, C0605b bVar) {
            C0605b bVar2;
            C0606c cVar2 = C0606c.REMOVED;
            int ordinal = bVar.ordinal();
            if (ordinal != 0) {
                if (ordinal != 1) {
                    if (ordinal == 2) {
                        if (FragmentManager.m2484s0(2)) {
                            StringBuilder P = C4924a.m17863P("SpecialEffectsController: For fragment ");
                            P.append(this.f2745c);
                            P.append(" mFinalState = ");
                            P.append(this.f2743a);
                            P.append(" -> REMOVED. mLifecycleImpact  = ");
                            P.append(this.f2744b);
                            P.append(" to REMOVING.");
                            Log.v("FragmentManager", P.toString());
                        }
                        this.f2743a = cVar2;
                        bVar2 = C0605b.REMOVING;
                    } else {
                        return;
                    }
                } else if (this.f2743a == cVar2) {
                    if (FragmentManager.m2484s0(2)) {
                        StringBuilder P2 = C4924a.m17863P("SpecialEffectsController: For fragment ");
                        P2.append(this.f2745c);
                        P2.append(" mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = ");
                        P2.append(this.f2744b);
                        P2.append(" to ADDING.");
                        Log.v("FragmentManager", P2.toString());
                    }
                    this.f2743a = C0606c.VISIBLE;
                    bVar2 = C0605b.ADDING;
                } else {
                    return;
                }
                this.f2744b = bVar2;
            } else if (this.f2743a != cVar2) {
                if (FragmentManager.m2484s0(2)) {
                    StringBuilder P3 = C4924a.m17863P("SpecialEffectsController: For fragment ");
                    P3.append(this.f2745c);
                    P3.append(" mFinalState = ");
                    P3.append(this.f2743a);
                    P3.append(" -> ");
                    P3.append(cVar);
                    P3.append(". ");
                    Log.v("FragmentManager", P3.toString());
                }
                this.f2743a = cVar;
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: l */
        public void mo2976l() {
        }

        public String toString() {
            StringBuilder T = C4924a.m17867T("Operation ", "{");
            T.append(Integer.toHexString(System.identityHashCode(this)));
            T.append("} ");
            T.append("{");
            T.append("mFinalState = ");
            T.append(this.f2743a);
            T.append("} ");
            T.append("{");
            T.append("mLifecycleImpact = ");
            T.append(this.f2744b);
            T.append("} ");
            T.append("{");
            T.append("mFragment = ");
            T.append(this.f2745c);
            T.append("}");
            return T.toString();
        }
    }

    C0599q0(ViewGroup viewGroup) {
        this.f2733a = viewGroup;
    }

    /* renamed from: a */
    private void m2762a(C0603d.C0606c cVar, C0603d.C0605b bVar, C0544a0 a0Var) {
        synchronized (this.f2734b) {
            C4709a aVar = new C4709a();
            C0603d h = m2763h(a0Var.mo2817k());
            if (h != null) {
                h.mo2986k(cVar, bVar);
                return;
            }
            C0602c cVar2 = new C0602c(cVar, bVar, a0Var, aVar);
            this.f2734b.add(cVar2);
            cVar2.mo2977a(new C0600a(cVar2));
            cVar2.mo2977a(new C0601b(cVar2));
        }
    }

    /* renamed from: h */
    private C0603d m2763h(Fragment fragment) {
        Iterator<C0603d> it = this.f2734b.iterator();
        while (it.hasNext()) {
            C0603d next = it.next();
            if (next.mo2981f().equals(fragment) && !next.mo2983h()) {
                return next;
            }
        }
        return null;
    }

    /* renamed from: l */
    static C0599q0 m2764l(ViewGroup viewGroup, FragmentManager fragmentManager) {
        return m2765m(viewGroup, fragmentManager.mo2735m0());
    }

    /* renamed from: m */
    static C0599q0 m2765m(ViewGroup viewGroup, C0608r0 r0Var) {
        Object tag = viewGroup.getTag(R.id.special_effects_controller_view_tag);
        if (tag instanceof C0599q0) {
            return (C0599q0) tag;
        }
        Objects.requireNonNull((FragmentManager.C0529f) r0Var);
        C0546b bVar = new C0546b(viewGroup);
        viewGroup.setTag(R.id.special_effects_controller_view_tag, bVar);
        return bVar;
    }

    /* renamed from: o */
    private void m2766o() {
        Iterator<C0603d> it = this.f2734b.iterator();
        while (it.hasNext()) {
            C0603d next = it.next();
            if (next.mo2982g() == C0603d.C0605b.ADDING) {
                next.mo2986k(C0603d.C0606c.m2792b(next.mo2981f().mo2638z4().getVisibility()), C0603d.C0605b.NONE);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo2964b(C0603d.C0606c cVar, C0544a0 a0Var) {
        if (FragmentManager.m2484s0(2)) {
            StringBuilder P = C4924a.m17863P("SpecialEffectsController: Enqueuing add operation for fragment ");
            P.append(a0Var.mo2817k());
            Log.v("FragmentManager", P.toString());
        }
        m2762a(cVar, C0603d.C0605b.ADDING, a0Var);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo2965c(C0544a0 a0Var) {
        if (FragmentManager.m2484s0(2)) {
            StringBuilder P = C4924a.m17863P("SpecialEffectsController: Enqueuing hide operation for fragment ");
            P.append(a0Var.mo2817k());
            Log.v("FragmentManager", P.toString());
        }
        m2762a(C0603d.C0606c.GONE, C0603d.C0605b.NONE, a0Var);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public void mo2966d(C0544a0 a0Var) {
        if (FragmentManager.m2484s0(2)) {
            StringBuilder P = C4924a.m17863P("SpecialEffectsController: Enqueuing remove operation for fragment ");
            P.append(a0Var.mo2817k());
            Log.v("FragmentManager", P.toString());
        }
        m2762a(C0603d.C0606c.REMOVED, C0603d.C0605b.REMOVING, a0Var);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo2967e(C0544a0 a0Var) {
        if (FragmentManager.m2484s0(2)) {
            StringBuilder P = C4924a.m17863P("SpecialEffectsController: Enqueuing show operation for fragment ");
            P.append(a0Var.mo2817k());
            Log.v("FragmentManager", P.toString());
        }
        m2762a(C0603d.C0606c.VISIBLE, C0603d.C0605b.NONE, a0Var);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public abstract void mo2829f(List<C0603d> list, boolean z);

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public void mo2968g() {
        if (!this.f2737e) {
            ViewGroup viewGroup = this.f2733a;
            int i = C4761m.f17241f;
            if (!viewGroup.isAttachedToWindow()) {
                mo2969i();
                this.f2736d = false;
                return;
            }
            synchronized (this.f2734b) {
                if (!this.f2734b.isEmpty()) {
                    ArrayList arrayList = new ArrayList(this.f2735c);
                    this.f2735c.clear();
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        C0603d dVar = (C0603d) it.next();
                        if (FragmentManager.m2484s0(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Cancelling operation " + dVar);
                        }
                        dVar.mo2978b();
                        if (!dVar.mo2984i()) {
                            this.f2735c.add(dVar);
                        }
                    }
                    m2766o();
                    ArrayList arrayList2 = new ArrayList(this.f2734b);
                    this.f2734b.clear();
                    this.f2735c.addAll(arrayList2);
                    Iterator it2 = arrayList2.iterator();
                    while (it2.hasNext()) {
                        ((C0603d) it2.next()).mo2976l();
                    }
                    mo2829f(arrayList2, this.f2736d);
                    this.f2736d = false;
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public void mo2969i() {
        String str;
        String str2;
        ViewGroup viewGroup = this.f2733a;
        int i = C4761m.f17241f;
        boolean isAttachedToWindow = viewGroup.isAttachedToWindow();
        synchronized (this.f2734b) {
            m2766o();
            Iterator<C0603d> it = this.f2734b.iterator();
            while (it.hasNext()) {
                it.next().mo2976l();
            }
            Iterator it2 = new ArrayList(this.f2735c).iterator();
            while (it2.hasNext()) {
                C0603d dVar = (C0603d) it2.next();
                if (FragmentManager.m2484s0(2)) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("SpecialEffectsController: ");
                    if (isAttachedToWindow) {
                        str2 = BuildConfig.FLAVOR;
                    } else {
                        str2 = "Container " + this.f2733a + " is not attached to window. ";
                    }
                    sb.append(str2);
                    sb.append("Cancelling running operation ");
                    sb.append(dVar);
                    Log.v("FragmentManager", sb.toString());
                }
                dVar.mo2978b();
            }
            Iterator it3 = new ArrayList(this.f2734b).iterator();
            while (it3.hasNext()) {
                C0603d dVar2 = (C0603d) it3.next();
                if (FragmentManager.m2484s0(2)) {
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("SpecialEffectsController: ");
                    if (isAttachedToWindow) {
                        str = BuildConfig.FLAVOR;
                    } else {
                        str = "Container " + this.f2733a + " is not attached to window. ";
                    }
                    sb2.append(str);
                    sb2.append("Cancelling pending operation ");
                    sb2.append(dVar2);
                    Log.v("FragmentManager", sb2.toString());
                }
                dVar2.mo2978b();
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j */
    public C0603d.C0605b mo2970j(C0544a0 a0Var) {
        C0603d dVar;
        C0603d h = m2763h(a0Var.mo2817k());
        if (h != null) {
            return h.mo2982g();
        }
        Fragment k = a0Var.mo2817k();
        Iterator<C0603d> it = this.f2735c.iterator();
        while (true) {
            if (!it.hasNext()) {
                dVar = null;
                break;
            }
            dVar = it.next();
            if (dVar.mo2981f().equals(k) && !dVar.mo2983h()) {
                break;
            }
        }
        if (dVar != null) {
            return dVar.mo2982g();
        }
        return null;
    }

    /* renamed from: k */
    public ViewGroup mo2971k() {
        return this.f2733a;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n */
    public void mo2972n() {
        synchronized (this.f2734b) {
            m2766o();
            this.f2737e = false;
            int size = this.f2734b.size() - 1;
            while (true) {
                if (size < 0) {
                    break;
                }
                C0603d dVar = this.f2734b.get(size);
                C0603d.C0606c f = C0603d.C0606c.m2793f(dVar.mo2981f().f2406F);
                C0603d.C0606c e = dVar.mo2980e();
                C0603d.C0606c cVar = C0603d.C0606c.VISIBLE;
                if (e == cVar && f != cVar) {
                    this.f2737e = dVar.mo2981f().mo2535A3();
                    break;
                }
                size--;
            }
        }
    }
}
