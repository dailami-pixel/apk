package androidx.fragment.app;

import android.view.View;

/* renamed from: androidx.fragment.app.r */
public abstract class C0607r {
    /* renamed from: b */
    public abstract View mo2644b(int i);

    /* renamed from: c */
    public abstract boolean mo2645c();
}
