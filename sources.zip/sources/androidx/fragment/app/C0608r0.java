package androidx.fragment.app;

/* renamed from: androidx.fragment.app.r0 */
interface C0608r0 {
}
