package androidx.fragment.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.lifecycle.C0926v;
import p098d.p120g.C4690a;

/* renamed from: androidx.fragment.app.s */
public class C0609s {

    /* renamed from: a */
    private final C0611u<?> f2760a;

    private C0609s(C0611u<?> uVar) {
        this.f2760a = uVar;
    }

    /* renamed from: b */
    public static C0609s m2797b(C0611u<?> uVar) {
        C4690a.m17112c(uVar, "callbacks == null");
        return new C0609s(uVar);
    }

    /* renamed from: a */
    public void mo2989a(Fragment fragment) {
        C0611u<?> uVar = this.f2760a;
        uVar.f2765d.mo2725g(uVar, uVar, (Fragment) null);
    }

    /* renamed from: c */
    public void mo2990c() {
        this.f2760a.f2765d.mo2741q();
    }

    /* renamed from: d */
    public void mo2991d(Configuration configuration) {
        this.f2760a.f2765d.mo2745s(configuration);
    }

    /* renamed from: e */
    public boolean mo2992e(MenuItem menuItem) {
        return this.f2760a.f2765d.mo2746t(menuItem);
    }

    /* renamed from: f */
    public void mo2993f() {
        this.f2760a.f2765d.mo2748u();
    }

    /* renamed from: g */
    public boolean mo2994g(Menu menu, MenuInflater menuInflater) {
        return this.f2760a.f2765d.mo2750v(menu, menuInflater);
    }

    /* renamed from: h */
    public void mo2995h() {
        this.f2760a.f2765d.mo2752w();
    }

    /* renamed from: i */
    public void mo2996i() {
        this.f2760a.f2765d.mo2756y();
    }

    /* renamed from: j */
    public void mo2997j(boolean z) {
        this.f2760a.f2765d.mo2758z(z);
    }

    /* renamed from: k */
    public boolean mo2998k(MenuItem menuItem) {
        return this.f2760a.f2765d.mo2685B(menuItem);
    }

    /* renamed from: l */
    public void mo2999l(Menu menu) {
        this.f2760a.f2765d.mo2687C(menu);
    }

    /* renamed from: m */
    public void mo3000m() {
        this.f2760a.f2765d.mo2690E();
    }

    /* renamed from: n */
    public void mo3001n(boolean z) {
        this.f2760a.f2765d.mo2691F(z);
    }

    /* renamed from: o */
    public boolean mo3002o(Menu menu) {
        return this.f2760a.f2765d.mo2693G(menu);
    }

    /* renamed from: p */
    public void mo3003p() {
        this.f2760a.f2765d.mo2697I();
    }

    /* renamed from: q */
    public void mo3004q() {
        this.f2760a.f2765d.mo2699J();
    }

    /* renamed from: r */
    public void mo3005r() {
        this.f2760a.f2765d.mo2701L();
    }

    /* renamed from: s */
    public boolean mo3006s() {
        return this.f2760a.f2765d.mo2711S(true);
    }

    /* renamed from: t */
    public FragmentManager mo3007t() {
        return this.f2760a.f2765d;
    }

    /* renamed from: u */
    public void mo3008u() {
        this.f2760a.f2765d.mo2684A0();
    }

    /* renamed from: v */
    public View mo3009v(View view, String str, Context context, AttributeSet attributeSet) {
        return ((C0612v) this.f2760a.f2765d.mo2731j0()).onCreateView(view, str, context, attributeSet);
    }

    /* renamed from: w */
    public void mo3010w(Parcelable parcelable) {
        C0611u<?> uVar = this.f2760a;
        if (uVar instanceof C0926v) {
            uVar.f2765d.mo2700K0(parcelable);
            return;
        }
        throw new IllegalStateException("Your FragmentHostCallback must implement ViewModelStoreOwner to call restoreSaveState(). Call restoreAllState()  if you're still using retainNestedNonConfig().");
    }

    /* renamed from: x */
    public Parcelable mo3011x() {
        return this.f2760a.f2765d.mo2702L0();
    }
}
