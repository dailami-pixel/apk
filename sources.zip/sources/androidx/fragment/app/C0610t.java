package androidx.fragment.app;

import androidx.fragment.app.Fragment;
import p098d.p112d.C4631j;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.fragment.app.t */
public class C0610t {

    /* renamed from: a */
    private static final C4631j<ClassLoader, C4631j<String, Class<?>>> f2761a = new C4631j<>();

    /* renamed from: b */
    static boolean m2821b(ClassLoader classLoader, String str) {
        try {
            return Fragment.class.isAssignableFrom(m2822c(classLoader, str));
        } catch (ClassNotFoundException unused) {
            return false;
        }
    }

    /* renamed from: c */
    private static Class<?> m2822c(ClassLoader classLoader, String str) throws ClassNotFoundException {
        C4631j<ClassLoader, C4631j<String, Class<?>>> jVar = f2761a;
        C4631j orDefault = jVar.getOrDefault(classLoader, null);
        if (orDefault == null) {
            orDefault = new C4631j();
            jVar.put(classLoader, orDefault);
        }
        Class<?> cls = (Class) orDefault.getOrDefault(str, null);
        if (cls != null) {
            return cls;
        }
        Class<?> cls2 = Class.forName(str, false, classLoader);
        orDefault.put(str, cls2);
        return cls2;
    }

    /* renamed from: d */
    public static Class<? extends Fragment> m2823d(ClassLoader classLoader, String str) {
        try {
            return m2822c(classLoader, str);
        } catch (ClassNotFoundException e) {
            throw new Fragment.InstantiationException(C4924a.m17909x("Unable to instantiate fragment ", str, ": make sure class name exists"), e);
        } catch (ClassCastException e2) {
            throw new Fragment.InstantiationException(C4924a.m17909x("Unable to instantiate fragment ", str, ": make sure class is a valid subclass of Fragment"), e2);
        }
    }

    /* renamed from: a */
    public Fragment mo2765a(ClassLoader classLoader, String str) {
        throw null;
    }
}
