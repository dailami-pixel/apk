package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import androidx.core.content.C0474a;
import p098d.p120g.C4690a;

/* renamed from: androidx.fragment.app.u */
public abstract class C0611u<E> extends C0607r {

    /* renamed from: a */
    private final Activity f2762a;

    /* renamed from: b */
    private final Context f2763b;

    /* renamed from: c */
    private final Handler f2764c;

    /* renamed from: d */
    final FragmentManager f2765d = new C0616x();

    C0611u(FragmentActivity fragmentActivity) {
        Handler handler = new Handler();
        this.f2762a = fragmentActivity;
        C4690a.m17112c(fragmentActivity, "context == null");
        this.f2763b = fragmentActivity;
        C4690a.m17112c(handler, "handler == null");
        this.f2764c = handler;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public Activity mo3012d() {
        return this.f2762a;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public Context mo3013e() {
        return this.f2763b;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public Handler mo3014f() {
        return this.f2764c;
    }

    /* renamed from: g */
    public abstract E mo2663g();

    /* renamed from: h */
    public abstract LayoutInflater mo2664h();

    /* renamed from: i */
    public abstract boolean mo2665i(Fragment fragment);

    /* renamed from: j */
    public void mo3015j(Intent intent, int i, Bundle bundle) {
        if (i == -1) {
            Context context = this.f2763b;
            int i2 = C0474a.f2214b;
            context.startActivity(intent, bundle);
            return;
        }
        throw new IllegalStateException("Starting activity with a requestCode requires a FragmentActivity host");
    }

    /* renamed from: k */
    public abstract void mo2666k();
}
