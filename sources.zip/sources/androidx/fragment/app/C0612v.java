package androidx.fragment.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/* renamed from: androidx.fragment.app.v */
class C0612v implements LayoutInflater.Factory2 {

    /* renamed from: a */
    final FragmentManager f2766a;

    /* renamed from: androidx.fragment.app.v$a */
    class C0613a implements View.OnAttachStateChangeListener {

        /* renamed from: a */
        final /* synthetic */ C0544a0 f2767a;

        C0613a(C0544a0 a0Var) {
            this.f2767a = a0Var;
        }

        public void onViewAttachedToWindow(View view) {
            Fragment k = this.f2767a.mo2817k();
            this.f2767a.mo2818l();
            C0599q0.m2764l((ViewGroup) k.f2406F.getParent(), C0612v.this.f2766a).mo2969i();
        }

        public void onViewDetachedFromWindow(View view) {
        }
    }

    C0612v(FragmentManager fragmentManager) {
        this.f2766a = fragmentManager;
    }

    /* JADX WARNING: Removed duplicated region for block: B:46:0x0141  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0160  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View onCreateView(android.view.View r9, java.lang.String r10, android.content.Context r11, android.util.AttributeSet r12) {
        /*
            r8 = this;
            java.lang.Class<androidx.fragment.app.FragmentContainerView> r0 = androidx.fragment.app.FragmentContainerView.class
            java.lang.String r0 = r0.getName()
            boolean r0 = r0.equals(r10)
            if (r0 == 0) goto L_0x0014
            androidx.fragment.app.FragmentContainerView r9 = new androidx.fragment.app.FragmentContainerView
            androidx.fragment.app.FragmentManager r10 = r8.f2766a
            r9.<init>((android.content.Context) r11, (android.util.AttributeSet) r12, (androidx.fragment.app.FragmentManager) r10)
            return r9
        L_0x0014:
            java.lang.String r0 = "fragment"
            boolean r10 = r0.equals(r10)
            r0 = 0
            if (r10 != 0) goto L_0x001e
            return r0
        L_0x001e:
            java.lang.String r10 = "class"
            java.lang.String r10 = r12.getAttributeValue(r0, r10)
            int[] r1 = p098d.p136j.C4819a.f17401a
            android.content.res.TypedArray r1 = r11.obtainStyledAttributes(r12, r1)
            r2 = 0
            if (r10 != 0) goto L_0x0031
            java.lang.String r10 = r1.getString(r2)
        L_0x0031:
            r3 = 1
            r4 = -1
            int r5 = r1.getResourceId(r3, r4)
            r6 = 2
            java.lang.String r7 = r1.getString(r6)
            r1.recycle()
            if (r10 == 0) goto L_0x01aa
            java.lang.ClassLoader r1 = r11.getClassLoader()
            boolean r1 = androidx.fragment.app.C0610t.m2821b(r1, r10)
            if (r1 != 0) goto L_0x004d
            goto L_0x01aa
        L_0x004d:
            if (r9 == 0) goto L_0x0053
            int r2 = r9.getId()
        L_0x0053:
            if (r2 != r4) goto L_0x0078
            if (r5 != r4) goto L_0x0078
            if (r7 == 0) goto L_0x005a
            goto L_0x0078
        L_0x005a:
            java.lang.IllegalArgumentException r9 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r11 = new java.lang.StringBuilder
            r11.<init>()
            java.lang.String r12 = r12.getPositionDescription()
            r11.append(r12)
            java.lang.String r12 = ": Must specify unique android:id, android:tag, or have a parent with an id for "
            r11.append(r12)
            r11.append(r10)
            java.lang.String r10 = r11.toString()
            r9.<init>(r10)
            throw r9
        L_0x0078:
            if (r5 == r4) goto L_0x0080
            androidx.fragment.app.FragmentManager r0 = r8.f2766a
            androidx.fragment.app.Fragment r0 = r0.mo2714X(r5)
        L_0x0080:
            if (r0 != 0) goto L_0x008a
            if (r7 == 0) goto L_0x008a
            androidx.fragment.app.FragmentManager r0 = r8.f2766a
            androidx.fragment.app.Fragment r0 = r0.mo2715Y(r7)
        L_0x008a:
            if (r0 != 0) goto L_0x0094
            if (r2 == r4) goto L_0x0094
            androidx.fragment.app.FragmentManager r0 = r8.f2766a
            androidx.fragment.app.Fragment r0 = r0.mo2714X(r2)
        L_0x0094:
            java.lang.String r1 = "Fragment "
            java.lang.String r4 = "FragmentManager"
            if (r0 != 0) goto L_0x00e9
            androidx.fragment.app.FragmentManager r0 = r8.f2766a
            androidx.fragment.app.t r0 = r0.mo2724f0()
            java.lang.ClassLoader r11 = r11.getClassLoader()
            androidx.fragment.app.Fragment r0 = r0.mo2765a(r11, r10)
            r0.f2432n = r3
            if (r5 == 0) goto L_0x00ae
            r11 = r5
            goto L_0x00af
        L_0x00ae:
            r11 = r2
        L_0x00af:
            r0.f2441w = r11
            r0.f2442x = r2
            r0.f2443y = r7
            r0.f2433o = r3
            androidx.fragment.app.FragmentManager r11 = r8.f2766a
            r0.f2437s = r11
            androidx.fragment.app.u r11 = r11.mo2730i0()
            r0.f2438t = r11
            androidx.fragment.app.FragmentManager r11 = r8.f2766a
            androidx.fragment.app.u r11 = r11.mo2730i0()
            r11.mo3013e()
            android.os.Bundle r11 = r0.f2421c
            r0.mo2574W3(r12, r11)
            androidx.fragment.app.FragmentManager r11 = r8.f2766a
            androidx.fragment.app.a0 r11 = r11.mo2720d(r0)
            boolean r12 = androidx.fragment.app.FragmentManager.m2484s0(r6)
            if (r12 == 0) goto L_0x0133
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            r12.<init>()
            r12.append(r1)
            r12.append(r0)
            java.lang.String r2 = " has been inflated via the <fragment> tag: id=0x"
            goto L_0x0122
        L_0x00e9:
            boolean r11 = r0.f2433o
            if (r11 != 0) goto L_0x016c
            r0.f2433o = r3
            androidx.fragment.app.FragmentManager r11 = r8.f2766a
            r0.f2437s = r11
            androidx.fragment.app.u r11 = r11.mo2730i0()
            r0.f2438t = r11
            androidx.fragment.app.FragmentManager r11 = r8.f2766a
            androidx.fragment.app.u r11 = r11.mo2730i0()
            r11.mo3013e()
            android.os.Bundle r11 = r0.f2421c
            r0.mo2574W3(r12, r11)
            androidx.fragment.app.FragmentManager r11 = r8.f2766a
            androidx.fragment.app.a0 r11 = r11.mo2736n(r0)
            boolean r12 = androidx.fragment.app.FragmentManager.m2484s0(r6)
            if (r12 == 0) goto L_0x0133
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            r12.<init>()
            java.lang.String r2 = "Retained Fragment "
            r12.append(r2)
            r12.append(r0)
            java.lang.String r2 = " has been re-attached via the <fragment> tag: id=0x"
        L_0x0122:
            r12.append(r2)
            java.lang.String r2 = java.lang.Integer.toHexString(r5)
            r12.append(r2)
            java.lang.String r12 = r12.toString()
            android.util.Log.v(r4, r12)
        L_0x0133:
            android.view.ViewGroup r9 = (android.view.ViewGroup) r9
            r0.f2405E = r9
            r11.mo2818l()
            r11.mo2816j()
            android.view.View r9 = r0.f2406F
            if (r9 == 0) goto L_0x0160
            if (r5 == 0) goto L_0x0146
            r9.setId(r5)
        L_0x0146:
            android.view.View r9 = r0.f2406F
            java.lang.Object r9 = r9.getTag()
            if (r9 != 0) goto L_0x0153
            android.view.View r9 = r0.f2406F
            r9.setTag(r7)
        L_0x0153:
            android.view.View r9 = r0.f2406F
            androidx.fragment.app.v$a r10 = new androidx.fragment.app.v$a
            r10.<init>(r11)
            r9.addOnAttachStateChangeListener(r10)
            android.view.View r9 = r0.f2406F
            return r9
        L_0x0160:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r11 = " did not create a view."
            java.lang.String r10 = p165e.p166a.p167a.p168a.C4924a.m17909x(r1, r10, r11)
            r9.<init>(r10)
            throw r9
        L_0x016c:
            java.lang.IllegalArgumentException r9 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r11 = new java.lang.StringBuilder
            r11.<init>()
            java.lang.String r12 = r12.getPositionDescription()
            r11.append(r12)
            java.lang.String r12 = ": Duplicate id 0x"
            r11.append(r12)
            java.lang.String r12 = java.lang.Integer.toHexString(r5)
            r11.append(r12)
            java.lang.String r12 = ", tag "
            r11.append(r12)
            r11.append(r7)
            java.lang.String r12 = ", or parent id 0x"
            r11.append(r12)
            java.lang.String r12 = java.lang.Integer.toHexString(r2)
            r11.append(r12)
            java.lang.String r12 = " with another fragment for "
            r11.append(r12)
            r11.append(r10)
            java.lang.String r10 = r11.toString()
            r9.<init>(r10)
            throw r9
        L_0x01aa:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.C0612v.onCreateView(android.view.View, java.lang.String, android.content.Context, android.util.AttributeSet):android.view.View");
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView((View) null, str, context, attributeSet);
    }
}
