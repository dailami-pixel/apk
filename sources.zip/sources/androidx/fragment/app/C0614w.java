package androidx.fragment.app;

import android.os.Bundle;
import android.view.View;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

/* renamed from: androidx.fragment.app.w */
class C0614w {

    /* renamed from: a */
    private final CopyOnWriteArrayList<C0615a> f2769a = new CopyOnWriteArrayList<>();

    /* renamed from: b */
    private final FragmentManager f2770b;

    /* renamed from: androidx.fragment.app.w$a */
    private static final class C0615a {
    }

    C0614w(FragmentManager fragmentManager) {
        this.f2770b = fragmentManager;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo3020a(Fragment fragment, Bundle bundle, boolean z) {
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3020a(fragment, bundle, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo3021b(Fragment fragment, boolean z) {
        this.f2770b.mo2730i0().mo3013e();
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3021b(fragment, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo3022c(Fragment fragment, Bundle bundle, boolean z) {
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3022c(fragment, bundle, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public void mo3023d(Fragment fragment, boolean z) {
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3023d(fragment, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo3024e(Fragment fragment, boolean z) {
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3024e(fragment, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public void mo3025f(Fragment fragment, boolean z) {
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3025f(fragment, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public void mo3026g(Fragment fragment, boolean z) {
        this.f2770b.mo2730i0().mo3013e();
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3026g(fragment, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public void mo3027h(Fragment fragment, Bundle bundle, boolean z) {
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3027h(fragment, bundle, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public void mo3028i(Fragment fragment, boolean z) {
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3028i(fragment, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j */
    public void mo3029j(Fragment fragment, Bundle bundle, boolean z) {
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3029j(fragment, bundle, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k */
    public void mo3030k(Fragment fragment, boolean z) {
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3030k(fragment, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l */
    public void mo3031l(Fragment fragment, boolean z) {
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3031l(fragment, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: m */
    public void mo3032m(Fragment fragment, View view, Bundle bundle, boolean z) {
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3032m(fragment, view, bundle, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n */
    public void mo3033n(Fragment fragment, boolean z) {
        Fragment l0 = this.f2770b.mo2733l0();
        if (l0 != null) {
            l0.mo2606m3().mo2732k0().mo3033n(fragment, true);
        }
        Iterator<C0615a> it = this.f2769a.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next());
            if (!z) {
                throw null;
            }
        }
    }
}
