package androidx.fragment.app;

/* renamed from: androidx.fragment.app.x */
class C0616x extends FragmentManager {
    C0616x() {
    }
}
