package androidx.fragment.app;

import android.util.Log;
import androidx.lifecycle.C0920s;
import androidx.lifecycle.C0921t;
import androidx.lifecycle.C0925u;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

/* renamed from: androidx.fragment.app.y */
final class C0617y extends C0920s {

    /* renamed from: b */
    private static final C0921t.C0922a f2771b = new C0618a();

    /* renamed from: c */
    private final HashMap<String, Fragment> f2772c = new HashMap<>();

    /* renamed from: d */
    private final HashMap<String, C0617y> f2773d = new HashMap<>();

    /* renamed from: e */
    private final HashMap<String, C0925u> f2774e = new HashMap<>();

    /* renamed from: f */
    private final boolean f2775f;

    /* renamed from: g */
    private boolean f2776g = false;

    /* renamed from: h */
    private boolean f2777h = false;

    /* renamed from: androidx.fragment.app.y$a */
    class C0618a implements C0921t.C0922a {
        C0618a() {
        }

        /* renamed from: a */
        public <T extends C0920s> T mo3047a(Class<T> cls) {
            return new C0617y(true);
        }
    }

    C0617y(boolean z) {
        this.f2775f = z;
    }

    /* renamed from: g */
    static C0617y m2847g(C0925u uVar) {
        return (C0617y) new C0921t(uVar, f2771b).mo3970a(C0617y.class);
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public void mo3034c() {
        if (FragmentManager.m2484s0(3)) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
        this.f2776g = true;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public void mo3035d(Fragment fragment) {
        if (FragmentManager.m2484s0(3)) {
            Log.d("FragmentManager", "Clearing non-config state for " + fragment);
        }
        C0617y yVar = this.f2773d.get(fragment.f2424f);
        if (yVar != null) {
            yVar.mo3034c();
            this.f2773d.remove(fragment.f2424f);
        }
        C0925u uVar = this.f2774e.get(fragment.f2424f);
        if (uVar != null) {
            uVar.mo3972a();
            this.f2774e.remove(fragment.f2424f);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public Fragment mo3036e(String str) {
        return this.f2772c.get(str);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0617y.class != obj.getClass()) {
            return false;
        }
        C0617y yVar = (C0617y) obj;
        return this.f2772c.equals(yVar.f2772c) && this.f2773d.equals(yVar.f2773d) && this.f2774e.equals(yVar.f2774e);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public C0617y mo3038f(Fragment fragment) {
        C0617y yVar = this.f2773d.get(fragment.f2424f);
        if (yVar != null) {
            return yVar;
        }
        C0617y yVar2 = new C0617y(this.f2775f);
        this.f2773d.put(fragment.f2424f, yVar2);
        return yVar2;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public Collection<Fragment> mo3039h() {
        return new ArrayList(this.f2772c.values());
    }

    public int hashCode() {
        int hashCode = this.f2773d.hashCode();
        return this.f2774e.hashCode() + ((hashCode + (this.f2772c.hashCode() * 31)) * 31);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public C0925u mo3041i(Fragment fragment) {
        C0925u uVar = this.f2774e.get(fragment.f2424f);
        if (uVar != null) {
            return uVar;
        }
        C0925u uVar2 = new C0925u();
        this.f2774e.put(fragment.f2424f, uVar2);
        return uVar2;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j */
    public boolean mo3042j() {
        return this.f2776g;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k */
    public void mo3043k(Fragment fragment) {
        if (!this.f2777h) {
            if ((this.f2772c.remove(fragment.f2424f) != null) && FragmentManager.m2484s0(2)) {
                Log.v("FragmentManager", "Updating retained Fragments: Removed " + fragment);
            }
        } else if (FragmentManager.m2484s0(2)) {
            Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved");
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l */
    public void mo3044l(boolean z) {
        this.f2777h = z;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: m */
    public boolean mo3045m(Fragment fragment) {
        if (this.f2772c.containsKey(fragment.f2424f) && this.f2775f) {
            return this.f2776g;
        }
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator<Fragment> it = this.f2772c.values().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator<String> it2 = this.f2773d.keySet().iterator();
        while (it2.hasNext()) {
            sb.append(it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator<String> it3 = this.f2774e.keySet().iterator();
        while (it3.hasNext()) {
            sb.append(it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
