package androidx.fragment.app;

/* renamed from: androidx.fragment.app.z */
public interface C0619z {
    /* renamed from: a */
    void mo2662a(FragmentManager fragmentManager, Fragment fragment);
}
