package androidx.fragment.app;

import android.animation.Animator;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.C0903f;
import androidx.lifecycle.C0907h;
import androidx.lifecycle.C0909j;
import androidx.lifecycle.C0910k;
import androidx.lifecycle.C0915o;
import androidx.lifecycle.C0925u;
import androidx.lifecycle.C0926v;
import androidx.savedstate.C1284a;
import androidx.savedstate.C1285b;
import androidx.savedstate.SavedStateRegistry;
import com.vidio.android.p195tv.R;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import p098d.p146m.p147a.C4848a;
import p165e.p166a.p167a.p168a.C4924a;

public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, C0909j, C0926v, C1285b {

    /* renamed from: a */
    static final Object f2400a = new Object();

    /* renamed from: A */
    boolean f2401A;

    /* renamed from: B */
    boolean f2402B;

    /* renamed from: C */
    boolean f2403C = true;

    /* renamed from: D */
    private boolean f2404D;

    /* renamed from: E */
    ViewGroup f2405E;

    /* renamed from: F */
    View f2406F;

    /* renamed from: G */
    boolean f2407G;

    /* renamed from: H */
    boolean f2408H = true;

    /* renamed from: I */
    C0518b f2409I;

    /* renamed from: J */
    boolean f2410J;

    /* renamed from: K */
    float f2411K;

    /* renamed from: L */
    LayoutInflater f2412L;

    /* renamed from: M */
    boolean f2413M;

    /* renamed from: N */
    C0903f.C0905b f2414N = C0903f.C0905b.RESUMED;

    /* renamed from: O */
    C0910k f2415O;

    /* renamed from: P */
    C0593o0 f2416P;

    /* renamed from: Q */
    C0915o<C0909j> f2417Q = new C0915o<>();

    /* renamed from: R */
    C1284a f2418R;

    /* renamed from: Z */
    private final ArrayList<C0519c> f2419Z;

    /* renamed from: b */
    int f2420b = -1;

    /* renamed from: c */
    Bundle f2421c;

    /* renamed from: d */
    SparseArray<Parcelable> f2422d;

    /* renamed from: e */
    Bundle f2423e;

    /* renamed from: f */
    String f2424f = UUID.randomUUID().toString();

    /* renamed from: g */
    Bundle f2425g;

    /* renamed from: h */
    Fragment f2426h;

    /* renamed from: i */
    String f2427i = null;

    /* renamed from: j */
    int f2428j;

    /* renamed from: k */
    private Boolean f2429k = null;

    /* renamed from: l */
    boolean f2430l;

    /* renamed from: m */
    boolean f2431m;

    /* renamed from: n */
    boolean f2432n;

    /* renamed from: o */
    boolean f2433o;

    /* renamed from: p */
    boolean f2434p;

    /* renamed from: q */
    boolean f2435q;

    /* renamed from: r */
    int f2436r;

    /* renamed from: s */
    FragmentManager f2437s;

    /* renamed from: t */
    C0611u<?> f2438t;

    /* renamed from: u */
    FragmentManager f2439u = new C0616x();

    /* renamed from: v */
    Fragment f2440v;

    /* renamed from: w */
    int f2441w;

    /* renamed from: x */
    int f2442x;

    /* renamed from: y */
    String f2443y;

    /* renamed from: z */
    boolean f2444z;

    public static class InstantiationException extends RuntimeException {
        public InstantiationException(String str, Exception exc) {
            super(str, exc);
        }
    }

    public static class SavedState implements Parcelable {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0516a();

        /* renamed from: a */
        final Bundle f2446a;

        /* renamed from: androidx.fragment.app.Fragment$SavedState$a */
        class C0516a implements Parcelable.ClassLoaderCreator<SavedState> {
            C0516a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new SavedState[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }
        }

        SavedState(Parcel parcel, ClassLoader classLoader) {
            Bundle readBundle = parcel.readBundle();
            this.f2446a = readBundle;
            if (classLoader != null && readBundle != null) {
                readBundle.setClassLoader(classLoader);
            }
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeBundle(this.f2446a);
        }
    }

    /* renamed from: androidx.fragment.app.Fragment$a */
    class C0517a extends C0607r {
        C0517a() {
        }

        /* renamed from: b */
        public View mo2644b(int i) {
            View view = Fragment.this.f2406F;
            if (view != null) {
                return view.findViewById(i);
            }
            StringBuilder P = C4924a.m17863P("Fragment ");
            P.append(Fragment.this);
            P.append(" does not have a view");
            throw new IllegalStateException(P.toString());
        }

        /* renamed from: c */
        public boolean mo2645c() {
            return Fragment.this.f2406F != null;
        }
    }

    /* renamed from: androidx.fragment.app.Fragment$b */
    static class C0518b {

        /* renamed from: a */
        View f2448a;

        /* renamed from: b */
        Animator f2449b;

        /* renamed from: c */
        boolean f2450c;

        /* renamed from: d */
        int f2451d;

        /* renamed from: e */
        int f2452e;

        /* renamed from: f */
        int f2453f;

        /* renamed from: g */
        int f2454g;

        /* renamed from: h */
        int f2455h;

        /* renamed from: i */
        ArrayList<String> f2456i;

        /* renamed from: j */
        ArrayList<String> f2457j;

        /* renamed from: k */
        Object f2458k;

        /* renamed from: l */
        Object f2459l;

        /* renamed from: m */
        Object f2460m;

        /* renamed from: n */
        float f2461n = 1.0f;

        /* renamed from: o */
        View f2462o = null;

        /* renamed from: p */
        C0520d f2463p;

        /* renamed from: q */
        boolean f2464q;

        C0518b() {
            Object obj = Fragment.f2400a;
            this.f2458k = obj;
            this.f2459l = obj;
            this.f2460m = obj;
        }
    }

    /* renamed from: androidx.fragment.app.Fragment$c */
    private static abstract class C0519c {
        private C0519c() {
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public abstract void mo2646a();
    }

    /* renamed from: androidx.fragment.app.Fragment$d */
    interface C0520d {
    }

    public Fragment() {
        new AtomicInteger();
        this.f2419Z = new ArrayList<>();
        this.f2415O = new C0910k(this);
        this.f2418R = C1284a.m5335a(this);
    }

    /* renamed from: W2 */
    private C0518b m2339W2() {
        if (this.f2409I == null) {
            this.f2409I = new C0518b();
        }
        return this.f2409I;
    }

    /* renamed from: k3 */
    private int m2340k3() {
        C0903f.C0905b bVar = this.f2414N;
        return (bVar == C0903f.C0905b.INITIALIZED || this.f2440v == null) ? bVar.ordinal() : Math.min(bVar.ordinal(), this.f2440v.m2340k3());
    }

    /* access modifiers changed from: package-private */
    /* renamed from: A3 */
    public boolean mo2535A3() {
        C0518b bVar = this.f2409I;
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: A4 */
    public void mo2536A4(Bundle bundle) {
        Parcelable parcelable;
        if (bundle != null && (parcelable = bundle.getParcelable("android:support:fragments")) != null) {
            this.f2439u.mo2700K0(parcelable);
            this.f2439u.mo2748u();
        }
    }

    /* renamed from: B3 */
    public final boolean mo2537B3() {
        return this.f2431m;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: B4 */
    public void mo2538B4(View view) {
        m2339W2().f2448a = view;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: C3 */
    public final boolean mo2539C3() {
        Fragment fragment = this.f2440v;
        return fragment != null && (fragment.f2431m || fragment.mo2539C3());
    }

    /* access modifiers changed from: package-private */
    /* renamed from: C4 */
    public void mo2540C4(int i, int i2, int i3, int i4) {
        if (this.f2409I != null || i != 0 || i2 != 0 || i3 != 0 || i4 != 0) {
            m2339W2().f2451d = i;
            m2339W2().f2452e = i2;
            m2339W2().f2453f = i3;
            m2339W2().f2454g = i4;
        }
    }

    /* renamed from: D3 */
    public final boolean mo2541D3() {
        return this.f2420b >= 7;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: D4 */
    public void mo2542D4(Animator animator) {
        m2339W2().f2449b = animator;
    }

    /* renamed from: E3 */
    public final boolean mo2543E3() {
        FragmentManager fragmentManager = this.f2437s;
        if (fragmentManager == null) {
            return false;
        }
        return fragmentManager.mo2753w0();
    }

    /* renamed from: E4 */
    public void mo2544E4(Bundle bundle) {
        if (this.f2437s == null || !mo2543E3()) {
            this.f2425g = bundle;
            return;
        }
        throw new IllegalStateException("Fragment already added and state has been saved");
    }

    /* renamed from: F1 */
    public final SavedStateRegistry mo340F1() {
        return this.f2418R.mo5354b();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:4:0x000a, code lost:
        r0 = r1.f2406F;
     */
    /* renamed from: F3 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean mo2545F3() {
        /*
            r1 = this;
            boolean r0 = r1.mo2635y3()
            if (r0 == 0) goto L_0x001e
            boolean r0 = r1.f2444z
            if (r0 != 0) goto L_0x001e
            android.view.View r0 = r1.f2406F
            if (r0 == 0) goto L_0x001e
            android.os.IBinder r0 = r0.getWindowToken()
            if (r0 == 0) goto L_0x001e
            android.view.View r0 = r1.f2406F
            int r0 = r0.getVisibility()
            if (r0 != 0) goto L_0x001e
            r0 = 1
            goto L_0x001f
        L_0x001e:
            r0 = 0
        L_0x001f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.Fragment.mo2545F3():boolean");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: F4 */
    public void mo2546F4(View view) {
        m2339W2().f2462o = view;
    }

    /* renamed from: G */
    public C0903f mo341G() {
        return this.f2415O;
    }

    @Deprecated
    /* renamed from: G3 */
    public void mo2547G3(Bundle bundle) {
        this.f2404D = true;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: G4 */
    public void mo2548G4(boolean z) {
        m2339W2().f2464q = z;
    }

    @Deprecated
    /* renamed from: H3 */
    public void mo2549H3(int i, int i2, Intent intent) {
        if (FragmentManager.m2484s0(2)) {
            Log.v("FragmentManager", "Fragment " + this + " received the following in onActivityResult(): requestCode: " + i + " resultCode: " + i2 + " data: " + intent);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: H4 */
    public void mo2550H4(int i) {
        if (this.f2409I != null || i != 0) {
            m2339W2();
            this.f2409I.f2455h = i;
        }
    }

    @Deprecated
    /* renamed from: I3 */
    public void mo2551I3() {
        this.f2404D = true;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: I4 */
    public void mo2552I4(C0520d dVar) {
        m2339W2();
        C0520d dVar2 = this.f2409I.f2463p;
        if (dVar != dVar2) {
            if (dVar != null && dVar2 != null) {
                throw new IllegalStateException("Trying to set a replacement startPostponedEnterTransition on " + this);
            } else if (dVar != null) {
                ((FragmentManager.C0538o) dVar).mo2773c();
            }
        }
    }

    /* renamed from: J3 */
    public void mo2553J3(Context context) {
        this.f2404D = true;
        C0611u<?> uVar = this.f2438t;
        if ((uVar == null ? null : uVar.mo3012d()) != null) {
            this.f2404D = false;
            mo2551I3();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: J4 */
    public void mo2554J4(boolean z) {
        if (this.f2409I != null) {
            m2339W2().f2450c = z;
        }
    }

    @Deprecated
    /* renamed from: K3 */
    public void mo2555K3(Fragment fragment) {
    }

    /* access modifiers changed from: package-private */
    /* renamed from: K4 */
    public void mo2556K4(float f) {
        m2339W2().f2461n = f;
    }

    /* renamed from: L3 */
    public boolean mo2557L3() {
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: L4 */
    public void mo2558L4(ArrayList<String> arrayList, ArrayList<String> arrayList2) {
        m2339W2();
        C0518b bVar = this.f2409I;
        bVar.f2456i = arrayList;
        bVar.f2457j = arrayList2;
    }

    /* renamed from: M3 */
    public void mo2559M3(Bundle bundle) {
        Parcelable parcelable;
        boolean z = true;
        this.f2404D = true;
        if (!(bundle == null || (parcelable = bundle.getParcelable("android:support:fragments")) == null)) {
            this.f2439u.mo2700K0(parcelable);
            this.f2439u.mo2748u();
        }
        FragmentManager fragmentManager = this.f2439u;
        if (fragmentManager.f2502q < 1) {
            z = false;
        }
        if (!z) {
            fragmentManager.mo2748u();
        }
    }

    /* renamed from: M4 */
    public void mo2560M4(Intent intent, Bundle bundle) {
        C0611u<?> uVar = this.f2438t;
        if (uVar != null) {
            uVar.mo3015j(intent, -1, bundle);
            return;
        }
        throw new IllegalStateException(C4924a.m17906u("Fragment ", this, " not attached to Activity"));
    }

    /* renamed from: N3 */
    public Animation mo2561N3() {
        return null;
    }

    @Deprecated
    /* renamed from: N4 */
    public void mo2562N4(Intent intent, int i, Bundle bundle) {
        if (this.f2438t != null) {
            mo2606m3().mo2755x0(this, intent, i, bundle);
            return;
        }
        throw new IllegalStateException(C4924a.m17906u("Fragment ", this, " not attached to Activity"));
    }

    /* renamed from: O3 */
    public Animator mo2563O3() {
        return null;
    }

    /* renamed from: O4 */
    public void mo2564O4() {
        if (this.f2409I != null) {
            Objects.requireNonNull(m2339W2());
        }
    }

    /* renamed from: P3 */
    public View mo2565P3(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return null;
    }

    /* renamed from: Q3 */
    public void mo2566Q3() {
        this.f2404D = true;
    }

    /* renamed from: R3 */
    public void mo2567R3() {
        this.f2404D = true;
    }

    /* renamed from: S3 */
    public void mo2568S3() {
        this.f2404D = true;
    }

    /* renamed from: T3 */
    public LayoutInflater mo2569T3(Bundle bundle) {
        return mo2601j3();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: U2 */
    public C0607r mo2570U2() {
        return new C0517a();
    }

    /* renamed from: U3 */
    public void mo2571U3() {
    }

    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0136, code lost:
        r1 = r2.f2427i;
     */
    /* renamed from: V2 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2572V2(java.lang.String r3, java.io.FileDescriptor r4, java.io.PrintWriter r5, java.lang.String[] r6) {
        /*
            r2 = this;
            r5.print(r3)
            java.lang.String r0 = "mFragmentId=#"
            r5.print(r0)
            int r0 = r2.f2441w
            java.lang.String r0 = java.lang.Integer.toHexString(r0)
            r5.print(r0)
            java.lang.String r0 = " mContainerId=#"
            r5.print(r0)
            int r0 = r2.f2442x
            java.lang.String r0 = java.lang.Integer.toHexString(r0)
            r5.print(r0)
            java.lang.String r0 = " mTag="
            r5.print(r0)
            java.lang.String r0 = r2.f2443y
            r5.println(r0)
            r5.print(r3)
            java.lang.String r0 = "mState="
            r5.print(r0)
            int r0 = r2.f2420b
            r5.print(r0)
            java.lang.String r0 = " mWho="
            r5.print(r0)
            java.lang.String r0 = r2.f2424f
            r5.print(r0)
            java.lang.String r0 = " mBackStackNesting="
            r5.print(r0)
            int r0 = r2.f2436r
            r5.println(r0)
            r5.print(r3)
            java.lang.String r0 = "mAdded="
            r5.print(r0)
            boolean r0 = r2.f2430l
            r5.print(r0)
            java.lang.String r0 = " mRemoving="
            r5.print(r0)
            boolean r0 = r2.f2431m
            r5.print(r0)
            java.lang.String r0 = " mFromLayout="
            r5.print(r0)
            boolean r0 = r2.f2432n
            r5.print(r0)
            java.lang.String r0 = " mInLayout="
            r5.print(r0)
            boolean r0 = r2.f2433o
            r5.println(r0)
            r5.print(r3)
            java.lang.String r0 = "mHidden="
            r5.print(r0)
            boolean r0 = r2.f2444z
            r5.print(r0)
            java.lang.String r0 = " mDetached="
            r5.print(r0)
            boolean r0 = r2.f2401A
            r5.print(r0)
            java.lang.String r0 = " mMenuVisible="
            r5.print(r0)
            boolean r0 = r2.f2403C
            r5.print(r0)
            java.lang.String r0 = " mHasMenu="
            r5.print(r0)
            r0 = 0
            r5.println(r0)
            r5.print(r3)
            java.lang.String r0 = "mRetainInstance="
            r5.print(r0)
            boolean r0 = r2.f2402B
            r5.print(r0)
            java.lang.String r0 = " mUserVisibleHint="
            r5.print(r0)
            boolean r0 = r2.f2408H
            r5.println(r0)
            androidx.fragment.app.FragmentManager r0 = r2.f2437s
            if (r0 == 0) goto L_0x00c7
            r5.print(r3)
            java.lang.String r0 = "mFragmentManager="
            r5.print(r0)
            androidx.fragment.app.FragmentManager r0 = r2.f2437s
            r5.println(r0)
        L_0x00c7:
            androidx.fragment.app.u<?> r0 = r2.f2438t
            if (r0 == 0) goto L_0x00d8
            r5.print(r3)
            java.lang.String r0 = "mHost="
            r5.print(r0)
            androidx.fragment.app.u<?> r0 = r2.f2438t
            r5.println(r0)
        L_0x00d8:
            androidx.fragment.app.Fragment r0 = r2.f2440v
            if (r0 == 0) goto L_0x00e9
            r5.print(r3)
            java.lang.String r0 = "mParentFragment="
            r5.print(r0)
            androidx.fragment.app.Fragment r0 = r2.f2440v
            r5.println(r0)
        L_0x00e9:
            android.os.Bundle r0 = r2.f2425g
            if (r0 == 0) goto L_0x00fa
            r5.print(r3)
            java.lang.String r0 = "mArguments="
            r5.print(r0)
            android.os.Bundle r0 = r2.f2425g
            r5.println(r0)
        L_0x00fa:
            android.os.Bundle r0 = r2.f2421c
            if (r0 == 0) goto L_0x010b
            r5.print(r3)
            java.lang.String r0 = "mSavedFragmentState="
            r5.print(r0)
            android.os.Bundle r0 = r2.f2421c
            r5.println(r0)
        L_0x010b:
            android.util.SparseArray<android.os.Parcelable> r0 = r2.f2422d
            if (r0 == 0) goto L_0x011c
            r5.print(r3)
            java.lang.String r0 = "mSavedViewState="
            r5.print(r0)
            android.util.SparseArray<android.os.Parcelable> r0 = r2.f2422d
            r5.println(r0)
        L_0x011c:
            android.os.Bundle r0 = r2.f2423e
            if (r0 == 0) goto L_0x012d
            r5.print(r3)
            java.lang.String r0 = "mSavedViewRegistryState="
            r5.print(r0)
            android.os.Bundle r0 = r2.f2423e
            r5.println(r0)
        L_0x012d:
            androidx.fragment.app.Fragment r0 = r2.f2426h
            if (r0 == 0) goto L_0x0132
            goto L_0x0140
        L_0x0132:
            androidx.fragment.app.FragmentManager r0 = r2.f2437s
            if (r0 == 0) goto L_0x013f
            java.lang.String r1 = r2.f2427i
            if (r1 == 0) goto L_0x013f
            androidx.fragment.app.Fragment r0 = r0.mo2713W(r1)
            goto L_0x0140
        L_0x013f:
            r0 = 0
        L_0x0140:
            if (r0 == 0) goto L_0x0157
            r5.print(r3)
            java.lang.String r1 = "mTarget="
            r5.print(r1)
            r5.print(r0)
            java.lang.String r0 = " mTargetRequestCode="
            r5.print(r0)
            int r0 = r2.f2428j
            r5.println(r0)
        L_0x0157:
            r5.print(r3)
            java.lang.String r0 = "mPopDirection="
            r5.print(r0)
            boolean r0 = r2.mo2608n3()
            r5.println(r0)
            int r0 = r2.mo2585c3()
            if (r0 == 0) goto L_0x017b
            r5.print(r3)
            java.lang.String r0 = "getEnterAnim="
            r5.print(r0)
            int r0 = r2.mo2585c3()
            r5.println(r0)
        L_0x017b:
            int r0 = r2.mo2592f3()
            if (r0 == 0) goto L_0x0190
            r5.print(r3)
            java.lang.String r0 = "getExitAnim="
            r5.print(r0)
            int r0 = r2.mo2592f3()
            r5.println(r0)
        L_0x0190:
            int r0 = r2.mo2610o3()
            if (r0 == 0) goto L_0x01a5
            r5.print(r3)
            java.lang.String r0 = "getPopEnterAnim="
            r5.print(r0)
            int r0 = r2.mo2610o3()
            r5.println(r0)
        L_0x01a5:
            int r0 = r2.mo2615p3()
            if (r0 == 0) goto L_0x01ba
            r5.print(r3)
            java.lang.String r0 = "getPopExitAnim="
            r5.print(r0)
            int r0 = r2.mo2615p3()
            r5.println(r0)
        L_0x01ba:
            android.view.ViewGroup r0 = r2.f2405E
            if (r0 == 0) goto L_0x01cb
            r5.print(r3)
            java.lang.String r0 = "mContainer="
            r5.print(r0)
            android.view.ViewGroup r0 = r2.f2405E
            r5.println(r0)
        L_0x01cb:
            android.view.View r0 = r2.f2406F
            if (r0 == 0) goto L_0x01dc
            r5.print(r3)
            java.lang.String r0 = "mView="
            r5.print(r0)
            android.view.View r0 = r2.f2406F
            r5.println(r0)
        L_0x01dc:
            android.view.View r0 = r2.mo2577Y2()
            if (r0 == 0) goto L_0x01f1
            r5.print(r3)
            java.lang.String r0 = "mAnimatingAway="
            r5.print(r0)
            android.view.View r0 = r2.mo2577Y2()
            r5.println(r0)
        L_0x01f1:
            android.content.Context r0 = r2.mo2583b3()
            if (r0 == 0) goto L_0x01fe
            d.m.a.a r0 = p098d.p146m.p147a.C4848a.m17697b(r2)
            r0.mo22129a(r3, r4, r5, r6)
        L_0x01fe:
            r5.print(r3)
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = "Child "
            r0.append(r1)
            androidx.fragment.app.FragmentManager r1 = r2.f2439u
            r0.append(r1)
            java.lang.String r1 = ":"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r5.println(r0)
            androidx.fragment.app.FragmentManager r0 = r2.f2439u
            java.lang.String r1 = "  "
            java.lang.String r3 = p165e.p166a.p167a.p168a.C4924a.m17907v(r3, r1)
            r0.mo2706O(r3, r4, r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.Fragment.mo2572V2(java.lang.String, java.io.FileDescriptor, java.io.PrintWriter, java.lang.String[]):void");
    }

    @Deprecated
    /* renamed from: V3 */
    public void mo2573V3() {
        this.f2404D = true;
    }

    /* renamed from: W3 */
    public void mo2574W3(AttributeSet attributeSet, Bundle bundle) {
        this.f2404D = true;
        C0611u<?> uVar = this.f2438t;
        if ((uVar == null ? null : uVar.mo3012d()) != null) {
            this.f2404D = false;
            mo2573V3();
        }
    }

    /* renamed from: X2 */
    public final FragmentActivity mo2575X2() {
        C0611u<?> uVar = this.f2438t;
        if (uVar == null) {
            return null;
        }
        return (FragmentActivity) uVar.mo3012d();
    }

    /* renamed from: X3 */
    public void mo2576X3() {
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Y2 */
    public View mo2577Y2() {
        C0518b bVar = this.f2409I;
        if (bVar == null) {
            return null;
        }
        return bVar.f2448a;
    }

    /* renamed from: Y3 */
    public void mo2578Y3() {
        this.f2404D = true;
    }

    /* renamed from: Z2 */
    public final Bundle mo2579Z2() {
        return this.f2425g;
    }

    /* renamed from: Z3 */
    public void mo2580Z3() {
    }

    /* renamed from: a3 */
    public final FragmentManager mo2581a3() {
        if (this.f2438t != null) {
            return this.f2439u;
        }
        throw new IllegalStateException(C4924a.m17906u("Fragment ", this, " has not been attached yet."));
    }

    /* renamed from: a4 */
    public void mo2582a4() {
    }

    /* renamed from: b3 */
    public Context mo2583b3() {
        C0611u<?> uVar = this.f2438t;
        if (uVar == null) {
            return null;
        }
        return uVar.mo3013e();
    }

    @Deprecated
    /* renamed from: b4 */
    public void mo2584b4() {
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c3 */
    public int mo2585c3() {
        C0518b bVar = this.f2409I;
        if (bVar == null) {
            return 0;
        }
        return bVar.f2451d;
    }

    /* renamed from: c4 */
    public void mo2586c4() {
        this.f2404D = true;
    }

    /* renamed from: d3 */
    public Object mo2587d3() {
        C0518b bVar = this.f2409I;
        if (bVar == null) {
            return null;
        }
        Objects.requireNonNull(bVar);
        return null;
    }

    /* renamed from: d4 */
    public void mo2588d4(Bundle bundle) {
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e3 */
    public void mo2589e3() {
        C0518b bVar = this.f2409I;
        if (bVar != null) {
            Objects.requireNonNull(bVar);
        }
    }

    /* renamed from: e4 */
    public void mo2590e4() {
        this.f2404D = true;
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f3 */
    public int mo2592f3() {
        C0518b bVar = this.f2409I;
        if (bVar == null) {
            return 0;
        }
        return bVar.f2452e;
    }

    /* renamed from: f4 */
    public void mo2593f4() {
        this.f2404D = true;
    }

    /* renamed from: g3 */
    public Object mo2594g3() {
        C0518b bVar = this.f2409I;
        if (bVar == null) {
            return null;
        }
        Objects.requireNonNull(bVar);
        return null;
    }

    /* renamed from: g4 */
    public void mo2595g4(View view, Bundle bundle) {
    }

    /* renamed from: h1 */
    public C0925u mo345h1() {
        if (this.f2437s == null) {
            throw new IllegalStateException("Can't access ViewModels from detached fragment");
        } else if (m2340k3() != 1) {
            return this.f2437s.mo2737n0(this);
        } else {
            throw new IllegalStateException("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h3 */
    public void mo2596h3() {
        C0518b bVar = this.f2409I;
        if (bVar != null) {
            Objects.requireNonNull(bVar);
        }
    }

    /* renamed from: h4 */
    public void mo2597h4(Bundle bundle) {
        this.f2404D = true;
    }

    public final int hashCode() {
        return super.hashCode();
    }

    @Deprecated
    /* renamed from: i3 */
    public final FragmentManager mo2599i3() {
        return this.f2437s;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i4 */
    public void mo2600i4(Bundle bundle) {
        this.f2439u.mo2684A0();
        this.f2420b = 3;
        this.f2404D = false;
        mo2547G3(bundle);
        if (this.f2404D) {
            if (FragmentManager.m2484s0(3)) {
                Log.d("FragmentManager", "moveto RESTORE_VIEW_STATE: " + this);
            }
            View view = this.f2406F;
            if (view != null) {
                Bundle bundle2 = this.f2421c;
                SparseArray<Parcelable> sparseArray = this.f2422d;
                if (sparseArray != null) {
                    view.restoreHierarchyState(sparseArray);
                    this.f2422d = null;
                }
                if (this.f2406F != null) {
                    this.f2416P.mo2954d(this.f2423e);
                    this.f2423e = null;
                }
                this.f2404D = false;
                mo2597h4(bundle2);
                if (!this.f2404D) {
                    throw new SuperNotCalledException(C4924a.m17906u("Fragment ", this, " did not call through to super.onViewStateRestored()"));
                } else if (this.f2406F != null) {
                    this.f2416P.mo2951a(C0903f.C0904a.ON_CREATE);
                }
            }
            this.f2421c = null;
            this.f2439u.mo2741q();
            return;
        }
        throw new SuperNotCalledException(C4924a.m17906u("Fragment ", this, " did not call through to super.onActivityCreated()"));
    }

    @Deprecated
    /* renamed from: j3 */
    public LayoutInflater mo2601j3() {
        C0611u<?> uVar = this.f2438t;
        if (uVar != null) {
            LayoutInflater h = uVar.mo2664h();
            h.setFactory2(this.f2439u.mo2731j0());
            return h;
        }
        throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j4 */
    public void mo2602j4() {
        Iterator<C0519c> it = this.f2419Z.iterator();
        while (it.hasNext()) {
            it.next().mo2646a();
        }
        this.f2419Z.clear();
        this.f2439u.mo2725g(this.f2438t, mo2570U2(), this);
        this.f2420b = 0;
        this.f2404D = false;
        mo2553J3(this.f2438t.mo3013e());
        if (this.f2404D) {
            this.f2437s.mo2683A(this);
            this.f2439u.mo2743r();
            return;
        }
        throw new SuperNotCalledException(C4924a.m17906u("Fragment ", this, " did not call through to super.onAttach()"));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k4 */
    public void mo2603k4(Bundle bundle) {
        this.f2439u.mo2684A0();
        this.f2420b = 1;
        this.f2404D = false;
        this.f2415O.mo3940a(new C0907h() {
            /* renamed from: c */
            public void mo360c(C0909j jVar, C0903f.C0904a aVar) {
                View view;
                if (aVar == C0903f.C0904a.ON_STOP && (view = Fragment.this.f2406F) != null) {
                    view.cancelPendingInputEvents();
                }
            }
        });
        this.f2418R.mo5355c(bundle);
        mo2559M3(bundle);
        this.f2413M = true;
        if (this.f2404D) {
            this.f2415O.mo3944f(C0903f.C0904a.ON_CREATE);
            return;
        }
        throw new SuperNotCalledException(C4924a.m17906u("Fragment ", this, " did not call through to super.onCreate()"));
    }

    /* renamed from: l3 */
    public final Fragment mo2604l3() {
        return this.f2440v;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l4 */
    public void mo2605l4(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f2439u.mo2684A0();
        this.f2435q = true;
        this.f2416P = new C0593o0();
        View P3 = mo2565P3(layoutInflater, viewGroup, bundle);
        this.f2406F = P3;
        if (P3 != null) {
            this.f2416P.mo2952b();
            this.f2406F.setTag(R.id.view_tree_lifecycle_owner, this.f2416P);
            this.f2406F.setTag(R.id.view_tree_view_model_store_owner, this);
            this.f2406F.setTag(R.id.view_tree_saved_state_registry_owner, this.f2416P);
            this.f2417Q.mo3923i(this.f2416P);
        } else if (!this.f2416P.mo2953c()) {
            this.f2416P = null;
        } else {
            throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
        }
    }

    /* renamed from: m3 */
    public final FragmentManager mo2606m3() {
        FragmentManager fragmentManager = this.f2437s;
        if (fragmentManager != null) {
            return fragmentManager;
        }
        throw new IllegalStateException(C4924a.m17906u("Fragment ", this, " not associated with a fragment manager."));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: m4 */
    public void mo2607m4() {
        this.f2439u.mo2752w();
        this.f2415O.mo3944f(C0903f.C0904a.ON_DESTROY);
        this.f2420b = 0;
        this.f2404D = false;
        this.f2413M = false;
        mo2566Q3();
        if (!this.f2404D) {
            throw new SuperNotCalledException(C4924a.m17906u("Fragment ", this, " did not call through to super.onDestroy()"));
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n3 */
    public boolean mo2608n3() {
        C0518b bVar = this.f2409I;
        if (bVar == null) {
            return false;
        }
        return bVar.f2450c;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n4 */
    public void mo2609n4() {
        this.f2439u.mo2754x();
        if (this.f2406F != null) {
            if (this.f2416P.mo341G().mo3941b().compareTo(C0903f.C0905b.CREATED) >= 0) {
                this.f2416P.mo2951a(C0903f.C0904a.ON_DESTROY);
            }
        }
        this.f2420b = 1;
        this.f2404D = false;
        mo2567R3();
        if (this.f2404D) {
            C4848a.m17697b(this).mo22130c();
            this.f2435q = false;
            return;
        }
        throw new SuperNotCalledException(C4924a.m17906u("Fragment ", this, " did not call through to super.onDestroyView()"));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: o3 */
    public int mo2610o3() {
        C0518b bVar = this.f2409I;
        if (bVar == null) {
            return 0;
        }
        return bVar.f2453f;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: o4 */
    public void mo2611o4() {
        this.f2420b = -1;
        this.f2404D = false;
        mo2568S3();
        this.f2412L = null;
        if (!this.f2404D) {
            throw new SuperNotCalledException(C4924a.m17906u("Fragment ", this, " did not call through to super.onDetach()"));
        } else if (!this.f2439u.mo2744r0()) {
            this.f2439u.mo2752w();
            this.f2439u = new C0616x();
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        this.f2404D = true;
    }

    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        mo2632w4().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    public void onLowMemory() {
        this.f2404D = true;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p3 */
    public int mo2615p3() {
        C0518b bVar = this.f2409I;
        if (bVar == null) {
            return 0;
        }
        return bVar.f2454g;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p4 */
    public void mo2616p4() {
        onLowMemory();
        this.f2439u.mo2756y();
    }

    /* renamed from: q3 */
    public Object mo2617q3() {
        C0518b bVar = this.f2409I;
        if (bVar == null) {
            return null;
        }
        Object obj = bVar.f2459l;
        if (obj != f2400a) {
            return obj;
        }
        mo2594g3();
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q4 */
    public void mo2618q4() {
        this.f2439u.mo2690E();
        if (this.f2406F != null) {
            this.f2416P.mo2951a(C0903f.C0904a.ON_PAUSE);
        }
        this.f2415O.mo3944f(C0903f.C0904a.ON_PAUSE);
        this.f2420b = 6;
        this.f2404D = false;
        mo2578Y3();
        if (!this.f2404D) {
            throw new SuperNotCalledException(C4924a.m17906u("Fragment ", this, " did not call through to super.onPause()"));
        }
    }

    /* renamed from: r3 */
    public final Resources mo2619r3() {
        return mo2636y4().getResources();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: r4 */
    public boolean mo2620r4(Menu menu) {
        if (!this.f2444z) {
            return false | this.f2439u.mo2693G(menu);
        }
        return false;
    }

    /* renamed from: s3 */
    public Object mo2621s3() {
        C0518b bVar = this.f2409I;
        if (bVar == null) {
            return null;
        }
        Object obj = bVar.f2458k;
        if (obj != f2400a) {
            return obj;
        }
        mo2587d3();
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: s4 */
    public void mo2622s4() {
        boolean v0 = this.f2437s.mo2751v0(this);
        Boolean bool = this.f2429k;
        if (bool == null || bool.booleanValue() != v0) {
            this.f2429k = Boolean.valueOf(v0);
            mo2582a4();
            this.f2439u.mo2695H();
        }
    }

    @Deprecated
    public void startActivityForResult(Intent intent, int i) {
        mo2562N4(intent, i, (Bundle) null);
    }

    /* renamed from: t3 */
    public Object mo2624t3() {
        C0518b bVar = this.f2409I;
        if (bVar == null) {
            return null;
        }
        Objects.requireNonNull(bVar);
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: t4 */
    public void mo2625t4() {
        this.f2439u.mo2684A0();
        this.f2439u.mo2711S(true);
        this.f2420b = 7;
        this.f2404D = false;
        mo2586c4();
        if (this.f2404D) {
            C0910k kVar = this.f2415O;
            C0903f.C0904a aVar = C0903f.C0904a.ON_RESUME;
            kVar.mo3944f(aVar);
            if (this.f2406F != null) {
                this.f2416P.mo2951a(aVar);
            }
            this.f2439u.mo2697I();
            return;
        }
        throw new SuperNotCalledException(C4924a.m17906u("Fragment ", this, " did not call through to super.onResume()"));
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append(getClass().getSimpleName());
        sb.append("{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("}");
        sb.append(" (");
        sb.append(this.f2424f);
        if (this.f2441w != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f2441w));
        }
        if (this.f2443y != null) {
            sb.append(" tag=");
            sb.append(this.f2443y);
        }
        sb.append(")");
        return sb.toString();
    }

    /* renamed from: u3 */
    public Object mo2627u3() {
        C0518b bVar = this.f2409I;
        if (bVar == null) {
            return null;
        }
        Object obj = bVar.f2460m;
        if (obj != f2400a) {
            return obj;
        }
        mo2624t3();
        return null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: u4 */
    public void mo2628u4() {
        this.f2439u.mo2684A0();
        this.f2439u.mo2711S(true);
        this.f2420b = 5;
        this.f2404D = false;
        mo2590e4();
        if (this.f2404D) {
            C0910k kVar = this.f2415O;
            C0903f.C0904a aVar = C0903f.C0904a.ON_START;
            kVar.mo3944f(aVar);
            if (this.f2406F != null) {
                this.f2416P.mo2951a(aVar);
            }
            this.f2439u.mo2699J();
            return;
        }
        throw new SuperNotCalledException(C4924a.m17906u("Fragment ", this, " did not call through to super.onStart()"));
    }

    /* renamed from: v3 */
    public final String mo2629v3(int i) {
        return mo2619r3().getString(i);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: v4 */
    public void mo2630v4() {
        this.f2439u.mo2701L();
        if (this.f2406F != null) {
            this.f2416P.mo2951a(C0903f.C0904a.ON_STOP);
        }
        this.f2415O.mo3944f(C0903f.C0904a.ON_STOP);
        this.f2420b = 4;
        this.f2404D = false;
        mo2593f4();
        if (!this.f2404D) {
            throw new SuperNotCalledException(C4924a.m17906u("Fragment ", this, " did not call through to super.onStop()"));
        }
    }

    /* renamed from: w3 */
    public final String mo2631w3(int i, Object... objArr) {
        return mo2619r3().getString(i, objArr);
    }

    /* renamed from: w4 */
    public final FragmentActivity mo2632w4() {
        FragmentActivity X2 = mo2575X2();
        if (X2 != null) {
            return X2;
        }
        throw new IllegalStateException(C4924a.m17906u("Fragment ", this, " not attached to an activity."));
    }

    /* renamed from: x3 */
    public View mo2633x3() {
        return this.f2406F;
    }

    /* renamed from: x4 */
    public final Bundle mo2634x4() {
        Bundle bundle = this.f2425g;
        if (bundle != null) {
            return bundle;
        }
        throw new IllegalStateException(C4924a.m17906u("Fragment ", this, " does not have any arguments."));
    }

    /* renamed from: y3 */
    public final boolean mo2635y3() {
        return this.f2438t != null && this.f2430l;
    }

    /* renamed from: y4 */
    public final Context mo2636y4() {
        Context b3 = mo2583b3();
        if (b3 != null) {
            return b3;
        }
        throw new IllegalStateException(C4924a.m17906u("Fragment ", this, " not attached to a context."));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: z3 */
    public final boolean mo2637z3() {
        return this.f2436r > 0;
    }

    /* renamed from: z4 */
    public final View mo2638z4() {
        View view = this.f2406F;
        if (view != null) {
            return view;
        }
        throw new IllegalStateException(C4924a.m17906u("Fragment ", this, " did not return a View from onCreateView() or this was called before onCreateView()."));
    }
}
