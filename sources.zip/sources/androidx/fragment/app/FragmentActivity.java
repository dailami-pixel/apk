package androidx.fragment.app;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.C0087c;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.C0100c;
import androidx.core.app.C0441a;
import androidx.lifecycle.C0903f;
import androidx.lifecycle.C0910k;
import androidx.lifecycle.C0925u;
import androidx.lifecycle.C0926v;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import p098d.p146m.p147a.C4848a;

public class FragmentActivity extends ComponentActivity implements C0441a.C0443b, C0441a.C0444c {

    /* renamed from: h */
    final C0609s f2465h = C0609s.m2797b(new C0521a());

    /* renamed from: i */
    final C0910k f2466i = new C0910k(this);

    /* renamed from: j */
    boolean f2467j;

    /* renamed from: k */
    boolean f2468k;

    /* renamed from: l */
    boolean f2469l = true;

    /* renamed from: androidx.fragment.app.FragmentActivity$a */
    class C0521a extends C0611u<FragmentActivity> implements C0926v, C0087c, C0100c, C0619z {
        public C0521a() {
            super(FragmentActivity.this);
        }

        /* renamed from: G */
        public C0903f mo341G() {
            return FragmentActivity.this.f2466i;
        }

        /* renamed from: J */
        public ActivityResultRegistry mo342J() {
            return FragmentActivity.this.mo342J();
        }

        /* renamed from: O */
        public OnBackPressedDispatcher mo343O() {
            return FragmentActivity.this.mo343O();
        }

        /* renamed from: a */
        public void mo2662a(FragmentManager fragmentManager, Fragment fragment) {
            FragmentActivity.this.mo2649H0(fragment);
        }

        /* renamed from: b */
        public View mo2644b(int i) {
            return FragmentActivity.this.findViewById(i);
        }

        /* renamed from: c */
        public boolean mo2645c() {
            Window window = FragmentActivity.this.getWindow();
            return (window == null || window.peekDecorView() == null) ? false : true;
        }

        /* renamed from: g */
        public Object mo2663g() {
            return FragmentActivity.this;
        }

        /* renamed from: h */
        public LayoutInflater mo2664h() {
            return FragmentActivity.this.getLayoutInflater().cloneInContext(FragmentActivity.this);
        }

        /* renamed from: h1 */
        public C0925u mo345h1() {
            return FragmentActivity.this.mo345h1();
        }

        /* renamed from: i */
        public boolean mo2665i(Fragment fragment) {
            return !FragmentActivity.this.isFinishing();
        }

        /* renamed from: k */
        public void mo2666k() {
            FragmentActivity.this.mo427I0();
        }
    }

    public FragmentActivity() {
        mo340F1().mo5352d("android:support:fragments", new C0584l(this));
        mo338B0(new C0587m(this));
    }

    /* renamed from: G0 */
    private static boolean m2445G0(FragmentManager fragmentManager, C0903f.C0905b bVar) {
        C0903f.C0905b bVar2 = C0903f.C0905b.STARTED;
        boolean z = false;
        for (Fragment next : fragmentManager.mo2728h0()) {
            if (next != null) {
                C0611u<?> uVar = next.f2438t;
                if ((uVar == null ? null : uVar.mo2663g()) != null) {
                    z |= m2445G0(next.mo2581a3(), bVar);
                }
                C0593o0 o0Var = next.f2416P;
                if (o0Var != null) {
                    if (o0Var.mo341G().mo3941b().compareTo(bVar2) >= 0) {
                        next.f2416P.mo2956f(bVar);
                        z = true;
                    }
                }
                if (next.f2415O.mo3941b().compareTo(bVar2) >= 0) {
                    next.f2415O.mo3946k(bVar);
                    z = true;
                }
            }
        }
        return z;
    }

    /* renamed from: E0 */
    public FragmentManager mo2647E0() {
        return this.f2465h.mo3007t();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: F0 */
    public void mo2648F0() {
        do {
        } while (m2445G0(mo2647E0(), C0903f.C0905b.CREATED));
    }

    @Deprecated
    /* renamed from: H0 */
    public void mo2649H0(Fragment fragment) {
    }

    @Deprecated
    /* renamed from: I0 */
    public void mo427I0() {
        invalidateOptionsMenu();
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str2 = str + "  ";
        printWriter.print(str2);
        printWriter.print("mCreated=");
        printWriter.print(this.f2467j);
        printWriter.print(" mResumed=");
        printWriter.print(this.f2468k);
        printWriter.print(" mStopped=");
        printWriter.print(this.f2469l);
        if (getApplication() != null) {
            C4848a.m17697b(this).mo22129a(str2, fileDescriptor, printWriter, strArr);
        }
        this.f2465h.mo3007t().mo2706O(str, fileDescriptor, printWriter, strArr);
    }

    @Deprecated
    /* renamed from: m */
    public final void mo2219m(int i) {
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        this.f2465h.mo3008u();
        super.onActivityResult(i, i2, intent);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f2465h.mo3008u();
        this.f2465h.mo2991d(configuration);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f2466i.mo3944f(C0903f.C0904a.ON_CREATE);
        this.f2465h.mo2993f();
    }

    public boolean onCreatePanelMenu(int i, Menu menu) {
        return i == 0 ? super.onCreatePanelMenu(i, menu) | this.f2465h.mo2994g(menu, getMenuInflater()) : super.onCreatePanelMenu(i, menu);
    }

    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View v = this.f2465h.mo3009v(view, str, context, attributeSet);
        return v == null ? super.onCreateView(view, str, context, attributeSet) : v;
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        this.f2465h.mo2995h();
        this.f2466i.mo3944f(C0903f.C0904a.ON_DESTROY);
    }

    public void onLowMemory() {
        super.onLowMemory();
        this.f2465h.mo2996i();
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 0) {
            return this.f2465h.mo2998k(menuItem);
        }
        if (i != 6) {
            return false;
        }
        return this.f2465h.mo2992e(menuItem);
    }

    public void onMultiWindowModeChanged(boolean z) {
        this.f2465h.mo2997j(z);
    }

    /* access modifiers changed from: protected */
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.f2465h.mo3008u();
    }

    public void onPanelClosed(int i, Menu menu) {
        if (i == 0) {
            this.f2465h.mo2999l(menu);
        }
        super.onPanelClosed(i, menu);
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
        this.f2468k = false;
        this.f2465h.mo3000m();
        this.f2466i.mo3944f(C0903f.C0904a.ON_PAUSE);
    }

    public void onPictureInPictureModeChanged(boolean z) {
        this.f2465h.mo3001n(z);
    }

    /* access modifiers changed from: protected */
    public void onPostResume() {
        super.onPostResume();
        this.f2466i.mo3944f(C0903f.C0904a.ON_RESUME);
        this.f2465h.mo3003p();
    }

    public boolean onPreparePanel(int i, View view, Menu menu) {
        return i == 0 ? super.onPreparePanel(0, view, menu) | this.f2465h.mo3002o(menu) : super.onPreparePanel(i, view, menu);
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        this.f2465h.mo3008u();
        super.onRequestPermissionsResult(i, strArr, iArr);
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        this.f2468k = true;
        this.f2465h.mo3008u();
        this.f2465h.mo3006s();
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        this.f2469l = false;
        if (!this.f2467j) {
            this.f2467j = true;
            this.f2465h.mo2990c();
        }
        this.f2465h.mo3008u();
        this.f2465h.mo3006s();
        this.f2466i.mo3944f(C0903f.C0904a.ON_START);
        this.f2465h.mo3004q();
    }

    public void onStateNotSaved() {
        this.f2465h.mo3008u();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        this.f2469l = true;
        do {
        } while (m2445G0(mo2647E0(), C0903f.C0905b.CREATED));
        this.f2465h.mo3005r();
        this.f2466i.mo3944f(C0903f.C0904a.ON_STOP);
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View v = this.f2465h.mo3009v((View) null, str, context, attributeSet);
        return v == null ? super.onCreateView(str, context, attributeSet) : v;
    }
}
