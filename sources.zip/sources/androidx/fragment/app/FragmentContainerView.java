package androidx.fragment.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import com.appsflyer.oaid.BuildConfig;
import com.vidio.android.p195tv.R;
import java.util.ArrayList;
import p098d.p136j.C4819a;
import p165e.p166a.p167a.p168a.C4924a;

public final class FragmentContainerView extends FrameLayout {

    /* renamed from: a */
    private ArrayList<View> f2471a;

    /* renamed from: b */
    private ArrayList<View> f2472b;

    /* renamed from: c */
    private boolean f2473c;

    public FragmentContainerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public FragmentContainerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        String str;
        this.f2473c = true;
        if (attributeSet != null) {
            String classAttribute = attributeSet.getClassAttribute();
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4819a.f17402b);
            if (classAttribute == null) {
                classAttribute = obtainStyledAttributes.getString(0);
                str = "android:name";
            } else {
                str = "class";
            }
            obtainStyledAttributes.recycle();
            if (classAttribute != null && !isInEditMode()) {
                throw new UnsupportedOperationException("FragmentContainerView must be within a FragmentActivity to use " + str + "=\"" + classAttribute + "\"");
            }
        }
    }

    FragmentContainerView(Context context, AttributeSet attributeSet, FragmentManager fragmentManager) {
        super(context, attributeSet);
        this.f2473c = true;
        String classAttribute = attributeSet.getClassAttribute();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4819a.f17402b);
        classAttribute = classAttribute == null ? obtainStyledAttributes.getString(0) : classAttribute;
        String string = obtainStyledAttributes.getString(1);
        obtainStyledAttributes.recycle();
        int id = getId();
        Fragment X = fragmentManager.mo2714X(id);
        if (classAttribute != null && X == null) {
            if (id <= 0) {
                throw new IllegalStateException(C4924a.m17909x("FragmentContainerView must have an android:id to add Fragment ", classAttribute, string != null ? C4924a.m17907v(" with tag ", string) : BuildConfig.FLAVOR));
            }
            Fragment a = fragmentManager.mo2724f0().mo2765a(context.getClassLoader(), classAttribute);
            a.mo2574W3(attributeSet, (Bundle) null);
            C0543a aVar = new C0543a(fragmentManager);
            aVar.f2597p = true;
            a.f2405E = this;
            aVar.mo2797i(getId(), a, string, 1);
            aVar.mo2872h();
            aVar.f2554q.mo2712T(aVar, true);
        }
        fragmentManager.mo2686B0(this);
    }

    /* renamed from: a */
    private void m2462a(View view) {
        ArrayList<View> arrayList = this.f2472b;
        if (arrayList != null && arrayList.contains(view)) {
            if (this.f2471a == null) {
                this.f2471a = new ArrayList<>();
            }
            this.f2471a.add(view);
        }
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        Object tag = view.getTag(R.id.fragment_container_view_tag);
        if ((tag instanceof Fragment ? (Fragment) tag : null) != null) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException("Views added to a FragmentContainerView must be associated with a Fragment. View " + view + " is not associated with a Fragment.");
    }

    /* access modifiers changed from: protected */
    public boolean addViewInLayout(View view, int i, ViewGroup.LayoutParams layoutParams, boolean z) {
        Object tag = view.getTag(R.id.fragment_container_view_tag);
        if ((tag instanceof Fragment ? (Fragment) tag : null) != null) {
            return super.addViewInLayout(view, i, layoutParams, z);
        }
        throw new IllegalStateException("Views added to a FragmentContainerView must be associated with a Fragment. View " + view + " is not associated with a Fragment.");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo2669b(boolean z) {
        this.f2473c = z;
    }

    /* access modifiers changed from: protected */
    public void dispatchDraw(Canvas canvas) {
        if (this.f2473c && this.f2471a != null) {
            for (int i = 0; i < this.f2471a.size(); i++) {
                super.drawChild(canvas, this.f2471a.get(i), getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    /* access modifiers changed from: protected */
    public boolean drawChild(Canvas canvas, View view, long j) {
        ArrayList<View> arrayList;
        if (!this.f2473c || (arrayList = this.f2471a) == null || arrayList.size() <= 0 || !this.f2471a.contains(view)) {
            return super.drawChild(canvas, view, j);
        }
        return false;
    }

    public void endViewTransition(View view) {
        ArrayList<View> arrayList = this.f2472b;
        if (arrayList != null) {
            arrayList.remove(view);
            ArrayList<View> arrayList2 = this.f2471a;
            if (arrayList2 != null && arrayList2.remove(view)) {
                this.f2473c = true;
            }
        }
        super.endViewTransition(view);
    }

    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        for (int i = 0; i < getChildCount(); i++) {
            getChildAt(i).dispatchApplyWindowInsets(new WindowInsets(windowInsets));
        }
        return windowInsets;
    }

    public void removeAllViewsInLayout() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            m2462a(getChildAt(childCount));
        }
        super.removeAllViewsInLayout();
    }

    /* access modifiers changed from: protected */
    public void removeDetachedView(View view, boolean z) {
        if (z) {
            m2462a(view);
        }
        super.removeDetachedView(view, z);
    }

    public void removeView(View view) {
        m2462a(view);
        super.removeView(view);
    }

    public void removeViewAt(int i) {
        m2462a(getChildAt(i));
        super.removeViewAt(i);
    }

    public void removeViewInLayout(View view) {
        m2462a(view);
        super.removeViewInLayout(view);
    }

    public void removeViews(int i, int i2) {
        for (int i3 = i; i3 < i + i2; i3++) {
            m2462a(getChildAt(i3));
        }
        super.removeViews(i, i2);
    }

    public void removeViewsInLayout(int i, int i2) {
        for (int i3 = i; i3 < i + i2; i3++) {
            m2462a(getChildAt(i3));
        }
        super.removeViewsInLayout(i, i2);
    }

    public void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    public void startViewTransition(View view) {
        if (view.getParent() == this) {
            if (this.f2472b == null) {
                this.f2472b = new ArrayList<>();
            }
            this.f2472b.add(view);
        }
        super.startViewTransition(view);
    }
}
