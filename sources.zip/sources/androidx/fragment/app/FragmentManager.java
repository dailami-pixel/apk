package androidx.fragment.app;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.C0086b;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.C0098a;
import androidx.activity.result.C0099b;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.p004d.C0101a;
import androidx.core.app.C0445b;
import androidx.fragment.app.C0553c0;
import androidx.fragment.app.C0569j0;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.C0903f;
import androidx.lifecycle.C0907h;
import androidx.lifecycle.C0909j;
import androidx.lifecycle.C0925u;
import com.vidio.android.p195tv.R;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import p098d.p120g.p126f.C4709a;
import p165e.p166a.p167a.p168a.C4924a;

public abstract class FragmentManager {

    /* renamed from: A */
    ArrayDeque<LaunchedFragmentInfo> f2474A = new ArrayDeque<>();

    /* renamed from: B */
    private boolean f2475B;

    /* renamed from: C */
    private boolean f2476C;

    /* renamed from: D */
    private boolean f2477D;

    /* renamed from: E */
    private boolean f2478E;

    /* renamed from: F */
    private boolean f2479F;

    /* renamed from: G */
    private ArrayList<C0543a> f2480G;

    /* renamed from: H */
    private ArrayList<Boolean> f2481H;

    /* renamed from: I */
    private ArrayList<Fragment> f2482I;

    /* renamed from: J */
    private ArrayList<C0538o> f2483J;

    /* renamed from: K */
    private C0617y f2484K;

    /* renamed from: L */
    private Runnable f2485L = new C0530g();

    /* renamed from: a */
    private final ArrayList<C0536m> f2486a = new ArrayList<>();

    /* renamed from: b */
    private boolean f2487b;
    /* access modifiers changed from: private */

    /* renamed from: c */
    public final C0551b0 f2488c = new C0551b0();

    /* renamed from: d */
    ArrayList<C0543a> f2489d;

    /* renamed from: e */
    private ArrayList<Fragment> f2490e;

    /* renamed from: f */
    private final C0612v f2491f = new C0612v(this);

    /* renamed from: g */
    private OnBackPressedDispatcher f2492g;

    /* renamed from: h */
    private final C0086b f2493h = new C0526c(false);

    /* renamed from: i */
    private final AtomicInteger f2494i = new AtomicInteger();

    /* renamed from: j */
    private final Map<String, Bundle> f2495j = Collections.synchronizedMap(new HashMap());

    /* renamed from: k */
    private final Map<String, ?> f2496k = Collections.synchronizedMap(new HashMap());

    /* renamed from: l */
    private ArrayList<C0535l> f2497l;

    /* renamed from: m */
    private Map<Fragment, HashSet<C4709a>> f2498m = Collections.synchronizedMap(new HashMap());

    /* renamed from: n */
    private final C0569j0.C0570a f2499n = new C0527d();

    /* renamed from: o */
    private final C0614w f2500o = new C0614w(this);

    /* renamed from: p */
    private final CopyOnWriteArrayList<C0619z> f2501p = new CopyOnWriteArrayList<>();

    /* renamed from: q */
    int f2502q = -1;

    /* renamed from: r */
    private C0611u<?> f2503r;

    /* renamed from: s */
    private C0607r f2504s;

    /* renamed from: t */
    private Fragment f2505t;

    /* renamed from: u */
    Fragment f2506u;

    /* renamed from: v */
    private C0610t f2507v = new C0528e();

    /* renamed from: w */
    private C0608r0 f2508w = new C0529f(this);

    /* renamed from: x */
    private C0099b<Intent> f2509x;

    /* renamed from: y */
    private C0099b<IntentSenderRequest> f2510y;

    /* renamed from: z */
    private C0099b<String[]> f2511z;

    /* renamed from: androidx.fragment.app.FragmentManager$6 */
    class C05226 implements C0907h {
        /* renamed from: c */
        public void mo360c(C0909j jVar, C0903f.C0904a aVar) {
            if (aVar == C0903f.C0904a.ON_START) {
                FragmentManager.m2476a((FragmentManager) null);
                throw null;
            } else if (aVar == C0903f.C0904a.ON_DESTROY) {
                throw null;
            }
        }
    }

    static class LaunchedFragmentInfo implements Parcelable {
        public static final Parcelable.Creator<LaunchedFragmentInfo> CREATOR = new C0523a();

        /* renamed from: a */
        String f2512a;

        /* renamed from: b */
        int f2513b;

        /* renamed from: androidx.fragment.app.FragmentManager$LaunchedFragmentInfo$a */
        class C0523a implements Parcelable.Creator<LaunchedFragmentInfo> {
            C0523a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new LaunchedFragmentInfo(parcel);
            }

            public Object[] newArray(int i) {
                return new LaunchedFragmentInfo[i];
            }
        }

        LaunchedFragmentInfo(Parcel parcel) {
            this.f2512a = parcel.readString();
            this.f2513b = parcel.readInt();
        }

        LaunchedFragmentInfo(String str, int i) {
            this.f2512a = str;
            this.f2513b = i;
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(this.f2512a);
            parcel.writeInt(this.f2513b);
        }
    }

    /* renamed from: androidx.fragment.app.FragmentManager$a */
    class C0524a implements C0098a<ActivityResult> {
        C0524a() {
        }

        /* renamed from: a */
        public void mo407a(Object obj) {
            StringBuilder sb;
            ActivityResult activityResult = (ActivityResult) obj;
            LaunchedFragmentInfo pollFirst = FragmentManager.this.f2474A.pollFirst();
            if (pollFirst == null) {
                sb = new StringBuilder();
                sb.append("No IntentSenders were started for ");
                sb.append(this);
            } else {
                String str = pollFirst.f2512a;
                int i = pollFirst.f2513b;
                Fragment i2 = FragmentManager.this.f2488c.mo2852i(str);
                if (i2 == null) {
                    sb = C4924a.m17867T("Intent Sender result delivered for unknown Fragment ", str);
                } else {
                    i2.mo2549H3(i, activityResult.mo379c(), activityResult.mo378a());
                    return;
                }
            }
            Log.w("FragmentManager", sb.toString());
        }
    }

    /* renamed from: androidx.fragment.app.FragmentManager$b */
    class C0525b implements C0098a<Map<String, Boolean>> {
        C0525b() {
        }

        /* renamed from: a */
        public void mo407a(Object obj) {
            String str;
            Map map = (Map) obj;
            String[] strArr = (String[]) map.keySet().toArray(new String[0]);
            ArrayList arrayList = new ArrayList(map.values());
            int[] iArr = new int[arrayList.size()];
            for (int i = 0; i < arrayList.size(); i++) {
                iArr[i] = ((Boolean) arrayList.get(i)).booleanValue() ? 0 : -1;
            }
            LaunchedFragmentInfo pollFirst = FragmentManager.this.f2474A.pollFirst();
            if (pollFirst == null) {
                str = "No permissions were requested for " + this;
            } else {
                String str2 = pollFirst.f2512a;
                Fragment i2 = FragmentManager.this.f2488c.mo2852i(str2);
                if (i2 == null) {
                    str = C4924a.m17907v("Permission request result delivered for unknown Fragment ", str2);
                } else {
                    i2.mo2584b4();
                    return;
                }
            }
            Log.w("FragmentManager", str);
        }
    }

    /* renamed from: androidx.fragment.app.FragmentManager$c */
    class C0526c extends C0086b {
        C0526c(boolean z) {
            super(z);
        }

        /* renamed from: b */
        public void mo369b() {
            FragmentManager.this.mo2738o0();
        }
    }

    /* renamed from: androidx.fragment.app.FragmentManager$d */
    class C0527d implements C0569j0.C0570a {
        C0527d() {
        }

        /* renamed from: a */
        public void mo2764a(Fragment fragment, C4709a aVar) {
            if (!aVar.mo21776b()) {
                FragmentManager.this.mo2694G0(fragment, aVar);
            }
        }
    }

    /* renamed from: androidx.fragment.app.FragmentManager$e */
    class C0528e extends C0610t {
        C0528e() {
        }

        /* renamed from: a */
        public Fragment mo2765a(ClassLoader classLoader, String str) {
            C0611u<?> i0 = FragmentManager.this.mo2730i0();
            Context e = FragmentManager.this.mo2730i0().mo3013e();
            Objects.requireNonNull(i0);
            Object obj = Fragment.f2400a;
            try {
                return (Fragment) C0610t.m2823d(e.getClassLoader(), str).getConstructor(new Class[0]).newInstance(new Object[0]);
            } catch (InstantiationException e2) {
                throw new Fragment.InstantiationException(C4924a.m17909x("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e2);
            } catch (IllegalAccessException e3) {
                throw new Fragment.InstantiationException(C4924a.m17909x("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e3);
            } catch (NoSuchMethodException e4) {
                throw new Fragment.InstantiationException(C4924a.m17909x("Unable to instantiate fragment ", str, ": could not find Fragment constructor"), e4);
            } catch (InvocationTargetException e5) {
                throw new Fragment.InstantiationException(C4924a.m17909x("Unable to instantiate fragment ", str, ": calling Fragment constructor caused an exception"), e5);
            }
        }
    }

    /* renamed from: androidx.fragment.app.FragmentManager$f */
    class C0529f implements C0608r0 {
        C0529f(FragmentManager fragmentManager) {
        }
    }

    /* renamed from: androidx.fragment.app.FragmentManager$g */
    class C0530g implements Runnable {
        C0530g() {
        }

        public void run() {
            FragmentManager.this.mo2711S(true);
        }
    }

    /* renamed from: androidx.fragment.app.FragmentManager$h */
    class C0531h implements C0619z {

        /* renamed from: a */
        final /* synthetic */ Fragment f2520a;

        C0531h(FragmentManager fragmentManager, Fragment fragment) {
            this.f2520a = fragment;
        }

        /* renamed from: a */
        public void mo2662a(FragmentManager fragmentManager, Fragment fragment) {
            this.f2520a.mo2555K3(fragment);
        }
    }

    /* renamed from: androidx.fragment.app.FragmentManager$i */
    class C0532i implements C0098a<ActivityResult> {
        C0532i() {
        }

        /* renamed from: a */
        public void mo407a(Object obj) {
            StringBuilder sb;
            ActivityResult activityResult = (ActivityResult) obj;
            LaunchedFragmentInfo pollFirst = FragmentManager.this.f2474A.pollFirst();
            if (pollFirst == null) {
                sb = new StringBuilder();
                sb.append("No Activities were started for result for ");
                sb.append(this);
            } else {
                String str = pollFirst.f2512a;
                int i = pollFirst.f2513b;
                Fragment i2 = FragmentManager.this.f2488c.mo2852i(str);
                if (i2 == null) {
                    sb = C4924a.m17867T("Activity result delivered for unknown Fragment ", str);
                } else {
                    i2.mo2549H3(i, activityResult.mo379c(), activityResult.mo378a());
                    return;
                }
            }
            Log.w("FragmentManager", sb.toString());
        }
    }

    /* renamed from: androidx.fragment.app.FragmentManager$j */
    public interface C0533j {
        int getId();

        String getName();
    }

    /* renamed from: androidx.fragment.app.FragmentManager$k */
    static class C0534k extends C0101a<IntentSenderRequest, ActivityResult> {
        C0534k() {
        }

        /* renamed from: a */
        public Intent mo408a(Context context, Object obj) {
            Bundle bundleExtra;
            IntentSenderRequest intentSenderRequest = (IntentSenderRequest) obj;
            Intent intent = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
            Intent a = intentSenderRequest.mo396a();
            if (!(a == null || (bundleExtra = a.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) == null)) {
                intent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundleExtra);
                a.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                if (a.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false)) {
                    IntentSenderRequest.C0097b bVar = new IntentSenderRequest.C0097b(intentSenderRequest.mo400e());
                    bVar.mo405b((Intent) null);
                    bVar.mo406c(intentSenderRequest.mo398d(), intentSenderRequest.mo397c());
                    intentSenderRequest = bVar.mo404a();
                }
            }
            intent.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", intentSenderRequest);
            if (FragmentManager.m2484s0(2)) {
                Log.v("FragmentManager", "CreateIntent created the following intent: " + intent);
            }
            return intent;
        }

        /* renamed from: c */
        public Object mo410c(int i, Intent intent) {
            return new ActivityResult(i, intent);
        }
    }

    /* renamed from: androidx.fragment.app.FragmentManager$l */
    public interface C0535l {
        /* renamed from: a */
        void mo2769a();
    }

    /* renamed from: androidx.fragment.app.FragmentManager$m */
    interface C0536m {
        /* renamed from: a */
        boolean mo2770a(ArrayList<C0543a> arrayList, ArrayList<Boolean> arrayList2);
    }

    /* renamed from: androidx.fragment.app.FragmentManager$n */
    private class C0537n implements C0536m {

        /* renamed from: a */
        final int f2522a;

        /* renamed from: b */
        final int f2523b;

        C0537n(String str, int i, int i2) {
            this.f2522a = i;
            this.f2523b = i2;
        }

        /* renamed from: a */
        public boolean mo2770a(ArrayList<C0543a> arrayList, ArrayList<Boolean> arrayList2) {
            Fragment fragment = FragmentManager.this.f2506u;
            if (fragment != null && this.f2522a < 0 && fragment.mo2581a3().mo2688C0()) {
                return false;
            }
            return FragmentManager.this.mo2692F0(arrayList, arrayList2, (String) null, this.f2522a, this.f2523b);
        }
    }

    /* renamed from: androidx.fragment.app.FragmentManager$o */
    static class C0538o implements Fragment.C0520d {

        /* renamed from: a */
        final boolean f2525a;

        /* renamed from: b */
        final C0543a f2526b;

        /* renamed from: c */
        private int f2527c;

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo2771a() {
            boolean z = this.f2527c > 0;
            for (Fragment next : this.f2526b.f2554q.mo2728h0()) {
                next.mo2552I4((Fragment.C0520d) null);
                if (z && next.mo2535A3()) {
                    next.mo2564O4();
                }
            }
            C0543a aVar = this.f2526b;
            aVar.f2554q.mo2734m(aVar, this.f2525a, !z, true);
        }

        /* renamed from: b */
        public boolean mo2772b() {
            return this.f2527c == 0;
        }

        /* renamed from: c */
        public void mo2773c() {
            this.f2527c++;
        }
    }

    /* renamed from: D */
    private void m2464D(Fragment fragment) {
        if (fragment != null && fragment.equals(mo2713W(fragment.f2424f))) {
            fragment.mo2622s4();
        }
    }

    /* renamed from: E0 */
    private boolean m2465E0(String str, int i, int i2) {
        mo2711S(false);
        m2471R(true);
        Fragment fragment = this.f2506u;
        if (fragment != null && i < 0 && fragment.mo2581a3().mo2688C0()) {
            return true;
        }
        boolean F0 = mo2692F0(this.f2480G, this.f2481H, (String) null, i, i2);
        if (F0) {
            this.f2487b = true;
            try {
                m2466J0(this.f2480G, this.f2481H);
            } finally {
                m2481k();
            }
        }
        m2473T0();
        m2468N();
        this.f2488c.mo2845b();
        return F0;
    }

    /* renamed from: J0 */
    private void m2466J0(ArrayList<C0543a> arrayList, ArrayList<Boolean> arrayList2) {
        if (!arrayList.isEmpty()) {
            if (arrayList.size() == arrayList2.size()) {
                m2475V(arrayList, arrayList2);
                int size = arrayList.size();
                int i = 0;
                int i2 = 0;
                while (i < size) {
                    if (!arrayList.get(i).f2597p) {
                        if (i2 != i) {
                            m2474U(arrayList, arrayList2, i2, i);
                        }
                        i2 = i + 1;
                        if (arrayList2.get(i).booleanValue()) {
                            while (i2 < size && arrayList2.get(i2).booleanValue() && !arrayList.get(i2).f2597p) {
                                i2++;
                            }
                        }
                        m2474U(arrayList, arrayList2, i, i2);
                        i = i2 - 1;
                    }
                    i++;
                }
                if (i2 != size) {
                    m2474U(arrayList, arrayList2, i2, size);
                    return;
                }
                return;
            }
            throw new IllegalStateException("Internal error with the back stack records");
        }
    }

    /* JADX INFO: finally extract failed */
    /* renamed from: K */
    private void m2467K(int i) {
        try {
            this.f2487b = true;
            this.f2488c.mo2847d(i);
            mo2757y0(i, false);
            Iterator it = ((HashSet) m2482l()).iterator();
            while (it.hasNext()) {
                ((C0599q0) it.next()).mo2969i();
            }
            this.f2487b = false;
            mo2711S(true);
        } catch (Throwable th) {
            this.f2487b = false;
            throw th;
        }
    }

    /* renamed from: N */
    private void m2468N() {
        if (this.f2479F) {
            this.f2479F = false;
            m2472S0();
        }
    }

    /* renamed from: P */
    private void m2469P() {
        Iterator it = ((HashSet) m2482l()).iterator();
        while (it.hasNext()) {
            ((C0599q0) it.next()).mo2969i();
        }
    }

    /* renamed from: Q0 */
    private void m2470Q0(Fragment fragment) {
        ViewGroup e0 = m2479e0(fragment);
        if (e0 != null && fragment.mo2585c3() + fragment.mo2592f3() + fragment.mo2610o3() + fragment.mo2615p3() > 0) {
            if (e0.getTag(R.id.visible_removing_fragment_view_tag) == null) {
                e0.setTag(R.id.visible_removing_fragment_view_tag, fragment);
            }
            ((Fragment) e0.getTag(R.id.visible_removing_fragment_view_tag)).mo2554J4(fragment.mo2608n3());
        }
    }

    /* renamed from: R */
    private void m2471R(boolean z) {
        if (this.f2487b) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        } else if (this.f2503r == null) {
            if (this.f2478E) {
                throw new IllegalStateException("FragmentManager has been destroyed");
            }
            throw new IllegalStateException("FragmentManager has not been attached to a host.");
        } else if (Looper.myLooper() != this.f2503r.mo3014f().getLooper()) {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        } else if (z || !mo2753w0()) {
            if (this.f2480G == null) {
                this.f2480G = new ArrayList<>();
                this.f2481H = new ArrayList<>();
            }
            this.f2487b = true;
            try {
                m2475V((ArrayList<C0543a>) null, (ArrayList<Boolean>) null);
            } finally {
                this.f2487b = false;
            }
        } else {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
    }

    /* renamed from: S0 */
    private void m2472S0() {
        Iterator it = ((ArrayList) this.f2488c.mo2854k()).iterator();
        while (it.hasNext()) {
            C0544a0 a0Var = (C0544a0) it.next();
            Fragment k = a0Var.mo2817k();
            if (k.f2407G) {
                if (this.f2487b) {
                    this.f2479F = true;
                } else {
                    k.f2407G = false;
                    a0Var.mo2818l();
                }
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x001a, code lost:
        if (mo2719c0() <= 0) goto L_0x0025;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0022, code lost:
        if (mo2751v0(r3.f2505t) == false) goto L_0x0025;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0025, code lost:
        r2 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0026, code lost:
        r0.mo373f(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0029, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0014, code lost:
        r0 = r3.f2493h;
     */
    /* renamed from: T0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m2473T0() {
        /*
            r3 = this;
            java.util.ArrayList<androidx.fragment.app.FragmentManager$m> r0 = r3.f2486a
            monitor-enter(r0)
            java.util.ArrayList<androidx.fragment.app.FragmentManager$m> r1 = r3.f2486a     // Catch:{ all -> 0x002a }
            boolean r1 = r1.isEmpty()     // Catch:{ all -> 0x002a }
            r2 = 1
            if (r1 != 0) goto L_0x0013
            androidx.activity.b r1 = r3.f2493h     // Catch:{ all -> 0x002a }
            r1.mo373f(r2)     // Catch:{ all -> 0x002a }
            monitor-exit(r0)     // Catch:{ all -> 0x002a }
            return
        L_0x0013:
            monitor-exit(r0)     // Catch:{ all -> 0x002a }
            androidx.activity.b r0 = r3.f2493h
            int r1 = r3.mo2719c0()
            if (r1 <= 0) goto L_0x0025
            androidx.fragment.app.Fragment r1 = r3.f2505t
            boolean r1 = r3.mo2751v0(r1)
            if (r1 == 0) goto L_0x0025
            goto L_0x0026
        L_0x0025:
            r2 = 0
        L_0x0026:
            r0.mo373f(r2)
            return
        L_0x002a:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x002a }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.FragmentManager.m2473T0():void");
    }

    /* renamed from: U */
    private void m2474U(ArrayList<C0543a> arrayList, ArrayList<Boolean> arrayList2, int i, int i2) {
        ViewGroup viewGroup;
        int i3;
        int i4;
        ArrayList<C0543a> arrayList3 = arrayList;
        ArrayList<Boolean> arrayList4 = arrayList2;
        int i5 = i;
        int i6 = i2;
        boolean z = arrayList3.get(i5).f2597p;
        ArrayList<Fragment> arrayList5 = this.f2482I;
        if (arrayList5 == null) {
            this.f2482I = new ArrayList<>();
        } else {
            arrayList5.clear();
        }
        this.f2482I.addAll(this.f2488c.mo2857n());
        Fragment fragment = this.f2506u;
        int i7 = i5;
        boolean z2 = false;
        while (true) {
            int i8 = 1;
            if (i7 < i6) {
                C0543a aVar = arrayList3.get(i7);
                int i9 = 3;
                if (!arrayList4.get(i7).booleanValue()) {
                    ArrayList<Fragment> arrayList6 = this.f2482I;
                    int i10 = 0;
                    while (i10 < aVar.f2582a.size()) {
                        C0553c0.C0554a aVar2 = aVar.f2582a.get(i10);
                        int i11 = aVar2.f2598a;
                        if (i11 != i8) {
                            if (i11 == 2) {
                                Fragment fragment2 = aVar2.f2599b;
                                int i12 = fragment2.f2442x;
                                int size = arrayList6.size() - 1;
                                boolean z3 = false;
                                while (size >= 0) {
                                    Fragment fragment3 = arrayList6.get(size);
                                    if (fragment3.f2442x != i12) {
                                        i4 = i12;
                                    } else if (fragment3 == fragment2) {
                                        i4 = i12;
                                        z3 = true;
                                    } else {
                                        if (fragment3 == fragment) {
                                            i4 = i12;
                                            aVar.f2582a.add(i10, new C0553c0.C0554a(9, fragment3));
                                            i10++;
                                            fragment = null;
                                        } else {
                                            i4 = i12;
                                        }
                                        C0553c0.C0554a aVar3 = new C0553c0.C0554a(3, fragment3);
                                        aVar3.f2600c = aVar2.f2600c;
                                        aVar3.f2602e = aVar2.f2602e;
                                        aVar3.f2601d = aVar2.f2601d;
                                        aVar3.f2603f = aVar2.f2603f;
                                        aVar.f2582a.add(i10, aVar3);
                                        arrayList6.remove(fragment3);
                                        i10++;
                                    }
                                    size--;
                                    ArrayList<Boolean> arrayList7 = arrayList2;
                                    i12 = i4;
                                }
                                if (z3) {
                                    aVar.f2582a.remove(i10);
                                    i10--;
                                } else {
                                    i3 = 1;
                                    aVar2.f2598a = 1;
                                    arrayList6.add(fragment2);
                                    i10 += i3;
                                    ArrayList<Boolean> arrayList8 = arrayList2;
                                    int i13 = i;
                                    i8 = 1;
                                    i9 = 3;
                                }
                            } else if (i11 == i9 || i11 == 6) {
                                arrayList6.remove(aVar2.f2599b);
                                Fragment fragment4 = aVar2.f2599b;
                                if (fragment4 == fragment) {
                                    aVar.f2582a.add(i10, new C0553c0.C0554a(9, fragment4));
                                    i10++;
                                    i3 = 1;
                                    fragment = null;
                                    i10 += i3;
                                    ArrayList<Boolean> arrayList82 = arrayList2;
                                    int i132 = i;
                                    i8 = 1;
                                    i9 = 3;
                                }
                            } else if (i11 != 7) {
                                if (i11 == 8) {
                                    aVar.f2582a.add(i10, new C0553c0.C0554a(9, fragment));
                                    i10++;
                                    fragment = aVar2.f2599b;
                                }
                            }
                            i3 = 1;
                            i10 += i3;
                            ArrayList<Boolean> arrayList822 = arrayList2;
                            int i1322 = i;
                            i8 = 1;
                            i9 = 3;
                        }
                        i3 = 1;
                        arrayList6.add(aVar2.f2599b);
                        i10 += i3;
                        ArrayList<Boolean> arrayList8222 = arrayList2;
                        int i13222 = i;
                        i8 = 1;
                        i9 = 3;
                    }
                } else {
                    int i14 = 1;
                    ArrayList<Fragment> arrayList9 = this.f2482I;
                    int size2 = aVar.f2582a.size() - 1;
                    while (size2 >= 0) {
                        C0553c0.C0554a aVar4 = aVar.f2582a.get(size2);
                        int i15 = aVar4.f2598a;
                        if (i15 != i14) {
                            if (i15 != 3) {
                                switch (i15) {
                                    case 6:
                                        break;
                                    case 7:
                                        break;
                                    case 8:
                                        fragment = null;
                                        break;
                                    case 9:
                                        fragment = aVar4.f2599b;
                                        break;
                                    case 10:
                                        aVar4.f2605h = aVar4.f2604g;
                                        break;
                                }
                            }
                            arrayList9.add(aVar4.f2599b);
                            size2--;
                            i14 = 1;
                        }
                        arrayList9.remove(aVar4.f2599b);
                        size2--;
                        i14 = 1;
                    }
                }
                z2 = z2 || aVar.f2588g;
                i7++;
                arrayList4 = arrayList2;
                int i16 = i;
            } else {
                this.f2482I.clear();
                if (!z && this.f2502q >= 1) {
                    for (int i17 = i; i17 < i6; i17++) {
                        Iterator<C0553c0.C0554a> it = arrayList3.get(i17).f2582a.iterator();
                        while (it.hasNext()) {
                            Fragment fragment5 = it.next().f2599b;
                            if (!(fragment5 == null || fragment5.f2437s == null)) {
                                this.f2488c.mo2859p(mo2736n(fragment5));
                            }
                        }
                    }
                }
                int i18 = i;
                while (i18 < i6) {
                    C0543a aVar5 = arrayList3.get(i18);
                    if (arrayList2.get(i18).booleanValue()) {
                        aVar5.mo2799l(-1);
                        aVar5.mo2803p(i18 == i6 + -1);
                    } else {
                        aVar5.mo2799l(1);
                        aVar5.mo2802o();
                    }
                    i18++;
                }
                ArrayList<Boolean> arrayList10 = arrayList2;
                boolean booleanValue = arrayList10.get(i6 - 1).booleanValue();
                for (int i19 = i; i19 < i6; i19++) {
                    C0543a aVar6 = arrayList3.get(i19);
                    if (booleanValue) {
                        for (int size3 = aVar6.f2582a.size() - 1; size3 >= 0; size3--) {
                            Fragment fragment6 = aVar6.f2582a.get(size3).f2599b;
                            if (fragment6 != null) {
                                mo2736n(fragment6).mo2818l();
                            }
                        }
                    } else {
                        Iterator<C0553c0.C0554a> it2 = aVar6.f2582a.iterator();
                        while (it2.hasNext()) {
                            Fragment fragment7 = it2.next().f2599b;
                            if (fragment7 != null) {
                                mo2736n(fragment7).mo2818l();
                            }
                        }
                    }
                }
                mo2757y0(this.f2502q, true);
                HashSet hashSet = new HashSet();
                for (int i20 = i; i20 < i6; i20++) {
                    Iterator<C0553c0.C0554a> it3 = arrayList3.get(i20).f2582a.iterator();
                    while (it3.hasNext()) {
                        Fragment fragment8 = it3.next().f2599b;
                        if (!(fragment8 == null || (viewGroup = fragment8.f2405E) == null)) {
                            hashSet.add(C0599q0.m2765m(viewGroup, mo2735m0()));
                        }
                    }
                }
                Iterator it4 = hashSet.iterator();
                while (it4.hasNext()) {
                    C0599q0 q0Var = (C0599q0) it4.next();
                    q0Var.f2736d = booleanValue;
                    q0Var.mo2972n();
                    q0Var.mo2968g();
                }
                for (int i21 = i; i21 < i6; i21++) {
                    C0543a aVar7 = arrayList3.get(i21);
                    if (arrayList10.get(i21).booleanValue() && aVar7.f2556s >= 0) {
                        aVar7.f2556s = -1;
                    }
                    Objects.requireNonNull(aVar7);
                }
                if (z2 && this.f2497l != null) {
                    for (int i22 = 0; i22 < this.f2497l.size(); i22++) {
                        this.f2497l.get(i22).mo2769a();
                    }
                    return;
                }
                return;
            }
        }
    }

    /* renamed from: V */
    private void m2475V(ArrayList<C0543a> arrayList, ArrayList<Boolean> arrayList2) {
        int indexOf;
        int indexOf2;
        ArrayList<C0538o> arrayList3 = this.f2483J;
        int size = arrayList3 == null ? 0 : arrayList3.size();
        int i = 0;
        while (i < size) {
            C0538o oVar = this.f2483J.get(i);
            if (arrayList == null || oVar.f2525a || (indexOf2 = arrayList.indexOf(oVar.f2526b)) == -1 || arrayList2 == null || !arrayList2.get(indexOf2).booleanValue()) {
                if (oVar.mo2772b() || (arrayList != null && oVar.f2526b.mo2805r(arrayList, 0, arrayList.size()))) {
                    this.f2483J.remove(i);
                    i--;
                    size--;
                    if (arrayList == null || oVar.f2525a || (indexOf = arrayList.indexOf(oVar.f2526b)) == -1 || arrayList2 == null || !arrayList2.get(indexOf).booleanValue()) {
                        oVar.mo2771a();
                    }
                }
                i++;
            } else {
                this.f2483J.remove(i);
                i--;
                size--;
            }
            C0543a aVar = oVar.f2526b;
            aVar.f2554q.mo2734m(aVar, oVar.f2525a, false, false);
            i++;
        }
    }

    /* renamed from: a */
    static /* synthetic */ Map m2476a(FragmentManager fragmentManager) {
        throw null;
    }

    /* renamed from: a0 */
    private void m2477a0() {
        Iterator it = ((HashSet) m2482l()).iterator();
        while (it.hasNext()) {
            C0599q0 q0Var = (C0599q0) it.next();
            if (q0Var.f2737e) {
                q0Var.f2737e = false;
                q0Var.mo2968g();
            }
        }
    }

    /* renamed from: e0 */
    private ViewGroup m2479e0(Fragment fragment) {
        ViewGroup viewGroup = fragment.f2405E;
        if (viewGroup != null) {
            return viewGroup;
        }
        if (fragment.f2442x > 0 && this.f2504s.mo2645c()) {
            View b = this.f2504s.mo2644b(fragment.f2442x);
            if (b instanceof ViewGroup) {
                return (ViewGroup) b;
            }
        }
        return null;
    }

    /* renamed from: j */
    private void m2480j(Fragment fragment) {
        HashSet hashSet = this.f2498m.get(fragment);
        if (hashSet != null) {
            Iterator it = hashSet.iterator();
            while (it.hasNext()) {
                ((C4709a) it.next()).mo21775a();
            }
            hashSet.clear();
            m2483o(fragment);
            this.f2498m.remove(fragment);
        }
    }

    /* renamed from: k */
    private void m2481k() {
        this.f2487b = false;
        this.f2481H.clear();
        this.f2480G.clear();
    }

    /* renamed from: l */
    private Set<C0599q0> m2482l() {
        HashSet hashSet = new HashSet();
        Iterator it = ((ArrayList) this.f2488c.mo2854k()).iterator();
        while (it.hasNext()) {
            ViewGroup viewGroup = ((C0544a0) it.next()).mo2817k().f2405E;
            if (viewGroup != null) {
                hashSet.add(C0599q0.m2765m(viewGroup, mo2735m0()));
            }
        }
        return hashSet;
    }

    /* renamed from: o */
    private void m2483o(Fragment fragment) {
        fragment.mo2609n4();
        this.f2500o.mo3033n(fragment, false);
        fragment.f2405E = null;
        fragment.f2406F = null;
        fragment.f2416P = null;
        fragment.f2417Q.mo3923i(null);
        fragment.f2433o = false;
    }

    /* renamed from: s0 */
    static boolean m2484s0(int i) {
        return Log.isLoggable("FragmentManager", i);
    }

    /* renamed from: t0 */
    private boolean m2485t0(Fragment fragment) {
        FragmentManager fragmentManager = fragment.f2439u;
        Iterator it = ((ArrayList) fragmentManager.f2488c.mo2855l()).iterator();
        boolean z = false;
        while (it.hasNext()) {
            Fragment fragment2 = (Fragment) it.next();
            if (fragment2 != null) {
                z = fragmentManager.m2485t0(fragment2);
                continue;
            }
            if (z) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: A */
    public void mo2683A(Fragment fragment) {
        Iterator<C0619z> it = this.f2501p.iterator();
        while (it.hasNext()) {
            it.next().mo2662a(this, fragment);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: A0 */
    public void mo2684A0() {
        if (this.f2503r != null) {
            this.f2476C = false;
            this.f2477D = false;
            this.f2484K.mo3044l(false);
            for (Fragment next : this.f2488c.mo2857n()) {
                if (next != null) {
                    next.f2439u.mo2684A0();
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: B */
    public boolean mo2685B(MenuItem menuItem) {
        if (this.f2502q < 1) {
            return false;
        }
        for (Fragment next : this.f2488c.mo2857n()) {
            if (next != null) {
                if (!next.f2444z ? next.f2439u.mo2685B(menuItem) : false) {
                    return true;
                }
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: B0 */
    public void mo2686B0(FragmentContainerView fragmentContainerView) {
        View view;
        Iterator it = ((ArrayList) this.f2488c.mo2854k()).iterator();
        while (it.hasNext()) {
            C0544a0 a0Var = (C0544a0) it.next();
            Fragment k = a0Var.mo2817k();
            if (k.f2442x == fragmentContainerView.getId() && (view = k.f2406F) != null && view.getParent() == null) {
                k.f2405E = fragmentContainerView;
                a0Var.mo2808b();
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: C */
    public void mo2687C(Menu menu) {
        if (this.f2502q >= 1) {
            for (Fragment next : this.f2488c.mo2857n()) {
                if (next != null && !next.f2444z) {
                    next.f2439u.mo2687C(menu);
                }
            }
        }
    }

    /* renamed from: C0 */
    public boolean mo2688C0() {
        return m2465E0((String) null, -1, 0);
    }

    /* renamed from: D0 */
    public boolean mo2689D0(int i, int i2) {
        if (i >= 0) {
            return m2465E0((String) null, i, i2);
        }
        throw new IllegalArgumentException(C4924a.m17900o("Bad id: ", i));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: E */
    public void mo2690E() {
        m2467K(5);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: F */
    public void mo2691F(boolean z) {
        for (Fragment next : this.f2488c.mo2857n()) {
            if (next != null) {
                next.mo2580Z3();
                next.f2439u.mo2691F(z);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: F0 */
    public boolean mo2692F0(ArrayList<C0543a> arrayList, ArrayList<Boolean> arrayList2, String str, int i, int i2) {
        int i3;
        ArrayList<C0543a> arrayList3 = this.f2489d;
        if (arrayList3 == null) {
            return false;
        }
        if (str == null && i < 0 && (i2 & 1) == 0) {
            int size = arrayList3.size() - 1;
            if (size < 0) {
                return false;
            }
            arrayList.add(this.f2489d.remove(size));
            arrayList2.add(Boolean.TRUE);
        } else {
            if (str != null || i >= 0) {
                int size2 = arrayList3.size() - 1;
                while (size2 >= 0) {
                    C0543a aVar = this.f2489d.get(size2);
                    if ((str != null && str.equals(aVar.f2590i)) || (i >= 0 && i == aVar.f2556s)) {
                        break;
                    }
                    size2--;
                }
                if (size2 < 0) {
                    return false;
                }
                if ((i2 & 1) != 0) {
                    while (true) {
                        size2--;
                        if (size2 < 0) {
                            break;
                        }
                        C0543a aVar2 = this.f2489d.get(size2);
                        if ((str == null || !str.equals(aVar2.f2590i)) && (i < 0 || i != aVar2.f2556s)) {
                            break;
                        }
                    }
                }
                i3 = size2;
            } else {
                i3 = -1;
            }
            if (i3 == this.f2489d.size() - 1) {
                return false;
            }
            for (int size3 = this.f2489d.size() - 1; size3 > i3; size3--) {
                arrayList.add(this.f2489d.remove(size3));
                arrayList2.add(Boolean.TRUE);
            }
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: G */
    public boolean mo2693G(Menu menu) {
        boolean z = false;
        if (this.f2502q < 1) {
            return false;
        }
        for (Fragment next : this.f2488c.mo2857n()) {
            if (next != null && mo2749u0(next) && next.mo2620r4(menu)) {
                z = true;
            }
        }
        return z;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: G0 */
    public void mo2694G0(Fragment fragment, C4709a aVar) {
        HashSet hashSet = this.f2498m.get(fragment);
        if (hashSet != null && hashSet.remove(aVar) && hashSet.isEmpty()) {
            this.f2498m.remove(fragment);
            if (fragment.f2420b < 5) {
                m2483o(fragment);
                mo2759z0(fragment, this.f2502q);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: H */
    public void mo2695H() {
        m2473T0();
        m2464D(this.f2506u);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: H0 */
    public void mo2696H0(Fragment fragment) {
        if (m2484s0(2)) {
            Log.v("FragmentManager", "remove: " + fragment + " nesting=" + fragment.f2436r);
        }
        boolean z = !fragment.mo2637z3();
        if (!fragment.f2401A || z) {
            this.f2488c.mo2862s(fragment);
            if (m2485t0(fragment)) {
                this.f2475B = true;
            }
            fragment.f2431m = true;
            m2470Q0(fragment);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: I */
    public void mo2697I() {
        this.f2476C = false;
        this.f2477D = false;
        this.f2484K.mo3044l(false);
        m2467K(7);
    }

    /* renamed from: I0 */
    public void mo2698I0(C0535l lVar) {
        ArrayList<C0535l> arrayList = this.f2497l;
        if (arrayList != null) {
            arrayList.remove(lVar);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: J */
    public void mo2699J() {
        this.f2476C = false;
        this.f2477D = false;
        this.f2484K.mo3044l(false);
        m2467K(5);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: K0 */
    public void mo2700K0(Parcelable parcelable) {
        C0544a0 a0Var;
        if (parcelable != null) {
            FragmentManagerState fragmentManagerState = (FragmentManagerState) parcelable;
            if (fragmentManagerState.f2528a != null) {
                this.f2488c.mo2863t();
                Iterator<FragmentState> it = fragmentManagerState.f2528a.iterator();
                while (it.hasNext()) {
                    FragmentState next = it.next();
                    if (next != null) {
                        Fragment e = this.f2484K.mo3036e(next.f2537b);
                        if (e != null) {
                            if (m2484s0(2)) {
                                Log.v("FragmentManager", "restoreSaveState: re-attaching retained " + e);
                            }
                            a0Var = new C0544a0(this.f2500o, this.f2488c, e, next);
                        } else {
                            a0Var = new C0544a0(this.f2500o, this.f2488c, this.f2503r.mo3013e().getClassLoader(), mo2724f0(), next);
                        }
                        Fragment k = a0Var.mo2817k();
                        k.f2437s = this;
                        if (m2484s0(2)) {
                            StringBuilder P = C4924a.m17863P("restoreSaveState: active (");
                            P.append(k.f2424f);
                            P.append("): ");
                            P.append(k);
                            Log.v("FragmentManager", P.toString());
                        }
                        a0Var.mo2820n(this.f2503r.mo3013e().getClassLoader());
                        this.f2488c.mo2859p(a0Var);
                        a0Var.mo2824r(this.f2502q);
                    }
                }
                Iterator it2 = ((ArrayList) this.f2484K.mo3039h()).iterator();
                while (it2.hasNext()) {
                    Fragment fragment = (Fragment) it2.next();
                    if (!this.f2488c.mo2846c(fragment.f2424f)) {
                        if (m2484s0(2)) {
                            Log.v("FragmentManager", "Discarding retained Fragment " + fragment + " that was not found in the set of active Fragments " + fragmentManagerState.f2528a);
                        }
                        this.f2484K.mo3043k(fragment);
                        fragment.f2437s = this;
                        C0544a0 a0Var2 = new C0544a0(this.f2500o, this.f2488c, fragment);
                        a0Var2.mo2824r(1);
                        a0Var2.mo2818l();
                        fragment.f2431m = true;
                        a0Var2.mo2818l();
                    }
                }
                this.f2488c.mo2864u(fragmentManagerState.f2529b);
                if (fragmentManagerState.f2530c != null) {
                    this.f2489d = new ArrayList<>(fragmentManagerState.f2530c.length);
                    int i = 0;
                    while (true) {
                        BackStackState[] backStackStateArr = fragmentManagerState.f2530c;
                        if (i >= backStackStateArr.length) {
                            break;
                        }
                        BackStackState backStackState = backStackStateArr[i];
                        Objects.requireNonNull(backStackState);
                        C0543a aVar = new C0543a(this);
                        int i2 = 0;
                        int i3 = 0;
                        while (true) {
                            int[] iArr = backStackState.f2386a;
                            if (i2 >= iArr.length) {
                                break;
                            }
                            C0553c0.C0554a aVar2 = new C0553c0.C0554a();
                            int i4 = i2 + 1;
                            aVar2.f2598a = iArr[i2];
                            if (m2484s0(2)) {
                                Log.v("FragmentManager", "Instantiate " + aVar + " op #" + i3 + " base fragment #" + backStackState.f2386a[i4]);
                            }
                            String str = backStackState.f2387b.get(i3);
                            aVar2.f2599b = str != null ? mo2713W(str) : null;
                            aVar2.f2604g = C0903f.C0905b.values()[backStackState.f2388c[i3]];
                            aVar2.f2605h = C0903f.C0905b.values()[backStackState.f2389d[i3]];
                            int[] iArr2 = backStackState.f2386a;
                            int i5 = i4 + 1;
                            int i6 = iArr2[i4];
                            aVar2.f2600c = i6;
                            int i7 = i5 + 1;
                            int i8 = iArr2[i5];
                            aVar2.f2601d = i8;
                            int i9 = i7 + 1;
                            int i10 = iArr2[i7];
                            aVar2.f2602e = i10;
                            int i11 = iArr2[i9];
                            aVar2.f2603f = i11;
                            aVar.f2583b = i6;
                            aVar.f2584c = i8;
                            aVar.f2585d = i10;
                            aVar.f2586e = i11;
                            aVar.mo2870c(aVar2);
                            i3++;
                            i2 = i9 + 1;
                        }
                        aVar.f2587f = backStackState.f2390e;
                        aVar.f2590i = backStackState.f2391f;
                        aVar.f2556s = backStackState.f2392g;
                        aVar.f2588g = true;
                        aVar.f2591j = backStackState.f2393h;
                        aVar.f2592k = backStackState.f2394i;
                        aVar.f2593l = backStackState.f2395j;
                        aVar.f2594m = backStackState.f2396k;
                        aVar.f2595n = backStackState.f2397l;
                        aVar.f2596o = backStackState.f2398m;
                        aVar.f2597p = backStackState.f2399n;
                        aVar.mo2799l(1);
                        if (m2484s0(2)) {
                            StringBuilder Q = C4924a.m17864Q("restoreAllState: back stack #", i, " (index ");
                            Q.append(aVar.f2556s);
                            Q.append("): ");
                            Q.append(aVar);
                            Log.v("FragmentManager", Q.toString());
                            PrintWriter printWriter = new PrintWriter(new C0595p0("FragmentManager"));
                            aVar.mo2801n("  ", printWriter, false);
                            printWriter.close();
                        }
                        this.f2489d.add(aVar);
                        i++;
                    }
                } else {
                    this.f2489d = null;
                }
                this.f2494i.set(fragmentManagerState.f2531d);
                String str2 = fragmentManagerState.f2532e;
                if (str2 != null) {
                    Fragment W = mo2713W(str2);
                    this.f2506u = W;
                    m2464D(W);
                }
                ArrayList<String> arrayList = fragmentManagerState.f2533f;
                if (arrayList != null) {
                    for (int i12 = 0; i12 < arrayList.size(); i12++) {
                        this.f2495j.put(arrayList.get(i12), fragmentManagerState.f2534g.get(i12));
                    }
                }
                this.f2474A = new ArrayDeque<>(fragmentManagerState.f2535h);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: L */
    public void mo2701L() {
        this.f2477D = true;
        this.f2484K.mo3044l(true);
        m2467K(4);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: L0 */
    public Parcelable mo2702L0() {
        int size;
        m2477a0();
        m2469P();
        mo2711S(true);
        this.f2476C = true;
        this.f2484K.mo3044l(true);
        ArrayList<FragmentState> v = this.f2488c.mo2865v();
        BackStackState[] backStackStateArr = null;
        if (v.isEmpty()) {
            if (m2484s0(2)) {
                Log.v("FragmentManager", "saveAllState: no fragments!");
            }
            return null;
        }
        ArrayList<String> w = this.f2488c.mo2866w();
        ArrayList<C0543a> arrayList = this.f2489d;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            backStackStateArr = new BackStackState[size];
            for (int i = 0; i < size; i++) {
                backStackStateArr[i] = new BackStackState(this.f2489d.get(i));
                if (m2484s0(2)) {
                    StringBuilder Q = C4924a.m17864Q("saveAllState: adding back stack #", i, ": ");
                    Q.append(this.f2489d.get(i));
                    Log.v("FragmentManager", Q.toString());
                }
            }
        }
        FragmentManagerState fragmentManagerState = new FragmentManagerState();
        fragmentManagerState.f2528a = v;
        fragmentManagerState.f2529b = w;
        fragmentManagerState.f2530c = backStackStateArr;
        fragmentManagerState.f2531d = this.f2494i.get();
        Fragment fragment = this.f2506u;
        if (fragment != null) {
            fragmentManagerState.f2532e = fragment.f2424f;
        }
        fragmentManagerState.f2533f.addAll(this.f2495j.keySet());
        fragmentManagerState.f2534g.addAll(this.f2495j.values());
        fragmentManagerState.f2535h = new ArrayList<>(this.f2474A);
        return fragmentManagerState;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: M */
    public void mo2703M() {
        m2467K(2);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: M0 */
    public void mo2704M0() {
        synchronized (this.f2486a) {
            ArrayList<C0538o> arrayList = this.f2483J;
            boolean z = false;
            boolean z2 = arrayList != null && !arrayList.isEmpty();
            if (this.f2486a.size() == 1) {
                z = true;
            }
            if (z2 || z) {
                this.f2503r.mo3014f().removeCallbacks(this.f2485L);
                this.f2503r.mo3014f().post(this.f2485L);
                m2473T0();
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: N0 */
    public void mo2705N0(Fragment fragment, boolean z) {
        ViewGroup e0 = m2479e0(fragment);
        if (e0 != null && (e0 instanceof FragmentContainerView)) {
            ((FragmentContainerView) e0).mo2669b(!z);
        }
    }

    /* renamed from: O */
    public void mo2706O(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int size;
        int size2;
        String v = C4924a.m17907v(str, "    ");
        this.f2488c.mo2848e(str, fileDescriptor, printWriter, strArr);
        ArrayList<Fragment> arrayList = this.f2490e;
        if (arrayList != null && (size2 = arrayList.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Fragments Created Menus:");
            for (int i = 0; i < size2; i++) {
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i);
                printWriter.print(": ");
                printWriter.println(this.f2490e.get(i).toString());
            }
        }
        ArrayList<C0543a> arrayList2 = this.f2489d;
        if (arrayList2 != null && (size = arrayList2.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Back Stack:");
            for (int i2 = 0; i2 < size; i2++) {
                C0543a aVar = this.f2489d.get(i2);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.println(aVar.toString());
                aVar.mo2801n(v, printWriter, true);
            }
        }
        printWriter.print(str);
        printWriter.println("Back Stack Index: " + this.f2494i.get());
        synchronized (this.f2486a) {
            int size3 = this.f2486a.size();
            if (size3 > 0) {
                printWriter.print(str);
                printWriter.println("Pending Actions:");
                for (int i3 = 0; i3 < size3; i3++) {
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i3);
                    printWriter.print(": ");
                    printWriter.println(this.f2486a.get(i3));
                }
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.f2503r);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.f2504s);
        if (this.f2505t != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.f2505t);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.f2502q);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.f2476C);
        printWriter.print(" mStopped=");
        printWriter.print(this.f2477D);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.f2478E);
        if (this.f2475B) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.f2475B);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: O0 */
    public void mo2707O0(Fragment fragment, C0903f.C0905b bVar) {
        if (!fragment.equals(mo2713W(fragment.f2424f)) || !(fragment.f2438t == null || fragment.f2437s == this)) {
            throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
        }
        fragment.f2414N = bVar;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: P0 */
    public void mo2708P0(Fragment fragment) {
        if (fragment == null || (fragment.equals(mo2713W(fragment.f2424f)) && (fragment.f2438t == null || fragment.f2437s == this))) {
            Fragment fragment2 = this.f2506u;
            this.f2506u = fragment;
            m2464D(fragment2);
            m2464D(this.f2506u);
            return;
        }
        throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Q */
    public void mo2709Q(C0536m mVar, boolean z) {
        if (!z) {
            if (this.f2503r == null) {
                if (this.f2478E) {
                    throw new IllegalStateException("FragmentManager has been destroyed");
                }
                throw new IllegalStateException("FragmentManager has not been attached to a host.");
            } else if (mo2753w0()) {
                throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
            }
        }
        synchronized (this.f2486a) {
            if (this.f2503r != null) {
                this.f2486a.add(mVar);
                mo2704M0();
            } else if (!z) {
                throw new IllegalStateException("Activity has been destroyed");
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: R0 */
    public void mo2710R0(Fragment fragment) {
        if (m2484s0(2)) {
            Log.v("FragmentManager", "show: " + fragment);
        }
        if (fragment.f2444z) {
            fragment.f2444z = false;
            fragment.f2410J = !fragment.f2410J;
        }
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: package-private */
    /* renamed from: S */
    public boolean mo2711S(boolean z) {
        boolean z2;
        m2471R(z);
        boolean z3 = false;
        while (true) {
            ArrayList<C0543a> arrayList = this.f2480G;
            ArrayList<Boolean> arrayList2 = this.f2481H;
            synchronized (this.f2486a) {
                if (this.f2486a.isEmpty()) {
                    z2 = false;
                } else {
                    int size = this.f2486a.size();
                    z2 = false;
                    for (int i = 0; i < size; i++) {
                        z2 |= this.f2486a.get(i).mo2770a(arrayList, arrayList2);
                    }
                    this.f2486a.clear();
                    this.f2503r.mo3014f().removeCallbacks(this.f2485L);
                }
            }
            if (z2) {
                this.f2487b = true;
                try {
                    m2466J0(this.f2480G, this.f2481H);
                    m2481k();
                    z3 = true;
                } catch (Throwable th) {
                    m2481k();
                    throw th;
                }
            } else {
                m2473T0();
                m2468N();
                this.f2488c.mo2845b();
                return z3;
            }
        }
        while (true) {
        }
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: package-private */
    /* renamed from: T */
    public void mo2712T(C0536m mVar, boolean z) {
        if (!z || (this.f2503r != null && !this.f2478E)) {
            m2471R(z);
            ((C0543a) mVar).mo2770a(this.f2480G, this.f2481H);
            this.f2487b = true;
            try {
                m2466J0(this.f2480G, this.f2481H);
                m2481k();
                m2473T0();
                m2468N();
                this.f2488c.mo2845b();
            } catch (Throwable th) {
                m2481k();
                throw th;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: W */
    public Fragment mo2713W(String str) {
        return this.f2488c.mo2849f(str);
    }

    /* renamed from: X */
    public Fragment mo2714X(int i) {
        return this.f2488c.mo2850g(i);
    }

    /* renamed from: Y */
    public Fragment mo2715Y(String str) {
        return this.f2488c.mo2851h(str);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Z */
    public Fragment mo2716Z(String str) {
        return this.f2488c.mo2852i(str);
    }

    /* renamed from: b0 */
    public C0533j mo2717b0(int i) {
        return this.f2489d.get(i);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo2718c(Fragment fragment, C4709a aVar) {
        if (this.f2498m.get(fragment) == null) {
            this.f2498m.put(fragment, new HashSet());
        }
        this.f2498m.get(fragment).add(aVar);
    }

    /* renamed from: c0 */
    public int mo2719c0() {
        ArrayList<C0543a> arrayList = this.f2489d;
        if (arrayList != null) {
            return arrayList.size();
        }
        return 0;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public C0544a0 mo2720d(Fragment fragment) {
        if (m2484s0(2)) {
            Log.v("FragmentManager", "add: " + fragment);
        }
        C0544a0 n = mo2736n(fragment);
        fragment.f2437s = this;
        this.f2488c.mo2859p(n);
        if (!fragment.f2401A) {
            this.f2488c.mo2844a(fragment);
            fragment.f2431m = false;
            if (fragment.f2406F == null) {
                fragment.f2410J = false;
            }
            if (m2485t0(fragment)) {
                this.f2475B = true;
            }
        }
        return n;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d0 */
    public C0607r mo2721d0() {
        return this.f2504s;
    }

    /* renamed from: e */
    public void mo2722e(C0535l lVar) {
        if (this.f2497l == null) {
            this.f2497l = new ArrayList<>();
        }
        this.f2497l.add(lVar);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public int mo2723f() {
        return this.f2494i.getAndIncrement();
    }

    /* renamed from: f0 */
    public C0610t mo2724f0() {
        Fragment fragment = this.f2505t;
        return fragment != null ? fragment.f2437s.mo2724f0() : this.f2507v;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v16, resolved type: androidx.activity.c} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v17, resolved type: androidx.fragment.app.Fragment} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v18, resolved type: androidx.fragment.app.Fragment} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v24, resolved type: androidx.fragment.app.Fragment} */
    /* access modifiers changed from: package-private */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x0022  */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0029  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x003c  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0045  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0070  */
    /* JADX WARNING: Removed duplicated region for block: B:34:? A[RETURN, SYNTHETIC] */
    /* renamed from: g */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2725g(androidx.fragment.app.C0611u<?> r3, androidx.fragment.app.C0607r r4, androidx.fragment.app.Fragment r5) {
        /*
            r2 = this;
            androidx.fragment.app.u<?> r0 = r2.f2503r
            if (r0 != 0) goto L_0x00d1
            r2.f2503r = r3
            r2.f2504s = r4
            r2.f2505t = r5
            if (r5 == 0) goto L_0x0012
            androidx.fragment.app.FragmentManager$h r4 = new androidx.fragment.app.FragmentManager$h
            r4.<init>(r2, r5)
            goto L_0x0019
        L_0x0012:
            boolean r4 = r3 instanceof androidx.fragment.app.C0619z
            if (r4 == 0) goto L_0x001e
            r4 = r3
            androidx.fragment.app.z r4 = (androidx.fragment.app.C0619z) r4
        L_0x0019:
            java.util.concurrent.CopyOnWriteArrayList<androidx.fragment.app.z> r0 = r2.f2501p
            r0.add(r4)
        L_0x001e:
            androidx.fragment.app.Fragment r4 = r2.f2505t
            if (r4 == 0) goto L_0x0025
            r2.m2473T0()
        L_0x0025:
            boolean r4 = r3 instanceof androidx.activity.C0087c
            if (r4 == 0) goto L_0x003a
            r4 = r3
            androidx.activity.c r4 = (androidx.activity.C0087c) r4
            androidx.activity.OnBackPressedDispatcher r0 = r4.mo343O()
            r2.f2492g = r0
            if (r5 == 0) goto L_0x0035
            r4 = r5
        L_0x0035:
            androidx.activity.b r1 = r2.f2493h
            r0.mo365a(r4, r1)
        L_0x003a:
            if (r5 == 0) goto L_0x0045
            androidx.fragment.app.FragmentManager r3 = r5.f2437s
            androidx.fragment.app.y r3 = r3.f2484K
            androidx.fragment.app.y r3 = r3.mo3038f(r5)
            goto L_0x005a
        L_0x0045:
            boolean r4 = r3 instanceof androidx.lifecycle.C0926v
            if (r4 == 0) goto L_0x0054
            androidx.lifecycle.v r3 = (androidx.lifecycle.C0926v) r3
            androidx.lifecycle.u r3 = r3.mo345h1()
            androidx.fragment.app.y r3 = androidx.fragment.app.C0617y.m2847g(r3)
            goto L_0x005a
        L_0x0054:
            androidx.fragment.app.y r3 = new androidx.fragment.app.y
            r4 = 0
            r3.<init>(r4)
        L_0x005a:
            r2.f2484K = r3
            boolean r4 = r2.mo2753w0()
            r3.mo3044l(r4)
            androidx.fragment.app.b0 r3 = r2.f2488c
            androidx.fragment.app.y r4 = r2.f2484K
            r3.mo2867x(r4)
            androidx.fragment.app.u<?> r3 = r2.f2503r
            boolean r4 = r3 instanceof androidx.activity.result.C0100c
            if (r4 == 0) goto L_0x00d0
            androidx.activity.result.c r3 = (androidx.activity.result.C0100c) r3
            androidx.activity.result.ActivityResultRegistry r3 = r3.mo342J()
            if (r5 == 0) goto L_0x0086
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = r5.f2424f
            java.lang.String r0 = ":"
            java.lang.String r4 = p165e.p166a.p167a.p168a.C4924a.m17852E(r4, r5, r0)
            goto L_0x0088
        L_0x0086:
            java.lang.String r4 = ""
        L_0x0088:
            java.lang.String r5 = "FragmentManager:"
            java.lang.String r4 = p165e.p166a.p167a.p168a.C4924a.m17907v(r5, r4)
            java.lang.String r5 = "StartActivityForResult"
            java.lang.String r5 = p165e.p166a.p167a.p168a.C4924a.m17907v(r4, r5)
            androidx.activity.result.d.c r0 = new androidx.activity.result.d.c
            r0.<init>()
            androidx.fragment.app.FragmentManager$i r1 = new androidx.fragment.app.FragmentManager$i
            r1.<init>()
            androidx.activity.result.b r5 = r3.mo389f(r5, r0, r1)
            r2.f2509x = r5
            java.lang.String r5 = "StartIntentSenderForResult"
            java.lang.String r5 = p165e.p166a.p167a.p168a.C4924a.m17907v(r4, r5)
            androidx.fragment.app.FragmentManager$k r0 = new androidx.fragment.app.FragmentManager$k
            r0.<init>()
            androidx.fragment.app.FragmentManager$a r1 = new androidx.fragment.app.FragmentManager$a
            r1.<init>()
            androidx.activity.result.b r5 = r3.mo389f(r5, r0, r1)
            r2.f2510y = r5
            java.lang.String r5 = "RequestPermissions"
            java.lang.String r4 = p165e.p166a.p167a.p168a.C4924a.m17907v(r4, r5)
            androidx.activity.result.d.b r5 = new androidx.activity.result.d.b
            r5.<init>()
            androidx.fragment.app.FragmentManager$b r0 = new androidx.fragment.app.FragmentManager$b
            r0.<init>()
            androidx.activity.result.b r3 = r3.mo389f(r4, r5, r0)
            r2.f2511z = r3
        L_0x00d0:
            return
        L_0x00d1:
            java.lang.IllegalStateException r3 = new java.lang.IllegalStateException
            java.lang.String r4 = "Already attached"
            r3.<init>(r4)
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.FragmentManager.mo2725g(androidx.fragment.app.u, androidx.fragment.app.r, androidx.fragment.app.Fragment):void");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g0 */
    public C0551b0 mo2726g0() {
        return this.f2488c;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public void mo2727h(Fragment fragment) {
        if (m2484s0(2)) {
            Log.v("FragmentManager", "attach: " + fragment);
        }
        if (fragment.f2401A) {
            fragment.f2401A = false;
            if (!fragment.f2430l) {
                this.f2488c.mo2844a(fragment);
                if (m2484s0(2)) {
                    Log.v("FragmentManager", "add from attach: " + fragment);
                }
                if (m2485t0(fragment)) {
                    this.f2475B = true;
                }
            }
        }
    }

    /* renamed from: h0 */
    public List<Fragment> mo2728h0() {
        return this.f2488c.mo2857n();
    }

    /* renamed from: i */
    public C0553c0 mo2729i() {
        return new C0543a(this);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i0 */
    public C0611u<?> mo2730i0() {
        return this.f2503r;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j0 */
    public LayoutInflater.Factory2 mo2731j0() {
        return this.f2491f;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k0 */
    public C0614w mo2732k0() {
        return this.f2500o;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l0 */
    public Fragment mo2733l0() {
        return this.f2505t;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: m */
    public void mo2734m(C0543a aVar, boolean z, boolean z2, boolean z3) {
        if (z) {
            aVar.mo2803p(z3);
        } else {
            aVar.mo2802o();
        }
        ArrayList arrayList = new ArrayList(1);
        ArrayList arrayList2 = new ArrayList(1);
        arrayList.add(aVar);
        arrayList2.add(Boolean.valueOf(z));
        if (z2 && this.f2502q >= 1) {
            C0569j0.m2678p(this.f2503r.mo3013e(), this.f2504s, arrayList, arrayList2, 0, 1, true, this.f2499n);
        }
        if (z3) {
            mo2757y0(this.f2502q, true);
        }
        Iterator it = ((ArrayList) this.f2488c.mo2855l()).iterator();
        while (it.hasNext()) {
            Fragment fragment = (Fragment) it.next();
            if (fragment != null) {
                View view = fragment.f2406F;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: m0 */
    public C0608r0 mo2735m0() {
        Fragment fragment = this.f2505t;
        return fragment != null ? fragment.f2437s.mo2735m0() : this.f2508w;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n */
    public C0544a0 mo2736n(Fragment fragment) {
        C0544a0 m = this.f2488c.mo2856m(fragment.f2424f);
        if (m != null) {
            return m;
        }
        C0544a0 a0Var = new C0544a0(this.f2500o, this.f2488c, fragment);
        a0Var.mo2820n(this.f2503r.mo3013e().getClassLoader());
        a0Var.mo2824r(this.f2502q);
        return a0Var;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n0 */
    public C0925u mo2737n0(Fragment fragment) {
        return this.f2484K.mo3041i(fragment);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: o0 */
    public void mo2738o0() {
        mo2711S(true);
        if (this.f2493h.mo370c()) {
            mo2688C0();
        } else {
            this.f2492g.mo366b();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p */
    public void mo2739p(Fragment fragment) {
        if (m2484s0(2)) {
            Log.v("FragmentManager", "detach: " + fragment);
        }
        if (!fragment.f2401A) {
            fragment.f2401A = true;
            if (fragment.f2430l) {
                if (m2484s0(2)) {
                    Log.v("FragmentManager", "remove from detach: " + fragment);
                }
                this.f2488c.mo2862s(fragment);
                if (m2485t0(fragment)) {
                    this.f2475B = true;
                }
                m2470Q0(fragment);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p0 */
    public void mo2740p0(Fragment fragment) {
        if (m2484s0(2)) {
            Log.v("FragmentManager", "hide: " + fragment);
        }
        if (!fragment.f2444z) {
            fragment.f2444z = true;
            fragment.f2410J = true ^ fragment.f2410J;
            m2470Q0(fragment);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q */
    public void mo2741q() {
        this.f2476C = false;
        this.f2477D = false;
        this.f2484K.mo3044l(false);
        m2467K(4);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q0 */
    public void mo2742q0(Fragment fragment) {
        if (fragment.f2430l && m2485t0(fragment)) {
            this.f2475B = true;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: r */
    public void mo2743r() {
        this.f2476C = false;
        this.f2477D = false;
        this.f2484K.mo3044l(false);
        m2467K(0);
    }

    /* renamed from: r0 */
    public boolean mo2744r0() {
        return this.f2478E;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: s */
    public void mo2745s(Configuration configuration) {
        for (Fragment next : this.f2488c.mo2857n()) {
            if (next != null) {
                next.onConfigurationChanged(configuration);
                next.f2439u.mo2745s(configuration);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: t */
    public boolean mo2746t(MenuItem menuItem) {
        if (this.f2502q < 1) {
            return false;
        }
        for (Fragment next : this.f2488c.mo2857n()) {
            if (next != null) {
                if (!next.f2444z ? next.mo2557L3() ? true : next.f2439u.mo2746t(menuItem) : false) {
                    return true;
                }
            }
        }
        return false;
    }

    public String toString() {
        Object obj;
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        Fragment fragment = this.f2505t;
        if (fragment != null) {
            sb.append(fragment.getClass().getSimpleName());
            sb.append("{");
            obj = this.f2505t;
        } else {
            C0611u<?> uVar = this.f2503r;
            if (uVar != null) {
                sb.append(uVar.getClass().getSimpleName());
                sb.append("{");
                obj = this.f2503r;
            } else {
                sb.append("null");
                sb.append("}}");
                return sb.toString();
            }
        }
        sb.append(Integer.toHexString(System.identityHashCode(obj)));
        sb.append("}");
        sb.append("}}");
        return sb.toString();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: u */
    public void mo2748u() {
        this.f2476C = false;
        this.f2477D = false;
        this.f2484K.mo3044l(false);
        m2467K(1);
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0008, code lost:
        r1 = r3.f2437s;
     */
    /* renamed from: u0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo2749u0(androidx.fragment.app.Fragment r3) {
        /*
            r2 = this;
            r0 = 1
            if (r3 != 0) goto L_0x0004
            return r0
        L_0x0004:
            boolean r1 = r3.f2403C
            if (r1 == 0) goto L_0x0015
            androidx.fragment.app.FragmentManager r1 = r3.f2437s
            if (r1 == 0) goto L_0x0016
            androidx.fragment.app.Fragment r3 = r3.f2440v
            boolean r3 = r1.mo2749u0(r3)
            if (r3 == 0) goto L_0x0015
            goto L_0x0016
        L_0x0015:
            r0 = 0
        L_0x0016:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.FragmentManager.mo2749u0(androidx.fragment.app.Fragment):boolean");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: v */
    public boolean mo2750v(Menu menu, MenuInflater menuInflater) {
        if (this.f2502q < 1) {
            return false;
        }
        ArrayList<Fragment> arrayList = null;
        boolean z = false;
        for (Fragment next : this.f2488c.mo2857n()) {
            if (next != null && mo2749u0(next)) {
                if (!next.f2444z ? next.f2439u.mo2750v(menu, menuInflater) | false : false) {
                    if (arrayList == null) {
                        arrayList = new ArrayList<>();
                    }
                    arrayList.add(next);
                    z = true;
                }
            }
        }
        if (this.f2490e != null) {
            for (int i = 0; i < this.f2490e.size(); i++) {
                Fragment fragment = this.f2490e.get(i);
                if (arrayList == null || !arrayList.contains(fragment)) {
                    Objects.requireNonNull(fragment);
                }
            }
        }
        this.f2490e = arrayList;
        return z;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: v0 */
    public boolean mo2751v0(Fragment fragment) {
        if (fragment == null) {
            return true;
        }
        FragmentManager fragmentManager = fragment.f2437s;
        if (!fragment.equals(fragmentManager.f2506u) || !mo2751v0(fragmentManager.f2505t)) {
            return false;
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: w */
    public void mo2752w() {
        this.f2478E = true;
        mo2711S(true);
        m2469P();
        m2467K(-1);
        this.f2503r = null;
        this.f2504s = null;
        this.f2505t = null;
        if (this.f2492g != null) {
            this.f2493h.mo371d();
            this.f2492g = null;
        }
        C0099b<Intent> bVar = this.f2509x;
        if (bVar != null) {
            bVar.mo393b();
            this.f2510y.mo393b();
            this.f2511z.mo393b();
        }
    }

    /* renamed from: w0 */
    public boolean mo2753w0() {
        return this.f2476C || this.f2477D;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: x */
    public void mo2754x() {
        m2467K(1);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: x0 */
    public void mo2755x0(Fragment fragment, Intent intent, int i, Bundle bundle) {
        if (this.f2509x != null) {
            this.f2474A.addLast(new LaunchedFragmentInfo(fragment.f2424f, i));
            if (!(intent == null || bundle == null)) {
                intent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundle);
            }
            this.f2509x.mo392a(intent, (C0445b) null);
            return;
        }
        this.f2503r.mo3015j(intent, i, bundle);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: y */
    public void mo2756y() {
        for (Fragment next : this.f2488c.mo2857n()) {
            if (next != null) {
                next.mo2616p4();
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: y0 */
    public void mo2757y0(int i, boolean z) {
        C0611u<?> uVar;
        if (this.f2503r == null && i != -1) {
            throw new IllegalStateException("No activity");
        } else if (z || i != this.f2502q) {
            this.f2502q = i;
            this.f2488c.mo2861r();
            m2472S0();
            if (this.f2475B && (uVar = this.f2503r) != null && this.f2502q == 7) {
                uVar.mo2666k();
                this.f2475B = false;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: z */
    public void mo2758z(boolean z) {
        for (Fragment next : this.f2488c.mo2857n()) {
            if (next != null) {
                next.mo2576X3();
                next.f2439u.mo2758z(z);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x005d, code lost:
        if (r1 != 5) goto L_0x01bf;
     */
    /* JADX WARNING: Removed duplicated region for block: B:100:0x01bb  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x006d  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0072  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0077  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x007c  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x0081  */
    /* renamed from: z0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2759z0(androidx.fragment.app.Fragment r17, int r18) {
        /*
            r16 = this;
            r0 = r16
            r7 = r17
            androidx.fragment.app.b0 r1 = r0.f2488c
            java.lang.String r2 = r7.f2424f
            androidx.fragment.app.a0 r1 = r1.mo2856m(r2)
            r8 = 1
            if (r1 != 0) goto L_0x001b
            androidx.fragment.app.a0 r1 = new androidx.fragment.app.a0
            androidx.fragment.app.w r2 = r0.f2500o
            androidx.fragment.app.b0 r3 = r0.f2488c
            r1.<init>(r2, r3, r7)
            r1.mo2824r(r8)
        L_0x001b:
            r9 = r1
            boolean r1 = r7.f2432n
            r10 = 2
            if (r1 == 0) goto L_0x0030
            boolean r1 = r7.f2433o
            if (r1 == 0) goto L_0x0030
            int r1 = r7.f2420b
            if (r1 != r10) goto L_0x0030
            r1 = r18
            int r1 = java.lang.Math.max(r1, r10)
            goto L_0x0032
        L_0x0030:
            r1 = r18
        L_0x0032:
            int r2 = r9.mo2810d()
            int r11 = java.lang.Math.min(r1, r2)
            int r1 = r7.f2420b
            r12 = 3
            java.lang.String r13 = "FragmentManager"
            r2 = -1
            r3 = 5
            r4 = 4
            if (r1 > r11) goto L_0x0086
            if (r1 >= r11) goto L_0x0051
            java.util.Map<androidx.fragment.app.Fragment, java.util.HashSet<d.g.f.a>> r1 = r0.f2498m
            boolean r1 = r1.isEmpty()
            if (r1 != 0) goto L_0x0051
            r16.m2480j(r17)
        L_0x0051:
            int r1 = r7.f2420b
            if (r1 == r2) goto L_0x0061
            if (r1 == 0) goto L_0x0066
            if (r1 == r8) goto L_0x006b
            if (r1 == r10) goto L_0x0075
            if (r1 == r4) goto L_0x007a
            if (r1 == r3) goto L_0x007f
            goto L_0x01bf
        L_0x0061:
            if (r11 <= r2) goto L_0x0066
            r9.mo2809c()
        L_0x0066:
            if (r11 <= 0) goto L_0x006b
            r9.mo2811e()
        L_0x006b:
            if (r11 <= r2) goto L_0x0070
            r9.mo2816j()
        L_0x0070:
            if (r11 <= r8) goto L_0x0075
            r9.mo2812f()
        L_0x0075:
            if (r11 <= r10) goto L_0x007a
            r9.mo2807a()
        L_0x007a:
            if (r11 <= r4) goto L_0x007f
            r9.mo2825s()
        L_0x007f:
            if (r11 <= r3) goto L_0x01bf
            r9.mo2821o()
            goto L_0x01bf
        L_0x0086:
            if (r1 <= r11) goto L_0x01bf
            if (r1 == 0) goto L_0x01b8
            if (r1 == r8) goto L_0x01a8
            if (r1 == r10) goto L_0x00d0
            if (r1 == r4) goto L_0x00a1
            if (r1 == r3) goto L_0x009c
            r5 = 7
            if (r1 == r5) goto L_0x0097
            goto L_0x01bf
        L_0x0097:
            if (r11 >= r5) goto L_0x009c
            r9.mo2819m()
        L_0x009c:
            if (r11 >= r3) goto L_0x00a1
            r9.mo2826t()
        L_0x00a1:
            if (r11 >= r4) goto L_0x00d0
            boolean r1 = m2484s0(r12)
            if (r1 == 0) goto L_0x00bd
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = "movefrom ACTIVITY_CREATED: "
            r1.append(r3)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            android.util.Log.d(r13, r1)
        L_0x00bd:
            android.view.View r1 = r7.f2406F
            if (r1 == 0) goto L_0x00d0
            androidx.fragment.app.u<?> r1 = r0.f2503r
            boolean r1 = r1.mo2665i(r7)
            if (r1 == 0) goto L_0x00d0
            android.util.SparseArray<android.os.Parcelable> r1 = r7.f2422d
            if (r1 != 0) goto L_0x00d0
            r9.mo2823q()
        L_0x00d0:
            if (r11 >= r10) goto L_0x01a8
            r1 = 0
            android.view.View r3 = r7.f2406F
            if (r3 == 0) goto L_0x019d
            android.view.ViewGroup r4 = r7.f2405E
            if (r4 == 0) goto L_0x019d
            r4.endViewTransition(r3)
            android.view.View r3 = r7.f2406F
            r3.clearAnimation()
            boolean r3 = r17.mo2539C3()
            if (r3 != 0) goto L_0x019d
            int r3 = r0.f2502q
            r4 = 0
            if (r3 <= r2) goto L_0x010f
            boolean r2 = r0.f2478E
            if (r2 != 0) goto L_0x010f
            android.view.View r2 = r7.f2406F
            int r2 = r2.getVisibility()
            if (r2 != 0) goto L_0x010f
            float r2 = r7.f2411K
            int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r2 < 0) goto L_0x010f
            androidx.fragment.app.u<?> r1 = r0.f2503r
            android.content.Context r1 = r1.mo3013e()
            r2 = 0
            boolean r3 = r17.mo2608n3()
            androidx.fragment.app.q$a r1 = androidx.fragment.app.C0596q.m2761a(r1, r7, r2, r3)
        L_0x010f:
            r7.f2411K = r4
            android.view.ViewGroup r14 = r7.f2405E
            android.view.View r15 = r7.f2406F
            if (r1 == 0) goto L_0x016b
            androidx.fragment.app.j0$a r5 = r0.f2499n
            r14.startViewTransition(r15)
            d.g.f.a r6 = new d.g.f.a
            r6.<init>()
            androidx.fragment.app.n r2 = new androidx.fragment.app.n
            r2.<init>(r7)
            r6.mo21777c(r2)
            r2 = r5
            androidx.fragment.app.FragmentManager$d r2 = (androidx.fragment.app.FragmentManager.C0527d) r2
            androidx.fragment.app.FragmentManager r2 = androidx.fragment.app.FragmentManager.this
            r2.mo2718c(r7, r6)
            android.view.animation.Animation r2 = r1.f2726a
            if (r2 == 0) goto L_0x014f
            androidx.fragment.app.q$b r2 = new androidx.fragment.app.q$b
            android.view.animation.Animation r1 = r1.f2726a
            r2.<init>(r1, r14, r15)
            android.view.View r1 = r7.f2406F
            r7.mo2538B4(r1)
            androidx.fragment.app.o r1 = new androidx.fragment.app.o
            r1.<init>(r14, r7, r5, r6)
            r2.setAnimationListener(r1)
            android.view.View r1 = r7.f2406F
            r1.startAnimation(r2)
            goto L_0x016b
        L_0x014f:
            android.animation.Animator r4 = r1.f2727b
            r7.mo2542D4(r4)
            androidx.fragment.app.p r3 = new androidx.fragment.app.p
            r1 = r3
            r2 = r14
            r12 = r3
            r3 = r15
            r8 = r4
            r4 = r17
            r1.<init>(r2, r3, r4, r5, r6)
            r8.addListener(r12)
            android.view.View r1 = r7.f2406F
            r8.setTarget(r1)
            r8.start()
        L_0x016b:
            r14.removeView(r15)
            boolean r1 = m2484s0(r10)
            if (r1 == 0) goto L_0x0198
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Removing view "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r2 = " for fragment "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r2 = " from container "
            r1.append(r2)
            r1.append(r14)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r13, r1)
        L_0x0198:
            android.view.ViewGroup r1 = r7.f2405E
            if (r14 == r1) goto L_0x019d
            return
        L_0x019d:
            java.util.Map<androidx.fragment.app.Fragment, java.util.HashSet<d.g.f.a>> r1 = r0.f2498m
            java.lang.Object r1 = r1.get(r7)
            if (r1 != 0) goto L_0x01a8
            r9.mo2814h()
        L_0x01a8:
            r1 = 1
            if (r11 >= r1) goto L_0x01b8
            java.util.Map<androidx.fragment.app.Fragment, java.util.HashSet<d.g.f.a>> r2 = r0.f2498m
            java.lang.Object r2 = r2.get(r7)
            if (r2 == 0) goto L_0x01b5
            r8 = 1
            goto L_0x01b9
        L_0x01b5:
            r9.mo2813g()
        L_0x01b8:
            r8 = r11
        L_0x01b9:
            if (r8 >= 0) goto L_0x01be
            r9.mo2815i()
        L_0x01be:
            r11 = r8
        L_0x01bf:
            int r1 = r7.f2420b
            if (r1 == r11) goto L_0x01f2
            r1 = 3
            boolean r1 = m2484s0(r1)
            if (r1 == 0) goto L_0x01f0
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "moveToState: Fragment state for "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r2 = " not updated inline; expected state "
            r1.append(r2)
            r1.append(r11)
            java.lang.String r2 = " found "
            r1.append(r2)
            int r2 = r7.f2420b
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.d(r13, r1)
        L_0x01f0:
            r7.f2420b = r11
        L_0x01f2:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.FragmentManager.mo2759z0(androidx.fragment.app.Fragment, int):void");
    }
}
