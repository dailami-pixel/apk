package androidx.fragment.app;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.fragment.app.FragmentManager;
import java.util.ArrayList;

final class FragmentManagerState implements Parcelable {
    public static final Parcelable.Creator<FragmentManagerState> CREATOR = new C0539a();

    /* renamed from: a */
    ArrayList<FragmentState> f2528a;

    /* renamed from: b */
    ArrayList<String> f2529b;

    /* renamed from: c */
    BackStackState[] f2530c;

    /* renamed from: d */
    int f2531d;

    /* renamed from: e */
    String f2532e = null;

    /* renamed from: f */
    ArrayList<String> f2533f = new ArrayList<>();

    /* renamed from: g */
    ArrayList<Bundle> f2534g = new ArrayList<>();

    /* renamed from: h */
    ArrayList<FragmentManager.LaunchedFragmentInfo> f2535h;

    /* renamed from: androidx.fragment.app.FragmentManagerState$a */
    class C0539a implements Parcelable.Creator<FragmentManagerState> {
        C0539a() {
        }

        public Object createFromParcel(Parcel parcel) {
            return new FragmentManagerState(parcel);
        }

        public Object[] newArray(int i) {
            return new FragmentManagerState[i];
        }
    }

    public FragmentManagerState() {
    }

    public FragmentManagerState(Parcel parcel) {
        this.f2528a = parcel.createTypedArrayList(FragmentState.CREATOR);
        this.f2529b = parcel.createStringArrayList();
        this.f2530c = (BackStackState[]) parcel.createTypedArray(BackStackState.CREATOR);
        this.f2531d = parcel.readInt();
        this.f2532e = parcel.readString();
        this.f2533f = parcel.createStringArrayList();
        this.f2534g = parcel.createTypedArrayList(Bundle.CREATOR);
        this.f2535h = parcel.createTypedArrayList(FragmentManager.LaunchedFragmentInfo.CREATOR);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedList(this.f2528a);
        parcel.writeStringList(this.f2529b);
        parcel.writeTypedArray(this.f2530c, i);
        parcel.writeInt(this.f2531d);
        parcel.writeString(this.f2532e);
        parcel.writeStringList(this.f2533f);
        parcel.writeTypedList(this.f2534g);
        parcel.writeTypedList(this.f2535h);
    }
}
