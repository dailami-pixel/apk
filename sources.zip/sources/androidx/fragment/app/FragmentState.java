package androidx.fragment.app;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

final class FragmentState implements Parcelable {
    public static final Parcelable.Creator<FragmentState> CREATOR = new C0540a();

    /* renamed from: a */
    final String f2536a;

    /* renamed from: b */
    final String f2537b;

    /* renamed from: c */
    final boolean f2538c;

    /* renamed from: d */
    final int f2539d;

    /* renamed from: e */
    final int f2540e;

    /* renamed from: f */
    final String f2541f;

    /* renamed from: g */
    final boolean f2542g;

    /* renamed from: h */
    final boolean f2543h;

    /* renamed from: i */
    final boolean f2544i;

    /* renamed from: j */
    final Bundle f2545j;

    /* renamed from: k */
    final boolean f2546k;

    /* renamed from: l */
    final int f2547l;

    /* renamed from: m */
    Bundle f2548m;

    /* renamed from: androidx.fragment.app.FragmentState$a */
    class C0540a implements Parcelable.Creator<FragmentState> {
        C0540a() {
        }

        public Object createFromParcel(Parcel parcel) {
            return new FragmentState(parcel);
        }

        public Object[] newArray(int i) {
            return new FragmentState[i];
        }
    }

    FragmentState(Parcel parcel) {
        this.f2536a = parcel.readString();
        this.f2537b = parcel.readString();
        boolean z = true;
        this.f2538c = parcel.readInt() != 0;
        this.f2539d = parcel.readInt();
        this.f2540e = parcel.readInt();
        this.f2541f = parcel.readString();
        this.f2542g = parcel.readInt() != 0;
        this.f2543h = parcel.readInt() != 0;
        this.f2544i = parcel.readInt() != 0;
        this.f2545j = parcel.readBundle();
        this.f2546k = parcel.readInt() == 0 ? false : z;
        this.f2548m = parcel.readBundle();
        this.f2547l = parcel.readInt();
    }

    FragmentState(Fragment fragment) {
        this.f2536a = fragment.getClass().getName();
        this.f2537b = fragment.f2424f;
        this.f2538c = fragment.f2432n;
        this.f2539d = fragment.f2441w;
        this.f2540e = fragment.f2442x;
        this.f2541f = fragment.f2443y;
        this.f2542g = fragment.f2402B;
        this.f2543h = fragment.f2431m;
        this.f2544i = fragment.f2401A;
        this.f2545j = fragment.f2425g;
        this.f2546k = fragment.f2444z;
        this.f2547l = fragment.f2414N.ordinal();
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentState{");
        sb.append(this.f2536a);
        sb.append(" (");
        sb.append(this.f2537b);
        sb.append(")}:");
        if (this.f2538c) {
            sb.append(" fromLayout");
        }
        if (this.f2540e != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f2540e));
        }
        String str = this.f2541f;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(this.f2541f);
        }
        if (this.f2542g) {
            sb.append(" retainInstance");
        }
        if (this.f2543h) {
            sb.append(" removing");
        }
        if (this.f2544i) {
            sb.append(" detached");
        }
        if (this.f2546k) {
            sb.append(" hidden");
        }
        return sb.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f2536a);
        parcel.writeString(this.f2537b);
        parcel.writeInt(this.f2538c ? 1 : 0);
        parcel.writeInt(this.f2539d);
        parcel.writeInt(this.f2540e);
        parcel.writeString(this.f2541f);
        parcel.writeInt(this.f2542g ? 1 : 0);
        parcel.writeInt(this.f2543h ? 1 : 0);
        parcel.writeInt(this.f2544i ? 1 : 0);
        parcel.writeBundle(this.f2545j);
        parcel.writeInt(this.f2546k ? 1 : 0);
        parcel.writeBundle(this.f2548m);
        parcel.writeInt(this.f2547l);
    }
}
