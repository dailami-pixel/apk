package androidx.fragment.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TabHost;
import java.util.ArrayList;
import java.util.Objects;
import p165e.p166a.p167a.p168a.C4924a;

@Deprecated
public class FragmentTabHost extends TabHost implements TabHost.OnTabChangeListener {

    /* renamed from: a */
    private final ArrayList<C0542a> f2549a = new ArrayList<>();

    /* renamed from: b */
    private int f2550b;

    /* renamed from: c */
    private TabHost.OnTabChangeListener f2551c;

    /* renamed from: d */
    private boolean f2552d;

    static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0541a();

        /* renamed from: a */
        String f2553a;

        /* renamed from: androidx.fragment.app.FragmentTabHost$SavedState$a */
        class C0541a implements Parcelable.Creator<SavedState> {
            C0541a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public Object[] newArray(int i) {
                return new SavedState[i];
            }
        }

        SavedState(Parcel parcel) {
            super(parcel);
            this.f2553a = parcel.readString();
        }

        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder P = C4924a.m17863P("FragmentTabHost.SavedState{");
            P.append(Integer.toHexString(System.identityHashCode(this)));
            P.append(" curTab=");
            return C4924a.m17852E(P, this.f2553a, "}");
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeString(this.f2553a);
        }
    }

    /* renamed from: androidx.fragment.app.FragmentTabHost$a */
    static final class C0542a {
    }

    @Deprecated
    public FragmentTabHost(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, new int[]{16842995}, 0, 0);
        this.f2550b = obtainStyledAttributes.getResourceId(0, 0);
        obtainStyledAttributes.recycle();
        super.setOnTabChangedListener(this);
    }

    /* renamed from: a */
    private C0553c0 m2578a(String str, C0553c0 c0Var) {
        if (this.f2549a.size() <= 0) {
            return null;
        }
        Objects.requireNonNull(this.f2549a.get(0));
        throw null;
    }

    /* access modifiers changed from: protected */
    @Deprecated
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        String currentTabTag = getCurrentTabTag();
        if (this.f2549a.size() <= 0) {
            this.f2552d = true;
            C0553c0 a = m2578a(currentTabTag, (C0553c0) null);
            if (a != null) {
                a.mo2794e();
                throw null;
            }
            return;
        }
        Objects.requireNonNull(this.f2549a.get(0));
        throw null;
    }

    /* access modifiers changed from: protected */
    @Deprecated
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f2552d = false;
    }

    /* access modifiers changed from: protected */
    @Deprecated
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        setCurrentTabByTag(savedState.f2553a);
    }

    /* access modifiers changed from: protected */
    @Deprecated
    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.f2553a = getCurrentTabTag();
        return savedState;
    }

    @Deprecated
    public void onTabChanged(String str) {
        C0553c0 a;
        if (this.f2552d && (a = m2578a(str, (C0553c0) null)) != null) {
            a.mo2794e();
        }
        TabHost.OnTabChangeListener onTabChangeListener = this.f2551c;
        if (onTabChangeListener != null) {
            onTabChangeListener.onTabChanged(str);
        }
    }

    @Deprecated
    public void setOnTabChangedListener(TabHost.OnTabChangeListener onTabChangeListener) {
        this.f2551c = onTabChangeListener;
    }

    @Deprecated
    public void setup() {
        throw new IllegalStateException("Must call setup() that takes a Context and FragmentManager");
    }
}
