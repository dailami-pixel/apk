package androidx.leanback.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.leanback.widget.C0781c0;
import androidx.leanback.widget.C0802g0;
import androidx.leanback.widget.C0858q0;
import androidx.leanback.widget.C0878y;
import androidx.leanback.widget.VerticalGridView;
import androidx.recyclerview.widget.RecyclerView;

/* renamed from: androidx.leanback.app.a */
abstract class C0620a extends Fragment {

    /* renamed from: a0 */
    private C0781c0 f2778a0;

    /* renamed from: b0 */
    VerticalGridView f2779b0;

    /* renamed from: c0 */
    private C0858q0 f2780c0;

    /* renamed from: d0 */
    final C0878y f2781d0 = new C0878y();

    /* renamed from: e0 */
    int f2782e0 = -1;

    /* renamed from: f0 */
    private boolean f2783f0;

    /* renamed from: g0 */
    C0622b f2784g0 = new C0622b();

    /* renamed from: h0 */
    private final C0802g0 f2785h0 = new C0621a();

    /* renamed from: androidx.leanback.app.a$a */
    class C0621a extends C0802g0 {
        C0621a() {
        }

        /* renamed from: a */
        public void mo3059a(RecyclerView recyclerView, RecyclerView.C1142b0 b0Var, int i, int i2) {
            C0620a aVar = C0620a.this;
            if (!aVar.f2784g0.f2787a) {
                aVar.f2782e0 = i;
                aVar.mo3051R4(recyclerView, b0Var, i, i2);
            }
        }
    }

    /* renamed from: androidx.leanback.app.a$b */
    private class C0622b extends RecyclerView.C1149i {

        /* renamed from: a */
        boolean f2787a = false;

        C0622b() {
        }

        /* renamed from: a */
        public void mo3060a() {
            mo3062f();
        }

        /* renamed from: c */
        public void mo3061c(int i, int i2) {
            mo3062f();
        }

        /* access modifiers changed from: package-private */
        /* renamed from: f */
        public void mo3062f() {
            if (this.f2787a) {
                this.f2787a = false;
                C0620a.this.f2781d0.unregisterAdapterDataObserver(this);
            }
            C0620a aVar = C0620a.this;
            VerticalGridView verticalGridView = aVar.f2779b0;
            if (verticalGridView != null) {
                verticalGridView.mo3737x(aVar.f2782e0);
            }
        }
    }

    C0620a() {
    }

    /* renamed from: P3 */
    public View mo2565P3(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(mo3050Q4(), viewGroup, false);
        this.f2779b0 = mo3049P4(inflate);
        if (this.f2783f0) {
            this.f2783f0 = false;
            mo3053T4();
        }
        return inflate;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: P4 */
    public abstract VerticalGridView mo3049P4(View view);

    /* access modifiers changed from: package-private */
    /* renamed from: Q4 */
    public abstract int mo3050Q4();

    /* renamed from: R3 */
    public void mo2567R3() {
        super.mo2567R3();
        C0622b bVar = this.f2784g0;
        if (bVar.f2787a) {
            bVar.f2787a = false;
            C0620a.this.f2781d0.unregisterAdapterDataObserver(bVar);
        }
        this.f2779b0 = null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: R4 */
    public abstract void mo3051R4(RecyclerView recyclerView, RecyclerView.C1142b0 b0Var, int i, int i2);

    /* renamed from: S4 */
    public void mo3052S4() {
        VerticalGridView verticalGridView = this.f2779b0;
        if (verticalGridView != null) {
            verticalGridView.setLayoutFrozen(false);
            this.f2779b0.mo3712g(true);
            this.f2779b0.mo3734u(true);
            this.f2779b0.mo3718k(false);
            this.f2779b0.mo3736w(true);
        }
    }

    /* renamed from: T4 */
    public boolean mo3053T4() {
        VerticalGridView verticalGridView = this.f2779b0;
        if (verticalGridView != null) {
            verticalGridView.mo3712g(false);
            this.f2779b0.mo3736w(false);
            return true;
        }
        this.f2783f0 = true;
        return false;
    }

    /* renamed from: U4 */
    public final void mo3054U4(C0781c0 c0Var) {
        if (this.f2778a0 != c0Var) {
            this.f2778a0 = c0Var;
            mo3058Y4();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: V4 */
    public void mo3055V4() {
        if (this.f2778a0 != null) {
            RecyclerView.C1147g adapter = this.f2779b0.getAdapter();
            C0878y yVar = this.f2781d0;
            if (adapter != yVar) {
                this.f2779b0.setAdapter(yVar);
            }
            if (this.f2781d0.getItemCount() == 0 && this.f2782e0 >= 0) {
                C0622b bVar = this.f2784g0;
                bVar.f2787a = true;
                C0620a.this.f2781d0.registerAdapterDataObserver(bVar);
                return;
            }
            int i = this.f2782e0;
            if (i >= 0) {
                this.f2779b0.mo3737x(i);
            }
        }
    }

    /* renamed from: W4 */
    public final void mo3056W4(C0858q0 q0Var) {
        if (this.f2780c0 != q0Var) {
            this.f2780c0 = q0Var;
            mo3058Y4();
        }
    }

    /* renamed from: X4 */
    public void mo3057X4(int i, boolean z) {
        if (this.f2782e0 != i) {
            this.f2782e0 = i;
            VerticalGridView verticalGridView = this.f2779b0;
            if (verticalGridView != null && !this.f2784g0.f2787a) {
                if (z) {
                    verticalGridView.mo3739z(i);
                } else {
                    verticalGridView.mo3737x(i);
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Y4 */
    public void mo3058Y4() {
        this.f2781d0.mo3891i(this.f2778a0);
        this.f2781d0.mo3893k(this.f2780c0);
        if (this.f2779b0 != null) {
            mo3055V4();
        }
    }

    /* renamed from: g4 */
    public void mo2595g4(View view, Bundle bundle) {
        if (bundle != null) {
            this.f2782e0 = bundle.getInt("currentSelectedPosition", -1);
        }
        mo3055V4();
        this.f2779b0.mo3727q(this.f2785h0);
    }
}
