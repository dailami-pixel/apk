package androidx.leanback.app;

import android.os.Bundle;
import android.view.View;
import p098d.p140l.p145g.C4843a;

/* renamed from: androidx.leanback.app.b */
public class C0623b extends C0631e {

    /* renamed from: g0 */
    final C4843a.C4846c f2789g0 = new C4843a.C4846c("START", true, false);

    /* renamed from: h0 */
    final C4843a.C4846c f2790h0 = new C4843a.C4846c("ENTRANCE_INIT", false, true);

    /* renamed from: i0 */
    final C4843a.C4846c f2791i0 = new C0624a("ENTRANCE_ON_PREPARED", true, false);

    /* renamed from: j0 */
    final C4843a.C4846c f2792j0 = new C0625b("ENTRANCE_ON_PREPARED_ON_CREATEVIEW");

    /* renamed from: k0 */
    final C4843a.C4846c f2793k0 = new C0626c("STATE_ENTRANCE_PERFORM");

    /* renamed from: l0 */
    final C4843a.C4846c f2794l0 = new C0627d("ENTRANCE_ON_ENDED");

    /* renamed from: m0 */
    final C4843a.C4846c f2795m0 = new C4843a.C4846c("ENTRANCE_COMPLETE", true, false);

    /* renamed from: n0 */
    final C4843a.C4845b f2796n0 = new C4843a.C4845b("onCreate");

    /* renamed from: o0 */
    final C4843a.C4845b f2797o0 = new C4843a.C4845b("onCreateView");

    /* renamed from: p0 */
    final C4843a.C4845b f2798p0 = new C4843a.C4845b("prepareEntranceTransition");

    /* renamed from: q0 */
    final C4843a.C4845b f2799q0 = new C4843a.C4845b("startEntranceTransition");

    /* renamed from: r0 */
    final C4843a.C4845b f2800r0 = new C4843a.C4845b("onEntranceTransitionEnd");

    /* renamed from: s0 */
    final C4843a.C4844a f2801s0 = new C0628e(this, "EntranceTransitionNotSupport");

    /* renamed from: t0 */
    final C4843a f2802t0 = new C4843a();

    /* renamed from: u0 */
    Object f2803u0;

    /* renamed from: v0 */
    final C0683p f2804v0 = new C0683p();

    /* renamed from: androidx.leanback.app.b$a */
    class C0624a extends C4843a.C4846c {
        C0624a(String str, boolean z, boolean z2) {
            super(str, z, z2);
        }

        /* renamed from: c */
        public void mo3070c() {
            C0623b.this.f2804v0.mo3210d();
        }
    }

    /* renamed from: androidx.leanback.app.b$b */
    class C0625b extends C4843a.C4846c {
        C0625b(String str) {
            super(str, false, true);
        }

        /* renamed from: c */
        public void mo3070c() {
            C0623b.this.mo3067c5();
        }
    }

    /* renamed from: androidx.leanback.app.b$c */
    class C0626c extends C4843a.C4846c {
        C0626c(String str) {
            super(str, false, true);
        }

        /* renamed from: c */
        public void mo3070c() {
            C0623b.this.f2804v0.mo3207a();
            C0623b bVar = C0623b.this;
            View x3 = bVar.mo2633x3();
            if (x3 != null) {
                x3.getViewTreeObserver().addOnPreDrawListener(new C0629c(bVar, x3));
                x3.invalidate();
            }
        }
    }

    /* renamed from: androidx.leanback.app.b$d */
    class C0627d extends C4843a.C4846c {
        C0627d(String str) {
            super(str, false, true);
        }

        /* renamed from: c */
        public void mo3070c() {
            C0623b.this.mo3066b5();
        }
    }

    /* renamed from: androidx.leanback.app.b$e */
    class C0628e extends C4843a.C4844a {
        C0628e(C0623b bVar, String str) {
            super(str);
        }
    }

    C0623b() {
    }

    /* renamed from: M3 */
    public void mo2559M3(Bundle bundle) {
        mo3064Z4();
        mo3065a5();
        this.f2802t0.mo22124g();
        super.mo2559M3(bundle);
        this.f2802t0.mo22122e(this.f2796n0);
    }

    /* access modifiers changed from: protected */
    /* renamed from: Y4 */
    public Object mo3063Y4() {
        throw null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Z4 */
    public void mo3064Z4() {
        this.f2802t0.mo22118a(this.f2789g0);
        this.f2802t0.mo22118a(this.f2790h0);
        this.f2802t0.mo22118a(this.f2791i0);
        this.f2802t0.mo22118a(this.f2792j0);
        this.f2802t0.mo22118a(this.f2793k0);
        this.f2802t0.mo22118a(this.f2794l0);
        this.f2802t0.mo22118a(this.f2795m0);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a5 */
    public void mo3065a5() {
        this.f2802t0.mo22121d(this.f2789g0, this.f2790h0, this.f2796n0);
        this.f2802t0.mo22120c(this.f2790h0, this.f2795m0, this.f2801s0);
        this.f2802t0.mo22121d(this.f2790h0, this.f2795m0, this.f2797o0);
        this.f2802t0.mo22121d(this.f2790h0, this.f2791i0, this.f2798p0);
        this.f2802t0.mo22121d(this.f2791i0, this.f2792j0, this.f2797o0);
        this.f2802t0.mo22121d(this.f2791i0, this.f2793k0, this.f2799q0);
        this.f2802t0.mo22119b(this.f2792j0, this.f2793k0);
        this.f2802t0.mo22121d(this.f2793k0, this.f2794l0, this.f2800r0);
        this.f2802t0.mo22119b(this.f2794l0, this.f2795m0);
    }

    /* access modifiers changed from: protected */
    /* renamed from: b5 */
    public void mo3066b5() {
    }

    /* access modifiers changed from: protected */
    /* renamed from: c5 */
    public void mo3067c5() {
    }

    /* access modifiers changed from: protected */
    /* renamed from: d5 */
    public void mo3068d5() {
    }

    /* access modifiers changed from: protected */
    /* renamed from: e5 */
    public void mo3069e5(Object obj) {
        throw null;
    }

    /* renamed from: g4 */
    public void mo2595g4(View view, Bundle bundle) {
        super.mo2595g4(view, bundle);
        this.f2802t0.mo22122e(this.f2797o0);
    }
}
