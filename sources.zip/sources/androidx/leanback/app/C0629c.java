package androidx.leanback.app;

import android.view.View;
import android.view.ViewTreeObserver;
import androidx.leanback.transition.C0729a;

/* renamed from: androidx.leanback.app.c */
class C0629c implements ViewTreeObserver.OnPreDrawListener {

    /* renamed from: a */
    final /* synthetic */ View f2809a;

    /* renamed from: b */
    final /* synthetic */ C0623b f2810b;

    C0629c(C0623b bVar, View view) {
        this.f2810b = bVar;
        this.f2809a = view;
    }

    public boolean onPreDraw() {
        this.f2809a.getViewTreeObserver().removeOnPreDrawListener(this);
        if (this.f2810b.mo2583b3() == null || this.f2810b.mo2633x3() == null) {
            return true;
        }
        C0623b bVar = this.f2810b;
        Object Y4 = bVar.mo3063Y4();
        bVar.f2803u0 = Y4;
        if (Y4 != null) {
            C0729a.m3169a(Y4, new C0630d(bVar));
        }
        this.f2810b.mo3068d5();
        C0623b bVar2 = this.f2810b;
        Object obj = bVar2.f2803u0;
        if (obj != null) {
            bVar2.mo3069e5(obj);
            return false;
        }
        bVar2.f2802t0.mo22122e(bVar2.f2800r0);
        return false;
    }
}
