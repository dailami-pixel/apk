package androidx.leanback.app;

import androidx.leanback.transition.C0731b;

/* renamed from: androidx.leanback.app.d */
class C0630d extends C0731b {

    /* renamed from: b */
    final /* synthetic */ C0623b f2811b;

    C0630d(C0623b bVar) {
        this.f2811b = bVar;
    }

    /* renamed from: a */
    public void mo3072a(Object obj) {
        C0623b bVar = this.f2811b;
        bVar.f2803u0 = null;
        bVar.f2802t0.mo22122e(bVar.f2800r0);
    }
}
