package androidx.leanback.app;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.leanback.widget.C0803g1;
import androidx.leanback.widget.C0815j1;
import com.vidio.android.p195tv.R;

/* renamed from: androidx.leanback.app.e */
public class C0631e extends Fragment {

    /* renamed from: a0 */
    private boolean f2812a0 = true;

    /* renamed from: b0 */
    private CharSequence f2813b0;

    /* renamed from: c0 */
    private View f2814c0;

    /* renamed from: d0 */
    private C0815j1 f2815d0;

    /* renamed from: e0 */
    private View.OnClickListener f2816e0;

    /* renamed from: f0 */
    private C0803g1 f2817f0;

    /* access modifiers changed from: package-private */
    /* renamed from: P4 */
    public C0803g1 mo3073P4() {
        return this.f2817f0;
    }

    /* renamed from: Q4 */
    public View mo3074Q4() {
        return this.f2814c0;
    }

    /* renamed from: R3 */
    public void mo2567R3() {
        super.mo2567R3();
        this.f2817f0 = null;
    }

    /* renamed from: R4 */
    public C0815j1 mo3075R4() {
        return this.f2815d0;
    }

    /* renamed from: S4 */
    public void mo3076S4(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view;
        View T4 = mo3077T4(layoutInflater, viewGroup);
        if (T4 != null) {
            viewGroup.addView(T4);
            view = T4.findViewById(R.id.browse_title_group);
        } else {
            view = null;
        }
        mo3079V4(view);
    }

    /* renamed from: T4 */
    public View mo3077T4(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        TypedValue typedValue = new TypedValue();
        return layoutInflater.inflate(viewGroup.getContext().getTheme().resolveAttribute(R.attr.browseTitleViewLayout, typedValue, true) ? typedValue.resourceId : R.layout.lb_browse_title, viewGroup, false);
    }

    /* renamed from: U4 */
    public void mo3078U4(CharSequence charSequence) {
        this.f2813b0 = charSequence;
        C0815j1 j1Var = this.f2815d0;
        if (j1Var != null) {
            j1Var.mo3603e(charSequence);
        }
    }

    /* renamed from: V4 */
    public void mo3079V4(View view) {
        this.f2814c0 = view;
        if (view == null) {
            this.f2815d0 = null;
            this.f2817f0 = null;
            return;
        }
        C0815j1 a = ((C0815j1.C0816a) view).mo3592a();
        this.f2815d0 = a;
        a.mo3603e(this.f2813b0);
        this.f2815d0.mo3601c((Drawable) null);
        View.OnClickListener onClickListener = this.f2816e0;
        if (onClickListener != null) {
            this.f2816e0 = onClickListener;
            C0815j1 j1Var = this.f2815d0;
            if (j1Var != null) {
                j1Var.mo3602d(onClickListener);
            }
        }
        if (mo2633x3() instanceof ViewGroup) {
            this.f2817f0 = new C0803g1((ViewGroup) mo2633x3(), this.f2814c0);
        }
    }

    /* renamed from: W4 */
    public void mo3080W4(int i) {
        C0815j1 j1Var = this.f2815d0;
        if (j1Var != null) {
            j1Var.mo3604f(i);
        }
        mo3081X4(true);
    }

    /* renamed from: X4 */
    public void mo3081X4(boolean z) {
        if (z != this.f2812a0) {
            this.f2812a0 = z;
            C0803g1 g1Var = this.f2817f0;
            if (g1Var != null) {
                g1Var.mo3745b(z);
            }
        }
    }

    /* renamed from: Y3 */
    public void mo2578Y3() {
        C0815j1 j1Var = this.f2815d0;
        if (j1Var != null) {
            j1Var.mo3600b(false);
        }
        super.mo2578Y3();
    }

    /* renamed from: c4 */
    public void mo2586c4() {
        super.mo2586c4();
        C0815j1 j1Var = this.f2815d0;
        if (j1Var != null) {
            j1Var.mo3600b(true);
        }
    }

    /* renamed from: d4 */
    public void mo2588d4(Bundle bundle) {
        bundle.putBoolean("titleShow", this.f2812a0);
    }

    /* renamed from: e4 */
    public void mo2590e4() {
        super.mo2590e4();
        if (this.f2815d0 != null) {
            mo3081X4(this.f2812a0);
            this.f2815d0.mo3600b(true);
        }
    }

    /* renamed from: g4 */
    public void mo2595g4(View view, Bundle bundle) {
        if (bundle != null) {
            this.f2812a0 = bundle.getBoolean("titleShow");
        }
        View view2 = this.f2814c0;
        if (view2 != null && (view instanceof ViewGroup)) {
            C0803g1 g1Var = new C0803g1((ViewGroup) view, view2);
            this.f2817f0 = g1Var;
            g1Var.mo3745b(this.f2812a0);
        }
    }
}
