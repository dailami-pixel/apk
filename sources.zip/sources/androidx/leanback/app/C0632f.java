package androidx.leanback.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import androidx.fragment.app.C0553c0;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.leanback.app.C0657i;
import androidx.leanback.app.C0685q;
import androidx.leanback.transition.C0729a;
import androidx.leanback.widget.BrowseFrameLayout;
import androidx.leanback.widget.C0767a0;
import androidx.leanback.widget.C0781c0;
import androidx.leanback.widget.C0806h0;
import androidx.leanback.widget.C0811i0;
import androidx.leanback.widget.C0844p0;
import androidx.leanback.widget.C0858q0;
import androidx.leanback.widget.C0864t0;
import androidx.leanback.widget.C0865u;
import androidx.leanback.widget.C0870v0;
import androidx.leanback.widget.ScaleFrameLayout;
import androidx.leanback.widget.VerticalGridView;
import androidx.recyclerview.widget.RecyclerView;
import com.vidio.android.p195tv.R;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import p098d.p120g.p130j.C4761m;
import p098d.p140l.C4825b;
import p098d.p140l.p145g.C4843a;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.leanback.app.f */
public class C0632f extends C0623b {

    /* renamed from: w0 */
    private static final String f2818w0 = (C0632f.class.getCanonicalName() + ".title");

    /* renamed from: x0 */
    private static final String f2819x0 = (C0632f.class.getCanonicalName() + ".headersState");

    /* renamed from: A0 */
    final C4843a.C4845b f2820A0 = new C4843a.C4845b("mainFragmentViewCreated");

    /* renamed from: B0 */
    final C4843a.C4845b f2821B0 = new C4843a.C4845b("screenDataReady");

    /* renamed from: C0 */
    private C0650r f2822C0 = new C0650r();

    /* renamed from: D0 */
    C0648p f2823D0;

    /* renamed from: E0 */
    Fragment f2824E0;

    /* renamed from: F0 */
    C0657i f2825F0;

    /* renamed from: G0 */
    C0652t f2826G0;

    /* renamed from: H0 */
    C0665j f2827H0;

    /* renamed from: I0 */
    private C0781c0 f2828I0;

    /* renamed from: J0 */
    private C0858q0 f2829J0;

    /* renamed from: K0 */
    private int f2830K0 = 1;

    /* renamed from: L0 */
    BrowseFrameLayout f2831L0;

    /* renamed from: M0 */
    private ScaleFrameLayout f2832M0;

    /* renamed from: N0 */
    boolean f2833N0 = true;

    /* renamed from: O0 */
    String f2834O0;

    /* renamed from: P0 */
    boolean f2835P0 = true;

    /* renamed from: Q0 */
    boolean f2836Q0 = true;

    /* renamed from: R0 */
    private int f2837R0;

    /* renamed from: S0 */
    private int f2838S0;

    /* renamed from: T0 */
    private boolean f2839T0 = true;

    /* renamed from: U0 */
    C0811i0 f2840U0;

    /* renamed from: V0 */
    private C0806h0 f2841V0;

    /* renamed from: W0 */
    private int f2842W0 = -1;

    /* renamed from: X0 */
    private float f2843X0;

    /* renamed from: Y0 */
    boolean f2844Y0;

    /* renamed from: Z0 */
    boolean f2845Z0 = true;

    /* renamed from: a1 */
    private final C0654v f2846a1 = new C0654v();

    /* renamed from: b1 */
    Object f2847b1;

    /* renamed from: c1 */
    Object f2848c1;

    /* renamed from: d1 */
    private Object f2849d1;

    /* renamed from: e1 */
    Object f2850e1;

    /* renamed from: f1 */
    C0643k f2851f1;

    /* renamed from: g1 */
    private final BrowseFrameLayout.C0740b f2852g1 = new C0638f();

    /* renamed from: h1 */
    private final BrowseFrameLayout.C0739a f2853h1 = new C0639g();

    /* renamed from: i1 */
    private C0657i.C0663e f2854i1 = new C0633a();

    /* renamed from: j1 */
    private C0657i.C0664f f2855j1 = new C0634b();

    /* renamed from: k1 */
    private final RecyclerView.C1166s f2856k1 = new C0635c();

    /* renamed from: y0 */
    final C4843a.C4846c f2857y0 = new C0636d("SET_ENTRANCE_START_STATE");

    /* renamed from: z0 */
    final C4843a.C4845b f2858z0 = new C4843a.C4845b("headerFragmentViewCreated");

    /* renamed from: androidx.leanback.app.f$a */
    class C0633a implements C0657i.C0663e {
        C0633a() {
        }
    }

    /* renamed from: androidx.leanback.app.f$b */
    class C0634b implements C0657i.C0664f {
        C0634b() {
        }
    }

    /* renamed from: androidx.leanback.app.f$c */
    class C0635c extends RecyclerView.C1166s {
        C0635c() {
        }

        /* renamed from: a */
        public void mo3109a(RecyclerView recyclerView, int i) {
            if (i == 0) {
                recyclerView.removeOnScrollListener(this);
                C0632f fVar = C0632f.this;
                if (!fVar.f2845Z0) {
                    fVar.mo3092f5();
                }
            }
        }
    }

    /* renamed from: androidx.leanback.app.f$d */
    class C0636d extends C4843a.C4846c {
        C0636d(String str) {
            super(str, false, true);
        }

        /* renamed from: c */
        public void mo3070c() {
            C0632f.this.mo3104t5();
        }
    }

    /* renamed from: androidx.leanback.app.f$e */
    class C0637e implements Runnable {

        /* renamed from: a */
        final /* synthetic */ boolean f2863a;

        C0637e(boolean z) {
            this.f2863a = z;
        }

        public void run() {
            C0632f.this.f2825F0.mo3053T4();
            C0632f.this.f2825F0.mo3143Z4();
            C0632f fVar = C0632f.this;
            Object d = C0729a.m3172d(fVar.mo2583b3(), fVar.f2835P0 ? R.transition.lb_browse_headers_in : R.transition.lb_browse_headers_out);
            fVar.f2850e1 = d;
            C0729a.m3169a(d, new C0656h(fVar));
            Objects.requireNonNull(C0632f.this);
            C0729a.m3173e(this.f2863a ? C0632f.this.f2847b1 : C0632f.this.f2848c1, C0632f.this.f2850e1);
            C0632f fVar2 = C0632f.this;
            if (!fVar2.f2833N0) {
                return;
            }
            if (!this.f2863a) {
                C0553c0 i = fVar2.mo2599i3().mo2729i();
                i.mo2871d(C0632f.this.f2834O0);
                i.mo2794e();
                return;
            }
            int i2 = fVar2.f2851f1.f2871b;
            if (i2 >= 0) {
                C0632f.this.mo2599i3().mo2689D0(fVar2.mo2599i3().mo2717b0(i2).getId(), 1);
            }
        }
    }

    /* renamed from: androidx.leanback.app.f$f */
    class C0638f implements BrowseFrameLayout.C0740b {
        C0638f() {
        }

        /* renamed from: a */
        public View mo3111a(View view, int i) {
            Fragment fragment;
            C0632f fVar = C0632f.this;
            if (fVar.f2836Q0 && fVar.mo3099o5()) {
                return view;
            }
            if (C0632f.this.mo3074Q4() != null && view != C0632f.this.mo3074Q4() && i == 33) {
                return C0632f.this.mo3074Q4();
            }
            if (C0632f.this.mo3074Q4() == null || !C0632f.this.mo3074Q4().hasFocus() || i != 130) {
                int i2 = C4761m.f17241f;
                boolean z = true;
                if (view.getLayoutDirection() != 1) {
                    z = false;
                }
                int i3 = 66;
                int i4 = z ? 66 : 17;
                if (z) {
                    i3 = 17;
                }
                C0632f fVar2 = C0632f.this;
                if (!fVar2.f2836Q0 || i != i4) {
                    if (i == i3) {
                        return (fVar2.mo3100p5() || (fragment = C0632f.this.f2824E0) == null || fragment.mo2633x3() == null) ? view : C0632f.this.f2824E0.mo2633x3();
                    }
                    if (i != 130 || !fVar2.f2835P0) {
                        return null;
                    }
                    return view;
                } else if (fVar2.mo3100p5()) {
                    return view;
                } else {
                    C0632f fVar3 = C0632f.this;
                    return (fVar3.f2835P0 || !fVar3.mo3098n5()) ? view : C0632f.this.f2825F0.f2779b0;
                }
            } else {
                C0632f fVar4 = C0632f.this;
                if (!fVar4.f2836Q0 || !fVar4.f2835P0) {
                    return fVar4.f2824E0.mo2633x3();
                }
                return fVar4.f2825F0.f2779b0;
            }
        }
    }

    /* renamed from: androidx.leanback.app.f$g */
    class C0639g implements BrowseFrameLayout.C0739a {
        C0639g() {
        }

        /* renamed from: a */
        public boolean mo3112a(int i, Rect rect) {
            C0657i iVar;
            if (C0632f.this.mo2581a3().mo2744r0()) {
                return true;
            }
            C0632f fVar = C0632f.this;
            if (fVar.f2836Q0 && fVar.f2835P0 && (iVar = fVar.f2825F0) != null && iVar.mo2633x3() != null && C0632f.this.f2825F0.mo2633x3().requestFocus(i, rect)) {
                return true;
            }
            Fragment fragment = C0632f.this.f2824E0;
            if (fragment == null || fragment.mo2633x3() == null || !C0632f.this.f2824E0.mo2633x3().requestFocus(i, rect)) {
                return C0632f.this.mo3074Q4() != null && C0632f.this.mo3074Q4().requestFocus(i, rect);
            }
            return true;
        }

        /* renamed from: b */
        public void mo3113b(View view, View view2) {
            if (!C0632f.this.mo2581a3().mo2744r0()) {
                C0632f fVar = C0632f.this;
                if (fVar.f2836Q0 && !fVar.mo3099o5()) {
                    int id = view.getId();
                    if (id == R.id.browse_container_dock) {
                        C0632f fVar2 = C0632f.this;
                        if (fVar2.f2835P0) {
                            fVar2.mo3089H5(false);
                            return;
                        }
                    }
                    if (id == R.id.browse_headers_dock) {
                        C0632f fVar3 = C0632f.this;
                        if (!fVar3.f2835P0) {
                            fVar3.mo3089H5(true);
                        }
                    }
                }
            }
        }
    }

    /* renamed from: androidx.leanback.app.f$h */
    class C0640h implements Runnable {
        C0640h() {
        }

        public void run() {
            C0632f.this.mo3088G5(true);
        }
    }

    /* renamed from: androidx.leanback.app.f$i */
    class C0641i implements Runnable {
        C0641i() {
        }

        public void run() {
            C0632f.this.mo3088G5(false);
        }
    }

    /* renamed from: androidx.leanback.app.f$j */
    class C0642j implements Runnable {
        C0642j() {
        }

        public void run() {
            C0632f.this.mo3103s5();
        }
    }

    /* renamed from: androidx.leanback.app.f$k */
    final class C0643k implements FragmentManager.C0535l {

        /* renamed from: a */
        int f2870a;

        /* renamed from: b */
        int f2871b = -1;

        C0643k() {
            this.f2870a = C0632f.this.mo2599i3().mo2719c0();
        }

        /* renamed from: a */
        public void mo2769a() {
            if (C0632f.this.mo2599i3() == null) {
                Log.w("BrowseSupportFragment", "getFragmentManager() is null, stack:", new Exception());
                return;
            }
            int c0 = C0632f.this.mo2599i3().mo2719c0();
            int i = this.f2870a;
            if (c0 > i) {
                int i2 = c0 - 1;
                if (C0632f.this.f2834O0.equals(C0632f.this.mo2599i3().mo2717b0(i2).getName())) {
                    this.f2871b = i2;
                }
            } else if (c0 < i && this.f2871b >= c0) {
                if (!C0632f.this.mo3098n5()) {
                    C0553c0 i3 = C0632f.this.mo2599i3().mo2729i();
                    i3.mo2871d(C0632f.this.f2834O0);
                    i3.mo2794e();
                    return;
                }
                this.f2871b = -1;
                C0632f fVar = C0632f.this;
                if (!fVar.f2835P0) {
                    fVar.mo3089H5(true);
                }
            }
            this.f2870a = c0;
        }
    }

    /* renamed from: androidx.leanback.app.f$l */
    private class C0644l implements ViewTreeObserver.OnPreDrawListener {

        /* renamed from: a */
        private final View f2873a;

        /* renamed from: b */
        private final Runnable f2874b;

        /* renamed from: c */
        private int f2875c;

        /* renamed from: d */
        private C0648p f2876d;

        C0644l(Runnable runnable, C0648p pVar, View view) {
            this.f2873a = view;
            this.f2874b = runnable;
            this.f2876d = pVar;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo3117a() {
            this.f2873a.getViewTreeObserver().addOnPreDrawListener(this);
            this.f2876d.mo3128i(false);
            this.f2873a.invalidate();
            this.f2875c = 0;
        }

        public boolean onPreDraw() {
            if (C0632f.this.mo2633x3() == null || C0632f.this.mo2583b3() == null) {
                this.f2873a.getViewTreeObserver().removeOnPreDrawListener(this);
                return true;
            }
            int i = this.f2875c;
            if (i == 0) {
                this.f2876d.mo3128i(true);
                this.f2873a.invalidate();
                this.f2875c = 1;
                return false;
            } else if (i != 1) {
                return false;
            } else {
                this.f2874b.run();
                this.f2873a.getViewTreeObserver().removeOnPreDrawListener(this);
                this.f2875c = 2;
                return false;
            }
        }
    }

    /* renamed from: androidx.leanback.app.f$m */
    public static abstract class C0645m<T extends Fragment> {
        /* renamed from: a */
        public abstract T mo3119a(Object obj);
    }

    /* renamed from: androidx.leanback.app.f$n */
    private final class C0646n {

        /* renamed from: a */
        boolean f2878a = true;

        C0646n() {
        }
    }

    /* renamed from: androidx.leanback.app.f$o */
    public static class C0647o extends C0645m<C0685q> {
        /* renamed from: a */
        public Fragment mo3119a(Object obj) {
            return new C0685q();
        }
    }

    /* renamed from: androidx.leanback.app.f$p */
    public static class C0648p<T extends Fragment> {

        /* renamed from: a */
        private boolean f2880a;

        /* renamed from: b */
        private final T f2881b;

        /* renamed from: c */
        C0646n f2882c;

        public C0648p(T t) {
            this.f2881b = t;
        }

        /* renamed from: a */
        public final T mo3120a() {
            return this.f2881b;
        }

        /* renamed from: b */
        public boolean mo3121b() {
            return this.f2880a;
        }

        /* renamed from: c */
        public boolean mo3122c() {
            return false;
        }

        /* renamed from: d */
        public void mo3123d() {
        }

        /* renamed from: e */
        public boolean mo3124e() {
            return false;
        }

        /* renamed from: f */
        public void mo3125f() {
        }

        /* renamed from: g */
        public void mo3126g(int i) {
        }

        /* renamed from: h */
        public void mo3127h(boolean z) {
        }

        /* renamed from: i */
        public void mo3128i(boolean z) {
        }

        /* renamed from: j */
        public void mo3129j(boolean z) {
            this.f2880a = z;
        }
    }

    /* renamed from: androidx.leanback.app.f$q */
    public interface C0649q {
        /* renamed from: v0 */
        C0648p mo3130v0();
    }

    /* renamed from: androidx.leanback.app.f$r */
    public static final class C0650r {

        /* renamed from: a */
        private static final C0645m f2883a = new C0647o();

        /* renamed from: b */
        private final Map<Class, C0645m> f2884b;

        public C0650r() {
            HashMap hashMap = new HashMap();
            this.f2884b = hashMap;
            hashMap.put(C0767a0.class, f2883a);
        }

        /* renamed from: a */
        public Fragment mo3131a(Object obj) {
            C0645m mVar = obj == null ? f2883a : this.f2884b.get(obj.getClass());
            if (mVar == null) {
                mVar = f2883a;
            }
            return mVar.mo3119a(obj);
        }
    }

    /* renamed from: androidx.leanback.app.f$s */
    class C0651s implements C0811i0 {

        /* renamed from: a */
        C0652t f2885a;

        public C0651s(C0652t tVar) {
            this.f2885a = tVar;
        }

        /* renamed from: a */
        public void mo3132a(C0844p0.C0845a aVar, Object obj, C0870v0.C0872b bVar, Object obj2) {
            C0864t0 t0Var = (C0864t0) obj2;
            C0632f.this.mo3101q5(((C0685q) ((C0685q.C0690d) this.f2885a).mo3134b()).f2782e0);
            C0811i0 i0Var = C0632f.this.f2840U0;
            if (i0Var != null) {
                i0Var.mo3132a(aVar, obj, bVar, t0Var);
            }
        }
    }

    /* renamed from: androidx.leanback.app.f$t */
    public static class C0652t<T extends Fragment> {

        /* renamed from: a */
        private final T f2887a;

        public C0652t(T t) {
            if (t != null) {
                this.f2887a = t;
                return;
            }
            throw new IllegalArgumentException("Fragment can't be null");
        }

        /* renamed from: a */
        public C0870v0.C0872b mo3133a(int i) {
            throw null;
        }

        /* renamed from: b */
        public final T mo3134b() {
            return this.f2887a;
        }

        /* renamed from: c */
        public void mo3135c(C0806h0 h0Var) {
            throw null;
        }
    }

    /* renamed from: androidx.leanback.app.f$u */
    public interface C0653u {
        /* renamed from: X */
        C0652t mo3136X();
    }

    /* renamed from: androidx.leanback.app.f$v */
    private final class C0654v implements Runnable {

        /* renamed from: a */
        private int f2888a = -1;

        /* renamed from: b */
        private int f2889b = -1;

        /* renamed from: c */
        private boolean f2890c = false;

        C0654v() {
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo3137a(int i, int i2, boolean z) {
            if (i2 >= this.f2889b) {
                this.f2888a = i;
                this.f2889b = i2;
                this.f2890c = z;
                C0632f.this.f2831L0.removeCallbacks(this);
                C0632f fVar = C0632f.this;
                if (!fVar.f2845Z0) {
                    fVar.f2831L0.post(this);
                }
            }
        }

        /* renamed from: b */
        public void mo3138b() {
            if (this.f2889b != -1) {
                C0632f.this.f2831L0.post(this);
            }
        }

        public void run() {
            C0632f.this.mo3087F5(this.f2888a, this.f2890c);
            this.f2888a = -1;
            this.f2889b = -1;
            this.f2890c = false;
        }
    }

    /* renamed from: g5 */
    private boolean m2906g5(C0781c0 c0Var, int i) {
        Object obj;
        boolean z = false;
        if (!this.f2836Q0) {
            obj = null;
        } else if (c0Var == null || c0Var.mo3154m() == 0) {
            return false;
        } else {
            if (i < 0) {
                i = 0;
            } else if (i >= c0Var.mo3154m()) {
                throw new IllegalArgumentException(String.format("Invalid position %d requested", new Object[]{Integer.valueOf(i)}));
            }
            obj = c0Var.mo3153a(i);
        }
        boolean z2 = this.f2844Y0;
        this.f2844Y0 = false;
        if (this.f2824E0 == null || z2) {
            z = true;
        }
        if (z) {
            Fragment a = this.f2822C0.mo3131a(obj);
            this.f2824E0 = a;
            if (a instanceof C0649q) {
                mo3106w5();
            } else {
                throw new IllegalArgumentException("Fragment must implement MainFragmentAdapterProvider");
            }
        }
        return z;
    }

    /* renamed from: h5 */
    private void m2907h5(boolean z) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f2832M0.getLayoutParams();
        marginLayoutParams.setMarginStart(!z ? this.f2837R0 : 0);
        this.f2832M0.setLayoutParams(marginLayoutParams);
        this.f2823D0.mo3128i(z);
        m2909x5();
        float f = (z || !this.f2839T0 || !this.f2823D0.mo3121b()) ? 1.0f : this.f2843X0;
        this.f2832M0.mo3535c(f);
        this.f2832M0.mo3534b(f);
    }

    /* renamed from: u5 */
    private void m2908u5(boolean z) {
        View x3 = this.f2825F0.mo2633x3();
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) x3.getLayoutParams();
        marginLayoutParams.setMarginStart(z ? 0 : -this.f2837R0);
        x3.setLayoutParams(marginLayoutParams);
    }

    /* renamed from: x5 */
    private void m2909x5() {
        int i = this.f2838S0;
        if (this.f2839T0 && this.f2823D0.mo3121b() && this.f2835P0) {
            i = (int) ((((float) i) / this.f2843X0) + 0.5f);
        }
        this.f2823D0.mo3126g(i);
    }

    /* renamed from: A5 */
    public void mo3082A5(C0811i0 i0Var) {
        this.f2840U0 = i0Var;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: B5 */
    public void mo3083B5(boolean z) {
        View a = mo3075R4().mo3599a();
        if (a != null) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) a.getLayoutParams();
            marginLayoutParams.setMarginStart(z ? 0 : -this.f2837R0);
            a.setLayoutParams(marginLayoutParams);
        }
    }

    /* renamed from: C5 */
    public void mo3084C5(int i) {
        this.f2846a1.mo3137a(i, 1, true);
    }

    /* renamed from: D5 */
    public void mo3085D5(int i, boolean z) {
        this.f2846a1.mo3137a(i, 1, z);
    }

    /* renamed from: E5 */
    public void mo3086E5(int i, boolean z, C0844p0.C0846b bVar) {
        C0652t tVar;
        if (this.f2822C0 != null && (tVar = this.f2826G0) != null) {
            ((C0685q) ((C0685q.C0690d) tVar).mo3134b()).mo3216g5(i, z, bVar);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: F5 */
    public void mo3087F5(int i, boolean z) {
        if (i != -1) {
            this.f2842W0 = i;
            C0657i iVar = this.f2825F0;
            if (iVar != null && this.f2823D0 != null) {
                iVar.mo3057X4(i, z);
                if (m2906g5(this.f2828I0, i)) {
                    if (!this.f2845Z0) {
                        VerticalGridView verticalGridView = this.f2825F0.f2779b0;
                        if (!this.f2835P0 || verticalGridView == null || verticalGridView.getScrollState() == 0) {
                            mo3092f5();
                        } else {
                            C0553c0 i2 = mo2581a3().mo2729i();
                            i2.mo2873k(R.id.scale_frame, new Fragment(), (String) null);
                            i2.mo2794e();
                            verticalGridView.removeOnScrollListener(this.f2856k1);
                            verticalGridView.addOnScrollListener(this.f2856k1);
                        }
                    }
                    m2907h5(!this.f2836Q0 || !this.f2835P0);
                }
                C0652t tVar = this.f2826G0;
                if (tVar != null) {
                    ((C0685q) ((C0685q.C0690d) tVar).mo3134b()).mo3057X4(i, z);
                }
                mo3091J5();
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: G5 */
    public void mo3088G5(boolean z) {
        this.f2825F0.mo3144a5(z);
        m2908u5(z);
        m2907h5(!z);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: H5 */
    public void mo3089H5(boolean z) {
        if (!mo2599i3().mo2744r0() && mo3098n5()) {
            this.f2835P0 = z;
            this.f2823D0.mo3124e();
            this.f2823D0.mo3125f();
            boolean z2 = !z;
            C0637e eVar = new C0637e(z);
            if (z2) {
                eVar.run();
            } else {
                new C0644l(eVar, this.f2823D0, mo2633x3()).mo3117a();
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: I5 */
    public void mo3090I5() {
        C0665j jVar = this.f2827H0;
        C0665j jVar2 = null;
        if (jVar != null) {
            jVar.mo3155p();
            this.f2827H0 = null;
        }
        if (this.f2826G0 != null) {
            C0781c0 c0Var = this.f2828I0;
            if (c0Var != null) {
                jVar2 = new C0665j(c0Var);
            }
            this.f2827H0 = jVar2;
            ((C0685q) ((C0685q.C0690d) this.f2826G0).mo3134b()).mo3054U4(jVar2);
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0065, code lost:
        if (r0 != 0) goto L_0x0067;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0009, code lost:
        r0 = r5.f2823D0;
     */
    /* renamed from: J5 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo3091J5() {
        /*
            r5 = this;
            boolean r0 = r5.f2835P0
            r1 = 0
            if (r0 != 0) goto L_0x001c
            boolean r0 = r5.f2844Y0
            if (r0 == 0) goto L_0x0012
            androidx.leanback.app.f$p r0 = r5.f2823D0
            if (r0 == 0) goto L_0x0012
            androidx.leanback.app.f$n r0 = r0.f2882c
            boolean r0 = r0.f2878a
            goto L_0x0018
        L_0x0012:
            int r0 = r5.f2842W0
            boolean r0 = r5.mo3097m5(r0)
        L_0x0018:
            if (r0 == 0) goto L_0x006b
            r0 = 6
            goto L_0x0067
        L_0x001c:
            boolean r0 = r5.f2844Y0
            if (r0 == 0) goto L_0x0029
            androidx.leanback.app.f$p r0 = r5.f2823D0
            if (r0 == 0) goto L_0x0029
            androidx.leanback.app.f$n r0 = r0.f2882c
            boolean r0 = r0.f2878a
            goto L_0x002f
        L_0x0029:
            int r0 = r5.f2842W0
            boolean r0 = r5.mo3097m5(r0)
        L_0x002f:
            int r2 = r5.f2842W0
            androidx.leanback.widget.c0 r3 = r5.f2828I0
            if (r3 == 0) goto L_0x005b
            int r3 = r3.mo3154m()
            if (r3 != 0) goto L_0x003c
            goto L_0x005b
        L_0x003c:
            r3 = 0
        L_0x003d:
            androidx.leanback.widget.c0 r4 = r5.f2828I0
            int r4 = r4.mo3154m()
            if (r3 >= r4) goto L_0x005b
            androidx.leanback.widget.c0 r4 = r5.f2828I0
            java.lang.Object r4 = r4.mo3153a(r3)
            androidx.leanback.widget.t0 r4 = (androidx.leanback.widget.C0864t0) r4
            boolean r4 = r4.mo3862c()
            if (r4 != 0) goto L_0x0056
            int r3 = r3 + 1
            goto L_0x003d
        L_0x0056:
            if (r2 != r3) goto L_0x0059
            goto L_0x005b
        L_0x0059:
            r2 = 0
            goto L_0x005c
        L_0x005b:
            r2 = 1
        L_0x005c:
            if (r0 == 0) goto L_0x0060
            r0 = 2
            goto L_0x0061
        L_0x0060:
            r0 = 0
        L_0x0061:
            if (r2 == 0) goto L_0x0065
            r0 = r0 | 4
        L_0x0065:
            if (r0 == 0) goto L_0x006b
        L_0x0067:
            r5.mo3080W4(r0)
            goto L_0x006e
        L_0x006b:
            r5.mo3081X4(r1)
        L_0x006e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.app.C0632f.mo3091J5():void");
    }

    /* renamed from: M3 */
    public void mo2559M3(Bundle bundle) {
        super.mo2559M3(bundle);
        Context b3 = mo2583b3();
        TypedArray obtainStyledAttributes = b3.obtainStyledAttributes(C4825b.f17409b);
        this.f2837R0 = (int) obtainStyledAttributes.getDimension(6, (float) b3.getResources().getDimensionPixelSize(R.dimen.lb_browse_rows_margin_start));
        this.f2838S0 = (int) obtainStyledAttributes.getDimension(7, (float) b3.getResources().getDimensionPixelSize(R.dimen.lb_browse_rows_margin_top));
        obtainStyledAttributes.recycle();
        Bundle Z2 = mo2579Z2();
        if (Z2 != null) {
            String str = f2818w0;
            if (Z2.containsKey(str)) {
                mo3078U4(Z2.getString(str));
            }
            String str2 = f2819x0;
            if (Z2.containsKey(str2)) {
                mo3105v5(Z2.getInt(str2));
            }
        }
        if (this.f2836Q0) {
            if (this.f2833N0) {
                this.f2834O0 = "lbHeadersBackStack_" + this;
                this.f2851f1 = new C0643k();
                mo2599i3().mo2722e(this.f2851f1);
                C0643k kVar = this.f2851f1;
                Objects.requireNonNull(kVar);
                if (bundle != null) {
                    int i = bundle.getInt("headerStackIndex", -1);
                    kVar.f2871b = i;
                    C0632f.this.f2835P0 = i == -1;
                } else {
                    C0632f fVar = C0632f.this;
                    if (!fVar.f2835P0) {
                        C0553c0 i2 = fVar.mo2599i3().mo2729i();
                        i2.mo2871d(C0632f.this.f2834O0);
                        i2.mo2794e();
                    }
                }
            } else if (bundle != null) {
                this.f2835P0 = bundle.getBoolean("headerShow");
            }
        }
        this.f2843X0 = mo2619r3().getFraction(R.fraction.lb_browse_rows_scale, 1, 1);
    }

    /* renamed from: P3 */
    public View mo2565P3(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        if (mo2581a3().mo2714X(R.id.scale_frame) == null) {
            this.f2825F0 = new C0657i();
            m2906g5(this.f2828I0, this.f2842W0);
            C0553c0 i = mo2581a3().mo2729i();
            i.mo2873k(R.id.browse_headers_dock, this.f2825F0, (String) null);
            Fragment fragment = this.f2824E0;
            if (fragment != null) {
                i.mo2873k(R.id.scale_frame, fragment, (String) null);
            } else {
                C0648p pVar = new C0648p(null);
                this.f2823D0 = pVar;
                pVar.f2882c = new C0646n();
            }
            i.mo2794e();
        } else {
            this.f2825F0 = (C0657i) mo2581a3().mo2714X(R.id.browse_headers_dock);
            this.f2824E0 = mo2581a3().mo2714X(R.id.scale_frame);
            this.f2844Y0 = bundle != null && bundle.getBoolean("isPageRow", false);
            this.f2842W0 = bundle != null ? bundle.getInt("currentSelectedPosition", 0) : 0;
            mo3106w5();
        }
        this.f2825F0.mo3145b5(true ^ this.f2836Q0);
        this.f2825F0.mo3054U4(this.f2828I0);
        this.f2825F0.mo3146c5(this.f2855j1);
        this.f2825F0.f2899l0 = this.f2854i1;
        View inflate = layoutInflater.inflate(R.layout.lb_browse_fragment, viewGroup, false);
        this.f2804v0.f2970b = (ViewGroup) inflate;
        BrowseFrameLayout browseFrameLayout = (BrowseFrameLayout) inflate.findViewById(R.id.browse_frame);
        this.f2831L0 = browseFrameLayout;
        browseFrameLayout.mo3327a(this.f2853h1);
        this.f2831L0.mo3328b(this.f2852g1);
        mo3076S4(layoutInflater, this.f2831L0, bundle);
        ScaleFrameLayout scaleFrameLayout = (ScaleFrameLayout) inflate.findViewById(R.id.scale_frame);
        this.f2832M0 = scaleFrameLayout;
        scaleFrameLayout.setPivotX(0.0f);
        this.f2832M0.setPivotY((float) this.f2838S0);
        this.f2847b1 = C0729a.m3171c(this.f2831L0, new C0640h());
        this.f2848c1 = C0729a.m3171c(this.f2831L0, new C0641i());
        this.f2849d1 = C0729a.m3171c(this.f2831L0, new C0642j());
        return inflate;
    }

    /* renamed from: Q3 */
    public void mo2566Q3() {
        if (this.f2851f1 != null) {
            mo2599i3().mo2698I0(this.f2851f1);
        }
        super.mo2566Q3();
    }

    /* renamed from: R3 */
    public void mo2567R3() {
        mo3107y5((C0652t) null);
        this.f2823D0 = null;
        this.f2824E0 = null;
        this.f2825F0 = null;
        super.mo2567R3();
    }

    /* access modifiers changed from: protected */
    /* renamed from: Y4 */
    public Object mo3063Y4() {
        return C0729a.m3172d(mo2583b3(), R.transition.lb_browse_entrance_transition);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Z4 */
    public void mo3064Z4() {
        super.mo3064Z4();
        this.f2802t0.mo22118a(this.f2857y0);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a5 */
    public void mo3065a5() {
        super.mo3065a5();
        this.f2802t0.mo22121d(this.f2791i0, this.f2857y0, this.f2858z0);
        this.f2802t0.mo22121d(this.f2791i0, this.f2792j0, this.f2820A0);
        this.f2802t0.mo22121d(this.f2791i0, this.f2793k0, this.f2821B0);
    }

    /* access modifiers changed from: protected */
    /* renamed from: b5 */
    public void mo3066b5() {
        C0648p pVar = this.f2823D0;
        if (pVar != null) {
            pVar.mo3123d();
        }
        C0657i iVar = this.f2825F0;
        if (iVar != null) {
            iVar.mo3052S4();
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: c5 */
    public void mo3067c5() {
        this.f2825F0.mo3053T4();
        this.f2823D0.mo3127h(false);
        this.f2823D0.mo3124e();
    }

    /* renamed from: d4 */
    public void mo2588d4(Bundle bundle) {
        super.mo2588d4(bundle);
        bundle.putInt("currentSelectedPosition", this.f2842W0);
        bundle.putBoolean("isPageRow", this.f2844Y0);
        C0643k kVar = this.f2851f1;
        if (kVar != null) {
            bundle.putInt("headerStackIndex", kVar.f2871b);
        } else {
            bundle.putBoolean("headerShow", this.f2835P0);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: d5 */
    public void mo3068d5() {
        this.f2825F0.mo3143Z4();
        this.f2823D0.mo3125f();
    }

    /* JADX WARNING: Removed duplicated region for block: B:24:0x005c  */
    /* renamed from: e4 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2590e4() {
        /*
            r5 = this;
            super.mo2590e4()
            androidx.leanback.app.i r0 = r5.f2825F0
            int r1 = r5.f2838S0
            androidx.leanback.widget.VerticalGridView r2 = r0.f2779b0
            r3 = 0
            if (r2 == 0) goto L_0x0025
            r2.mo3719l(r3)
            androidx.leanback.widget.VerticalGridView r2 = r0.f2779b0
            r4 = -1082130432(0xffffffffbf800000, float:-1.0)
            r2.mo3720m(r4)
            androidx.leanback.widget.VerticalGridView r2 = r0.f2779b0
            r2.mo3701C(r1)
            androidx.leanback.widget.VerticalGridView r1 = r0.f2779b0
            r1.mo3702D(r4)
            androidx.leanback.widget.VerticalGridView r0 = r0.f2779b0
            r0.mo3700B(r3)
        L_0x0025:
            r5.m2909x5()
            boolean r0 = r5.f2836Q0
            if (r0 == 0) goto L_0x003d
            boolean r0 = r5.f2835P0
            if (r0 == 0) goto L_0x003d
            androidx.leanback.app.i r0 = r5.f2825F0
            if (r0 == 0) goto L_0x003d
            android.view.View r0 = r0.mo2633x3()
            if (r0 == 0) goto L_0x003d
            androidx.leanback.app.i r0 = r5.f2825F0
            goto L_0x0051
        L_0x003d:
            boolean r0 = r5.f2836Q0
            if (r0 == 0) goto L_0x0045
            boolean r0 = r5.f2835P0
            if (r0 != 0) goto L_0x0058
        L_0x0045:
            androidx.fragment.app.Fragment r0 = r5.f2824E0
            if (r0 == 0) goto L_0x0058
            android.view.View r0 = r0.mo2633x3()
            if (r0 == 0) goto L_0x0058
            androidx.fragment.app.Fragment r0 = r5.f2824E0
        L_0x0051:
            android.view.View r0 = r0.mo2633x3()
            r0.requestFocus()
        L_0x0058:
            boolean r0 = r5.f2836Q0
            if (r0 == 0) goto L_0x0061
            boolean r0 = r5.f2835P0
            r5.mo3088G5(r0)
        L_0x0061:
            d.l.g.a r0 = r5.f2802t0
            d.l.g.a$b r1 = r5.f2858z0
            r0.mo22122e(r1)
            r5.f2845Z0 = r3
            r5.mo3092f5()
            androidx.leanback.app.f$v r0 = r5.f2846a1
            r0.mo3138b()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.app.C0632f.mo2590e4():void");
    }

    /* access modifiers changed from: protected */
    /* renamed from: e5 */
    public void mo3069e5(Object obj) {
        C0729a.m3173e(this.f2849d1, obj);
    }

    /* renamed from: f4 */
    public void mo2593f4() {
        this.f2845Z0 = true;
        C0654v vVar = this.f2846a1;
        C0632f.this.f2831L0.removeCallbacks(vVar);
        super.mo2593f4();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f5 */
    public final void mo3092f5() {
        FragmentManager a3 = mo2581a3();
        if (a3.mo2714X(R.id.scale_frame) != this.f2824E0) {
            C0553c0 i = a3.mo2729i();
            i.mo2873k(R.id.scale_frame, this.f2824E0, (String) null);
            i.mo2794e();
        }
    }

    /* renamed from: i5 */
    public C0781c0 mo3093i5() {
        return this.f2828I0;
    }

    /* renamed from: j5 */
    public Fragment mo3094j5() {
        return this.f2824E0;
    }

    /* renamed from: k5 */
    public C0685q mo3095k5() {
        Fragment fragment = this.f2824E0;
        if (fragment instanceof C0685q) {
            return (C0685q) fragment;
        }
        return null;
    }

    /* renamed from: l5 */
    public int mo3096l5() {
        return this.f2842W0;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: m5 */
    public boolean mo3097m5(int i) {
        C0781c0 c0Var = this.f2828I0;
        if (!(c0Var == null || c0Var.mo3154m() == 0)) {
            int i2 = 0;
            while (i2 < this.f2828I0.mo3154m()) {
                if (((C0864t0) this.f2828I0.mo3153a(i2)).mo3862c()) {
                    return i == i2;
                }
                i2++;
            }
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n5 */
    public final boolean mo3098n5() {
        C0781c0 c0Var = this.f2828I0;
        return (c0Var == null || c0Var.mo3154m() == 0) ? false : true;
    }

    /* renamed from: o5 */
    public boolean mo3099o5() {
        return this.f2850e1 != null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p5 */
    public boolean mo3100p5() {
        if ((this.f2825F0.f2779b0.getScrollState() != 0) || this.f2823D0.mo3122c()) {
            return true;
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q5 */
    public void mo3101q5(int i) {
        this.f2846a1.mo3137a(i, 0, true);
    }

    /* renamed from: r5 */
    public void mo3102r5(C0781c0 c0Var) {
        this.f2828I0 = c0Var;
        C0858q0 c = c0Var.mo3666c();
        if (c != null) {
            if (c != this.f2829J0) {
                this.f2829J0 = c;
                C0844p0[] b = c.mo3141b();
                C0865u uVar = new C0865u();
                int length = b.length + 1;
                C0844p0[] p0VarArr = new C0844p0[length];
                System.arraycopy(p0VarArr, 0, b, 0, b.length);
                p0VarArr[length - 1] = uVar;
                this.f2828I0.mo3675l(new C0655g(this, c, uVar, p0VarArr));
            }
            if (mo2633x3() != null) {
                mo3090I5();
                this.f2825F0.mo3054U4(this.f2828I0);
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Adapter.getPresenterSelector() is null");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: s5 */
    public void mo3103s5() {
        m2908u5(this.f2835P0);
        mo3083B5(true);
        this.f2823D0.mo3127h(true);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: t5 */
    public void mo3104t5() {
        m2908u5(false);
        mo3083B5(false);
    }

    /* renamed from: v5 */
    public void mo3105v5(int i) {
        if (i < 1 || i > 3) {
            throw new IllegalArgumentException(C4924a.m17900o("Invalid headers state: ", i));
        } else if (i != this.f2830K0) {
            this.f2830K0 = i;
            if (i != 1) {
                if (i == 2) {
                    this.f2836Q0 = true;
                } else if (i != 3) {
                    C4924a.m17875a0("Unknown headers state: ", i, "BrowseSupportFragment");
                } else {
                    this.f2836Q0 = false;
                }
                this.f2835P0 = false;
            } else {
                this.f2836Q0 = true;
                this.f2835P0 = true;
            }
            C0657i iVar = this.f2825F0;
            if (iVar != null) {
                iVar.mo3145b5(true ^ this.f2836Q0);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: w5 */
    public void mo3106w5() {
        C0648p v0 = ((C0649q) this.f2824E0).mo3130v0();
        this.f2823D0 = v0;
        v0.f2882c = new C0646n();
        if (!this.f2844Y0) {
            Fragment fragment = this.f2824E0;
            if (fragment instanceof C0653u) {
                mo3107y5(((C0653u) fragment).mo3136X());
            } else {
                mo3107y5((C0652t) null);
            }
            this.f2844Y0 = this.f2826G0 == null;
            return;
        }
        mo3107y5((C0652t) null);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: y5 */
    public void mo3107y5(C0652t tVar) {
        C0652t tVar2 = this.f2826G0;
        if (tVar != tVar2) {
            if (tVar2 != null) {
                ((C0685q) ((C0685q.C0690d) tVar2).mo3134b()).mo3054U4((C0781c0) null);
            }
            this.f2826G0 = tVar;
            if (tVar != null) {
                ((C0685q) ((C0685q.C0690d) tVar).mo3134b()).mo3215e5(new C0651s(tVar));
                this.f2826G0.mo3135c(this.f2841V0);
            }
            mo3090I5();
        }
    }

    /* renamed from: z5 */
    public void mo3108z5(C0806h0 h0Var) {
        this.f2841V0 = h0Var;
        C0652t tVar = this.f2826G0;
        if (tVar != null) {
            tVar.mo3135c(h0Var);
        }
    }
}
