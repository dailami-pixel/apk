package androidx.leanback.app;

import androidx.leanback.widget.C0844p0;
import androidx.leanback.widget.C0858q0;
import androidx.leanback.widget.C0864t0;

/* renamed from: androidx.leanback.app.g */
class C0655g extends C0858q0 {

    /* renamed from: a */
    final /* synthetic */ C0858q0 f2892a;

    /* renamed from: b */
    final /* synthetic */ C0844p0 f2893b;

    /* renamed from: c */
    final /* synthetic */ C0844p0[] f2894c;

    C0655g(C0632f fVar, C0858q0 q0Var, C0844p0 p0Var, C0844p0[] p0VarArr) {
        this.f2892a = q0Var;
        this.f2893b = p0Var;
        this.f2894c = p0VarArr;
    }

    /* renamed from: a */
    public C0844p0 mo3140a(Object obj) {
        return ((C0864t0) obj).mo3862c() ? this.f2892a.mo3140a(obj) : this.f2893b;
    }

    /* renamed from: b */
    public C0844p0[] mo3141b() {
        return this.f2894c;
    }
}
