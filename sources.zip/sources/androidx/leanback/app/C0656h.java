package androidx.leanback.app;

import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.leanback.app.C0632f;
import androidx.leanback.transition.C0731b;
import androidx.leanback.widget.VerticalGridView;
import java.util.Objects;

/* renamed from: androidx.leanback.app.h */
class C0656h extends C0731b {

    /* renamed from: b */
    final /* synthetic */ C0632f f2895b;

    C0656h(C0632f fVar) {
        this.f2895b = fVar;
    }

    /* renamed from: a */
    public void mo3072a(Object obj) {
        VerticalGridView verticalGridView;
        Fragment fragment;
        View x3;
        C0632f fVar = this.f2895b;
        fVar.f2850e1 = null;
        C0632f.C0648p pVar = fVar.f2823D0;
        if (pVar != null) {
            pVar.mo3123d();
            C0632f fVar2 = this.f2895b;
            if (!fVar2.f2835P0 && (fragment = fVar2.f2824E0) != null && (x3 = fragment.mo2633x3()) != null && !x3.hasFocus()) {
                x3.requestFocus();
            }
        }
        C0657i iVar = this.f2895b.f2825F0;
        if (iVar != null) {
            iVar.mo3052S4();
            C0632f fVar3 = this.f2895b;
            if (fVar3.f2835P0 && (verticalGridView = fVar3.f2825F0.f2779b0) != null && !verticalGridView.hasFocus()) {
                verticalGridView.requestFocus();
            }
        }
        this.f2895b.mo3091J5();
        Objects.requireNonNull(this.f2895b);
    }

    /* renamed from: b */
    public void mo3142b(Object obj) {
    }
}
