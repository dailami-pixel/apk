package androidx.leanback.app;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import androidx.fragment.app.Fragment;
import androidx.leanback.app.C0632f;
import androidx.leanback.widget.C0805h;
import androidx.leanback.widget.C0817k;
import androidx.leanback.widget.C0824l;
import androidx.leanback.widget.C0839p;
import androidx.leanback.widget.C0858q0;
import androidx.leanback.widget.C0864t0;
import androidx.leanback.widget.C0866u0;
import androidx.leanback.widget.C0877x0;
import androidx.leanback.widget.C0878y;
import androidx.leanback.widget.VerticalGridView;
import androidx.recyclerview.widget.RecyclerView;
import com.vidio.android.p195tv.R;

/* renamed from: androidx.leanback.app.i */
public class C0657i extends C0620a {

    /* renamed from: i0 */
    private static final C0858q0 f2896i0;

    /* renamed from: j0 */
    static View.OnLayoutChangeListener f2897j0 = new C0660b();

    /* renamed from: k0 */
    private C0664f f2898k0;

    /* renamed from: l0 */
    C0663e f2899l0;

    /* renamed from: m0 */
    private boolean f2900m0 = true;

    /* renamed from: n0 */
    private boolean f2901n0 = false;

    /* renamed from: o0 */
    private int f2902o0;

    /* renamed from: p0 */
    private boolean f2903p0;

    /* renamed from: q0 */
    private final C0878y.C0880b f2904q0 = new C0658a();

    /* renamed from: r0 */
    final C0878y.C0883e f2905r0 = new C0661c(this);

    /* renamed from: androidx.leanback.app.i$a */
    class C0658a extends C0878y.C0880b {

        /* renamed from: androidx.leanback.app.i$a$a */
        class C0659a implements View.OnClickListener {

            /* renamed from: a */
            final /* synthetic */ C0878y.C0882d f2907a;

            C0659a(C0878y.C0882d dVar) {
                this.f2907a = dVar;
            }

            public void onClick(View view) {
                Fragment fragment;
                C0663e eVar = C0657i.this.f2899l0;
                if (eVar != null) {
                    C0866u0.C0867a aVar = (C0866u0.C0867a) this.f2907a.mo3904e();
                    C0864t0 t0Var = (C0864t0) this.f2907a.mo3902b();
                    C0632f.C0633a aVar2 = (C0632f.C0633a) eVar;
                    C0632f fVar = C0632f.this;
                    if (fVar.f2836Q0 && fVar.f2835P0 && !fVar.mo3099o5() && (fragment = C0632f.this.f2824E0) != null && fragment.mo2633x3() != null) {
                        C0632f.this.mo3089H5(false);
                        C0632f.this.f2824E0.mo2633x3().requestFocus();
                    }
                }
            }
        }

        C0658a() {
        }

        /* renamed from: d */
        public void mo3147d(C0878y.C0882d dVar) {
            View view = dVar.mo3904e().f3529a;
            view.setOnClickListener(new C0659a(dVar));
            if (C0657i.this.f2905r0 != null) {
                dVar.itemView.addOnLayoutChangeListener(C0657i.f2897j0);
            } else {
                view.addOnLayoutChangeListener(C0657i.f2897j0);
            }
        }
    }

    /* renamed from: androidx.leanback.app.i$b */
    static class C0660b implements View.OnLayoutChangeListener {
        C0660b() {
        }

        public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
            view.setPivotX(view.getLayoutDirection() == 1 ? (float) view.getWidth() : 0.0f);
            view.setPivotY((float) (view.getMeasuredHeight() / 2));
        }
    }

    /* renamed from: androidx.leanback.app.i$c */
    class C0661c extends C0878y.C0883e {
        C0661c(C0657i iVar) {
        }

        /* renamed from: a */
        public View mo3150a(View view) {
            return new C0662d(view.getContext());
        }

        /* renamed from: b */
        public void mo3151b(View view, View view2) {
            ((FrameLayout) view).addView(view2);
        }
    }

    /* renamed from: androidx.leanback.app.i$d */
    static class C0662d extends FrameLayout {
        public C0662d(Context context) {
            super(context);
        }

        public boolean hasOverlappingRendering() {
            return false;
        }
    }

    /* renamed from: androidx.leanback.app.i$e */
    public interface C0663e {
    }

    /* renamed from: androidx.leanback.app.i$f */
    public interface C0664f {
    }

    static {
        C0805h hVar = new C0805h();
        hVar.mo3746c(C0824l.class, new C0817k());
        hVar.mo3746c(C0877x0.class, new C0866u0(R.layout.lb_section_header, false));
        hVar.mo3746c(C0864t0.class, new C0866u0(R.layout.lb_header));
        f2896i0 = hVar;
    }

    public C0657i() {
        mo3056W4(f2896i0);
        C0839p.m3629d(this.f2781d0);
    }

    /* renamed from: d5 */
    private void m2983d5(int i) {
        Drawable background = mo2633x3().findViewById(R.id.fade_out_edge).getBackground();
        if (background instanceof GradientDrawable) {
            background.mutate();
            ((GradientDrawable) background).setColors(new int[]{0, i});
        }
    }

    /* renamed from: e5 */
    private void m2984e5() {
        VerticalGridView verticalGridView = this.f2779b0;
        if (verticalGridView != null) {
            mo2633x3().setVisibility(this.f2901n0 ? 8 : 0);
            if (this.f2901n0) {
                return;
            }
            if (this.f2900m0) {
                verticalGridView.mo3714h(0);
            } else {
                verticalGridView.mo3714h(4);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: P4 */
    public VerticalGridView mo3049P4(View view) {
        return (VerticalGridView) view.findViewById(R.id.browse_headers);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Q4 */
    public int mo3050Q4() {
        return R.layout.lb_headers_fragment;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: R4 */
    public void mo3051R4(RecyclerView recyclerView, RecyclerView.C1142b0 b0Var, int i, int i2) {
        int i3;
        C0632f fVar;
        C0664f fVar2 = this.f2898k0;
        if (fVar2 != null) {
            if (b0Var == null || i < 0) {
                fVar = C0632f.this;
                i3 = fVar.f2825F0.f2782e0;
                if (!fVar.f2835P0) {
                    return;
                }
            } else {
                C0878y.C0882d dVar = (C0878y.C0882d) b0Var;
                C0866u0.C0867a aVar = (C0866u0.C0867a) dVar.mo3904e();
                C0864t0 t0Var = (C0864t0) dVar.mo3902b();
                fVar = C0632f.this;
                i3 = fVar.f2825F0.f2782e0;
                if (!fVar.f2835P0) {
                    return;
                }
            }
            fVar.mo3101q5(i3);
        }
    }

    /* renamed from: S4 */
    public void mo3052S4() {
        VerticalGridView verticalGridView;
        if (this.f2900m0 && (verticalGridView = this.f2779b0) != null) {
            verticalGridView.setDescendantFocusability(262144);
            if (verticalGridView.hasFocus()) {
                verticalGridView.requestFocus();
            }
        }
        super.mo3052S4();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Y4 */
    public void mo3058Y4() {
        super.mo3058Y4();
        C0878y yVar = this.f2781d0;
        yVar.mo3892j(this.f2904q0);
        yVar.mo3895m(this.f2905r0);
    }

    /* renamed from: Z4 */
    public void mo3143Z4() {
        VerticalGridView verticalGridView;
        VerticalGridView verticalGridView2 = this.f2779b0;
        if (verticalGridView2 != null) {
            verticalGridView2.mo3734u(false);
            this.f2779b0.setLayoutFrozen(true);
            this.f2779b0.mo3718k(true);
        }
        if (!this.f2900m0 && (verticalGridView = this.f2779b0) != null) {
            verticalGridView.setDescendantFocusability(131072);
            if (verticalGridView.hasFocus()) {
                verticalGridView.requestFocus();
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a5 */
    public void mo3144a5(boolean z) {
        this.f2900m0 = z;
        m2984e5();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b5 */
    public void mo3145b5(boolean z) {
        this.f2901n0 = z;
        m2984e5();
    }

    /* renamed from: c5 */
    public void mo3146c5(C0664f fVar) {
        this.f2898k0 = fVar;
    }

    /* renamed from: d4 */
    public void mo2588d4(Bundle bundle) {
        bundle.putInt("currentSelectedPosition", this.f2782e0);
    }

    /* renamed from: g4 */
    public void mo2595g4(View view, Bundle bundle) {
        int color;
        super.mo2595g4(view, bundle);
        VerticalGridView verticalGridView = this.f2779b0;
        if (verticalGridView != null) {
            if (this.f2903p0) {
                verticalGridView.setBackgroundColor(this.f2902o0);
                color = this.f2902o0;
            } else {
                Drawable background = verticalGridView.getBackground();
                if (background instanceof ColorDrawable) {
                    color = ((ColorDrawable) background).getColor();
                }
                m2984e5();
            }
            m2983d5(color);
            m2984e5();
        }
    }
}
