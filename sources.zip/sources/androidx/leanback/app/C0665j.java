package androidx.leanback.app;

import androidx.leanback.widget.C0781c0;
import androidx.leanback.widget.C0864t0;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.leanback.app.j */
class C0665j extends C0781c0 {

    /* renamed from: c */
    private final C0781c0 f2909c;

    /* renamed from: d */
    int f2910d;

    /* renamed from: e */
    final C0781c0.C0783b f2911e;

    /* renamed from: androidx.leanback.app.j$a */
    private class C0666a extends C0781c0.C0783b {
        C0666a() {
        }

        /* renamed from: a */
        public void mo3158a() {
            C0665j.this.mo3157r();
            C0665j.this.mo3668e();
        }
    }

    /* renamed from: androidx.leanback.app.j$b */
    private class C0667b extends C0781c0.C0783b {
        C0667b() {
        }

        /* renamed from: a */
        public void mo3158a() {
            C0665j.this.mo3157r();
            mo3162g(16, -1, -1);
        }

        /* renamed from: c */
        public void mo3159c(int i, int i2) {
            int i3 = C0665j.this.f2910d;
            if (i <= i3) {
                mo3162g(2, i, Math.min(i2, (i3 - i) + 1));
            }
        }

        /* renamed from: e */
        public void mo3160e(int i, int i2) {
            C0665j jVar = C0665j.this;
            int i3 = jVar.f2910d;
            if (i <= i3) {
                jVar.f2910d = i3 + i2;
                jVar.mo3156q(4, i, i2);
                return;
            }
            jVar.mo3157r();
            C0665j jVar2 = C0665j.this;
            int i4 = jVar2.f2910d;
            if (i4 > i3) {
                jVar2.mo3156q(4, i3 + 1, i4 - i3);
            }
        }

        /* renamed from: f */
        public void mo3161f(int i, int i2) {
            int i3 = (i + i2) - 1;
            C0665j jVar = C0665j.this;
            int i4 = jVar.f2910d;
            if (i3 < i4) {
                jVar.f2910d = i4 - i2;
                mo3162g(8, i, i2);
                return;
            }
            jVar.mo3157r();
            int i5 = C0665j.this.f2910d;
            int i6 = i4 - i5;
            if (i6 > 0) {
                mo3162g(8, Math.min(i5 + 1, i), i6);
            }
        }

        /* access modifiers changed from: protected */
        /* renamed from: g */
        public void mo3162g(int i, int i2, int i3) {
            C0665j.this.mo3156q(i, i2, i3);
        }
    }

    public C0665j(C0781c0 c0Var) {
        super(c0Var.mo3666c());
        this.f2909c = c0Var;
        mo3157r();
        this.f2911e = c0Var.mo3667d() ? new C0667b() : new C0666a();
        mo3157r();
        c0Var.mo3674k(this.f2911e);
    }

    /* renamed from: a */
    public Object mo3153a(int i) {
        return this.f2909c.mo3153a(i);
    }

    /* renamed from: m */
    public int mo3154m() {
        return this.f2910d + 1;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p */
    public void mo3155p() {
        this.f2909c.mo3676n(this.f2911e);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q */
    public void mo3156q(int i, int i2, int i3) {
        if (i == 2) {
            mo3670g(i2, i3);
        } else if (i == 4) {
            mo3672i(i2, i3);
        } else if (i == 8) {
            mo3673j(i2, i3);
        } else if (i == 16) {
            mo3668e();
        } else {
            throw new IllegalArgumentException(C4924a.m17900o("Invalid event type ", i));
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: r */
    public void mo3157r() {
        this.f2910d = -1;
        for (int m = this.f2909c.mo3154m() - 1; m >= 0; m--) {
            if (((C0864t0) this.f2909c.mo3153a(m)).mo3862c()) {
                this.f2910d = m;
                return;
            }
        }
    }
}
