package androidx.leanback.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import androidx.fragment.app.C0553c0;
import androidx.fragment.app.Fragment;
import androidx.leanback.widget.C0769b;
import androidx.leanback.widget.C0781c0;
import androidx.leanback.widget.C0784c1;
import androidx.leanback.widget.C0789e;
import androidx.leanback.widget.C0798f;
import androidx.leanback.widget.C0801g;
import androidx.leanback.widget.C0805h;
import androidx.leanback.widget.C0832n0;
import androidx.leanback.widget.C0837o0;
import androidx.leanback.widget.C0844p0;
import androidx.leanback.widget.C0858q0;
import androidx.leanback.widget.C0864t0;
import androidx.leanback.widget.C0870v0;
import androidx.leanback.widget.C0873w;
import androidx.leanback.widget.C0878y;
import androidx.leanback.widget.VerticalGridView;
import com.vidio.android.p195tv.R;
import java.util.Objects;
import p098d.p140l.p141c.C4826a;
import p098d.p140l.p141c.C4827b;
import p098d.p140l.p143e.C4835c;

/* renamed from: androidx.leanback.app.k */
public class C0668k extends Fragment {

    /* renamed from: A0 */
    int f2914A0;

    /* renamed from: B0 */
    ValueAnimator f2915B0;

    /* renamed from: C0 */
    ValueAnimator f2916C0;

    /* renamed from: D0 */
    ValueAnimator f2917D0;

    /* renamed from: E0 */
    ValueAnimator f2918E0;

    /* renamed from: F0 */
    ValueAnimator f2919F0;

    /* renamed from: G0 */
    ValueAnimator f2920G0;

    /* renamed from: H0 */
    private final Animator.AnimatorListener f2921H0 = new C0673e();

    /* renamed from: I0 */
    private final Handler f2922I0 = new C0674f();

    /* renamed from: J0 */
    private final C0789e.C0794e f2923J0 = new C0675g();

    /* renamed from: K0 */
    private final C0789e.C0793d f2924K0 = new C0676h();

    /* renamed from: L0 */
    private TimeInterpolator f2925L0 = new C4827b(100, 0);

    /* renamed from: M0 */
    private TimeInterpolator f2926M0 = new C4826a(100, 0);

    /* renamed from: N0 */
    private final C0878y.C0880b f2927N0 = new C0669a();

    /* renamed from: O0 */
    final C0837o0.C0838a f2928O0 = new C0670b(this);

    /* renamed from: a0 */
    C4835c.C4836a f2929a0;

    /* renamed from: b0 */
    C0683p f2930b0 = new C0683p();

    /* renamed from: c0 */
    C0685q f2931c0;

    /* renamed from: d0 */
    C0781c0 f2932d0;

    /* renamed from: e0 */
    C0832n0 f2933e0;

    /* renamed from: f0 */
    C0864t0 f2934f0;

    /* renamed from: g0 */
    C0798f f2935g0;

    /* renamed from: h0 */
    C0798f f2936h0;

    /* renamed from: i0 */
    private final C0798f f2937i0 = new C0671c();

    /* renamed from: j0 */
    private final C0801g f2938j0 = new C0672d();

    /* renamed from: k0 */
    int f2939k0;

    /* renamed from: l0 */
    int f2940l0;

    /* renamed from: m0 */
    View f2941m0;

    /* renamed from: n0 */
    View f2942n0;

    /* renamed from: o0 */
    int f2943o0 = 1;

    /* renamed from: p0 */
    int f2944p0;

    /* renamed from: q0 */
    int f2945q0;

    /* renamed from: r0 */
    int f2946r0;

    /* renamed from: s0 */
    int f2947s0;

    /* renamed from: t0 */
    int f2948t0;

    /* renamed from: u0 */
    int f2949u0;

    /* renamed from: v0 */
    int f2950v0;

    /* renamed from: w0 */
    View.OnKeyListener f2951w0;

    /* renamed from: x0 */
    boolean f2952x0 = true;

    /* renamed from: y0 */
    boolean f2953y0 = true;

    /* renamed from: z0 */
    boolean f2954z0 = true;

    /* renamed from: androidx.leanback.app.k$a */
    class C0669a extends C0878y.C0880b {
        C0669a() {
        }

        /* renamed from: b */
        public void mo3181b(C0878y.C0882d dVar) {
            if (!C0668k.this.f2954z0) {
                dVar.mo3904e().f3529a.setAlpha(0.0f);
            }
        }

        /* renamed from: c */
        public void mo3182c(C0878y.C0882d dVar) {
        }

        /* renamed from: d */
        public void mo3147d(C0878y.C0882d dVar) {
            C0844p0.C0845a e = dVar.mo3904e();
            if (e instanceof C0837o0) {
                ((C0837o0) e).mo3195b(C0668k.this.f2928O0);
            }
        }

        /* renamed from: e */
        public void mo3183e(C0878y.C0882d dVar) {
            dVar.mo3904e().f3529a.setAlpha(1.0f);
            dVar.mo3904e().f3529a.setTranslationY(0.0f);
            dVar.mo3904e().f3529a.setAlpha(1.0f);
        }
    }

    /* renamed from: androidx.leanback.app.k$b */
    class C0670b extends C0837o0.C0838a {
        C0670b(C0668k kVar) {
        }
    }

    /* renamed from: androidx.leanback.app.k$c */
    class C0671c implements C0798f {
        C0671c() {
        }

        /* renamed from: a */
        public void mo3184a(C0844p0.C0845a aVar, Object obj, C0870v0.C0872b bVar, Object obj2) {
            C0798f fVar = C0668k.this.f2936h0;
            if (fVar != null && (bVar instanceof C0832n0.C0833a)) {
                fVar.mo3184a(aVar, obj, bVar, obj2);
            }
            C0798f fVar2 = C0668k.this.f2935g0;
            if (fVar2 != null) {
                fVar2.mo3184a(aVar, obj, bVar, obj2);
            }
        }
    }

    /* renamed from: androidx.leanback.app.k$d */
    class C0672d implements C0801g {
        C0672d() {
        }

        /* renamed from: a */
        public void mo3132a(C0844p0.C0845a aVar, Object obj, C0870v0.C0872b bVar, Object obj2) {
            Objects.requireNonNull(C0668k.this);
        }
    }

    /* renamed from: androidx.leanback.app.k$e */
    class C0673e implements Animator.AnimatorListener {
        C0673e() {
        }

        public void onAnimationCancel(Animator animator) {
        }

        public void onAnimationEnd(Animator animator) {
            C0878y.C0882d dVar;
            C0668k kVar = C0668k.this;
            if (kVar.f2914A0 <= 0) {
                VerticalGridView S4 = kVar.mo3165S4();
                if (S4 != null && S4.mo3703a() == 0 && (dVar = (C0878y.C0882d) S4.findViewHolderForAdapterPosition(0)) != null && (dVar.mo3903d() instanceof C0832n0)) {
                    C0870v0.C0872b bVar = (C0870v0.C0872b) dVar.mo3904e();
                    Objects.requireNonNull((C0832n0) dVar.mo3903d());
                }
            } else if (kVar.mo3165S4() != null) {
                kVar.mo3165S4().mo3712g(true);
            }
            Objects.requireNonNull(C0668k.this);
        }

        public void onAnimationRepeat(Animator animator) {
        }

        public void onAnimationStart(Animator animator) {
            C0668k kVar = C0668k.this;
            if (kVar.mo3165S4() != null) {
                kVar.mo3165S4().mo3712g(false);
            }
        }
    }

    /* renamed from: androidx.leanback.app.k$f */
    class C0674f extends Handler {
        C0674f() {
        }

        public void handleMessage(Message message) {
            if (message.what == 1) {
                C0668k kVar = C0668k.this;
                if (kVar.f2952x0) {
                    kVar.mo3166T4(true);
                }
            }
        }
    }

    /* renamed from: androidx.leanback.app.k$g */
    class C0675g implements C0789e.C0794e {
        C0675g() {
        }

        /* renamed from: a */
        public boolean mo3190a(MotionEvent motionEvent) {
            return C0668k.this.mo3170Y4(motionEvent);
        }
    }

    /* renamed from: androidx.leanback.app.k$h */
    class C0676h implements C0789e.C0793d {
        C0676h() {
        }

        /* renamed from: a */
        public boolean mo3191a(KeyEvent keyEvent) {
            return C0668k.this.mo3170Y4(keyEvent);
        }
    }

    public C0668k() {
        this.f2930b0.mo3208b(500);
    }

    /* renamed from: P4 */
    static void m3011P4(ValueAnimator valueAnimator, ValueAnimator valueAnimator2) {
        if (valueAnimator.isStarted()) {
            valueAnimator.end();
        } else if (valueAnimator2.isStarted()) {
            valueAnimator2.end();
        }
    }

    /* renamed from: V4 */
    private static ValueAnimator m3012V4(Context context, int i) {
        ValueAnimator valueAnimator = (ValueAnimator) AnimatorInflater.loadAnimator(context, i);
        valueAnimator.setDuration(valueAnimator.getDuration() * 1);
        return valueAnimator;
    }

    /* renamed from: a5 */
    static void m3013a5(ValueAnimator valueAnimator, ValueAnimator valueAnimator2, boolean z) {
        if (valueAnimator.isStarted()) {
            valueAnimator.reverse();
            if (!z) {
                valueAnimator.end();
                return;
            }
            return;
        }
        valueAnimator2.start();
        if (!z) {
            valueAnimator2.end();
        }
    }

    /* renamed from: i5 */
    private void m3014i5() {
        C0781c0 c0Var = this.f2932d0;
        if (c0Var != null && this.f2934f0 != null && this.f2933e0 != null) {
            C0858q0 c = c0Var.mo3666c();
            if (c == null) {
                C0805h hVar = new C0805h();
                hVar.mo3746c(this.f2934f0.getClass(), this.f2933e0);
                this.f2932d0.mo3675l(hVar);
            } else if (c instanceof C0805h) {
                ((C0805h) c).mo3746c(this.f2934f0.getClass(), this.f2933e0);
            }
        }
    }

    /* renamed from: j5 */
    private void m3015j5() {
        C0864t0 t0Var;
        C0781c0 c0Var = this.f2932d0;
        if ((c0Var instanceof C0769b) && this.f2934f0 != null) {
            C0769b bVar = (C0769b) c0Var;
            if (bVar.mo3154m() == 0) {
                bVar.mo3609p(this.f2934f0);
            } else {
                bVar.mo3615v(0, this.f2934f0);
            }
        } else if ((c0Var instanceof C0784c1) && (t0Var = this.f2934f0) != null) {
            ((C0784c1) c0Var).mo3685o(0, t0Var);
        }
    }

    /* renamed from: m5 */
    private void m3016m5(int i) {
        Handler handler = this.f2922I0;
        if (handler != null) {
            handler.removeMessages(1);
            this.f2922I0.sendEmptyMessageDelayed(1, (long) i);
        }
    }

    /* renamed from: n5 */
    private void m3017n5() {
        Handler handler = this.f2922I0;
        if (handler != null) {
            handler.removeMessages(1);
        }
    }

    /* renamed from: o5 */
    private void m3018o5() {
        View view = this.f2942n0;
        if (view != null) {
            int i = this.f2944p0;
            int i2 = this.f2943o0;
            if (i2 == 0) {
                i = 0;
            } else if (i2 == 2) {
                i = this.f2945q0;
            }
            view.setBackground(new ColorDrawable(i));
            int i3 = this.f2914A0;
            this.f2914A0 = i3;
            View view2 = this.f2942n0;
            if (view2 != null) {
                view2.getBackground().setAlpha(i3);
            }
        }
    }

    /* renamed from: M3 */
    public void mo2559M3(Bundle bundle) {
        super.mo2559M3(bundle);
        this.f2940l0 = mo2619r3().getDimensionPixelSize(R.dimen.lb_playback_other_rows_center_to_bottom);
        this.f2939k0 = mo2619r3().getDimensionPixelSize(R.dimen.lb_playback_controls_padding_bottom);
        this.f2944p0 = mo2619r3().getColor(R.color.lb_playback_controls_background_dark);
        this.f2945q0 = mo2619r3().getColor(R.color.lb_playback_controls_background_light);
        TypedValue typedValue = new TypedValue();
        mo2583b3().getTheme().resolveAttribute(R.attr.playbackControlsAutoHideTimeout, typedValue, true);
        this.f2946r0 = typedValue.data;
        mo2583b3().getTheme().resolveAttribute(R.attr.playbackControlsAutoHideTickleTimeout, typedValue, true);
        this.f2947s0 = typedValue.data;
        this.f2948t0 = mo2619r3().getDimensionPixelSize(R.dimen.lb_playback_major_fade_translate_y);
        this.f2949u0 = mo2619r3().getDimensionPixelSize(R.dimen.lb_playback_minor_fade_translate_y);
        C0677l lVar = new C0677l(this);
        Context b3 = mo2583b3();
        ValueAnimator V4 = m3012V4(b3, R.animator.lb_playback_bg_fade_in);
        this.f2915B0 = V4;
        V4.addUpdateListener(lVar);
        this.f2915B0.addListener(this.f2921H0);
        ValueAnimator V42 = m3012V4(b3, R.animator.lb_playback_bg_fade_out);
        this.f2916C0 = V42;
        V42.addUpdateListener(lVar);
        this.f2916C0.addListener(this.f2921H0);
        C0678m mVar = new C0678m(this);
        Context b32 = mo2583b3();
        ValueAnimator V43 = m3012V4(b32, R.animator.lb_playback_controls_fade_in);
        this.f2917D0 = V43;
        V43.addUpdateListener(mVar);
        this.f2917D0.setInterpolator(this.f2925L0);
        ValueAnimator V44 = m3012V4(b32, R.animator.lb_playback_controls_fade_out);
        this.f2918E0 = V44;
        V44.addUpdateListener(mVar);
        this.f2918E0.setInterpolator(this.f2926M0);
        C0679n nVar = new C0679n(this);
        Context b33 = mo2583b3();
        ValueAnimator V45 = m3012V4(b33, R.animator.lb_playback_controls_fade_in);
        this.f2919F0 = V45;
        V45.addUpdateListener(nVar);
        this.f2919F0.setInterpolator(this.f2925L0);
        ValueAnimator V46 = m3012V4(b33, R.animator.lb_playback_controls_fade_out);
        this.f2920G0 = V46;
        V46.addUpdateListener(nVar);
        this.f2920G0.setInterpolator(new AccelerateInterpolator());
    }

    /* renamed from: P3 */
    public View mo2565P3(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.lb_playback_fragment, viewGroup, false);
        this.f2941m0 = inflate;
        this.f2942n0 = inflate.findViewById(R.id.playback_fragment_background);
        C0685q qVar = (C0685q) mo2581a3().mo2714X(R.id.playback_controls_dock);
        this.f2931c0 = qVar;
        if (qVar == null) {
            this.f2931c0 = new C0685q();
            C0553c0 i = mo2581a3().mo2729i();
            i.mo2873k(R.id.playback_controls_dock, this.f2931c0, (String) null);
            i.mo2794e();
        }
        C0781c0 c0Var = this.f2932d0;
        if (c0Var == null) {
            mo3172b5(new C0769b((C0858q0) new C0805h()));
        } else {
            this.f2931c0.mo3054U4(c0Var);
        }
        this.f2931c0.mo3215e5(this.f2938j0);
        C0685q qVar2 = this.f2931c0;
        qVar2.f2988s0 = this.f2937i0;
        if (!qVar2.f2983n0) {
            this.f2914A0 = 255;
            m3018o5();
            this.f2931c0.f2993x0 = this.f2927N0;
            C0683p pVar = this.f2930b0;
            if (pVar != null) {
                pVar.f2970b = (ViewGroup) this.f2941m0;
            }
            return this.f2941m0;
        }
        throw new IllegalStateException("Item clicked listener must be set before views are created");
    }

    /* renamed from: Q3 */
    public void mo2566Q3() {
        C4835c.C4836a aVar = this.f2929a0;
        if (aVar != null) {
            aVar.mo22110a();
        }
        super.mo2566Q3();
    }

    /* renamed from: Q4 */
    public C0781c0 mo3163Q4() {
        return this.f2932d0;
    }

    /* renamed from: R3 */
    public void mo2567R3() {
        this.f2941m0 = null;
        this.f2942n0 = null;
        super.mo2567R3();
    }

    /* renamed from: R4 */
    public C0683p mo3164R4() {
        return this.f2930b0;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: S4 */
    public VerticalGridView mo3165S4() {
        C0685q qVar = this.f2931c0;
        if (qVar == null) {
            return null;
        }
        return qVar.mo3213c5();
    }

    /* renamed from: T4 */
    public void mo3166T4(boolean z) {
        mo3180l5(false, z);
    }

    /* renamed from: U4 */
    public boolean mo3167U4() {
        return this.f2954z0;
    }

    /* access modifiers changed from: protected */
    /* renamed from: W4 */
    public void mo3168W4(boolean z) {
        C0683p pVar = this.f2930b0;
        if (pVar == null) {
            return;
        }
        if (z) {
            pVar.mo3210d();
        } else {
            pVar.mo3207a();
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: X4 */
    public void mo3169X4() {
    }

    /* renamed from: Y3 */
    public void mo2578Y3() {
        C4835c.C4836a aVar = this.f2929a0;
        if (aVar != null) {
            aVar.mo22111b();
        }
        if (this.f2922I0.hasMessages(1)) {
            this.f2922I0.removeMessages(1);
        }
        super.mo2578Y3();
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0042, code lost:
        if (r7.f2952x0 != false) goto L_0x0058;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0056, code lost:
        if (r7.f2952x0 != false) goto L_0x0058;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0058, code lost:
        m3016m5(r8);
     */
    /* renamed from: Y4 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo3170Y4(android.view.InputEvent r8) {
        /*
            r7 = this;
            boolean r0 = r7.f2954z0
            r1 = 1
            r0 = r0 ^ r1
            boolean r2 = r8 instanceof android.view.KeyEvent
            r3 = 0
            if (r2 == 0) goto L_0x0026
            r2 = r8
            android.view.KeyEvent r2 = (android.view.KeyEvent) r2
            int r4 = r2.getKeyCode()
            int r5 = r2.getAction()
            android.view.View$OnKeyListener r6 = r7.f2951w0
            if (r6 == 0) goto L_0x0023
            android.view.View r3 = r7.mo2633x3()
            boolean r3 = r6.onKey(r3, r4, r2)
            r2 = r3
            r3 = r4
            goto L_0x0028
        L_0x0023:
            r3 = r4
            r2 = 0
            goto L_0x0028
        L_0x0026:
            r2 = 0
            r5 = 0
        L_0x0028:
            r4 = 4
            if (r3 == r4) goto L_0x005c
            r4 = 111(0x6f, float:1.56E-43)
            if (r3 == r4) goto L_0x005c
            switch(r3) {
                case 19: goto L_0x0045;
                case 20: goto L_0x0045;
                case 21: goto L_0x0045;
                case 22: goto L_0x0045;
                case 23: goto L_0x0045;
                default: goto L_0x0032;
            }
        L_0x0032:
            if (r2 == 0) goto L_0x006a
            if (r5 != 0) goto L_0x006a
            r7.m3017n5()
            r7.mo3179k5(r1)
            int r8 = r7.f2947s0
            if (r8 <= 0) goto L_0x006a
            boolean r0 = r7.f2952x0
            if (r0 == 0) goto L_0x006a
            goto L_0x0058
        L_0x0045:
            if (r0 == 0) goto L_0x0048
            r2 = 1
        L_0x0048:
            if (r5 != 0) goto L_0x006a
            r7.m3017n5()
            r7.mo3179k5(r1)
            int r8 = r7.f2947s0
            if (r8 <= 0) goto L_0x006a
            boolean r0 = r7.f2952x0
            if (r0 == 0) goto L_0x006a
        L_0x0058:
            r7.m3016m5(r8)
            goto L_0x006a
        L_0x005c:
            if (r0 != 0) goto L_0x006a
            android.view.KeyEvent r8 = (android.view.KeyEvent) r8
            int r8 = r8.getAction()
            if (r8 != r1) goto L_0x006b
            r7.mo3166T4(r1)
            goto L_0x006b
        L_0x006a:
            r1 = r2
        L_0x006b:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.app.C0668k.mo3170Y4(android.view.InputEvent):boolean");
    }

    /* access modifiers changed from: protected */
    /* renamed from: Z4 */
    public void mo3171Z4(int i, int i2) {
    }

    /* renamed from: b5 */
    public void mo3172b5(C0781c0 c0Var) {
        this.f2932d0 = c0Var;
        m3015j5();
        m3014i5();
        mo3178h5();
        C0685q qVar = this.f2931c0;
        if (qVar != null) {
            qVar.mo3054U4(c0Var);
        }
    }

    /* renamed from: c4 */
    public void mo2586c4() {
        super.mo2586c4();
        if (this.f2954z0 && this.f2952x0) {
            m3016m5(this.f2946r0);
        }
        mo3165S4().mo3729s(this.f2923J0);
        mo3165S4().mo3728r(this.f2924K0);
        C4835c.C4836a aVar = this.f2929a0;
        if (aVar != null) {
            aVar.mo22112c();
        }
    }

    /* renamed from: c5 */
    public void mo3173c5(int i) {
        if (i != 0 && i != 1 && i != 2) {
            throw new IllegalArgumentException("Invalid background type");
        } else if (i != this.f2943o0) {
            this.f2943o0 = i;
            m3018o5();
        }
    }

    /* renamed from: d5 */
    public void mo3174d5(boolean z) {
        if (z != this.f2952x0) {
            this.f2952x0 = z;
            if (mo2541D3() && mo2633x3().hasFocus()) {
                mo3179k5(true);
                if (z) {
                    m3016m5(this.f2946r0);
                } else {
                    m3017n5();
                }
            }
        }
    }

    /* renamed from: e4 */
    public void mo2590e4() {
        super.mo2590e4();
        VerticalGridView c5 = this.f2931c0.mo3213c5();
        if (c5 != null) {
            c5.mo3701C(-this.f2939k0);
            c5.mo3702D(-1.0f);
            c5.mo3719l(this.f2940l0 - this.f2939k0);
            c5.mo3720m(50.0f);
            c5.setPadding(c5.getPaddingLeft(), c5.getPaddingTop(), c5.getPaddingRight(), this.f2939k0);
            c5.mo3700B(2);
        }
        this.f2931c0.mo3054U4(this.f2932d0);
        C4835c.C4836a aVar = this.f2929a0;
        if (aVar != null) {
            aVar.mo22113d();
        }
    }

    /* renamed from: e5 */
    public void mo3175e5(C0798f fVar) {
        this.f2935g0 = fVar;
    }

    /* renamed from: f4 */
    public void mo2593f4() {
        C4835c.C4836a aVar = this.f2929a0;
        if (aVar != null) {
            aVar.mo22114e();
        }
        super.mo2593f4();
    }

    /* renamed from: f5 */
    public void mo3176f5(C0864t0 t0Var) {
        this.f2934f0 = t0Var;
        m3015j5();
        m3014i5();
    }

    /* renamed from: g4 */
    public void mo2595g4(View view, Bundle bundle) {
        this.f2954z0 = true;
        if (!this.f2953y0) {
            mo3180l5(false, false);
            this.f2953y0 = true;
        }
    }

    /* renamed from: g5 */
    public void mo3177g5(C0832n0 n0Var) {
        this.f2933e0 = n0Var;
        m3014i5();
        mo3178h5();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h5 */
    public void mo3178h5() {
        C0844p0[] b;
        Class<C0873w> cls = C0873w.class;
        C0781c0 c0Var = this.f2932d0;
        if (c0Var != null && c0Var.mo3666c() != null && (b = this.f2932d0.mo3666c().mo3141b()) != null) {
            for (int i = 0; i < b.length; i++) {
                if ((b[i] instanceof C0832n0) && b[i].mo3767c(cls) == null) {
                    C0873w wVar = new C0873w();
                    C0873w.C0874a aVar = new C0873w.C0874a();
                    aVar.mo3885a(0);
                    aVar.mo3886b(100.0f);
                    wVar.mo3884b(new C0873w.C0874a[]{aVar});
                    b[i].mo3821h(cls, wVar);
                }
            }
        }
    }

    /* renamed from: k5 */
    public void mo3179k5(boolean z) {
        mo3180l5(true, z);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l5 */
    public void mo3180l5(boolean z, boolean z2) {
        ValueAnimator valueAnimator;
        ValueAnimator valueAnimator2;
        if (mo2633x3() == null) {
            this.f2953y0 = z;
            return;
        }
        if (!mo2541D3()) {
            z2 = false;
        }
        if (z != this.f2954z0) {
            this.f2954z0 = z;
            if (!z) {
                m3017n5();
            }
            this.f2950v0 = (mo3165S4() == null || mo3165S4().mo3703a() == 0) ? this.f2948t0 : this.f2949u0;
            if (z) {
                m3013a5(this.f2916C0, this.f2915B0, z2);
                m3013a5(this.f2918E0, this.f2917D0, z2);
                valueAnimator2 = this.f2920G0;
                valueAnimator = this.f2919F0;
            } else {
                m3013a5(this.f2915B0, this.f2916C0, z2);
                m3013a5(this.f2917D0, this.f2918E0, z2);
                valueAnimator2 = this.f2919F0;
                valueAnimator = this.f2920G0;
            }
            m3013a5(valueAnimator2, valueAnimator, z2);
            if (z2) {
                mo2633x3().announceForAccessibility(mo2629v3(z ? R.string.lb_playback_controls_shown : R.string.lb_playback_controls_hidden));
            }
        } else if (!z2) {
            m3011P4(this.f2915B0, this.f2916C0);
            m3011P4(this.f2917D0, this.f2918E0);
            m3011P4(this.f2919F0, this.f2920G0);
        }
    }
}
