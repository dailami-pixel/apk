package androidx.leanback.app;

import android.animation.ValueAnimator;
import android.view.View;

/* renamed from: androidx.leanback.app.l */
class C0677l implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a */
    final /* synthetic */ C0668k f2962a;

    C0677l(C0668k kVar) {
        this.f2962a = kVar;
    }

    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        C0668k kVar = this.f2962a;
        int intValue = ((Integer) valueAnimator.getAnimatedValue()).intValue();
        kVar.f2914A0 = intValue;
        View view = kVar.f2942n0;
        if (view != null) {
            view.getBackground().setAlpha(intValue);
        }
    }
}
