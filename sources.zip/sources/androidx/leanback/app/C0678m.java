package androidx.leanback.app;

import android.animation.ValueAnimator;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

/* renamed from: androidx.leanback.app.m */
class C0678m implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a */
    final /* synthetic */ C0668k f2963a;

    C0678m(C0668k kVar) {
        this.f2963a = kVar;
    }

    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        RecyclerView.C1142b0 findViewHolderForAdapterPosition;
        View view;
        if (this.f2963a.mo3165S4() != null && (findViewHolderForAdapterPosition = this.f2963a.mo3165S4().findViewHolderForAdapterPosition(0)) != null && (view = findViewHolderForAdapterPosition.itemView) != null) {
            float floatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            view.setAlpha(floatValue);
            view.setTranslationY((1.0f - floatValue) * ((float) this.f2963a.f2950v0));
        }
    }
}
