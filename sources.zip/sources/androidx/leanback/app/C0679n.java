package androidx.leanback.app;

import android.animation.ValueAnimator;
import android.view.View;

/* renamed from: androidx.leanback.app.n */
class C0679n implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a */
    final /* synthetic */ C0668k f2964a;

    C0679n(C0668k kVar) {
        this.f2964a = kVar;
    }

    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        if (this.f2964a.mo3165S4() != null) {
            float floatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            int childCount = this.f2964a.mo3165S4().getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = this.f2964a.mo3165S4().getChildAt(i);
                if (this.f2964a.mo3165S4().getChildAdapterPosition(childAt) > 0) {
                    childAt.setAlpha(floatValue);
                    childAt.setTranslationY((1.0f - floatValue) * ((float) this.f2964a.f2950v0));
                }
            }
        }
    }
}
