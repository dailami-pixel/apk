package androidx.leanback.app;

import android.view.View;
import androidx.leanback.widget.C0766a;
import androidx.leanback.widget.C0781c0;
import androidx.leanback.widget.C0786d0;
import androidx.leanback.widget.C0806h0;
import androidx.leanback.widget.C0832n0;
import androidx.leanback.widget.C0837o0;
import androidx.leanback.widget.C0844p0;
import androidx.leanback.widget.C0864t0;
import androidx.leanback.widget.C0870v0;
import java.util.Objects;
import p098d.p140l.p143e.C4835c;

/* renamed from: androidx.leanback.app.o */
public class C0680o extends C4835c implements C0837o0 {

    /* renamed from: b */
    final C0668k f2965b;

    /* renamed from: c */
    final C4835c.C4837b f2966c = new C0682b();

    /* renamed from: androidx.leanback.app.o$a */
    class C0681a implements C0806h0 {

        /* renamed from: a */
        final /* synthetic */ C0786d0 f2967a;

        C0681a(C0680o oVar, C0786d0 d0Var) {
            this.f2967a = d0Var;
        }

        /* renamed from: a */
        public void mo3184a(C0844p0.C0845a aVar, Object obj, C0870v0.C0872b bVar, Object obj2) {
            C0864t0 t0Var = (C0864t0) obj2;
            if (obj instanceof C0766a) {
                this.f2967a.mo3689d((C0766a) obj);
            }
        }
    }

    /* renamed from: androidx.leanback.app.o$b */
    class C0682b extends C4835c.C4837b {
        C0682b() {
        }

        /* renamed from: a */
        public void mo3204a(boolean z) {
            C0680o.this.f2965b.mo3168W4(z);
        }

        /* renamed from: b */
        public void mo3205b(int i, CharSequence charSequence) {
            C0680o.this.f2965b.mo3169X4();
        }

        /* renamed from: c */
        public void mo3206c(int i, int i2) {
            C0680o.this.f2965b.mo3171Z4(i, i2);
        }
    }

    public C0680o(C0668k kVar) {
        this.f2965b = kVar;
    }

    /* renamed from: b */
    public void mo3195b(C0837o0.C0838a aVar) {
        Objects.requireNonNull(this.f2965b);
    }

    /* renamed from: c */
    public C4835c.C4837b mo3196c() {
        return this.f2966c;
    }

    /* renamed from: d */
    public void mo3197d() {
        C0781c0 c0Var = this.f2965b.f2932d0;
        if (c0Var != null) {
            c0Var.mo3670g(0, 1);
        }
    }

    /* renamed from: e */
    public void mo3198e(boolean z) {
        this.f2965b.mo3174d5(z);
    }

    /* renamed from: f */
    public void mo3199f(C4835c.C4836a aVar) {
        this.f2965b.f2929a0 = aVar;
    }

    /* renamed from: g */
    public void mo3200g(C0786d0 d0Var) {
        this.f2965b.f2936h0 = new C0681a(this, d0Var);
    }

    /* renamed from: h */
    public void mo3201h(View.OnKeyListener onKeyListener) {
        this.f2965b.f2951w0 = onKeyListener;
    }

    /* renamed from: i */
    public void mo3202i(C0864t0 t0Var) {
        this.f2965b.mo3176f5(t0Var);
    }

    /* renamed from: j */
    public void mo3203j(C0832n0 n0Var) {
        this.f2965b.mo3177g5(n0Var);
    }
}
