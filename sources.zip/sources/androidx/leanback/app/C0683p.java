package androidx.leanback.app;

import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

/* renamed from: androidx.leanback.app.p */
public final class C0683p {

    /* renamed from: a */
    private long f2969a = 1000;

    /* renamed from: b */
    ViewGroup f2970b;

    /* renamed from: c */
    View f2971c;

    /* renamed from: d */
    private Handler f2972d = new Handler();

    /* renamed from: e */
    boolean f2973e = true;

    /* renamed from: f */
    boolean f2974f;

    /* renamed from: g */
    boolean f2975g;

    /* renamed from: h */
    private Runnable f2976h = new C0684a();

    /* renamed from: androidx.leanback.app.p$a */
    class C0684a implements Runnable {
        C0684a() {
        }

        public void run() {
            C0683p pVar = C0683p.this;
            if (pVar.f2973e) {
                boolean z = pVar.f2974f;
                if ((z || pVar.f2970b != null) && pVar.f2975g) {
                    View view = pVar.f2971c;
                    if (view == null) {
                        pVar.f2971c = new ProgressBar(C0683p.this.f2970b.getContext(), (AttributeSet) null, 16842874);
                        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
                        layoutParams.gravity = 17;
                        C0683p pVar2 = C0683p.this;
                        pVar2.f2970b.addView(pVar2.f2971c, layoutParams);
                    } else if (z) {
                        view.setVisibility(0);
                    }
                }
            }
        }
    }

    /* renamed from: a */
    public void mo3207a() {
        this.f2975g = false;
        if (this.f2974f) {
            this.f2971c.setVisibility(4);
        } else {
            View view = this.f2971c;
            if (view != null) {
                this.f2970b.removeView(view);
                this.f2971c = null;
            }
        }
        this.f2972d.removeCallbacks(this.f2976h);
    }

    /* renamed from: b */
    public void mo3208b(long j) {
        this.f2969a = j;
    }

    /* renamed from: c */
    public void mo3209c(View view) {
        if (view.getParent() != null) {
            this.f2971c = view;
            view.setVisibility(4);
            this.f2974f = true;
            return;
        }
        throw new IllegalArgumentException("Must have a parent");
    }

    /* renamed from: d */
    public void mo3210d() {
        if (this.f2973e) {
            this.f2975g = true;
            this.f2972d.postDelayed(this.f2976h, this.f2969a);
        }
    }
}
