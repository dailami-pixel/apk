package androidx.leanback.app;

import android.animation.TimeAnimator;
import android.os.Bundle;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.leanback.app.C0632f;
import androidx.leanback.widget.C0772b0;
import androidx.leanback.widget.C0798f;
import androidx.leanback.widget.C0801g;
import androidx.leanback.widget.C0806h0;
import androidx.leanback.widget.C0826l1;
import androidx.leanback.widget.C0844p0;
import androidx.leanback.widget.C0870v0;
import androidx.leanback.widget.C0878y;
import androidx.leanback.widget.HorizontalGridView;
import androidx.leanback.widget.VerticalGridView;
import androidx.recyclerview.widget.RecyclerView;
import com.vidio.android.p195tv.R;
import java.util.ArrayList;

/* renamed from: androidx.leanback.app.q */
public class C0685q extends C0620a implements C0632f.C0653u, C0632f.C0649q {

    /* renamed from: i0 */
    private C0689c f2978i0;

    /* renamed from: j0 */
    private C0690d f2979j0;

    /* renamed from: k0 */
    C0878y.C0882d f2980k0;

    /* renamed from: l0 */
    private int f2981l0;

    /* renamed from: m0 */
    boolean f2982m0 = true;

    /* renamed from: n0 */
    boolean f2983n0;

    /* renamed from: o0 */
    private int f2984o0 = RecyclerView.UNDEFINED_DURATION;

    /* renamed from: p0 */
    boolean f2985p0 = true;

    /* renamed from: q0 */
    boolean f2986q0;

    /* renamed from: r0 */
    C0801g f2987r0;

    /* renamed from: s0 */
    C0798f f2988s0;

    /* renamed from: t0 */
    int f2989t0;

    /* renamed from: u0 */
    Interpolator f2990u0 = new DecelerateInterpolator(2.0f);

    /* renamed from: v0 */
    private RecyclerView.C1167t f2991v0;

    /* renamed from: w0 */
    private ArrayList<C0844p0> f2992w0;

    /* renamed from: x0 */
    C0878y.C0880b f2993x0;

    /* renamed from: y0 */
    private final C0878y.C0880b f2994y0 = new C0686a();

    /* renamed from: androidx.leanback.app.q$a */
    class C0686a extends C0878y.C0880b {
        C0686a() {
        }

        /* renamed from: a */
        public void mo3218a(C0844p0 p0Var, int i) {
            C0878y.C0880b bVar = C0685q.this.f2993x0;
            if (bVar != null) {
                bVar.mo3218a(p0Var, i);
            }
        }

        /* renamed from: b */
        public void mo3181b(C0878y.C0882d dVar) {
            ((C0870v0) dVar.mo3903d()).mo3876x(dVar.mo3904e(), C0685q.this.f2982m0);
            C0870v0 v0Var = (C0870v0) dVar.mo3903d();
            C0870v0.C0872b m = v0Var.mo3873m(dVar.mo3904e());
            v0Var.mo3641v(m, C0685q.this.f2985p0);
            v0Var.mo3633k(m, C0685q.this.f2986q0);
            C0878y.C0880b bVar = C0685q.this.f2993x0;
            if (bVar != null) {
                bVar.mo3181b(dVar);
            }
        }

        /* renamed from: c */
        public void mo3182c(C0878y.C0882d dVar) {
            C0878y.C0880b bVar = C0685q.this.f2993x0;
            if (bVar != null) {
                bVar.mo3182c(dVar);
            }
        }

        /* renamed from: d */
        public void mo3147d(C0878y.C0882d dVar) {
            VerticalGridView c5 = C0685q.this.mo3213c5();
            if (c5 != null) {
                c5.setClipChildren(false);
            }
            C0685q.this.mo3217h5(dVar);
            C0685q qVar = C0685q.this;
            qVar.f2983n0 = true;
            dVar.mo3905f(new C0691e(dVar));
            C0685q.m3073f5(dVar, false, true);
            C0878y.C0880b bVar = C0685q.this.f2993x0;
            if (bVar != null) {
                bVar.mo3147d(dVar);
            }
            C0870v0.C0872b m = ((C0870v0) dVar.mo3903d()).mo3873m(dVar.mo3904e());
            m.mo3882v(C0685q.this.f2987r0);
            m.mo3881u(C0685q.this.f2988s0);
        }

        /* renamed from: e */
        public void mo3183e(C0878y.C0882d dVar) {
            C0878y.C0882d dVar2 = C0685q.this.f2980k0;
            if (dVar2 == dVar) {
                C0685q.m3073f5(dVar2, false, true);
                C0685q.this.f2980k0 = null;
            }
            C0878y.C0880b bVar = C0685q.this.f2993x0;
            if (bVar != null) {
                bVar.mo3183e(dVar);
            }
        }

        /* renamed from: f */
        public void mo3219f(C0878y.C0882d dVar) {
            C0685q.m3073f5(dVar, false, true);
            C0878y.C0880b bVar = C0685q.this.f2993x0;
            if (bVar != null) {
                bVar.mo3219f(dVar);
            }
        }
    }

    /* renamed from: androidx.leanback.app.q$b */
    class C0687b implements C0826l1 {

        /* renamed from: a */
        final /* synthetic */ C0844p0.C0846b f2996a;

        /* renamed from: androidx.leanback.app.q$b$a */
        class C0688a implements Runnable {

            /* renamed from: a */
            final /* synthetic */ RecyclerView.C1142b0 f2997a;

            C0688a(RecyclerView.C1142b0 b0Var) {
                this.f2997a = b0Var;
            }

            public void run() {
                C0687b.this.f2996a.mo3649a(C0685q.m3072b5((C0878y.C0882d) this.f2997a));
            }
        }

        C0687b(C0685q qVar, C0844p0.C0846b bVar) {
            this.f2996a = bVar;
        }

        /* renamed from: a */
        public void mo3220a(RecyclerView.C1142b0 b0Var) {
            b0Var.itemView.post(new C0688a(b0Var));
        }
    }

    /* renamed from: androidx.leanback.app.q$c */
    public static class C0689c extends C0632f.C0648p<C0685q> {
        public C0689c(C0685q qVar) {
            super(qVar);
            mo3129j(true);
        }

        /* renamed from: c */
        public boolean mo3122c() {
            C0685q qVar = (C0685q) mo3120a();
            return (qVar.mo3213c5() == null || qVar.mo3213c5().getScrollState() == 0) ? false : true;
        }

        /* renamed from: d */
        public void mo3123d() {
            ((C0685q) mo3120a()).mo3052S4();
        }

        /* renamed from: e */
        public boolean mo3124e() {
            return ((C0685q) mo3120a()).mo3053T4();
        }

        /* renamed from: f */
        public void mo3125f() {
            C0685q qVar = (C0685q) mo3120a();
            VerticalGridView verticalGridView = qVar.f2779b0;
            if (verticalGridView != null) {
                verticalGridView.mo3734u(false);
                qVar.f2779b0.setLayoutFrozen(true);
                qVar.f2779b0.mo3718k(true);
            }
        }

        /* renamed from: g */
        public void mo3126g(int i) {
            ((C0685q) mo3120a()).mo3214d5(i);
        }

        /* renamed from: h */
        public void mo3127h(boolean z) {
            C0685q qVar = (C0685q) mo3120a();
            qVar.f2985p0 = z;
            VerticalGridView c5 = qVar.mo3213c5();
            if (c5 != null) {
                int childCount = c5.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    C0878y.C0882d dVar = (C0878y.C0882d) c5.getChildViewHolder(c5.getChildAt(i));
                    C0870v0 v0Var = (C0870v0) dVar.mo3903d();
                    v0Var.mo3641v(v0Var.mo3873m(dVar.mo3904e()), qVar.f2985p0);
                }
            }
        }

        /* renamed from: i */
        public void mo3128i(boolean z) {
            C0685q qVar = (C0685q) mo3120a();
            qVar.f2982m0 = z;
            VerticalGridView c5 = qVar.mo3213c5();
            if (c5 != null) {
                int childCount = c5.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    C0878y.C0882d dVar = (C0878y.C0882d) c5.getChildViewHolder(c5.getChildAt(i));
                    ((C0870v0) dVar.mo3903d()).mo3876x(dVar.mo3904e(), qVar.f2982m0);
                }
            }
        }
    }

    /* renamed from: androidx.leanback.app.q$d */
    public static class C0690d extends C0632f.C0652t<C0685q> {
        public C0690d(C0685q qVar) {
            super(qVar);
        }

        /* renamed from: a */
        public C0870v0.C0872b mo3133a(int i) {
            VerticalGridView verticalGridView = ((C0685q) mo3134b()).f2779b0;
            if (verticalGridView == null) {
                return null;
            }
            return C0685q.m3072b5((C0878y.C0882d) verticalGridView.findViewHolderForAdapterPosition(i));
        }

        /* renamed from: c */
        public void mo3135c(C0806h0 h0Var) {
            C0685q qVar = (C0685q) mo3134b();
            qVar.f2988s0 = h0Var;
            if (qVar.f2983n0) {
                throw new IllegalStateException("Item clicked listener must be set before views are created");
            }
        }
    }

    /* renamed from: androidx.leanback.app.q$e */
    final class C0691e implements TimeAnimator.TimeListener {

        /* renamed from: a */
        final C0870v0 f2999a;

        /* renamed from: b */
        final C0844p0.C0845a f3000b;

        /* renamed from: c */
        final TimeAnimator f3001c;

        /* renamed from: d */
        int f3002d;

        /* renamed from: e */
        Interpolator f3003e;

        /* renamed from: f */
        float f3004f;

        /* renamed from: g */
        float f3005g;

        C0691e(C0878y.C0882d dVar) {
            TimeAnimator timeAnimator = new TimeAnimator();
            this.f3001c = timeAnimator;
            this.f2999a = (C0870v0) dVar.mo3903d();
            this.f3000b = dVar.mo3904e();
            timeAnimator.setTimeListener(this);
        }

        public void onTimeUpdate(TimeAnimator timeAnimator, long j, long j2) {
            float f;
            if (this.f3001c.isRunning()) {
                int i = this.f3002d;
                if (j >= ((long) i)) {
                    f = 1.0f;
                    this.f3001c.end();
                } else {
                    f = (float) (((double) j) / ((double) i));
                }
                Interpolator interpolator = this.f3003e;
                if (interpolator != null) {
                    f = interpolator.getInterpolation(f);
                }
                this.f2999a.mo3871A(this.f3000b, (f * this.f3005g) + this.f3004f);
            }
        }
    }

    /* renamed from: Z4 */
    private void m3071Z4(boolean z) {
        this.f2986q0 = z;
        VerticalGridView c5 = mo3213c5();
        if (c5 != null) {
            int childCount = c5.getChildCount();
            for (int i = 0; i < childCount; i++) {
                C0878y.C0882d dVar = (C0878y.C0882d) c5.getChildViewHolder(c5.getChildAt(i));
                C0870v0 v0Var = (C0870v0) dVar.mo3903d();
                v0Var.mo3633k(v0Var.mo3873m(dVar.mo3904e()), z);
            }
        }
    }

    /* renamed from: b5 */
    static C0870v0.C0872b m3072b5(C0878y.C0882d dVar) {
        if (dVar == null) {
            return null;
        }
        return ((C0870v0) dVar.mo3903d()).mo3873m(dVar.mo3904e());
    }

    /* renamed from: f5 */
    static void m3073f5(C0878y.C0882d dVar, boolean z, boolean z2) {
        C0691e eVar = (C0691e) dVar.mo3901a();
        eVar.f3001c.end();
        float f = z ? 1.0f : 0.0f;
        if (z2) {
            eVar.f2999a.mo3871A(eVar.f3000b, f);
        } else if (eVar.f2999a.mo3874n(eVar.f3000b) != f) {
            C0685q qVar = C0685q.this;
            eVar.f3002d = qVar.f2989t0;
            eVar.f3003e = qVar.f2990u0;
            float n = eVar.f2999a.mo3874n(eVar.f3000b);
            eVar.f3004f = n;
            eVar.f3005g = f - n;
            eVar.f3001c.start();
        }
        ((C0870v0) dVar.mo3903d()).mo3877y(dVar.mo3904e(), z);
    }

    /* renamed from: M3 */
    public void mo2559M3(Bundle bundle) {
        super.mo2559M3(bundle);
        this.f2989t0 = mo2619r3().getInteger(R.integer.lb_browse_rows_anim_duration);
    }

    /* access modifiers changed from: protected */
    /* renamed from: P4 */
    public VerticalGridView mo3049P4(View view) {
        return (VerticalGridView) view.findViewById(R.id.container_list);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Q4 */
    public int mo3050Q4() {
        return R.layout.lb_rows_fragment;
    }

    /* renamed from: R3 */
    public void mo2567R3() {
        this.f2983n0 = false;
        super.mo2567R3();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: R4 */
    public void mo3051R4(RecyclerView recyclerView, RecyclerView.C1142b0 b0Var, int i, int i2) {
        C0878y.C0882d dVar = this.f2980k0;
        boolean z = true;
        if (!(dVar == b0Var && this.f2981l0 == i2)) {
            this.f2981l0 = i2;
            if (dVar != null) {
                m3073f5(dVar, false, false);
            }
            C0878y.C0882d dVar2 = (C0878y.C0882d) b0Var;
            this.f2980k0 = dVar2;
            if (dVar2 != null) {
                m3073f5(dVar2, true, false);
            }
        }
        C0689c cVar = this.f2978i0;
        if (cVar != null) {
            C0632f.C0646n nVar = cVar.f2882c;
            if (i > 0) {
                z = false;
            }
            nVar.f2878a = z;
            C0632f fVar = C0632f.this;
            C0632f.C0648p pVar = fVar.f2823D0;
            if (pVar != null && pVar.f2882c == nVar && fVar.f2844Y0) {
                fVar.mo3091J5();
            }
        }
    }

    /* renamed from: S4 */
    public void mo3052S4() {
        super.mo3052S4();
        m3071Z4(false);
    }

    /* renamed from: T4 */
    public boolean mo3053T4() {
        boolean T4 = super.mo3053T4();
        if (T4) {
            m3071Z4(true);
        }
        return T4;
    }

    /* renamed from: X */
    public C0632f.C0652t mo3136X() {
        if (this.f2979j0 == null) {
            this.f2979j0 = new C0690d(this);
        }
        return this.f2979j0;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Y4 */
    public void mo3058Y4() {
        super.mo3058Y4();
        this.f2980k0 = null;
        this.f2983n0 = false;
        C0878y yVar = this.f2781d0;
        if (yVar != null) {
            yVar.mo3892j(this.f2994y0);
        }
    }

    /* renamed from: a5 */
    public C0870v0.C0872b mo3212a5(int i) {
        VerticalGridView c5 = mo3213c5();
        if (c5 == null) {
            return null;
        }
        return m3072b5((C0878y.C0882d) c5.findViewHolderForAdapterPosition(i));
    }

    /* renamed from: c5 */
    public VerticalGridView mo3213c5() {
        return this.f2779b0;
    }

    /* renamed from: d4 */
    public void mo2588d4(Bundle bundle) {
        bundle.putInt("currentSelectedPosition", this.f2782e0);
    }

    /* renamed from: d5 */
    public void mo3214d5(int i) {
        if (i != Integer.MIN_VALUE) {
            this.f2984o0 = i;
            VerticalGridView c5 = mo3213c5();
            if (c5 != null) {
                c5.mo3719l(0);
                c5.mo3720m(-1.0f);
                c5.mo3721n(true);
                c5.mo3701C(this.f2984o0);
                c5.mo3702D(-1.0f);
                c5.mo3700B(0);
            }
        }
    }

    /* renamed from: e5 */
    public void mo3215e5(C0801g gVar) {
        this.f2987r0 = gVar;
        VerticalGridView c5 = mo3213c5();
        if (c5 != null) {
            int childCount = c5.getChildCount();
            for (int i = 0; i < childCount; i++) {
                m3072b5((C0878y.C0882d) c5.getChildViewHolder(c5.getChildAt(i))).mo3882v(this.f2987r0);
            }
        }
    }

    /* renamed from: g4 */
    public void mo2595g4(View view, Bundle bundle) {
        super.mo2595g4(view, bundle);
        mo3213c5().mo3722o(R.id.row_content);
        mo3213c5().mo3735v(2);
        mo3214d5(this.f2984o0);
        this.f2991v0 = null;
        this.f2992w0 = null;
        C0689c cVar = this.f2978i0;
        if (cVar != null) {
            C0632f.C0646n nVar = cVar.f2882c;
            C0632f fVar = C0632f.this;
            fVar.f2802t0.mo22122e(fVar.f2820A0);
            C0632f fVar2 = C0632f.this;
            if (!fVar2.f2844Y0) {
                fVar2.f2802t0.mo22122e(fVar2.f2821B0);
            }
        }
    }

    /* renamed from: g5 */
    public void mo3216g5(int i, boolean z, C0844p0.C0846b bVar) {
        VerticalGridView c5 = mo3213c5();
        if (c5 != null) {
            C0687b bVar2 = null;
            if (bVar != null) {
                bVar2 = new C0687b(this, bVar);
            }
            if (z) {
                c5.mo3699A(i, bVar2);
            } else {
                c5.mo3738y(i, bVar2);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h5 */
    public void mo3217h5(C0878y.C0882d dVar) {
        C0870v0.C0872b m = ((C0870v0) dVar.mo3903d()).mo3873m(dVar.mo3904e());
        if (m instanceof C0772b0.C0778e) {
            C0772b0.C0778e eVar = (C0772b0.C0778e) m;
            HorizontalGridView x = eVar.mo3652x();
            RecyclerView.C1167t tVar = this.f2991v0;
            if (tVar == null) {
                this.f2991v0 = x.getRecycledViewPool();
            } else {
                x.setRecycledViewPool(tVar);
            }
            C0878y w = eVar.mo3651w();
            ArrayList<C0844p0> arrayList = this.f2992w0;
            if (arrayList == null) {
                this.f2992w0 = w.mo3888c();
            } else {
                w.mo3894l(arrayList);
            }
        }
    }

    /* renamed from: v0 */
    public C0632f.C0648p mo3130v0() {
        if (this.f2978i0 == null) {
            this.f2978i0 = new C0689c(this);
        }
        return this.f2978i0;
    }
}
