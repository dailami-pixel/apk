package androidx.leanback.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.leanback.transition.C0729a;
import androidx.leanback.widget.BrowseFrameLayout;
import androidx.leanback.widget.C0781c0;
import androidx.leanback.widget.C0796e0;
import androidx.leanback.widget.C0806h0;
import androidx.leanback.widget.C0811i0;
import androidx.leanback.widget.C0819k1;
import androidx.leanback.widget.C0844p0;
import androidx.leanback.widget.C0864t0;
import androidx.leanback.widget.C0870v0;
import com.vidio.android.p195tv.R;
import p098d.p140l.p145g.C4843a;

/* renamed from: androidx.leanback.app.r */
public class C0692r extends C0623b {

    /* renamed from: A0 */
    private C0806h0 f3007A0;

    /* renamed from: B0 */
    private Object f3008B0;

    /* renamed from: C0 */
    private int f3009C0 = -1;

    /* renamed from: D0 */
    final C4843a.C4846c f3010D0 = new C0693a("SET_ENTRANCE_START_STATE");

    /* renamed from: E0 */
    private final C0811i0 f3011E0 = new C0694b();

    /* renamed from: F0 */
    private final C0796e0 f3012F0 = new C0695c();

    /* renamed from: w0 */
    private C0781c0 f3013w0;

    /* renamed from: x0 */
    private C0819k1 f3014x0;

    /* renamed from: y0 */
    C0819k1.C0823c f3015y0;

    /* renamed from: z0 */
    C0811i0 f3016z0;

    /* renamed from: androidx.leanback.app.r$a */
    class C0693a extends C4843a.C4846c {
        C0693a(String str) {
            super(str, false, true);
        }

        /* renamed from: c */
        public void mo3070c() {
            C0692r.this.mo3225h5(false);
        }
    }

    /* renamed from: androidx.leanback.app.r$b */
    class C0694b implements C0811i0 {
        C0694b() {
        }

        /* renamed from: a */
        public void mo3132a(C0844p0.C0845a aVar, Object obj, C0870v0.C0872b bVar, Object obj2) {
            C0864t0 t0Var = (C0864t0) obj2;
            C0692r.this.mo3223f5(C0692r.this.f3015y0.mo3766s().mo3703a());
            C0811i0 i0Var = C0692r.this.f3016z0;
            if (i0Var != null) {
                i0Var.mo3132a(aVar, obj, bVar, t0Var);
            }
        }
    }

    /* renamed from: androidx.leanback.app.r$c */
    class C0695c implements C0796e0 {
        C0695c() {
        }

        /* renamed from: a */
        public void mo3230a(ViewGroup viewGroup, View view, int i, long j) {
            if (i == 0) {
                C0692r.this.mo3229l5();
            }
        }
    }

    /* renamed from: androidx.leanback.app.r$d */
    class C0696d implements Runnable {
        C0696d() {
        }

        public void run() {
            C0692r.this.mo3225h5(true);
        }
    }

    /* renamed from: m5 */
    private void m3108m5() {
        C0819k1.C0823c cVar = this.f3015y0;
        if (cVar != null) {
            this.f3014x0.mo3748b(cVar, this.f3013w0);
            if (this.f3009C0 != -1) {
                this.f3015y0.mo3766s().mo3737x(this.f3009C0);
            }
        }
    }

    /* renamed from: P3 */
    public View mo2565P3(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        ViewGroup viewGroup2 = (ViewGroup) layoutInflater.inflate(R.layout.lb_vertical_grid_fragment, viewGroup, false);
        mo3076S4(layoutInflater, (ViewGroup) viewGroup2.findViewById(R.id.grid_frame), bundle);
        this.f2804v0.f2970b = viewGroup2;
        ViewGroup viewGroup3 = (ViewGroup) viewGroup2.findViewById(R.id.browse_grid_dock);
        C0819k1.C0823c k = this.f3014x0.mo3749d(viewGroup3);
        this.f3015y0 = k;
        viewGroup3.addView(k.f3529a);
        this.f3015y0.mo3766s().mo3726p(this.f3012F0);
        this.f3008B0 = C0729a.m3171c(viewGroup3, new C0696d());
        m3108m5();
        return viewGroup2;
    }

    /* renamed from: R3 */
    public void mo2567R3() {
        super.mo2567R3();
        this.f3015y0 = null;
    }

    /* access modifiers changed from: protected */
    /* renamed from: Y4 */
    public Object mo3063Y4() {
        return C0729a.m3172d(mo2583b3(), R.transition.lb_vertical_grid_entrance_transition);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Z4 */
    public void mo3064Z4() {
        super.mo3064Z4();
        this.f2802t0.mo22118a(this.f3010D0);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a5 */
    public void mo3065a5() {
        super.mo3065a5();
        this.f2802t0.mo22121d(this.f2791i0, this.f3010D0, this.f2797o0);
    }

    /* renamed from: e4 */
    public void mo2590e4() {
        super.mo2590e4();
        ((BrowseFrameLayout) mo2633x3().findViewById(R.id.grid_frame)).mo3328b(mo3073P4().mo3744a());
    }

    /* access modifiers changed from: protected */
    /* renamed from: e5 */
    public void mo3069e5(Object obj) {
        C0729a.m3173e(this.f3008B0, obj);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f5 */
    public void mo3223f5(int i) {
        if (i != this.f3009C0) {
            this.f3009C0 = i;
            mo3229l5();
        }
    }

    /* renamed from: g5 */
    public void mo3224g5(C0781c0 c0Var) {
        this.f3013w0 = c0Var;
        m3108m5();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h5 */
    public void mo3225h5(boolean z) {
        this.f3014x0.mo3761m(this.f3015y0, z);
    }

    /* renamed from: i5 */
    public void mo3226i5(C0819k1 k1Var) {
        this.f3014x0 = k1Var;
        k1Var.mo3764p(this.f3011E0);
        C0806h0 h0Var = this.f3007A0;
        if (h0Var != null) {
            this.f3014x0.mo3763o(h0Var);
        }
    }

    /* renamed from: j5 */
    public void mo3227j5(C0806h0 h0Var) {
        this.f3007A0 = h0Var;
        C0819k1 k1Var = this.f3014x0;
        if (k1Var != null) {
            k1Var.mo3763o(h0Var);
        }
    }

    /* renamed from: k5 */
    public void mo3228k5(C0811i0 i0Var) {
        this.f3016z0 = i0Var;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l5 */
    public void mo3229l5() {
        if (this.f3015y0.mo3766s().findViewHolderForAdapterPosition(this.f3009C0) != null) {
            mo3081X4(!this.f3015y0.mo3766s().mo3705d(this.f3009C0));
        }
    }
}
