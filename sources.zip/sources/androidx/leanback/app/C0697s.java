package androidx.leanback.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import com.vidio.android.p195tv.R;

/* renamed from: androidx.leanback.app.s */
public class C0697s extends C0668k {

    /* renamed from: P0 */
    SurfaceView f3021P0;

    /* renamed from: Q0 */
    SurfaceHolder.Callback f3022Q0;

    /* renamed from: R0 */
    int f3023R0 = 0;

    /* renamed from: androidx.leanback.app.s$a */
    class C0698a implements SurfaceHolder.Callback {
        C0698a() {
        }

        public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
            SurfaceHolder.Callback callback = C0697s.this.f3022Q0;
            if (callback != null) {
                callback.surfaceChanged(surfaceHolder, i, i2, i3);
            }
        }

        public void surfaceCreated(SurfaceHolder surfaceHolder) {
            SurfaceHolder.Callback callback = C0697s.this.f3022Q0;
            if (callback != null) {
                callback.surfaceCreated(surfaceHolder);
            }
            C0697s.this.f3023R0 = 1;
        }

        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            SurfaceHolder.Callback callback = C0697s.this.f3022Q0;
            if (callback != null) {
                callback.surfaceDestroyed(surfaceHolder);
            }
            C0697s.this.f3023R0 = 0;
        }
    }

    /* renamed from: P3 */
    public View mo2565P3(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        ViewGroup viewGroup2 = (ViewGroup) super.mo2565P3(layoutInflater, viewGroup, bundle);
        SurfaceView surfaceView = (SurfaceView) LayoutInflater.from(mo2583b3()).inflate(R.layout.lb_video_surface, viewGroup2, false);
        this.f3021P0 = surfaceView;
        viewGroup2.addView(surfaceView, 0);
        this.f3021P0.getHolder().addCallback(new C0698a());
        mo3173c5(2);
        return viewGroup2;
    }

    /* renamed from: R3 */
    public void mo2567R3() {
        this.f3021P0 = null;
        this.f3023R0 = 0;
        super.mo2567R3();
    }

    /* access modifiers changed from: protected */
    /* renamed from: Z4 */
    public void mo3171Z4(int i, int i2) {
        int width = mo2633x3().getWidth();
        int height = mo2633x3().getHeight();
        ViewGroup.LayoutParams layoutParams = this.f3021P0.getLayoutParams();
        int i3 = width * i2;
        int i4 = i * height;
        if (i3 > i4) {
            layoutParams.height = height;
            layoutParams.width = i4 / i2;
        } else {
            layoutParams.width = width;
            layoutParams.height = i3 / i;
        }
        this.f3021P0.setLayoutParams(layoutParams);
    }

    /* renamed from: p5 */
    public SurfaceView mo3232p5() {
        return this.f3021P0;
    }

    /* renamed from: q5 */
    public void mo3233q5(SurfaceHolder.Callback callback) {
        this.f3022Q0 = callback;
        if (callback != null && this.f3023R0 == 1) {
            callback.surfaceCreated(this.f3021P0.getHolder());
        }
    }
}
