package androidx.leanback.app;

import android.view.SurfaceHolder;
import p098d.p140l.p143e.C4840e;

/* renamed from: androidx.leanback.app.t */
public class C0699t extends C0680o implements C4840e {

    /* renamed from: d */
    private final C0697s f3025d;

    public C0699t(C0697s sVar) {
        super(sVar);
        this.f3025d = sVar;
    }

    /* renamed from: a */
    public void mo3237a(SurfaceHolder.Callback callback) {
        this.f3025d.mo3233q5(callback);
    }
}
