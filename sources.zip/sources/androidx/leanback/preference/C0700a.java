package androidx.leanback.preference;

import androidx.preference.C1113g;

/* renamed from: androidx.leanback.preference.a */
public abstract class C0700a extends C1113g {
}
