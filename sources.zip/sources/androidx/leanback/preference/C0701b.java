package androidx.leanback.preference;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Checkable;
import android.widget.TextView;
import androidx.leanback.widget.VerticalGridView;
import androidx.preference.DialogPreference;
import androidx.preference.ListPreference;
import androidx.preference.MultiSelectListPreference;
import androidx.recyclerview.widget.RecyclerView;
import com.vidio.android.p195tv.R;
import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import p098d.p112d.C4619c;

/* renamed from: androidx.leanback.preference.b */
public class C0701b extends C0706c {

    /* renamed from: b */
    private boolean f3027b;

    /* renamed from: c */
    private CharSequence[] f3028c;

    /* renamed from: d */
    private CharSequence[] f3029d;

    /* renamed from: e */
    private CharSequence f3030e;

    /* renamed from: f */
    private CharSequence f3031f;

    /* renamed from: g */
    Set<String> f3032g;

    /* renamed from: h */
    private String f3033h;

    /* renamed from: androidx.leanback.preference.b$a */
    public class C0702a extends RecyclerView.C1147g<C0704c> implements C0704c.C0705a {

        /* renamed from: a */
        private final CharSequence[] f3034a;

        /* renamed from: b */
        private final CharSequence[] f3035b;

        /* renamed from: c */
        private final Set<String> f3036c;

        public C0702a(CharSequence[] charSequenceArr, CharSequence[] charSequenceArr2, Set<String> set) {
            this.f3034a = charSequenceArr;
            this.f3035b = charSequenceArr2;
            this.f3036c = new HashSet(set);
        }

        /* renamed from: b */
        public void mo3243b(C0704c cVar) {
            int adapterPosition = cVar.getAdapterPosition();
            if (adapterPosition != -1) {
                String charSequence = this.f3035b[adapterPosition].toString();
                if (this.f3036c.contains(charSequence)) {
                    this.f3036c.remove(charSequence);
                } else {
                    this.f3036c.add(charSequence);
                }
                MultiSelectListPreference multiSelectListPreference = (MultiSelectListPreference) C0701b.this.mo3250a();
                new HashSet(this.f3036c);
                Objects.requireNonNull(multiSelectListPreference);
                multiSelectListPreference.mo4458A0(new HashSet(this.f3036c));
                C0701b.this.f3032g = this.f3036c;
                notifyDataSetChanged();
            }
        }

        public int getItemCount() {
            return this.f3034a.length;
        }

        public void onBindViewHolder(RecyclerView.C1142b0 b0Var, int i) {
            C0704c cVar = (C0704c) b0Var;
            cVar.mo3248b().setChecked(this.f3036c.contains(this.f3035b[i].toString()));
            cVar.mo3247a().setText(this.f3034a[i]);
        }

        public RecyclerView.C1142b0 onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new C0704c(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.leanback_list_preference_item_multi, viewGroup, false), this);
        }
    }

    /* renamed from: androidx.leanback.preference.b$b */
    public class C0703b extends RecyclerView.C1147g<C0704c> implements C0704c.C0705a {

        /* renamed from: a */
        private final CharSequence[] f3038a;

        /* renamed from: b */
        private final CharSequence[] f3039b;

        /* renamed from: c */
        private CharSequence f3040c;

        public C0703b(CharSequence[] charSequenceArr, CharSequence[] charSequenceArr2, CharSequence charSequence) {
            this.f3038a = charSequenceArr;
            this.f3039b = charSequenceArr2;
            this.f3040c = charSequence;
        }

        /* renamed from: b */
        public void mo3243b(C0704c cVar) {
            int adapterPosition = cVar.getAdapterPosition();
            if (adapterPosition != -1) {
                CharSequence charSequence = this.f3039b[adapterPosition];
                ListPreference listPreference = (ListPreference) C0701b.this.mo3250a();
                if (adapterPosition >= 0) {
                    String charSequence2 = this.f3039b[adapterPosition].toString();
                    Objects.requireNonNull(listPreference);
                    listPreference.mo4451B0(charSequence2);
                    this.f3040c = charSequence;
                }
                C0701b.this.getFragmentManager().popBackStack();
                notifyDataSetChanged();
            }
        }

        public int getItemCount() {
            return this.f3038a.length;
        }

        public void onBindViewHolder(RecyclerView.C1142b0 b0Var, int i) {
            C0704c cVar = (C0704c) b0Var;
            cVar.mo3248b().setChecked(this.f3039b[i].equals(this.f3040c));
            cVar.mo3247a().setText(this.f3038a[i]);
        }

        public RecyclerView.C1142b0 onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new C0704c(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.leanback_list_preference_item_single, viewGroup, false), this);
        }
    }

    /* renamed from: androidx.leanback.preference.b$c */
    public static class C0704c extends RecyclerView.C1142b0 implements View.OnClickListener {

        /* renamed from: a */
        private final Checkable f3042a;

        /* renamed from: b */
        private final TextView f3043b;

        /* renamed from: c */
        private final ViewGroup f3044c;

        /* renamed from: d */
        private final C0705a f3045d;

        /* renamed from: androidx.leanback.preference.b$c$a */
        public interface C0705a {
            /* renamed from: b */
            void mo3243b(C0704c cVar);
        }

        public C0704c(View view, C0705a aVar) {
            super(view);
            this.f3042a = (Checkable) view.findViewById(R.id.button);
            ViewGroup viewGroup = (ViewGroup) view.findViewById(R.id.container);
            this.f3044c = viewGroup;
            this.f3043b = (TextView) view.findViewById(16908310);
            viewGroup.setOnClickListener(this);
            this.f3045d = aVar;
        }

        /* renamed from: a */
        public TextView mo3247a() {
            return this.f3043b;
        }

        /* renamed from: b */
        public Checkable mo3248b() {
            return this.f3042a;
        }

        public void onClick(View view) {
            this.f3045d.mo3243b(this);
        }
    }

    public void onCreate(Bundle bundle) {
        String str;
        super.onCreate(bundle);
        int i = 0;
        if (bundle == null) {
            DialogPreference a = mo3250a();
            this.f3030e = a.mo4432u0();
            this.f3031f = a.mo4431t0();
            if (a instanceof ListPreference) {
                this.f3027b = false;
                ListPreference listPreference = (ListPreference) a;
                this.f3028c = listPreference.mo4453y0();
                this.f3029d = listPreference.mo4454z0();
                str = listPreference.mo4450A0();
            } else if (a instanceof MultiSelectListPreference) {
                this.f3027b = true;
                MultiSelectListPreference multiSelectListPreference = (MultiSelectListPreference) a;
                this.f3028c = multiSelectListPreference.mo4459x0();
                this.f3029d = multiSelectListPreference.mo4460y0();
                this.f3032g = multiSelectListPreference.mo4461z0();
                return;
            } else {
                throw new IllegalArgumentException("Preference must be a ListPreference or MultiSelectListPreference");
            }
        } else {
            this.f3030e = bundle.getCharSequence("LeanbackListPreferenceDialogFragment.title");
            this.f3031f = bundle.getCharSequence("LeanbackListPreferenceDialogFragment.message");
            this.f3027b = bundle.getBoolean("LeanbackListPreferenceDialogFragment.isMulti");
            this.f3028c = bundle.getCharSequenceArray("LeanbackListPreferenceDialogFragment.entries");
            this.f3029d = bundle.getCharSequenceArray("LeanbackListPreferenceDialogFragment.entryValues");
            if (this.f3027b) {
                String[] stringArray = bundle.getStringArray("LeanbackListPreferenceDialogFragment.initialSelections");
                if (stringArray != null) {
                    i = stringArray.length;
                }
                C4619c cVar = new C4619c(i);
                this.f3032g = cVar;
                if (stringArray != null) {
                    Collections.addAll(cVar, stringArray);
                    return;
                }
                return;
            }
            str = bundle.getString("LeanbackListPreferenceDialogFragment.initialSelection");
        }
        this.f3033h = str;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.leanback_list_preference_fragment, viewGroup, false);
        VerticalGridView verticalGridView = (VerticalGridView) inflate.findViewById(16908298);
        verticalGridView.mo3700B(3);
        verticalGridView.mo3717j(0);
        verticalGridView.setAdapter(this.f3027b ? new C0702a(this.f3028c, this.f3029d, this.f3032g) : new C0703b(this.f3028c, this.f3029d, this.f3033h));
        verticalGridView.requestFocus();
        CharSequence charSequence = this.f3030e;
        if (!TextUtils.isEmpty(charSequence)) {
            ((TextView) inflate.findViewById(R.id.decor_title)).setText(charSequence);
        }
        CharSequence charSequence2 = this.f3031f;
        if (!TextUtils.isEmpty(charSequence2)) {
            TextView textView = (TextView) inflate.findViewById(16908299);
            textView.setVisibility(0);
            textView.setText(charSequence2);
        }
        return inflate;
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putCharSequence("LeanbackListPreferenceDialogFragment.title", this.f3030e);
        bundle.putCharSequence("LeanbackListPreferenceDialogFragment.message", this.f3031f);
        bundle.putBoolean("LeanbackListPreferenceDialogFragment.isMulti", this.f3027b);
        bundle.putCharSequenceArray("LeanbackListPreferenceDialogFragment.entries", this.f3028c);
        bundle.putCharSequenceArray("LeanbackListPreferenceDialogFragment.entryValues", this.f3029d);
        if (this.f3027b) {
            Set<String> set = this.f3032g;
            bundle.putStringArray("LeanbackListPreferenceDialogFragment.initialSelections", (String[]) set.toArray(new String[set.size()]));
            return;
        }
        bundle.putString("LeanbackListPreferenceDialogFragment.initialSelection", this.f3033h);
    }
}
