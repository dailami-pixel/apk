package androidx.leanback.preference;

import android.app.Fragment;
import android.os.Bundle;
import androidx.preference.DialogPreference;
import p098d.p140l.C4824a;

/* renamed from: androidx.leanback.preference.c */
public class C0706c extends Fragment {

    /* renamed from: a */
    private DialogPreference f3046a;

    public C0706c() {
        C4824a.m17605a(this);
    }

    /* renamed from: a */
    public DialogPreference mo3250a() {
        if (this.f3046a == null) {
            this.f3046a = (DialogPreference) ((DialogPreference.C1088a) getTargetFragment()).mo4435a(getArguments().getString("key"));
        }
        return this.f3046a;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Fragment targetFragment = getTargetFragment();
        if (!(targetFragment instanceof DialogPreference.C1088a)) {
            throw new IllegalStateException("Target fragment " + targetFragment + " must implement TargetFragment interface");
        }
    }
}
