package androidx.leanback.preference;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.vidio.android.p195tv.R;
import p098d.p140l.C4824a;

/* renamed from: androidx.leanback.preference.d */
public abstract class C0707d extends C0700a {
    public C0707d() {
        C4824a.m17605a(this);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.leanback_preference_fragment, viewGroup, false);
        ViewGroup viewGroup2 = (ViewGroup) inflate.findViewById(R.id.main_frame);
        viewGroup2.addView(super.onCreateView(layoutInflater, viewGroup2, bundle));
        return inflate;
    }

    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        CharSequence B = mo4565e().mo4465B();
        View view2 = getView();
        TextView textView = view2 == null ? null : (TextView) view2.findViewById(R.id.decor_title);
        if (textView != null) {
            textView.setText(B);
        }
    }
}
