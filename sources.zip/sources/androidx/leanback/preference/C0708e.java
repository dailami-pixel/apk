package androidx.leanback.preference;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.preference.C1113g;
import androidx.preference.ListPreference;
import androidx.preference.MultiSelectListPreference;
import androidx.preference.Preference;
import com.vidio.android.p195tv.R;

/* renamed from: androidx.leanback.preference.e */
public abstract class C0708e extends Fragment implements C1113g.C1118e, C1113g.C1119f, C1113g.C1117d {

    /* renamed from: a */
    private final C0709a f3047a = new C0709a();

    /* renamed from: androidx.leanback.preference.e$a */
    private class C0709a implements View.OnKeyListener {
        C0709a() {
        }

        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            if (i == 4) {
                return C0708e.this.getChildFragmentManager().popBackStackImmediate();
            }
            return false;
        }
    }

    /* renamed from: d */
    public boolean mo3253d(C1113g gVar, Preference preference) {
        C0701b bVar;
        if (preference instanceof ListPreference) {
            String q = ((ListPreference) preference).mo4504q();
            Bundle bundle = new Bundle(1);
            bundle.putString("key", q);
            bVar = new C0701b();
            bVar.setArguments(bundle);
        } else if (!(preference instanceof MultiSelectListPreference)) {
            return false;
        } else {
            String q2 = ((MultiSelectListPreference) preference).mo4504q();
            Bundle bundle2 = new Bundle(1);
            bundle2.putString("key", q2);
            bVar = new C0701b();
            bVar.setArguments(bundle2);
        }
        bVar.setTargetFragment(gVar, 0);
        mo3255f(bVar);
        return true;
    }

    /* renamed from: e */
    public abstract void mo3254e();

    /* renamed from: f */
    public void mo3255f(Fragment fragment) {
        FragmentTransaction beginTransaction = getChildFragmentManager().beginTransaction();
        if (getChildFragmentManager().findFragmentByTag("androidx.leanback.preference.LeanbackSettingsFragment.PREFERENCE_FRAGMENT") != null) {
            beginTransaction.addToBackStack((String) null).replace(R.id.settings_preference_fragment_container, fragment, "androidx.leanback.preference.LeanbackSettingsFragment.PREFERENCE_FRAGMENT");
        } else {
            beginTransaction.add(R.id.settings_preference_fragment_container, fragment, "androidx.leanback.preference.LeanbackSettingsFragment.PREFERENCE_FRAGMENT");
        }
        beginTransaction.commit();
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.leanback_settings_fragment, viewGroup, false);
    }

    public void onPause() {
        super.onPause();
        LeanbackSettingsRootView leanbackSettingsRootView = (LeanbackSettingsRootView) getView();
        if (leanbackSettingsRootView != null) {
            leanbackSettingsRootView.mo3238a((View.OnKeyListener) null);
        }
    }

    public void onResume() {
        super.onResume();
        LeanbackSettingsRootView leanbackSettingsRootView = (LeanbackSettingsRootView) getView();
        if (leanbackSettingsRootView != null) {
            leanbackSettingsRootView.mo3238a(this.f3047a);
        }
    }

    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        if (bundle == null) {
            mo3254e();
        }
    }
}
