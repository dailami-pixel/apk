package androidx.leanback.preference;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

public class LeanbackSettingsRootView extends FrameLayout {

    /* renamed from: a */
    private View.OnKeyListener f3026a;

    public LeanbackSettingsRootView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public LeanbackSettingsRootView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* renamed from: a */
    public void mo3238a(View.OnKeyListener onKeyListener) {
        this.f3026a = onKeyListener;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:4:0x000f, code lost:
        r0 = r4.f3026a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean dispatchKeyEvent(android.view.KeyEvent r5) {
        /*
            r4 = this;
            int r0 = r5.getAction()
            r1 = 1
            r2 = 0
            if (r0 != r1) goto L_0x001c
            int r0 = r5.getKeyCode()
            r3 = 4
            if (r0 != r3) goto L_0x001c
            android.view.View$OnKeyListener r0 = r4.f3026a
            if (r0 == 0) goto L_0x001c
            int r3 = r5.getKeyCode()
            boolean r0 = r0.onKey(r4, r3, r5)
            goto L_0x001d
        L_0x001c:
            r0 = 0
        L_0x001d:
            if (r0 != 0) goto L_0x0027
            boolean r5 = super.dispatchKeyEvent(r5)
            if (r5 == 0) goto L_0x0026
            goto L_0x0027
        L_0x0026:
            r1 = 0
        L_0x0027:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.preference.LeanbackSettingsRootView.dispatchKeyEvent(android.view.KeyEvent):boolean");
    }
}
