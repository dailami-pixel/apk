package androidx.leanback.preference.internal;

import android.content.Context;
import android.graphics.Outline;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;

public class OutlineOnlyWithChildrenFrameLayout extends FrameLayout {

    /* renamed from: a */
    private ViewOutlineProvider f3049a;

    /* renamed from: b */
    ViewOutlineProvider f3050b;

    /* renamed from: androidx.leanback.preference.internal.OutlineOnlyWithChildrenFrameLayout$a */
    class C0710a extends ViewOutlineProvider {
        C0710a() {
        }

        public void getOutline(View view, Outline outline) {
            (OutlineOnlyWithChildrenFrameLayout.this.getChildCount() > 0 ? OutlineOnlyWithChildrenFrameLayout.this.f3050b : ViewOutlineProvider.BACKGROUND).getOutline(view, outline);
        }
    }

    public OutlineOnlyWithChildrenFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public OutlineOnlyWithChildrenFrameLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        invalidateOutline();
    }

    public void setOutlineProvider(ViewOutlineProvider viewOutlineProvider) {
        this.f3050b = viewOutlineProvider;
        if (this.f3049a == null) {
            this.f3049a = new C0710a();
        }
        super.setOutlineProvider(this.f3049a);
    }
}
