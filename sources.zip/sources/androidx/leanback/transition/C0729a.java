package androidx.leanback.transition;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.graphics.Path;
import android.transition.Scene;
import android.transition.Transition;
import android.transition.TransitionInflater;
import android.transition.TransitionManager;
import android.transition.TransitionValues;
import android.view.View;
import android.view.ViewGroup;
import com.vidio.android.p195tv.R;
import java.util.Objects;

/* renamed from: androidx.leanback.transition.a */
public class C0729a {

    /* renamed from: androidx.leanback.transition.a$a */
    static class C0730a implements Transition.TransitionListener {

        /* renamed from: a */
        final /* synthetic */ C0731b f3081a;

        C0730a(C0731b bVar) {
            this.f3081a = bVar;
        }

        public void onTransitionCancel(Transition transition) {
            Objects.requireNonNull(this.f3081a);
        }

        public void onTransitionEnd(Transition transition) {
            this.f3081a.mo3072a(transition);
        }

        public void onTransitionPause(Transition transition) {
            Objects.requireNonNull(this.f3081a);
        }

        public void onTransitionResume(Transition transition) {
            Objects.requireNonNull(this.f3081a);
        }

        public void onTransitionStart(Transition transition) {
            this.f3081a.mo3142b(transition);
        }
    }

    /* renamed from: a */
    public static void m3169a(Object obj, C0731b bVar) {
        C0730a aVar = new C0730a(bVar);
        bVar.f3082a = aVar;
        ((Transition) obj).addListener(aVar);
    }

    /* renamed from: b */
    static Animator m3170b(View view, TransitionValues transitionValues, int i, int i2, float f, float f2, float f3, float f4, TimeInterpolator timeInterpolator, Transition transition) {
        float translationX = view.getTranslationX();
        float translationY = view.getTranslationY();
        int[] iArr = (int[]) transitionValues.view.getTag(R.id.transitionPosition);
        if (iArr != null) {
            f = ((float) (iArr[0] - i)) + translationX;
            f2 = ((float) (iArr[1] - i2)) + translationY;
        }
        int round = Math.round(f - translationX) + i;
        int round2 = Math.round(f2 - translationY) + i2;
        view.setTranslationX(f);
        view.setTranslationY(f2);
        if (f == f3 && f2 == f4) {
            return null;
        }
        Path path = new Path();
        path.moveTo(f, f2);
        path.lineTo(f3, f4);
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(view, View.TRANSLATION_X, View.TRANSLATION_Y, path);
        C0732c cVar = new C0732c(view, transitionValues.view, round, round2, translationX, translationY);
        transition.addListener(cVar);
        ofFloat.addListener(cVar);
        ofFloat.addPauseListener(cVar);
        ofFloat.setInterpolator(timeInterpolator);
        return ofFloat;
    }

    /* renamed from: c */
    public static Object m3171c(ViewGroup viewGroup, Runnable runnable) {
        Scene scene = new Scene(viewGroup);
        scene.setEnterAction(runnable);
        return scene;
    }

    /* renamed from: d */
    public static Object m3172d(Context context, int i) {
        return TransitionInflater.from(context).inflateTransition(i);
    }

    /* renamed from: e */
    public static void m3173e(Object obj, Object obj2) {
        TransitionManager.go((Scene) obj, (Transition) obj2);
    }
}
