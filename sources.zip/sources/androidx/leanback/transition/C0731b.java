package androidx.leanback.transition;

/* renamed from: androidx.leanback.transition.b */
public class C0731b {

    /* renamed from: a */
    protected Object f3082a;

    /* renamed from: a */
    public void mo3072a(Object obj) {
        throw null;
    }

    /* renamed from: b */
    public void mo3142b(Object obj) {
    }
}
