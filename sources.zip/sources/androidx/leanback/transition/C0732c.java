package androidx.leanback.transition;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.transition.Transition;
import android.view.View;
import com.vidio.android.p195tv.R;

/* renamed from: androidx.leanback.transition.c */
class C0732c extends AnimatorListenerAdapter implements Transition.TransitionListener {

    /* renamed from: a */
    private final View f3083a;

    /* renamed from: b */
    private final View f3084b;

    /* renamed from: c */
    private final int f3085c;

    /* renamed from: d */
    private final int f3086d;

    /* renamed from: e */
    private int[] f3087e;

    /* renamed from: f */
    private float f3088f;

    /* renamed from: g */
    private float f3089g;

    /* renamed from: h */
    private final float f3090h;

    /* renamed from: i */
    private final float f3091i;

    C0732c(View view, View view2, int i, int i2, float f, float f2) {
        this.f3084b = view;
        this.f3083a = view2;
        this.f3085c = i - Math.round(view.getTranslationX());
        this.f3086d = i2 - Math.round(view.getTranslationY());
        this.f3090h = f;
        this.f3091i = f2;
        int[] iArr = (int[]) view2.getTag(R.id.transitionPosition);
        this.f3087e = iArr;
        if (iArr != null) {
            view2.setTag(R.id.transitionPosition, (Object) null);
        }
    }

    public void onAnimationCancel(Animator animator) {
        if (this.f3087e == null) {
            this.f3087e = new int[2];
        }
        this.f3087e[0] = Math.round(this.f3084b.getTranslationX() + ((float) this.f3085c));
        this.f3087e[1] = Math.round(this.f3084b.getTranslationY() + ((float) this.f3086d));
        this.f3083a.setTag(R.id.transitionPosition, this.f3087e);
    }

    public void onAnimationEnd(Animator animator) {
    }

    public void onAnimationPause(Animator animator) {
        this.f3088f = this.f3084b.getTranslationX();
        this.f3089g = this.f3084b.getTranslationY();
        this.f3084b.setTranslationX(this.f3090h);
        this.f3084b.setTranslationY(this.f3091i);
    }

    public void onAnimationResume(Animator animator) {
        this.f3084b.setTranslationX(this.f3088f);
        this.f3084b.setTranslationY(this.f3089g);
    }

    public void onTransitionCancel(Transition transition) {
    }

    public void onTransitionEnd(Transition transition) {
        this.f3084b.setTranslationX(this.f3090h);
        this.f3084b.setTranslationY(this.f3091i);
    }

    public void onTransitionPause(Transition transition) {
    }

    public void onTransitionResume(Transition transition) {
    }

    public void onTransitionStart(Transition transition) {
    }
}
