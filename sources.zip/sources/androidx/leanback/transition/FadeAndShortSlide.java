package androidx.leanback.transition;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.transition.Fade;
import android.transition.Transition;
import android.transition.TransitionValues;
import android.transition.Visibility;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import p098d.p140l.C4825b;

public class FadeAndShortSlide extends Visibility {

    /* renamed from: a */
    private static final TimeInterpolator f3052a = new DecelerateInterpolator();

    /* renamed from: b */
    static final C0717g f3053b = new C0711a();

    /* renamed from: c */
    static final C0717g f3054c = new C0712b();

    /* renamed from: d */
    static final C0717g f3055d = new C0713c();

    /* renamed from: e */
    static final C0717g f3056e = new C0714d();

    /* renamed from: f */
    static final C0717g f3057f = new C0715e();

    /* renamed from: g */
    private C0717g f3058g;

    /* renamed from: h */
    private Visibility f3059h;

    /* renamed from: i */
    private float f3060i;

    /* renamed from: j */
    final C0717g f3061j;

    /* renamed from: androidx.leanback.transition.FadeAndShortSlide$a */
    static class C0711a extends C0717g {
        C0711a() {
        }

        /* renamed from: a */
        public float mo3275a(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            boolean z = true;
            if (viewGroup.getLayoutDirection() != 1) {
                z = false;
            }
            float translationX = view.getTranslationX();
            float a = fadeAndShortSlide.mo3264a(viewGroup);
            return z ? translationX + a : translationX - a;
        }
    }

    /* renamed from: androidx.leanback.transition.FadeAndShortSlide$b */
    static class C0712b extends C0717g {
        C0712b() {
        }

        /* renamed from: a */
        public float mo3275a(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            boolean z = true;
            if (viewGroup.getLayoutDirection() != 1) {
                z = false;
            }
            float translationX = view.getTranslationX();
            float a = fadeAndShortSlide.mo3264a(viewGroup);
            return z ? translationX - a : translationX + a;
        }
    }

    /* renamed from: androidx.leanback.transition.FadeAndShortSlide$c */
    static class C0713c extends C0717g {
        C0713c() {
        }

        /* renamed from: a */
        public float mo3275a(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            int width = (view.getWidth() / 2) + iArr[0];
            viewGroup.getLocationOnScreen(iArr);
            Rect epicenter = fadeAndShortSlide.getEpicenter();
            int width2 = epicenter == null ? (viewGroup.getWidth() / 2) + iArr[0] : epicenter.centerX();
            float translationX = view.getTranslationX();
            float a = fadeAndShortSlide.mo3264a(viewGroup);
            return width < width2 ? translationX - a : translationX + a;
        }
    }

    /* renamed from: androidx.leanback.transition.FadeAndShortSlide$d */
    static class C0714d extends C0717g {
        C0714d() {
        }

        /* renamed from: b */
        public float mo3276b(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            return view.getTranslationY() + fadeAndShortSlide.mo3266b(viewGroup);
        }
    }

    /* renamed from: androidx.leanback.transition.FadeAndShortSlide$e */
    static class C0715e extends C0717g {
        C0715e() {
        }

        /* renamed from: b */
        public float mo3276b(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            return view.getTranslationY() - fadeAndShortSlide.mo3266b(viewGroup);
        }
    }

    /* renamed from: androidx.leanback.transition.FadeAndShortSlide$f */
    class C0716f extends C0717g {
        C0716f() {
        }

        /* renamed from: b */
        public float mo3276b(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            int height = (view.getHeight() / 2) + iArr[1];
            viewGroup.getLocationOnScreen(iArr);
            Rect epicenter = FadeAndShortSlide.this.getEpicenter();
            int height2 = epicenter == null ? (viewGroup.getHeight() / 2) + iArr[1] : epicenter.centerY();
            float translationY = view.getTranslationY();
            float b = fadeAndShortSlide.mo3266b(viewGroup);
            return height < height2 ? translationY - b : translationY + b;
        }
    }

    /* renamed from: androidx.leanback.transition.FadeAndShortSlide$g */
    private static abstract class C0717g {
        C0717g() {
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public float mo3275a(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            return view.getTranslationX();
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public float mo3276b(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            return view.getTranslationY();
        }
    }

    public FadeAndShortSlide() {
        this(8388611);
    }

    public FadeAndShortSlide(int i) {
        this.f3059h = new Fade();
        this.f3060i = -1.0f;
        this.f3061j = new C0716f();
        mo3267c(i);
    }

    public FadeAndShortSlide(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f3059h = new Fade();
        this.f3060i = -1.0f;
        this.f3061j = new C0716f();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825b.f17419l);
        mo3267c(obtainStyledAttributes.getInt(3, 8388611));
        obtainStyledAttributes.recycle();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public float mo3264a(ViewGroup viewGroup) {
        float f = this.f3060i;
        return f >= 0.0f ? f : (float) (viewGroup.getWidth() / 4);
    }

    public Transition addListener(Transition.TransitionListener transitionListener) {
        this.f3059h.addListener(transitionListener);
        return super.addListener(transitionListener);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public float mo3266b(ViewGroup viewGroup) {
        float f = this.f3060i;
        return f >= 0.0f ? f : (float) (viewGroup.getHeight() / 4);
    }

    /* renamed from: c */
    public void mo3267c(int i) {
        C0717g gVar;
        if (i == 48) {
            gVar = f3057f;
        } else if (i == 80) {
            gVar = f3056e;
        } else if (i == 112) {
            gVar = this.f3061j;
        } else if (i == 8388611) {
            gVar = f3053b;
        } else if (i == 8388613) {
            gVar = f3054c;
        } else if (i == 8388615) {
            gVar = f3055d;
        } else {
            throw new IllegalArgumentException("Invalid slide direction");
        }
        this.f3058g = gVar;
    }

    public void captureEndValues(TransitionValues transitionValues) {
        this.f3059h.captureEndValues(transitionValues);
        super.captureEndValues(transitionValues);
        int[] iArr = new int[2];
        transitionValues.view.getLocationOnScreen(iArr);
        transitionValues.values.put("android:fadeAndShortSlideTransition:screenPosition", iArr);
    }

    public void captureStartValues(TransitionValues transitionValues) {
        this.f3059h.captureStartValues(transitionValues);
        super.captureStartValues(transitionValues);
        int[] iArr = new int[2];
        transitionValues.view.getLocationOnScreen(iArr);
        transitionValues.values.put("android:fadeAndShortSlideTransition:screenPosition", iArr);
    }

    public Transition clone() {
        FadeAndShortSlide fadeAndShortSlide = (FadeAndShortSlide) super.clone();
        fadeAndShortSlide.f3059h = (Visibility) this.f3059h.clone();
        return fadeAndShortSlide;
    }

    public Animator onAppear(ViewGroup viewGroup, View view, TransitionValues transitionValues, TransitionValues transitionValues2) {
        ViewGroup viewGroup2 = viewGroup;
        ViewGroup viewGroup3 = view;
        TransitionValues transitionValues3 = transitionValues2;
        if (transitionValues3 == null || viewGroup2 == viewGroup3) {
            return null;
        }
        int[] iArr = (int[]) transitionValues3.values.get("android:fadeAndShortSlideTransition:screenPosition");
        int i = iArr[0];
        int i2 = iArr[1];
        float translationX = view.getTranslationX();
        View view2 = view;
        TransitionValues transitionValues4 = transitionValues2;
        Animator b = C0729a.m3170b(view2, transitionValues4, i, i2, this.f3058g.mo3275a(this, viewGroup, viewGroup3, iArr), this.f3058g.mo3276b(this, viewGroup, viewGroup3, iArr), translationX, view.getTranslationY(), f3052a, this);
        Animator onAppear = this.f3059h.onAppear(viewGroup, viewGroup3, transitionValues, transitionValues3);
        if (b == null) {
            return onAppear;
        }
        if (onAppear == null) {
            return b;
        }
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(b).with(onAppear);
        return animatorSet;
    }

    public Animator onDisappear(ViewGroup viewGroup, View view, TransitionValues transitionValues, TransitionValues transitionValues2) {
        ViewGroup viewGroup2 = viewGroup;
        ViewGroup viewGroup3 = view;
        TransitionValues transitionValues3 = transitionValues;
        if (transitionValues3 == null || viewGroup2 == viewGroup3) {
            return null;
        }
        int[] iArr = (int[]) transitionValues3.values.get("android:fadeAndShortSlideTransition:screenPosition");
        int i = iArr[0];
        int i2 = iArr[1];
        float translationX = view.getTranslationX();
        float a = this.f3058g.mo3275a(this, viewGroup, viewGroup3, iArr);
        Animator b = C0729a.m3170b(view, transitionValues, i, i2, translationX, view.getTranslationY(), a, this.f3058g.mo3276b(this, viewGroup, viewGroup3, iArr), f3052a, this);
        Animator onDisappear = this.f3059h.onDisappear(viewGroup, viewGroup3, transitionValues3, transitionValues2);
        if (b == null) {
            return onDisappear;
        }
        if (onDisappear == null) {
            return b;
        }
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(b).with(onDisappear);
        return animatorSet;
    }

    public Transition removeListener(Transition.TransitionListener transitionListener) {
        this.f3059h.removeListener(transitionListener);
        return super.removeListener(transitionListener);
    }

    public void setEpicenterCallback(Transition.EpicenterCallback epicenterCallback) {
        this.f3059h.setEpicenterCallback(epicenterCallback);
        super.setEpicenterCallback(epicenterCallback);
    }
}
