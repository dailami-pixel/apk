package androidx.leanback.transition;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.transition.TransitionValues;
import android.transition.Visibility;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import androidx.leanback.widget.C0814j0;
import com.vidio.android.p195tv.R;

public class ParallaxTransition extends Visibility {

    /* renamed from: a */
    static Interpolator f3063a = new LinearInterpolator();

    /* renamed from: androidx.leanback.transition.ParallaxTransition$a */
    class C0718a implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a */
        final /* synthetic */ C0814j0 f3064a;

        C0718a(ParallaxTransition parallaxTransition, C0814j0 j0Var) {
            this.f3064a = j0Var;
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            this.f3064a.mo3754a();
        }
    }

    public ParallaxTransition() {
    }

    public ParallaxTransition(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public Animator mo3277a(View view) {
        C0814j0 j0Var = (C0814j0) view.getTag(R.id.lb_parallax_source);
        if (j0Var == null) {
            return null;
        }
        ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{0.0f, 1.0f});
        ofFloat.setInterpolator(f3063a);
        ofFloat.addUpdateListener(new C0718a(this, j0Var));
        return ofFloat;
    }

    public Animator onAppear(ViewGroup viewGroup, View view, TransitionValues transitionValues, TransitionValues transitionValues2) {
        if (transitionValues2 == null) {
            return null;
        }
        return mo3277a(view);
    }

    public Animator onDisappear(ViewGroup viewGroup, View view, TransitionValues transitionValues, TransitionValues transitionValues2) {
        if (transitionValues == null) {
            return null;
        }
        return mo3277a(view);
    }
}
