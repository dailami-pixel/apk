package androidx.leanback.transition;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.TypedArray;
import android.transition.TransitionValues;
import android.transition.Visibility;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import com.vidio.android.p195tv.R;
import p098d.p140l.C4825b;

class SlideKitkat extends Visibility {

    /* renamed from: a */
    private static final TimeInterpolator f3065a = new DecelerateInterpolator();

    /* renamed from: b */
    private static final TimeInterpolator f3066b = new AccelerateInterpolator();

    /* renamed from: c */
    private static final C0725g f3067c = new C0719a();

    /* renamed from: d */
    private static final C0725g f3068d = new C0720b();

    /* renamed from: e */
    private static final C0725g f3069e = new C0721c();

    /* renamed from: f */
    private static final C0725g f3070f = new C0722d();

    /* renamed from: g */
    private static final C0725g f3071g = new C0723e();

    /* renamed from: h */
    private static final C0725g f3072h = new C0724f();

    /* renamed from: i */
    private C0725g f3073i;

    /* renamed from: androidx.leanback.transition.SlideKitkat$a */
    static class C0719a extends C0726h {
        C0719a() {
        }

        /* renamed from: b */
        public float mo3284b(View view) {
            return view.getTranslationX() - ((float) view.getWidth());
        }
    }

    /* renamed from: androidx.leanback.transition.SlideKitkat$b */
    static class C0720b extends C0727i {
        C0720b() {
        }

        /* renamed from: b */
        public float mo3284b(View view) {
            return view.getTranslationY() - ((float) view.getHeight());
        }
    }

    /* renamed from: androidx.leanback.transition.SlideKitkat$c */
    static class C0721c extends C0726h {
        C0721c() {
        }

        /* renamed from: b */
        public float mo3284b(View view) {
            return view.getTranslationX() + ((float) view.getWidth());
        }
    }

    /* renamed from: androidx.leanback.transition.SlideKitkat$d */
    static class C0722d extends C0727i {
        C0722d() {
        }

        /* renamed from: b */
        public float mo3284b(View view) {
            return view.getTranslationY() + ((float) view.getHeight());
        }
    }

    /* renamed from: androidx.leanback.transition.SlideKitkat$e */
    static class C0723e extends C0726h {
        C0723e() {
        }

        /* renamed from: b */
        public float mo3284b(View view) {
            return view.getLayoutDirection() == 1 ? view.getTranslationX() + ((float) view.getWidth()) : view.getTranslationX() - ((float) view.getWidth());
        }
    }

    /* renamed from: androidx.leanback.transition.SlideKitkat$f */
    static class C0724f extends C0726h {
        C0724f() {
        }

        /* renamed from: b */
        public float mo3284b(View view) {
            return view.getLayoutDirection() == 1 ? view.getTranslationX() - ((float) view.getWidth()) : view.getTranslationX() + ((float) view.getWidth());
        }
    }

    /* renamed from: androidx.leanback.transition.SlideKitkat$g */
    private interface C0725g {
        /* renamed from: a */
        Property<View, Float> mo3285a();

        /* renamed from: b */
        float mo3284b(View view);

        /* renamed from: c */
        float mo3286c(View view);
    }

    /* renamed from: androidx.leanback.transition.SlideKitkat$h */
    private static abstract class C0726h implements C0725g {
        C0726h() {
        }

        /* renamed from: a */
        public Property<View, Float> mo3285a() {
            return View.TRANSLATION_X;
        }

        /* renamed from: c */
        public float mo3286c(View view) {
            return view.getTranslationX();
        }
    }

    /* renamed from: androidx.leanback.transition.SlideKitkat$i */
    private static abstract class C0727i implements C0725g {
        C0727i() {
        }

        /* renamed from: a */
        public Property<View, Float> mo3285a() {
            return View.TRANSLATION_Y;
        }

        /* renamed from: c */
        public float mo3286c(View view) {
            return view.getTranslationY();
        }
    }

    /* renamed from: androidx.leanback.transition.SlideKitkat$j */
    private static class C0728j extends AnimatorListenerAdapter {

        /* renamed from: a */
        private boolean f3074a = false;

        /* renamed from: b */
        private float f3075b;

        /* renamed from: c */
        private final View f3076c;

        /* renamed from: d */
        private final float f3077d;

        /* renamed from: e */
        private final float f3078e;

        /* renamed from: f */
        private final int f3079f;

        /* renamed from: g */
        private final Property<View, Float> f3080g;

        public C0728j(View view, Property<View, Float> property, float f, float f2, int i) {
            this.f3080g = property;
            this.f3076c = view;
            this.f3078e = f;
            this.f3077d = f2;
            this.f3079f = i;
            view.setVisibility(0);
        }

        public void onAnimationCancel(Animator animator) {
            this.f3076c.setTag(R.id.lb_slide_transition_value, new float[]{this.f3076c.getTranslationX(), this.f3076c.getTranslationY()});
            this.f3080g.set(this.f3076c, Float.valueOf(this.f3078e));
            this.f3074a = true;
        }

        public void onAnimationEnd(Animator animator) {
            if (!this.f3074a) {
                this.f3080g.set(this.f3076c, Float.valueOf(this.f3078e));
            }
            this.f3076c.setVisibility(this.f3079f);
        }

        public void onAnimationPause(Animator animator) {
            this.f3075b = this.f3080g.get(this.f3076c).floatValue();
            this.f3080g.set(this.f3076c, Float.valueOf(this.f3077d));
            this.f3076c.setVisibility(this.f3079f);
        }

        public void onAnimationResume(Animator animator) {
            this.f3080g.set(this.f3076c, Float.valueOf(this.f3075b));
            this.f3076c.setVisibility(0);
        }
    }

    public SlideKitkat() {
        mo3281b(80);
    }

    public SlideKitkat(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825b.f17419l);
        mo3281b(obtainStyledAttributes.getInt(3, 80));
        long j = (long) obtainStyledAttributes.getInt(1, -1);
        if (j >= 0) {
            setDuration(j);
        }
        long j2 = (long) obtainStyledAttributes.getInt(2, -1);
        if (j2 > 0) {
            setStartDelay(j2);
        }
        int resourceId = obtainStyledAttributes.getResourceId(0, 0);
        if (resourceId > 0) {
            setInterpolator(AnimationUtils.loadInterpolator(context, resourceId));
        }
        obtainStyledAttributes.recycle();
    }

    /* renamed from: a */
    private Animator m3154a(View view, Property<View, Float> property, float f, float f2, float f3, TimeInterpolator timeInterpolator, int i) {
        float[] fArr = (float[]) view.getTag(R.id.lb_slide_transition_value);
        if (fArr != null) {
            f = View.TRANSLATION_Y == property ? fArr[1] : fArr[0];
            view.setTag(R.id.lb_slide_transition_value, (Object) null);
        }
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(view, property, new float[]{f, f2});
        C0728j jVar = new C0728j(view, property, f3, f2, i);
        ofFloat.addListener(jVar);
        ofFloat.addPauseListener(jVar);
        ofFloat.setInterpolator(timeInterpolator);
        return ofFloat;
    }

    /* renamed from: b */
    public void mo3281b(int i) {
        C0725g gVar;
        if (i == 3) {
            gVar = f3067c;
        } else if (i == 5) {
            gVar = f3069e;
        } else if (i == 48) {
            gVar = f3068d;
        } else if (i == 80) {
            gVar = f3070f;
        } else if (i == 8388611) {
            gVar = f3071g;
        } else if (i == 8388613) {
            gVar = f3072h;
        } else {
            throw new IllegalArgumentException("Invalid slide direction");
        }
        this.f3073i = gVar;
    }

    public Animator onAppear(ViewGroup viewGroup, TransitionValues transitionValues, int i, TransitionValues transitionValues2, int i2) {
        View view = transitionValues2 != null ? transitionValues2.view : null;
        if (view == null) {
            return null;
        }
        float c = this.f3073i.mo3286c(view);
        return m3154a(view, this.f3073i.mo3285a(), this.f3073i.mo3284b(view), c, c, f3065a, 0);
    }

    public Animator onDisappear(ViewGroup viewGroup, TransitionValues transitionValues, int i, TransitionValues transitionValues2, int i2) {
        View view = transitionValues != null ? transitionValues.view : null;
        if (view == null) {
            return null;
        }
        float c = this.f3073i.mo3286c(view);
        return m3154a(view, this.f3073i.mo3285a(), c, this.f3073i.mo3284b(view), c, f3066b, 4);
    }
}
