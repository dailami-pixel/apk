package androidx.leanback.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Transformation;
import android.widget.FrameLayout;
import com.vidio.android.p195tv.R;
import java.util.ArrayList;
import p098d.p140l.C4825b;

public class BaseCardView extends FrameLayout {

    /* renamed from: a */
    private static final int[] f3092a = {16842919};

    /* renamed from: b */
    private int f3093b;

    /* renamed from: c */
    private int f3094c;

    /* renamed from: d */
    private int f3095d;

    /* renamed from: e */
    private ArrayList<View> f3096e;

    /* renamed from: f */
    ArrayList<View> f3097f;

    /* renamed from: g */
    ArrayList<View> f3098g;

    /* renamed from: h */
    private int f3099h;

    /* renamed from: i */
    private int f3100i;

    /* renamed from: j */
    private boolean f3101j;

    /* renamed from: k */
    private int f3102k;

    /* renamed from: l */
    private final int f3103l;

    /* renamed from: m */
    private final int f3104m;

    /* renamed from: n */
    float f3105n;

    /* renamed from: o */
    float f3106o;

    /* renamed from: p */
    float f3107p;

    /* renamed from: q */
    private Animation f3108q;

    /* renamed from: r */
    private final Runnable f3109r;

    public static class LayoutParams extends FrameLayout.LayoutParams {
        @ViewDebug.ExportedProperty(category = "layout", mapping = {@ViewDebug.IntToString(from = 0, to = "MAIN"), @ViewDebug.IntToString(from = 1, to = "INFO"), @ViewDebug.IntToString(from = 2, to = "EXTRA")})

        /* renamed from: a */
        public int f3110a = 0;

        public LayoutParams(int i, int i2) {
            super(i, i2);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825b.f17412e);
            this.f3110a = obtainStyledAttributes.getInt(0, 0);
            obtainStyledAttributes.recycle();
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(LayoutParams layoutParams) {
            super(layoutParams);
            this.f3110a = layoutParams.f3110a;
        }
    }

    /* renamed from: androidx.leanback.widget.BaseCardView$a */
    class C0733a implements Runnable {
        C0733a() {
        }

        public void run() {
            BaseCardView.this.mo3306a(true);
        }
    }

    /* renamed from: androidx.leanback.widget.BaseCardView$b */
    class C0734b implements Animation.AnimationListener {
        C0734b() {
        }

        public void onAnimationEnd(Animation animation) {
            if (BaseCardView.this.f3105n == 0.0f) {
                for (int i = 0; i < BaseCardView.this.f3098g.size(); i++) {
                    BaseCardView.this.f3098g.get(i).setVisibility(8);
                }
            }
        }

        public void onAnimationRepeat(Animation animation) {
        }

        public void onAnimationStart(Animation animation) {
        }
    }

    /* renamed from: androidx.leanback.widget.BaseCardView$c */
    class C0735c extends Animation {
        C0735c(BaseCardView baseCardView) {
        }
    }

    /* renamed from: androidx.leanback.widget.BaseCardView$d */
    final class C0736d extends C0735c {

        /* renamed from: a */
        private float f3113a;

        /* renamed from: b */
        private float f3114b;

        public C0736d(float f, float f2) {
            super(BaseCardView.this);
            this.f3113a = f;
            this.f3114b = f2 - f;
        }

        /* access modifiers changed from: protected */
        public void applyTransformation(float f, Transformation transformation) {
            BaseCardView.this.f3107p = (f * this.f3114b) + this.f3113a;
            for (int i = 0; i < BaseCardView.this.f3097f.size(); i++) {
                BaseCardView.this.f3097f.get(i).setAlpha(BaseCardView.this.f3107p);
            }
        }
    }

    /* renamed from: androidx.leanback.widget.BaseCardView$e */
    final class C0737e extends C0735c {

        /* renamed from: a */
        private float f3116a;

        /* renamed from: b */
        private float f3117b;

        public C0737e(float f, float f2) {
            super(BaseCardView.this);
            this.f3116a = f;
            this.f3117b = f2 - f;
        }

        /* access modifiers changed from: protected */
        public void applyTransformation(float f, Transformation transformation) {
            BaseCardView baseCardView = BaseCardView.this;
            baseCardView.f3106o = (f * this.f3117b) + this.f3116a;
            baseCardView.requestLayout();
        }
    }

    /* renamed from: androidx.leanback.widget.BaseCardView$f */
    final class C0738f extends C0735c {

        /* renamed from: a */
        private float f3119a;

        /* renamed from: b */
        private float f3120b;

        public C0738f(float f, float f2) {
            super(BaseCardView.this);
            this.f3119a = f;
            this.f3120b = f2 - f;
        }

        /* access modifiers changed from: protected */
        public void applyTransformation(float f, Transformation transformation) {
            BaseCardView baseCardView = BaseCardView.this;
            baseCardView.f3105n = (f * this.f3120b) + this.f3119a;
            baseCardView.requestLayout();
        }
    }

    public BaseCardView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.baseCardViewStyle);
    }

    /* JADX INFO: finally extract failed */
    public BaseCardView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3109r = new C0733a();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825b.f17411d, i, 0);
        try {
            this.f3093b = obtainStyledAttributes.getInteger(3, 0);
            Drawable drawable = obtainStyledAttributes.getDrawable(2);
            if (drawable != null) {
                setForeground(drawable);
            }
            Drawable drawable2 = obtainStyledAttributes.getDrawable(1);
            if (drawable2 != null) {
                setBackground(drawable2);
            }
            this.f3094c = obtainStyledAttributes.getInteger(5, 1);
            int integer = obtainStyledAttributes.getInteger(4, 2);
            this.f3095d = integer;
            int i2 = this.f3094c;
            if (integer < i2) {
                this.f3095d = i2;
            }
            this.f3102k = obtainStyledAttributes.getInteger(6, getResources().getInteger(R.integer.lb_card_selected_animation_delay));
            this.f3104m = obtainStyledAttributes.getInteger(7, getResources().getInteger(R.integer.lb_card_selected_animation_duration));
            this.f3103l = obtainStyledAttributes.getInteger(0, getResources().getInteger(R.integer.lb_card_activated_animation_duration));
            obtainStyledAttributes.recycle();
            this.f3101j = true;
            this.f3096e = new ArrayList<>();
            this.f3097f = new ArrayList<>();
            this.f3098g = new ArrayList<>();
            float f = 0.0f;
            this.f3105n = 0.0f;
            this.f3106o = (this.f3093b == 2 && this.f3094c == 2 && !isSelected()) ? 0.0f : 1.0f;
            this.f3107p = (this.f3093b == 1 && this.f3094c == 2 && !isSelected()) ? f : 1.0f;
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    /* renamed from: c */
    private boolean m3176c() {
        return this.f3093b == 3;
    }

    /* renamed from: d */
    private boolean m3177d() {
        return this.f3093b != 0;
    }

    /* renamed from: e */
    private void m3178e(boolean z) {
        int i = this.f3093b;
        float f = 0.0f;
        if (i == 3) {
            if (z) {
                for (int i2 = 0; i2 < this.f3097f.size(); i2++) {
                    this.f3097f.get(i2).setVisibility(0);
                }
                return;
            }
            for (int i3 = 0; i3 < this.f3097f.size(); i3++) {
                this.f3097f.get(i3).setVisibility(8);
            }
            for (int i4 = 0; i4 < this.f3098g.size(); i4++) {
                this.f3098g.get(i4).setVisibility(8);
            }
            this.f3105n = 0.0f;
        } else if (i == 2) {
            if (this.f3094c == 2) {
                mo3307b();
                if (z) {
                    for (int i5 = 0; i5 < this.f3097f.size(); i5++) {
                        this.f3097f.get(i5).setVisibility(0);
                    }
                }
                if (z) {
                    f = 1.0f;
                }
                if (this.f3106o != f) {
                    C0737e eVar = new C0737e(this.f3106o, f);
                    this.f3108q = eVar;
                    eVar.setDuration((long) this.f3104m);
                    this.f3108q.setInterpolator(new AccelerateDecelerateInterpolator());
                    this.f3108q.setAnimationListener(new C0780c(this));
                    startAnimation(this.f3108q);
                    return;
                }
                return;
            }
            for (int i6 = 0; i6 < this.f3097f.size(); i6++) {
                this.f3097f.get(i6).setVisibility(z ? 0 : 8);
            }
        } else if (i == 1) {
            mo3307b();
            if (z) {
                for (int i7 = 0; i7 < this.f3097f.size(); i7++) {
                    this.f3097f.get(i7).setVisibility(0);
                }
            }
            if ((z ? 1.0f : 0.0f) != this.f3107p) {
                float f2 = this.f3107p;
                if (z) {
                    f = 1.0f;
                }
                C0736d dVar = new C0736d(f2, f);
                this.f3108q = dVar;
                dVar.setDuration((long) this.f3103l);
                this.f3108q.setInterpolator(new DecelerateInterpolator());
                this.f3108q.setAnimationListener(new C0785d(this));
                startAnimation(this.f3108q);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo3306a(boolean z) {
        mo3307b();
        int i = 0;
        if (z) {
            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(this.f3099h, 1073741824);
            int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(0, 0);
            int i2 = 0;
            for (int i3 = 0; i3 < this.f3098g.size(); i3++) {
                View view = this.f3098g.get(i3);
                view.setVisibility(0);
                view.measure(makeMeasureSpec, makeMeasureSpec2);
                i2 = Math.max(i2, view.getMeasuredHeight());
            }
            i = i2;
        }
        C0738f fVar = new C0738f(this.f3105n, z ? (float) i : 0.0f);
        this.f3108q = fVar;
        fVar.setDuration((long) this.f3104m);
        this.f3108q.setInterpolator(new AccelerateDecelerateInterpolator());
        this.f3108q.setAnimationListener(new C0734b());
        startAnimation(this.f3108q);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo3307b() {
        Animation animation = this.f3108q;
        if (animation != null) {
            animation.cancel();
            this.f3108q = null;
            clearAnimation();
        }
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-2, -2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    /* access modifiers changed from: protected */
    public int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i);
        int length = onCreateDrawableState.length;
        boolean z = false;
        boolean z2 = false;
        for (int i2 = 0; i2 < length; i2++) {
            if (onCreateDrawableState[i2] == 16842919) {
                z = true;
            }
            if (onCreateDrawableState[i2] == 16842910) {
                z2 = true;
            }
        }
        return (!z || !z2) ? z ? f3092a : z2 ? View.ENABLED_STATE_SET : View.EMPTY_STATE_SET : View.PRESSED_ENABLED_STATE_SET;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f3109r);
        mo3307b();
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        float paddingTop = (float) getPaddingTop();
        for (int i5 = 0; i5 < this.f3096e.size(); i5++) {
            View view = this.f3096e.get(i5);
            if (view.getVisibility() != 8) {
                view.layout(getPaddingLeft(), (int) paddingTop, getPaddingLeft() + this.f3099h, (int) (((float) view.getMeasuredHeight()) + paddingTop));
                paddingTop += (float) view.getMeasuredHeight();
            }
        }
        if (m3177d()) {
            float f = 0.0f;
            for (int i6 = 0; i6 < this.f3097f.size(); i6++) {
                f += (float) this.f3097f.get(i6).getMeasuredHeight();
            }
            int i7 = this.f3093b;
            if (i7 == 1) {
                paddingTop -= f;
                if (paddingTop < 0.0f) {
                    paddingTop = 0.0f;
                }
            } else if (i7 != 2) {
                paddingTop -= this.f3105n;
            } else if (this.f3094c == 2) {
                f *= this.f3106o;
            }
            for (int i8 = 0; i8 < this.f3097f.size(); i8++) {
                View view2 = this.f3097f.get(i8);
                if (view2.getVisibility() != 8) {
                    int measuredHeight = view2.getMeasuredHeight();
                    if (((float) measuredHeight) > f) {
                        measuredHeight = (int) f;
                    }
                    float f2 = (float) measuredHeight;
                    paddingTop += f2;
                    view2.layout(getPaddingLeft(), (int) paddingTop, getPaddingLeft() + this.f3099h, (int) paddingTop);
                    f -= f2;
                    if (f <= 0.0f) {
                        break;
                    }
                }
            }
            if (m3176c()) {
                for (int i9 = 0; i9 < this.f3098g.size(); i9++) {
                    View view3 = this.f3098g.get(i9);
                    if (view3.getVisibility() != 8) {
                        view3.layout(getPaddingLeft(), (int) paddingTop, getPaddingLeft() + this.f3099h, (int) (((float) view3.getMeasuredHeight()) + paddingTop));
                        paddingTop += (float) view3.getMeasuredHeight();
                    }
                }
            }
        }
        onSizeChanged(0, 0, i3 - i, i4 - i2);
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x0077, code lost:
        if (r3 != false) goto L_0x0083;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0081, code lost:
        if (r7 != false) goto L_0x0083;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0033, code lost:
        if (r0.f3106o > 0.0f) goto L_0x0042;
     */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0045  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0054  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0056  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x005c  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00a2  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00ea  */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x014b  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x015c  */
    /* JADX WARNING: Removed duplicated region for block: B:79:0x0166  */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x0093 A[EDGE_INSN: B:82:0x0093->B:39:0x0093 ?: BREAK  , SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r16, int r17) {
        /*
            r15 = this;
            r0 = r15
            r1 = 0
            r0.f3099h = r1
            r0.f3100i = r1
            java.util.ArrayList<android.view.View> r2 = r0.f3096e
            r2.clear()
            java.util.ArrayList<android.view.View> r2 = r0.f3097f
            r2.clear()
            java.util.ArrayList<android.view.View> r2 = r0.f3098g
            r2.clear()
            int r2 = r15.getChildCount()
            boolean r3 = r15.m3177d()
            r4 = 0
            r5 = 2
            r6 = 1
            if (r3 == 0) goto L_0x0047
            int r3 = r0.f3094c
            if (r3 == 0) goto L_0x0042
            if (r3 == r6) goto L_0x003d
            if (r3 == r5) goto L_0x002b
            goto L_0x0036
        L_0x002b:
            int r3 = r0.f3093b
            if (r3 != r5) goto L_0x0038
            float r3 = r0.f3106o
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L_0x0036
            goto L_0x0042
        L_0x0036:
            r3 = 0
            goto L_0x0043
        L_0x0038:
            boolean r3 = r15.isSelected()
            goto L_0x0043
        L_0x003d:
            boolean r3 = r15.isActivated()
            goto L_0x0043
        L_0x0042:
            r3 = 1
        L_0x0043:
            if (r3 == 0) goto L_0x0047
            r3 = 1
            goto L_0x0048
        L_0x0047:
            r3 = 0
        L_0x0048:
            boolean r7 = r15.m3176c()
            if (r7 == 0) goto L_0x0056
            float r7 = r0.f3105n
            int r7 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r7 <= 0) goto L_0x0056
            r7 = 1
            goto L_0x0057
        L_0x0056:
            r7 = 0
        L_0x0057:
            r8 = 0
        L_0x0058:
            r9 = 8
            if (r8 >= r2) goto L_0x0093
            android.view.View r10 = r15.getChildAt(r8)
            if (r10 != 0) goto L_0x0063
            goto L_0x0090
        L_0x0063:
            android.view.ViewGroup$LayoutParams r11 = r10.getLayoutParams()
            androidx.leanback.widget.BaseCardView$LayoutParams r11 = (androidx.leanback.widget.BaseCardView.LayoutParams) r11
            int r11 = r11.f3110a
            if (r11 != r6) goto L_0x007a
            float r11 = r0.f3107p
            r10.setAlpha(r11)
            java.util.ArrayList<android.view.View> r11 = r0.f3097f
            r11.add(r10)
            if (r3 == 0) goto L_0x0084
            goto L_0x0083
        L_0x007a:
            if (r11 != r5) goto L_0x0088
            java.util.ArrayList<android.view.View> r11 = r0.f3098g
            r11.add(r10)
            if (r7 == 0) goto L_0x0084
        L_0x0083:
            r9 = 0
        L_0x0084:
            r10.setVisibility(r9)
            goto L_0x0090
        L_0x0088:
            java.util.ArrayList<android.view.View> r9 = r0.f3096e
            r9.add(r10)
            r10.setVisibility(r1)
        L_0x0090:
            int r8 = r8 + 1
            goto L_0x0058
        L_0x0093:
            int r2 = android.view.View.MeasureSpec.makeMeasureSpec(r1, r1)
            r3 = 0
            r7 = 0
            r8 = 0
        L_0x009a:
            java.util.ArrayList<android.view.View> r10 = r0.f3096e
            int r10 = r10.size()
            if (r3 >= r10) goto L_0x00cf
            java.util.ArrayList<android.view.View> r10 = r0.f3096e
            java.lang.Object r10 = r10.get(r3)
            android.view.View r10 = (android.view.View) r10
            int r11 = r10.getVisibility()
            if (r11 == r9) goto L_0x00cc
            r15.measureChild(r10, r2, r2)
            int r11 = r0.f3099h
            int r12 = r10.getMeasuredWidth()
            int r11 = java.lang.Math.max(r11, r12)
            r0.f3099h = r11
            int r11 = r10.getMeasuredHeight()
            int r7 = r7 + r11
            int r10 = r10.getMeasuredState()
            int r8 = android.view.View.combineMeasuredStates(r8, r10)
        L_0x00cc:
            int r3 = r3 + 1
            goto L_0x009a
        L_0x00cf:
            int r3 = r0.f3099h
            int r3 = r3 / r5
            float r3 = (float) r3
            r15.setPivotX(r3)
            int r3 = r7 / 2
            float r3 = (float) r3
            r15.setPivotY(r3)
            int r3 = r0.f3099h
            r10 = 1073741824(0x40000000, float:2.0)
            int r3 = android.view.View.MeasureSpec.makeMeasureSpec(r3, r10)
            boolean r10 = r15.m3177d()
            if (r10 == 0) goto L_0x014b
            r10 = 0
            r11 = 0
        L_0x00ec:
            java.util.ArrayList<android.view.View> r12 = r0.f3097f
            int r12 = r12.size()
            if (r10 >= r12) goto L_0x011a
            java.util.ArrayList<android.view.View> r12 = r0.f3097f
            java.lang.Object r12 = r12.get(r10)
            android.view.View r12 = (android.view.View) r12
            int r13 = r12.getVisibility()
            if (r13 == r9) goto L_0x0117
            r15.measureChild(r12, r3, r2)
            int r13 = r0.f3093b
            if (r13 == r6) goto L_0x010f
            int r13 = r12.getMeasuredHeight()
            int r13 = r13 + r11
            r11 = r13
        L_0x010f:
            int r12 = r12.getMeasuredState()
            int r8 = android.view.View.combineMeasuredStates(r8, r12)
        L_0x0117:
            int r10 = r10 + 1
            goto L_0x00ec
        L_0x011a:
            boolean r10 = r15.m3176c()
            if (r10 == 0) goto L_0x014c
            r10 = 0
            r12 = 0
        L_0x0122:
            java.util.ArrayList<android.view.View> r13 = r0.f3098g
            int r13 = r13.size()
            if (r10 >= r13) goto L_0x014d
            java.util.ArrayList<android.view.View> r13 = r0.f3098g
            java.lang.Object r13 = r13.get(r10)
            android.view.View r13 = (android.view.View) r13
            int r14 = r13.getVisibility()
            if (r14 == r9) goto L_0x0148
            r15.measureChild(r13, r3, r2)
            int r14 = r13.getMeasuredHeight()
            int r12 = r12 + r14
            int r13 = r13.getMeasuredState()
            int r8 = android.view.View.combineMeasuredStates(r8, r13)
        L_0x0148:
            int r10 = r10 + 1
            goto L_0x0122
        L_0x014b:
            r11 = 0
        L_0x014c:
            r12 = 0
        L_0x014d:
            boolean r2 = r15.m3177d()
            if (r2 == 0) goto L_0x0158
            int r2 = r0.f3094c
            if (r2 != r5) goto L_0x0158
            r1 = 1
        L_0x0158:
            float r2 = (float) r7
            float r3 = (float) r11
            if (r1 == 0) goto L_0x0160
            float r5 = r0.f3106o
            float r3 = r3 * r5
        L_0x0160:
            float r2 = r2 + r3
            float r3 = (float) r12
            float r2 = r2 + r3
            if (r1 == 0) goto L_0x0166
            goto L_0x0168
        L_0x0166:
            float r4 = r0.f3105n
        L_0x0168:
            float r2 = r2 - r4
            int r1 = (int) r2
            r0.f3100i = r1
            int r1 = r0.f3099h
            int r2 = r15.getPaddingLeft()
            int r2 = r2 + r1
            int r1 = r15.getPaddingRight()
            int r1 = r1 + r2
            r2 = r16
            int r1 = android.view.View.resolveSizeAndState(r1, r2, r8)
            int r2 = r0.f3100i
            int r3 = r15.getPaddingTop()
            int r3 = r3 + r2
            int r2 = r15.getPaddingBottom()
            int r2 = r2 + r3
            int r3 = r8 << 16
            r4 = r17
            int r2 = android.view.View.resolveSizeAndState(r2, r4, r3)
            r15.setMeasuredDimension(r1, r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.BaseCardView.onMeasure(int, int):void");
    }

    public void setActivated(boolean z) {
        if (z != isActivated()) {
            super.setActivated(z);
            isActivated();
            if (m3177d()) {
                int i = this.f3094c;
                boolean z2 = true;
                if (i == 1) {
                    if (i != 0) {
                        z2 = i != 1 ? i != 2 ? false : isSelected() : isActivated();
                    }
                    m3178e(z2);
                }
            }
        }
    }

    public void setSelected(boolean z) {
        if (z != isSelected()) {
            super.setSelected(z);
            boolean isSelected = isSelected();
            removeCallbacks(this.f3109r);
            if (this.f3093b == 3) {
                if (!isSelected) {
                    mo3306a(false);
                } else if (!this.f3101j) {
                    post(this.f3109r);
                    this.f3101j = true;
                } else {
                    postDelayed(this.f3109r, (long) this.f3102k);
                }
            } else if (this.f3094c == 2) {
                m3178e(isSelected);
            }
        }
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public String toString() {
        return super.toString();
    }

    /* access modifiers changed from: protected */
    /* renamed from: generateDefaultLayoutParams  reason: collision with other method in class */
    public FrameLayout.LayoutParams m41561generateDefaultLayoutParams() {
        return new LayoutParams(-2, -2);
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams ? new LayoutParams((LayoutParams) layoutParams) : new LayoutParams(layoutParams);
    }

    /* renamed from: generateLayoutParams  reason: collision with other method in class */
    public FrameLayout.LayoutParams m41562generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }
}
