package androidx.leanback.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;

public class BrowseFrameLayout extends FrameLayout {

    /* renamed from: a */
    private C0740b f3122a;

    /* renamed from: b */
    private C0739a f3123b;

    /* renamed from: androidx.leanback.widget.BrowseFrameLayout$a */
    public interface C0739a {
        /* renamed from: a */
        boolean mo3112a(int i, Rect rect);

        /* renamed from: b */
        void mo3113b(View view, View view2);
    }

    /* renamed from: androidx.leanback.widget.BrowseFrameLayout$b */
    public interface C0740b {
        /* renamed from: a */
        View mo3111a(View view, int i);
    }

    public BrowseFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public BrowseFrameLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* renamed from: a */
    public void mo3327a(C0739a aVar) {
        this.f3123b = aVar;
    }

    /* renamed from: b */
    public void mo3328b(C0740b bVar) {
        this.f3122a = bVar;
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r0 = r0.mo3111a(r2, r3);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View focusSearch(android.view.View r2, int r3) {
        /*
            r1 = this;
            androidx.leanback.widget.BrowseFrameLayout$b r0 = r1.f3122a
            if (r0 == 0) goto L_0x000b
            android.view.View r0 = r0.mo3111a(r2, r3)
            if (r0 == 0) goto L_0x000b
            return r0
        L_0x000b:
            android.view.View r2 = super.focusSearch(r2, r3)
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.BrowseFrameLayout.focusSearch(android.view.View, int):android.view.View");
    }

    /* access modifiers changed from: protected */
    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        C0739a aVar = this.f3123b;
        if (aVar == null || !aVar.mo3112a(i, rect)) {
            return super.onRequestFocusInDescendants(i, rect);
        }
        return true;
    }

    public void requestChildFocus(View view, View view2) {
        C0739a aVar = this.f3123b;
        if (aVar != null) {
            aVar.mo3113b(view, view2);
        }
        super.requestChildFocus(view, view2);
    }
}
