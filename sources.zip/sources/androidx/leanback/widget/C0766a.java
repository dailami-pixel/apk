package androidx.leanback.widget;

import android.text.TextUtils;

/* renamed from: androidx.leanback.widget.a */
public class C0766a {
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (!TextUtils.isEmpty((CharSequence) null)) {
            sb.append((CharSequence) null);
        }
        if (!TextUtils.isEmpty((CharSequence) null)) {
            if (!TextUtils.isEmpty((CharSequence) null)) {
                sb.append(" ");
            }
            sb.append((CharSequence) null);
        }
        return sb.toString();
    }
}
