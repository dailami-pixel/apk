package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.a0 */
public class C0767a0 extends C0864t0 {

    /* renamed from: d */
    private final C0781c0 f3373d;

    public C0767a0(long j, C0861s sVar, C0781c0 c0Var) {
        super(j, sVar);
        this.f3373d = c0Var;
        m3382g();
    }

    public C0767a0(C0781c0 c0Var) {
        this.f3373d = c0Var;
        m3382g();
    }

    public C0767a0(C0861s sVar, C0781c0 c0Var) {
        super(sVar);
        this.f3373d = c0Var;
        m3382g();
    }

    /* renamed from: g */
    private void m3382g() {
        if (this.f3373d == null) {
            throw new IllegalArgumentException("ObjectAdapter cannot be null");
        }
    }

    /* renamed from: f */
    public final C0781c0 mo3607f() {
        return this.f3373d;
    }
}
