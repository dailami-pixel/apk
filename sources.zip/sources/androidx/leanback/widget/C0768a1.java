package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.a1 */
public final class C0768a1 extends C0858q0 {

    /* renamed from: a */
    private final C0844p0 f3374a;

    public C0768a1(C0844p0 p0Var) {
        this.f3374a = p0Var;
    }

    /* renamed from: a */
    public C0844p0 mo3140a(Object obj) {
        return this.f3374a;
    }

    /* renamed from: b */
    public C0844p0[] mo3141b() {
        return new C0844p0[]{this.f3374a};
    }
}
