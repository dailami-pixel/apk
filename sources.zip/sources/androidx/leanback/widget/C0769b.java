package androidx.leanback.widget;

import androidx.recyclerview.widget.C1200j;
import androidx.recyclerview.widget.C1219p;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/* renamed from: androidx.leanback.widget.b */
public class C0769b extends C0781c0 {

    /* renamed from: c */
    public static final /* synthetic */ int f3375c = 0;

    /* renamed from: d */
    private final List f3376d = new ArrayList();

    /* renamed from: e */
    final List f3377e = new ArrayList();

    /* renamed from: f */
    private List f3378f;

    /* renamed from: g */
    C1219p f3379g;

    /* renamed from: androidx.leanback.widget.b$a */
    class C0770a extends C1200j.C1202b {

        /* renamed from: a */
        final /* synthetic */ List f3380a;

        /* renamed from: b */
        final /* synthetic */ C0813j f3381b;

        C0770a(List list, C0813j jVar) {
            this.f3380a = list;
            this.f3381b = jVar;
        }

        /* renamed from: a */
        public boolean mo3618a(int i, int i2) {
            return this.f3381b.mo3752a(C0769b.this.f3377e.get(i), this.f3380a.get(i2));
        }

        /* renamed from: b */
        public boolean mo3619b(int i, int i2) {
            return this.f3381b.mo3753b(C0769b.this.f3377e.get(i), this.f3380a.get(i2));
        }

        /* renamed from: c */
        public Object mo3620c(int i, int i2) {
            C0813j jVar = this.f3381b;
            C0769b.this.f3377e.get(i);
            this.f3380a.get(i2);
            Objects.requireNonNull(jVar);
            return null;
        }

        /* renamed from: d */
        public int mo3621d() {
            return this.f3380a.size();
        }

        /* renamed from: e */
        public int mo3622e() {
            return C0769b.this.f3377e.size();
        }
    }

    /* renamed from: androidx.leanback.widget.b$b */
    class C0771b implements C1219p {
        C0771b() {
        }

        /* renamed from: a */
        public void mo3623a(int i, int i2) {
            int i3 = C0769b.f3375c;
            C0769b.this.mo3669f(i, i2);
        }

        /* renamed from: b */
        public void mo3624b(int i, int i2) {
            int i3 = C0769b.f3375c;
            C0769b.this.mo3672i(i, i2);
        }

        /* renamed from: c */
        public void mo3625c(int i, int i2) {
            int i3 = C0769b.f3375c;
            C0769b.this.mo3673j(i, i2);
        }

        /* renamed from: d */
        public void mo3626d(int i, int i2, Object obj) {
            int i3 = C0769b.f3375c;
            C0769b.this.mo3671h(i, i2, obj);
        }
    }

    public C0769b() {
    }

    public C0769b(C0844p0 p0Var) {
        super(p0Var);
    }

    public C0769b(C0858q0 q0Var) {
        super(q0Var);
    }

    /* renamed from: a */
    public Object mo3153a(int i) {
        return this.f3376d.get(i);
    }

    /* renamed from: m */
    public int mo3154m() {
        return this.f3376d.size();
    }

    /* renamed from: o */
    public void mo3608o(int i, Object obj) {
        this.f3376d.add(i, obj);
        mo3672i(i, 1);
    }

    /* renamed from: p */
    public void mo3609p(Object obj) {
        mo3608o(this.f3376d.size(), obj);
    }

    /* renamed from: q */
    public void mo3610q(int i, Collection collection) {
        int size = collection.size();
        if (size != 0) {
            this.f3376d.addAll(i, collection);
            mo3672i(i, size);
        }
    }

    /* renamed from: r */
    public void mo3611r() {
        int size = this.f3376d.size();
        if (size != 0) {
            this.f3376d.clear();
            mo3673j(0, size);
        }
    }

    /* renamed from: s */
    public int mo3612s(Object obj) {
        return this.f3376d.indexOf(obj);
    }

    /* renamed from: t */
    public boolean mo3613t(Object obj) {
        int indexOf = this.f3376d.indexOf(obj);
        if (indexOf >= 0) {
            this.f3376d.remove(indexOf);
            mo3673j(indexOf, 1);
        }
        return indexOf >= 0;
    }

    /* renamed from: u */
    public int mo3614u(int i, int i2) {
        int min = Math.min(i2, this.f3376d.size() - i);
        if (min <= 0) {
            return 0;
        }
        for (int i3 = 0; i3 < min; i3++) {
            this.f3376d.remove(i);
        }
        mo3673j(i, min);
        return min;
    }

    /* renamed from: v */
    public void mo3615v(int i, Object obj) {
        this.f3376d.set(i, obj);
        mo3670g(i, 1);
    }

    /* renamed from: w */
    public void mo3616w(List list, C0813j jVar) {
        this.f3377e.clear();
        this.f3377e.addAll(this.f3376d);
        C1200j.C1203c a = C1200j.m5077a(new C0770a(list, jVar));
        this.f3376d.clear();
        this.f3376d.addAll(list);
        if (this.f3379g == null) {
            this.f3379g = new C0771b();
        }
        a.mo5190a(this.f3379g);
        this.f3377e.clear();
    }

    /* renamed from: x */
    public <E> List<E> mo3617x() {
        if (this.f3378f == null) {
            this.f3378f = Collections.unmodifiableList(this.f3376d);
        }
        return this.f3378f;
    }
}
