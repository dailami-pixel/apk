package androidx.leanback.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.leanback.widget.C0789e;
import androidx.leanback.widget.C0839p;
import androidx.leanback.widget.C0844p0;
import androidx.leanback.widget.C0866u0;
import androidx.leanback.widget.C0870v0;
import androidx.leanback.widget.C0878y;
import androidx.leanback.widget.C0888z0;
import androidx.recyclerview.widget.RecyclerView;
import com.vidio.android.p195tv.R;
import java.util.HashMap;
import p098d.p140l.C4825b;
import p098d.p140l.p144f.C4841a;

/* renamed from: androidx.leanback.widget.b0 */
public class C0772b0 extends C0870v0 {

    /* renamed from: e */
    private static int f3384e;

    /* renamed from: f */
    private static int f3385f;

    /* renamed from: g */
    private static int f3386g;

    /* renamed from: h */
    private int f3387h;

    /* renamed from: i */
    private int f3388i;

    /* renamed from: j */
    private boolean f3389j;

    /* renamed from: k */
    private boolean f3390k;

    /* renamed from: l */
    private int f3391l;

    /* renamed from: m */
    private boolean f3392m;

    /* renamed from: n */
    private boolean f3393n;

    /* renamed from: o */
    private HashMap<C0844p0, Integer> f3394o;

    /* renamed from: p */
    C0888z0 f3395p;

    /* renamed from: q */
    private C0878y.C0883e f3396q;

    /* renamed from: androidx.leanback.widget.b0$a */
    class C0773a implements C0799f0 {

        /* renamed from: a */
        final /* synthetic */ C0778e f3397a;

        C0773a(C0778e eVar) {
            this.f3397a = eVar;
        }

        /* renamed from: a */
        public void mo3642a(ViewGroup viewGroup, View view, int i, long j) {
            C0772b0.this.mo3629E(this.f3397a, view, true);
        }
    }

    /* renamed from: androidx.leanback.widget.b0$b */
    class C0774b implements C0789e.C0795f {

        /* renamed from: a */
        final /* synthetic */ C0778e f3399a;

        C0774b(C0772b0 b0Var, C0778e eVar) {
            this.f3399a = eVar;
        }
    }

    /* renamed from: androidx.leanback.widget.b0$c */
    class C0775c extends C0878y {

        /* renamed from: h */
        C0778e f3400h;

        /* renamed from: androidx.leanback.widget.b0$c$a */
        class C0776a implements View.OnClickListener {

            /* renamed from: a */
            final /* synthetic */ C0878y.C0882d f3402a;

            C0776a(C0878y.C0882d dVar) {
                this.f3402a = dVar;
            }

            public void onClick(View view) {
                C0878y.C0882d dVar = (C0878y.C0882d) C0775c.this.f3400h.f3406n.getChildViewHolder(this.f3402a.itemView);
                if (C0775c.this.f3400h.mo3879s() != null) {
                    C0798f s = C0775c.this.f3400h.mo3879s();
                    C0844p0.C0845a aVar = this.f3402a.f3656b;
                    Object obj = dVar.f3658d;
                    C0778e eVar = C0775c.this.f3400h;
                    s.mo3184a(aVar, obj, eVar, (C0767a0) eVar.f3628d);
                }
            }
        }

        C0775c(C0778e eVar) {
            this.f3400h = eVar;
        }

        /* renamed from: d */
        public void mo3643d(C0844p0 p0Var, int i) {
            this.f3400h.f3406n.getRecycledViewPool().mo5042i(i, C0772b0.this.mo3628D(p0Var));
        }

        /* renamed from: e */
        public void mo3644e(C0878y.C0882d dVar) {
            C0772b0.this.mo3627C(this.f3400h, dVar.itemView);
            C0778e eVar = this.f3400h;
            View view = dVar.itemView;
            int i = eVar.f3630f;
            if (i == 1) {
                view.setActivated(true);
            } else if (i == 2) {
                view.setActivated(false);
            }
        }

        /* renamed from: f */
        public void mo3645f(C0878y.C0882d dVar) {
            if (this.f3400h.mo3879s() != null) {
                dVar.f3656b.f3529a.setOnClickListener(new C0776a(dVar));
            }
        }

        /* access modifiers changed from: protected */
        /* renamed from: g */
        public void mo3646g(C0878y.C0882d dVar) {
            View view = dVar.itemView;
            if (view instanceof ViewGroup) {
                ((ViewGroup) view).setTransitionGroup(true);
            }
            C0888z0 z0Var = C0772b0.this.f3395p;
            if (z0Var != null) {
                z0Var.mo3907a(dVar.itemView);
            }
        }

        /* renamed from: h */
        public void mo3647h(C0878y.C0882d dVar) {
            if (this.f3400h.mo3879s() != null) {
                dVar.f3656b.f3529a.setOnClickListener((View.OnClickListener) null);
            }
        }
    }

    /* renamed from: androidx.leanback.widget.b0$d */
    public static class C0777d extends C0844p0.C0846b {

        /* renamed from: a */
        private int f3404a;

        /* renamed from: b */
        private boolean f3405b = true;

        public C0777d(int i) {
            this.f3404a = i;
        }

        /* renamed from: a */
        public void mo3649a(C0844p0.C0845a aVar) {
            if (aVar instanceof C0778e) {
                HorizontalGridView horizontalGridView = ((C0778e) aVar).f3406n;
                if (this.f3405b) {
                    horizontalGridView.mo3699A(this.f3404a, (C0826l1) null);
                } else {
                    horizontalGridView.mo3738y(this.f3404a, (C0826l1) null);
                }
            }
        }

        /* renamed from: b */
        public void mo3650b(boolean z) {
            this.f3405b = z;
        }
    }

    /* renamed from: androidx.leanback.widget.b0$e */
    public static class C0778e extends C0870v0.C0872b {

        /* renamed from: n */
        final HorizontalGridView f3406n;

        /* renamed from: o */
        C0878y f3407o;

        /* renamed from: p */
        final C0863t f3408p = new C0863t();

        /* renamed from: q */
        final int f3409q;

        /* renamed from: r */
        final int f3410r;

        /* renamed from: s */
        final int f3411s;

        /* renamed from: t */
        final int f3412t;

        public C0778e(View view, HorizontalGridView horizontalGridView, C0772b0 b0Var) {
            super(view);
            this.f3406n = horizontalGridView;
            this.f3409q = horizontalGridView.getPaddingTop();
            this.f3410r = horizontalGridView.getPaddingBottom();
            this.f3411s = horizontalGridView.getPaddingLeft();
            this.f3412t = horizontalGridView.getPaddingRight();
        }

        /* renamed from: w */
        public final C0878y mo3651w() {
            return this.f3407o;
        }

        /* renamed from: x */
        public final HorizontalGridView mo3652x() {
            return this.f3406n;
        }
    }

    public C0772b0() {
        this(2, false);
    }

    /* renamed from: G */
    private void m3407G(C0778e eVar) {
        int i;
        int i2 = 0;
        if (eVar.f3632h) {
            C0866u0.C0867a aVar = eVar.f3627c;
            if (aVar != null) {
                i2 = mo3872l() != null ? mo3872l().mo3865i(aVar) : aVar.f3529a.getPaddingBottom();
            }
            i2 = (eVar.f3631g ? f3385f : eVar.f3409q) - i2;
            i = f3386g;
        } else if (eVar.f3631g) {
            i = f3384e;
            i2 = i - eVar.f3410r;
        } else {
            i = eVar.f3410r;
        }
        eVar.f3406n.setPadding(eVar.f3411s, i2, eVar.f3412t, i);
    }

    /* renamed from: H */
    private void m3408H(C0778e eVar) {
        if (eVar.f3632h && eVar.f3631g) {
            HorizontalGridView horizontalGridView = eVar.f3406n;
            C0878y.C0882d dVar = (C0878y.C0882d) horizontalGridView.findViewHolderForPosition(horizontalGridView.f3425a.f3137H);
            mo3629E(eVar, dVar == null ? null : dVar.itemView, false);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: C */
    public void mo3627C(C0778e eVar, View view) {
        C0888z0 z0Var = this.f3395p;
        if (z0Var != null && z0Var.f3667b) {
            int color = eVar.f3635k.mo22080b().getColor();
            if (this.f3395p.f3670e) {
                ((ShadowOverlayContainer) view).mo3577a(color);
            } else {
                C0888z0.m3785b(view, color);
            }
        }
    }

    /* renamed from: D */
    public int mo3628D(C0844p0 p0Var) {
        if (this.f3394o.containsKey(p0Var)) {
            return this.f3394o.get(p0Var).intValue();
        }
        return 24;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: E */
    public void mo3629E(C0778e eVar, View view, boolean z) {
        C0801g gVar;
        C0801g gVar2;
        if (view != null) {
            if (eVar.f3631g) {
                C0878y.C0882d dVar = (C0878y.C0882d) eVar.f3406n.getChildViewHolder(view);
                if (z && (gVar2 = eVar.f3636l) != null) {
                    gVar2.mo3132a(dVar.f3656b, dVar.f3658d, eVar, eVar.f3628d);
                }
            }
        } else if (z && (gVar = eVar.f3636l) != null) {
            gVar.mo3132a((C0844p0.C0845a) null, (Object) null, eVar, eVar.f3628d);
        }
    }

    /* renamed from: F */
    public final void mo3630F(boolean z) {
        this.f3390k = z;
    }

    /* access modifiers changed from: protected */
    /* renamed from: i */
    public C0870v0.C0872b mo3631i(ViewGroup viewGroup) {
        Context context = viewGroup.getContext();
        if (f3384e == 0) {
            f3384e = context.getResources().getDimensionPixelSize(R.dimen.lb_browse_selected_row_top_padding);
            f3385f = context.getResources().getDimensionPixelSize(R.dimen.lb_browse_expanded_selected_row_top_padding);
            f3386g = context.getResources().getDimensionPixelSize(R.dimen.lb_browse_expanded_row_no_hovercard_bottom_padding);
        }
        ListRowView listRowView = new ListRowView(viewGroup.getContext(), (AttributeSet) null);
        HorizontalGridView a = listRowView.mo3478a();
        if (this.f3391l < 0) {
            TypedArray obtainStyledAttributes = a.getContext().obtainStyledAttributes(C4825b.f17409b);
            this.f3391l = (int) obtainStyledAttributes.getDimension(5, 0.0f);
            obtainStyledAttributes.recycle();
        }
        a.mo3473E(this.f3391l);
        return new C0778e(listRowView, listRowView.mo3478a(), this);
    }

    /* access modifiers changed from: protected */
    /* renamed from: j */
    public void mo3632j(C0870v0.C0872b bVar, boolean z) {
        C0801g gVar;
        C0801g gVar2;
        C0778e eVar = (C0778e) bVar;
        HorizontalGridView horizontalGridView = eVar.f3406n;
        C0878y.C0882d dVar = (C0878y.C0882d) horizontalGridView.findViewHolderForPosition(horizontalGridView.f3425a.f3137H);
        if (dVar == null) {
            if (z && (gVar2 = bVar.f3636l) != null) {
                gVar2.mo3132a((C0844p0.C0845a) null, (Object) null, bVar, bVar.f3629e);
            }
        } else if (z && (gVar = bVar.f3636l) != null) {
            gVar.mo3132a(dVar.f3656b, dVar.f3658d, eVar, eVar.f3628d);
        }
    }

    /* renamed from: k */
    public void mo3633k(C0870v0.C0872b bVar, boolean z) {
        C0778e eVar = (C0778e) bVar;
        eVar.f3406n.mo3736w(!z);
        eVar.f3406n.mo3712g(!z);
    }

    /* access modifiers changed from: protected */
    /* renamed from: o */
    public void mo3634o(C0870v0.C0872b bVar) {
        super.mo3634o(bVar);
        C0778e eVar = (C0778e) bVar;
        Context context = bVar.f3529a.getContext();
        boolean z = false;
        if (this.f3395p == null) {
            C0888z0.C0889a aVar = new C0888z0.C0889a();
            aVar.mo3910c(this.f3623c);
            aVar.mo3912e(this.f3390k);
            aVar.mo3911d((C4841a.m17684a(context).mo22116b() ^ true) && this.f3392m);
            aVar.mo3914g(!C4841a.m17684a(context).mo22117c());
            aVar.mo3909b(this.f3393n);
            aVar.mo3913f(C0888z0.C0890b.f3680a);
            C0888z0 a = aVar.mo3908a(context);
            this.f3395p = a;
            if (a.f3670e) {
                this.f3396q = new C0887z(a);
            }
        }
        C0775c cVar = new C0775c(eVar);
        eVar.f3407o = cVar;
        cVar.f3646b = this.f3396q;
        C0888z0 z0Var = this.f3395p;
        HorizontalGridView horizontalGridView = eVar.f3406n;
        if (z0Var.f3666a == 2) {
            horizontalGridView.setLayoutMode(1);
        }
        eVar.f3407o.f3648d = new C0839p.C0840a(this.f3388i, this.f3389j);
        HorizontalGridView horizontalGridView2 = eVar.f3406n;
        if (this.f3395p.f3666a != 3) {
            z = true;
        }
        horizontalGridView2.mo3716i(z);
        eVar.f3406n.f3425a.mo3426z2(new C0773a(eVar));
        eVar.f3406n.mo3733t(new C0774b(this, eVar));
        HorizontalGridView horizontalGridView3 = eVar.f3406n;
        horizontalGridView3.f3425a.mo3423y2(this.f3387h);
        horizontalGridView3.requestLayout();
    }

    /* renamed from: p */
    public final boolean mo3635p() {
        return false;
    }

    /* access modifiers changed from: protected */
    /* renamed from: q */
    public void mo3636q(C0870v0.C0872b bVar, Object obj) {
        super.mo3636q(bVar, obj);
        C0778e eVar = (C0778e) bVar;
        C0767a0 a0Var = (C0767a0) obj;
        eVar.f3407o.mo3891i(a0Var.mo3607f());
        eVar.f3406n.setAdapter(eVar.f3407o);
        HorizontalGridView horizontalGridView = eVar.f3406n;
        C0861s a = a0Var.mo3860a();
        horizontalGridView.setContentDescription(a != null ? a.mo3858b() : null);
    }

    /* access modifiers changed from: protected */
    /* renamed from: r */
    public void mo3637r(C0870v0.C0872b bVar, boolean z) {
        super.mo3637r(bVar, z);
        C0778e eVar = (C0778e) bVar;
        m3407G(eVar);
        m3408H(eVar);
    }

    /* access modifiers changed from: protected */
    /* renamed from: s */
    public void mo3638s(C0870v0.C0872b bVar, boolean z) {
        super.mo3638s(bVar, z);
        C0778e eVar = (C0778e) bVar;
        m3407G(eVar);
        m3408H(eVar);
    }

    /* access modifiers changed from: protected */
    /* renamed from: t */
    public void mo3639t(C0870v0.C0872b bVar) {
        super.mo3639t(bVar);
        C0778e eVar = (C0778e) bVar;
        int childCount = eVar.f3406n.getChildCount();
        for (int i = 0; i < childCount; i++) {
            mo3627C(eVar, eVar.f3406n.getChildAt(i));
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: u */
    public void mo3640u(C0870v0.C0872b bVar) {
        C0778e eVar = (C0778e) bVar;
        eVar.f3406n.setAdapter((RecyclerView.C1147g) null);
        eVar.f3407o.mo3891i((C0781c0) null);
        super.mo3640u(bVar);
    }

    /* renamed from: v */
    public void mo3641v(C0870v0.C0872b bVar, boolean z) {
        super.mo3641v(bVar, z);
        ((C0778e) bVar).f3406n.mo3714h(z ? 0 : 4);
    }

    public C0772b0(int i, boolean z) {
        boolean z2 = true;
        this.f3387h = 1;
        this.f3390k = true;
        this.f3391l = -1;
        this.f3392m = true;
        this.f3393n = true;
        this.f3394o = new HashMap<>();
        if (i != 0 && C0839p.m3627b(i) <= 0) {
            z2 = false;
        }
        if (z2) {
            this.f3388i = i;
            this.f3389j = z;
            return;
        }
        throw new IllegalArgumentException("Unhandled zoom factor");
    }
}
