package androidx.leanback.widget;

import androidx.leanback.widget.C0855q;
import androidx.leanback.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.common.api.C4291a;
import p098d.p112d.C4621e;

/* renamed from: androidx.leanback.widget.b1 */
class C0779b1 extends C0855q {

    /* renamed from: j */
    private final C0855q.C0856a f3413j = new C0855q.C0856a(0);

    C0779b1() {
        mo3856r(1);
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public final boolean mo3653b(int i, boolean z) {
        int i2;
        if (((GridLayoutManager.C0743b) this.f3591b).mo3443c() == 0) {
            return false;
        }
        if (!z && mo3849c(i)) {
            return false;
        }
        int s = mo3660s();
        boolean z2 = false;
        while (s < ((GridLayoutManager.C0743b) this.f3591b).mo3443c()) {
            int b = ((GridLayoutManager.C0743b) this.f3591b).mo3442b(s, true, this.f3590a, false);
            if (this.f3595f < 0 || this.f3596g < 0) {
                i2 = this.f3592c ? C4291a.C4299e.API_PRIORITY_OTHER : RecyclerView.UNDEFINED_DURATION;
                this.f3595f = s;
            } else if (this.f3592c) {
                int i3 = s - 1;
                i2 = (((GridLayoutManager.C0743b) this.f3591b).mo3444d(i3) - ((GridLayoutManager.C0743b) this.f3591b).mo3445e(i3)) - this.f3593d;
            } else {
                int i4 = s - 1;
                i2 = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i4) + ((GridLayoutManager.C0743b) this.f3591b).mo3445e(i4) + this.f3593d;
            }
            this.f3596g = s;
            ((GridLayoutManager.C0743b) this.f3591b).mo3441a(this.f3590a[0], s, b, 0, i2);
            if (z || mo3849c(i)) {
                return true;
            }
            s++;
            z2 = true;
        }
        return z2;
    }

    /* renamed from: e */
    public void mo3654e(int i, int i2, RecyclerView.C1158o.C1161c cVar) {
        int i3;
        int i4;
        if (!this.f3592c ? i2 >= 0 : i2 <= 0) {
            if (this.f3596g != ((GridLayoutManager.C0743b) this.f3591b).mo3443c() - 1) {
                i3 = mo3660s();
                int e = ((GridLayoutManager.C0743b) this.f3591b).mo3445e(this.f3596g) + this.f3593d;
                int d = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(this.f3596g);
                if (this.f3592c) {
                    e = -e;
                }
                i4 = e + d;
            } else {
                return;
            }
        } else if (this.f3595f != 0) {
            i3 = mo3661t();
            i4 = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(this.f3595f) + (this.f3592c ? this.f3593d : -this.f3593d);
        } else {
            return;
        }
        cVar.mo5028a(i3, Math.abs(i4 - i));
    }

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public final int mo3655f(boolean z, int i, int[] iArr) {
        if (iArr != null) {
            iArr[0] = 0;
            iArr[1] = i;
        }
        return this.f3592c ? ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i) : ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i) + ((GridLayoutManager.C0743b) this.f3591b).mo3445e(i);
    }

    /* access modifiers changed from: protected */
    /* renamed from: h */
    public final int mo3656h(boolean z, int i, int[] iArr) {
        if (iArr != null) {
            iArr[0] = 0;
            iArr[1] = i;
        }
        return this.f3592c ? ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i) - ((GridLayoutManager.C0743b) this.f3591b).mo3445e(i) : ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i);
    }

    /* renamed from: j */
    public final C4621e[] mo3657j(int i, int i2) {
        this.f3597h[0].mo21352b();
        this.f3597h[0].mo21351a(i);
        this.f3597h[0].mo21351a(i2);
        return this.f3597h;
    }

    /* renamed from: k */
    public final C0855q.C0856a mo3658k(int i) {
        return this.f3413j;
    }

    /* access modifiers changed from: protected */
    /* renamed from: n */
    public final boolean mo3659n(int i, boolean z) {
        int i2;
        if (((GridLayoutManager.C0743b) this.f3591b).mo3443c() == 0) {
            return false;
        }
        if (!z && mo3850d(i)) {
            return false;
        }
        int i3 = GridLayoutManager.this.f3170y;
        int t = mo3661t();
        boolean z2 = false;
        while (t >= i3) {
            int b = ((GridLayoutManager.C0743b) this.f3591b).mo3442b(t, false, this.f3590a, false);
            if (this.f3595f < 0 || this.f3596g < 0) {
                i2 = this.f3592c ? RecyclerView.UNDEFINED_DURATION : C4291a.C4299e.API_PRIORITY_OTHER;
                this.f3595f = t;
                this.f3596g = t;
            } else {
                i2 = this.f3592c ? ((GridLayoutManager.C0743b) this.f3591b).mo3444d(t + 1) + this.f3593d + b : (((GridLayoutManager.C0743b) this.f3591b).mo3444d(t + 1) - this.f3593d) - b;
                this.f3595f = t;
            }
            ((GridLayoutManager.C0743b) this.f3591b).mo3441a(this.f3590a[0], t, b, 0, i2);
            if (z || mo3850d(i)) {
                return true;
            }
            t--;
            z2 = true;
        }
        return z2;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: s */
    public int mo3660s() {
        int i = this.f3596g;
        if (i >= 0) {
            return i + 1;
        }
        int i2 = this.f3598i;
        if (i2 != -1) {
            return Math.min(i2, ((GridLayoutManager.C0743b) this.f3591b).mo3443c() - 1);
        }
        return 0;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: t */
    public int mo3661t() {
        int i = this.f3595f;
        if (i >= 0) {
            return i - 1;
        }
        int i2 = this.f3598i;
        return i2 != -1 ? Math.min(i2, ((GridLayoutManager.C0743b) this.f3591b).mo3443c() - 1) : ((GridLayoutManager.C0743b) this.f3591b).mo3443c() - 1;
    }
}
