package androidx.leanback.widget;

import android.view.animation.Animation;

/* renamed from: androidx.leanback.widget.c */
class C0780c implements Animation.AnimationListener {

    /* renamed from: a */
    final /* synthetic */ BaseCardView f3414a;

    C0780c(BaseCardView baseCardView) {
        this.f3414a = baseCardView;
    }

    public void onAnimationEnd(Animation animation) {
        if (this.f3414a.f3106o == 0.0f) {
            for (int i = 0; i < this.f3414a.f3097f.size(); i++) {
                this.f3414a.f3097f.get(i).setVisibility(8);
            }
        }
    }

    public void onAnimationRepeat(Animation animation) {
    }

    public void onAnimationStart(Animation animation) {
    }
}
