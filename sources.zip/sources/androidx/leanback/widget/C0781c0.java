package androidx.leanback.widget;

import android.database.Observable;

/* renamed from: androidx.leanback.widget.c0 */
public abstract class C0781c0 {

    /* renamed from: a */
    private final C0782a f3415a = new C0782a();

    /* renamed from: b */
    private C0858q0 f3416b;

    /* renamed from: androidx.leanback.widget.c0$a */
    private static final class C0782a extends Observable<C0783b> {
        C0782a() {
        }

        /* renamed from: a */
        public void mo3677a() {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((C0783b) this.mObservers.get(size)).mo3158a();
            }
        }

        /* renamed from: b */
        public void mo3678b(int i, int i2) {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((C0783b) this.mObservers.get(size)).mo3683b(i, i2);
            }
        }

        /* renamed from: c */
        public void mo3679c(int i, int i2) {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((C0783b) this.mObservers.get(size)).mo3159c(i, i2);
            }
        }

        /* renamed from: d */
        public void mo3680d(int i, int i2, Object obj) {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((C0783b) this.mObservers.get(size)).mo3684d(i, i2, obj);
            }
        }

        /* renamed from: e */
        public void mo3681e(int i, int i2) {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((C0783b) this.mObservers.get(size)).mo3160e(i, i2);
            }
        }

        /* renamed from: f */
        public void mo3682f(int i, int i2) {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((C0783b) this.mObservers.get(size)).mo3161f(i, i2);
            }
        }
    }

    /* renamed from: androidx.leanback.widget.c0$b */
    public static abstract class C0783b {
        /* renamed from: a */
        public void mo3158a() {
        }

        /* renamed from: b */
        public void mo3683b(int i, int i2) {
            mo3158a();
        }

        /* renamed from: c */
        public void mo3159c(int i, int i2) {
            mo3158a();
        }

        /* renamed from: d */
        public void mo3684d(int i, int i2, Object obj) {
            mo3158a();
        }

        /* renamed from: e */
        public void mo3160e(int i, int i2) {
            mo3158a();
        }

        /* renamed from: f */
        public void mo3161f(int i, int i2) {
            mo3158a();
        }
    }

    public C0781c0() {
    }

    public C0781c0(C0844p0 p0Var) {
        mo3675l(new C0768a1(p0Var));
    }

    public C0781c0(C0858q0 q0Var) {
        mo3675l(q0Var);
    }

    /* renamed from: a */
    public abstract Object mo3153a(int i);

    /* renamed from: b */
    public final C0844p0 mo3665b(Object obj) {
        C0858q0 q0Var = this.f3416b;
        if (q0Var != null) {
            return q0Var.mo3140a(obj);
        }
        throw new IllegalStateException("Presenter selector must not be null");
    }

    /* renamed from: c */
    public final C0858q0 mo3666c() {
        return this.f3416b;
    }

    /* renamed from: d */
    public boolean mo3667d() {
        return this instanceof C0769b;
    }

    /* access modifiers changed from: protected */
    /* renamed from: e */
    public final void mo3668e() {
        this.f3415a.mo3677a();
    }

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public final void mo3669f(int i, int i2) {
        this.f3415a.mo3678b(i, i2);
    }

    /* renamed from: g */
    public final void mo3670g(int i, int i2) {
        this.f3415a.mo3679c(i, i2);
    }

    /* renamed from: h */
    public final void mo3671h(int i, int i2, Object obj) {
        this.f3415a.mo3680d(i, i2, obj);
    }

    /* access modifiers changed from: protected */
    /* renamed from: i */
    public final void mo3672i(int i, int i2) {
        this.f3415a.mo3681e(i, i2);
    }

    /* access modifiers changed from: protected */
    /* renamed from: j */
    public final void mo3673j(int i, int i2) {
        this.f3415a.mo3682f(i, i2);
    }

    /* renamed from: k */
    public final void mo3674k(C0783b bVar) {
        this.f3415a.registerObserver(bVar);
    }

    /* renamed from: l */
    public final void mo3675l(C0858q0 q0Var) {
        if (q0Var != null) {
            C0858q0 q0Var2 = this.f3416b;
            boolean z = q0Var2 != null;
            if (!z || q0Var2 == q0Var) {
            }
            this.f3416b = q0Var;
            if (z) {
                this.f3415a.mo3677a();
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Presenter selector must not be null");
    }

    /* renamed from: m */
    public abstract int mo3154m();

    /* renamed from: n */
    public final void mo3676n(C0783b bVar) {
        this.f3415a.unregisterObserver(bVar);
    }
}
