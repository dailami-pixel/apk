package androidx.leanback.widget;

import android.util.SparseArray;

/* renamed from: androidx.leanback.widget.c1 */
public class C0784c1 extends C0781c0 {

    /* renamed from: c */
    private SparseArray<Object> f3417c = new SparseArray<>();

    /* renamed from: a */
    public Object mo3153a(int i) {
        return this.f3417c.valueAt(i);
    }

    /* renamed from: d */
    public boolean mo3667d() {
        return true;
    }

    /* renamed from: m */
    public int mo3154m() {
        return this.f3417c.size();
    }

    /* renamed from: o */
    public void mo3685o(int i, Object obj) {
        int indexOfKey = this.f3417c.indexOfKey(i);
        if (indexOfKey < 0) {
            this.f3417c.append(i, obj);
            mo3672i(this.f3417c.indexOfKey(i), 1);
        } else if (this.f3417c.valueAt(indexOfKey) != obj) {
            this.f3417c.setValueAt(indexOfKey, obj);
            mo3670g(indexOfKey, 1);
        }
    }
}
