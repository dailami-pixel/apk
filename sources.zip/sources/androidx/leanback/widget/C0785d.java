package androidx.leanback.widget;

import android.view.animation.Animation;

/* renamed from: androidx.leanback.widget.d */
class C0785d implements Animation.AnimationListener {

    /* renamed from: a */
    final /* synthetic */ BaseCardView f3418a;

    C0785d(BaseCardView baseCardView) {
        this.f3418a = baseCardView;
    }

    public void onAnimationEnd(Animation animation) {
        if (((double) this.f3418a.f3107p) == 0.0d) {
            for (int i = 0; i < this.f3418a.f3097f.size(); i++) {
                this.f3418a.f3097f.get(i).setVisibility(8);
            }
        }
    }

    public void onAnimationRepeat(Animation animation) {
    }

    public void onAnimationStart(Animation animation) {
    }
}
