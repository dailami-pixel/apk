package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.d0 */
public interface C0786d0 {
    /* renamed from: d */
    void mo3689d(C0766a aVar);
}
