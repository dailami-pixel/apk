package androidx.leanback.widget;

import androidx.leanback.widget.C0855q;
import androidx.leanback.widget.GridLayoutManager;
import com.google.android.gms.common.api.C4291a;
import p098d.p112d.C4620d;
import p098d.p112d.C4621e;

/* renamed from: androidx.leanback.widget.d1 */
abstract class C0787d1 extends C0855q {

    /* renamed from: j */
    protected C4620d<C0788a> f3419j = new C4620d<>(64);

    /* renamed from: k */
    protected int f3420k = -1;

    /* renamed from: l */
    protected Object f3421l;

    /* renamed from: m */
    protected int f3422m;

    /* renamed from: androidx.leanback.widget.d1$a */
    public static class C0788a extends C0855q.C0856a {

        /* renamed from: b */
        public int f3423b;

        /* renamed from: c */
        public int f3424c;

        public C0788a(int i, int i2, int i3) {
            super(i);
            this.f3423b = i2;
            this.f3424c = i3;
        }
    }

    C0787d1() {
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public final boolean mo3653b(int i, boolean z) {
        boolean u;
        if (((GridLayoutManager.C0743b) this.f3591b).mo3443c() == 0) {
            return false;
        }
        if (!z && mo3849c(i)) {
            return false;
        }
        try {
            if (mo3691s(i, z)) {
                u = true;
                this.f3590a[0] = null;
            } else {
                u = mo3693u(i, z);
                this.f3590a[0] = null;
            }
            this.f3421l = null;
            return u;
        } catch (Throwable th) {
            this.f3590a[0] = null;
            this.f3421l = null;
            throw th;
        }
    }

    /* renamed from: j */
    public final C4621e[] mo3657j(int i, int i2) {
        for (int i3 = 0; i3 < this.f3594e; i3++) {
            this.f3597h[i3].mo21352b();
        }
        if (i >= 0) {
            while (i <= i2) {
                C4621e eVar = this.f3597h[mo3658k(i).f3599a];
                if (eVar.mo21356f() <= 0 || eVar.mo21354d() != i - 1) {
                    eVar.mo21351a(i);
                } else {
                    eVar.mo21355e();
                }
                eVar.mo21351a(i);
                i++;
            }
        }
        return this.f3597h;
    }

    /* renamed from: m */
    public void mo3690m(int i) {
        super.mo3690m(i);
        this.f3419j.mo21348e((mo3694v() - i) + 1);
        if (this.f3419j.mo21350g() == 0) {
            this.f3420k = -1;
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: n */
    public final boolean mo3659n(int i, boolean z) {
        boolean z2;
        if (((GridLayoutManager.C0743b) this.f3591b).mo3443c() == 0) {
            return false;
        }
        if (!z && mo3850d(i)) {
            return false;
        }
        try {
            if (mo3696x(i, z)) {
                z2 = true;
                this.f3590a[0] = null;
            } else {
                z2 = mo3698z(i, z);
                this.f3590a[0] = null;
            }
            this.f3421l = null;
            return z2;
        } catch (Throwable th) {
            this.f3590a[0] = null;
            this.f3421l = null;
            throw th;
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: s */
    public final boolean mo3691s(int i, boolean z) {
        int i2;
        int i3;
        int i4;
        if (this.f3419j.mo21350g() == 0) {
            return false;
        }
        int c = ((GridLayoutManager.C0743b) this.f3591b).mo3443c();
        int i5 = this.f3596g;
        if (i5 >= 0) {
            i2 = i5 + 1;
            i3 = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i5);
        } else {
            int i6 = this.f3598i;
            i2 = i6 != -1 ? i6 : 0;
            if (i2 > mo3694v() + 1 || i2 < this.f3420k) {
                C4620d<C0788a> dVar = this.f3419j;
                dVar.mo21349f(dVar.mo21350g());
                return false;
            } else if (i2 > mo3694v()) {
                return false;
            } else {
                i3 = C4291a.C4299e.API_PRIORITY_OTHER;
            }
        }
        int v = mo3694v();
        int i7 = i2;
        while (i7 < c && i7 <= v) {
            C0788a w = mo3658k(i7);
            if (i3 != Integer.MAX_VALUE) {
                i3 += w.f3423b;
            }
            int i8 = w.f3599a;
            int b = ((GridLayoutManager.C0743b) this.f3591b).mo3442b(i7, true, this.f3590a, false);
            if (b != w.f3424c) {
                w.f3424c = b;
                this.f3419j.mo21348e(v - i7);
                i4 = i7;
            } else {
                i4 = v;
            }
            this.f3596g = i7;
            if (this.f3595f < 0) {
                this.f3595f = i7;
            }
            ((GridLayoutManager.C0743b) this.f3591b).mo3441a(this.f3590a[0], i7, b, i8, i3);
            if (!z && mo3849c(i)) {
                return true;
            }
            if (i3 == Integer.MAX_VALUE) {
                i3 = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i7);
            }
            if (i8 == this.f3594e - 1 && z) {
                return true;
            }
            i7++;
            v = i4;
        }
        return false;
    }

    /* access modifiers changed from: protected */
    /* renamed from: t */
    public final int mo3692t(int i, int i2, int i3) {
        int i4;
        boolean z;
        int i5 = this.f3596g;
        if (i5 < 0 || (i5 == mo3694v() && this.f3596g == i - 1)) {
            int i6 = this.f3596g;
            if (i6 >= 0) {
                i4 = i3 - ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i6);
            } else if (this.f3419j.mo21350g() <= 0 || i != mo3694v() + 1) {
                i4 = 0;
            } else {
                int v = mo3694v();
                while (true) {
                    if (v < this.f3420k) {
                        z = false;
                        break;
                    } else if (mo3658k(v).f3599a == i2) {
                        z = true;
                        break;
                    } else {
                        v--;
                    }
                }
                if (!z) {
                    v = mo3694v();
                }
                i4 = this.f3592c ? (-mo3658k(v).f3424c) - this.f3593d : mo3658k(v).f3424c + this.f3593d;
                for (int i7 = v + 1; i7 <= mo3694v(); i7++) {
                    i4 -= mo3658k(i7).f3423b;
                }
            }
            C0788a aVar = new C0788a(i2, i4, 0);
            this.f3419j.mo21346b(aVar);
            Object obj = this.f3421l;
            if (obj != null) {
                aVar.f3424c = this.f3422m;
                this.f3421l = null;
            } else {
                aVar.f3424c = ((GridLayoutManager.C0743b) this.f3591b).mo3442b(i, true, this.f3590a, false);
                obj = this.f3590a[0];
            }
            Object obj2 = obj;
            if (this.f3419j.mo21350g() == 1) {
                this.f3596g = i;
                this.f3595f = i;
                this.f3420k = i;
            } else {
                int i8 = this.f3596g;
                if (i8 < 0) {
                    this.f3596g = i;
                    this.f3595f = i;
                } else {
                    this.f3596g = i8 + 1;
                }
            }
            ((GridLayoutManager.C0743b) this.f3591b).mo3441a(obj2, i, aVar.f3424c, i2, i3);
            return aVar.f3424c;
        }
        throw new IllegalStateException();
    }

    /* access modifiers changed from: protected */
    /* renamed from: u */
    public abstract boolean mo3693u(int i, boolean z);

    /* renamed from: v */
    public final int mo3694v() {
        return (this.f3419j.mo21350g() + this.f3420k) - 1;
    }

    /* renamed from: w */
    public final C0788a mo3658k(int i) {
        int i2 = i - this.f3420k;
        if (i2 < 0 || i2 >= this.f3419j.mo21350g()) {
            return null;
        }
        return this.f3419j.mo21347d(i2);
    }

    /* access modifiers changed from: protected */
    /* renamed from: x */
    public final boolean mo3696x(int i, boolean z) {
        int i2;
        int i3;
        int i4;
        if (this.f3419j.mo21350g() == 0) {
            return false;
        }
        int i5 = this.f3595f;
        if (i5 >= 0) {
            i4 = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i5);
            i3 = mo3658k(this.f3595f).f3423b;
            i2 = this.f3595f - 1;
        } else {
            i4 = C4291a.C4299e.API_PRIORITY_OTHER;
            int i6 = this.f3598i;
            i2 = i6 != -1 ? i6 : 0;
            if (i2 <= mo3694v()) {
                int i7 = this.f3420k;
                if (i2 >= i7 - 1) {
                    if (i2 < i7) {
                        return false;
                    }
                    i3 = 0;
                }
            }
            C4620d<C0788a> dVar = this.f3419j;
            dVar.mo21349f(dVar.mo21350g());
            return false;
        }
        int max = Math.max(GridLayoutManager.this.f3170y, this.f3420k);
        while (i2 >= max) {
            C0788a w = mo3658k(i2);
            int i8 = w.f3599a;
            int b = ((GridLayoutManager.C0743b) this.f3591b).mo3442b(i2, false, this.f3590a, false);
            if (b != w.f3424c) {
                this.f3419j.mo21349f((i2 + 1) - this.f3420k);
                this.f3420k = this.f3595f;
                this.f3421l = this.f3590a[0];
                this.f3422m = b;
                return false;
            }
            this.f3595f = i2;
            if (this.f3596g < 0) {
                this.f3596g = i2;
            }
            ((GridLayoutManager.C0743b) this.f3591b).mo3441a(this.f3590a[0], i2, b, i8, i4 - i3);
            if (!z && mo3850d(i)) {
                return true;
            }
            i4 = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i2);
            i3 = w.f3423b;
            if (i8 == 0 && z) {
                return true;
            }
            i2--;
        }
        return false;
    }

    /* access modifiers changed from: protected */
    /* renamed from: y */
    public final int mo3697y(int i, int i2, int i3) {
        int i4 = this.f3595f;
        if (i4 < 0 || (i4 == this.f3420k && i4 == i + 1)) {
            int i5 = this.f3420k;
            C0788a w = i5 >= 0 ? mo3658k(i5) : null;
            int d = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(this.f3420k);
            C0788a aVar = new C0788a(i2, 0, 0);
            this.f3419j.mo21345a(aVar);
            Object obj = this.f3421l;
            if (obj != null) {
                aVar.f3424c = this.f3422m;
                this.f3421l = null;
            } else {
                aVar.f3424c = ((GridLayoutManager.C0743b) this.f3591b).mo3442b(i, false, this.f3590a, false);
                obj = this.f3590a[0];
            }
            Object obj2 = obj;
            this.f3595f = i;
            this.f3420k = i;
            if (this.f3596g < 0) {
                this.f3596g = i;
            }
            int i6 = !this.f3592c ? i3 - aVar.f3424c : i3 + aVar.f3424c;
            if (w != null) {
                w.f3423b = d - i6;
            }
            ((GridLayoutManager.C0743b) this.f3591b).mo3441a(obj2, i, aVar.f3424c, i2, i6);
            return aVar.f3424c;
        }
        throw new IllegalStateException();
    }

    /* access modifiers changed from: protected */
    /* renamed from: z */
    public abstract boolean mo3698z(int i, boolean z);
}
