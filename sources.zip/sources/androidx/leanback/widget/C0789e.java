package androidx.leanback.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import androidx.leanback.widget.C0772b0;
import androidx.recyclerview.widget.C1230w;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Objects;
import p098d.p140l.C4825b;

/* renamed from: androidx.leanback.widget.e */
public abstract class C0789e extends RecyclerView {

    /* renamed from: a */
    final GridLayoutManager f3425a;

    /* renamed from: b */
    private boolean f3426b = true;

    /* renamed from: c */
    private boolean f3427c = true;

    /* renamed from: d */
    private RecyclerView.C1152l f3428d;

    /* renamed from: e */
    private C0794e f3429e;

    /* renamed from: f */
    private C0793d f3430f;

    /* renamed from: g */
    RecyclerView.C1170v f3431g;

    /* renamed from: h */
    private C0795f f3432h;

    /* renamed from: i */
    int f3433i = 4;

    /* renamed from: androidx.leanback.widget.e$a */
    class C0790a implements RecyclerView.C1170v {
        C0790a() {
        }

        /* renamed from: a */
        public void mo3740a(RecyclerView.C1142b0 b0Var) {
            GridLayoutManager gridLayoutManager = C0789e.this.f3425a;
            Objects.requireNonNull(gridLayoutManager);
            int adapterPosition = b0Var.getAdapterPosition();
            if (adapterPosition != -1) {
                gridLayoutManager.f3161f0.mo3784f(b0Var.itemView, adapterPosition);
            }
            RecyclerView.C1170v vVar = C0789e.this.f3431g;
            if (vVar != null) {
                ((C0790a) vVar).mo3740a(b0Var);
            }
        }
    }

    /* renamed from: androidx.leanback.widget.e$b */
    class C0791b extends C0802g0 {

        /* renamed from: a */
        final /* synthetic */ int f3435a;

        /* renamed from: b */
        final /* synthetic */ C0826l1 f3436b;

        C0791b(int i, C0826l1 l1Var) {
            this.f3435a = i;
            this.f3436b = l1Var;
        }

        /* renamed from: a */
        public void mo3059a(RecyclerView recyclerView, RecyclerView.C1142b0 b0Var, int i, int i2) {
            if (i == this.f3435a) {
                C0789e.this.f3425a.mo3399j2(this);
                this.f3436b.mo3220a(b0Var);
            }
        }
    }

    /* renamed from: androidx.leanback.widget.e$c */
    class C0792c extends C0802g0 {

        /* renamed from: a */
        final /* synthetic */ int f3438a;

        /* renamed from: b */
        final /* synthetic */ C0826l1 f3439b;

        C0792c(int i, C0826l1 l1Var) {
            this.f3438a = i;
            this.f3439b = l1Var;
        }

        /* renamed from: b */
        public void mo3741b(RecyclerView recyclerView, RecyclerView.C1142b0 b0Var, int i, int i2) {
            if (i == this.f3438a) {
                C0789e.this.f3425a.mo3399j2(this);
                this.f3439b.mo3220a(b0Var);
            }
        }
    }

    /* renamed from: androidx.leanback.widget.e$d */
    public interface C0793d {
        /* renamed from: a */
        boolean mo3191a(KeyEvent keyEvent);
    }

    /* renamed from: androidx.leanback.widget.e$e */
    public interface C0794e {
        /* renamed from: a */
        boolean mo3190a(MotionEvent motionEvent);
    }

    /* renamed from: androidx.leanback.widget.e$f */
    public interface C0795f {
    }

    C0789e(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this);
        this.f3425a = gridLayoutManager;
        setLayoutManager(gridLayoutManager);
        setPreserveFocusAfterLayout(false);
        setDescendantFocusability(262144);
        setHasFixedSize(true);
        setChildrenDrawingOrderEnabled(true);
        setWillNotDraw(true);
        setOverScrollMode(2);
        ((C1230w) getItemAnimator()).mo5238t(false);
        super.setRecyclerListener(new C0790a());
    }

    /* renamed from: A */
    public void mo3699A(int i, C0826l1 l1Var) {
        if (l1Var != null) {
            RecyclerView.C1142b0 findViewHolderForPosition = findViewHolderForPosition(i);
            if (findViewHolderForPosition == null || hasPendingAdapterUpdates()) {
                this.f3425a.mo3411t1(new C0791b(i, l1Var));
            } else {
                l1Var.mo3220a(findViewHolderForPosition);
            }
        }
        this.f3425a.mo3353E2(i, 0, true, 0);
    }

    /* renamed from: B */
    public void mo3700B(int i) {
        this.f3425a.f3157b0.mo3788a().mo3809q(i);
        requestLayout();
    }

    /* renamed from: C */
    public void mo3701C(int i) {
        this.f3425a.f3157b0.mo3788a().mo3810r(i);
        requestLayout();
    }

    /* renamed from: D */
    public void mo3702D(float f) {
        this.f3425a.f3157b0.mo3788a().mo3811s(f);
        requestLayout();
    }

    /* renamed from: a */
    public int mo3703a() {
        return this.f3425a.f3137H;
    }

    /* renamed from: b */
    public int mo3704b() {
        return this.f3425a.mo3374N1();
    }

    /* renamed from: d */
    public boolean mo3705d(int i) {
        return this.f3425a.mo3387Y1(i);
    }

    /* access modifiers changed from: protected */
    public boolean dispatchGenericFocusedEvent(MotionEvent motionEvent) {
        return super.dispatchGenericFocusedEvent(motionEvent);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        C0793d dVar = this.f3430f;
        if ((dVar != null && dVar.mo3191a(keyEvent)) || super.dispatchKeyEvent(keyEvent)) {
            return true;
        }
        C0795f fVar = this.f3432h;
        if (fVar == null) {
            return false;
        }
        Objects.requireNonNull(((C0772b0.C0774b) fVar).f3399a);
        return false;
    }

    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        C0794e eVar = this.f3429e;
        if (eVar == null || !eVar.mo3190a(motionEvent)) {
            return super.dispatchTouchEvent(motionEvent);
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo3709e(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825b.f17413f);
        boolean z = obtainStyledAttributes.getBoolean(4, false);
        boolean z2 = obtainStyledAttributes.getBoolean(3, false);
        GridLayoutManager gridLayoutManager = this.f3425a;
        gridLayoutManager.f3133D = (z ? 2048 : 0) | (gridLayoutManager.f3133D & -6145) | (z2 ? 4096 : 0);
        boolean z3 = obtainStyledAttributes.getBoolean(6, true);
        boolean z4 = obtainStyledAttributes.getBoolean(5, true);
        GridLayoutManager gridLayoutManager2 = this.f3425a;
        gridLayoutManager2.f3133D = (z3 ? 8192 : 0) | (gridLayoutManager2.f3133D & -24577) | (z4 ? 16384 : 0);
        gridLayoutManager2.mo3356F2(obtainStyledAttributes.getDimensionPixelSize(2, obtainStyledAttributes.getDimensionPixelSize(8, 0)));
        this.f3425a.mo3412t2(obtainStyledAttributes.getDimensionPixelSize(1, obtainStyledAttributes.getDimensionPixelSize(7, 0)));
        if (obtainStyledAttributes.hasValue(0)) {
            this.f3425a.mo3409s2(obtainStyledAttributes.getInt(0, 0));
            requestLayout();
        }
        obtainStyledAttributes.recycle();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public final boolean mo3710f() {
        return isChildrenDrawingOrderEnabled();
    }

    public View focusSearch(int i) {
        if (isFocused()) {
            GridLayoutManager gridLayoutManager = this.f3425a;
            View x = gridLayoutManager.mo4651x(gridLayoutManager.f3137H);
            if (x != null) {
                return focusSearch(x, i);
            }
        }
        return super.focusSearch(i);
    }

    /* renamed from: g */
    public void mo3712g(boolean z) {
        RecyclerView.C1152l lVar;
        if (this.f3426b != z) {
            this.f3426b = z;
            if (!z) {
                this.f3428d = getItemAnimator();
                lVar = null;
            } else {
                lVar = this.f3428d;
            }
            super.setItemAnimator(lVar);
        }
    }

    public int getChildDrawingOrder(int i, int i2) {
        int indexOfChild;
        GridLayoutManager gridLayoutManager = this.f3425a;
        View x = gridLayoutManager.mo4651x(gridLayoutManager.f3137H);
        if (x == null || i2 < (indexOfChild = indexOfChild(x))) {
            return i2;
        }
        if (i2 < i - 1) {
            indexOfChild = ((indexOfChild + i) - 1) - i2;
        }
        return indexOfChild;
    }

    /* renamed from: h */
    public void mo3714h(int i) {
        GridLayoutManager gridLayoutManager = this.f3425a;
        gridLayoutManager.f3143N = i;
        if (i != -1) {
            int D = gridLayoutManager.mo4966D();
            for (int i2 = 0; i2 < D; i2++) {
                gridLayoutManager.mo4964C(i2).setVisibility(gridLayoutManager.f3143N);
            }
        }
    }

    public boolean hasOverlappingRendering() {
        return this.f3427c;
    }

    /* renamed from: i */
    public void mo3716i(boolean z) {
        super.setChildrenDrawingOrderEnabled(z);
    }

    /* renamed from: j */
    public void mo3717j(int i) {
        if (i == 0 || i == 1 || i == 2) {
            this.f3425a.mo3407r2(i);
            requestLayout();
            return;
        }
        throw new IllegalArgumentException("Invalid scrollStrategy");
    }

    /* renamed from: k */
    public final void mo3718k(boolean z) {
        setDescendantFocusability(z ? 393216 : 262144);
        GridLayoutManager gridLayoutManager = this.f3425a;
        gridLayoutManager.f3133D = (z ? 32768 : 0) | (gridLayoutManager.f3133D & -32769);
    }

    /* renamed from: l */
    public void mo3719l(int i) {
        this.f3425a.mo3414u2(i);
        requestLayout();
    }

    /* renamed from: m */
    public void mo3720m(float f) {
        this.f3425a.mo3416v2(f);
        requestLayout();
    }

    /* renamed from: n */
    public void mo3721n(boolean z) {
        this.f3425a.mo3418w2(z);
        requestLayout();
    }

    /* renamed from: o */
    public void mo3722o(int i) {
        this.f3425a.mo3420x2(i);
    }

    /* access modifiers changed from: protected */
    public void onFocusChanged(boolean z, int i, Rect rect) {
        super.onFocusChanged(z, i, rect);
        GridLayoutManager gridLayoutManager = this.f3425a;
        Objects.requireNonNull(gridLayoutManager);
        if (z) {
            int i2 = gridLayoutManager.f3137H;
            while (true) {
                View x = gridLayoutManager.mo4651x(i2);
                if (x != null) {
                    if (x.getVisibility() != 0 || !x.hasFocusable()) {
                        i2++;
                    } else {
                        x.requestFocus();
                        return;
                    }
                } else {
                    return;
                }
            }
        }
    }

    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        return this.f3425a.mo3382U1(this, i, rect);
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x001b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onRtlPropertiesChanged(int r7) {
        /*
            r6 = this;
            androidx.leanback.widget.GridLayoutManager r0 = r6.f3425a
            int r1 = r0.f3167v
            r2 = 1
            r3 = 0
            if (r1 != 0) goto L_0x000d
            if (r7 != r2) goto L_0x0012
            r1 = 262144(0x40000, float:3.67342E-40)
            goto L_0x0013
        L_0x000d:
            if (r7 != r2) goto L_0x0012
            r1 = 524288(0x80000, float:7.34684E-40)
            goto L_0x0013
        L_0x0012:
            r1 = 0
        L_0x0013:
            int r4 = r0.f3133D
            r5 = 786432(0xc0000, float:1.102026E-39)
            r5 = r5 & r4
            if (r5 != r1) goto L_0x001b
            goto L_0x0031
        L_0x001b:
            r5 = -786433(0xfffffffffff3ffff, float:NaN)
            r4 = r4 & r5
            r1 = r1 | r4
            r0.f3133D = r1
            r1 = r1 | 256(0x100, float:3.59E-43)
            r0.f3133D = r1
            androidx.leanback.widget.n1 r0 = r0.f3157b0
            androidx.leanback.widget.n1$a r0 = r0.f3496c
            if (r7 != r2) goto L_0x002d
            goto L_0x002e
        L_0x002d:
            r2 = 0
        L_0x002e:
            r0.mo3807o(r2)
        L_0x0031:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.C0789e.onRtlPropertiesChanged(int):void");
    }

    /* renamed from: p */
    public void mo3726p(C0796e0 e0Var) {
        this.f3425a.f3136G = e0Var;
    }

    /* renamed from: q */
    public void mo3727q(C0802g0 g0Var) {
        this.f3425a.mo3343A2(g0Var);
    }

    /* renamed from: r */
    public void mo3728r(C0793d dVar) {
        this.f3430f = dVar;
    }

    /* renamed from: s */
    public void mo3729s(C0794e eVar) {
        this.f3429e = eVar;
    }

    public void scrollToPosition(int i) {
        GridLayoutManager gridLayoutManager = this.f3425a;
        if ((gridLayoutManager.f3133D & 64) != 0) {
            gridLayoutManager.mo3353E2(i, 0, false, 0);
        } else {
            super.scrollToPosition(i);
        }
    }

    public void setRecyclerListener(RecyclerView.C1170v vVar) {
        this.f3431g = vVar;
    }

    public void smoothScrollToPosition(int i) {
        GridLayoutManager gridLayoutManager = this.f3425a;
        if ((gridLayoutManager.f3133D & 64) != 0) {
            gridLayoutManager.mo3353E2(i, 0, false, 0);
        } else {
            super.smoothScrollToPosition(i);
        }
    }

    /* renamed from: t */
    public void mo3733t(C0795f fVar) {
        this.f3432h = fVar;
    }

    /* renamed from: u */
    public void mo3734u(boolean z) {
        GridLayoutManager gridLayoutManager = this.f3425a;
        int i = gridLayoutManager.f3133D;
        int i2 = 65536;
        if (((i & 65536) != 0) != z) {
            int i3 = i & -65537;
            if (!z) {
                i2 = 0;
            }
            gridLayoutManager.f3133D = i3 | i2;
            if (z) {
                gridLayoutManager.mo4991b1();
            }
        }
    }

    /* renamed from: v */
    public final void mo3735v(int i) {
        this.f3425a.f3161f0.mo3786h(i);
    }

    /* renamed from: w */
    public void mo3736w(boolean z) {
        this.f3425a.mo3350D2(z);
    }

    /* renamed from: x */
    public void mo3737x(int i) {
        this.f3425a.mo3353E2(i, 0, false, 0);
    }

    /* renamed from: y */
    public void mo3738y(int i, C0826l1 l1Var) {
        if (l1Var != null) {
            RecyclerView.C1142b0 findViewHolderForPosition = findViewHolderForPosition(i);
            if (findViewHolderForPosition == null || hasPendingAdapterUpdates()) {
                this.f3425a.mo3411t1(new C0792c(i, l1Var));
            } else {
                l1Var.mo3220a(findViewHolderForPosition);
            }
        }
        this.f3425a.mo3353E2(i, 0, false, 0);
    }

    /* renamed from: z */
    public void mo3739z(int i) {
        this.f3425a.mo3353E2(i, 0, true, 0);
    }
}
