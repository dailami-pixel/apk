package androidx.leanback.widget;

import android.view.View;
import android.view.ViewGroup;

/* renamed from: androidx.leanback.widget.e0 */
public interface C0796e0 {
    /* renamed from: a */
    void mo3230a(ViewGroup viewGroup, View view, int i, long j);
}
