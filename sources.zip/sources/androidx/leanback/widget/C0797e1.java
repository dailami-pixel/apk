package androidx.leanback.widget;

import androidx.leanback.widget.C0787d1;
import androidx.leanback.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.common.api.C4291a;

/* renamed from: androidx.leanback.widget.e1 */
final class C0797e1 extends C0787d1 {
    C0797e1() {
    }

    /* renamed from: A */
    private int m3522A(boolean z) {
        boolean z2 = false;
        if (z) {
            for (int i = this.f3596g; i >= this.f3595f; i--) {
                int i2 = mo3658k(i).f3599a;
                if (i2 == 0) {
                    z2 = true;
                } else if (z2 && i2 == this.f3594e - 1) {
                    return i;
                }
            }
            return -1;
        }
        for (int i3 = this.f3595f; i3 <= this.f3596g; i3++) {
            int i4 = mo3658k(i3).f3599a;
            if (i4 == this.f3594e - 1) {
                z2 = true;
            } else if (z2 && i4 == 0) {
                return i3;
            }
        }
        return -1;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: B */
    public int mo3742B(int i) {
        C0787d1.C0788a w;
        int i2 = this.f3595f;
        if (i2 < 0) {
            return RecyclerView.UNDEFINED_DURATION;
        }
        if (this.f3592c) {
            int d = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i2);
            if (mo3658k(this.f3595f).f3599a == i) {
                return d;
            }
            int i3 = this.f3595f;
            do {
                i3++;
                if (i3 <= mo3694v()) {
                    w = mo3658k(i3);
                    d += w.f3423b;
                }
            } while (w.f3599a != i);
            return d;
        }
        int d2 = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(this.f3596g);
        C0787d1.C0788a w2 = mo3658k(this.f3596g);
        if (w2.f3599a != i) {
            int i4 = this.f3596g;
            while (true) {
                i4--;
                if (i4 < this.f3420k) {
                    break;
                }
                d2 -= w2.f3423b;
                w2 = mo3658k(i4);
                if (w2.f3599a == i) {
                    break;
                }
            }
        }
        return d2 + w2.f3424c;
        return RecyclerView.UNDEFINED_DURATION;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: C */
    public int mo3743C(int i) {
        C0787d1.C0788a w;
        int i2 = this.f3595f;
        if (i2 < 0) {
            return C4291a.C4299e.API_PRIORITY_OTHER;
        }
        if (this.f3592c) {
            int d = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(this.f3596g);
            C0787d1.C0788a w2 = mo3658k(this.f3596g);
            if (w2.f3599a != i) {
                int i3 = this.f3596g;
                while (true) {
                    i3--;
                    if (i3 < this.f3420k) {
                        break;
                    }
                    d -= w2.f3423b;
                    w2 = mo3658k(i3);
                    if (w2.f3599a == i) {
                        break;
                    }
                }
            }
            return d - w2.f3424c;
        }
        int d2 = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i2);
        if (mo3658k(this.f3595f).f3599a == i) {
            return d2;
        }
        int i4 = this.f3595f;
        do {
            i4++;
            if (i4 <= mo3694v()) {
                w = mo3658k(i4);
                d2 += w.f3423b;
            }
        } while (w.f3599a != i);
        return d2;
        return C4291a.C4299e.API_PRIORITY_OTHER;
    }

    /* renamed from: f */
    public int mo3655f(boolean z, int i, int[] iArr) {
        int i2;
        int d = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i);
        C0787d1.C0788a w = mo3658k(i);
        int i3 = w.f3599a;
        if (this.f3592c) {
            i2 = i3;
            int i4 = i2;
            int i5 = 1;
            int i6 = i + 1;
            int i7 = d;
            while (i5 < this.f3594e && i6 <= this.f3596g) {
                C0787d1.C0788a w2 = mo3658k(i6);
                i7 += w2.f3423b;
                int i8 = w2.f3599a;
                if (i8 != i4) {
                    i5++;
                    if (!z ? i7 >= d : i7 <= d) {
                        i4 = i8;
                    } else {
                        d = i7;
                        i = i6;
                        i2 = i8;
                        i4 = i2;
                    }
                }
                i6++;
            }
        } else {
            int i9 = i - 1;
            int i10 = 1;
            int i11 = i3;
            C0787d1.C0788a aVar = w;
            int i12 = d;
            d = ((GridLayoutManager.C0743b) this.f3591b).mo3445e(i) + d;
            i2 = i11;
            while (i10 < this.f3594e && i9 >= this.f3595f) {
                i12 -= aVar.f3423b;
                aVar = mo3658k(i9);
                int i13 = aVar.f3599a;
                if (i13 != i11) {
                    i10++;
                    int e = ((GridLayoutManager.C0743b) this.f3591b).mo3445e(i9) + i12;
                    if (!z ? e >= d : e <= d) {
                        i11 = i13;
                    } else {
                        d = e;
                        i = i9;
                        i2 = i13;
                        i11 = i2;
                    }
                }
                i9--;
            }
        }
        if (iArr != null) {
            iArr[0] = i2;
            iArr[1] = i;
        }
        return d;
    }

    /* renamed from: h */
    public int mo3656h(boolean z, int i, int[] iArr) {
        int i2;
        int d = ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i);
        C0787d1.C0788a w = mo3658k(i);
        int i3 = w.f3599a;
        if (this.f3592c) {
            int i4 = i - 1;
            int i5 = 1;
            i2 = d - ((GridLayoutManager.C0743b) this.f3591b).mo3445e(i);
            int i6 = i3;
            while (i5 < this.f3594e && i4 >= this.f3595f) {
                d -= w.f3423b;
                w = mo3658k(i4);
                int i7 = w.f3599a;
                if (i7 != i6) {
                    i5++;
                    int e = d - ((GridLayoutManager.C0743b) this.f3591b).mo3445e(i4);
                    if (!z ? e >= i2 : e <= i2) {
                        i6 = i7;
                    } else {
                        i2 = e;
                        i = i4;
                        i3 = i7;
                        i6 = i3;
                    }
                }
                i4--;
            }
        } else {
            int i8 = i3;
            int i9 = i8;
            int i10 = 1;
            int i11 = i + 1;
            int i12 = d;
            while (i10 < this.f3594e && i11 <= this.f3596g) {
                C0787d1.C0788a w2 = mo3658k(i11);
                i12 += w2.f3423b;
                int i13 = w2.f3599a;
                if (i13 != i9) {
                    i10++;
                    if (!z ? i12 >= d : i12 <= d) {
                        i9 = i13;
                    } else {
                        d = i12;
                        i = i11;
                        i8 = i13;
                        i9 = i8;
                    }
                }
                i11++;
            }
            i2 = d;
            i3 = i8;
        }
        if (iArr != null) {
            iArr[0] = i3;
            iArr[1] = i;
        }
        return i2;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:59:0x00c2, code lost:
        if (r13.f3592c != false) goto L_0x00c4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x00c8, code lost:
        r10 = r13.f3593d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x00e7, code lost:
        if (r13.f3592c != false) goto L_0x00c4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:93:0x0131, code lost:
        r6 = r10;
     */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x0101 A[LOOP:2: B:77:0x0101->B:91:0x0125, LOOP_START, PHI: r6 r9 r10 
      PHI: (r6v10 int) = (r6v3 int), (r6v14 int) binds: [B:76:0x00ff, B:91:0x0125] A[DONT_GENERATE, DONT_INLINE]
      PHI: (r9v7 int) = (r9v5 int), (r9v8 int) binds: [B:76:0x00ff, B:91:0x0125] A[DONT_GENERATE, DONT_INLINE]
      PHI: (r10v3 int) = (r10v2 int), (r10v5 int) binds: [B:76:0x00ff, B:91:0x0125] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARNING: Removed duplicated region for block: B:94:0x0133  */
    /* renamed from: u */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo3693u(int r14, boolean r15) {
        /*
            r13 = this;
            androidx.leanback.widget.q$b r0 = r13.f3591b
            androidx.leanback.widget.GridLayoutManager$b r0 = (androidx.leanback.widget.GridLayoutManager.C0743b) r0
            int r0 = r0.mo3443c()
            int r1 = r13.f3596g
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = 0
            r4 = 0
            r5 = 1
            if (r1 < 0) goto L_0x0078
            int r6 = r13.mo3694v()
            if (r1 >= r6) goto L_0x0018
            return r4
        L_0x0018:
            int r1 = r13.f3596g
            int r6 = r1 + 1
            androidx.leanback.widget.d1$a r1 = r13.mo3658k(r1)
            int r1 = r1.f3599a
            int r7 = r13.m3522A(r5)
            if (r7 >= 0) goto L_0x0042
            r7 = 0
            r8 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x002b:
            int r9 = r13.f3594e
            if (r7 >= r9) goto L_0x0050
            boolean r8 = r13.f3592c
            if (r8 == 0) goto L_0x0038
            int r8 = r13.mo3743C(r7)
            goto L_0x003c
        L_0x0038:
            int r8 = r13.mo3742B(r7)
        L_0x003c:
            if (r8 == r2) goto L_0x003f
            goto L_0x0050
        L_0x003f:
            int r7 = r7 + 1
            goto L_0x002b
        L_0x0042:
            boolean r8 = r13.f3592c
            if (r8 == 0) goto L_0x004b
            int r7 = r13.mo3656h(r4, r7, r3)
            goto L_0x004f
        L_0x004b:
            int r7 = r13.mo3655f(r5, r7, r3)
        L_0x004f:
            r8 = r7
        L_0x0050:
            boolean r7 = r13.f3592c
            if (r7 == 0) goto L_0x005b
            int r7 = r13.mo3743C(r1)
            if (r7 > r8) goto L_0x0076
            goto L_0x0061
        L_0x005b:
            int r7 = r13.mo3742B(r1)
            if (r7 < r8) goto L_0x0076
        L_0x0061:
            int r1 = r1 + 1
            int r7 = r13.f3594e
            if (r1 != r7) goto L_0x0076
            boolean r1 = r13.f3592c
            if (r1 == 0) goto L_0x0070
            int r1 = r13.mo3852i(r4, r3)
            goto L_0x0074
        L_0x0070:
            int r1 = r13.mo3851g(r5, r3)
        L_0x0074:
            r8 = r1
            r1 = 0
        L_0x0076:
            r7 = 1
            goto L_0x009a
        L_0x0078:
            int r1 = r13.f3598i
            r6 = -1
            if (r1 == r6) goto L_0x007f
            r6 = r1
            goto L_0x0080
        L_0x007f:
            r6 = 0
        L_0x0080:
            d.d.d<androidx.leanback.widget.d1$a> r1 = r13.f3419j
            int r1 = r1.mo21350g()
            if (r1 <= 0) goto L_0x0094
            int r1 = r13.mo3694v()
            androidx.leanback.widget.d1$a r1 = r13.mo3658k(r1)
            int r1 = r1.f3599a
            int r1 = r1 + r5
            goto L_0x0095
        L_0x0094:
            r1 = r6
        L_0x0095:
            int r7 = r13.f3594e
            int r1 = r1 % r7
            r7 = 0
            r8 = 0
        L_0x009a:
            r9 = 0
        L_0x009b:
            int r10 = r13.f3594e
            if (r1 >= r10) goto L_0x0149
            if (r6 == r0) goto L_0x0148
            if (r15 != 0) goto L_0x00ab
            boolean r10 = r13.mo3849c(r14)
            if (r10 == 0) goto L_0x00ab
            goto L_0x0148
        L_0x00ab:
            boolean r9 = r13.f3592c
            if (r9 == 0) goto L_0x00b4
            int r9 = r13.mo3743C(r1)
            goto L_0x00b8
        L_0x00b4:
            int r9 = r13.mo3742B(r1)
        L_0x00b8:
            r10 = 2147483647(0x7fffffff, float:NaN)
            if (r9 == r10) goto L_0x00cc
            if (r9 != r2) goto L_0x00c0
            goto L_0x00cc
        L_0x00c0:
            boolean r10 = r13.f3592c
            if (r10 == 0) goto L_0x00c8
        L_0x00c4:
            int r10 = r13.f3593d
            int r10 = -r10
            goto L_0x00ca
        L_0x00c8:
            int r10 = r13.f3593d
        L_0x00ca:
            int r9 = r9 + r10
            goto L_0x00f9
        L_0x00cc:
            boolean r9 = r13.f3592c
            if (r1 != 0) goto L_0x00ea
            if (r9 == 0) goto L_0x00da
            int r9 = r13.f3594e
            int r9 = r9 - r5
            int r9 = r13.mo3743C(r9)
            goto L_0x00e1
        L_0x00da:
            int r9 = r13.f3594e
            int r9 = r9 - r5
            int r9 = r13.mo3742B(r9)
        L_0x00e1:
            if (r9 == r10) goto L_0x00f9
            if (r9 == r2) goto L_0x00f9
            boolean r10 = r13.f3592c
            if (r10 == 0) goto L_0x00c8
            goto L_0x00c4
        L_0x00ea:
            if (r9 == 0) goto L_0x00f3
            int r9 = r1 + -1
            int r9 = r13.mo3742B(r9)
            goto L_0x00f9
        L_0x00f3:
            int r9 = r1 + -1
            int r9 = r13.mo3743C(r9)
        L_0x00f9:
            int r10 = r6 + 1
            int r6 = r13.mo3692t(r6, r1, r9)
            if (r7 == 0) goto L_0x0133
        L_0x0101:
            boolean r11 = r13.f3592c
            if (r11 == 0) goto L_0x010a
            int r11 = r9 - r6
            if (r11 <= r8) goto L_0x0131
            goto L_0x010e
        L_0x010a:
            int r11 = r9 + r6
            if (r11 >= r8) goto L_0x0131
        L_0x010e:
            if (r10 == r0) goto L_0x0130
            if (r15 != 0) goto L_0x0119
            boolean r11 = r13.mo3849c(r14)
            if (r11 == 0) goto L_0x0119
            goto L_0x0130
        L_0x0119:
            boolean r11 = r13.f3592c
            if (r11 == 0) goto L_0x0122
            int r6 = -r6
            int r11 = r13.f3593d
            int r6 = r6 - r11
            goto L_0x0125
        L_0x0122:
            int r11 = r13.f3593d
            int r6 = r6 + r11
        L_0x0125:
            int r9 = r9 + r6
            int r6 = r10 + 1
            int r10 = r13.mo3692t(r10, r1, r9)
            r12 = r10
            r10 = r6
            r6 = r12
            goto L_0x0101
        L_0x0130:
            return r5
        L_0x0131:
            r6 = r10
            goto L_0x0143
        L_0x0133:
            boolean r6 = r13.f3592c
            if (r6 == 0) goto L_0x013c
            int r6 = r13.mo3743C(r1)
            goto L_0x0140
        L_0x013c:
            int r6 = r13.mo3742B(r1)
        L_0x0140:
            r8 = r6
            r6 = r10
            r7 = 1
        L_0x0143:
            int r1 = r1 + 1
            r9 = 1
            goto L_0x009b
        L_0x0148:
            return r9
        L_0x0149:
            if (r15 == 0) goto L_0x014c
            return r9
        L_0x014c:
            boolean r1 = r13.f3592c
            if (r1 == 0) goto L_0x0155
            int r1 = r13.mo3852i(r4, r3)
            goto L_0x0159
        L_0x0155:
            int r1 = r13.mo3851g(r5, r3)
        L_0x0159:
            r8 = r1
            r1 = 0
            goto L_0x009b
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.C0797e1.mo3693u(int, boolean):boolean");
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x00b8, code lost:
        if (r12.f3592c != false) goto L_0x00ba;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:59:0x00bd, code lost:
        r9 = -r12.f3593d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x00da, code lost:
        if (r12.f3592c != false) goto L_0x00ba;
     */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x00f6 A[LOOP:2: B:77:0x00f6->B:91:0x011a, LOOP_START, PHI: r5 r8 r9 
      PHI: (r5v10 int) = (r5v3 int), (r5v14 int) binds: [B:76:0x00f4, B:91:0x011a] A[DONT_GENERATE, DONT_INLINE]
      PHI: (r8v7 int) = (r8v5 int), (r8v8 int) binds: [B:76:0x00f4, B:91:0x011a] A[DONT_GENERATE, DONT_INLINE]
      PHI: (r9v2 int) = (r9v1 int), (r9v4 int) binds: [B:76:0x00f4, B:91:0x011a] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARNING: Removed duplicated region for block: B:94:0x0128  */
    /* renamed from: z */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo3698z(int r13, boolean r14) {
        /*
            r12 = this;
            int r0 = r12.f3595f
            r1 = 2147483647(0x7fffffff, float:NaN)
            r2 = 0
            r3 = 0
            r4 = 1
            if (r0 < 0) goto L_0x0070
            int r5 = r12.f3420k
            if (r0 <= r5) goto L_0x000f
            return r3
        L_0x000f:
            int r5 = r0 + -1
            androidx.leanback.widget.d1$a r0 = r12.mo3658k(r0)
            int r0 = r0.f3599a
            int r6 = r12.m3522A(r3)
            if (r6 >= 0) goto L_0x003a
            int r0 = r0 + -1
            int r6 = r12.f3594e
            int r6 = r6 - r4
            r7 = 2147483647(0x7fffffff, float:NaN)
        L_0x0025:
            if (r6 < 0) goto L_0x0048
            boolean r7 = r12.f3592c
            if (r7 == 0) goto L_0x0030
            int r7 = r12.mo3742B(r6)
            goto L_0x0034
        L_0x0030:
            int r7 = r12.mo3743C(r6)
        L_0x0034:
            if (r7 == r1) goto L_0x0037
            goto L_0x0048
        L_0x0037:
            int r6 = r6 + -1
            goto L_0x0025
        L_0x003a:
            boolean r7 = r12.f3592c
            if (r7 == 0) goto L_0x0043
            int r6 = r12.mo3655f(r4, r6, r2)
            goto L_0x0047
        L_0x0043:
            int r6 = r12.mo3656h(r3, r6, r2)
        L_0x0047:
            r7 = r6
        L_0x0048:
            boolean r6 = r12.f3592c
            if (r6 == 0) goto L_0x0053
            int r6 = r12.mo3742B(r0)
            if (r6 < r7) goto L_0x006e
            goto L_0x0059
        L_0x0053:
            int r6 = r12.mo3743C(r0)
            if (r6 > r7) goto L_0x006e
        L_0x0059:
            int r0 = r0 + -1
            if (r0 >= 0) goto L_0x006e
            int r0 = r12.f3594e
            int r0 = r0 - r4
            boolean r6 = r12.f3592c
            if (r6 == 0) goto L_0x0069
            int r6 = r12.mo3851g(r4, r2)
            goto L_0x006d
        L_0x0069:
            int r6 = r12.mo3852i(r3, r2)
        L_0x006d:
            r7 = r6
        L_0x006e:
            r6 = 1
            goto L_0x0093
        L_0x0070:
            int r0 = r12.f3598i
            r5 = -1
            if (r0 == r5) goto L_0x0077
            r5 = r0
            goto L_0x0078
        L_0x0077:
            r5 = 0
        L_0x0078:
            d.d.d<androidx.leanback.widget.d1$a> r0 = r12.f3419j
            int r0 = r0.mo21350g()
            if (r0 <= 0) goto L_0x008d
            int r0 = r12.f3420k
            androidx.leanback.widget.d1$a r0 = r12.mo3658k(r0)
            int r0 = r0.f3599a
            int r6 = r12.f3594e
            int r0 = r0 + r6
            int r0 = r0 - r4
            goto L_0x008e
        L_0x008d:
            r0 = r5
        L_0x008e:
            int r6 = r12.f3594e
            int r0 = r0 % r6
            r6 = 0
            r7 = 0
        L_0x0093:
            r8 = 0
        L_0x0094:
            if (r0 < 0) goto L_0x013e
            if (r5 < 0) goto L_0x013d
            if (r14 != 0) goto L_0x00a2
            boolean r9 = r12.mo3850d(r13)
            if (r9 == 0) goto L_0x00a2
            goto L_0x013d
        L_0x00a2:
            boolean r8 = r12.f3592c
            if (r8 == 0) goto L_0x00ab
            int r8 = r12.mo3742B(r0)
            goto L_0x00af
        L_0x00ab:
            int r8 = r12.mo3743C(r0)
        L_0x00af:
            r9 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r8 == r1) goto L_0x00c2
            if (r8 != r9) goto L_0x00b6
            goto L_0x00c2
        L_0x00b6:
            boolean r9 = r12.f3592c
            if (r9 == 0) goto L_0x00bd
        L_0x00ba:
            int r9 = r12.f3593d
            goto L_0x00c0
        L_0x00bd:
            int r9 = r12.f3593d
            int r9 = -r9
        L_0x00c0:
            int r8 = r8 + r9
            goto L_0x00ee
        L_0x00c2:
            int r8 = r12.f3594e
            int r8 = r8 - r4
            if (r0 != r8) goto L_0x00dd
            boolean r8 = r12.f3592c
            if (r8 == 0) goto L_0x00d0
            int r8 = r12.mo3742B(r3)
            goto L_0x00d4
        L_0x00d0:
            int r8 = r12.mo3743C(r3)
        L_0x00d4:
            if (r8 == r1) goto L_0x00ee
            if (r8 == r9) goto L_0x00ee
            boolean r9 = r12.f3592c
            if (r9 == 0) goto L_0x00bd
            goto L_0x00ba
        L_0x00dd:
            boolean r8 = r12.f3592c
            if (r8 == 0) goto L_0x00e8
            int r8 = r0 + 1
            int r8 = r12.mo3743C(r8)
            goto L_0x00ee
        L_0x00e8:
            int r8 = r0 + 1
            int r8 = r12.mo3742B(r8)
        L_0x00ee:
            int r9 = r5 + -1
            int r5 = r12.mo3697y(r5, r0, r8)
            if (r6 == 0) goto L_0x0128
        L_0x00f6:
            boolean r10 = r12.f3592c
            if (r10 == 0) goto L_0x00ff
            int r10 = r8 + r5
            if (r10 >= r7) goto L_0x0126
            goto L_0x0103
        L_0x00ff:
            int r10 = r8 - r5
            if (r10 <= r7) goto L_0x0126
        L_0x0103:
            if (r9 < 0) goto L_0x0125
            if (r14 != 0) goto L_0x010e
            boolean r10 = r12.mo3850d(r13)
            if (r10 == 0) goto L_0x010e
            goto L_0x0125
        L_0x010e:
            boolean r10 = r12.f3592c
            if (r10 == 0) goto L_0x0116
            int r10 = r12.f3593d
            int r5 = r5 + r10
            goto L_0x011a
        L_0x0116:
            int r5 = -r5
            int r10 = r12.f3593d
            int r5 = r5 - r10
        L_0x011a:
            int r8 = r8 + r5
            int r5 = r9 + -1
            int r9 = r12.mo3697y(r9, r0, r8)
            r11 = r9
            r9 = r5
            r5 = r11
            goto L_0x00f6
        L_0x0125:
            return r4
        L_0x0126:
            r5 = r9
            goto L_0x0138
        L_0x0128:
            boolean r5 = r12.f3592c
            if (r5 == 0) goto L_0x0131
            int r5 = r12.mo3742B(r0)
            goto L_0x0135
        L_0x0131:
            int r5 = r12.mo3743C(r0)
        L_0x0135:
            r7 = r5
            r5 = r9
            r6 = 1
        L_0x0138:
            int r0 = r0 + -1
            r8 = 1
            goto L_0x0094
        L_0x013d:
            return r8
        L_0x013e:
            if (r14 == 0) goto L_0x0141
            return r8
        L_0x0141:
            boolean r0 = r12.f3592c
            if (r0 == 0) goto L_0x014a
            int r0 = r12.mo3851g(r4, r2)
            goto L_0x014e
        L_0x014a:
            int r0 = r12.mo3852i(r3, r2)
        L_0x014e:
            r7 = r0
            int r0 = r12.f3594e
            int r0 = r0 - r4
            goto L_0x0094
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.C0797e1.mo3698z(int, boolean):boolean");
    }
}
