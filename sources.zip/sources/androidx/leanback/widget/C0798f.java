package androidx.leanback.widget;

import androidx.leanback.widget.C0844p0;
import androidx.leanback.widget.C0870v0;

/* renamed from: androidx.leanback.widget.f */
public interface C0798f<T> {
    /* renamed from: a */
    void mo3184a(C0844p0.C0845a aVar, Object obj, C0870v0.C0872b bVar, T t);
}
