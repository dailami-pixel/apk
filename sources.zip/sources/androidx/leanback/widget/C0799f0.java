package androidx.leanback.widget;

import android.view.View;
import android.view.ViewGroup;

@Deprecated
/* renamed from: androidx.leanback.widget.f0 */
public interface C0799f0 {
    /* renamed from: a */
    void mo3642a(ViewGroup viewGroup, View view, int i, long j);
}
