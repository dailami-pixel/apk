package androidx.leanback.widget;

import android.view.View;

/* renamed from: androidx.leanback.widget.f1 */
class C0800f1 {

    /* renamed from: a */
    View f3441a;

    /* renamed from: b */
    View f3442b;

    C0800f1() {
    }
}
