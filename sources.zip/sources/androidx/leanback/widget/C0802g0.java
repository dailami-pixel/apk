package androidx.leanback.widget;

import androidx.recyclerview.widget.RecyclerView;

/* renamed from: androidx.leanback.widget.g0 */
public abstract class C0802g0 {
    /* renamed from: a */
    public void mo3059a(RecyclerView recyclerView, RecyclerView.C1142b0 b0Var, int i, int i2) {
    }

    /* renamed from: b */
    public void mo3741b(RecyclerView recyclerView, RecyclerView.C1142b0 b0Var, int i, int i2) {
    }
}
