package androidx.leanback.widget;

import android.view.View;
import android.view.ViewGroup;
import androidx.leanback.transition.C0729a;
import androidx.leanback.widget.BrowseFrameLayout;
import com.vidio.android.p195tv.R;
import p098d.p120g.p130j.C4761m;

/* renamed from: androidx.leanback.widget.g1 */
public class C0803g1 {

    /* renamed from: a */
    ViewGroup f3443a;

    /* renamed from: b */
    View f3444b;

    /* renamed from: c */
    private Object f3445c;

    /* renamed from: d */
    private Object f3446d;

    /* renamed from: e */
    private Object f3447e;

    /* renamed from: f */
    private Object f3448f;

    /* renamed from: g */
    private final BrowseFrameLayout.C0740b f3449g = new C0804a();

    /* renamed from: androidx.leanback.widget.g1$a */
    class C0804a implements BrowseFrameLayout.C0740b {
        C0804a() {
        }

        /* renamed from: a */
        public View mo3111a(View view, int i) {
            View view2 = C0803g1.this.f3444b;
            if (view != view2 && i == 33) {
                return view2;
            }
            int i2 = C4761m.f17241f;
            boolean z = true;
            if (view.getLayoutDirection() != 1) {
                z = false;
            }
            int i3 = z ? 17 : 66;
            if (!C0803g1.this.f3444b.hasFocus()) {
                return null;
            }
            if (i == 130 || i == i3) {
                return C0803g1.this.f3443a;
            }
            return null;
        }
    }

    public C0803g1(ViewGroup viewGroup, View view) {
        if (viewGroup == null || view == null) {
            throw new IllegalArgumentException("Views may not be null");
        }
        this.f3443a = viewGroup;
        this.f3444b = view;
        this.f3445c = C0729a.m3172d(viewGroup.getContext(), R.transition.lb_title_out);
        this.f3446d = C0729a.m3172d(this.f3443a.getContext(), R.transition.lb_title_in);
        this.f3447e = C0729a.m3171c(this.f3443a, new C0807h1(this));
        this.f3448f = C0729a.m3171c(this.f3443a, new C0812i1(this));
    }

    /* renamed from: a */
    public BrowseFrameLayout.C0740b mo3744a() {
        return this.f3449g;
    }

    /* renamed from: b */
    public void mo3745b(boolean z) {
        Object obj;
        Object obj2;
        if (z) {
            obj = this.f3447e;
            obj2 = this.f3446d;
        } else {
            obj = this.f3448f;
            obj2 = this.f3445c;
        }
        C0729a.m3173e(obj, obj2);
    }
}
