package androidx.leanback.widget;

import java.util.ArrayList;
import java.util.HashMap;

/* renamed from: androidx.leanback.widget.h */
public final class C0805h extends C0858q0 {

    /* renamed from: a */
    private final ArrayList<C0844p0> f3451a = new ArrayList<>();

    /* renamed from: b */
    private final HashMap<Class<?>, Object> f3452b = new HashMap<>();

    /* renamed from: a */
    public C0844p0 mo3140a(Object obj) {
        Object obj2;
        C0844p0 a;
        Class cls = obj.getClass();
        do {
            obj2 = this.f3452b.get(cls);
            if (!(obj2 instanceof C0858q0) || (a = ((C0858q0) obj2).mo3140a(obj)) == null) {
                cls = cls.getSuperclass();
                if (obj2 != null) {
                    break;
                }
            } else {
                return a;
            }
        } while (cls != null);
        return (C0844p0) obj2;
    }

    /* renamed from: b */
    public C0844p0[] mo3141b() {
        ArrayList<C0844p0> arrayList = this.f3451a;
        return (C0844p0[]) arrayList.toArray(new C0844p0[arrayList.size()]);
    }

    /* renamed from: c */
    public C0805h mo3746c(Class<?> cls, C0844p0 p0Var) {
        this.f3452b.put(cls, p0Var);
        if (!this.f3451a.contains(p0Var)) {
            this.f3451a.add(p0Var);
        }
        return this;
    }
}
