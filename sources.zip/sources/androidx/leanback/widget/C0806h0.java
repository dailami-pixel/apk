package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.h0 */
public interface C0806h0 extends C0798f<C0864t0> {
}
