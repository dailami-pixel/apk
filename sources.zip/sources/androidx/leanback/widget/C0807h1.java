package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.h1 */
class C0807h1 implements Runnable {

    /* renamed from: a */
    final /* synthetic */ C0803g1 f3453a;

    C0807h1(C0803g1 g1Var) {
        this.f3453a = g1Var;
    }

    public void run() {
        this.f3453a.f3444b.setVisibility(0);
    }
}
