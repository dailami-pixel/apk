package androidx.leanback.widget;

import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.leanback.widget.C0844p0;
import com.vidio.android.p195tv.R;
import java.util.Objects;

/* renamed from: androidx.leanback.widget.i */
public class C0808i extends C0858q0 {

    /* renamed from: a */
    private final C0844p0 f3454a;

    /* renamed from: b */
    private final C0844p0[] f3455b;

    /* renamed from: androidx.leanback.widget.i$a */
    static class C0809a extends C0844p0.C0845a {

        /* renamed from: b */
        ImageView f3456b;

        /* renamed from: c */
        TextView f3457c;

        /* renamed from: d */
        View f3458d;

        public C0809a(View view) {
            super(view);
            this.f3456b = (ImageView) view.findViewById(R.id.icon);
            this.f3457c = (TextView) view.findViewById(R.id.label);
            this.f3458d = view.findViewById(R.id.button);
        }
    }

    /* renamed from: androidx.leanback.widget.i$b */
    static class C0810b extends C0844p0 {
        C0810b(int i) {
        }

        /* renamed from: b */
        public void mo3748b(C0844p0.C0845a aVar, Object obj) {
            C0809a aVar2 = (C0809a) aVar;
            ImageView imageView = aVar2.f3456b;
            Objects.requireNonNull((C0766a) obj);
            imageView.setImageDrawable((Drawable) null);
            TextView textView = aVar2.f3457c;
            if (textView != null) {
                textView.setText((CharSequence) null);
            }
            boolean isEmpty = TextUtils.isEmpty((CharSequence) null);
            if (!TextUtils.equals(aVar2.f3458d.getContentDescription(), (CharSequence) null)) {
                aVar2.f3458d.setContentDescription((CharSequence) null);
                aVar2.f3458d.sendAccessibilityEvent(32768);
            }
        }

        /* renamed from: d */
        public C0844p0.C0845a mo3749d(ViewGroup viewGroup) {
            return new C0809a(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.lb_control_button_primary, viewGroup, false));
        }

        /* renamed from: e */
        public void mo3750e(C0844p0.C0845a aVar) {
            C0809a aVar2 = (C0809a) aVar;
            aVar2.f3456b.setImageDrawable((Drawable) null);
            TextView textView = aVar2.f3457c;
            if (textView != null) {
                textView.setText((CharSequence) null);
            }
            aVar2.f3458d.setContentDescription((CharSequence) null);
        }
    }

    public C0808i() {
        C0810b bVar = new C0810b(R.layout.lb_control_button_primary);
        this.f3454a = bVar;
        this.f3455b = new C0844p0[]{bVar};
    }

    /* renamed from: a */
    public C0844p0 mo3140a(Object obj) {
        return this.f3454a;
    }

    /* renamed from: b */
    public C0844p0[] mo3141b() {
        return this.f3455b;
    }
}
