package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.i0 */
public interface C0811i0 extends C0801g<C0864t0> {
}
