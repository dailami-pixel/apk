package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.i1 */
class C0812i1 implements Runnable {

    /* renamed from: a */
    final /* synthetic */ C0803g1 f3459a;

    C0812i1(C0803g1 g1Var) {
        this.f3459a = g1Var;
    }

    public void run() {
        this.f3459a.f3444b.setVisibility(4);
    }
}
