package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.j */
public abstract class C0813j<Value> {
    /* renamed from: a */
    public abstract boolean mo3752a(Value value, Value value2);

    /* renamed from: b */
    public abstract boolean mo3753b(Value value, Value value2);
}
