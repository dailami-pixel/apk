package androidx.leanback.widget;

import android.util.Property;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/* renamed from: androidx.leanback.widget.j0 */
public abstract class C0814j0<PropertyT extends Property> {

    /* renamed from: a */
    final List<PropertyT> f3460a;

    /* renamed from: b */
    final List<PropertyT> f3461b;

    /* renamed from: c */
    private int[] f3462c = new int[4];

    /* renamed from: d */
    private float[] f3463d = new float[4];

    /* renamed from: e */
    private final List<C0818k0> f3464e = new ArrayList(4);

    public C0814j0() {
        ArrayList arrayList = new ArrayList();
        this.f3460a = arrayList;
        this.f3461b = Collections.unmodifiableList(arrayList);
    }

    /* renamed from: a */
    public void mo3754a() {
        for (int i = 0; i < this.f3464e.size(); i++) {
            C0818k0 k0Var = this.f3464e.get(i);
            if (k0Var.f3465a.size() >= 2) {
                mo3755b();
                boolean z = false;
                for (int i2 = 0; i2 < k0Var.f3466b.size(); i2++) {
                    Objects.requireNonNull(k0Var.f3466b.get(i2));
                    if (!z) {
                        k0Var.mo3756a(this);
                        z = true;
                    }
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public final void mo3755b() throws IllegalStateException {
        if (this.f3460a.size() >= 2) {
            float f = this.f3463d[0];
            int i = 1;
            while (i < this.f3460a.size()) {
                float f2 = this.f3463d[i];
                if (f2 < f) {
                    int i2 = i - 1;
                    throw new IllegalStateException(String.format("Parallax Property[%d]\"%s\" is smaller than Property[%d]\"%s\"", new Object[]{Integer.valueOf(i), ((Property) this.f3460a.get(i)).getName(), Integer.valueOf(i2), ((Property) this.f3460a.get(i2)).getName()}));
                } else if (f == -3.4028235E38f && f2 == Float.MAX_VALUE) {
                    int i3 = i - 1;
                    throw new IllegalStateException(String.format("Parallax Property[%d]\"%s\" is UNKNOWN_BEFORE and Property[%d]\"%s\" is UNKNOWN_AFTER", new Object[]{Integer.valueOf(i3), ((Property) this.f3460a.get(i3)).getName(), Integer.valueOf(i), ((Property) this.f3460a.get(i)).getName()}));
                } else {
                    i++;
                    f = f2;
                }
            }
        }
    }
}
