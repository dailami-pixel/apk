package androidx.leanback.widget;

import android.graphics.drawable.Drawable;
import android.view.View;

/* renamed from: androidx.leanback.widget.j1 */
public abstract class C0815j1 {

    /* renamed from: androidx.leanback.widget.j1$a */
    public interface C0816a {
        /* renamed from: a */
        C0815j1 mo3592a();
    }

    /* renamed from: a */
    public abstract View mo3599a();

    /* renamed from: b */
    public abstract void mo3600b(boolean z);

    /* renamed from: c */
    public abstract void mo3601c(Drawable drawable);

    /* renamed from: d */
    public abstract void mo3602d(View.OnClickListener onClickListener);

    /* renamed from: e */
    public abstract void mo3603e(CharSequence charSequence);

    /* renamed from: f */
    public abstract void mo3604f(int i);
}
