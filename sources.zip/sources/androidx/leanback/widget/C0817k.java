package androidx.leanback.widget;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.leanback.widget.C0844p0;
import com.vidio.android.p195tv.R;

/* renamed from: androidx.leanback.widget.k */
public class C0817k extends C0844p0 {
    /* renamed from: b */
    public void mo3748b(C0844p0.C0845a aVar, Object obj) {
    }

    /* renamed from: d */
    public C0844p0.C0845a mo3749d(ViewGroup viewGroup) {
        return new C0844p0.C0845a(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.lb_divider, viewGroup, false));
    }

    /* renamed from: e */
    public void mo3750e(C0844p0.C0845a aVar) {
    }
}
