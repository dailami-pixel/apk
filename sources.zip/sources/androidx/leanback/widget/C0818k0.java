package androidx.leanback.widget;

import java.util.ArrayList;
import java.util.List;

/* renamed from: androidx.leanback.widget.k0 */
public abstract class C0818k0 {

    /* renamed from: a */
    final List<?> f3465a = new ArrayList(2);

    /* renamed from: b */
    final List<C0825l0> f3466b;

    C0818k0() {
        new ArrayList(2);
        new ArrayList(2);
        this.f3466b = new ArrayList(4);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public abstract float mo3756a(C0814j0 j0Var);
}
