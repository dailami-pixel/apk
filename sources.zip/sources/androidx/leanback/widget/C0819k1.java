package androidx.leanback.widget;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.leanback.widget.C0839p;
import androidx.leanback.widget.C0844p0;
import androidx.leanback.widget.C0870v0;
import androidx.leanback.widget.C0878y;
import androidx.leanback.widget.C0888z0;
import androidx.recyclerview.widget.RecyclerView;
import com.vidio.android.p195tv.R;
import p098d.p140l.p144f.C4841a;

/* renamed from: androidx.leanback.widget.k1 */
public class C0819k1 extends C0844p0 {

    /* renamed from: b */
    private int f3467b = -1;

    /* renamed from: c */
    private int f3468c;

    /* renamed from: d */
    private boolean f3469d;

    /* renamed from: e */
    private boolean f3470e = true;

    /* renamed from: f */
    private boolean f3471f = true;

    /* renamed from: g */
    private C0811i0 f3472g;

    /* renamed from: h */
    private C0806h0 f3473h;

    /* renamed from: i */
    private boolean f3474i = true;

    /* renamed from: j */
    C0888z0 f3475j;

    /* renamed from: k */
    private C0878y.C0883e f3476k;

    /* renamed from: androidx.leanback.widget.k1$a */
    class C0820a implements C0799f0 {

        /* renamed from: a */
        final /* synthetic */ C0823c f3477a;

        C0820a(C0823c cVar) {
            this.f3477a = cVar;
        }

        /* renamed from: a */
        public void mo3642a(ViewGroup viewGroup, View view, int i, long j) {
            C0819k1.this.mo3760l(this.f3477a, view);
        }
    }

    /* renamed from: androidx.leanback.widget.k1$b */
    class C0821b extends C0878y {

        /* renamed from: androidx.leanback.widget.k1$b$a */
        class C0822a implements View.OnClickListener {

            /* renamed from: a */
            final /* synthetic */ C0878y.C0882d f3480a;

            C0822a(C0878y.C0882d dVar) {
                this.f3480a = dVar;
            }

            public void onClick(View view) {
                if (C0819k1.this.mo3757i() != null) {
                    C0806h0 i = C0819k1.this.mo3757i();
                    C0878y.C0882d dVar = this.f3480a;
                    i.mo3184a(dVar.f3656b, dVar.f3658d, (C0870v0.C0872b) null, null);
                }
            }
        }

        C0821b() {
        }

        /* renamed from: e */
        public void mo3644e(C0878y.C0882d dVar) {
            dVar.itemView.setActivated(true);
        }

        /* renamed from: f */
        public void mo3645f(C0878y.C0882d dVar) {
            if (C0819k1.this.mo3757i() != null) {
                dVar.f3656b.f3529a.setOnClickListener(new C0822a(dVar));
            }
        }

        /* access modifiers changed from: protected */
        /* renamed from: g */
        public void mo3646g(C0878y.C0882d dVar) {
            View view = dVar.itemView;
            if (view instanceof ViewGroup) {
                ((ViewGroup) view).setTransitionGroup(true);
            }
            C0888z0 z0Var = C0819k1.this.f3475j;
            if (z0Var != null) {
                z0Var.mo3907a(dVar.itemView);
            }
        }

        /* renamed from: h */
        public void mo3647h(C0878y.C0882d dVar) {
            if (C0819k1.this.mo3757i() != null) {
                dVar.f3656b.f3529a.setOnClickListener((View.OnClickListener) null);
            }
        }
    }

    /* renamed from: androidx.leanback.widget.k1$c */
    public static class C0823c extends C0844p0.C0845a {

        /* renamed from: b */
        C0878y f3482b;

        /* renamed from: c */
        final VerticalGridView f3483c;

        /* renamed from: d */
        boolean f3484d;

        public C0823c(VerticalGridView verticalGridView) {
            super(verticalGridView);
            this.f3483c = verticalGridView;
        }

        /* renamed from: s */
        public VerticalGridView mo3766s() {
            return this.f3483c;
        }
    }

    public C0819k1(int i, boolean z) {
        this.f3468c = i;
        this.f3469d = z;
    }

    /* renamed from: b */
    public void mo3748b(C0844p0.C0845a aVar, Object obj) {
        C0823c cVar = (C0823c) aVar;
        cVar.f3482b.mo3891i((C0781c0) obj);
        cVar.f3483c.setAdapter(cVar.f3482b);
    }

    /* renamed from: e */
    public void mo3750e(C0844p0.C0845a aVar) {
        C0823c cVar = (C0823c) aVar;
        cVar.f3482b.mo3891i((C0781c0) null);
        cVar.f3483c.setAdapter((RecyclerView.C1147g) null);
    }

    /* renamed from: i */
    public final C0806h0 mo3757i() {
        return this.f3473h;
    }

    /* access modifiers changed from: protected */
    /* renamed from: j */
    public void mo3758j(C0823c cVar) {
        int i = this.f3467b;
        if (i != -1) {
            VerticalGridView verticalGridView = cVar.f3483c;
            verticalGridView.f3425a.mo3423y2(i);
            verticalGridView.requestLayout();
            boolean z = true;
            cVar.f3484d = true;
            Context context = cVar.f3483c.getContext();
            if (this.f3475j == null) {
                C0888z0.C0889a aVar = new C0888z0.C0889a();
                aVar.mo3910c(this.f3469d);
                aVar.mo3912e(this.f3470e);
                aVar.mo3911d(this.f3474i);
                aVar.mo3914g(!C4841a.m17684a(context).mo22117c());
                aVar.mo3909b(this.f3471f);
                aVar.mo3913f(C0888z0.C0890b.f3680a);
                C0888z0 a = aVar.mo3908a(context);
                this.f3475j = a;
                if (a.f3670e) {
                    this.f3476k = new C0887z(a);
                }
            }
            cVar.f3482b.f3646b = this.f3476k;
            C0888z0 z0Var = this.f3475j;
            VerticalGridView verticalGridView2 = cVar.f3483c;
            if (z0Var.f3666a == 2) {
                verticalGridView2.setLayoutMode(1);
            }
            VerticalGridView verticalGridView3 = cVar.f3483c;
            if (this.f3475j.f3666a == 3) {
                z = false;
            }
            verticalGridView3.mo3716i(z);
            cVar.f3482b.f3648d = new C0839p.C0840a(this.f3468c, this.f3469d);
            VerticalGridView verticalGridView4 = cVar.f3483c;
            verticalGridView4.f3425a.mo3426z2(new C0820a(cVar));
            return;
        }
        throw new IllegalStateException("Number of columns must be set");
    }

    /* renamed from: k */
    public final C0823c mo3749d(ViewGroup viewGroup) {
        C0823c cVar = new C0823c((VerticalGridView) LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.lb_vertical_grid, viewGroup, false).findViewById(R.id.browse_grid));
        cVar.f3484d = false;
        cVar.f3482b = new C0821b();
        mo3758j(cVar);
        if (cVar.f3484d) {
            return cVar;
        }
        throw new RuntimeException("super.initializeGridViewHolder() must be called");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l */
    public void mo3760l(C0823c cVar, View view) {
        C0878y.C0882d dVar;
        if (this.f3472g != null) {
            if (view == null) {
                dVar = null;
            } else {
                dVar = (C0878y.C0882d) cVar.f3483c.getChildViewHolder(view);
            }
            if (dVar == null) {
                this.f3472g.mo3132a((C0844p0.C0845a) null, (Object) null, (C0870v0.C0872b) null, null);
            } else {
                this.f3472g.mo3132a(dVar.f3656b, dVar.f3658d, (C0870v0.C0872b) null, null);
            }
        }
    }

    /* renamed from: m */
    public void mo3761m(C0823c cVar, boolean z) {
        cVar.f3483c.mo3714h(z ? 0 : 4);
    }

    /* renamed from: n */
    public void mo3762n(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("Invalid number of columns");
        } else if (this.f3467b != i) {
            this.f3467b = i;
        }
    }

    /* renamed from: o */
    public final void mo3763o(C0806h0 h0Var) {
        this.f3473h = h0Var;
    }

    /* renamed from: p */
    public final void mo3764p(C0811i0 i0Var) {
        this.f3472g = i0Var;
    }
}
