package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.l */
public class C0824l extends C0864t0 {
}
