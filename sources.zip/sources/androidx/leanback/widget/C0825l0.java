package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.l0 */
public abstract class C0825l0 {
}
