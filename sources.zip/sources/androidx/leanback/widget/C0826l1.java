package androidx.leanback.widget;

import androidx.recyclerview.widget.RecyclerView;

/* renamed from: androidx.leanback.widget.l1 */
public interface C0826l1 {
    /* renamed from: a */
    void mo3220a(RecyclerView.C1142b0 b0Var);
}
