package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.m */
public interface C0827m {
    /* renamed from: c */
    Object mo3767c(Class<?> cls);
}
