package androidx.leanback.widget;

import java.util.Objects;

/* renamed from: androidx.leanback.widget.m0 */
public class C0828m0 extends C0864t0 {

    /* renamed from: d */
    private Object f3485d;

    /* renamed from: e */
    private C0781c0 f3486e;

    /* renamed from: f */
    private C0781c0 f3487f;

    /* renamed from: g */
    private long f3488g;

    /* renamed from: h */
    private long f3489h;

    /* renamed from: i */
    private long f3490i;

    /* renamed from: j */
    private C0829a f3491j;

    /* renamed from: androidx.leanback.widget.m0$a */
    public static class C0829a {
        /* renamed from: a */
        public void mo3777a(C0828m0 m0Var, long j) {
            throw null;
        }

        /* renamed from: b */
        public void mo3778b(C0828m0 m0Var, long j) {
            throw null;
        }
    }

    public C0828m0() {
    }

    public C0828m0(Object obj) {
        this.f3485d = obj;
    }

    /* renamed from: f */
    public final Object mo3768f() {
        return this.f3485d;
    }

    /* renamed from: g */
    public final C0781c0 mo3769g() {
        return this.f3486e;
    }

    /* renamed from: h */
    public final C0781c0 mo3770h() {
        return this.f3487f;
    }

    /* renamed from: i */
    public void mo3771i(long j) {
        if (this.f3490i != j) {
            this.f3490i = j;
            C0829a aVar = this.f3491j;
            if (aVar != null) {
                Objects.requireNonNull(aVar);
            }
        }
    }

    /* renamed from: j */
    public void mo3772j(long j) {
        if (this.f3489h != j) {
            this.f3489h = j;
            C0829a aVar = this.f3491j;
            if (aVar != null) {
                aVar.mo3777a(this, j);
            }
        }
    }

    /* renamed from: k */
    public void mo3773k(long j) {
        if (this.f3488g != j) {
            this.f3488g = j;
            C0829a aVar = this.f3491j;
            if (aVar != null) {
                aVar.mo3778b(this, j);
            }
        }
    }

    /* renamed from: l */
    public void mo3774l(C0829a aVar) {
        this.f3491j = aVar;
    }

    /* renamed from: m */
    public final void mo3775m(C0781c0 c0Var) {
        this.f3486e = c0Var;
    }

    /* renamed from: n */
    public final void mo3776n(C0781c0 c0Var) {
        this.f3487f = c0Var;
    }
}
