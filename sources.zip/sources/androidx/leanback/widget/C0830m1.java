package androidx.leanback.widget;

import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.View;
import com.google.android.gms.common.api.C4291a;
import java.util.Map;
import p098d.p112d.C4624h;

/* renamed from: androidx.leanback.widget.m1 */
class C0830m1 {

    /* renamed from: a */
    private int f3492a = 0;

    /* renamed from: b */
    private C4624h<String, SparseArray<Parcelable>> f3493b;

    /* renamed from: a */
    public void mo3779a() {
        C4624h<String, SparseArray<Parcelable>> hVar = this.f3493b;
        if (hVar != null) {
            hVar.evictAll();
        }
    }

    /* renamed from: b */
    public final void mo3780b(Bundle bundle) {
        C4624h<String, SparseArray<Parcelable>> hVar = this.f3493b;
        if (hVar != null && bundle != null) {
            hVar.evictAll();
            for (String str : bundle.keySet()) {
                this.f3493b.put(str, bundle.getSparseParcelableArray(str));
            }
        }
    }

    /* renamed from: c */
    public final void mo3781c(View view, int i) {
        SparseArray remove;
        if (this.f3493b != null && (remove = this.f3493b.remove(Integer.toString(i))) != null) {
            view.restoreHierarchyState(remove);
        }
    }

    /* renamed from: d */
    public void mo3782d(int i) {
        C4624h<String, SparseArray<Parcelable>> hVar = this.f3493b;
        if (hVar != null && hVar.size() != 0) {
            this.f3493b.remove(Integer.toString(i));
        }
    }

    /* renamed from: e */
    public final Bundle mo3783e() {
        C4624h<String, SparseArray<Parcelable>> hVar = this.f3493b;
        if (hVar == null || hVar.size() == 0) {
            return null;
        }
        Map<String, SparseArray<Parcelable>> snapshot = this.f3493b.snapshot();
        Bundle bundle = new Bundle();
        for (Map.Entry next : snapshot.entrySet()) {
            bundle.putSparseParcelableArray((String) next.getKey(), (SparseArray) next.getValue());
        }
        return bundle;
    }

    /* renamed from: f */
    public final void mo3784f(View view, int i) {
        int i2 = this.f3492a;
        if (i2 == 1) {
            C4624h<String, SparseArray<Parcelable>> hVar = this.f3493b;
            if (hVar != null && hVar.size() != 0) {
                this.f3493b.remove(Integer.toString(i));
            }
        } else if ((i2 == 2 || i2 == 3) && this.f3493b != null) {
            String num = Integer.toString(i);
            SparseArray sparseArray = new SparseArray();
            view.saveHierarchyState(sparseArray);
            this.f3493b.put(num, sparseArray);
        }
    }

    /* renamed from: g */
    public final Bundle mo3785g(Bundle bundle, View view, int i) {
        if (this.f3492a != 0) {
            String num = Integer.toString(i);
            SparseArray sparseArray = new SparseArray();
            view.saveHierarchyState(sparseArray);
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putSparseParcelableArray(num, sparseArray);
        }
        return bundle;
    }

    /* renamed from: h */
    public final void mo3786h(int i) {
        C4624h<String, SparseArray<Parcelable>> hVar;
        this.f3492a = i;
        if (i == 2) {
            C4624h<String, SparseArray<Parcelable>> hVar2 = this.f3493b;
            if (hVar2 == null || hVar2.maxSize() != 100) {
                hVar = new C4624h<>(100);
            } else {
                return;
            }
        } else if (i == 3 || i == 1) {
            C4624h<String, SparseArray<Parcelable>> hVar3 = this.f3493b;
            if (hVar3 == null || hVar3.maxSize() != Integer.MAX_VALUE) {
                hVar = new C4624h<>(C4291a.C4299e.API_PRIORITY_OTHER);
            } else {
                return;
            }
        } else {
            hVar = null;
        }
        this.f3493b = hVar;
    }
}
