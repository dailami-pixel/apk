package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.n */
public interface C0831n {
    /* renamed from: a */
    C0827m mo3787a(int i);
}
