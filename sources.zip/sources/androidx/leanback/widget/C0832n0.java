package androidx.leanback.widget;

import android.view.View;
import androidx.leanback.widget.C0870v0;

/* renamed from: androidx.leanback.widget.n0 */
public abstract class C0832n0 extends C0870v0 {

    /* renamed from: androidx.leanback.widget.n0$a */
    public static class C0833a extends C0870v0.C0872b {
        public C0833a(View view) {
            super(view);
        }
    }
}
