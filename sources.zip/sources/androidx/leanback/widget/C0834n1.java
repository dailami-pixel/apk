package androidx.leanback.widget;

import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.common.api.C4291a;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.leanback.widget.n1 */
class C0834n1 {

    /* renamed from: a */
    private int f3494a = 0;

    /* renamed from: b */
    public final C0835a f3495b;

    /* renamed from: c */
    public final C0835a f3496c;

    /* renamed from: d */
    private C0835a f3497d;

    /* renamed from: e */
    private C0835a f3498e;

    /* renamed from: androidx.leanback.widget.n1$a */
    public static class C0835a {

        /* renamed from: a */
        private int f3499a = C4291a.C4299e.API_PRIORITY_OTHER;

        /* renamed from: b */
        private int f3500b = RecyclerView.UNDEFINED_DURATION;

        /* renamed from: c */
        private int f3501c;

        /* renamed from: d */
        private int f3502d;

        /* renamed from: e */
        private int f3503e = 3;

        /* renamed from: f */
        private int f3504f = 0;

        /* renamed from: g */
        private float f3505g = 50.0f;

        /* renamed from: h */
        private int f3506h;

        /* renamed from: i */
        private int f3507i;

        /* renamed from: j */
        private int f3508j;

        /* renamed from: k */
        private boolean f3509k;

        public C0835a(String str) {
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public final int mo3793a() {
            if (!this.f3509k) {
                int i = this.f3504f;
                if (i < 0) {
                    i += this.f3506h;
                }
                float f = this.f3505g;
                return f != -1.0f ? i + ((int) ((((float) this.f3506h) * f) / 100.0f)) : i;
            }
            int i2 = this.f3504f;
            int i3 = i2 >= 0 ? this.f3506h - i2 : -i2;
            float f2 = this.f3505g;
            return f2 != -1.0f ? i3 - ((int) ((((float) this.f3506h) * f2) / 100.0f)) : i3;
        }

        /* renamed from: b */
        public final int mo3794b() {
            return (this.f3506h - this.f3507i) - this.f3508j;
        }

        /* renamed from: c */
        public final int mo3795c() {
            return this.f3501c;
        }

        /* renamed from: d */
        public final int mo3796d() {
            return this.f3502d;
        }

        /* renamed from: e */
        public final int mo3797e() {
            return this.f3508j;
        }

        /* renamed from: f */
        public final int mo3798f() {
            return this.f3507i;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:12:0x002e, code lost:
            r9 = r8.f3501c;
         */
        /* renamed from: g */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final int mo3799g(int r9) {
            /*
                r8 = this;
                int r0 = r8.f3506h
                int r1 = r8.mo3793a()
                boolean r2 = r8.mo3804l()
                boolean r3 = r8.mo3803k()
                if (r2 != 0) goto L_0x0034
                int r4 = r8.f3507i
                int r5 = r1 - r4
                boolean r6 = r8.f3509k
                if (r6 != 0) goto L_0x001f
                int r6 = r8.f3503e
                r6 = r6 & 1
                if (r6 == 0) goto L_0x0034
                goto L_0x0025
            L_0x001f:
                int r6 = r8.f3503e
                r6 = r6 & 2
                if (r6 == 0) goto L_0x0034
            L_0x0025:
                int r6 = r8.f3500b
                int r7 = r9 - r6
                if (r7 > r5) goto L_0x0034
                int r6 = r6 - r4
                if (r3 != 0) goto L_0x0033
                int r9 = r8.f3501c
                if (r6 <= r9) goto L_0x0033
                r6 = r9
            L_0x0033:
                return r6
            L_0x0034:
                if (r3 != 0) goto L_0x005c
                int r3 = r0 - r1
                int r4 = r8.f3508j
                int r3 = r3 - r4
                boolean r5 = r8.f3509k
                if (r5 != 0) goto L_0x0046
                int r5 = r8.f3503e
                r5 = r5 & 2
                if (r5 == 0) goto L_0x005c
                goto L_0x004c
            L_0x0046:
                int r5 = r8.f3503e
                r5 = r5 & 1
                if (r5 == 0) goto L_0x005c
            L_0x004c:
                int r5 = r8.f3499a
                int r6 = r5 - r9
                if (r6 > r3) goto L_0x005c
                int r0 = r0 - r4
                int r5 = r5 - r0
                if (r2 != 0) goto L_0x005b
                int r9 = r8.f3502d
                if (r5 >= r9) goto L_0x005b
                r5 = r9
            L_0x005b:
                return r5
            L_0x005c:
                int r9 = r9 - r1
                return r9
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.C0834n1.C0835a.mo3799g(int):int");
        }

        /* renamed from: h */
        public final int mo3800h() {
            return this.f3506h;
        }

        /* renamed from: i */
        public final void mo3801i() {
            this.f3499a = C4291a.C4299e.API_PRIORITY_OTHER;
            this.f3501c = C4291a.C4299e.API_PRIORITY_OTHER;
        }

        /* renamed from: j */
        public final void mo3802j() {
            this.f3500b = RecyclerView.UNDEFINED_DURATION;
            this.f3502d = RecyclerView.UNDEFINED_DURATION;
        }

        /* renamed from: k */
        public final boolean mo3803k() {
            return this.f3499a == Integer.MAX_VALUE;
        }

        /* renamed from: l */
        public final boolean mo3804l() {
            return this.f3500b == Integer.MIN_VALUE;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: m */
        public void mo3805m() {
            this.f3500b = RecyclerView.UNDEFINED_DURATION;
            this.f3499a = C4291a.C4299e.API_PRIORITY_OTHER;
        }

        /* renamed from: n */
        public final void mo3806n(int i, int i2) {
            this.f3507i = i;
            this.f3508j = i2;
        }

        /* renamed from: o */
        public final void mo3807o(boolean z) {
            this.f3509k = z;
        }

        /* renamed from: p */
        public final void mo3808p(int i) {
            this.f3506h = i;
        }

        /* renamed from: q */
        public final void mo3809q(int i) {
            this.f3503e = i;
        }

        /* renamed from: r */
        public final void mo3810r(int i) {
            this.f3504f = i;
        }

        /* renamed from: s */
        public final void mo3811s(float f) {
            if ((f < 0.0f || f > 100.0f) && f != -1.0f) {
                throw new IllegalArgumentException();
            }
            this.f3505g = f;
        }

        /* renamed from: t */
        public final void mo3812t(int i, int i2, int i3, int i4) {
            int i5;
            int min;
            this.f3500b = i;
            this.f3499a = i2;
            int b = mo3794b();
            int a = mo3793a();
            boolean l = mo3804l();
            boolean k = mo3803k();
            if (!l) {
                this.f3502d = (this.f3509k ? (this.f3503e & 2) == 0 : (this.f3503e & 1) == 0) ? i3 - a : this.f3500b - this.f3507i;
            }
            if (!k) {
                if (this.f3509k ? (this.f3503e & 1) == 0 : (this.f3503e & 2) == 0) {
                    this.f3501c = i4 - a;
                } else {
                    this.f3501c = (this.f3499a - this.f3507i) - b;
                }
            }
            if (!k && !l) {
                if (!this.f3509k) {
                    int i6 = this.f3503e;
                    if ((i6 & 1) != 0) {
                        min = this.f3502d;
                    } else if ((i6 & 2) != 0) {
                        int max = Math.max(this.f3501c, i3 - a);
                        this.f3501c = max;
                        i5 = Math.min(this.f3502d, max);
                        this.f3502d = i5;
                        return;
                    } else {
                        return;
                    }
                } else {
                    int i7 = this.f3503e;
                    if ((i7 & 1) != 0) {
                        i5 = Math.min(this.f3502d, this.f3501c);
                        this.f3502d = i5;
                        return;
                    } else if ((i7 & 2) != 0) {
                        min = Math.min(this.f3502d, i4 - a);
                        this.f3502d = min;
                    } else {
                        return;
                    }
                }
                this.f3501c = Math.max(min, this.f3501c);
            }
        }

        public String toString() {
            StringBuilder P = C4924a.m17863P(" min:");
            P.append(this.f3500b);
            P.append(" ");
            P.append(this.f3502d);
            P.append(" max:");
            P.append(this.f3499a);
            P.append(" ");
            P.append(this.f3501c);
            return P.toString();
        }
    }

    C0834n1() {
        C0835a aVar = new C0835a("vertical");
        this.f3495b = aVar;
        C0835a aVar2 = new C0835a("horizontal");
        this.f3496c = aVar2;
        this.f3497d = aVar2;
        this.f3498e = aVar;
    }

    /* renamed from: a */
    public final C0835a mo3788a() {
        return this.f3497d;
    }

    /* renamed from: b */
    public final void mo3789b() {
        this.f3497d.mo3805m();
    }

    /* renamed from: c */
    public final C0835a mo3790c() {
        return this.f3498e;
    }

    /* renamed from: d */
    public final void mo3791d(int i) {
        C0835a aVar;
        this.f3494a = i;
        if (i == 0) {
            this.f3497d = this.f3496c;
            aVar = this.f3495b;
        } else {
            this.f3497d = this.f3495b;
            aVar = this.f3496c;
        }
        this.f3498e = aVar;
    }

    public String toString() {
        StringBuilder P = C4924a.m17863P("horizontal=");
        P.append(this.f3496c);
        P.append("; vertical=");
        P.append(this.f3495b);
        return P.toString();
    }
}
