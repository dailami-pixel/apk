package androidx.leanback.widget;

import android.view.View;

/* renamed from: androidx.leanback.widget.o */
interface C0836o {
    /* renamed from: a */
    void mo3814a(View view, boolean z);

    /* renamed from: b */
    void mo3815b(View view);
}
