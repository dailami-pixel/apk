package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.o0 */
public interface C0837o0 {

    /* renamed from: androidx.leanback.widget.o0$a */
    public static class C0838a {
    }

    /* renamed from: b */
    void mo3195b(C0838a aVar);
}
