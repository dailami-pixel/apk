package androidx.leanback.widget;

import android.animation.TimeAnimator;
import android.content.res.Resources;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.ViewParent;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.leanback.widget.C0866u0;
import androidx.leanback.widget.C0878y;
import androidx.leanback.widget.C0884y0;
import androidx.recyclerview.widget.RecyclerView;
import com.vidio.android.p195tv.R;
import java.util.Objects;
import p098d.p140l.p142d.C4828a;

/* renamed from: androidx.leanback.widget.p */
public class C0839p {

    /* renamed from: a */
    private static SparseArray<ViewOutlineProvider> f3510a;

    /* renamed from: androidx.leanback.widget.p$a */
    static class C0840a implements C0836o {

        /* renamed from: a */
        private int f3511a;

        /* renamed from: b */
        private final boolean f3512b;

        C0840a(int i, boolean z) {
            if (i == 0 || C0839p.m3627b(i) > 0) {
                this.f3511a = i;
                this.f3512b = z;
                return;
            }
            throw new IllegalArgumentException("Unhandled zoom index");
        }

        /* renamed from: c */
        private C0841b m3630c(View view) {
            C0841b bVar = (C0841b) view.getTag(R.id.lb_focus_animator);
            if (bVar == null) {
                Resources resources = view.getResources();
                int i = this.f3511a;
                bVar = new C0841b(view, i == 0 ? 1.0f : resources.getFraction(C0839p.m3627b(i), 1, 1), this.f3512b, 150);
                view.setTag(R.id.lb_focus_animator, bVar);
            }
            return bVar;
        }

        /* renamed from: a */
        public void mo3814a(View view, boolean z) {
            view.setSelected(z);
            m3630c(view).mo3816a(z, false);
        }

        /* renamed from: b */
        public void mo3815b(View view) {
            m3630c(view).mo3816a(false, true);
        }
    }

    /* renamed from: androidx.leanback.widget.p$b */
    static class C0841b implements TimeAnimator.TimeListener {

        /* renamed from: a */
        private final View f3513a;

        /* renamed from: b */
        private final int f3514b;

        /* renamed from: c */
        private final ShadowOverlayContainer f3515c;

        /* renamed from: d */
        private final float f3516d;

        /* renamed from: e */
        private float f3517e = 0.0f;

        /* renamed from: f */
        private float f3518f;

        /* renamed from: g */
        private float f3519g;

        /* renamed from: h */
        private final TimeAnimator f3520h;

        /* renamed from: i */
        private final Interpolator f3521i;

        /* renamed from: j */
        private final C4828a f3522j;

        C0841b(View view, float f, boolean z, int i) {
            TimeAnimator timeAnimator = new TimeAnimator();
            this.f3520h = timeAnimator;
            this.f3521i = new AccelerateDecelerateInterpolator();
            this.f3513a = view;
            this.f3514b = i;
            this.f3516d = f - 1.0f;
            if (view instanceof ShadowOverlayContainer) {
                this.f3515c = (ShadowOverlayContainer) view;
            } else {
                this.f3515c = null;
            }
            timeAnimator.setTimeListener(this);
            if (z) {
                this.f3522j = C4828a.m17609a(view.getContext());
            } else {
                this.f3522j = null;
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo3816a(boolean z, boolean z2) {
            this.f3520h.end();
            float f = z ? 1.0f : 0.0f;
            if (z2) {
                mo3817b(f);
                return;
            }
            float f2 = this.f3517e;
            if (f2 != f) {
                this.f3518f = f2;
                this.f3519g = f - f2;
                this.f3520h.start();
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo3817b(float f) {
            this.f3517e = f;
            float f2 = (this.f3516d * f) + 1.0f;
            this.f3513a.setScaleX(f2);
            this.f3513a.setScaleY(f2);
            ShadowOverlayContainer shadowOverlayContainer = this.f3515c;
            if (shadowOverlayContainer != null) {
                shadowOverlayContainer.mo3578b(f);
            } else {
                C0888z0.m3786c(this.f3513a.getTag(R.id.lb_shadow_impl), 3, f);
            }
            C4828a aVar = this.f3522j;
            if (aVar != null) {
                aVar.mo22081c(f);
                int color = this.f3522j.mo22080b().getColor();
                ShadowOverlayContainer shadowOverlayContainer2 = this.f3515c;
                if (shadowOverlayContainer2 != null) {
                    shadowOverlayContainer2.mo3577a(color);
                } else {
                    C0888z0.m3785b(this.f3513a, color);
                }
            }
        }

        public void onTimeUpdate(TimeAnimator timeAnimator, long j, long j2) {
            float f;
            int i = this.f3514b;
            if (j >= ((long) i)) {
                f = 1.0f;
                this.f3520h.end();
            } else {
                f = (float) (((double) j) / ((double) i));
            }
            Interpolator interpolator = this.f3521i;
            if (interpolator != null) {
                f = interpolator.getInterpolation(f);
            }
            mo3817b((f * this.f3519g) + this.f3518f);
        }
    }

    /* renamed from: androidx.leanback.widget.p$c */
    static class C0842c implements C0836o {

        /* renamed from: a */
        private boolean f3523a;

        /* renamed from: b */
        private float f3524b;

        /* renamed from: c */
        private int f3525c;

        /* renamed from: d */
        boolean f3526d;

        /* renamed from: androidx.leanback.widget.p$c$a */
        static class C0843a extends C0841b {

            /* renamed from: k */
            C0878y.C0882d f3527k;

            C0843a(View view, float f, int i) {
                super(view, f, false, i);
                ViewParent parent = view.getParent();
                while (parent != null && !(parent instanceof RecyclerView)) {
                    parent = parent.getParent();
                }
                if (parent != null) {
                    this.f3527k = (C0878y.C0882d) ((RecyclerView) parent).getChildViewHolder(view);
                }
            }

            /* access modifiers changed from: package-private */
            /* renamed from: b */
            public void mo3817b(float f) {
                C0878y.C0882d dVar = this.f3527k;
                C0844p0 p0Var = dVar.f3655a;
                if (p0Var instanceof C0866u0) {
                    C0866u0 u0Var = (C0866u0) p0Var;
                    C0866u0.C0867a aVar = (C0866u0.C0867a) dVar.f3656b;
                    Objects.requireNonNull(u0Var);
                    aVar.f3613b = f;
                    u0Var.mo3866j(aVar);
                }
                super.mo3817b(f);
            }
        }

        C0842c(boolean z) {
            this.f3526d = z;
        }

        /* renamed from: a */
        public void mo3814a(View view, boolean z) {
            float f;
            if (!this.f3523a) {
                Resources resources = view.getResources();
                TypedValue typedValue = new TypedValue();
                if (this.f3526d) {
                    resources.getValue(R.dimen.lb_browse_header_select_scale, typedValue, true);
                    f = typedValue.getFloat();
                } else {
                    f = 1.0f;
                }
                this.f3524b = f;
                resources.getValue(R.dimen.lb_browse_header_select_duration, typedValue, true);
                this.f3525c = typedValue.data;
                this.f3523a = true;
            }
            view.setSelected(z);
            C0841b bVar = (C0841b) view.getTag(R.id.lb_focus_animator);
            if (bVar == null) {
                bVar = new C0843a(view, this.f3524b, this.f3525c);
                view.setTag(R.id.lb_focus_animator, bVar);
            }
            bVar.mo3816a(z, false);
        }

        /* renamed from: b */
        public void mo3815b(View view) {
        }
    }

    /* renamed from: a */
    static Object m3626a(View view, float f, float f2, int i) {
        ViewOutlineProvider viewOutlineProvider = C0884y0.f3661a;
        if (i > 0) {
            m3628c(view, true, i);
        } else {
            view.setOutlineProvider(C0884y0.f3661a);
        }
        C0884y0.C0886b bVar = new C0884y0.C0886b();
        bVar.f3662a = view;
        bVar.f3663b = f;
        bVar.f3664c = f2;
        view.setZ(f);
        return bVar;
    }

    /* renamed from: b */
    static int m3627b(int i) {
        if (i == 1) {
            return R.fraction.lb_focus_zoom_factor_small;
        }
        if (i == 2) {
            return R.fraction.lb_focus_zoom_factor_medium;
        }
        if (i == 3) {
            return R.fraction.lb_focus_zoom_factor_large;
        }
        if (i != 4) {
            return 0;
        }
        return R.fraction.lb_focus_zoom_factor_xsmall;
    }

    /* renamed from: c */
    public static void m3628c(View view, boolean z, int i) {
        if (z) {
            if (f3510a == null) {
                f3510a = new SparseArray<>();
            }
            ViewOutlineProvider viewOutlineProvider = f3510a.get(i);
            if (viewOutlineProvider == null) {
                viewOutlineProvider = new C0862s0(i);
                if (f3510a.size() < 32) {
                    f3510a.put(i, viewOutlineProvider);
                }
            }
            view.setOutlineProvider(viewOutlineProvider);
        } else {
            view.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        }
        view.setClipToOutline(z);
    }

    /* renamed from: d */
    public static void m3629d(C0878y yVar) {
        yVar.f3648d = new C0842c(true);
    }
}
