package androidx.leanback.widget;

import android.view.View;
import android.view.ViewGroup;
import java.util.HashMap;
import java.util.Map;

/* renamed from: androidx.leanback.widget.p0 */
public abstract class C0844p0 implements C0827m {

    /* renamed from: a */
    private Map<Class, Object> f3528a;

    /* renamed from: androidx.leanback.widget.p0$a */
    public static class C0845a implements C0827m {

        /* renamed from: a */
        public final View f3529a;

        public C0845a(View view) {
            this.f3529a = view;
        }

        /* renamed from: c */
        public final Object mo3767c(Class<?> cls) {
            return null;
        }
    }

    /* renamed from: androidx.leanback.widget.p0$b */
    public static abstract class C0846b {
        /* renamed from: a */
        public abstract void mo3649a(C0845a aVar);
    }

    /* renamed from: a */
    protected static void m3638a(View view) {
        if (view != null && view.hasTransientState()) {
            view.animate().cancel();
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                int childCount = viewGroup.getChildCount();
                int i = 0;
                while (view.hasTransientState() && i < childCount) {
                    m3638a(viewGroup.getChildAt(i));
                    i++;
                }
            }
        }
    }

    /* renamed from: b */
    public abstract void mo3748b(C0845a aVar, Object obj);

    /* renamed from: c */
    public final Object mo3767c(Class<?> cls) {
        Map<Class, Object> map = this.f3528a;
        if (map == null) {
            return null;
        }
        return map.get(cls);
    }

    /* renamed from: d */
    public abstract C0845a mo3749d(ViewGroup viewGroup);

    /* renamed from: e */
    public abstract void mo3750e(C0845a aVar);

    /* renamed from: f */
    public void mo3819f(C0845a aVar) {
    }

    /* renamed from: g */
    public void mo3820g(C0845a aVar) {
        m3638a(aVar.f3529a);
    }

    /* renamed from: h */
    public final void mo3821h(Class<?> cls, Object obj) {
        if (this.f3528a == null) {
            this.f3528a = new HashMap();
        }
        this.f3528a.put(cls, obj);
    }
}
