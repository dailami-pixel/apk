package androidx.leanback.widget;

import androidx.leanback.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.common.api.C4291a;
import p098d.p112d.C4621e;

/* renamed from: androidx.leanback.widget.q */
abstract class C0855q {

    /* renamed from: a */
    Object[] f3590a = new Object[1];

    /* renamed from: b */
    protected C0857b f3591b;

    /* renamed from: c */
    protected boolean f3592c;

    /* renamed from: d */
    protected int f3593d;

    /* renamed from: e */
    protected int f3594e;

    /* renamed from: f */
    protected int f3595f = -1;

    /* renamed from: g */
    protected int f3596g = -1;

    /* renamed from: h */
    protected C4621e[] f3597h;

    /* renamed from: i */
    protected int f3598i = -1;

    /* renamed from: androidx.leanback.widget.q$a */
    public static class C0856a {

        /* renamed from: a */
        public int f3599a;

        public C0856a(int i) {
            this.f3599a = i;
        }
    }

    /* renamed from: androidx.leanback.widget.q$b */
    public interface C0857b {
    }

    C0855q() {
    }

    /* renamed from: q */
    private void m3678q() {
        if (this.f3596g < this.f3595f) {
            this.f3596g = -1;
            this.f3595f = -1;
        }
    }

    /* renamed from: a */
    public boolean mo3848a() {
        return mo3653b(this.f3592c ? C4291a.C4299e.API_PRIORITY_OTHER : RecyclerView.UNDEFINED_DURATION, true);
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract boolean mo3653b(int i, boolean z);

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x001f A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean mo3849c(int r5) {
        /*
            r4 = this;
            int r0 = r4.f3596g
            r1 = 0
            if (r0 >= 0) goto L_0x0006
            return r1
        L_0x0006:
            boolean r0 = r4.f3592c
            r2 = 0
            r3 = 1
            if (r0 == 0) goto L_0x0016
            int r0 = r4.mo3852i(r3, r2)
            int r2 = r4.f3593d
            int r5 = r5 + r2
            if (r0 > r5) goto L_0x0020
            goto L_0x001f
        L_0x0016:
            int r0 = r4.mo3851g(r1, r2)
            int r2 = r4.f3593d
            int r5 = r5 - r2
            if (r0 < r5) goto L_0x0020
        L_0x001f:
            r1 = 1
        L_0x0020:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.C0855q.mo3849c(int):boolean");
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x001f A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean mo3850d(int r5) {
        /*
            r4 = this;
            int r0 = r4.f3596g
            r1 = 0
            if (r0 >= 0) goto L_0x0006
            return r1
        L_0x0006:
            boolean r0 = r4.f3592c
            r2 = 0
            r3 = 1
            if (r0 == 0) goto L_0x0016
            int r0 = r4.mo3851g(r1, r2)
            int r2 = r4.f3593d
            int r5 = r5 - r2
            if (r0 < r5) goto L_0x0020
            goto L_0x001f
        L_0x0016:
            int r0 = r4.mo3852i(r3, r2)
            int r2 = r4.f3593d
            int r5 = r5 + r2
            if (r0 > r5) goto L_0x0020
        L_0x001f:
            r1 = 1
        L_0x0020:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.C0855q.mo3850d(int):boolean");
    }

    /* renamed from: e */
    public void mo3654e(int i, int i2, RecyclerView.C1158o.C1161c cVar) {
    }

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public abstract int mo3655f(boolean z, int i, int[] iArr);

    /* renamed from: g */
    public final int mo3851g(boolean z, int[] iArr) {
        return mo3655f(z, this.f3592c ? this.f3595f : this.f3596g, iArr);
    }

    /* access modifiers changed from: protected */
    /* renamed from: h */
    public abstract int mo3656h(boolean z, int i, int[] iArr);

    /* renamed from: i */
    public final int mo3852i(boolean z, int[] iArr) {
        return mo3656h(z, this.f3592c ? this.f3596g : this.f3595f, iArr);
    }

    /* renamed from: j */
    public abstract C4621e[] mo3657j(int i, int i2);

    /* renamed from: k */
    public abstract C0856a mo3658k(int i);

    /* renamed from: l */
    public final int mo3853l(int i) {
        C0856a k = mo3658k(i);
        if (k == null) {
            return -1;
        }
        return k.f3599a;
    }

    /* renamed from: m */
    public void mo3690m(int i) {
        int i2;
        if (i >= 0 && (i2 = this.f3596g) >= 0) {
            if (i2 >= i) {
                this.f3596g = i - 1;
            }
            m3678q();
            if (this.f3595f < 0) {
                this.f3598i = i;
            }
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: n */
    public abstract boolean mo3659n(int i, boolean z);

    /* renamed from: o */
    public void mo3854o(int i, int i2) {
        while (true) {
            int i3 = this.f3596g;
            if (i3 < this.f3595f || i3 <= i) {
                break;
            }
            boolean z = false;
            if (this.f3592c ? ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i3) <= i2 : ((GridLayoutManager.C0743b) this.f3591b).mo3444d(i3) >= i2) {
                z = true;
            }
            if (!z) {
                break;
            }
            ((GridLayoutManager.C0743b) this.f3591b).mo3446f(this.f3596g);
            this.f3596g--;
        }
        m3678q();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0021, code lost:
        if ((((androidx.leanback.widget.GridLayoutManager.C0743b) r5.f3591b).mo3444d(r5.f3595f) + r0) <= r7) goto L_0x0031;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x002f, code lost:
        if ((((androidx.leanback.widget.GridLayoutManager.C0743b) r5.f3591b).mo3444d(r5.f3595f) - r0) >= r7) goto L_0x0031;
     */
    /* renamed from: p */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo3855p(int r6, int r7) {
        /*
            r5 = this;
        L_0x0000:
            int r0 = r5.f3596g
            int r1 = r5.f3595f
            if (r0 < r1) goto L_0x0043
            if (r1 >= r6) goto L_0x0043
            androidx.leanback.widget.q$b r0 = r5.f3591b
            androidx.leanback.widget.GridLayoutManager$b r0 = (androidx.leanback.widget.GridLayoutManager.C0743b) r0
            int r0 = r0.mo3445e(r1)
            boolean r1 = r5.f3592c
            r2 = 0
            r3 = 1
            if (r1 != 0) goto L_0x0024
            androidx.leanback.widget.q$b r1 = r5.f3591b
            int r4 = r5.f3595f
            androidx.leanback.widget.GridLayoutManager$b r1 = (androidx.leanback.widget.GridLayoutManager.C0743b) r1
            int r1 = r1.mo3444d(r4)
            int r1 = r1 + r0
            if (r1 > r7) goto L_0x0032
            goto L_0x0031
        L_0x0024:
            androidx.leanback.widget.q$b r1 = r5.f3591b
            int r4 = r5.f3595f
            androidx.leanback.widget.GridLayoutManager$b r1 = (androidx.leanback.widget.GridLayoutManager.C0743b) r1
            int r1 = r1.mo3444d(r4)
            int r1 = r1 - r0
            if (r1 < r7) goto L_0x0032
        L_0x0031:
            r2 = 1
        L_0x0032:
            if (r2 == 0) goto L_0x0043
            androidx.leanback.widget.q$b r0 = r5.f3591b
            int r1 = r5.f3595f
            androidx.leanback.widget.GridLayoutManager$b r0 = (androidx.leanback.widget.GridLayoutManager.C0743b) r0
            r0.mo3446f(r1)
            int r0 = r5.f3595f
            int r0 = r0 + r3
            r5.f3595f = r0
            goto L_0x0000
        L_0x0043:
            r5.m3678q()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.C0855q.mo3855p(int, int):void");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: r */
    public void mo3856r(int i) {
        if (i <= 0) {
            throw new IllegalArgumentException();
        } else if (this.f3594e != i) {
            this.f3594e = i;
            this.f3597h = new C4621e[i];
            for (int i2 = 0; i2 < this.f3594e; i2++) {
                this.f3597h[i2] = new C4621e();
            }
        }
    }
}
