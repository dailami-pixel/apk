package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.q0 */
public abstract class C0858q0 {
    /* renamed from: a */
    public abstract C0844p0 mo3140a(Object obj);

    /* renamed from: b */
    public C0844p0[] mo3141b() {
        return null;
    }
}
