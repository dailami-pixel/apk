package androidx.leanback.widget;

import android.graphics.PointF;
import androidx.leanback.widget.GridLayoutManager;

/* renamed from: androidx.leanback.widget.r */
class C0859r extends GridLayoutManager.C0744c {

    /* renamed from: s */
    final /* synthetic */ GridLayoutManager f3600s;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    C0859r(GridLayoutManager gridLayoutManager) {
        super();
        this.f3600s = gridLayoutManager;
    }

    /* renamed from: a */
    public PointF mo3451a(int i) {
        if (mo5062c() == 0) {
            return null;
        }
        GridLayoutManager gridLayoutManager = this.f3600s;
        boolean z = false;
        int Z = gridLayoutManager.mo4987Z(gridLayoutManager.mo4964C(0));
        GridLayoutManager gridLayoutManager2 = this.f3600s;
        int i2 = 1;
        if ((gridLayoutManager2.f3133D & 262144) == 0 ? i < Z : i > Z) {
            z = true;
        }
        if (z) {
            i2 = -1;
        }
        return gridLayoutManager2.f3167v == 0 ? new PointF((float) i2, 0.0f) : new PointF(0.0f, (float) i2);
    }
}
