package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.r0 */
public abstract class C0860r0 {
}
