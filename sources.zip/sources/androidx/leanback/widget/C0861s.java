package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.s */
public class C0861s {

    /* renamed from: a */
    private final long f3601a;

    /* renamed from: b */
    private final String f3602b;

    public C0861s(long j, String str) {
        this.f3601a = j;
        this.f3602b = str;
    }

    public C0861s(String str) {
        this.f3601a = -1;
        this.f3602b = str;
    }

    /* renamed from: a */
    public final long mo3857a() {
        return this.f3601a;
    }

    /* renamed from: b */
    public final String mo3858b() {
        return this.f3602b;
    }
}
