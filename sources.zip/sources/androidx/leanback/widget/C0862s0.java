package androidx.leanback.widget;

import android.graphics.Outline;
import android.view.View;
import android.view.ViewOutlineProvider;

/* renamed from: androidx.leanback.widget.s0 */
final class C0862s0 extends ViewOutlineProvider {

    /* renamed from: a */
    private int f3603a;

    C0862s0(int i) {
        this.f3603a = i;
    }

    public void getOutline(View view, Outline outline) {
        outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), (float) this.f3603a);
        outline.setAlpha(1.0f);
    }
}
