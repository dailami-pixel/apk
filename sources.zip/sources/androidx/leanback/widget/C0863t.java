package androidx.leanback.widget;

import android.graphics.Rect;

/* renamed from: androidx.leanback.widget.t */
public final class C0863t extends C0860r0 {

    /* renamed from: a */
    private int[] f3604a = new int[2];

    /* renamed from: b */
    private Rect f3605b = new Rect();
}
