package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.t0 */
public class C0864t0 {

    /* renamed from: a */
    private int f3606a = 1;

    /* renamed from: b */
    private C0861s f3607b;

    /* renamed from: c */
    private long f3608c = -1;

    public C0864t0() {
    }

    public C0864t0(long j, C0861s sVar) {
        this.f3608c = j;
        this.f3606a = (1 & -2) | 0;
        this.f3607b = sVar;
    }

    /* renamed from: a */
    public final C0861s mo3860a() {
        return this.f3607b;
    }

    /* renamed from: b */
    public final long mo3861b() {
        if ((this.f3606a & 1) != 1) {
            return this.f3608c;
        }
        C0861s sVar = this.f3607b;
        if (sVar != null) {
            return sVar.mo3857a();
        }
        return -1;
    }

    /* renamed from: c */
    public boolean mo3862c() {
        return !(this instanceof C0824l);
    }

    /* renamed from: d */
    public final void mo3863d(C0861s sVar) {
        this.f3607b = sVar;
    }

    /* renamed from: e */
    public final void mo3864e(long j) {
        this.f3608c = j;
        this.f3606a = (this.f3606a & -2) | 0;
    }

    public C0864t0(C0861s sVar) {
        this.f3607b = sVar;
    }
}
