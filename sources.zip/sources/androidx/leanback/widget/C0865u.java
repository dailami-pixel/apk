package androidx.leanback.widget;

import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.leanback.widget.C0870v0;

/* renamed from: androidx.leanback.widget.u */
public class C0865u extends C0870v0 {
    public C0865u() {
        mo3875w((C0866u0) null);
    }

    /* access modifiers changed from: protected */
    /* renamed from: i */
    public C0870v0.C0872b mo3631i(ViewGroup viewGroup) {
        RelativeLayout relativeLayout = new RelativeLayout(viewGroup.getContext());
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(0, 0));
        return new C0870v0.C0872b(relativeLayout);
    }
}
