package androidx.leanback.widget;

import android.graphics.Paint;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.leanback.widget.C0844p0;
import com.vidio.android.p195tv.R;

/* renamed from: androidx.leanback.widget.u0 */
public class C0866u0 extends C0844p0 {

    /* renamed from: b */
    private final int f3609b;

    /* renamed from: c */
    private final Paint f3610c;

    /* renamed from: d */
    private boolean f3611d;

    /* renamed from: e */
    private final boolean f3612e;

    /* renamed from: androidx.leanback.widget.u0$a */
    public static class C0867a extends C0844p0.C0845a {

        /* renamed from: b */
        float f3613b;

        /* renamed from: c */
        float f3614c;

        /* renamed from: d */
        RowHeaderView f3615d;

        /* renamed from: e */
        TextView f3616e;

        public C0867a(View view) {
            super(view);
            this.f3615d = (RowHeaderView) view.findViewById(R.id.row_header);
            this.f3616e = (TextView) view.findViewById(R.id.row_header_description);
            RowHeaderView rowHeaderView = this.f3615d;
            if (rowHeaderView != null) {
                rowHeaderView.getCurrentTextColor();
            }
            this.f3614c = view.getResources().getFraction(R.fraction.lb_browse_header_unselect_alpha, 1, 1);
        }
    }

    public C0866u0() {
        this.f3610c = new Paint(1);
        this.f3609b = R.layout.lb_row_header;
        this.f3612e = true;
    }

    public C0866u0(int i, boolean z) {
        this.f3610c = new Paint(1);
        this.f3609b = i;
        this.f3612e = z;
    }

    /* renamed from: b */
    public void mo3748b(C0844p0.C0845a aVar, Object obj) {
        C0861s a = obj == null ? null : ((C0864t0) obj).mo3860a();
        C0867a aVar2 = (C0867a) aVar;
        if (a == null) {
            RowHeaderView rowHeaderView = aVar2.f3615d;
            if (rowHeaderView != null) {
                rowHeaderView.setText((CharSequence) null);
            }
            TextView textView = aVar2.f3616e;
            if (textView != null) {
                textView.setText((CharSequence) null);
            }
            aVar.f3529a.setContentDescription((CharSequence) null);
            if (this.f3611d) {
                aVar.f3529a.setVisibility(8);
                return;
            }
            return;
        }
        RowHeaderView rowHeaderView2 = aVar2.f3615d;
        if (rowHeaderView2 != null) {
            rowHeaderView2.setText(a.mo3858b());
        }
        if (aVar2.f3616e != null) {
            if (TextUtils.isEmpty((CharSequence) null)) {
                aVar2.f3616e.setVisibility(8);
            } else {
                aVar2.f3616e.setVisibility(0);
            }
            aVar2.f3616e.setText((CharSequence) null);
        }
        aVar.f3529a.setContentDescription((CharSequence) null);
        aVar.f3529a.setVisibility(0);
    }

    /* renamed from: d */
    public C0844p0.C0845a mo3749d(ViewGroup viewGroup) {
        C0867a aVar = new C0867a(LayoutInflater.from(viewGroup.getContext()).inflate(this.f3609b, viewGroup, false));
        if (this.f3612e) {
            aVar.f3613b = 0.0f;
            mo3866j(aVar);
        }
        return aVar;
    }

    /* renamed from: e */
    public void mo3750e(C0844p0.C0845a aVar) {
        C0867a aVar2 = (C0867a) aVar;
        RowHeaderView rowHeaderView = aVar2.f3615d;
        if (rowHeaderView != null) {
            rowHeaderView.setText((CharSequence) null);
        }
        TextView textView = aVar2.f3616e;
        if (textView != null) {
            textView.setText((CharSequence) null);
        }
        if (this.f3612e) {
            aVar2.f3613b = 0.0f;
            mo3866j(aVar2);
        }
    }

    /* renamed from: i */
    public int mo3865i(C0867a aVar) {
        int paddingBottom = aVar.f3529a.getPaddingBottom();
        View view = aVar.f3529a;
        if (!(view instanceof TextView)) {
            return paddingBottom;
        }
        TextView textView = (TextView) view;
        Paint paint = this.f3610c;
        if (paint.getTextSize() != textView.getTextSize()) {
            paint.setTextSize(textView.getTextSize());
        }
        if (paint.getTypeface() != textView.getTypeface()) {
            paint.setTypeface(textView.getTypeface());
        }
        return paddingBottom + ((int) paint.descent());
    }

    /* access modifiers changed from: protected */
    /* renamed from: j */
    public void mo3866j(C0867a aVar) {
        if (this.f3612e) {
            View view = aVar.f3529a;
            float f = aVar.f3614c;
            view.setAlpha(((1.0f - f) * aVar.f3613b) + f);
        }
    }

    /* renamed from: k */
    public void mo3867k(boolean z) {
        this.f3611d = z;
    }

    public C0866u0(int i) {
        this.f3610c = new Paint(1);
        this.f3609b = i;
        this.f3612e = true;
    }
}
