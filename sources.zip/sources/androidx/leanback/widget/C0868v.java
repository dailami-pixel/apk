package androidx.leanback.widget;

import android.view.View;
import androidx.leanback.widget.C0873w;

/* renamed from: androidx.leanback.widget.v */
class C0868v {

    /* renamed from: a */
    private int f3617a = 0;

    /* renamed from: b */
    public final C0869a f3618b = new C0869a(1);

    /* renamed from: c */
    public final C0869a f3619c;

    /* renamed from: d */
    private C0869a f3620d;

    /* renamed from: androidx.leanback.widget.v$a */
    static final class C0869a extends C0873w.C0874a {

        /* renamed from: e */
        private int f3621e;

        C0869a(int i) {
            this.f3621e = i;
        }

        /* renamed from: c */
        public int mo3870c(View view) {
            return C0876x.m3749a(view, this, this.f3621e);
        }
    }

    C0868v() {
        C0869a aVar = new C0869a(0);
        this.f3619c = aVar;
        this.f3620d = aVar;
    }

    /* renamed from: a */
    public final C0869a mo3868a() {
        return this.f3620d;
    }

    /* renamed from: b */
    public final void mo3869b(int i) {
        this.f3617a = i;
        this.f3620d = i == 0 ? this.f3619c : this.f3618b;
    }
}
