package androidx.leanback.widget;

import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.leanback.widget.C0844p0;
import androidx.leanback.widget.C0866u0;
import java.util.Objects;
import p098d.p140l.p142d.C4828a;

/* renamed from: androidx.leanback.widget.v0 */
public abstract class C0870v0 extends C0844p0 {

    /* renamed from: b */
    private C0866u0 f3622b;

    /* renamed from: c */
    boolean f3623c = true;

    /* renamed from: d */
    int f3624d = 1;

    /* renamed from: androidx.leanback.widget.v0$a */
    static class C0871a extends C0844p0.C0845a {

        /* renamed from: b */
        final C0872b f3625b;

        public C0871a(RowContainerView rowContainerView, C0872b bVar) {
            super(rowContainerView);
            rowContainerView.addView(bVar.f3529a);
            C0866u0.C0867a aVar = bVar.f3627c;
            if (aVar != null) {
                rowContainerView.mo3523a(aVar.f3529a);
            }
            this.f3625b = bVar;
            bVar.f3626b = this;
        }
    }

    /* renamed from: androidx.leanback.widget.v0$b */
    public static class C0872b extends C0844p0.C0845a {

        /* renamed from: b */
        C0871a f3626b;

        /* renamed from: c */
        C0866u0.C0867a f3627c;

        /* renamed from: d */
        C0864t0 f3628d;

        /* renamed from: e */
        Object f3629e;

        /* renamed from: f */
        int f3630f = 0;

        /* renamed from: g */
        boolean f3631g;

        /* renamed from: h */
        boolean f3632h;

        /* renamed from: i */
        boolean f3633i;

        /* renamed from: j */
        float f3634j = 0.0f;

        /* renamed from: k */
        protected final C4828a f3635k;

        /* renamed from: l */
        C0801g f3636l;

        /* renamed from: m */
        private C0798f f3637m;

        public C0872b(View view) {
            super(view);
            this.f3635k = C4828a.m17609a(view.getContext());
        }

        /* renamed from: s */
        public final C0798f mo3879s() {
            return this.f3637m;
        }

        /* renamed from: t */
        public final void mo3880t(boolean z) {
            this.f3630f = z ? 1 : 2;
        }

        /* renamed from: u */
        public final void mo3881u(C0798f fVar) {
            this.f3637m = fVar;
        }

        /* renamed from: v */
        public final void mo3882v(C0801g gVar) {
            this.f3636l = gVar;
        }
    }

    public C0870v0() {
        C0866u0 u0Var = new C0866u0();
        this.f3622b = u0Var;
        u0Var.mo3867k(true);
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x0025  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0029  */
    /* renamed from: B */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m3716B(androidx.leanback.widget.C0870v0.C0872b r6, android.view.View r7) {
        /*
            r5 = this;
            int r0 = r5.f3624d
            r1 = 1
            r2 = 0
            r3 = 2
            if (r0 == r1) goto L_0x001c
            if (r0 == r3) goto L_0x0019
            r4 = 3
            if (r0 == r4) goto L_0x000d
            goto L_0x0021
        L_0x000d:
            boolean r0 = r6.f3632h
            if (r0 == 0) goto L_0x0017
            boolean r0 = r6.f3631g
            if (r0 == 0) goto L_0x0017
            r0 = 1
            goto L_0x001e
        L_0x0017:
            r0 = 0
            goto L_0x001e
        L_0x0019:
            boolean r0 = r6.f3631g
            goto L_0x001e
        L_0x001c:
            boolean r0 = r6.f3632h
        L_0x001e:
            r6.mo3880t(r0)
        L_0x0021:
            int r6 = r6.f3630f
            if (r6 != r1) goto L_0x0029
            r7.setActivated(r1)
            goto L_0x002e
        L_0x0029:
            if (r6 != r3) goto L_0x002e
            r7.setActivated(r2)
        L_0x002e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.C0870v0.m3716B(androidx.leanback.widget.v0$b, android.view.View):void");
    }

    /* renamed from: A */
    public final void mo3871A(C0844p0.C0845a aVar, float f) {
        C0872b m = mo3873m(aVar);
        m.f3634j = f;
        mo3639t(m);
    }

    /* renamed from: b */
    public final void mo3748b(C0844p0.C0845a aVar, Object obj) {
        mo3636q(mo3873m(aVar), obj);
    }

    /* renamed from: d */
    public final C0844p0.C0845a mo3749d(ViewGroup viewGroup) {
        C0844p0.C0845a aVar;
        C0872b i = mo3631i(viewGroup);
        i.f3633i = false;
        boolean z = true;
        if (this.f3622b == null) {
            if (!(mo3635p() && this.f3623c)) {
                z = false;
            }
        }
        if (z) {
            RowContainerView rowContainerView = new RowContainerView(viewGroup.getContext(), (AttributeSet) null, 0);
            C0866u0 u0Var = this.f3622b;
            if (u0Var != null) {
                i.f3627c = (C0866u0.C0867a) u0Var.mo3749d((ViewGroup) i.f3529a);
            }
            aVar = new C0871a(rowContainerView, i);
        } else {
            aVar = i;
        }
        mo3634o(i);
        if (i.f3633i) {
            return aVar;
        }
        throw new RuntimeException("super.initializeRowViewHolder() must be called");
    }

    /* renamed from: e */
    public final void mo3750e(C0844p0.C0845a aVar) {
        mo3640u(mo3873m(aVar));
    }

    /* renamed from: f */
    public final void mo3819f(C0844p0.C0845a aVar) {
        if (mo3873m(aVar).f3627c != null) {
            Objects.requireNonNull(this.f3622b);
        }
    }

    /* renamed from: g */
    public final void mo3820g(C0844p0.C0845a aVar) {
        C0872b m = mo3873m(aVar);
        C0866u0.C0867a aVar2 = m.f3627c;
        if (aVar2 != null) {
            Objects.requireNonNull(this.f3622b);
            C0844p0.m3638a(aVar2.f3529a);
        }
        C0844p0.m3638a(m.f3529a);
    }

    /* access modifiers changed from: protected */
    /* renamed from: i */
    public abstract C0872b mo3631i(ViewGroup viewGroup);

    /* access modifiers changed from: protected */
    /* renamed from: j */
    public void mo3632j(C0872b bVar, boolean z) {
        C0801g gVar;
        if (z && (gVar = bVar.f3636l) != null) {
            gVar.mo3132a((C0844p0.C0845a) null, (Object) null, bVar, bVar.f3629e);
        }
    }

    /* renamed from: k */
    public void mo3633k(C0872b bVar, boolean z) {
    }

    /* renamed from: l */
    public final C0866u0 mo3872l() {
        return this.f3622b;
    }

    /* renamed from: m */
    public final C0872b mo3873m(C0844p0.C0845a aVar) {
        return aVar instanceof C0871a ? ((C0871a) aVar).f3625b : (C0872b) aVar;
    }

    /* renamed from: n */
    public final float mo3874n(C0844p0.C0845a aVar) {
        return mo3873m(aVar).f3634j;
    }

    /* access modifiers changed from: protected */
    /* renamed from: o */
    public void mo3634o(C0872b bVar) {
        bVar.f3633i = true;
        View view = bVar.f3529a;
        if (view instanceof ViewGroup) {
            ((ViewGroup) view).setClipChildren(false);
        }
        C0871a aVar = bVar.f3626b;
        if (aVar != null) {
            ((ViewGroup) aVar.f3529a).setClipChildren(false);
        }
    }

    /* renamed from: p */
    public boolean mo3635p() {
        return true;
    }

    /* access modifiers changed from: protected */
    /* renamed from: q */
    public void mo3636q(C0872b bVar, Object obj) {
        bVar.f3629e = obj;
        C0864t0 t0Var = obj instanceof C0864t0 ? (C0864t0) obj : null;
        bVar.f3628d = t0Var;
        C0866u0.C0867a aVar = bVar.f3627c;
        if (aVar != null && t0Var != null) {
            this.f3622b.mo3748b(aVar, obj);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: r */
    public void mo3637r(C0872b bVar, boolean z) {
        if (!(this.f3622b == null || bVar.f3627c == null)) {
            ((RowContainerView) bVar.f3626b.f3529a).mo3525c(bVar.f3632h);
        }
        m3716B(bVar, bVar.f3529a);
    }

    /* access modifiers changed from: protected */
    /* renamed from: s */
    public void mo3638s(C0872b bVar, boolean z) {
        mo3632j(bVar, z);
        if (!(this.f3622b == null || bVar.f3627c == null)) {
            ((RowContainerView) bVar.f3626b.f3529a).mo3525c(bVar.f3632h);
        }
        m3716B(bVar, bVar.f3529a);
    }

    /* access modifiers changed from: protected */
    /* renamed from: t */
    public void mo3639t(C0872b bVar) {
        if (this.f3623c) {
            bVar.f3635k.mo22081c(bVar.f3634j);
            C0866u0.C0867a aVar = bVar.f3627c;
            if (aVar != null) {
                C0866u0 u0Var = this.f3622b;
                float f = bVar.f3634j;
                Objects.requireNonNull(u0Var);
                aVar.f3613b = f;
                u0Var.mo3866j(aVar);
            }
            if (mo3635p()) {
                ((RowContainerView) bVar.f3626b.f3529a).mo3524b(bVar.f3635k.mo22080b().getColor());
            }
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: u */
    public void mo3640u(C0872b bVar) {
        C0866u0.C0867a aVar = bVar.f3627c;
        if (aVar != null) {
            this.f3622b.mo3750e(aVar);
        }
        bVar.f3628d = null;
        bVar.f3629e = null;
    }

    /* renamed from: v */
    public void mo3641v(C0872b bVar, boolean z) {
        C0866u0.C0867a aVar = bVar.f3627c;
        if (aVar != null && aVar.f3529a.getVisibility() != 8) {
            bVar.f3627c.f3529a.setVisibility(z ? 0 : 4);
        }
    }

    /* renamed from: w */
    public final void mo3875w(C0866u0 u0Var) {
        this.f3622b = u0Var;
    }

    /* renamed from: x */
    public final void mo3876x(C0844p0.C0845a aVar, boolean z) {
        C0872b m = mo3873m(aVar);
        m.f3632h = z;
        mo3637r(m, z);
    }

    /* renamed from: y */
    public final void mo3877y(C0844p0.C0845a aVar, boolean z) {
        C0872b m = mo3873m(aVar);
        m.f3631g = z;
        mo3638s(m, z);
    }

    /* renamed from: z */
    public final void mo3878z(boolean z) {
        this.f3623c = z;
    }
}
