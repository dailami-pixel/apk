package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.w */
public final class C0873w {

    /* renamed from: a */
    private C0874a[] f3638a = {new C0874a()};

    /* renamed from: androidx.leanback.widget.w$a */
    public static class C0874a {

        /* renamed from: a */
        int f3639a = -1;

        /* renamed from: b */
        int f3640b = 0;

        /* renamed from: c */
        float f3641c = 50.0f;

        /* renamed from: d */
        boolean f3642d = false;

        /* renamed from: a */
        public final void mo3885a(int i) {
            this.f3640b = i;
        }

        /* renamed from: b */
        public final void mo3886b(float f) {
            if ((f < 0.0f || f > 100.0f) && f != -1.0f) {
                throw new IllegalArgumentException();
            }
            this.f3641c = f;
        }
    }

    /* renamed from: a */
    public C0874a[] mo3883a() {
        return this.f3638a;
    }

    /* renamed from: b */
    public void mo3884b(C0874a[] aVarArr) {
        if (aVarArr.length >= 1) {
            this.f3638a = aVarArr;
            return;
        }
        throw new IllegalArgumentException();
    }
}
