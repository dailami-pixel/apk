package androidx.leanback.widget;

import android.os.SystemClock;
import android.view.MotionEvent;

/* renamed from: androidx.leanback.widget.w0 */
class C0875w0 implements Runnable {

    /* renamed from: a */
    final /* synthetic */ SearchBar f3643a;

    C0875w0(SearchBar searchBar) {
        this.f3643a = searchBar;
    }

    public void run() {
        this.f3643a.f3273b.requestFocusFromTouch();
        this.f3643a.f3273b.dispatchTouchEvent(MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), 0, (float) this.f3643a.f3273b.getWidth(), (float) this.f3643a.f3273b.getHeight(), 0));
        this.f3643a.f3273b.dispatchTouchEvent(MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), 1, (float) this.f3643a.f3273b.getWidth(), (float) this.f3643a.f3273b.getHeight(), 0));
    }
}
