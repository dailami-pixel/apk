package androidx.leanback.widget;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import androidx.leanback.widget.C0873w;
import androidx.leanback.widget.GridLayoutManager;
import java.util.Objects;

/* renamed from: androidx.leanback.widget.x */
class C0876x {

    /* renamed from: a */
    private static Rect f3644a = new Rect();

    /* renamed from: a */
    static int m3749a(View view, C0873w.C0874a aVar, int i) {
        View view2;
        int i2;
        GridLayoutManager.LayoutParams layoutParams = (GridLayoutManager.LayoutParams) view.getLayoutParams();
        int i3 = aVar.f3639a;
        if (i3 == 0 || (view2 = view.findViewById(i3)) == null) {
            view2 = view;
        }
        int i4 = aVar.f3640b;
        if (i != 0) {
            if (aVar.f3642d) {
                float f = aVar.f3641c;
                if (f == 0.0f) {
                    i4 += view2.getPaddingTop();
                } else if (f == 100.0f) {
                    i4 -= view2.getPaddingBottom();
                }
            }
            if (aVar.f3641c != -1.0f) {
                if (view2 == view) {
                    Objects.requireNonNull(layoutParams);
                    i2 = (view2.getHeight() - layoutParams.f3173f) - layoutParams.f3175h;
                } else {
                    i2 = view2.getHeight();
                }
                i4 += (int) ((((float) i2) * aVar.f3641c) / 100.0f);
            }
            if (view == view2) {
                return i4;
            }
            Rect rect = f3644a;
            rect.top = i4;
            ((ViewGroup) view).offsetDescendantRectToMyCoords(view2, rect);
            return f3644a.top - layoutParams.f3173f;
        } else if (view.getLayoutDirection() == 1) {
            int k = (view2 == view ? layoutParams.mo3432k(view2) : view2.getWidth()) - i4;
            if (aVar.f3642d) {
                float f2 = aVar.f3641c;
                if (f2 == 0.0f) {
                    k -= view2.getPaddingRight();
                } else if (f2 == 100.0f) {
                    k += view2.getPaddingLeft();
                }
            }
            if (aVar.f3641c != -1.0f) {
                k -= (int) ((((float) (view2 == view ? layoutParams.mo3432k(view2) : view2.getWidth())) * aVar.f3641c) / 100.0f);
            }
            if (view == view2) {
                return k;
            }
            Rect rect2 = f3644a;
            rect2.right = k;
            ((ViewGroup) view).offsetDescendantRectToMyCoords(view2, rect2);
            return f3644a.right + layoutParams.f3174g;
        } else {
            if (aVar.f3642d) {
                float f3 = aVar.f3641c;
                if (f3 == 0.0f) {
                    i4 += view2.getPaddingLeft();
                } else if (f3 == 100.0f) {
                    i4 -= view2.getPaddingRight();
                }
            }
            if (aVar.f3641c != -1.0f) {
                i4 += (int) ((((float) (view2 == view ? layoutParams.mo3432k(view2) : view2.getWidth())) * aVar.f3641c) / 100.0f);
            }
            int i5 = i4;
            if (view == view2) {
                return i5;
            }
            Rect rect3 = f3644a;
            rect3.left = i5;
            ((ViewGroup) view).offsetDescendantRectToMyCoords(view2, rect3);
            return f3644a.left - layoutParams.f3172e;
        }
    }
}
