package androidx.leanback.widget;

/* renamed from: androidx.leanback.widget.x0 */
public class C0877x0 extends C0864t0 {
    /* renamed from: c */
    public final boolean mo3862c() {
        return false;
    }
}
