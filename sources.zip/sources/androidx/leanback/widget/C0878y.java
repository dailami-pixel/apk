package androidx.leanback.widget;

import android.view.View;
import android.view.ViewGroup;
import androidx.leanback.widget.C0781c0;
import androidx.leanback.widget.C0844p0;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/* renamed from: androidx.leanback.widget.y */
public class C0878y extends RecyclerView.C1147g implements C0831n {

    /* renamed from: a */
    private C0781c0 f3645a;

    /* renamed from: b */
    C0883e f3646b;

    /* renamed from: c */
    private C0858q0 f3647c;

    /* renamed from: d */
    C0836o f3648d;

    /* renamed from: e */
    private C0880b f3649e;

    /* renamed from: f */
    private ArrayList<C0844p0> f3650f = new ArrayList<>();

    /* renamed from: g */
    private C0781c0.C0783b f3651g = new C0879a();

    /* renamed from: androidx.leanback.widget.y$a */
    class C0879a extends C0781c0.C0783b {
        C0879a() {
        }

        /* renamed from: a */
        public void mo3158a() {
            C0878y.this.notifyDataSetChanged();
        }

        /* renamed from: b */
        public void mo3683b(int i, int i2) {
            C0878y.this.notifyItemMoved(i, i2);
        }

        /* renamed from: c */
        public void mo3159c(int i, int i2) {
            C0878y.this.notifyItemRangeChanged(i, i2);
        }

        /* renamed from: d */
        public void mo3684d(int i, int i2, Object obj) {
            C0878y.this.notifyItemRangeChanged(i, i2, obj);
        }

        /* renamed from: e */
        public void mo3160e(int i, int i2) {
            C0878y.this.notifyItemRangeInserted(i, i2);
        }

        /* renamed from: f */
        public void mo3161f(int i, int i2) {
            C0878y.this.notifyItemRangeRemoved(i, i2);
        }
    }

    /* renamed from: androidx.leanback.widget.y$b */
    public static class C0880b {
        /* renamed from: a */
        public void mo3218a(C0844p0 p0Var, int i) {
        }

        /* renamed from: b */
        public void mo3181b(C0882d dVar) {
        }

        /* renamed from: c */
        public void mo3182c(C0882d dVar) {
        }

        /* renamed from: d */
        public void mo3147d(C0882d dVar) {
            throw null;
        }

        /* renamed from: e */
        public void mo3183e(C0882d dVar) {
        }

        /* renamed from: f */
        public void mo3219f(C0882d dVar) {
        }
    }

    /* renamed from: androidx.leanback.widget.y$c */
    final class C0881c implements View.OnFocusChangeListener {

        /* renamed from: a */
        View.OnFocusChangeListener f3653a;

        C0881c() {
        }

        public void onFocusChange(View view, boolean z) {
            if (C0878y.this.f3646b != null) {
                view = (View) view.getParent();
            }
            C0836o oVar = C0878y.this.f3648d;
            if (oVar != null) {
                oVar.mo3814a(view, z);
            }
            View.OnFocusChangeListener onFocusChangeListener = this.f3653a;
            if (onFocusChangeListener != null) {
                onFocusChangeListener.onFocusChange(view, z);
            }
        }
    }

    /* renamed from: androidx.leanback.widget.y$d */
    public class C0882d extends RecyclerView.C1142b0 implements C0827m {

        /* renamed from: a */
        final C0844p0 f3655a;

        /* renamed from: b */
        final C0844p0.C0845a f3656b;

        /* renamed from: c */
        final C0881c f3657c;

        /* renamed from: d */
        Object f3658d;

        /* renamed from: e */
        Object f3659e;

        C0882d(C0844p0 p0Var, View view, C0844p0.C0845a aVar) {
            super(view);
            this.f3657c = new C0881c();
            this.f3655a = p0Var;
            this.f3656b = aVar;
        }

        /* renamed from: a */
        public final Object mo3901a() {
            return this.f3659e;
        }

        /* renamed from: b */
        public final Object mo3902b() {
            return this.f3658d;
        }

        /* renamed from: c */
        public Object mo3767c(Class<?> cls) {
            Objects.requireNonNull(this.f3656b);
            return null;
        }

        /* renamed from: d */
        public final C0844p0 mo3903d() {
            return this.f3655a;
        }

        /* renamed from: e */
        public final C0844p0.C0845a mo3904e() {
            return this.f3656b;
        }

        /* renamed from: f */
        public void mo3905f(Object obj) {
            this.f3659e = obj;
        }
    }

    /* renamed from: androidx.leanback.widget.y$e */
    public static abstract class C0883e {
        /* renamed from: a */
        public abstract View mo3150a(View view);

        /* renamed from: b */
        public abstract void mo3151b(View view, View view2);
    }

    public C0878y() {
    }

    public C0878y(C0781c0 c0Var, C0858q0 q0Var) {
        mo3891i(c0Var);
        this.f3647c = q0Var;
    }

    /* renamed from: a */
    public C0827m mo3787a(int i) {
        return this.f3650f.get(i);
    }

    /* renamed from: c */
    public ArrayList<C0844p0> mo3888c() {
        return this.f3650f;
    }

    /* access modifiers changed from: protected */
    /* renamed from: d */
    public void mo3643d(C0844p0 p0Var, int i) {
    }

    /* access modifiers changed from: protected */
    /* renamed from: e */
    public void mo3644e(C0882d dVar) {
    }

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public void mo3645f(C0882d dVar) {
    }

    /* access modifiers changed from: protected */
    /* renamed from: g */
    public void mo3646g(C0882d dVar) {
    }

    public int getItemCount() {
        C0781c0 c0Var = this.f3645a;
        if (c0Var != null) {
            return c0Var.mo3154m();
        }
        return 0;
    }

    public long getItemId(int i) {
        Objects.requireNonNull(this.f3645a);
        return -1;
    }

    public int getItemViewType(int i) {
        C0858q0 q0Var = this.f3647c;
        if (q0Var == null) {
            q0Var = this.f3645a.mo3666c();
        }
        C0844p0 a = q0Var.mo3140a(this.f3645a.mo3153a(i));
        int indexOf = this.f3650f.indexOf(a);
        if (indexOf < 0) {
            this.f3650f.add(a);
            indexOf = this.f3650f.indexOf(a);
            mo3643d(a, indexOf);
            C0880b bVar = this.f3649e;
            if (bVar != null) {
                bVar.mo3218a(a, indexOf);
            }
        }
        return indexOf;
    }

    /* access modifiers changed from: protected */
    /* renamed from: h */
    public void mo3647h(C0882d dVar) {
    }

    /* renamed from: i */
    public void mo3891i(C0781c0 c0Var) {
        C0781c0 c0Var2 = this.f3645a;
        if (c0Var != c0Var2) {
            if (c0Var2 != null) {
                c0Var2.mo3676n(this.f3651g);
            }
            this.f3645a = c0Var;
            if (c0Var == null) {
                notifyDataSetChanged();
                return;
            }
            c0Var.mo3674k(this.f3651g);
            boolean hasStableIds = hasStableIds();
            Objects.requireNonNull(this.f3645a);
            if (hasStableIds) {
                Objects.requireNonNull(this.f3645a);
                setHasStableIds(false);
            }
            notifyDataSetChanged();
        }
    }

    /* renamed from: j */
    public void mo3892j(C0880b bVar) {
        this.f3649e = bVar;
    }

    /* renamed from: k */
    public void mo3893k(C0858q0 q0Var) {
        this.f3647c = q0Var;
        notifyDataSetChanged();
    }

    /* renamed from: l */
    public void mo3894l(ArrayList<C0844p0> arrayList) {
        this.f3650f = arrayList;
    }

    /* renamed from: m */
    public void mo3895m(C0883e eVar) {
        this.f3646b = eVar;
    }

    public final void onBindViewHolder(RecyclerView.C1142b0 b0Var, int i) {
        C0882d dVar = (C0882d) b0Var;
        Object a = this.f3645a.mo3153a(i);
        dVar.f3658d = a;
        dVar.f3655a.mo3748b(dVar.f3656b, a);
        mo3645f(dVar);
        C0880b bVar = this.f3649e;
        if (bVar != null) {
            bVar.mo3182c(dVar);
        }
    }

    public final void onBindViewHolder(RecyclerView.C1142b0 b0Var, int i, List list) {
        C0882d dVar = (C0882d) b0Var;
        Object a = this.f3645a.mo3153a(i);
        dVar.f3658d = a;
        dVar.f3655a.mo3748b(dVar.f3656b, a);
        mo3645f(dVar);
        C0880b bVar = this.f3649e;
        if (bVar != null) {
            bVar.mo3182c(dVar);
        }
    }

    public final RecyclerView.C1142b0 onCreateViewHolder(ViewGroup viewGroup, int i) {
        C0844p0.C0845a aVar;
        View view;
        C0844p0 p0Var = this.f3650f.get(i);
        C0883e eVar = this.f3646b;
        if (eVar != null) {
            view = eVar.mo3150a(viewGroup);
            aVar = p0Var.mo3749d(viewGroup);
            this.f3646b.mo3151b(view, aVar.f3529a);
        } else {
            aVar = p0Var.mo3749d(viewGroup);
            view = aVar.f3529a;
        }
        C0882d dVar = new C0882d(p0Var, view, aVar);
        mo3646g(dVar);
        C0880b bVar = this.f3649e;
        if (bVar != null) {
            bVar.mo3147d(dVar);
        }
        View view2 = dVar.f3656b.f3529a;
        if (view2 != null) {
            dVar.f3657c.f3653a = view2.getOnFocusChangeListener();
            view2.setOnFocusChangeListener(dVar.f3657c);
        }
        C0836o oVar = this.f3648d;
        if (oVar != null) {
            oVar.mo3815b(view);
        }
        return dVar;
    }

    public final boolean onFailedToRecycleView(RecyclerView.C1142b0 b0Var) {
        onViewRecycled(b0Var);
        return false;
    }

    public final void onViewAttachedToWindow(RecyclerView.C1142b0 b0Var) {
        C0882d dVar = (C0882d) b0Var;
        mo3644e(dVar);
        C0880b bVar = this.f3649e;
        if (bVar != null) {
            bVar.mo3181b(dVar);
        }
        dVar.f3655a.mo3819f(dVar.f3656b);
    }

    public final void onViewDetachedFromWindow(RecyclerView.C1142b0 b0Var) {
        C0882d dVar = (C0882d) b0Var;
        dVar.f3655a.mo3820g(dVar.f3656b);
        C0880b bVar = this.f3649e;
        if (bVar != null) {
            bVar.mo3183e(dVar);
        }
    }

    public final void onViewRecycled(RecyclerView.C1142b0 b0Var) {
        C0882d dVar = (C0882d) b0Var;
        dVar.f3655a.mo3750e(dVar.f3656b);
        mo3647h(dVar);
        C0880b bVar = this.f3649e;
        if (bVar != null) {
            bVar.mo3219f(dVar);
        }
        dVar.f3658d = null;
    }
}
