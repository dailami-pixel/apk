package androidx.leanback.widget;

import android.graphics.Outline;
import android.view.View;
import android.view.ViewOutlineProvider;

/* renamed from: androidx.leanback.widget.y0 */
class C0884y0 {

    /* renamed from: a */
    static final ViewOutlineProvider f3661a = new C0885a();

    /* renamed from: androidx.leanback.widget.y0$a */
    static class C0885a extends ViewOutlineProvider {
        C0885a() {
        }

        public void getOutline(View view, Outline outline) {
            outline.setRect(0, 0, view.getWidth(), view.getHeight());
            outline.setAlpha(1.0f);
        }
    }

    /* renamed from: androidx.leanback.widget.y0$b */
    static class C0886b {

        /* renamed from: a */
        View f3662a;

        /* renamed from: b */
        float f3663b;

        /* renamed from: c */
        float f3664c;

        C0886b() {
        }
    }
}
