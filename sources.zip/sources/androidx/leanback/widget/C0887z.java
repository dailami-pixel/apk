package androidx.leanback.widget;

import android.content.Context;
import android.view.View;
import androidx.leanback.widget.C0878y;

/* renamed from: androidx.leanback.widget.z */
public class C0887z extends C0878y.C0883e {

    /* renamed from: a */
    private final C0888z0 f3665a;

    public C0887z(C0888z0 z0Var) {
        this.f3665a = z0Var;
    }

    /* renamed from: a */
    public View mo3150a(View view) {
        Context context = view.getContext();
        C0888z0 z0Var = this.f3665a;
        if (z0Var.f3670e) {
            return new ShadowOverlayContainer(context, z0Var.f3666a, z0Var.f3667b, z0Var.f3672g, z0Var.f3673h, z0Var.f3671f);
        }
        throw new IllegalArgumentException();
    }

    /* renamed from: b */
    public void mo3151b(View view, View view2) {
        ((ShadowOverlayContainer) view).mo3579c(view2);
    }
}
