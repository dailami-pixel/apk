package androidx.leanback.widget;

import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import android.view.ViewOutlineProvider;
import androidx.leanback.widget.C0884y0;
import com.vidio.android.p195tv.R;

/* renamed from: androidx.leanback.widget.z0 */
public final class C0888z0 {

    /* renamed from: a */
    int f3666a = 1;

    /* renamed from: b */
    boolean f3667b;

    /* renamed from: c */
    boolean f3668c;

    /* renamed from: d */
    boolean f3669d;

    /* renamed from: e */
    boolean f3670e;

    /* renamed from: f */
    int f3671f;

    /* renamed from: g */
    float f3672g;

    /* renamed from: h */
    float f3673h;

    /* renamed from: androidx.leanback.widget.z0$a */
    public static final class C0889a {

        /* renamed from: a */
        private boolean f3674a;

        /* renamed from: b */
        private boolean f3675b;

        /* renamed from: c */
        private boolean f3676c;

        /* renamed from: d */
        private boolean f3677d = true;

        /* renamed from: e */
        private boolean f3678e;

        /* renamed from: f */
        private C0890b f3679f = C0890b.f3680a;

        /* JADX WARNING: Code restructure failed: missing block: B:13:0x005a, code lost:
            if (r5.f3678e == false) goto L_0x007b;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:15:0x005e, code lost:
            if (r0.f3667b == false) goto L_0x007b;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x0074, code lost:
            if (r5.f3678e == false) goto L_0x007b;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:0x0078, code lost:
            if (r0.f3667b == false) goto L_0x007b;
         */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public androidx.leanback.widget.C0888z0 mo3908a(android.content.Context r6) {
            /*
                r5 = this;
                androidx.leanback.widget.z0 r0 = new androidx.leanback.widget.z0
                r0.<init>()
                boolean r1 = r5.f3674a
                r0.f3667b = r1
                boolean r1 = r5.f3675b
                r0.f3668c = r1
                boolean r2 = r5.f3676c
                r0.f3669d = r2
                if (r1 == 0) goto L_0x0025
                androidx.leanback.widget.z0$b r1 = r5.f3679f
                java.util.Objects.requireNonNull(r1)
                android.content.res.Resources r1 = r6.getResources()
                r2 = 2131165629(0x7f0701bd, float:1.794548E38)
                int r1 = r1.getDimensionPixelSize(r2)
                r0.f3671f = r1
            L_0x0025:
                boolean r1 = r0.f3669d
                r2 = 23
                r3 = 0
                r4 = 1
                if (r1 == 0) goto L_0x0067
                boolean r1 = r5.f3677d
                if (r1 == 0) goto L_0x0061
                r1 = 3
                r0.f3666a = r1
                androidx.leanback.widget.z0$b r1 = r5.f3679f
                java.util.Objects.requireNonNull(r1)
                android.content.res.Resources r6 = r6.getResources()
                r1 = 2131165541(0x7f070165, float:1.7945302E38)
                float r1 = r6.getDimension(r1)
                r0.f3673h = r1
                r1 = 2131165542(0x7f070166, float:1.7945304E38)
                float r6 = r6.getDimension(r1)
                r0.f3672g = r6
                int r6 = android.os.Build.VERSION.SDK_INT
                if (r6 < r2) goto L_0x0055
                r6 = 1
                goto L_0x0056
            L_0x0055:
                r6 = 0
            L_0x0056:
                if (r6 == 0) goto L_0x005c
                boolean r6 = r5.f3678e
                if (r6 == 0) goto L_0x007b
            L_0x005c:
                boolean r6 = r0.f3667b
                if (r6 == 0) goto L_0x007b
                goto L_0x007a
            L_0x0061:
                r6 = 2
                r0.f3666a = r6
                r0.f3670e = r4
                goto L_0x007d
            L_0x0067:
                r0.f3666a = r4
                int r6 = android.os.Build.VERSION.SDK_INT
                if (r6 < r2) goto L_0x006f
                r6 = 1
                goto L_0x0070
            L_0x006f:
                r6 = 0
            L_0x0070:
                if (r6 == 0) goto L_0x0076
                boolean r6 = r5.f3678e
                if (r6 == 0) goto L_0x007b
            L_0x0076:
                boolean r6 = r0.f3667b
                if (r6 == 0) goto L_0x007b
            L_0x007a:
                r3 = 1
            L_0x007b:
                r0.f3670e = r3
            L_0x007d:
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.C0888z0.C0889a.mo3908a(android.content.Context):androidx.leanback.widget.z0");
        }

        /* renamed from: b */
        public C0889a mo3909b(boolean z) {
            this.f3678e = z;
            return this;
        }

        /* renamed from: c */
        public C0889a mo3910c(boolean z) {
            this.f3674a = z;
            return this;
        }

        /* renamed from: d */
        public C0889a mo3911d(boolean z) {
            this.f3675b = z;
            return this;
        }

        /* renamed from: e */
        public C0889a mo3912e(boolean z) {
            this.f3676c = z;
            return this;
        }

        /* renamed from: f */
        public C0889a mo3913f(C0890b bVar) {
            this.f3679f = bVar;
            return this;
        }

        /* renamed from: g */
        public C0889a mo3914g(boolean z) {
            this.f3677d = z;
            return this;
        }
    }

    /* renamed from: androidx.leanback.widget.z0$b */
    public static final class C0890b {

        /* renamed from: a */
        public static final C0890b f3680a = new C0890b();
    }

    C0888z0() {
    }

    /* renamed from: b */
    public static void m3785b(View view, int i) {
        int i2 = Build.VERSION.SDK_INT;
        Drawable foreground = i2 >= 23 ? view.getForeground() : null;
        if (foreground instanceof ColorDrawable) {
            ((ColorDrawable) foreground).setColor(i);
            return;
        }
        ColorDrawable colorDrawable = new ColorDrawable(i);
        if (i2 >= 23) {
            view.setForeground(colorDrawable);
        }
    }

    /* renamed from: c */
    static void m3786c(Object obj, int i, float f) {
        if (obj != null) {
            if (f < 0.0f) {
                f = 0.0f;
            } else if (f > 1.0f) {
                f = 1.0f;
            }
            if (i == 2) {
                C0800f1 f1Var = (C0800f1) obj;
                f1Var.f3441a.setAlpha(1.0f - f);
                f1Var.f3442b.setAlpha(f);
            } else if (i == 3) {
                ViewOutlineProvider viewOutlineProvider = C0884y0.f3661a;
                C0884y0.C0886b bVar = (C0884y0.C0886b) obj;
                View view = bVar.f3662a;
                float f2 = bVar.f3663b;
                view.setZ(((bVar.f3664c - f2) * f) + f2);
            }
        }
    }

    /* renamed from: a */
    public void mo3907a(View view) {
        if (!this.f3670e) {
            if (!this.f3669d) {
                if (!this.f3668c) {
                    return;
                }
            } else if (this.f3666a == 3) {
                view.setTag(R.id.lb_shadow_impl, C0839p.m3626a(view, this.f3672g, this.f3673h, this.f3671f));
                return;
            } else if (!this.f3668c) {
                return;
            }
            C0839p.m3628c(view, true, this.f3671f);
        }
    }
}
