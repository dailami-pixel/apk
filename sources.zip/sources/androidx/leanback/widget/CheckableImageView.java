package androidx.leanback.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Checkable;
import android.widget.ImageView;

class CheckableImageView extends ImageView implements Checkable {

    /* renamed from: a */
    private static final int[] f3124a = {16842912};

    /* renamed from: b */
    private boolean f3125b;

    public CheckableImageView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public CheckableImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public boolean isChecked() {
        return this.f3125b;
    }

    public int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        if (isChecked()) {
            ImageView.mergeDrawableStates(onCreateDrawableState, f3124a);
        }
        return onCreateDrawableState;
    }

    public void setChecked(boolean z) {
        if (this.f3125b != z) {
            this.f3125b = z;
            refreshDrawableState();
        }
    }

    public void toggle() {
        setChecked(!this.f3125b);
    }
}
