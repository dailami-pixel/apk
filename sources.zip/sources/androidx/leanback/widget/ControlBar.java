package androidx.leanback.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import java.util.ArrayList;

class ControlBar extends LinearLayout {

    /* renamed from: a */
    int f3126a = -1;

    /* renamed from: b */
    boolean f3127b = true;

    public ControlBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public ControlBar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        int i3;
        if (i == 33 || i == 130) {
            int i4 = this.f3126a;
            if (i4 >= 0 && i4 < getChildCount()) {
                i3 = this.f3126a;
            } else if (getChildCount() > 0) {
                i3 = this.f3127b ? getChildCount() / 2 : 0;
            } else {
                return;
            }
            arrayList.add(getChildAt(i3));
            return;
        }
        super.addFocusables(arrayList, i, i2);
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
    }

    /* access modifiers changed from: protected */
    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (getChildCount() > 0) {
            int i2 = this.f3126a;
            if (getChildAt((i2 < 0 || i2 >= getChildCount()) ? this.f3127b ? getChildCount() / 2 : 0 : this.f3126a).requestFocus(i, rect)) {
                return true;
            }
        }
        return super.onRequestFocusInDescendants(i, rect);
    }

    public void requestChildFocus(View view, View view2) {
        super.requestChildFocus(view, view2);
        this.f3126a = indexOfChild(view);
    }
}
