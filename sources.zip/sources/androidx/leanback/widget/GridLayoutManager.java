package androidx.leanback.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import androidx.leanback.widget.C0834n1;
import androidx.leanback.widget.C0855q;
import androidx.leanback.widget.C0873w;
import androidx.recyclerview.widget.C1217n;
import androidx.recyclerview.widget.C1222r;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.common.api.C4291a;
import java.util.ArrayList;
import java.util.Objects;
import p098d.p112d.C4621e;
import p098d.p120g.p130j.C4761m;
import p098d.p120g.p130j.p131w.C4791b;
import p165e.p166a.p167a.p168a.C4924a;

final class GridLayoutManager extends RecyclerView.C1158o {

    /* renamed from: r */
    private static final Rect f3128r = new Rect();

    /* renamed from: s */
    static int[] f3129s = new int[2];

    /* renamed from: A */
    final SparseIntArray f3130A = new SparseIntArray();

    /* renamed from: B */
    int[] f3131B;

    /* renamed from: C */
    RecyclerView.C1169u f3132C;

    /* renamed from: D */
    int f3133D = 221696;

    /* renamed from: E */
    private C0799f0 f3134E = null;

    /* renamed from: F */
    private ArrayList<C0802g0> f3135F = null;

    /* renamed from: G */
    C0796e0 f3136G = null;

    /* renamed from: H */
    int f3137H = -1;

    /* renamed from: I */
    int f3138I = 0;

    /* renamed from: J */
    C0744c f3139J;

    /* renamed from: K */
    C0745d f3140K;

    /* renamed from: L */
    private int f3141L = 0;

    /* renamed from: M */
    private int f3142M;

    /* renamed from: N */
    int f3143N;

    /* renamed from: O */
    int f3144O;

    /* renamed from: P */
    private int f3145P;

    /* renamed from: Q */
    private int f3146Q;

    /* renamed from: R */
    private int[] f3147R;

    /* renamed from: S */
    private int f3148S;

    /* renamed from: T */
    private int f3149T;

    /* renamed from: U */
    private int f3150U;

    /* renamed from: V */
    private int f3151V;

    /* renamed from: W */
    private int f3152W = 8388659;

    /* renamed from: X */
    int f3153X;

    /* renamed from: Y */
    private int f3154Y = 1;

    /* renamed from: Z */
    C0855q f3155Z;

    /* renamed from: a0 */
    private int f3156a0 = 0;

    /* renamed from: b0 */
    final C0834n1 f3157b0 = new C0834n1();

    /* renamed from: c0 */
    private final C0868v f3158c0 = new C0868v();

    /* renamed from: d0 */
    private int f3159d0;

    /* renamed from: e0 */
    private int[] f3160e0 = new int[2];

    /* renamed from: f0 */
    final C0830m1 f3161f0 = new C0830m1();

    /* renamed from: g0 */
    private C0831n f3162g0;

    /* renamed from: h0 */
    private final Runnable f3163h0 = new C0742a();

    /* renamed from: i0 */
    private C0855q.C0857b f3164i0 = new C0743b();

    /* renamed from: t */
    int f3165t = 10;

    /* renamed from: u */
    final C0789e f3166u;

    /* renamed from: v */
    int f3167v = 0;

    /* renamed from: w */
    private C1222r f3168w = C1222r.m5124a(this);

    /* renamed from: x */
    RecyclerView.C1175y f3169x;

    /* renamed from: y */
    int f3170y;

    /* renamed from: z */
    int f3171z;

    static final class LayoutParams extends RecyclerView.LayoutParams {

        /* renamed from: e */
        int f3172e;

        /* renamed from: f */
        int f3173f;

        /* renamed from: g */
        int f3174g;

        /* renamed from: h */
        int f3175h;

        /* renamed from: i */
        private int f3176i;

        /* renamed from: j */
        private int f3177j;

        /* renamed from: k */
        private int[] f3178k;

        /* renamed from: l */
        private C0873w f3179l;

        public LayoutParams(int i, int i2) {
            super(i, i2);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public LayoutParams(LayoutParams layoutParams) {
            super((RecyclerView.LayoutParams) layoutParams);
        }

        public LayoutParams(RecyclerView.LayoutParams layoutParams) {
            super(layoutParams);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: f */
        public void mo3427f(int i, View view) {
            C0873w.C0874a[] a = this.f3179l.mo3883a();
            int[] iArr = this.f3178k;
            if (iArr == null || iArr.length != a.length) {
                this.f3178k = new int[a.length];
            }
            for (int i2 = 0; i2 < a.length; i2++) {
                this.f3178k[i2] = C0876x.m3749a(view, a[i2], i);
            }
            if (i == 0) {
                this.f3176i = this.f3178k[0];
            } else {
                this.f3177j = this.f3178k[0];
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: g */
        public int[] mo3428g() {
            return this.f3178k;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: h */
        public int mo3429h() {
            return this.f3176i;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: i */
        public int mo3430i() {
            return this.f3177j;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: j */
        public C0873w mo3431j() {
            return this.f3179l;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: k */
        public int mo3432k(View view) {
            return (view.getWidth() - this.f3172e) - this.f3174g;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: l */
        public void mo3433l(int i) {
            this.f3176i = i;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: m */
        public void mo3434m(int i) {
            this.f3177j = i;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: n */
        public void mo3435n(C0873w wVar) {
            this.f3179l = wVar;
        }
    }

    static final class SavedState implements Parcelable {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0741a();

        /* renamed from: a */
        int f3180a;

        /* renamed from: b */
        Bundle f3181b = Bundle.EMPTY;

        /* renamed from: androidx.leanback.widget.GridLayoutManager$SavedState$a */
        static class C0741a implements Parcelable.Creator<SavedState> {
            C0741a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public Object[] newArray(int i) {
                return new SavedState[i];
            }
        }

        SavedState() {
        }

        SavedState(Parcel parcel) {
            this.f3180a = parcel.readInt();
            this.f3181b = parcel.readBundle(GridLayoutManager.class.getClassLoader());
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f3180a);
            parcel.writeBundle(this.f3181b);
        }
    }

    /* renamed from: androidx.leanback.widget.GridLayoutManager$a */
    class C0742a implements Runnable {
        C0742a() {
        }

        public void run() {
            GridLayoutManager.this.mo4991b1();
        }
    }

    /* renamed from: androidx.leanback.widget.GridLayoutManager$b */
    class C0743b implements C0855q.C0857b {
        C0743b() {
        }

        /* renamed from: a */
        public void mo3441a(Object obj, int i, int i2, int i3, int i4) {
            int i5;
            int i6;
            C0745d dVar;
            View view = (View) obj;
            if (i4 == Integer.MIN_VALUE || i4 == Integer.MAX_VALUE) {
                GridLayoutManager gridLayoutManager = GridLayoutManager.this;
                boolean z = gridLayoutManager.f3155Z.f3592c;
                C0834n1.C0835a a = gridLayoutManager.f3157b0.mo3788a();
                i4 = !z ? a.mo3798f() : a.mo3800h() - GridLayoutManager.this.f3157b0.mo3788a().mo3797e();
            }
            GridLayoutManager gridLayoutManager2 = GridLayoutManager.this;
            if (!gridLayoutManager2.f3155Z.f3592c) {
                i5 = i2 + i4;
                i6 = i4;
            } else {
                i6 = i4 - i2;
                i5 = i4;
            }
            int f = GridLayoutManager.this.f3157b0.mo3790c().mo3798f() + gridLayoutManager2.mo3363I1(i3);
            GridLayoutManager gridLayoutManager3 = GridLayoutManager.this;
            int i7 = f - gridLayoutManager3.f3144O;
            gridLayoutManager3.f3161f0.mo3781c(view, i);
            GridLayoutManager.this.mo3390a2(i3, view, i6, i5, i7);
            if (!GridLayoutManager.this.f3169x.mo5081f()) {
                GridLayoutManager.this.mo3367K2();
            }
            GridLayoutManager gridLayoutManager4 = GridLayoutManager.this;
            if (!((gridLayoutManager4.f3133D & 3) == 1 || (dVar = gridLayoutManager4.f3140K) == null)) {
                dVar.mo3453u();
            }
            GridLayoutManager gridLayoutManager5 = GridLayoutManager.this;
            if (gridLayoutManager5.f3136G != null) {
                RecyclerView.C1142b0 childViewHolder = gridLayoutManager5.f3166u.getChildViewHolder(view);
                GridLayoutManager gridLayoutManager6 = GridLayoutManager.this;
                gridLayoutManager6.f3136G.mo3230a(gridLayoutManager6.f3166u, view, i, childViewHolder == null ? -1 : childViewHolder.getItemId());
            }
        }

        /* JADX WARNING: type inference failed for: r8v0, types: [java.lang.Object[]] */
        /* JADX WARNING: Code restructure failed: missing block: B:22:0x007b, code lost:
            if (r9.f3140K == null) goto L_0x00a7;
         */
        /* JADX WARNING: Unknown variable types count: 1 */
        /* renamed from: b */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public int mo3442b(int r6, boolean r7, java.lang.Object[] r8, boolean r9) {
            /*
                r5 = this;
                androidx.leanback.widget.GridLayoutManager r0 = androidx.leanback.widget.GridLayoutManager.this
                int r1 = r0.f3170y
                int r1 = r6 - r1
                androidx.recyclerview.widget.RecyclerView$u r0 = r0.f3132C
                android.view.View r0 = r0.mo5050f(r1)
                android.view.ViewGroup$LayoutParams r1 = r0.getLayoutParams()
                androidx.leanback.widget.GridLayoutManager$LayoutParams r1 = (androidx.leanback.widget.GridLayoutManager.LayoutParams) r1
                androidx.leanback.widget.GridLayoutManager r2 = androidx.leanback.widget.GridLayoutManager.this
                androidx.leanback.widget.e r2 = r2.f3166u
                androidx.recyclerview.widget.RecyclerView$b0 r2 = r2.getChildViewHolder(r0)
                androidx.leanback.widget.GridLayoutManager r3 = androidx.leanback.widget.GridLayoutManager.this
                java.lang.Class<androidx.leanback.widget.w> r4 = androidx.leanback.widget.C0873w.class
                java.lang.Object r2 = r3.mo3352E1(r2, r4)
                androidx.leanback.widget.w r2 = (androidx.leanback.widget.C0873w) r2
                r1.mo3435n(r2)
                boolean r1 = r1.mo4857d()
                r2 = 0
                if (r1 != 0) goto L_0x00af
                if (r9 == 0) goto L_0x003e
                if (r7 == 0) goto L_0x0038
                androidx.leanback.widget.GridLayoutManager r7 = androidx.leanback.widget.GridLayoutManager.this
                r7.mo4989b(r0)
                goto L_0x004b
            L_0x0038:
                androidx.leanback.widget.GridLayoutManager r7 = androidx.leanback.widget.GridLayoutManager.this
                r7.mo4992c(r0, r2)
                goto L_0x004b
            L_0x003e:
                if (r7 == 0) goto L_0x0046
                androidx.leanback.widget.GridLayoutManager r7 = androidx.leanback.widget.GridLayoutManager.this
                r7.mo4993d(r0)
                goto L_0x004b
            L_0x0046:
                androidx.leanback.widget.GridLayoutManager r7 = androidx.leanback.widget.GridLayoutManager.this
                r7.mo4995e(r0, r2)
            L_0x004b:
                androidx.leanback.widget.GridLayoutManager r7 = androidx.leanback.widget.GridLayoutManager.this
                int r7 = r7.f3143N
                r9 = -1
                if (r7 == r9) goto L_0x0055
                r0.setVisibility(r7)
            L_0x0055:
                androidx.leanback.widget.GridLayoutManager r7 = androidx.leanback.widget.GridLayoutManager.this
                androidx.leanback.widget.GridLayoutManager$d r7 = r7.f3140K
                if (r7 == 0) goto L_0x005e
                r7.mo3454v()
            L_0x005e:
                androidx.leanback.widget.GridLayoutManager r7 = androidx.leanback.widget.GridLayoutManager.this
                android.view.View r9 = r0.findFocus()
                int r7 = r7.mo3372M1(r0, r9)
                androidx.leanback.widget.GridLayoutManager r9 = androidx.leanback.widget.GridLayoutManager.this
                int r1 = r9.f3133D
                r3 = r1 & 3
                r4 = 1
                if (r3 == r4) goto L_0x007e
                int r1 = r9.f3137H
                if (r6 != r1) goto L_0x00aa
                int r6 = r9.f3138I
                if (r7 != r6) goto L_0x00aa
                androidx.leanback.widget.GridLayoutManager$d r6 = r9.f3140K
                if (r6 != 0) goto L_0x00aa
                goto L_0x00a7
            L_0x007e:
                r3 = r1 & 4
                if (r3 != 0) goto L_0x00aa
                r1 = r1 & 16
                if (r1 != 0) goto L_0x008f
                int r3 = r9.f3137H
                if (r6 != r3) goto L_0x008f
                int r3 = r9.f3138I
                if (r7 != r3) goto L_0x008f
                goto L_0x00a7
            L_0x008f:
                if (r1 == 0) goto L_0x00aa
                int r9 = r9.f3137H
                if (r6 < r9) goto L_0x00aa
                boolean r9 = r0.hasFocusable()
                if (r9 == 0) goto L_0x00aa
                androidx.leanback.widget.GridLayoutManager r9 = androidx.leanback.widget.GridLayoutManager.this
                r9.f3137H = r6
                r9.f3138I = r7
                int r6 = r9.f3133D
                r6 = r6 & -17
                r9.f3133D = r6
            L_0x00a7:
                r9.mo3417w1()
            L_0x00aa:
                androidx.leanback.widget.GridLayoutManager r6 = androidx.leanback.widget.GridLayoutManager.this
                r6.mo3392c2(r0)
            L_0x00af:
                r8[r2] = r0
                androidx.leanback.widget.GridLayoutManager r6 = androidx.leanback.widget.GridLayoutManager.this
                int r7 = r6.f3167v
                if (r7 != 0) goto L_0x00bc
                int r6 = r6.mo3349D1(r0)
                goto L_0x00c0
            L_0x00bc:
                int r6 = r6.mo3346C1(r0)
            L_0x00c0:
                return r6
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.GridLayoutManager.C0743b.mo3442b(int, boolean, java.lang.Object[], boolean):int");
        }

        /* renamed from: c */
        public int mo3443c() {
            return GridLayoutManager.this.f3169x.mo5078c() + GridLayoutManager.this.f3170y;
        }

        /* renamed from: d */
        public int mo3444d(int i) {
            GridLayoutManager gridLayoutManager = GridLayoutManager.this;
            View x = gridLayoutManager.mo4651x(i - gridLayoutManager.f3170y);
            GridLayoutManager gridLayoutManager2 = GridLayoutManager.this;
            return (gridLayoutManager2.f3133D & 262144) != 0 ? gridLayoutManager2.mo3378R1(x) : gridLayoutManager2.mo3379S1(x);
        }

        /* renamed from: e */
        public int mo3445e(int i) {
            GridLayoutManager gridLayoutManager = GridLayoutManager.this;
            return gridLayoutManager.mo3381T1(gridLayoutManager.mo4651x(i - gridLayoutManager.f3170y));
        }

        /* renamed from: f */
        public void mo3446f(int i) {
            GridLayoutManager gridLayoutManager = GridLayoutManager.this;
            View x = gridLayoutManager.mo4651x(i - gridLayoutManager.f3170y);
            GridLayoutManager gridLayoutManager2 = GridLayoutManager.this;
            if ((gridLayoutManager2.f3133D & 3) == 1) {
                gridLayoutManager2.mo5019v(x, gridLayoutManager2.f3132C);
            } else {
                gridLayoutManager2.mo4984X0(x, gridLayoutManager2.f3132C);
            }
        }
    }

    /* renamed from: androidx.leanback.widget.GridLayoutManager$c */
    abstract class C0744c extends C1217n {

        /* renamed from: q */
        boolean f3184q;

        C0744c() {
            super(GridLayoutManager.this.f3166u.getContext());
        }

        /* access modifiers changed from: protected */
        /* renamed from: j */
        public void mo3447j() {
            super.mo3447j();
            if (!this.f3184q) {
                mo3450t();
            }
            GridLayoutManager gridLayoutManager = GridLayoutManager.this;
            if (gridLayoutManager.f3139J == this) {
                gridLayoutManager.f3139J = null;
            }
            if (gridLayoutManager.f3140K == this) {
                gridLayoutManager.f3140K = null;
            }
        }

        /* access modifiers changed from: protected */
        /* renamed from: k */
        public void mo3448k(View view, RecyclerView.C1175y yVar, RecyclerView.C1172x.C1173a aVar) {
            int i;
            int i2;
            if (GridLayoutManager.this.mo3366J1(view, (View) null, GridLayoutManager.f3129s)) {
                if (GridLayoutManager.this.f3167v == 0) {
                    int[] iArr = GridLayoutManager.f3129s;
                    i = iArr[0];
                    i2 = iArr[1];
                } else {
                    int[] iArr2 = GridLayoutManager.f3129s;
                    int i3 = iArr2[1];
                    i2 = iArr2[0];
                    i = i3;
                }
                aVar.mo5075d(i, i2, mo5210q((int) Math.sqrt((double) ((i2 * i2) + (i * i)))), this.f4795j);
            }
        }

        /* access modifiers changed from: protected */
        /* renamed from: r */
        public int mo3449r(int i) {
            int r = super.mo3449r(i);
            if (GridLayoutManager.this.f3157b0.mo3788a().mo3800h() <= 0) {
                return r;
            }
            float h = (30.0f / ((float) GridLayoutManager.this.f3157b0.mo3788a().mo3800h())) * ((float) i);
            return ((float) r) < h ? (int) h : r;
        }

        /* access modifiers changed from: protected */
        /* renamed from: t */
        public void mo3450t() {
            View b = mo5061b(mo5064e());
            if (b != null) {
                if (GridLayoutManager.this.f3137H != mo5064e()) {
                    GridLayoutManager.this.f3137H = mo5064e();
                }
                if (GridLayoutManager.this.mo5003i0()) {
                    GridLayoutManager.this.f3133D |= 32;
                    b.requestFocus();
                    GridLayoutManager.this.f3133D &= -33;
                }
                GridLayoutManager.this.mo3417w1();
                GridLayoutManager.this.mo3419x1();
            } else if (mo5064e() >= 0) {
                GridLayoutManager.this.mo3402n2(mo5064e(), 0, false, 0);
            }
        }
    }

    /* renamed from: androidx.leanback.widget.GridLayoutManager$d */
    final class C0745d extends C0744c {

        /* renamed from: s */
        private final boolean f3186s;

        /* renamed from: t */
        private int f3187t;

        C0745d(int i, boolean z) {
            super();
            this.f3187t = i;
            this.f3186s = z;
            mo5069l(-2);
        }

        /* renamed from: a */
        public PointF mo3451a(int i) {
            int i2 = this.f3187t;
            if (i2 == 0) {
                return null;
            }
            GridLayoutManager gridLayoutManager = GridLayoutManager.this;
            int i3 = ((gridLayoutManager.f3133D & 262144) == 0 ? i2 >= 0 : i2 <= 0) ? 1 : -1;
            return gridLayoutManager.f3167v == 0 ? new PointF((float) i3, 0.0f) : new PointF(0.0f, (float) i3);
        }

        /* access modifiers changed from: protected */
        /* renamed from: s */
        public void mo3452s(RecyclerView.C1172x.C1173a aVar) {
            if (this.f3187t != 0) {
                super.mo3452s(aVar);
            }
        }

        /* access modifiers changed from: protected */
        /* renamed from: t */
        public void mo3450t() {
            super.mo3450t();
            this.f3187t = 0;
            View b = mo5061b(mo5064e());
            if (b != null) {
                GridLayoutManager.this.mo3403p2(b, true);
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: u */
        public void mo3453u() {
            int i;
            if (this.f3186s && (i = this.f3187t) != 0) {
                this.f3187t = GridLayoutManager.this.mo3396g2(true, i);
            }
            int i2 = this.f3187t;
            if (i2 == 0 || ((i2 > 0 && GridLayoutManager.this.mo3385W1()) || (this.f3187t < 0 && GridLayoutManager.this.mo3384V1()))) {
                mo5069l(GridLayoutManager.this.f3137H);
                mo5071n();
            }
        }

        /* access modifiers changed from: package-private */
        /* JADX WARNING: Removed duplicated region for block: B:14:0x0026  */
        /* JADX WARNING: Removed duplicated region for block: B:25:0x004c  */
        /* renamed from: v */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void mo3454v() {
            /*
                r4 = this;
                boolean r0 = r4.f3186s
                if (r0 != 0) goto L_0x0069
                int r0 = r4.f3187t
                if (r0 != 0) goto L_0x0009
                goto L_0x0069
            L_0x0009:
                r1 = 0
                if (r0 <= 0) goto L_0x0014
                androidx.leanback.widget.GridLayoutManager r0 = androidx.leanback.widget.GridLayoutManager.this
                int r2 = r0.f3137H
            L_0x0010:
                int r0 = r0.f3153X
                int r2 = r2 + r0
                goto L_0x001b
            L_0x0014:
                androidx.leanback.widget.GridLayoutManager r0 = androidx.leanback.widget.GridLayoutManager.this
                int r2 = r0.f3137H
            L_0x0018:
                int r0 = r0.f3153X
                int r2 = r2 - r0
            L_0x001b:
                int r0 = r4.f3187t
                if (r0 == 0) goto L_0x004c
                android.view.View r0 = r4.mo5061b(r2)
                if (r0 != 0) goto L_0x0026
                goto L_0x004c
            L_0x0026:
                androidx.leanback.widget.GridLayoutManager r3 = androidx.leanback.widget.GridLayoutManager.this
                boolean r3 = r3.mo3415v1(r0)
                if (r3 != 0) goto L_0x002f
                goto L_0x0042
            L_0x002f:
                androidx.leanback.widget.GridLayoutManager r1 = androidx.leanback.widget.GridLayoutManager.this
                r1.f3137H = r2
                r3 = 0
                r1.f3138I = r3
                int r1 = r4.f3187t
                if (r1 <= 0) goto L_0x003d
                int r1 = r1 + -1
                goto L_0x003f
            L_0x003d:
                int r1 = r1 + 1
            L_0x003f:
                r4.f3187t = r1
                r1 = r0
            L_0x0042:
                int r0 = r4.f3187t
                if (r0 <= 0) goto L_0x0049
                androidx.leanback.widget.GridLayoutManager r0 = androidx.leanback.widget.GridLayoutManager.this
                goto L_0x0010
            L_0x0049:
                androidx.leanback.widget.GridLayoutManager r0 = androidx.leanback.widget.GridLayoutManager.this
                goto L_0x0018
            L_0x004c:
                if (r1 == 0) goto L_0x0069
                androidx.leanback.widget.GridLayoutManager r0 = androidx.leanback.widget.GridLayoutManager.this
                boolean r0 = r0.mo5003i0()
                if (r0 == 0) goto L_0x0069
                androidx.leanback.widget.GridLayoutManager r0 = androidx.leanback.widget.GridLayoutManager.this
                int r2 = r0.f3133D
                r2 = r2 | 32
                r0.f3133D = r2
                r1.requestFocus()
                androidx.leanback.widget.GridLayoutManager r0 = androidx.leanback.widget.GridLayoutManager.this
                int r1 = r0.f3133D
                r1 = r1 & -33
                r0.f3133D = r1
            L_0x0069:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.GridLayoutManager.C0745d.mo3454v():void");
        }

        /* access modifiers changed from: package-private */
        /* renamed from: w */
        public void mo3455w() {
            int i = this.f3187t;
            if (i > (-GridLayoutManager.this.f3165t)) {
                this.f3187t = i - 1;
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: x */
        public void mo3456x() {
            int i = this.f3187t;
            if (i < GridLayoutManager.this.f3165t) {
                this.f3187t = i + 1;
            }
        }
    }

    public GridLayoutManager(C0789e eVar) {
        this.f3166u = eVar;
        this.f3143N = -1;
        mo5002h1(false);
    }

    /* renamed from: A1 */
    private int m3186A1(int i) {
        return m3187B1(mo4964C(i));
    }

    /* renamed from: B1 */
    private int m3187B1(View view) {
        LayoutParams layoutParams;
        if (view == null || (layoutParams = (LayoutParams) view.getLayoutParams()) == null || layoutParams.mo4857d()) {
            return -1;
        }
        return layoutParams.mo4854a();
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x0023 A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0038 A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0046 A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* renamed from: F1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private int m3188F1(int r10) {
        /*
            r9 = this;
            int r0 = r9.f3167v
            r1 = 130(0x82, float:1.82E-43)
            r2 = 66
            r3 = 33
            r4 = 0
            r5 = 3
            r6 = 2
            r7 = 17
            r8 = 1
            if (r0 != 0) goto L_0x002b
            r0 = 262144(0x40000, float:3.67342E-40)
            if (r10 == r7) goto L_0x0025
            if (r10 == r3) goto L_0x0023
            if (r10 == r2) goto L_0x001d
            if (r10 == r1) goto L_0x001b
            goto L_0x0046
        L_0x001b:
            r4 = 3
            goto L_0x0048
        L_0x001d:
            int r10 = r9.f3133D
            r10 = r10 & r0
            if (r10 != 0) goto L_0x0048
            goto L_0x0038
        L_0x0023:
            r4 = 2
            goto L_0x0048
        L_0x0025:
            int r10 = r9.f3133D
            r10 = r10 & r0
            if (r10 != 0) goto L_0x0038
            goto L_0x0048
        L_0x002b:
            if (r0 != r8) goto L_0x0046
            r0 = 524288(0x80000, float:7.34684E-40)
            if (r10 == r7) goto L_0x0040
            if (r10 == r3) goto L_0x0048
            if (r10 == r2) goto L_0x003a
            if (r10 == r1) goto L_0x0038
            goto L_0x0046
        L_0x0038:
            r4 = 1
            goto L_0x0048
        L_0x003a:
            int r10 = r9.f3133D
            r10 = r10 & r0
            if (r10 != 0) goto L_0x0023
            goto L_0x001b
        L_0x0040:
            int r10 = r9.f3133D
            r10 = r10 & r0
            if (r10 != 0) goto L_0x001b
            goto L_0x0023
        L_0x0046:
            r4 = 17
        L_0x0048:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.GridLayoutManager.m3188F1(int):int");
    }

    /* renamed from: G1 */
    private int m3189G1(View view) {
        return this.f3157b0.mo3788a().mo3799g(m3197O1(view));
    }

    /* renamed from: G2 */
    private void m3190G2() {
        int D = mo4966D();
        for (int i = 0; i < D; i++) {
            m3192H2(mo4964C(i));
        }
    }

    /* renamed from: H1 */
    private int m3191H1(int i) {
        int i2 = this.f3146Q;
        if (i2 != 0) {
            return i2;
        }
        int[] iArr = this.f3147R;
        if (iArr == null) {
            return 0;
        }
        return iArr[i];
    }

    /* renamed from: H2 */
    private void m3192H2(View view) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (layoutParams.mo3431j() == null) {
            layoutParams.mo3433l(this.f3158c0.f3619c.mo3870c(view));
        } else {
            layoutParams.mo3427f(this.f3167v, view);
            if (this.f3167v != 0) {
                layoutParams.mo3433l(this.f3158c0.f3619c.mo3870c(view));
                return;
            }
        }
        layoutParams.mo3434m(this.f3158c0.f3618b.mo3870c(view));
    }

    /* renamed from: J2 */
    private void m3193J2() {
        int i = this.f3133D & -1025;
        int i2 = 0;
        if (m3203f2(false)) {
            i2 = 1024;
        }
        int i3 = i | i2;
        this.f3133D = i3;
        if ((i3 & 1024) != 0) {
            C0789e eVar = this.f3166u;
            Runnable runnable = this.f3163h0;
            int i4 = C4761m.f17241f;
            eVar.postOnAnimation(runnable);
        }
    }

    /* renamed from: K1 */
    private int m3194K1(View view) {
        return this.f3157b0.mo3790c().mo3799g(this.f3167v == 0 ? m3199Q1(view) : m3198P1(view));
    }

    /* renamed from: L1 */
    private int m3195L1() {
        int i = (this.f3133D & 524288) != 0 ? 0 : this.f3153X - 1;
        return mo3363I1(i) + m3191H1(i);
    }

    /* renamed from: L2 */
    private void m3196L2() {
        C0834n1.C0835a c = this.f3157b0.mo3790c();
        int f = c.mo3798f() - this.f3144O;
        int L1 = m3195L1() + f;
        c.mo3812t(f, L1, f, L1);
    }

    /* renamed from: O1 */
    private int m3197O1(View view) {
        return this.f3167v == 0 ? m3198P1(view) : m3199Q1(view);
    }

    /* renamed from: P1 */
    private int m3198P1(View view) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        Objects.requireNonNull(layoutParams);
        return view.getLeft() + layoutParams.f3172e + layoutParams.mo3429h();
    }

    /* renamed from: Q1 */
    private int m3199Q1(View view) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        Objects.requireNonNull(layoutParams);
        return view.getTop() + layoutParams.f3173f + layoutParams.mo3430i();
    }

    /* renamed from: b2 */
    private void m3200b2() {
        this.f3132C = null;
        this.f3169x = null;
        this.f3170y = 0;
        this.f3171z = 0;
    }

    /* renamed from: d2 */
    private void m3201d2() {
        this.f3155Z.mo3659n((this.f3133D & 262144) != 0 ? this.f3159d0 + 0 + this.f3171z : 0 - this.f3171z, false);
    }

    /* renamed from: e2 */
    private void m3202e2(boolean z) {
        if (z) {
            if (mo3385W1()) {
                return;
            }
        } else if (mo3384V1()) {
            return;
        }
        C0745d dVar = this.f3140K;
        if (dVar == null) {
            this.f3166u.stopScroll();
            boolean z2 = true;
            int i = z ? 1 : -1;
            if (this.f3153X <= 1) {
                z2 = false;
            }
            C0745d dVar2 = new C0745d(i, z2);
            this.f3141L = 0;
            mo3406r1(dVar2);
        } else if (z) {
            dVar.mo3456x();
        } else {
            dVar.mo3455w();
        }
    }

    /* renamed from: f2 */
    private boolean m3203f2(boolean z) {
        C4621e[] eVarArr;
        int i;
        if (this.f3146Q != 0 || this.f3147R == null) {
            return false;
        }
        C0855q qVar = this.f3155Z;
        if (qVar == null) {
            eVarArr = null;
        } else {
            eVarArr = qVar.mo3657j(qVar.f3595f, qVar.f3596g);
        }
        boolean z2 = false;
        int i2 = -1;
        for (int i3 = 0; i3 < this.f3153X; i3++) {
            C4621e eVar = eVarArr == null ? null : eVarArr[i3];
            int f = eVar == null ? 0 : eVar.mo21356f();
            int i4 = -1;
            for (int i5 = 0; i5 < f; i5 += 2) {
                int c = eVar.mo21353c(i5 + 1);
                for (int c2 = eVar.mo21353c(i5); c2 <= c; c2++) {
                    View x = mo4651x(c2 - this.f3170y);
                    if (x != null) {
                        if (z) {
                            mo3392c2(x);
                        }
                        int C1 = this.f3167v == 0 ? mo3346C1(x) : mo3349D1(x);
                        if (C1 > i4) {
                            i4 = C1;
                        }
                    }
                }
            }
            int c3 = this.f3169x.mo5078c();
            if (!this.f3166u.hasFixedSize() && z && i4 < 0 && c3 > 0) {
                if (i2 < 0) {
                    int i6 = this.f3137H;
                    if (i6 < 0) {
                        i6 = 0;
                    } else if (i6 >= c3) {
                        i6 = c3 - 1;
                    }
                    if (mo4966D() > 0) {
                        int layoutPosition = this.f3166u.getChildViewHolder(mo4964C(0)).getLayoutPosition();
                        int layoutPosition2 = this.f3166u.getChildViewHolder(mo4964C(mo4966D() - 1)).getLayoutPosition();
                        if (i >= layoutPosition && i <= layoutPosition2) {
                            i = i - layoutPosition <= layoutPosition2 - i ? layoutPosition - 1 : layoutPosition2 + 1;
                            if (i < 0 && layoutPosition2 < c3 - 1) {
                                i = layoutPosition2 + 1;
                            } else if (i >= c3 && layoutPosition > 0) {
                                i = layoutPosition - 1;
                            }
                        }
                    }
                    if (i >= 0 && i < c3) {
                        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(0, 0);
                        int[] iArr = this.f3160e0;
                        View f2 = this.f3132C.mo5050f(i);
                        if (f2 != null) {
                            LayoutParams layoutParams = (LayoutParams) f2.getLayoutParams();
                            Rect rect = f3128r;
                            mo5000h(f2, rect);
                            f2.measure(ViewGroup.getChildMeasureSpec(makeMeasureSpec, mo4983X() + mo4981W() + layoutParams.leftMargin + layoutParams.rightMargin + rect.left + rect.right, layoutParams.width), ViewGroup.getChildMeasureSpec(makeMeasureSpec2, mo4980V() + mo4985Y() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top + rect.bottom, layoutParams.height));
                            iArr[0] = mo3349D1(f2);
                            iArr[1] = mo3346C1(f2);
                            this.f3132C.mo5053j(f2);
                        }
                        i2 = this.f3167v == 0 ? this.f3160e0[1] : this.f3160e0[0];
                    }
                }
                if (i2 >= 0) {
                    i4 = i2;
                }
            }
            if (i4 < 0) {
                i4 = 0;
            }
            int[] iArr2 = this.f3147R;
            if (iArr2[i3] != i4) {
                iArr2[i3] = i4;
                z2 = true;
            }
        }
        return z2;
    }

    /* renamed from: h2 */
    private void m3204h2() {
        int i = this.f3133D;
        if ((65600 & i) == 65536) {
            C0855q qVar = this.f3155Z;
            int i2 = this.f3137H;
            int i3 = 0;
            if ((i & 262144) == 0) {
                i3 = 0 + this.f3159d0;
            }
            qVar.mo3854o(i2, i3);
        }
    }

    /* renamed from: i2 */
    private void m3205i2() {
        int i = this.f3133D;
        if ((65600 & i) == 65536) {
            C0855q qVar = this.f3155Z;
            int i2 = this.f3137H;
            int i3 = 0;
            if ((i & 262144) != 0) {
                i3 = 0 + this.f3159d0;
            }
            qVar.mo3855p(i2, i3);
        }
    }

    /* renamed from: k2 */
    private void m3206k2(RecyclerView.C1169u uVar, RecyclerView.C1175y yVar) {
        if (!(this.f3132C == null && this.f3169x == null)) {
            Log.e("GridLayoutManager", "Recycler information was not released, bug!");
        }
        this.f3132C = uVar;
        this.f3169x = yVar;
        this.f3170y = 0;
        this.f3171z = 0;
    }

    /* renamed from: l2 */
    private int m3207l2(int i) {
        int i2;
        int i3 = this.f3133D;
        boolean z = true;
        if ((i3 & 64) == 0 && (i3 & 3) != 1 && (i <= 0 ? !(i >= 0 || this.f3157b0.mo3788a().mo3804l() || i >= (i2 = this.f3157b0.mo3788a().mo3796d())) : !(this.f3157b0.mo3788a().mo3803k() || i <= (i2 = this.f3157b0.mo3788a().mo3795c())))) {
            i = i2;
        }
        if (i == 0) {
            return 0;
        }
        int i4 = -i;
        int D = mo4966D();
        if (this.f3167v == 1) {
            for (int i5 = 0; i5 < D; i5++) {
                mo4964C(i5).offsetTopAndBottom(i4);
            }
        } else {
            for (int i6 = 0; i6 < D; i6++) {
                mo4964C(i6).offsetLeftAndRight(i4);
            }
        }
        if ((this.f3133D & 3) == 1) {
            mo3367K2();
            return i;
        }
        int D2 = mo4966D();
        if ((this.f3133D & 262144) == 0 ? i >= 0 : i <= 0) {
            m3210u1();
        } else {
            m3201d2();
        }
        boolean z2 = mo4966D() > D2;
        int D3 = mo4966D();
        if ((262144 & this.f3133D) == 0 ? i >= 0 : i <= 0) {
            m3205i2();
        } else {
            m3204h2();
        }
        if (mo4966D() >= D3) {
            z = false;
        }
        if (z2 || z) {
            m3193J2();
        }
        this.f3166u.invalidate();
        mo3367K2();
        return i;
    }

    /* renamed from: m2 */
    private int m3208m2(int i) {
        int i2 = 0;
        if (i == 0) {
            return 0;
        }
        int i3 = -i;
        int D = mo4966D();
        if (this.f3167v == 0) {
            while (i2 < D) {
                mo4964C(i2).offsetTopAndBottom(i3);
                i2++;
            }
        } else {
            while (i2 < D) {
                mo4964C(i2).offsetLeftAndRight(i3);
                i2++;
            }
        }
        this.f3144O += i;
        m3196L2();
        this.f3166u.invalidate();
        return i;
    }

    /* renamed from: o2 */
    private void m3209o2(View view, View view2, boolean z, int i, int i2) {
        if ((this.f3133D & 64) == 0) {
            int B1 = m3187B1(view);
            int M1 = mo3372M1(view, view2);
            if (!(B1 == this.f3137H && M1 == this.f3138I)) {
                this.f3137H = B1;
                this.f3138I = M1;
                this.f3141L = 0;
                if ((this.f3133D & 3) != 1) {
                    mo3417w1();
                }
                if (this.f3166u.mo3710f()) {
                    this.f3166u.invalidate();
                }
            }
            if (view != null) {
                if (!view.hasFocus() && this.f3166u.hasFocus()) {
                    view.requestFocus();
                }
                if ((this.f3133D & 131072) == 0 && z) {
                    return;
                }
                if (mo3366J1(view, view2, f3129s) || i != 0 || i2 != 0) {
                    int[] iArr = f3129s;
                    int i3 = iArr[0] + i;
                    int i4 = iArr[1] + i2;
                    if ((this.f3133D & 3) == 1) {
                        m3207l2(i3);
                        m3208m2(i4);
                        return;
                    }
                    if (this.f3167v != 0) {
                        int i5 = i3;
                        i3 = i4;
                        i4 = i5;
                    }
                    if (z) {
                        this.f3166u.smoothScrollBy(i3, i4);
                        return;
                    }
                    this.f3166u.scrollBy(i3, i4);
                    mo3419x1();
                }
            }
        }
    }

    /* renamed from: u1 */
    private void m3210u1() {
        this.f3155Z.mo3653b((this.f3133D & 262144) != 0 ? 0 - this.f3171z : this.f3159d0 + 0 + this.f3171z, false);
    }

    /* renamed from: A */
    public RecyclerView.LayoutParams mo3342A(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams ? new LayoutParams((LayoutParams) layoutParams) : layoutParams instanceof RecyclerView.LayoutParams ? new LayoutParams((RecyclerView.LayoutParams) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams) : new LayoutParams(layoutParams);
    }

    /* renamed from: A2 */
    public void mo3343A2(C0802g0 g0Var) {
        if (g0Var == null) {
            this.f3135F = null;
            return;
        }
        ArrayList<C0802g0> arrayList = this.f3135F;
        if (arrayList == null) {
            this.f3135F = new ArrayList<>();
        } else {
            arrayList.clear();
        }
        this.f3135F.add(g0Var);
    }

    /* renamed from: B0 */
    public void mo3344B0(RecyclerView.C1169u uVar, RecyclerView.C1175y yVar, C4791b bVar) {
        int i;
        int i2;
        C0855q qVar;
        C0855q qVar2;
        m3206k2(uVar, yVar);
        int c = yVar.mo5078c();
        boolean z = (this.f3133D & 262144) != 0;
        if (c > 1 && !mo3389Z1(0)) {
            if (Build.VERSION.SDK_INT >= 23) {
                bVar.mo21943b(this.f3167v == 0 ? z ? C4791b.C4792a.f17292l : C4791b.C4792a.f17290j : C4791b.C4792a.f17289i);
            } else {
                bVar.mo21941a(8192);
            }
            bVar.mo21969o0(true);
        }
        if (c > 1 && !mo3389Z1(c - 1)) {
            if (Build.VERSION.SDK_INT >= 23) {
                bVar.mo21943b(this.f3167v == 0 ? z ? C4791b.C4792a.f17290j : C4791b.C4792a.f17292l : C4791b.C4792a.f17291k);
            } else {
                bVar.mo21941a(4096);
            }
            bVar.mo21969o0(true);
        }
        if (this.f3167v != 0 || (qVar2 = this.f3155Z) == null) {
            i = super.mo3391c0(uVar, yVar);
        } else {
            i = qVar2.f3594e;
        }
        if (this.f3167v != 1 || (qVar = this.f3155Z) == null) {
            i2 = super.mo3354F(uVar, yVar);
        } else {
            i2 = qVar.f3594e;
        }
        bVar.mo21935U(C4791b.C4793b.m17481b(i, i2, false, 0));
        m3200b2();
    }

    /* renamed from: B2 */
    public void mo3345B2(int i) {
        if (i == 0 || i == 1) {
            this.f3167v = i;
            this.f3168w = C1222r.m5125b(this, i);
            this.f3157b0.mo3791d(i);
            this.f3158c0.mo3869b(i);
            this.f3133D |= 256;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: C1 */
    public int mo3346C1(View view) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        return mo4967J(view) + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    /* renamed from: C2 */
    public void mo3347C2(int i) {
        if (i >= 0 || i == -2) {
            this.f3145P = i;
            return;
        }
        throw new IllegalArgumentException(C4924a.m17900o("Invalid row height: ", i));
    }

    /* renamed from: D0 */
    public void mo3348D0(RecyclerView.C1169u uVar, RecyclerView.C1175y yVar, View view, C4791b bVar) {
        int i;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (this.f3155Z != null && (layoutParams instanceof LayoutParams)) {
            int a = ((LayoutParams) layoutParams).mo4854a();
            int l = a >= 0 ? this.f3155Z.mo3853l(a) : -1;
            if (l >= 0) {
                int i2 = a / this.f3155Z.f3594e;
                if (this.f3167v == 0) {
                    i = l;
                    l = i2;
                } else {
                    i = i2;
                }
                bVar.mo21936V(C4791b.C4794c.m17482f(i, 1, l, 1, false, false));
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: D1 */
    public int mo3349D1(View view) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        return mo4968K(view) + layoutParams.leftMargin + layoutParams.rightMargin;
    }

    /* renamed from: D2 */
    public void mo3350D2(boolean z) {
        int i;
        int i2 = this.f3133D;
        int i3 = 0;
        if (((i2 & 131072) != 0) != z) {
            int i4 = i2 & -131073;
            if (z) {
                i3 = 131072;
            }
            int i5 = i4 | i3;
            this.f3133D = i5;
            if ((i5 & 131072) != 0 && this.f3156a0 == 0 && (i = this.f3137H) != -1) {
                mo3402n2(i, this.f3138I, true, this.f3142M);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:70:0x00ca A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x00cb  */
    /* renamed from: E0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View mo3351E0(android.view.View r8, int r9) {
        /*
            r7 = this;
            int r0 = r7.f3133D
            r1 = 32768(0x8000, float:4.5918E-41)
            r0 = r0 & r1
            if (r0 == 0) goto L_0x0009
            return r8
        L_0x0009:
            android.view.FocusFinder r0 = android.view.FocusFinder.getInstance()
            r1 = 0
            r2 = 0
            r3 = 2
            r4 = 1
            if (r9 == r3) goto L_0x001d
            if (r9 != r4) goto L_0x0016
            goto L_0x001d
        L_0x0016:
            androidx.leanback.widget.e r1 = r7.f3166u
            android.view.View r0 = r0.findNextFocus(r1, r8, r9)
            goto L_0x0054
        L_0x001d:
            boolean r5 = r7.mo3398j()
            if (r5 == 0) goto L_0x0030
            if (r9 != r3) goto L_0x0028
            r1 = 130(0x82, float:1.82E-43)
            goto L_0x002a
        L_0x0028:
            r1 = 33
        L_0x002a:
            androidx.leanback.widget.e r5 = r7.f3166u
            android.view.View r1 = r0.findNextFocus(r5, r8, r1)
        L_0x0030:
            boolean r5 = r7.mo3397i()
            if (r5 == 0) goto L_0x0053
            int r1 = r7.mo4974R()
            if (r1 != r4) goto L_0x003e
            r1 = 1
            goto L_0x003f
        L_0x003e:
            r1 = 0
        L_0x003f:
            if (r9 != r3) goto L_0x0043
            r5 = 1
            goto L_0x0044
        L_0x0043:
            r5 = 0
        L_0x0044:
            r1 = r1 ^ r5
            if (r1 == 0) goto L_0x004a
            r1 = 66
            goto L_0x004c
        L_0x004a:
            r1 = 17
        L_0x004c:
            androidx.leanback.widget.e r5 = r7.f3166u
            android.view.View r0 = r0.findNextFocus(r5, r8, r1)
            goto L_0x0054
        L_0x0053:
            r0 = r1
        L_0x0054:
            if (r0 == 0) goto L_0x0057
            return r0
        L_0x0057:
            androidx.leanback.widget.e r1 = r7.f3166u
            int r1 = r1.getDescendantFocusability()
            r5 = 393216(0x60000, float:5.51013E-40)
            if (r1 != r5) goto L_0x006c
            androidx.leanback.widget.e r0 = r7.f3166u
            android.view.ViewParent r0 = r0.getParent()
            android.view.View r8 = r0.focusSearch(r8, r9)
            return r8
        L_0x006c:
            int r1 = r7.m3188F1(r9)
            androidx.leanback.widget.e r5 = r7.f3166u
            int r5 = r5.getScrollState()
            if (r5 == 0) goto L_0x007a
            r5 = 1
            goto L_0x007b
        L_0x007a:
            r5 = 0
        L_0x007b:
            r6 = 131072(0x20000, float:1.83671E-40)
            if (r1 != r4) goto L_0x0097
            if (r5 != 0) goto L_0x0087
            int r1 = r7.f3133D
            r1 = r1 & 4096(0x1000, float:5.74E-42)
            if (r1 != 0) goto L_0x0088
        L_0x0087:
            r0 = r8
        L_0x0088:
            int r1 = r7.f3133D
            r1 = r1 & r6
            if (r1 == 0) goto L_0x00c8
            boolean r1 = r7.mo3385W1()
            if (r1 != 0) goto L_0x00c8
            r7.m3202e2(r4)
            goto L_0x00c7
        L_0x0097:
            if (r1 != 0) goto L_0x00b1
            if (r5 != 0) goto L_0x00a1
            int r1 = r7.f3133D
            r1 = r1 & 2048(0x800, float:2.87E-42)
            if (r1 != 0) goto L_0x00a2
        L_0x00a1:
            r0 = r8
        L_0x00a2:
            int r1 = r7.f3133D
            r1 = r1 & r6
            if (r1 == 0) goto L_0x00c8
            boolean r1 = r7.mo3384V1()
            if (r1 != 0) goto L_0x00c8
            r7.m3202e2(r2)
            goto L_0x00c7
        L_0x00b1:
            r2 = 3
            if (r1 != r2) goto L_0x00bd
            if (r5 != 0) goto L_0x00c7
            int r1 = r7.f3133D
            r1 = r1 & 16384(0x4000, float:2.2959E-41)
            if (r1 != 0) goto L_0x00c8
            goto L_0x00c7
        L_0x00bd:
            if (r1 != r3) goto L_0x00c8
            if (r5 != 0) goto L_0x00c7
            int r1 = r7.f3133D
            r1 = r1 & 8192(0x2000, float:1.14794E-41)
            if (r1 != 0) goto L_0x00c8
        L_0x00c7:
            r0 = r8
        L_0x00c8:
            if (r0 == 0) goto L_0x00cb
            return r0
        L_0x00cb:
            androidx.leanback.widget.e r0 = r7.f3166u
            android.view.ViewParent r0 = r0.getParent()
            android.view.View r9 = r0.focusSearch(r8, r9)
            if (r9 == 0) goto L_0x00d8
            return r9
        L_0x00d8:
            if (r8 == 0) goto L_0x00db
            goto L_0x00dd
        L_0x00db:
            androidx.leanback.widget.e r8 = r7.f3166u
        L_0x00dd:
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.GridLayoutManager.mo3351E0(android.view.View, int):android.view.View");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: E1 */
    public <E> E mo3352E1(RecyclerView.C1142b0 b0Var, Class<? extends E> cls) {
        C0831n nVar;
        C0827m a;
        E c = b0Var instanceof C0827m ? ((C0827m) b0Var).mo3767c(cls) : null;
        return (c != null || (nVar = this.f3162g0) == null || (a = nVar.mo3787a(b0Var.getItemViewType())) == null) ? c : a.mo3767c(cls);
    }

    /* renamed from: E2 */
    public void mo3353E2(int i, int i2, boolean z, int i3) {
        if ((this.f3137H != i && i != -1) || i2 != this.f3138I || i3 != this.f3142M) {
            mo3402n2(i, i2, z, i3);
        }
    }

    /* renamed from: F */
    public int mo3354F(RecyclerView.C1169u uVar, RecyclerView.C1175y yVar) {
        C0855q qVar;
        if (this.f3167v != 1 || (qVar = this.f3155Z) == null) {
            return super.mo3354F(uVar, yVar);
        }
        return qVar.f3594e;
    }

    /* renamed from: F0 */
    public void mo3355F0(RecyclerView recyclerView, int i, int i2) {
        C0855q qVar;
        int i3;
        int i4 = this.f3137H;
        if (!(i4 == -1 || (qVar = this.f3155Z) == null || qVar.f3595f < 0 || (i3 = this.f3141L) == Integer.MIN_VALUE || i > i4 + i3)) {
            this.f3141L = i3 + i2;
        }
        this.f3161f0.mo3779a();
    }

    /* renamed from: F2 */
    public void mo3356F2(int i) {
        int i2 = this.f3167v;
        this.f3149T = i;
        if (i2 == 1) {
            this.f3150U = i;
        } else {
            this.f3151V = i;
        }
    }

    /* renamed from: G */
    public int mo3357G(View view) {
        return super.mo3357G(view) - ((LayoutParams) view.getLayoutParams()).f3175h;
    }

    /* renamed from: G0 */
    public void mo3358G0(RecyclerView recyclerView) {
        this.f3141L = 0;
        this.f3161f0.mo3779a();
    }

    /* renamed from: H */
    public void mo3359H(View view, Rect rect) {
        super.mo3359H(view, rect);
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        rect.left += layoutParams.f3172e;
        rect.top += layoutParams.f3173f;
        rect.right -= layoutParams.f3174g;
        rect.bottom -= layoutParams.f3175h;
    }

    /* renamed from: H0 */
    public void mo3360H0(RecyclerView recyclerView, int i, int i2, int i3) {
        int i4;
        int i5;
        int i6 = this.f3137H;
        if (!(i6 == -1 || (i4 = this.f3141L) == Integer.MIN_VALUE)) {
            int i7 = i6 + i4;
            if (i > i7 || i7 >= i + i3) {
                if (i < i7 && i2 > i7 - i3) {
                    i5 = i4 - i3;
                } else if (i > i7 && i2 < i7) {
                    i5 = i4 + i3;
                }
                this.f3141L = i5;
            } else {
                this.f3141L = (i2 - i) + i4;
            }
        }
        this.f3161f0.mo3779a();
    }

    /* renamed from: I */
    public int mo3361I(View view) {
        return super.mo3361I(view) + ((LayoutParams) view.getLayoutParams()).f3172e;
    }

    /* renamed from: I0 */
    public void mo3362I0(RecyclerView recyclerView, int i, int i2) {
        C0855q qVar;
        int i3;
        int i4;
        int i5 = this.f3137H;
        if (!(i5 == -1 || (qVar = this.f3155Z) == null || qVar.f3595f < 0 || (i3 = this.f3141L) == Integer.MIN_VALUE || i > (i4 = i5 + i3))) {
            if (i + i2 > i4) {
                int i6 = (i - i4) + i3;
                this.f3141L = i6;
                this.f3137H = i5 + i6;
                this.f3141L = RecyclerView.UNDEFINED_DURATION;
            } else {
                this.f3141L = i3 - i2;
            }
        }
        this.f3161f0.mo3779a();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: I1 */
    public int mo3363I1(int i) {
        int i2 = 0;
        if ((this.f3133D & 524288) != 0) {
            for (int i3 = this.f3153X - 1; i3 > i; i3--) {
                i2 += m3191H1(i3) + this.f3151V;
            }
            return i2;
        }
        int i4 = 0;
        while (i2 < i) {
            i4 += m3191H1(i2) + this.f3151V;
            i2++;
        }
        return i4;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: I2 */
    public void mo3364I2() {
        int i = 0;
        if (mo4966D() > 0) {
            i = this.f3155Z.f3595f - ((LayoutParams) mo4964C(0).getLayoutParams()).mo4855b();
        }
        this.f3170y = i;
    }

    /* renamed from: J0 */
    public void mo3365J0(RecyclerView recyclerView, int i, int i2) {
        int i3 = i2 + i;
        while (i < i3) {
            this.f3161f0.mo3782d(i);
            i++;
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00f3  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00fa  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0108  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x010a  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x0113 A[ADDED_TO_REGION] */
    /* renamed from: J1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo3366J1(android.view.View r12, android.view.View r13, int[] r14) {
        /*
            r11 = this;
            int r0 = r11.f3156a0
            r1 = 2
            r2 = 0
            r3 = 1
            if (r0 == r3) goto L_0x0040
            if (r0 == r1) goto L_0x0040
            int r0 = r11.m3189G1(r12)
            if (r13 == 0) goto L_0x0029
            int r13 = r11.mo3372M1(r12, r13)
            if (r13 == 0) goto L_0x0029
            android.view.ViewGroup$LayoutParams r1 = r12.getLayoutParams()
            androidx.leanback.widget.GridLayoutManager$LayoutParams r1 = (androidx.leanback.widget.GridLayoutManager.LayoutParams) r1
            int[] r4 = r1.mo3428g()
            r13 = r4[r13]
            int[] r1 = r1.mo3428g()
            r1 = r1[r2]
            int r13 = r13 - r1
            int r0 = r0 + r13
        L_0x0029:
            int r12 = r11.m3194K1(r12)
            int r13 = r11.f3142M
            int r0 = r0 + r13
            if (r0 != 0) goto L_0x003a
            if (r12 == 0) goto L_0x0035
            goto L_0x003a
        L_0x0035:
            r14[r2] = r2
            r14[r3] = r2
            goto L_0x003f
        L_0x003a:
            r14[r2] = r0
            r14[r3] = r12
            r2 = 1
        L_0x003f:
            return r2
        L_0x0040:
            int r13 = r11.m3187B1(r12)
            androidx.recyclerview.widget.r r0 = r11.f3168w
            int r0 = r0.mo5217f(r12)
            androidx.recyclerview.widget.r r4 = r11.f3168w
            int r4 = r4.mo5214c(r12)
            androidx.leanback.widget.n1 r5 = r11.f3157b0
            androidx.leanback.widget.n1$a r5 = r5.mo3788a()
            int r5 = r5.mo3798f()
            androidx.leanback.widget.n1 r6 = r11.f3157b0
            androidx.leanback.widget.n1$a r6 = r6.mo3788a()
            int r6 = r6.mo3794b()
            androidx.leanback.widget.q r7 = r11.f3155Z
            int r7 = r7.mo3853l(r13)
            r8 = 0
            if (r0 >= r5) goto L_0x00b7
            int r0 = r11.f3156a0
            if (r0 != r1) goto L_0x00eb
            r0 = r12
        L_0x0072:
            androidx.leanback.widget.q r9 = r11.f3155Z
            boolean r10 = r9.f3592c
            if (r10 == 0) goto L_0x007b
            r10 = -2147483648(0xffffffff80000000, float:-0.0)
            goto L_0x007e
        L_0x007b:
            r10 = 2147483647(0x7fffffff, float:NaN)
        L_0x007e:
            boolean r9 = r9.mo3659n(r10, r3)
            if (r9 == 0) goto L_0x00b4
            androidx.leanback.widget.q r0 = r11.f3155Z
            int r9 = r0.f3595f
            d.d.e[] r0 = r0.mo3657j(r9, r13)
            r0 = r0[r7]
            int r9 = r0.mo21353c(r2)
            android.view.View r9 = r11.mo4651x(r9)
            int r10 = r11.mo3379S1(r9)
            int r10 = r4 - r10
            if (r10 <= r6) goto L_0x00b2
            int r13 = r0.mo21356f()
            if (r13 <= r1) goto L_0x00af
            int r13 = r0.mo21353c(r1)
            android.view.View r13 = r11.mo4651x(r13)
            r1 = r8
            r8 = r13
            goto L_0x00f1
        L_0x00af:
            r1 = r8
            r8 = r9
            goto L_0x00f1
        L_0x00b2:
            r0 = r9
            goto L_0x0072
        L_0x00b4:
            r1 = r8
            r8 = r0
            goto L_0x00f1
        L_0x00b7:
            int r9 = r6 + r5
            if (r4 <= r9) goto L_0x00f0
            int r4 = r11.f3156a0
            if (r4 != r1) goto L_0x00ee
        L_0x00bf:
            androidx.leanback.widget.q r1 = r11.f3155Z
            int r4 = r1.f3596g
            d.d.e[] r1 = r1.mo3657j(r13, r4)
            r1 = r1[r7]
            int r4 = r1.mo21356f()
            int r4 = r4 - r3
            int r1 = r1.mo21353c(r4)
            android.view.View r1 = r11.mo4651x(r1)
            int r4 = r11.mo3378R1(r1)
            int r4 = r4 - r0
            if (r4 <= r6) goto L_0x00df
            r1 = r8
            goto L_0x00e7
        L_0x00df:
            androidx.leanback.widget.q r4 = r11.f3155Z
            boolean r4 = r4.mo3848a()
            if (r4 != 0) goto L_0x00bf
        L_0x00e7:
            if (r1 == 0) goto L_0x00ea
            goto L_0x00f1
        L_0x00ea:
            r8 = r1
        L_0x00eb:
            r1 = r8
            r8 = r12
            goto L_0x00f1
        L_0x00ee:
            r1 = r12
            goto L_0x00f1
        L_0x00f0:
            r1 = r8
        L_0x00f1:
            if (r8 == 0) goto L_0x00fa
            androidx.recyclerview.widget.r r13 = r11.f3168w
            int r13 = r13.mo5217f(r8)
            goto L_0x0103
        L_0x00fa:
            if (r1 == 0) goto L_0x0105
            androidx.recyclerview.widget.r r13 = r11.f3168w
            int r13 = r13.mo5214c(r1)
            int r5 = r5 + r6
        L_0x0103:
            int r13 = r13 - r5
            goto L_0x0106
        L_0x0105:
            r13 = 0
        L_0x0106:
            if (r8 == 0) goto L_0x010a
            r12 = r8
            goto L_0x010d
        L_0x010a:
            if (r1 == 0) goto L_0x010d
            r12 = r1
        L_0x010d:
            int r12 = r11.m3194K1(r12)
            if (r13 != 0) goto L_0x0115
            if (r12 == 0) goto L_0x011a
        L_0x0115:
            r14[r2] = r13
            r14[r3] = r12
            r2 = 1
        L_0x011a:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.GridLayoutManager.mo3366J1(android.view.View, android.view.View, int[]):boolean");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: K2 */
    public void mo3367K2() {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        if (this.f3169x.mo5078c() != 0) {
            if ((this.f3133D & 262144) == 0) {
                i4 = this.f3155Z.f3596g;
                i = this.f3155Z.f3595f;
                i2 = this.f3169x.mo5078c() - 1;
                i3 = 0;
            } else {
                C0855q qVar = this.f3155Z;
                int i7 = qVar.f3595f;
                i = qVar.f3596g;
                i2 = 0;
                int i8 = i7;
                i3 = this.f3169x.mo5078c() - 1;
                i4 = i8;
            }
            if (i4 >= 0 && i >= 0) {
                boolean z = i4 == i2;
                boolean z2 = i == i3;
                if (z || !this.f3157b0.mo3788a().mo3803k() || z2 || !this.f3157b0.mo3788a().mo3804l()) {
                    int i9 = C4291a.C4299e.API_PRIORITY_OTHER;
                    if (z) {
                        i9 = this.f3155Z.mo3851g(true, f3129s);
                        View x = mo4651x(f3129s[1]);
                        i5 = m3197O1(x);
                        int[] g = ((LayoutParams) x.getLayoutParams()).mo3428g();
                        if (g != null && g.length > 0) {
                            i5 = (g[g.length - 1] - g[0]) + i5;
                        }
                    } else {
                        i5 = C4291a.C4299e.API_PRIORITY_OTHER;
                    }
                    int i10 = RecyclerView.UNDEFINED_DURATION;
                    if (z2) {
                        i10 = this.f3155Z.mo3852i(false, f3129s);
                        i6 = m3197O1(mo4651x(f3129s[1]));
                    } else {
                        i6 = RecyclerView.UNDEFINED_DURATION;
                    }
                    this.f3157b0.mo3788a().mo3812t(i10, i9, i6, i5);
                }
            }
        }
    }

    /* renamed from: L */
    public int mo3368L(View view) {
        return super.mo3368L(view) - ((LayoutParams) view.getLayoutParams()).f3174g;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:108:0x0208, code lost:
        if (((r2 & 262144) != 0) != r3.f3592c) goto L_0x020a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:126:0x02d0, code lost:
        r10 = r4;
        r21 = r5;
        r19 = r11;
        r17 = r12;
        r20 = r13;
        r13 = r2;
        r12 = r3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:140:0x0359, code lost:
        r0 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:291:0x05f3, code lost:
        if (r1 < 0) goto L_0x0627;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:302:0x0625, code lost:
        if (r1 < 0) goto L_0x0627;
     */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x029f  */
    /* JADX WARNING: Removed duplicated region for block: B:155:0x03b0 A[LOOP:5: B:155:0x03b0->B:158:0x03bc, LOOP_START] */
    /* JADX WARNING: Removed duplicated region for block: B:160:0x03c6  */
    /* JADX WARNING: Removed duplicated region for block: B:173:0x03f3 A[LOOP:6: B:173:0x03f3->B:176:0x03ff, LOOP_START] */
    /* JADX WARNING: Removed duplicated region for block: B:194:0x0445  */
    /* JADX WARNING: Removed duplicated region for block: B:218:0x049b  */
    /* JADX WARNING: Removed duplicated region for block: B:219:0x049e  */
    /* JADX WARNING: Removed duplicated region for block: B:221:0x04a1 A[LOOP:9: B:220:0x049f->B:221:0x04a1, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:225:0x04ac  */
    /* JADX WARNING: Removed duplicated region for block: B:230:0x04c4  */
    /* JADX WARNING: Removed duplicated region for block: B:269:0x059d  */
    /* JADX WARNING: Removed duplicated region for block: B:270:0x05a2  */
    /* JADX WARNING: Removed duplicated region for block: B:286:0x05da  */
    /* JADX WARNING: Removed duplicated region for block: B:307:0x0635 A[LOOP:7: B:177:0x0402->B:307:0x0635, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:325:0x0478 A[EDGE_INSN: B:325:0x0478->B:209:0x0478 ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:329:0x045a A[EDGE_INSN: B:329:0x045a->B:200:0x045a ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:98:0x01a3  */
    /* JADX WARNING: Removed duplicated region for block: B:99:0x01ef  */
    /* renamed from: L0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo3369L0(androidx.recyclerview.widget.RecyclerView.C1169u r23, androidx.recyclerview.widget.RecyclerView.C1175y r24) {
        /*
            r22 = this;
            r6 = r22
            int r0 = r6.f3153X
            if (r0 != 0) goto L_0x0007
            return
        L_0x0007:
            int r0 = r24.mo5078c()
            if (r0 >= 0) goto L_0x000e
            return
        L_0x000e:
            int r0 = r6.f3133D
            r0 = r0 & 64
            if (r0 == 0) goto L_0x0021
            int r0 = r22.mo4966D()
            if (r0 <= 0) goto L_0x0021
            int r0 = r6.f3133D
            r0 = r0 | 128(0x80, float:1.794E-43)
            r6.f3133D = r0
            return
        L_0x0021:
            int r0 = r6.f3133D
            r1 = r0 & 512(0x200, float:7.175E-43)
            if (r1 != 0) goto L_0x0034
            r1 = 0
            r6.f3155Z = r1
            r6.f3147R = r1
            r0 = r0 & -1025(0xfffffffffffffbff, float:NaN)
            r6.f3133D = r0
            r22.mo3383V0(r23)
            return
        L_0x0034:
            r0 = r0 & -4
            r7 = 1
            r0 = r0 | r7
            r6.f3133D = r0
            r22.m3206k2(r23, r24)
            boolean r0 = r24.mo5081f()
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            r8 = 0
            if (r0 == 0) goto L_0x00e4
            r22.mo3364I2()
            int r0 = r22.mo4966D()
            androidx.leanback.widget.q r2 = r6.f3155Z
            if (r2 == 0) goto L_0x00da
            if (r0 <= 0) goto L_0x00da
            r2 = 2147483647(0x7fffffff, float:NaN)
            androidx.leanback.widget.e r3 = r6.f3166u
            android.view.View r4 = r6.mo4964C(r8)
            androidx.recyclerview.widget.RecyclerView$b0 r3 = r3.getChildViewHolder(r4)
            int r3 = r3.getOldPosition()
            androidx.leanback.widget.e r4 = r6.f3166u
            int r5 = r0 + -1
            android.view.View r5 = r6.mo4964C(r5)
            androidx.recyclerview.widget.RecyclerView$b0 r4 = r4.getChildViewHolder(r5)
            int r4 = r4.getOldPosition()
        L_0x0074:
            if (r8 >= r0) goto L_0x00cf
            android.view.View r5 = r6.mo4964C(r8)
            android.view.ViewGroup$LayoutParams r7 = r5.getLayoutParams()
            androidx.leanback.widget.GridLayoutManager$LayoutParams r7 = (androidx.leanback.widget.GridLayoutManager.LayoutParams) r7
            androidx.leanback.widget.e r9 = r6.f3166u
            int r9 = r9.getChildAdapterPosition(r5)
            boolean r10 = r7.mo4856c()
            if (r10 != 0) goto L_0x00b8
            boolean r10 = r7.mo4857d()
            if (r10 != 0) goto L_0x00b8
            boolean r10 = r5.isLayoutRequested()
            if (r10 != 0) goto L_0x00b8
            boolean r10 = r5.hasFocus()
            if (r10 != 0) goto L_0x00a6
            int r10 = r6.f3137H
            int r11 = r7.mo4854a()
            if (r10 == r11) goto L_0x00b8
        L_0x00a6:
            boolean r10 = r5.hasFocus()
            if (r10 == 0) goto L_0x00b4
            int r10 = r6.f3137H
            int r7 = r7.mo4854a()
            if (r10 != r7) goto L_0x00b8
        L_0x00b4:
            if (r9 < r3) goto L_0x00b8
            if (r9 <= r4) goto L_0x00cc
        L_0x00b8:
            androidx.recyclerview.widget.r r7 = r6.f3168w
            int r7 = r7.mo5217f(r5)
            int r2 = java.lang.Math.min(r2, r7)
            androidx.recyclerview.widget.r r7 = r6.f3168w
            int r5 = r7.mo5214c(r5)
            int r1 = java.lang.Math.max(r1, r5)
        L_0x00cc:
            int r8 = r8 + 1
            goto L_0x0074
        L_0x00cf:
            if (r1 <= r2) goto L_0x00d4
            int r1 = r1 - r2
            r6.f3171z = r1
        L_0x00d4:
            r22.m3210u1()
            r22.m3201d2()
        L_0x00da:
            int r0 = r6.f3133D
            r0 = r0 & -4
            r6.f3133D = r0
            r22.m3200b2()
            return
        L_0x00e4:
            boolean r0 = r24.mo5082g()
            if (r0 == 0) goto L_0x0118
            android.util.SparseIntArray r0 = r6.f3130A
            r0.clear()
            int r0 = r22.mo4966D()
            r2 = 0
        L_0x00f4:
            if (r2 >= r0) goto L_0x0118
            androidx.leanback.widget.e r3 = r6.f3166u
            android.view.View r4 = r6.mo4964C(r2)
            androidx.recyclerview.widget.RecyclerView$b0 r3 = r3.getChildViewHolder(r4)
            int r3 = r3.getOldPosition()
            if (r3 < 0) goto L_0x0115
            androidx.leanback.widget.q r4 = r6.f3155Z
            androidx.leanback.widget.q$a r4 = r4.mo3658k(r3)
            if (r4 == 0) goto L_0x0115
            android.util.SparseIntArray r5 = r6.f3130A
            int r4 = r4.f3599a
            r5.put(r3, r4)
        L_0x0115:
            int r2 = r2 + 1
            goto L_0x00f4
        L_0x0118:
            boolean r0 = r22.mo5010n0()
            if (r0 != 0) goto L_0x0124
            int r0 = r6.f3156a0
            if (r0 != 0) goto L_0x0124
            r9 = 1
            goto L_0x0125
        L_0x0124:
            r9 = 0
        L_0x0125:
            int r0 = r6.f3137H
            r10 = -1
            if (r0 == r10) goto L_0x0133
            int r2 = r6.f3141L
            if (r2 == r1) goto L_0x0133
            int r0 = r0 + r2
            r6.f3137H = r0
            r6.f3138I = r8
        L_0x0133:
            r6.f3141L = r8
            int r0 = r6.f3137H
            android.view.View r11 = r6.mo4651x(r0)
            int r12 = r6.f3137H
            int r13 = r6.f3138I
            androidx.leanback.widget.e r0 = r6.f3166u
            boolean r14 = r0.hasFocus()
            androidx.leanback.widget.q r0 = r6.f3155Z
            if (r0 == 0) goto L_0x014c
            int r1 = r0.f3595f
            goto L_0x014d
        L_0x014c:
            r1 = -1
        L_0x014d:
            if (r0 == 0) goto L_0x0152
            int r0 = r0.f3596g
            goto L_0x0153
        L_0x0152:
            r0 = -1
        L_0x0153:
            int r2 = r6.f3167v
            if (r2 != 0) goto L_0x0160
            int r2 = r24.mo5079d()
            int r3 = r24.mo5080e()
            goto L_0x0168
        L_0x0160:
            int r3 = r24.mo5079d()
            int r2 = r24.mo5080e()
        L_0x0168:
            r15 = r2
            r5 = r3
            androidx.recyclerview.widget.RecyclerView$y r2 = r6.f3169x
            int r2 = r2.mo5078c()
            if (r2 != 0) goto L_0x0175
            r6.f3137H = r10
            goto L_0x0183
        L_0x0175:
            int r3 = r6.f3137H
            if (r3 < r2) goto L_0x017d
            int r2 = r2 - r7
            r6.f3137H = r2
            goto L_0x0183
        L_0x017d:
            if (r3 != r10) goto L_0x0185
            if (r2 <= 0) goto L_0x0185
            r6.f3137H = r8
        L_0x0183:
            r6.f3138I = r8
        L_0x0185:
            androidx.recyclerview.widget.RecyclerView$y r2 = r6.f3169x
            boolean r2 = r2.mo5077b()
            r16 = 262144(0x40000, float:3.67342E-40)
            if (r2 != 0) goto L_0x01ef
            androidx.leanback.widget.q r2 = r6.f3155Z
            if (r2 == 0) goto L_0x01ef
            int r3 = r2.f3595f
            if (r3 < 0) goto L_0x01ef
            int r3 = r6.f3133D
            r3 = r3 & 256(0x100, float:3.59E-43)
            if (r3 != 0) goto L_0x01ef
            int r2 = r2.f3594e
            int r3 = r6.f3153X
            if (r2 != r3) goto L_0x01ef
            androidx.leanback.widget.n1 r2 = r6.f3157b0
            androidx.leanback.widget.n1$a r2 = r2.f3496c
            int r3 = r22.mo4998g0()
            r2.mo3808p(r3)
            androidx.leanback.widget.n1 r2 = r6.f3157b0
            androidx.leanback.widget.n1$a r2 = r2.f3495b
            int r3 = r22.mo4970O()
            r2.mo3808p(r3)
            androidx.leanback.widget.n1 r2 = r6.f3157b0
            androidx.leanback.widget.n1$a r2 = r2.f3496c
            int r3 = r22.mo4981W()
            int r4 = r22.mo4983X()
            r2.mo3806n(r3, r4)
            androidx.leanback.widget.n1 r2 = r6.f3157b0
            androidx.leanback.widget.n1$a r2 = r2.f3495b
            int r3 = r22.mo4985Y()
            int r4 = r22.mo4980V()
            r2.mo3806n(r3, r4)
            androidx.leanback.widget.n1 r2 = r6.f3157b0
            androidx.leanback.widget.n1$a r2 = r2.mo3788a()
            int r2 = r2.mo3800h()
            r6.f3159d0 = r2
            r22.m3196L2()
            androidx.leanback.widget.q r2 = r6.f3155Z
            int r3 = r6.f3150U
            r2.f3593d = r3
            r2 = 1
            goto L_0x029d
        L_0x01ef:
            int r2 = r6.f3133D
            r2 = r2 & -257(0xfffffffffffffeff, float:NaN)
            r6.f3133D = r2
            androidx.leanback.widget.q r3 = r6.f3155Z
            if (r3 == 0) goto L_0x020a
            int r4 = r6.f3153X
            int r10 = r3.f3594e
            if (r4 != r10) goto L_0x020a
            r2 = r2 & r16
            if (r2 == 0) goto L_0x0205
            r2 = 1
            goto L_0x0206
        L_0x0205:
            r2 = 0
        L_0x0206:
            boolean r3 = r3.f3592c
            if (r2 == r3) goto L_0x022e
        L_0x020a:
            int r2 = r6.f3153X
            if (r2 != r7) goto L_0x0214
            androidx.leanback.widget.b1 r2 = new androidx.leanback.widget.b1
            r2.<init>()
            goto L_0x021d
        L_0x0214:
            androidx.leanback.widget.e1 r3 = new androidx.leanback.widget.e1
            r3.<init>()
            r3.mo3856r(r2)
            r2 = r3
        L_0x021d:
            r6.f3155Z = r2
            androidx.leanback.widget.q$b r3 = r6.f3164i0
            r2.f3591b = r3
            int r3 = r6.f3133D
            r3 = r3 & r16
            if (r3 == 0) goto L_0x022b
            r3 = 1
            goto L_0x022c
        L_0x022b:
            r3 = 0
        L_0x022c:
            r2.f3592c = r3
        L_0x022e:
            androidx.leanback.widget.n1 r2 = r6.f3157b0
            r2.mo3789b()
            androidx.leanback.widget.n1 r2 = r6.f3157b0
            androidx.leanback.widget.n1$a r2 = r2.f3496c
            int r3 = r22.mo4998g0()
            r2.mo3808p(r3)
            androidx.leanback.widget.n1 r2 = r6.f3157b0
            androidx.leanback.widget.n1$a r2 = r2.f3495b
            int r3 = r22.mo4970O()
            r2.mo3808p(r3)
            androidx.leanback.widget.n1 r2 = r6.f3157b0
            androidx.leanback.widget.n1$a r2 = r2.f3496c
            int r3 = r22.mo4981W()
            int r4 = r22.mo4983X()
            r2.mo3806n(r3, r4)
            androidx.leanback.widget.n1 r2 = r6.f3157b0
            androidx.leanback.widget.n1$a r2 = r2.f3495b
            int r3 = r22.mo4985Y()
            int r4 = r22.mo4980V()
            r2.mo3806n(r3, r4)
            androidx.leanback.widget.n1 r2 = r6.f3157b0
            androidx.leanback.widget.n1$a r2 = r2.mo3788a()
            int r2 = r2.mo3800h()
            r6.f3159d0 = r2
            r6.f3144O = r8
            r22.m3196L2()
            androidx.leanback.widget.q r2 = r6.f3155Z
            int r3 = r6.f3150U
            r2.f3593d = r3
            androidx.recyclerview.widget.RecyclerView$u r2 = r6.f3132C
            r6.mo5018u(r2)
            androidx.leanback.widget.q r2 = r6.f3155Z
            r3 = -1
            r2.f3596g = r3
            r2.f3595f = r3
            androidx.leanback.widget.n1 r2 = r6.f3157b0
            androidx.leanback.widget.n1$a r2 = r2.mo3788a()
            r2.mo3802j()
            androidx.leanback.widget.n1 r2 = r6.f3157b0
            androidx.leanback.widget.n1$a r2 = r2.mo3788a()
            r2.mo3801i()
            r2 = 0
        L_0x029d:
            if (r2 == 0) goto L_0x03c6
            int r0 = r6.f3133D
            r0 = r0 | 4
            r6.f3133D = r0
            androidx.leanback.widget.q r0 = r6.f3155Z
            int r1 = r6.f3137H
            r0.f3598i = r1
            int r4 = r22.mo4966D()
            androidx.leanback.widget.q r0 = r6.f3155Z
            int r0 = r0.f3595f
            int r1 = r6.f3133D
            r1 = r1 & -9
            r6.f3133D = r1
            r3 = r0
            r2 = 0
        L_0x02bb:
            if (r2 >= r4) goto L_0x036c
            android.view.View r0 = r6.mo4964C(r2)
            int r1 = r6.m3187B1(r0)
            if (r3 == r1) goto L_0x02c8
            goto L_0x02d0
        L_0x02c8:
            androidx.leanback.widget.q r1 = r6.f3155Z
            androidx.leanback.widget.q$a r1 = r1.mo3658k(r3)
            if (r1 != 0) goto L_0x02dd
        L_0x02d0:
            r10 = r4
            r21 = r5
            r19 = r11
            r17 = r12
            r20 = r13
            r13 = r2
            r12 = r3
            goto L_0x0359
        L_0x02dd:
            int r10 = r1.f3599a
            int r10 = r6.mo3363I1(r10)
            androidx.leanback.widget.n1 r7 = r6.f3157b0
            androidx.leanback.widget.n1$a r7 = r7.mo3790c()
            int r7 = r7.mo3798f()
            int r7 = r7 + r10
            int r10 = r6.f3144O
            int r7 = r7 - r10
            int r10 = r6.mo3379S1(r0)
            android.graphics.Rect r8 = f3128r
            r6.mo3359H(r0, r8)
            r17 = r4
            int r4 = r6.f3167v
            if (r4 != 0) goto L_0x0305
            int r4 = r8.width()
            goto L_0x0309
        L_0x0305:
            int r4 = r8.height()
        L_0x0309:
            r8 = r4
            android.view.ViewGroup$LayoutParams r4 = r0.getLayoutParams()
            androidx.leanback.widget.GridLayoutManager$LayoutParams r4 = (androidx.leanback.widget.GridLayoutManager.LayoutParams) r4
            boolean r4 = r4.mo4858e()
            if (r4 == 0) goto L_0x032a
            int r4 = r6.f3133D
            r4 = r4 | 8
            r6.f3133D = r4
            androidx.recyclerview.widget.RecyclerView$u r4 = r6.f3132C
            r6.mo5019v(r0, r4)
            androidx.recyclerview.widget.RecyclerView$u r0 = r6.f3132C
            android.view.View r0 = r0.mo5050f(r3)
            r6.mo4995e(r0, r2)
        L_0x032a:
            r4 = r0
            r6.mo3392c2(r4)
            int r0 = r6.f3167v
            if (r0 != 0) goto L_0x0337
            int r0 = r6.mo3349D1(r4)
            goto L_0x033b
        L_0x0337:
            int r0 = r6.mo3346C1(r4)
        L_0x033b:
            int r18 = r10 + r0
            int r1 = r1.f3599a
            r19 = r11
            r11 = r0
            r0 = r22
            r20 = r13
            r13 = r2
            r2 = r4
            r4 = r3
            r3 = r10
            r10 = r17
            r17 = r12
            r12 = r4
            r4 = r18
            r21 = r5
            r5 = r7
            r0.mo3390a2(r1, r2, r3, r4, r5)
            if (r8 == r11) goto L_0x035b
        L_0x0359:
            r0 = 1
            goto L_0x0378
        L_0x035b:
            int r2 = r13 + 1
            int r3 = r12 + 1
            r4 = r10
            r12 = r17
            r11 = r19
            r13 = r20
            r5 = r21
            r7 = 1
            r8 = 0
            goto L_0x02bb
        L_0x036c:
            r10 = r4
            r21 = r5
            r19 = r11
            r17 = r12
            r20 = r13
            r13 = r2
            r12 = r3
            r0 = 0
        L_0x0378:
            if (r0 == 0) goto L_0x03bf
            androidx.leanback.widget.q r0 = r6.f3155Z
            int r0 = r0.f3596g
            r1 = -1
            int r4 = r10 + -1
        L_0x0381:
            if (r4 < r13) goto L_0x038f
            android.view.View r1 = r6.mo4964C(r4)
            androidx.recyclerview.widget.RecyclerView$u r2 = r6.f3132C
            r6.mo5019v(r1, r2)
            int r4 = r4 + -1
            goto L_0x0381
        L_0x038f:
            androidx.leanback.widget.q r1 = r6.f3155Z
            r1.mo3690m(r12)
            int r1 = r6.f3133D
            r2 = 65536(0x10000, float:9.18355E-41)
            r1 = r1 & r2
            if (r1 == 0) goto L_0x03b0
            r22.m3210u1()
            int r1 = r6.f3137H
            if (r1 < 0) goto L_0x03bf
            if (r1 > r0) goto L_0x03bf
        L_0x03a4:
            androidx.leanback.widget.q r0 = r6.f3155Z
            int r1 = r0.f3596g
            int r2 = r6.f3137H
            if (r1 >= r2) goto L_0x03bf
            r0.mo3848a()
            goto L_0x03a4
        L_0x03b0:
            androidx.leanback.widget.q r1 = r6.f3155Z
            boolean r1 = r1.mo3848a()
            if (r1 == 0) goto L_0x03bf
            androidx.leanback.widget.q r1 = r6.f3155Z
            int r1 = r1.f3596g
            if (r1 >= r0) goto L_0x03bf
            goto L_0x03b0
        L_0x03bf:
            r22.mo3367K2()
            r22.m3196L2()
            goto L_0x0402
        L_0x03c6:
            r21 = r5
            r19 = r11
            r17 = r12
            r20 = r13
            int r2 = r6.f3133D
            r2 = r2 & -5
            r6.f3133D = r2
            r2 = r2 & -17
            if (r14 == 0) goto L_0x03db
            r3 = 16
            goto L_0x03dc
        L_0x03db:
            r3 = 0
        L_0x03dc:
            r2 = r2 | r3
            r6.f3133D = r2
            if (r9 == 0) goto L_0x03ec
            if (r1 < 0) goto L_0x03e9
            int r2 = r6.f3137H
            if (r2 > r0) goto L_0x03e9
            if (r2 >= r1) goto L_0x03ec
        L_0x03e9:
            int r1 = r6.f3137H
            r0 = r1
        L_0x03ec:
            androidx.leanback.widget.q r2 = r6.f3155Z
            r2.f3598i = r1
            r1 = -1
            if (r0 == r1) goto L_0x0402
        L_0x03f3:
            androidx.leanback.widget.q r1 = r6.f3155Z
            boolean r1 = r1.mo3848a()
            if (r1 == 0) goto L_0x0402
            android.view.View r1 = r6.mo4651x(r0)
            if (r1 != 0) goto L_0x0402
            goto L_0x03f3
        L_0x0402:
            r22.mo3367K2()
            androidx.leanback.widget.q r0 = r6.f3155Z
            int r1 = r0.f3595f
            int r0 = r0.f3596g
            int r2 = -r15
            r3 = r21
            int r4 = -r3
            int r5 = r6.f3137H
            android.view.View r5 = r6.mo4651x(r5)
            if (r5 == 0) goto L_0x041d
            if (r9 == 0) goto L_0x041d
            r7 = 0
            r6.mo3405q2(r5, r7, r2, r4)
        L_0x041d:
            if (r5 == 0) goto L_0x042b
            if (r14 == 0) goto L_0x042b
            boolean r7 = r5.hasFocus()
            if (r7 != 0) goto L_0x042b
            r5.requestFocus()
            goto L_0x0468
        L_0x042b:
            if (r14 != 0) goto L_0x0468
            androidx.leanback.widget.e r7 = r6.f3166u
            boolean r7 = r7.hasFocus()
            if (r7 != 0) goto L_0x0468
            if (r5 == 0) goto L_0x043e
            boolean r7 = r5.hasFocusable()
            if (r7 == 0) goto L_0x043e
            goto L_0x0451
        L_0x043e:
            int r7 = r22.mo4966D()
            r8 = 0
        L_0x0443:
            if (r8 >= r7) goto L_0x045a
            android.view.View r5 = r6.mo4964C(r8)
            if (r5 == 0) goto L_0x0457
            boolean r10 = r5.hasFocusable()
            if (r10 == 0) goto L_0x0457
        L_0x0451:
            androidx.leanback.widget.e r7 = r6.f3166u
            r7.focusableViewAvailable(r5)
            goto L_0x045a
        L_0x0457:
            int r8 = r8 + 1
            goto L_0x0443
        L_0x045a:
            if (r9 == 0) goto L_0x0468
            if (r5 == 0) goto L_0x0468
            boolean r7 = r5.hasFocus()
            if (r7 == 0) goto L_0x0468
            r7 = 0
            r6.mo3405q2(r5, r7, r2, r4)
        L_0x0468:
            r22.m3210u1()
            r22.m3201d2()
            androidx.leanback.widget.q r2 = r6.f3155Z
            int r4 = r2.f3595f
            if (r4 != r1) goto L_0x0635
            int r1 = r2.f3596g
            if (r1 != r0) goto L_0x0635
            r22.m3205i2()
            r22.m3204h2()
            boolean r0 = r24.mo5082g()
            if (r0 == 0) goto L_0x0597
            androidx.recyclerview.widget.RecyclerView$u r0 = r6.f3132C
            java.util.List r0 = r0.mo5049e()
            int r1 = r0.size()
            if (r1 != 0) goto L_0x0492
            goto L_0x0597
        L_0x0492:
            int[] r2 = r6.f3131B
            if (r2 == 0) goto L_0x0499
            int r3 = r2.length
            if (r1 <= r3) goto L_0x04a8
        L_0x0499:
            if (r2 != 0) goto L_0x049e
            r2 = 16
            goto L_0x049f
        L_0x049e:
            int r2 = r2.length
        L_0x049f:
            if (r2 >= r1) goto L_0x04a4
            int r2 = r2 << 1
            goto L_0x049f
        L_0x04a4:
            int[] r2 = new int[r2]
            r6.f3131B = r2
        L_0x04a8:
            r2 = 0
            r3 = 0
        L_0x04aa:
            if (r2 >= r1) goto L_0x04c2
            java.lang.Object r4 = r0.get(r2)
            androidx.recyclerview.widget.RecyclerView$b0 r4 = (androidx.recyclerview.widget.RecyclerView.C1142b0) r4
            int r4 = r4.getAdapterPosition()
            if (r4 < 0) goto L_0x04bf
            int[] r5 = r6.f3131B
            int r7 = r3 + 1
            r5[r3] = r4
            r3 = r7
        L_0x04bf:
            int r2 = r2 + 1
            goto L_0x04aa
        L_0x04c2:
            if (r3 <= 0) goto L_0x0592
            int[] r0 = r6.f3131B
            r1 = 0
            java.util.Arrays.sort(r0, r1, r3)
            androidx.leanback.widget.q r0 = r6.f3155Z
            int[] r2 = r6.f3131B
            android.util.SparseIntArray r4 = r6.f3130A
            int r5 = r0.f3596g
            if (r5 < 0) goto L_0x04d9
            int r7 = java.util.Arrays.binarySearch(r2, r1, r3, r5)
            goto L_0x04da
        L_0x04d9:
            r7 = 0
        L_0x04da:
            if (r7 >= 0) goto L_0x0543
            int r1 = -r7
            r7 = 1
            int r1 = r1 - r7
            boolean r7 = r0.f3592c
            if (r7 == 0) goto L_0x04f8
            androidx.leanback.widget.q$b r7 = r0.f3591b
            androidx.leanback.widget.GridLayoutManager$b r7 = (androidx.leanback.widget.GridLayoutManager.C0743b) r7
            int r7 = r7.mo3444d(r5)
            androidx.leanback.widget.q$b r8 = r0.f3591b
            androidx.leanback.widget.GridLayoutManager$b r8 = (androidx.leanback.widget.GridLayoutManager.C0743b) r8
            int r5 = r8.mo3445e(r5)
            int r7 = r7 - r5
            int r5 = r0.f3593d
            int r7 = r7 - r5
            goto L_0x050c
        L_0x04f8:
            androidx.leanback.widget.q$b r7 = r0.f3591b
            androidx.leanback.widget.GridLayoutManager$b r7 = (androidx.leanback.widget.GridLayoutManager.C0743b) r7
            int r7 = r7.mo3444d(r5)
            androidx.leanback.widget.q$b r8 = r0.f3591b
            androidx.leanback.widget.GridLayoutManager$b r8 = (androidx.leanback.widget.GridLayoutManager.C0743b) r8
            int r5 = r8.mo3445e(r5)
            int r7 = r7 + r5
            int r5 = r0.f3593d
            int r7 = r7 + r5
        L_0x050c:
            r5 = r7
        L_0x050d:
            if (r1 >= r3) goto L_0x0543
            r9 = r2[r1]
            int r7 = r4.get(r9)
            if (r7 >= 0) goto L_0x0519
            r11 = 0
            goto L_0x051a
        L_0x0519:
            r11 = r7
        L_0x051a:
            androidx.leanback.widget.q$b r7 = r0.f3591b
            java.lang.Object[] r8 = r0.f3590a
            androidx.leanback.widget.GridLayoutManager$b r7 = (androidx.leanback.widget.GridLayoutManager.C0743b) r7
            r10 = 1
            int r13 = r7.mo3442b(r9, r10, r8, r10)
            androidx.leanback.widget.q$b r7 = r0.f3591b
            java.lang.Object[] r8 = r0.f3590a
            r10 = 0
            r8 = r8[r10]
            androidx.leanback.widget.GridLayoutManager$b r7 = (androidx.leanback.widget.GridLayoutManager.C0743b) r7
            r10 = r13
            r12 = r5
            r7.mo3441a(r8, r9, r10, r11, r12)
            boolean r7 = r0.f3592c
            if (r7 == 0) goto L_0x053c
            int r5 = r5 - r13
            int r7 = r0.f3593d
            int r5 = r5 - r7
            goto L_0x0540
        L_0x053c:
            int r5 = r5 + r13
            int r7 = r0.f3593d
            int r5 = r5 + r7
        L_0x0540:
            int r1 = r1 + 1
            goto L_0x050d
        L_0x0543:
            int r1 = r0.f3595f
            if (r1 < 0) goto L_0x054d
            r5 = 0
            int r3 = java.util.Arrays.binarySearch(r2, r5, r3, r1)
            goto L_0x054e
        L_0x054d:
            r3 = 0
        L_0x054e:
            if (r3 >= 0) goto L_0x0592
            int r3 = -r3
            int r3 = r3 + -2
            androidx.leanback.widget.q$b r5 = r0.f3591b
            androidx.leanback.widget.GridLayoutManager$b r5 = (androidx.leanback.widget.GridLayoutManager.C0743b) r5
            int r1 = r5.mo3444d(r1)
        L_0x055b:
            if (r3 < 0) goto L_0x0592
            r9 = r2[r3]
            int r5 = r4.get(r9)
            if (r5 >= 0) goto L_0x0567
            r11 = 0
            goto L_0x0568
        L_0x0567:
            r11 = r5
        L_0x0568:
            androidx.leanback.widget.q$b r5 = r0.f3591b
            java.lang.Object[] r7 = r0.f3590a
            androidx.leanback.widget.GridLayoutManager$b r5 = (androidx.leanback.widget.GridLayoutManager.C0743b) r5
            r8 = 1
            r10 = 0
            int r5 = r5.mo3442b(r9, r10, r7, r8)
            boolean r7 = r0.f3592c
            if (r7 == 0) goto L_0x057d
            int r7 = r0.f3593d
            int r1 = r1 + r7
            int r1 = r1 + r5
            goto L_0x0581
        L_0x057d:
            int r7 = r0.f3593d
            int r1 = r1 - r7
            int r1 = r1 - r5
        L_0x0581:
            androidx.leanback.widget.q$b r7 = r0.f3591b
            java.lang.Object[] r8 = r0.f3590a
            r10 = 0
            r8 = r8[r10]
            androidx.leanback.widget.GridLayoutManager$b r7 = (androidx.leanback.widget.GridLayoutManager.C0743b) r7
            r10 = r5
            r12 = r1
            r7.mo3441a(r8, r9, r10, r11, r12)
            int r3 = r3 + -1
            goto L_0x055b
        L_0x0592:
            android.util.SparseIntArray r0 = r6.f3130A
            r0.clear()
        L_0x0597:
            int r0 = r6.f3133D
            r1 = r0 & 1024(0x400, float:1.435E-42)
            if (r1 == 0) goto L_0x05a2
            r0 = r0 & -1025(0xfffffffffffffbff, float:NaN)
            r6.f3133D = r0
            goto L_0x05a5
        L_0x05a2:
            r22.m3193J2()
        L_0x05a5:
            int r0 = r6.f3133D
            r0 = r0 & 4
            if (r0 == 0) goto L_0x05c6
            int r0 = r6.f3137H
            r1 = r17
            if (r0 != r1) goto L_0x05ce
            int r1 = r6.f3138I
            r2 = r20
            if (r1 != r2) goto L_0x05ce
            android.view.View r0 = r6.mo4651x(r0)
            r4 = r19
            if (r0 != r4) goto L_0x05ce
            int r0 = r6.f3133D
            r0 = r0 & 8
            if (r0 == 0) goto L_0x05c6
            goto L_0x05ce
        L_0x05c6:
            int r0 = r6.f3133D
            r0 = r0 & 20
            r5 = 16
            if (r0 != r5) goto L_0x05d1
        L_0x05ce:
            r22.mo3417w1()
        L_0x05d1:
            r22.mo3419x1()
            int r0 = r6.f3133D
            r1 = r0 & 64
            if (r1 == 0) goto L_0x062b
            int r1 = r6.f3167v
            r7 = 1
            if (r1 != r7) goto L_0x05f6
            int r0 = r22.mo4970O()
            int r0 = -r0
            int r1 = r22.mo4966D()
            if (r1 <= 0) goto L_0x0628
            r1 = 0
            android.view.View r1 = r6.mo4964C(r1)
            int r1 = r1.getTop()
            if (r1 >= 0) goto L_0x0628
            goto L_0x0627
        L_0x05f6:
            r0 = r0 & r16
            if (r0 == 0) goto L_0x0611
            int r0 = r22.mo4998g0()
            int r1 = r22.mo4966D()
            if (r1 <= 0) goto L_0x0628
            r8 = 0
            android.view.View r1 = r6.mo4964C(r8)
            int r1 = r1.getRight()
            if (r1 <= r0) goto L_0x0628
            r0 = r1
            goto L_0x0628
        L_0x0611:
            r8 = 0
            int r0 = r22.mo4998g0()
            int r0 = -r0
            int r1 = r22.mo4966D()
            if (r1 <= 0) goto L_0x0628
            android.view.View r1 = r6.mo4964C(r8)
            int r1 = r1.getLeft()
            if (r1 >= 0) goto L_0x0628
        L_0x0627:
            int r0 = r0 + r1
        L_0x0628:
            r6.m3207l2(r0)
        L_0x062b:
            int r0 = r6.f3133D
            r0 = r0 & -4
            r6.f3133D = r0
            r22.m3200b2()
            return
        L_0x0635:
            r21 = r3
            goto L_0x0402
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.GridLayoutManager.mo3369L0(androidx.recyclerview.widget.RecyclerView$u, androidx.recyclerview.widget.RecyclerView$y):void");
    }

    /* renamed from: M */
    public int mo3370M(View view) {
        return super.mo3370M(view) + ((LayoutParams) view.getLayoutParams()).f3173f;
    }

    /* renamed from: M0 */
    public void mo3371M0(RecyclerView.C1175y yVar) {
    }

    /* access modifiers changed from: package-private */
    /* renamed from: M1 */
    public int mo3372M1(View view, View view2) {
        C0873w j;
        if (!(view == null || view2 == null || (j = ((LayoutParams) view.getLayoutParams()).mo3431j()) == null)) {
            C0873w.C0874a[] a = j.mo3883a();
            if (a.length > 1) {
                while (view2 != view) {
                    int id = view2.getId();
                    if (id != -1) {
                        for (int i = 1; i < a.length; i++) {
                            if (a[i].f3639a == id) {
                                return i;
                            }
                        }
                        continue;
                    }
                    view2 = (View) view2.getParent();
                }
            }
        }
        return 0;
    }

    /* JADX WARNING: Removed duplicated region for block: B:49:0x00d2  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x00e6  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00ea  */
    /* renamed from: N0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo3373N0(androidx.recyclerview.widget.RecyclerView.C1169u r7, androidx.recyclerview.widget.RecyclerView.C1175y r8, int r9, int r10) {
        /*
            r6 = this;
            r6.m3206k2(r7, r8)
            int r7 = r6.f3167v
            if (r7 != 0) goto L_0x001c
            int r7 = android.view.View.MeasureSpec.getSize(r9)
            int r8 = android.view.View.MeasureSpec.getSize(r10)
            int r9 = android.view.View.MeasureSpec.getMode(r10)
            int r10 = r6.mo4985Y()
            int r0 = r6.mo4980V()
            goto L_0x0030
        L_0x001c:
            int r8 = android.view.View.MeasureSpec.getSize(r9)
            int r7 = android.view.View.MeasureSpec.getSize(r10)
            int r9 = android.view.View.MeasureSpec.getMode(r9)
            int r10 = r6.mo4981W()
            int r0 = r6.mo4983X()
        L_0x0030:
            int r0 = r0 + r10
            r6.f3148S = r8
            int r10 = r6.f3145P
            r1 = -2
            java.lang.String r2 = "wrong spec"
            r3 = 1073741824(0x40000000, float:2.0)
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            r5 = 1
            if (r10 != r1) goto L_0x0083
            int r8 = r6.f3154Y
            if (r8 != 0) goto L_0x0044
            r8 = 1
        L_0x0044:
            r6.f3153X = r8
            r10 = 0
            r6.f3146Q = r10
            int[] r10 = r6.f3147R
            if (r10 == 0) goto L_0x0050
            int r10 = r10.length
            if (r10 == r8) goto L_0x0054
        L_0x0050:
            int[] r8 = new int[r8]
            r6.f3147R = r8
        L_0x0054:
            androidx.recyclerview.widget.RecyclerView$y r8 = r6.f3169x
            boolean r8 = r8.mo5081f()
            if (r8 == 0) goto L_0x005f
            r6.mo3364I2()
        L_0x005f:
            r6.m3203f2(r5)
            if (r9 == r4) goto L_0x0077
            if (r9 == 0) goto L_0x0072
            if (r9 != r3) goto L_0x006c
            int r8 = r6.f3148S
            goto L_0x00e2
        L_0x006c:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            r7.<init>(r2)
            throw r7
        L_0x0072:
            int r8 = r6.m3195L1()
            goto L_0x00a5
        L_0x0077:
            int r8 = r6.m3195L1()
            int r8 = r8 + r0
            int r9 = r6.f3148S
            int r8 = java.lang.Math.min(r8, r9)
            goto L_0x00e2
        L_0x0083:
            if (r9 == r4) goto L_0x00a7
            if (r9 == 0) goto L_0x0090
            if (r9 != r3) goto L_0x008a
            goto L_0x00a7
        L_0x008a:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            r7.<init>(r2)
            throw r7
        L_0x0090:
            if (r10 != 0) goto L_0x0094
            int r10 = r8 - r0
        L_0x0094:
            r6.f3146Q = r10
            int r8 = r6.f3154Y
            if (r8 != 0) goto L_0x009b
            r8 = 1
        L_0x009b:
            r6.f3153X = r8
            int r10 = r10 * r8
            int r9 = r6.f3151V
            int r8 = r8 - r5
            int r8 = r8 * r9
            int r8 = r8 + r10
        L_0x00a5:
            int r8 = r8 + r0
            goto L_0x00e2
        L_0x00a7:
            int r1 = r6.f3154Y
            if (r1 != 0) goto L_0x00b4
            if (r10 != 0) goto L_0x00b4
            r6.f3153X = r5
            int r10 = r8 - r0
        L_0x00b1:
            r6.f3146Q = r10
            goto L_0x00d0
        L_0x00b4:
            if (r1 != 0) goto L_0x00c1
            r6.f3146Q = r10
            int r1 = r6.f3151V
            int r2 = r8 + r1
            int r10 = r10 + r1
            int r2 = r2 / r10
            r6.f3153X = r2
            goto L_0x00d0
        L_0x00c1:
            r6.f3153X = r1
            if (r10 != 0) goto L_0x00b1
            int r10 = r8 - r0
            int r2 = r6.f3151V
            int r3 = r1 + -1
            int r3 = r3 * r2
            int r10 = r10 - r3
            int r10 = r10 / r1
            goto L_0x00b1
        L_0x00d0:
            if (r9 != r4) goto L_0x00e2
            int r9 = r6.f3146Q
            int r10 = r6.f3153X
            int r9 = r9 * r10
            int r1 = r6.f3151V
            int r10 = r10 - r5
            int r10 = r10 * r1
            int r10 = r10 + r9
            int r10 = r10 + r0
            if (r10 >= r8) goto L_0x00e2
            r8 = r10
        L_0x00e2:
            int r9 = r6.f3167v
            if (r9 != 0) goto L_0x00ea
            r6.mo5005j1(r7, r8)
            goto L_0x00ed
        L_0x00ea:
            r6.mo5005j1(r8, r7)
        L_0x00ed:
            r6.m3200b2()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.GridLayoutManager.mo3373N0(androidx.recyclerview.widget.RecyclerView$u, androidx.recyclerview.widget.RecyclerView$y, int, int):void");
    }

    /* renamed from: N1 */
    public int mo3374N1() {
        return this.f3149T;
    }

    /* renamed from: O0 */
    public boolean mo3375O0(RecyclerView recyclerView, View view, View view2) {
        if ((this.f3133D & 32768) == 0 && m3187B1(view) != -1 && (this.f3133D & 35) == 0) {
            m3209o2(view, view2, true, 0, 0);
        }
        return true;
    }

    /* renamed from: Q0 */
    public void mo3376Q0(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState) parcelable;
            this.f3137H = savedState.f3180a;
            this.f3141L = 0;
            this.f3161f0.mo3780b(savedState.f3181b);
            this.f3133D |= 256;
            mo4991b1();
        }
    }

    /* renamed from: R0 */
    public Parcelable mo3377R0() {
        SavedState savedState = new SavedState();
        savedState.f3180a = this.f3137H;
        Bundle e = this.f3161f0.mo3783e();
        int D = mo4966D();
        for (int i = 0; i < D; i++) {
            View C = mo4964C(i);
            int B1 = m3187B1(C);
            if (B1 != -1) {
                e = this.f3161f0.mo3785g(e, C, B1);
            }
        }
        savedState.f3181b = e;
        return savedState;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: R1 */
    public int mo3378R1(View view) {
        return this.f3168w.mo5214c(view);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: S1 */
    public int mo3379S1(View view) {
        return this.f3168w.mo5217f(view);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0032, code lost:
        if (r5 != false) goto L_0x0034;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0042, code lost:
        if (r5 != false) goto L_0x0037;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0054, code lost:
        if (r7 == p098d.p120g.p130j.p131w.C4791b.C4792a.f17291k.mo21990b()) goto L_0x0034;
     */
    /* renamed from: T0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo3380T0(androidx.recyclerview.widget.RecyclerView.C1169u r5, androidx.recyclerview.widget.RecyclerView.C1175y r6, int r7, android.os.Bundle r8) {
        /*
            r4 = this;
            int r8 = r4.f3133D
            r0 = 131072(0x20000, float:1.83671E-40)
            r8 = r8 & r0
            r0 = 0
            r1 = 1
            if (r8 == 0) goto L_0x000b
            r8 = 1
            goto L_0x000c
        L_0x000b:
            r8 = 0
        L_0x000c:
            if (r8 != 0) goto L_0x000f
            return r1
        L_0x000f:
            r4.m3206k2(r5, r6)
            int r5 = r4.f3133D
            r6 = 262144(0x40000, float:3.67342E-40)
            r5 = r5 & r6
            if (r5 == 0) goto L_0x001b
            r5 = 1
            goto L_0x001c
        L_0x001b:
            r5 = 0
        L_0x001c:
            int r6 = android.os.Build.VERSION.SDK_INT
            r8 = 23
            r2 = 8192(0x2000, float:1.14794E-41)
            r3 = 4096(0x1000, float:5.74E-42)
            if (r6 < r8) goto L_0x0057
            int r6 = r4.f3167v
            if (r6 != 0) goto L_0x0045
            d.g.j.w.b$a r6 = p098d.p120g.p130j.p131w.C4791b.C4792a.f17290j
            int r6 = r6.mo21990b()
            if (r7 != r6) goto L_0x003a
            if (r5 == 0) goto L_0x0037
        L_0x0034:
            r7 = 4096(0x1000, float:5.74E-42)
            goto L_0x0057
        L_0x0037:
            r7 = 8192(0x2000, float:1.14794E-41)
            goto L_0x0057
        L_0x003a:
            d.g.j.w.b$a r6 = p098d.p120g.p130j.p131w.C4791b.C4792a.f17292l
            int r6 = r6.mo21990b()
            if (r7 != r6) goto L_0x0057
            if (r5 == 0) goto L_0x0034
            goto L_0x0037
        L_0x0045:
            d.g.j.w.b$a r5 = p098d.p120g.p130j.p131w.C4791b.C4792a.f17289i
            int r5 = r5.mo21990b()
            if (r7 != r5) goto L_0x004e
            goto L_0x0037
        L_0x004e:
            d.g.j.w.b$a r5 = p098d.p120g.p130j.p131w.C4791b.C4792a.f17291k
            int r5 = r5.mo21990b()
            if (r7 != r5) goto L_0x0057
            goto L_0x0034
        L_0x0057:
            if (r7 == r3) goto L_0x0064
            if (r7 == r2) goto L_0x005c
            goto L_0x006a
        L_0x005c:
            r4.m3202e2(r0)
            r5 = -1
            r4.mo3396g2(r0, r5)
            goto L_0x006a
        L_0x0064:
            r4.m3202e2(r1)
            r4.mo3396g2(r0, r1)
        L_0x006a:
            r4.m3200b2()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.GridLayoutManager.mo3380T0(androidx.recyclerview.widget.RecyclerView$u, androidx.recyclerview.widget.RecyclerView$y, int, android.os.Bundle):boolean");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: T1 */
    public int mo3381T1(View view) {
        Rect rect = f3128r;
        mo3359H(view, rect);
        return this.f3167v == 0 ? rect.width() : rect.height();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: U1 */
    public boolean mo3382U1(RecyclerView recyclerView, int i, Rect rect) {
        int i2;
        int i3;
        int i4 = this.f3156a0;
        if (i4 == 1 || i4 == 2) {
            int D = mo4966D();
            int i5 = -1;
            if ((i & 2) != 0) {
                i5 = D;
                i2 = 0;
                i3 = 1;
            } else {
                i2 = D - 1;
                i3 = -1;
            }
            int f = this.f3157b0.mo3788a().mo3798f();
            int b = this.f3157b0.mo3788a().mo3794b() + f;
            while (i2 != i5) {
                View C = mo4964C(i2);
                if (C.getVisibility() == 0 && this.f3168w.mo5217f(C) >= f && this.f3168w.mo5214c(C) <= b && C.requestFocus(i, rect)) {
                    return true;
                }
                i2 += i3;
            }
            return false;
        }
        View x = mo4651x(this.f3137H);
        if (x != null) {
            return x.requestFocus(i, rect);
        }
        return false;
    }

    /* renamed from: V0 */
    public void mo3383V0(RecyclerView.C1169u uVar) {
        for (int D = mo4966D() - 1; D >= 0; D--) {
            mo4986Y0(D, uVar);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: V1 */
    public boolean mo3384V1() {
        return mo4973Q() == 0 || this.f3166u.findViewHolderForAdapterPosition(0) != null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: W1 */
    public boolean mo3385W1() {
        int Q = mo4973Q();
        return Q == 0 || this.f3166u.findViewHolderForAdapterPosition(Q - 1) != null;
    }

    /* access modifiers changed from: protected */
    /* renamed from: X1 */
    public boolean mo3386X1() {
        return this.f3155Z != null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Y1 */
    public boolean mo3387Y1(int i) {
        int i2;
        C0855q qVar = this.f3155Z;
        if (!(qVar == null || i == -1 || (i2 = qVar.f3595f) < 0)) {
            if (i2 > 0) {
                return true;
            }
            int i3 = qVar.mo3658k(i).f3599a;
            for (int D = mo4966D() - 1; D >= 0; D--) {
                int A1 = m3186A1(D);
                C0855q.C0856a k = this.f3155Z.mo3658k(A1);
                if (k != null && k.f3599a == i3 && A1 < i) {
                    return true;
                }
            }
        }
        return false;
    }

    /* renamed from: Z0 */
    public boolean mo3388Z0(RecyclerView recyclerView, View view, Rect rect, boolean z) {
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: Z1 */
    public boolean mo3389Z1(int i) {
        RecyclerView.C1142b0 findViewHolderForAdapterPosition = this.f3166u.findViewHolderForAdapterPosition(i);
        return findViewHolderForAdapterPosition != null && findViewHolderForAdapterPosition.itemView.getLeft() >= 0 && findViewHolderForAdapterPosition.itemView.getRight() <= this.f3166u.getWidth() && findViewHolderForAdapterPosition.itemView.getTop() >= 0 && findViewHolderForAdapterPosition.itemView.getBottom() <= this.f3166u.getHeight();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a2 */
    public void mo3390a2(int i, View view, int i2, int i3, int i4) {
        int i5;
        int C1 = this.f3167v == 0 ? mo3346C1(view) : mo3349D1(view);
        int i6 = this.f3146Q;
        if (i6 > 0) {
            C1 = Math.min(C1, i6);
        }
        int i7 = this.f3152W;
        int i8 = i7 & 112;
        int absoluteGravity = (this.f3133D & 786432) != 0 ? Gravity.getAbsoluteGravity(i7 & 8388615, 1) : i7 & 7;
        int i9 = this.f3167v;
        if (!((i9 == 0 && i8 == 48) || (i9 == 1 && absoluteGravity == 3))) {
            if ((i9 == 0 && i8 == 80) || (i9 == 1 && absoluteGravity == 5)) {
                i5 = m3191H1(i) - C1;
            } else if ((i9 == 0 && i8 == 16) || (i9 == 1 && absoluteGravity == 1)) {
                i5 = (m3191H1(i) - C1) / 2;
            }
            i4 += i5;
        }
        int i10 = C1 + i4;
        if (this.f3167v != 0) {
            int i11 = i4;
            i4 = i2;
            i2 = i11;
            int i12 = i10;
            i10 = i3;
            i3 = i12;
        }
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        mo5013p0(view, i2, i4, i3, i10);
        Rect rect = f3128r;
        super.mo3359H(view, rect);
        int i13 = i2 - rect.left;
        int i14 = i4 - rect.top;
        int i15 = rect.right - i3;
        layoutParams.f3172e = i13;
        layoutParams.f3173f = i14;
        layoutParams.f3174g = i15;
        layoutParams.f3175h = rect.bottom - i10;
        m3192H2(view);
    }

    /* renamed from: c0 */
    public int mo3391c0(RecyclerView.C1169u uVar, RecyclerView.C1175y yVar) {
        C0855q qVar;
        if (this.f3167v != 0 || (qVar = this.f3155Z) == null) {
            return super.mo3391c0(uVar, yVar);
        }
        return qVar.f3594e;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c2 */
    public void mo3392c2(View view) {
        int i;
        int i2;
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        Rect rect = f3128r;
        mo5000h(view, rect);
        int i3 = layoutParams.leftMargin + layoutParams.rightMargin + rect.left + rect.right;
        int i4 = layoutParams.topMargin + layoutParams.bottomMargin + rect.top + rect.bottom;
        int makeMeasureSpec = this.f3145P == -2 ? View.MeasureSpec.makeMeasureSpec(0, 0) : View.MeasureSpec.makeMeasureSpec(this.f3146Q, 1073741824);
        int i5 = this.f3167v;
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(0, 0);
        if (i5 == 0) {
            i = ViewGroup.getChildMeasureSpec(makeMeasureSpec2, i3, layoutParams.width);
            i2 = ViewGroup.getChildMeasureSpec(makeMeasureSpec, i4, layoutParams.height);
        } else {
            int childMeasureSpec = ViewGroup.getChildMeasureSpec(makeMeasureSpec2, i4, layoutParams.height);
            i = ViewGroup.getChildMeasureSpec(makeMeasureSpec, i3, layoutParams.width);
            i2 = childMeasureSpec;
        }
        view.measure(i, i2);
    }

    /* renamed from: d1 */
    public int mo3393d1(int i, RecyclerView.C1169u uVar, RecyclerView.C1175y yVar) {
        if ((this.f3133D & 512) == 0 || !mo3386X1()) {
            return 0;
        }
        m3206k2(uVar, yVar);
        this.f3133D = (this.f3133D & -4) | 2;
        int l2 = this.f3167v == 0 ? m3207l2(i) : m3208m2(i);
        m3200b2();
        this.f3133D &= -4;
        return l2;
    }

    /* renamed from: e1 */
    public void mo3394e1(int i) {
        mo3353E2(i, 0, false, 0);
    }

    /* renamed from: f1 */
    public int mo3395f1(int i, RecyclerView.C1169u uVar, RecyclerView.C1175y yVar) {
        if ((this.f3133D & 512) == 0 || !mo3386X1()) {
            return 0;
        }
        this.f3133D = (this.f3133D & -4) | 2;
        m3206k2(uVar, yVar);
        int l2 = this.f3167v == 1 ? m3207l2(i) : m3208m2(i);
        m3200b2();
        this.f3133D &= -4;
        return l2;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g2 */
    public int mo3396g2(boolean z, int i) {
        C0855q qVar = this.f3155Z;
        if (qVar == null) {
            return i;
        }
        int i2 = this.f3137H;
        int l = i2 != -1 ? qVar.mo3853l(i2) : -1;
        View view = null;
        int D = mo4966D();
        for (int i3 = 0; i3 < D && i != 0; i3++) {
            int i4 = i > 0 ? i3 : (D - 1) - i3;
            View C = mo4964C(i4);
            if (mo3415v1(C)) {
                int A1 = m3186A1(i4);
                int l2 = this.f3155Z.mo3853l(A1);
                if (l == -1) {
                    i2 = A1;
                    view = C;
                    l = l2;
                } else if (l2 == l && ((i > 0 && A1 > i2) || (i < 0 && A1 < i2))) {
                    i = i > 0 ? i - 1 : i + 1;
                    i2 = A1;
                    view = C;
                }
            }
        }
        if (view != null) {
            if (z) {
                if (mo5003i0()) {
                    this.f3133D |= 32;
                    view.requestFocus();
                    this.f3133D &= -33;
                }
                this.f3137H = i2;
                this.f3138I = 0;
            } else {
                mo3403p2(view, true);
            }
        }
        return i;
    }

    /* renamed from: i */
    public boolean mo3397i() {
        return this.f3167v == 0 || this.f3153X > 1;
    }

    /* renamed from: j */
    public boolean mo3398j() {
        return this.f3167v == 1 || this.f3153X > 1;
    }

    /* renamed from: j2 */
    public void mo3399j2(C0802g0 g0Var) {
        ArrayList<C0802g0> arrayList = this.f3135F;
        if (arrayList != null) {
            arrayList.remove(g0Var);
        }
    }

    /* renamed from: m */
    public void mo3400m(int i, int i2, RecyclerView.C1175y yVar, RecyclerView.C1158o.C1161c cVar) {
        try {
            m3206k2((RecyclerView.C1169u) null, yVar);
            if (this.f3167v != 0) {
                i = i2;
            }
            if (mo4966D() != 0) {
                if (i != 0) {
                    int i3 = 0;
                    if (i >= 0) {
                        i3 = 0 + this.f3159d0;
                    }
                    this.f3155Z.mo3654e(i3, i, cVar);
                    m3200b2();
                }
            }
        } finally {
            m3200b2();
        }
    }

    /* renamed from: n */
    public void mo3401n(int i, RecyclerView.C1158o.C1161c cVar) {
        int i2 = this.f3166u.f3433i;
        if (i != 0 && i2 != 0) {
            int max = Math.max(0, Math.min(this.f3137H - ((i2 - 1) / 2), i - i2));
            int i3 = max;
            while (i3 < i && i3 < max + i2) {
                cVar.mo5028a(i3, 0);
                i3++;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n2 */
    public void mo3402n2(int i, int i2, boolean z, int i3) {
        this.f3142M = i3;
        View x = mo4651x(i);
        boolean z2 = !mo5010n0();
        if (!z2 || this.f3166u.isLayoutRequested() || x == null || m3187B1(x) != i) {
            int i4 = this.f3133D;
            if ((i4 & 512) == 0 || (i4 & 64) != 0) {
                this.f3137H = i;
                this.f3138I = i2;
                this.f3141L = RecyclerView.UNDEFINED_DURATION;
                return;
            } else if (!z || this.f3166u.isLayoutRequested()) {
                if (!z2) {
                    C0744c cVar = this.f3139J;
                    if (cVar != null) {
                        cVar.f3184q = true;
                    }
                    this.f3166u.stopScroll();
                }
                if (this.f3166u.isLayoutRequested() || x == null || m3187B1(x) != i) {
                    this.f3137H = i;
                    this.f3138I = i2;
                    this.f3141L = RecyclerView.UNDEFINED_DURATION;
                    this.f3133D |= 256;
                    mo4991b1();
                    return;
                }
            } else {
                this.f3137H = i;
                this.f3138I = i2;
                this.f3141L = RecyclerView.UNDEFINED_DURATION;
                if (!mo3386X1()) {
                    StringBuilder P = C4924a.m17863P("GridLayoutManager:");
                    P.append(this.f3166u.getId());
                    Log.w(P.toString(), "setSelectionSmooth should not be called before first layout pass");
                    return;
                }
                C0859r rVar = new C0859r(this);
                rVar.mo5069l(i);
                mo3406r1(rVar);
                int e = rVar.mo5064e();
                if (e != this.f3137H) {
                    this.f3137H = e;
                    this.f3138I = 0;
                    return;
                }
                return;
            }
        }
        this.f3133D |= 32;
        mo3403p2(x, z);
        this.f3133D &= -33;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: p2 */
    public void mo3403p2(View view, boolean z) {
        m3209o2(view, view.findFocus(), z, 0, 0);
    }

    /* renamed from: q1 */
    public void mo3404q1(RecyclerView recyclerView, RecyclerView.C1175y yVar, int i) {
        mo3353E2(i, 0, true, 0);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: q2 */
    public void mo3405q2(View view, boolean z, int i, int i2) {
        m3209o2(view, view.findFocus(), z, i, i2);
    }

    /* renamed from: r1 */
    public void mo3406r1(RecyclerView.C1172x xVar) {
        C0744c cVar = this.f3139J;
        if (cVar != null) {
            cVar.f3184q = true;
        }
        super.mo3406r1(xVar);
        if (!xVar.mo5066g() || !(xVar instanceof C0744c)) {
            this.f3139J = null;
        } else {
            C0744c cVar2 = (C0744c) xVar;
            this.f3139J = cVar2;
            if (cVar2 instanceof C0745d) {
                this.f3140K = (C0745d) cVar2;
                return;
            }
        }
        this.f3140K = null;
    }

    /* renamed from: r2 */
    public void mo3407r2(int i) {
        this.f3156a0 = i;
    }

    /* renamed from: s1 */
    public boolean mo3408s1() {
        return true;
    }

    /* renamed from: s2 */
    public void mo3409s2(int i) {
        this.f3152W = i;
    }

    /* renamed from: t0 */
    public void mo3410t0(RecyclerView.C1147g gVar, RecyclerView.C1147g gVar2) {
        if (gVar != null) {
            this.f3155Z = null;
            this.f3147R = null;
            this.f3133D &= -1025;
            this.f3137H = -1;
            this.f3141L = 0;
            this.f3161f0.mo3779a();
        }
        if (gVar2 instanceof C0831n) {
            this.f3162g0 = (C0831n) gVar2;
        } else {
            this.f3162g0 = null;
        }
    }

    /* renamed from: t1 */
    public void mo3411t1(C0802g0 g0Var) {
        if (this.f3135F == null) {
            this.f3135F = new ArrayList<>();
        }
        this.f3135F.add(g0Var);
    }

    /* renamed from: t2 */
    public void mo3412t2(int i) {
        if (this.f3167v == 0) {
            this.f3150U = i;
        } else {
            this.f3151V = i;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x004a  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x004c  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0052  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x0061  */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x011f A[RETURN] */
    /* renamed from: u0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo3413u0(androidx.recyclerview.widget.RecyclerView r18, java.util.ArrayList<android.view.View> r19, int r20, int r21) {
        /*
            r17 = this;
            r0 = r17
            r1 = r19
            r2 = r20
            r3 = r21
            int r4 = r0.f3133D
            r5 = 32768(0x8000, float:4.5918E-41)
            r4 = r4 & r5
            r5 = 1
            if (r4 == 0) goto L_0x0012
            return r5
        L_0x0012:
            boolean r4 = r18.hasFocus()
            if (r4 == 0) goto L_0x0120
            androidx.leanback.widget.GridLayoutManager$d r4 = r0.f3140K
            if (r4 == 0) goto L_0x001d
            return r5
        L_0x001d:
            int r4 = r0.m3188F1(r2)
            android.view.View r7 = r18.findFocus()
            androidx.leanback.widget.e r8 = r0.f3166u
            r9 = -1
            if (r8 == 0) goto L_0x0043
            if (r7 == r8) goto L_0x0043
            android.view.View r7 = r0.mo5021w(r7)
            if (r7 == 0) goto L_0x0043
            int r8 = r17.mo4966D()
            r10 = 0
        L_0x0037:
            if (r10 >= r8) goto L_0x0043
            android.view.View r11 = r0.mo4964C(r10)
            if (r11 != r7) goto L_0x0040
            goto L_0x0044
        L_0x0040:
            int r10 = r10 + 1
            goto L_0x0037
        L_0x0043:
            r10 = -1
        L_0x0044:
            int r7 = r0.m3186A1(r10)
            if (r7 != r9) goto L_0x004c
            r8 = 0
            goto L_0x0050
        L_0x004c:
            android.view.View r8 = r0.mo4651x(r7)
        L_0x0050:
            if (r8 == 0) goto L_0x0055
            r8.addFocusables(r1, r2, r3)
        L_0x0055:
            androidx.leanback.widget.q r11 = r0.f3155Z
            if (r11 == 0) goto L_0x011f
            int r11 = r17.mo4966D()
            if (r11 != 0) goto L_0x0061
            goto L_0x011f
        L_0x0061:
            r11 = 3
            r12 = 2
            if (r4 == r11) goto L_0x0067
            if (r4 != r12) goto L_0x006e
        L_0x0067:
            androidx.leanback.widget.q r13 = r0.f3155Z
            int r13 = r13.f3594e
            if (r13 > r5) goto L_0x006e
            return r5
        L_0x006e:
            androidx.leanback.widget.q r13 = r0.f3155Z
            if (r13 == 0) goto L_0x007b
            if (r8 == 0) goto L_0x007b
            androidx.leanback.widget.q$a r13 = r13.mo3658k(r7)
            int r13 = r13.f3599a
            goto L_0x007c
        L_0x007b:
            r13 = -1
        L_0x007c:
            int r14 = r19.size()
            if (r4 == r5) goto L_0x0087
            if (r4 != r11) goto L_0x0085
            goto L_0x0087
        L_0x0085:
            r15 = -1
            goto L_0x0088
        L_0x0087:
            r15 = 1
        L_0x0088:
            if (r15 <= 0) goto L_0x0093
            int r16 = r17.mo4966D()
            int r16 = r16 + -1
            r6 = r16
            goto L_0x0094
        L_0x0093:
            r6 = 0
        L_0x0094:
            if (r10 != r9) goto L_0x00a0
            if (r15 <= 0) goto L_0x009a
            r9 = 0
            goto L_0x00a2
        L_0x009a:
            int r9 = r17.mo4966D()
            int r9 = r9 - r5
            goto L_0x00a2
        L_0x00a0:
            int r9 = r10 + r15
        L_0x00a2:
            if (r15 <= 0) goto L_0x00a7
            if (r9 > r6) goto L_0x019e
            goto L_0x00a9
        L_0x00a7:
            if (r9 < r6) goto L_0x019e
        L_0x00a9:
            android.view.View r10 = r0.mo4964C(r9)
            int r16 = r10.getVisibility()
            if (r16 != 0) goto L_0x011c
            boolean r16 = r10.hasFocusable()
            if (r16 != 0) goto L_0x00bb
            goto L_0x011c
        L_0x00bb:
            if (r8 != 0) goto L_0x00c8
            r10.addFocusables(r1, r2, r3)
            int r10 = r19.size()
            if (r10 <= r14) goto L_0x011c
            goto L_0x019e
        L_0x00c8:
            int r12 = r0.m3186A1(r9)
            androidx.leanback.widget.q r11 = r0.f3155Z
            androidx.leanback.widget.q$a r11 = r11.mo3658k(r12)
            if (r11 != 0) goto L_0x00d6
        L_0x00d4:
            r12 = 3
            goto L_0x010b
        L_0x00d6:
            if (r4 != r5) goto L_0x00e9
            int r11 = r11.f3599a
            if (r11 != r13) goto L_0x00d4
            if (r12 <= r7) goto L_0x00d4
            r10.addFocusables(r1, r2, r3)
            int r10 = r19.size()
            if (r10 <= r14) goto L_0x00d4
            goto L_0x019e
        L_0x00e9:
            if (r4 != 0) goto L_0x00fc
            int r11 = r11.f3599a
            if (r11 != r13) goto L_0x00d4
            if (r12 >= r7) goto L_0x00d4
            r10.addFocusables(r1, r2, r3)
            int r10 = r19.size()
            if (r10 <= r14) goto L_0x00d4
            goto L_0x019e
        L_0x00fc:
            r12 = 3
            if (r4 != r12) goto L_0x010d
            int r11 = r11.f3599a
            if (r11 != r13) goto L_0x0104
            goto L_0x010b
        L_0x0104:
            if (r11 >= r13) goto L_0x0108
            goto L_0x019e
        L_0x0108:
            r10.addFocusables(r1, r2, r3)
        L_0x010b:
            r12 = 2
            goto L_0x011c
        L_0x010d:
            r12 = 2
            if (r4 != r12) goto L_0x011c
            int r11 = r11.f3599a
            if (r11 != r13) goto L_0x0115
            goto L_0x011c
        L_0x0115:
            if (r11 <= r13) goto L_0x0119
            goto L_0x019e
        L_0x0119:
            r10.addFocusables(r1, r2, r3)
        L_0x011c:
            int r9 = r9 + r15
            r11 = 3
            goto L_0x00a2
        L_0x011f:
            return r5
        L_0x0120:
            int r4 = r19.size()
            int r6 = r0.f3156a0
            if (r6 == 0) goto L_0x0181
            androidx.leanback.widget.n1 r6 = r0.f3157b0
            androidx.leanback.widget.n1$a r6 = r6.mo3788a()
            int r6 = r6.mo3798f()
            androidx.leanback.widget.n1 r7 = r0.f3157b0
            androidx.leanback.widget.n1$a r7 = r7.mo3788a()
            int r7 = r7.mo3794b()
            int r7 = r7 + r6
            int r8 = r17.mo4966D()
            r9 = 0
        L_0x0142:
            if (r9 >= r8) goto L_0x0164
            android.view.View r10 = r0.mo4964C(r9)
            int r11 = r10.getVisibility()
            if (r11 != 0) goto L_0x0161
            androidx.recyclerview.widget.r r11 = r0.f3168w
            int r11 = r11.mo5217f(r10)
            if (r11 < r6) goto L_0x0161
            androidx.recyclerview.widget.r r11 = r0.f3168w
            int r11 = r11.mo5214c(r10)
            if (r11 > r7) goto L_0x0161
            r10.addFocusables(r1, r2, r3)
        L_0x0161:
            int r9 = r9 + 1
            goto L_0x0142
        L_0x0164:
            int r6 = r19.size()
            if (r6 != r4) goto L_0x018c
            int r6 = r17.mo4966D()
            r7 = 0
        L_0x016f:
            if (r7 >= r6) goto L_0x018c
            android.view.View r8 = r0.mo4964C(r7)
            int r9 = r8.getVisibility()
            if (r9 != 0) goto L_0x017e
            r8.addFocusables(r1, r2, r3)
        L_0x017e:
            int r7 = r7 + 1
            goto L_0x016f
        L_0x0181:
            int r6 = r0.f3137H
            android.view.View r6 = r0.mo4651x(r6)
            if (r6 == 0) goto L_0x018c
            r6.addFocusables(r1, r2, r3)
        L_0x018c:
            int r2 = r19.size()
            if (r2 == r4) goto L_0x0193
            return r5
        L_0x0193:
            boolean r2 = r18.isFocusable()
            if (r2 == 0) goto L_0x019e
            r2 = r18
            r1.add(r2)
        L_0x019e:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.GridLayoutManager.mo3413u0(androidx.recyclerview.widget.RecyclerView, java.util.ArrayList, int, int):boolean");
    }

    /* renamed from: u2 */
    public void mo3414u2(int i) {
        this.f3158c0.mo3868a().f3640b = i;
        m3190G2();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: v1 */
    public boolean mo3415v1(View view) {
        return view.getVisibility() == 0 && (!mo5003i0() || view.hasFocusable());
    }

    /* renamed from: v2 */
    public void mo3416v2(float f) {
        this.f3158c0.mo3868a().mo3886b(f);
        m3190G2();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: w1 */
    public void mo3417w1() {
        if (this.f3134E == null) {
            ArrayList<C0802g0> arrayList = this.f3135F;
            if (!(arrayList != null && arrayList.size() > 0)) {
                return;
            }
        }
        int i = this.f3137H;
        View x = i == -1 ? null : mo4651x(i);
        if (x != null) {
            RecyclerView.C1142b0 childViewHolder = this.f3166u.getChildViewHolder(x);
            C0799f0 f0Var = this.f3134E;
            if (f0Var != null) {
                f0Var.mo3642a(this.f3166u, x, this.f3137H, childViewHolder == null ? -1 : childViewHolder.getItemId());
            }
            mo3422y1(this.f3166u, childViewHolder, this.f3137H, this.f3138I);
        } else {
            C0799f0 f0Var2 = this.f3134E;
            if (f0Var2 != null) {
                f0Var2.mo3642a(this.f3166u, (View) null, -1, -1);
            }
            mo3422y1(this.f3166u, (RecyclerView.C1142b0) null, -1, 0);
        }
        if ((this.f3133D & 3) != 1 && !this.f3166u.isLayoutRequested()) {
            int D = mo4966D();
            for (int i2 = 0; i2 < D; i2++) {
                if (mo4964C(i2).isLayoutRequested()) {
                    C0789e eVar = this.f3166u;
                    Runnable runnable = this.f3163h0;
                    int i3 = C4761m.f17241f;
                    eVar.postOnAnimation(runnable);
                    return;
                }
            }
        }
    }

    /* renamed from: w2 */
    public void mo3418w2(boolean z) {
        this.f3158c0.mo3868a().f3642d = z;
        m3190G2();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: x1 */
    public void mo3419x1() {
        ArrayList<C0802g0> arrayList = this.f3135F;
        if (arrayList != null && arrayList.size() > 0) {
            int i = this.f3137H;
            View x = i == -1 ? null : mo4651x(i);
            if (x != null) {
                mo3425z1(this.f3166u, this.f3166u.getChildViewHolder(x), this.f3137H, this.f3138I);
                return;
            }
            C0799f0 f0Var = this.f3134E;
            if (f0Var != null) {
                f0Var.mo3642a(this.f3166u, (View) null, -1, -1);
            }
            mo3425z1(this.f3166u, (RecyclerView.C1142b0) null, -1, 0);
        }
    }

    /* renamed from: x2 */
    public void mo3420x2(int i) {
        this.f3158c0.mo3868a().f3639a = i;
        m3190G2();
    }

    /* renamed from: y */
    public RecyclerView.LayoutParams mo3421y() {
        return new LayoutParams(-2, -2);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: y1 */
    public void mo3422y1(RecyclerView recyclerView, RecyclerView.C1142b0 b0Var, int i, int i2) {
        ArrayList<C0802g0> arrayList = this.f3135F;
        if (arrayList != null) {
            int size = arrayList.size();
            while (true) {
                size--;
                if (size >= 0) {
                    this.f3135F.get(size).mo3059a(recyclerView, b0Var, i, i2);
                } else {
                    return;
                }
            }
        }
    }

    /* renamed from: y2 */
    public void mo3423y2(int i) {
        if (i >= 0) {
            this.f3154Y = i;
            return;
        }
        throw new IllegalArgumentException();
    }

    /* renamed from: z */
    public RecyclerView.LayoutParams mo3424z(Context context, AttributeSet attributeSet) {
        return new LayoutParams(context, attributeSet);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: z1 */
    public void mo3425z1(RecyclerView recyclerView, RecyclerView.C1142b0 b0Var, int i, int i2) {
        ArrayList<C0802g0> arrayList = this.f3135F;
        if (arrayList != null) {
            int size = arrayList.size();
            while (true) {
                size--;
                if (size >= 0) {
                    this.f3135F.get(size).mo3741b(recyclerView, b0Var, i, i2);
                } else {
                    return;
                }
            }
        }
    }

    /* renamed from: z2 */
    public void mo3426z2(C0799f0 f0Var) {
        this.f3134E = f0Var;
    }
}
