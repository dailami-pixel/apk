package androidx.leanback.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import p098d.p140l.C4824a;

class GuidedActionItemContainer extends NonOverlappingLinearLayoutWithForeground {

    /* renamed from: d */
    private boolean f3192d;

    public GuidedActionItemContainer(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public GuidedActionItemContainer(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3192d = true;
    }

    public View focusSearch(View view, int i) {
        if (this.f3192d || !C4824a.m17606b(this, view)) {
            return super.focusSearch(view, i);
        }
        View focusSearch = super.focusSearch(view, i);
        if (C4824a.m17606b(this, focusSearch)) {
            return focusSearch;
        }
        return null;
    }
}
