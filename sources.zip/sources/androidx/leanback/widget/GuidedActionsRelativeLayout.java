package androidx.leanback.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.vidio.android.p195tv.R;

class GuidedActionsRelativeLayout extends RelativeLayout {

    /* renamed from: a */
    private float f3193a;

    /* renamed from: b */
    private boolean f3194b;

    public GuidedActionsRelativeLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public GuidedActionsRelativeLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3194b = false;
        this.f3193a = GuidanceStylingRelativeLayout.m3322a(context);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        this.f3194b = false;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        View findViewById;
        int size = View.MeasureSpec.getSize(i2);
        if (size > 0 && (findViewById = findViewById(R.id.guidedactions_sub_list)) != null) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) findViewById.getLayoutParams();
            if (marginLayoutParams.topMargin < 0 && !this.f3194b) {
                this.f3194b = true;
            }
            if (this.f3194b) {
                marginLayoutParams.topMargin = (int) ((this.f3193a * ((float) size)) / 100.0f);
            }
        }
        super.onMeasure(i, i2);
    }
}
