package androidx.leanback.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Shader;
import android.util.AttributeSet;
import p098d.p140l.C4825b;

public class HorizontalGridView extends C0789e {

    /* renamed from: j */
    private Paint f3195j;

    /* renamed from: k */
    private Bitmap f3196k;

    /* renamed from: l */
    private LinearGradient f3197l;

    /* renamed from: m */
    private int f3198m;

    /* renamed from: n */
    private Bitmap f3199n;

    /* renamed from: o */
    private Rect f3200o;

    public HorizontalGridView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public HorizontalGridView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3195j = new Paint();
        this.f3200o = new Rect();
        this.f3425a.mo3345B2(0);
        mo3709e(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825b.f17415h);
        if (obtainStyledAttributes.peekValue(1) != null) {
            mo3474F(obtainStyledAttributes.getLayoutDimension(1, 0));
        }
        this.f3425a.mo3423y2(obtainStyledAttributes.getInt(0, 1));
        requestLayout();
        obtainStyledAttributes.recycle();
        setLayerType(0, (Paint) null);
        setWillNotDraw(true);
        Paint paint = new Paint();
        this.f3195j = paint;
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
    }

    /* renamed from: E */
    public final void mo3473E(int i) {
        if (this.f3198m != i) {
            this.f3198m = i;
            this.f3197l = i != 0 ? new LinearGradient(0.0f, 0.0f, (float) this.f3198m, 0.0f, 0, -16777216, Shader.TileMode.CLAMP) : null;
            invalidate();
        }
    }

    /* renamed from: F */
    public void mo3474F(int i) {
        this.f3425a.mo3347C2(i);
        requestLayout();
    }

    public void draw(Canvas canvas) {
        this.f3196k = null;
        this.f3199n = null;
        super.draw(canvas);
    }
}
