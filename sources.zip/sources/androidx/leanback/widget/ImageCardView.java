package androidx.leanback.widget;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.vidio.android.p195tv.R;
import p098d.p140l.C4825b;

public class ImageCardView extends BaseCardView {

    /* renamed from: s */
    private ImageView f3201s;

    /* renamed from: t */
    private ViewGroup f3202t;

    /* renamed from: u */
    private TextView f3203u;

    /* renamed from: v */
    private TextView f3204v;

    /* renamed from: w */
    private ImageView f3205w;

    /* renamed from: x */
    private boolean f3206x;

    /* renamed from: y */
    ObjectAnimator f3207y;

    public ImageCardView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.imageCardViewStyle);
    }

    public ImageCardView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        ViewGroup viewGroup;
        TextView textView;
        setFocusable(true);
        setFocusableInTouchMode(true);
        LayoutInflater from = LayoutInflater.from(getContext());
        from.inflate(R.layout.lb_image_card_view, this);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C4825b.f17416i, i, 2131821323);
        int i2 = obtainStyledAttributes.getInt(1, 0);
        boolean z = i2 == 0;
        boolean z2 = (i2 & 1) == 1;
        boolean z3 = (i2 & 2) == 2;
        boolean z4 = (i2 & 4) == 4;
        boolean z5 = !z4 && (i2 & 8) == 8;
        ImageView imageView = (ImageView) findViewById(R.id.main_image);
        this.f3201s = imageView;
        if (imageView.getDrawable() == null) {
            this.f3201s.setVisibility(4);
        }
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this.f3201s, "alpha", new float[]{1.0f});
        this.f3207y = ofFloat;
        ofFloat.setDuration((long) this.f3201s.getResources().getInteger(17694720));
        ViewGroup viewGroup2 = (ViewGroup) findViewById(R.id.info_field);
        this.f3202t = viewGroup2;
        if (z) {
            removeView(viewGroup2);
        } else {
            if (z2) {
                TextView textView2 = (TextView) from.inflate(R.layout.lb_image_card_view_themed_title, viewGroup2, false);
                this.f3203u = textView2;
                this.f3202t.addView(textView2);
            }
            if (z3) {
                TextView textView3 = (TextView) from.inflate(R.layout.lb_image_card_view_themed_content, this.f3202t, false);
                this.f3204v = textView3;
                this.f3202t.addView(textView3);
            }
            if (z4 || z5) {
                ImageView imageView2 = (ImageView) from.inflate(z5 ? R.layout.lb_image_card_view_themed_badge_left : R.layout.lb_image_card_view_themed_badge_right, this.f3202t, false);
                this.f3205w = imageView2;
                this.f3202t.addView(imageView2);
            }
            if (z2 && !z3 && this.f3205w != null) {
                RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.f3203u.getLayoutParams();
                int id = this.f3205w.getId();
                if (z5) {
                    layoutParams.addRule(17, id);
                } else {
                    layoutParams.addRule(16, id);
                }
                this.f3203u.setLayoutParams(layoutParams);
            }
            if (z3) {
                RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) this.f3204v.getLayoutParams();
                if (!z2) {
                    layoutParams2.addRule(10);
                }
                if (z5) {
                    layoutParams2.removeRule(16);
                    layoutParams2.removeRule(20);
                    layoutParams2.addRule(17, this.f3205w.getId());
                }
                this.f3204v.setLayoutParams(layoutParams2);
            }
            ImageView imageView3 = this.f3205w;
            if (imageView3 != null) {
                RelativeLayout.LayoutParams layoutParams3 = (RelativeLayout.LayoutParams) imageView3.getLayoutParams();
                if (z3) {
                    textView = this.f3204v;
                } else {
                    textView = z2 ? this.f3203u : textView;
                    this.f3205w.setLayoutParams(layoutParams3);
                }
                layoutParams3.addRule(8, textView.getId());
                this.f3205w.setLayoutParams(layoutParams3);
            }
            Drawable drawable = obtainStyledAttributes.getDrawable(0);
            if (!(drawable == null || (viewGroup = this.f3202t) == null)) {
                viewGroup.setBackground(drawable);
            }
            ImageView imageView4 = this.f3205w;
            if (imageView4 != null && imageView4.getDrawable() == null) {
                this.f3205w.setVisibility(8);
            }
        }
        obtainStyledAttributes.recycle();
    }

    public boolean hasOverlappingRendering() {
        return false;
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f3206x = true;
        if (this.f3201s.getAlpha() == 0.0f) {
            this.f3201s.setAlpha(0.0f);
            if (this.f3206x) {
                this.f3207y.start();
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        this.f3206x = false;
        this.f3207y.cancel();
        this.f3201s.setAlpha(1.0f);
        super.onDetachedFromWindow();
    }
}
