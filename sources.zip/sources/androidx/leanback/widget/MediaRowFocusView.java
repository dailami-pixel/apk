package androidx.leanback.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import com.vidio.android.p195tv.R;

class MediaRowFocusView extends View {

    /* renamed from: a */
    private final Paint f3216a;

    /* renamed from: b */
    private final RectF f3217b = new RectF();

    /* renamed from: c */
    private int f3218c;

    public MediaRowFocusView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        Paint paint = new Paint();
        paint.setColor(context.getResources().getColor(R.color.lb_playback_media_row_highlight_color));
        this.f3216a = paint;
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int height = getHeight() / 2;
        this.f3218c = height;
        int height2 = ((height * 2) - getHeight()) / 2;
        this.f3217b.set(0.0f, (float) (-height2), (float) getWidth(), (float) (getHeight() + height2));
        RectF rectF = this.f3217b;
        int i = this.f3218c;
        canvas.drawRoundRect(rectF, (float) i, (float) i, this.f3216a);
    }

    public MediaRowFocusView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Paint paint = new Paint();
        paint.setColor(context.getResources().getColor(R.color.lb_playback_media_row_highlight_color));
        this.f3216a = paint;
    }
}
