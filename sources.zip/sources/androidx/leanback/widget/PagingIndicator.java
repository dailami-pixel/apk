package androidx.leanback.widget;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import com.vidio.android.p195tv.R;
import p098d.p140l.C4825b;

public class PagingIndicator extends View {

    /* renamed from: a */
    private static final TimeInterpolator f3223a = new DecelerateInterpolator();

    /* renamed from: b */
    private static final Property<C0750d, Float> f3224b;

    /* renamed from: c */
    private static final Property<C0750d, Float> f3225c;

    /* renamed from: d */
    private static final Property<C0750d, Float> f3226d;

    /* renamed from: e */
    boolean f3227e;

    /* renamed from: f */
    final int f3228f;

    /* renamed from: g */
    final int f3229g;

    /* renamed from: h */
    private final int f3230h;

    /* renamed from: i */
    final int f3231i;

    /* renamed from: j */
    final int f3232j;

    /* renamed from: k */
    private final int f3233k;

    /* renamed from: l */
    private final int f3234l;

    /* renamed from: m */
    private int[] f3235m;

    /* renamed from: n */
    private int[] f3236n;

    /* renamed from: o */
    private int[] f3237o;

    /* renamed from: p */
    int f3238p;

    /* renamed from: q */
    int f3239q;

    /* renamed from: r */
    final Paint f3240r;

    /* renamed from: s */
    final Paint f3241s;

    /* renamed from: t */
    private final AnimatorSet f3242t;

    /* renamed from: u */
    private final AnimatorSet f3243u;

    /* renamed from: v */
    private final AnimatorSet f3244v;

    /* renamed from: w */
    Bitmap f3245w;

    /* renamed from: x */
    Paint f3246x;

    /* renamed from: y */
    final Rect f3247y;

    /* renamed from: z */
    final float f3248z;

    /* renamed from: androidx.leanback.widget.PagingIndicator$a */
    static class C0747a extends Property<C0750d, Float> {
        C0747a(Class cls, String str) {
            super(cls, str);
        }

        public Object get(Object obj) {
            return Float.valueOf(((C0750d) obj).f3249a);
        }

        public void set(Object obj, Object obj2) {
            C0750d dVar = (C0750d) obj;
            dVar.f3249a = ((Float) obj2).floatValue();
            dVar.mo3505a();
            throw null;
        }
    }

    /* renamed from: androidx.leanback.widget.PagingIndicator$b */
    static class C0748b extends Property<C0750d, Float> {
        C0748b(Class cls, String str) {
            super(cls, str);
        }

        public Object get(Object obj) {
            return Float.valueOf(((C0750d) obj).f3251c);
        }

        public void set(Object obj, Object obj2) {
            C0750d dVar = (C0750d) obj;
            float floatValue = ((Float) obj2).floatValue();
            dVar.f3251c = floatValue;
            dVar.f3252d = floatValue / 2.0f;
            throw null;
        }
    }

    /* renamed from: androidx.leanback.widget.PagingIndicator$c */
    static class C0749c extends Property<C0750d, Float> {
        C0749c(Class cls, String str) {
            super(cls, str);
        }

        public Object get(Object obj) {
            return Float.valueOf(((C0750d) obj).f3250b);
        }

        public void set(Object obj, Object obj2) {
            ((C0750d) obj).f3250b = ((Float) obj2).floatValue() * 0.0f * 0.0f;
            throw null;
        }
    }

    /* renamed from: androidx.leanback.widget.PagingIndicator$d */
    public class C0750d {

        /* renamed from: a */
        float f3249a;

        /* renamed from: b */
        float f3250b;

        /* renamed from: c */
        float f3251c;

        /* renamed from: d */
        float f3252d;

        /* renamed from: a */
        public void mo3505a() {
            Math.round(this.f3249a * 255.0f);
            throw null;
        }
    }

    static {
        Class<Float> cls = Float.class;
        f3224b = new C0747a(cls, "alpha");
        f3225c = new C0748b(cls, "diameter");
        f3226d = new C0749c(cls, "translation_x");
    }

    public PagingIndicator(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PagingIndicator(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        AnimatorSet animatorSet = new AnimatorSet();
        this.f3244v = animatorSet;
        Resources resources = getResources();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825b.f17410c, i, 0);
        int e = m3334e(obtainStyledAttributes, 6, R.dimen.lb_page_indicator_dot_radius);
        this.f3229g = e;
        int i2 = e * 2;
        this.f3228f = i2;
        int e2 = m3334e(obtainStyledAttributes, 2, R.dimen.lb_page_indicator_arrow_radius);
        this.f3232j = e2;
        int i3 = e2 * 2;
        this.f3231i = i3;
        this.f3230h = m3334e(obtainStyledAttributes, 5, R.dimen.lb_page_indicator_dot_gap);
        this.f3233k = m3334e(obtainStyledAttributes, 4, R.dimen.lb_page_indicator_arrow_gap);
        int color = obtainStyledAttributes.getColor(3, getResources().getColor(R.color.lb_page_indicator_dot));
        Paint paint = new Paint(1);
        this.f3240r = paint;
        paint.setColor(color);
        this.f3239q = obtainStyledAttributes.getColor(0, getResources().getColor(R.color.lb_page_indicator_arrow_background));
        if (this.f3246x == null && obtainStyledAttributes.hasValue(1)) {
            int color2 = obtainStyledAttributes.getColor(1, 0);
            if (this.f3246x == null) {
                this.f3246x = new Paint();
            }
            this.f3246x.setColorFilter(new PorterDuffColorFilter(color2, PorterDuff.Mode.SRC_IN));
        }
        obtainStyledAttributes.recycle();
        this.f3227e = resources.getConfiguration().getLayoutDirection() == 0;
        int color3 = resources.getColor(R.color.lb_page_indicator_arrow_shadow);
        int dimensionPixelSize = resources.getDimensionPixelSize(R.dimen.lb_page_indicator_arrow_shadow_radius);
        this.f3234l = dimensionPixelSize;
        Paint paint2 = new Paint(1);
        this.f3241s = paint2;
        float dimensionPixelSize2 = (float) resources.getDimensionPixelSize(R.dimen.lb_page_indicator_arrow_shadow_offset);
        paint2.setShadowLayer((float) dimensionPixelSize, dimensionPixelSize2, dimensionPixelSize2, color3);
        this.f3245w = m3335f();
        this.f3247y = new Rect(0, 0, this.f3245w.getWidth(), this.f3245w.getHeight());
        float f = (float) i3;
        this.f3248z = ((float) this.f3245w.getWidth()) / f;
        AnimatorSet animatorSet2 = new AnimatorSet();
        this.f3242t = animatorSet2;
        float f2 = (float) i2;
        animatorSet2.playTogether(new Animator[]{m3331b(0.0f, 1.0f), m3332c(f2, f), m3333d()});
        AnimatorSet animatorSet3 = new AnimatorSet();
        this.f3243u = animatorSet3;
        animatorSet3.playTogether(new Animator[]{m3331b(1.0f, 0.0f), m3332c(f, f2), m3333d()});
        animatorSet.playTogether(new Animator[]{animatorSet2, animatorSet3});
        setLayerType(1, (Paint) null);
    }

    /* renamed from: a */
    private void m3330a() {
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int width = getWidth() - getPaddingRight();
        int i = this.f3229g;
        int i2 = this.f3233k;
        int i3 = i2 * 2;
        int i4 = this.f3230h;
        int i5 = (paddingLeft + width) / 2;
        int[] iArr = new int[0];
        this.f3235m = iArr;
        int[] iArr2 = new int[0];
        this.f3236n = iArr2;
        int[] iArr3 = new int[0];
        this.f3237o = iArr3;
        int i6 = ((i4 * -3) + ((i * 2) + i3)) / 2;
        if (this.f3227e) {
            int i7 = (i5 - i6) + i;
            iArr[0] = (i7 - i4) + i2;
            iArr2[0] = i7;
            iArr3[0] = i3 + (i7 - (i4 * 2));
        } else {
            int i8 = (i6 + i5) - i;
            iArr[0] = (i8 + i4) - i2;
            iArr2[0] = i8;
            iArr3[0] = ((i4 * 2) + i8) - i3;
        }
        this.f3238p = paddingTop + this.f3232j;
        throw null;
    }

    /* renamed from: b */
    private Animator m3331b(float f, float f2) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat((Object) null, f3224b, new float[]{f, f2});
        ofFloat.setDuration(167);
        ofFloat.setInterpolator(f3223a);
        return ofFloat;
    }

    /* renamed from: c */
    private Animator m3332c(float f, float f2) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat((Object) null, f3225c, new float[]{f, f2});
        ofFloat.setDuration(417);
        ofFloat.setInterpolator(f3223a);
        return ofFloat;
    }

    /* renamed from: d */
    private Animator m3333d() {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat((Object) null, f3226d, new float[]{(float) ((-this.f3233k) + this.f3230h), 0.0f});
        ofFloat.setDuration(417);
        ofFloat.setInterpolator(f3223a);
        return ofFloat;
    }

    /* renamed from: e */
    private int m3334e(TypedArray typedArray, int i, int i2) {
        return typedArray.getDimensionPixelOffset(i, getResources().getDimensionPixelOffset(i2));
    }

    /* renamed from: f */
    private Bitmap m3335f() {
        Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), R.drawable.lb_ic_nav_arrow);
        if (this.f3227e) {
            return decodeResource;
        }
        Matrix matrix = new Matrix();
        matrix.preScale(-1.0f, 1.0f);
        return Bitmap.createBitmap(decodeResource, 0, 0, decodeResource.getWidth(), decodeResource.getHeight(), matrix, false);
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int paddingBottom = getPaddingBottom() + getPaddingTop() + this.f3231i + this.f3234l;
        int mode = View.MeasureSpec.getMode(i2);
        if (mode == Integer.MIN_VALUE) {
            paddingBottom = Math.min(paddingBottom, View.MeasureSpec.getSize(i2));
        } else if (mode == 1073741824) {
            paddingBottom = View.MeasureSpec.getSize(i2);
        }
        int paddingRight = getPaddingRight() + (this.f3230h * -3) + (this.f3233k * 2) + (this.f3229g * 2) + getPaddingLeft();
        int mode2 = View.MeasureSpec.getMode(i);
        if (mode2 == Integer.MIN_VALUE) {
            paddingRight = Math.min(paddingRight, View.MeasureSpec.getSize(i));
        } else if (mode2 == 1073741824) {
            paddingRight = View.MeasureSpec.getSize(i);
        }
        setMeasuredDimension(paddingRight, paddingBottom);
    }

    public void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        boolean z = i == 0;
        if (this.f3227e != z) {
            this.f3227e = z;
            this.f3245w = m3335f();
            m3330a();
            throw null;
        }
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        setMeasuredDimension(i, i2);
        m3330a();
        throw null;
    }
}
