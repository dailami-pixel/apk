package androidx.leanback.widget;

import android.content.Context;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import java.util.ArrayList;

class PersistentFocusWrapper extends FrameLayout {

    /* renamed from: a */
    private int f3253a = -1;

    /* renamed from: b */
    private boolean f3254b = true;

    static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0751a();

        /* renamed from: a */
        int f3255a;

        /* renamed from: androidx.leanback.widget.PersistentFocusWrapper$SavedState$a */
        static class C0751a implements Parcelable.Creator<SavedState> {
            C0751a() {
            }

            public Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public Object[] newArray(int i) {
                return new SavedState[i];
            }
        }

        SavedState(Parcel parcel) {
            super(parcel);
            this.f3255a = parcel.readInt();
        }

        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f3255a);
        }
    }

    public PersistentFocusWrapper(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public PersistentFocusWrapper(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        if (!hasFocus()) {
            boolean z = false;
            ViewGroup viewGroup = (ViewGroup) getChildAt(0);
            if ((viewGroup == null ? 0 : viewGroup.getChildCount()) != 0) {
                boolean z2 = this.f3254b;
                if ((z2 && (i == 33 || i == 130)) || (!z2 && (i == 17 || i == 66))) {
                    z = true;
                }
                if (z) {
                    arrayList.add(this);
                    return;
                }
            }
        }
        super.addFocusables(arrayList, i, i2);
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        this.f3253a = savedState.f3255a;
        super.onRestoreInstanceState(savedState.getSuperState());
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.f3255a = this.f3253a;
        return savedState;
    }

    public void requestChildFocus(View view, View view2) {
        super.requestChildFocus(view, view2);
        while (view2 != null && view2.getParent() != view) {
            view2 = (View) view2.getParent();
        }
        this.f3253a = view2 == null ? -1 : ((ViewGroup) view).indexOfChild(view2);
    }

    public boolean requestFocus(int i, Rect rect) {
        int i2;
        int i3 = 0;
        ViewGroup viewGroup = (ViewGroup) getChildAt(0);
        if (viewGroup != null && (i2 = this.f3253a) >= 0) {
            ViewGroup viewGroup2 = (ViewGroup) getChildAt(0);
            if (viewGroup2 != null) {
                i3 = viewGroup2.getChildCount();
            }
            if (i2 < i3 && viewGroup.getChildAt(this.f3253a).requestFocus(i, rect)) {
                return true;
            }
        }
        return super.requestFocus(i, rect);
    }
}
