package androidx.leanback.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.widget.TextView;
import androidx.core.widget.C0502c;
import p098d.p140l.C4825b;

class ResizingTextView extends TextView {

    /* renamed from: a */
    private int f3256a;

    /* renamed from: b */
    private int f3257b;

    /* renamed from: c */
    private boolean f3258c;

    /* renamed from: d */
    private int f3259d;

    /* renamed from: e */
    private int f3260e;

    /* renamed from: f */
    private boolean f3261f;

    /* renamed from: g */
    private int f3262g;

    /* renamed from: h */
    private float f3263h;

    /* renamed from: i */
    private int f3264i;

    /* renamed from: j */
    private int f3265j;

    public ResizingTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    public ResizingTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3261f = false;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825b.f17417j, i, 0);
        try {
            this.f3256a = obtainStyledAttributes.getInt(1, 1);
            this.f3257b = obtainStyledAttributes.getDimensionPixelSize(4, -1);
            this.f3258c = obtainStyledAttributes.getBoolean(0, false);
            this.f3259d = obtainStyledAttributes.getDimensionPixelOffset(3, 0);
            this.f3260e = obtainStyledAttributes.getDimensionPixelOffset(2, 0);
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    /* renamed from: a */
    private void m3337a(int i, int i2) {
        if (isPaddingRelative()) {
            setPaddingRelative(getPaddingStart(), i, getPaddingEnd(), i2);
        } else {
            setPadding(getPaddingLeft(), i, getPaddingRight(), i2);
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x005c  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x009f  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00de  */
    /* JADX WARNING: Removed duplicated region for block: B:47:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r6, int r7) {
        /*
            r5 = this;
            boolean r0 = r5.f3261f
            r1 = 1
            if (r0 != 0) goto L_0x0020
            float r0 = r5.getTextSize()
            int r0 = (int) r0
            r5.f3262g = r0
            float r0 = r5.getLineSpacingExtra()
            r5.f3263h = r0
            int r0 = r5.getPaddingTop()
            r5.f3264i = r0
            int r0 = r5.getPaddingBottom()
            r5.f3265j = r0
            r5.f3261f = r1
        L_0x0020:
            int r0 = r5.f3262g
            float r0 = (float) r0
            r2 = 0
            r5.setTextSize(r2, r0)
            float r0 = r5.f3263h
            float r3 = r5.getLineSpacingMultiplier()
            r5.setLineSpacing(r0, r3)
            int r0 = r5.f3264i
            int r3 = r5.f3265j
            r5.m3337a(r0, r3)
            super.onMeasure(r6, r7)
            android.text.Layout r0 = r5.getLayout()
            if (r0 == 0) goto L_0x0053
            int r3 = r5.f3256a
            r3 = r3 & r1
            if (r3 <= 0) goto L_0x0053
            int r0 = r0.getLineCount()
            int r3 = r5.getMaxLines()
            if (r3 <= r1) goto L_0x0053
            if (r0 != r3) goto L_0x0053
            r0 = 1
            goto L_0x0054
        L_0x0053:
            r0 = 0
        L_0x0054:
            float r3 = r5.getTextSize()
            int r3 = (int) r3
            r4 = -1
            if (r0 == 0) goto L_0x009f
            int r0 = r5.f3257b
            if (r0 == r4) goto L_0x0067
            if (r3 == r0) goto L_0x0067
            float r0 = (float) r0
            r5.setTextSize(r2, r0)
            r2 = 1
        L_0x0067:
            float r0 = r5.f3263h
            int r3 = r5.f3262g
            float r3 = (float) r3
            float r0 = r0 + r3
            int r3 = r5.f3257b
            float r3 = (float) r3
            float r0 = r0 - r3
            boolean r3 = r5.f3258c
            if (r3 == 0) goto L_0x0085
            float r3 = r5.getLineSpacingExtra()
            int r3 = (r3 > r0 ? 1 : (r3 == r0 ? 0 : -1))
            if (r3 == 0) goto L_0x0085
            float r2 = r5.getLineSpacingMultiplier()
            r5.setLineSpacing(r0, r2)
            r2 = 1
        L_0x0085:
            int r0 = r5.f3264i
            int r3 = r5.f3259d
            int r0 = r0 + r3
            int r3 = r5.f3265j
            int r4 = r5.f3260e
            int r3 = r3 + r4
            int r4 = r5.getPaddingTop()
            if (r4 != r0) goto L_0x009b
            int r4 = r5.getPaddingBottom()
            if (r4 == r3) goto L_0x00d3
        L_0x009b:
            r5.m3337a(r0, r3)
            goto L_0x00dc
        L_0x009f:
            int r0 = r5.f3257b
            if (r0 == r4) goto L_0x00ac
            int r0 = r5.f3262g
            if (r3 == r0) goto L_0x00ac
            float r0 = (float) r0
            r5.setTextSize(r2, r0)
            r2 = 1
        L_0x00ac:
            boolean r0 = r5.f3258c
            if (r0 == 0) goto L_0x00c2
            float r0 = r5.getLineSpacingExtra()
            float r3 = r5.f3263h
            int r0 = (r0 > r3 ? 1 : (r0 == r3 ? 0 : -1))
            if (r0 == 0) goto L_0x00c2
            float r0 = r5.getLineSpacingMultiplier()
            r5.setLineSpacing(r3, r0)
            r2 = 1
        L_0x00c2:
            int r0 = r5.getPaddingTop()
            int r3 = r5.f3264i
            if (r0 != r3) goto L_0x00d5
            int r0 = r5.getPaddingBottom()
            int r3 = r5.f3265j
            if (r0 == r3) goto L_0x00d3
            goto L_0x00d5
        L_0x00d3:
            r1 = r2
            goto L_0x00dc
        L_0x00d5:
            int r0 = r5.f3264i
            int r2 = r5.f3265j
            r5.m3337a(r0, r2)
        L_0x00dc:
            if (r1 == 0) goto L_0x00e1
            super.onMeasure(r6, r7)
        L_0x00e1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.ResizingTextView.onMeasure(int, int):void");
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C0502c.m2298h(this, callback));
    }
}
