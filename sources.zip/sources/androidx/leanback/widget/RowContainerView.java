package androidx.leanback.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.vidio.android.p195tv.R;

final class RowContainerView extends LinearLayout {

    /* renamed from: a */
    private ViewGroup f3266a;

    /* renamed from: b */
    private Drawable f3267b;

    /* renamed from: c */
    private boolean f3268c;

    public RowContainerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public RowContainerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3268c = true;
        setOrientation(1);
        LayoutInflater.from(context).inflate(R.layout.lb_row_container, this);
        this.f3266a = (ViewGroup) findViewById(R.id.lb_row_container_header_dock);
        setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
    }

    /* renamed from: a */
    public void mo3523a(View view) {
        if (this.f3266a.indexOfChild(view) < 0) {
            this.f3266a.addView(view, 0);
        }
    }

    /* renamed from: b */
    public void mo3524b(int i) {
        Drawable drawable = this.f3267b;
        if (drawable instanceof ColorDrawable) {
            ((ColorDrawable) drawable.mutate()).setColor(i);
            invalidate();
            return;
        }
        setForeground(new ColorDrawable(i));
    }

    /* renamed from: c */
    public void mo3525c(boolean z) {
        this.f3266a.setVisibility(z ? 0 : 8);
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        Drawable drawable = this.f3267b;
        if (drawable != null) {
            if (this.f3268c) {
                this.f3268c = false;
                drawable.setBounds(0, 0, getWidth(), getHeight());
            }
            this.f3267b.draw(canvas);
        }
    }

    public Drawable getForeground() {
        return this.f3267b;
    }

    public boolean hasOverlappingRendering() {
        return false;
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.f3268c = true;
    }

    public void setForeground(Drawable drawable) {
        this.f3267b = drawable;
        setWillNotDraw(drawable == null);
        invalidate();
    }
}
