package androidx.leanback.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.SparseIntArray;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.leanback.widget.SearchEditText;
import com.appsflyer.oaid.BuildConfig;
import com.vidio.android.p195tv.R;
import java.util.Objects;

public class SearchBar extends RelativeLayout {

    /* renamed from: a */
    static final String f3272a = SearchBar.class.getSimpleName();

    /* renamed from: b */
    SearchEditText f3273b;

    /* renamed from: c */
    SpeechOrbView f3274c;

    /* renamed from: d */
    private ImageView f3275d;

    /* renamed from: e */
    String f3276e;

    /* renamed from: f */
    private String f3277f;

    /* renamed from: g */
    final Handler f3278g;

    /* renamed from: h */
    private final InputMethodManager f3279h;

    /* renamed from: i */
    boolean f3280i;

    /* renamed from: j */
    private Drawable f3281j;

    /* renamed from: k */
    private final int f3282k;

    /* renamed from: l */
    private final int f3283l;

    /* renamed from: m */
    private final int f3284m;

    /* renamed from: n */
    private final int f3285n;

    /* renamed from: o */
    private int f3286o;

    /* renamed from: p */
    private int f3287p;

    /* renamed from: q */
    private int f3288q;

    /* renamed from: r */
    SoundPool f3289r;

    /* renamed from: s */
    SparseIntArray f3290s;

    /* renamed from: t */
    private final Context f3291t;

    /* renamed from: androidx.leanback.widget.SearchBar$a */
    class C0752a implements View.OnFocusChangeListener {
        C0752a() {
        }

        public void onFocusChange(View view, boolean z) {
            SearchBar searchBar = SearchBar.this;
            if (z) {
                searchBar.f3278g.post(new C0875w0(searchBar));
            } else {
                searchBar.mo3539a();
            }
            SearchBar.this.mo3541e(z);
        }
    }

    /* renamed from: androidx.leanback.widget.SearchBar$b */
    class C0753b implements Runnable {
        C0753b() {
        }

        public void run() {
            SearchBar searchBar = SearchBar.this;
            String obj = searchBar.f3273b.getText().toString();
            if (!TextUtils.equals(searchBar.f3276e, obj)) {
                searchBar.f3276e = obj;
            }
        }
    }

    /* renamed from: androidx.leanback.widget.SearchBar$c */
    class C0754c implements TextWatcher {

        /* renamed from: a */
        final /* synthetic */ Runnable f3294a;

        C0754c(Runnable runnable) {
            this.f3294a = runnable;
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            SearchBar searchBar = SearchBar.this;
            Objects.requireNonNull(searchBar);
            searchBar.f3278g.removeCallbacks(this.f3294a);
            SearchBar.this.f3278g.post(this.f3294a);
        }
    }

    /* renamed from: androidx.leanback.widget.SearchBar$d */
    class C0755d implements SearchEditText.C0760a {
        C0755d() {
        }
    }

    /* renamed from: androidx.leanback.widget.SearchBar$e */
    class C0756e implements TextView.OnEditorActionListener {

        /* renamed from: androidx.leanback.widget.SearchBar$e$a */
        class C0757a implements Runnable {
            C0757a() {
            }

            public void run() {
                SearchBar searchBar = SearchBar.this;
                searchBar.f3280i = true;
                searchBar.f3274c.requestFocus();
            }
        }

        C0756e() {
        }

        public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            if (3 == i || i == 0) {
                Objects.requireNonNull(SearchBar.this);
            }
            if (1 == i) {
                Objects.requireNonNull(SearchBar.this);
            }
            if (2 != i) {
                return false;
            }
            SearchBar.this.mo3539a();
            SearchBar.this.f3278g.postDelayed(new C0757a(), 500);
            return true;
        }
    }

    /* renamed from: androidx.leanback.widget.SearchBar$f */
    class C0758f implements View.OnClickListener {
        C0758f() {
        }

        public void onClick(View view) {
            SearchBar searchBar = SearchBar.this;
            if (!searchBar.hasFocus()) {
                searchBar.requestFocus();
            }
        }
    }

    /* renamed from: androidx.leanback.widget.SearchBar$g */
    class C0759g implements View.OnFocusChangeListener {
        C0759g() {
        }

        public void onFocusChange(View view, boolean z) {
            SearchBar searchBar = SearchBar.this;
            if (z) {
                searchBar.mo3539a();
                SearchBar searchBar2 = SearchBar.this;
                if (searchBar2.f3280i) {
                    if (!searchBar2.hasFocus()) {
                        searchBar2.requestFocus();
                    }
                    SearchBar.this.f3280i = false;
                }
            } else {
                searchBar.mo3540c();
            }
            SearchBar.this.mo3541e(z);
        }
    }

    public SearchBar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public SearchBar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3278g = new Handler();
        this.f3280i = false;
        this.f3290s = new SparseIntArray();
        this.f3291t = context;
        Resources resources = getResources();
        LayoutInflater.from(getContext()).inflate(R.layout.lb_search_bar, this, true);
        this.f3288q = getResources().getDimensionPixelSize(R.dimen.lb_search_bar_height);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, this.f3288q);
        layoutParams.addRule(10, -1);
        setLayoutParams(layoutParams);
        setBackgroundColor(0);
        setClipChildren(false);
        this.f3276e = BuildConfig.FLAVOR;
        this.f3279h = (InputMethodManager) context.getSystemService("input_method");
        this.f3283l = resources.getColor(R.color.lb_search_bar_text_speech_mode);
        this.f3282k = resources.getColor(R.color.lb_search_bar_text);
        this.f3287p = resources.getInteger(R.integer.lb_search_bar_speech_mode_background_alpha);
        this.f3286o = resources.getInteger(R.integer.lb_search_bar_text_mode_background_alpha);
        this.f3285n = resources.getColor(R.color.lb_search_bar_hint_speech_mode);
        this.f3284m = resources.getColor(R.color.lb_search_bar_hint);
        AudioManager audioManager = (AudioManager) context.getSystemService("audio");
    }

    /* renamed from: b */
    private boolean m3344b() {
        return this.f3274c.isFocused();
    }

    /* renamed from: d */
    private void m3345d() {
        String string = getResources().getString(R.string.lb_search_bar_hint);
        if (!TextUtils.isEmpty((CharSequence) null)) {
            if (m3344b()) {
                string = getResources().getString(R.string.lb_search_bar_hint_with_title_speech, new Object[]{null});
            } else {
                string = getResources().getString(R.string.lb_search_bar_hint_with_title, new Object[]{null});
            }
        } else if (m3344b()) {
            string = getResources().getString(R.string.lb_search_bar_hint_speech);
        }
        this.f3277f = string;
        SearchEditText searchEditText = this.f3273b;
        if (searchEditText != null) {
            searchEditText.setHint(string);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo3539a() {
        this.f3279h.hideSoftInputFromWindow(this.f3273b.getWindowToken(), 0);
    }

    /* renamed from: c */
    public void mo3540c() {
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo3541e(boolean z) {
        SearchEditText searchEditText;
        int i;
        SearchEditText searchEditText2;
        int i2;
        if (z) {
            this.f3281j.setAlpha(this.f3287p);
            if (m3344b()) {
                searchEditText2 = this.f3273b;
                i2 = this.f3285n;
            } else {
                searchEditText2 = this.f3273b;
                i2 = this.f3283l;
            }
            searchEditText2.setTextColor(i2);
            searchEditText = this.f3273b;
            i = this.f3285n;
        } else {
            this.f3281j.setAlpha(this.f3286o);
            this.f3273b.setTextColor(this.f3282k);
            searchEditText = this.f3273b;
            i = this.f3284m;
        }
        searchEditText.setHintTextColor(i);
        m3345d();
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f3289r = new SoundPool(2, 1, 0);
        Context context = this.f3291t;
        int[] iArr = {R.raw.lb_voice_failure, R.raw.lb_voice_open, R.raw.lb_voice_no_input, R.raw.lb_voice_success};
        for (int i = 0; i < 4; i++) {
            int i2 = iArr[i];
            this.f3290s.put(i2, this.f3289r.load(context, i2, 1));
        }
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        mo3540c();
        this.f3289r.release();
        super.onDetachedFromWindow();
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        super.onFinishInflate();
        this.f3281j = ((RelativeLayout) findViewById(R.id.lb_search_bar_items)).getBackground();
        this.f3273b = (SearchEditText) findViewById(R.id.lb_search_text_editor);
        this.f3275d = (ImageView) findViewById(R.id.lb_search_bar_badge);
        this.f3273b.setOnFocusChangeListener(new C0752a());
        this.f3273b.addTextChangedListener(new C0754c(new C0753b()));
        this.f3273b.mo3555c(new C0755d());
        this.f3273b.setOnEditorActionListener(new C0756e());
        this.f3273b.setPrivateImeOptions("escapeNorth,voiceDismiss");
        SpeechOrbView speechOrbView = (SpeechOrbView) findViewById(R.id.lb_search_bar_speech_orb);
        this.f3274c = speechOrbView;
        speechOrbView.mo3561e(new C0758f());
        this.f3274c.setOnFocusChangeListener(new C0759g());
        mo3541e(hasFocus());
        m3345d();
    }

    public void setNextFocusDownId(int i) {
        this.f3274c.setNextFocusDownId(i);
        this.f3273b.setNextFocusDownId(i);
    }
}
