package androidx.leanback.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import java.util.Objects;

public class SearchEditText extends StreamingTextView {

    /* renamed from: h */
    private C0760a f3301h;

    /* renamed from: androidx.leanback.widget.SearchEditText$a */
    public interface C0760a {
    }

    static {
        Class<SearchEditText> cls = SearchEditText.class;
    }

    public SearchEditText(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 2131821027);
    }

    public SearchEditText(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* renamed from: c */
    public void mo3555c(C0760a aVar) {
        this.f3301h = aVar;
    }

    public boolean onKeyPreIme(int i, KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() != 4) {
            return super.onKeyPreIme(i, keyEvent);
        }
        C0760a aVar = this.f3301h;
        if (aVar == null) {
            return false;
        }
        Objects.requireNonNull(SearchBar.this);
        return false;
    }
}
