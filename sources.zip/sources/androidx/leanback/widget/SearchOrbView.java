package androidx.leanback.widget;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.vidio.android.p195tv.R;
import p098d.p120g.p130j.C4761m;
import p098d.p140l.C4825b;
import p165e.p166a.p167a.p168a.C4924a;

public class SearchOrbView extends FrameLayout implements View.OnClickListener {

    /* renamed from: a */
    private View.OnClickListener f3302a;

    /* renamed from: b */
    private View f3303b;

    /* renamed from: c */
    private View f3304c;

    /* renamed from: d */
    private ImageView f3305d;

    /* renamed from: e */
    private Drawable f3306e;

    /* renamed from: f */
    private C0763c f3307f;

    /* renamed from: g */
    private final float f3308g;

    /* renamed from: h */
    private final int f3309h;

    /* renamed from: i */
    private final int f3310i;

    /* renamed from: j */
    private final float f3311j;

    /* renamed from: k */
    private final float f3312k;

    /* renamed from: l */
    private ValueAnimator f3313l;

    /* renamed from: m */
    private boolean f3314m;

    /* renamed from: n */
    private boolean f3315n;

    /* renamed from: o */
    private final ArgbEvaluator f3316o;

    /* renamed from: p */
    private final ValueAnimator.AnimatorUpdateListener f3317p;

    /* renamed from: q */
    private ValueAnimator f3318q;

    /* renamed from: r */
    private final ValueAnimator.AnimatorUpdateListener f3319r;

    /* renamed from: androidx.leanback.widget.SearchOrbView$a */
    class C0761a implements ValueAnimator.AnimatorUpdateListener {
        C0761a() {
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            SearchOrbView.this.mo3564h(((Integer) valueAnimator.getAnimatedValue()).intValue());
        }
    }

    /* renamed from: androidx.leanback.widget.SearchOrbView$b */
    class C0762b implements ValueAnimator.AnimatorUpdateListener {
        C0762b() {
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            SearchOrbView.this.mo3565i(valueAnimator.getAnimatedFraction());
        }
    }

    /* renamed from: androidx.leanback.widget.SearchOrbView$c */
    public static class C0763c {

        /* renamed from: a */
        public int f3322a;

        /* renamed from: b */
        public int f3323b;

        /* renamed from: c */
        public int f3324c;

        public C0763c(int i, int i2, int i3) {
            this.f3322a = i;
            if (i2 == i) {
                i2 = Color.argb((int) ((((float) Color.alpha(i)) * 0.85f) + 38.25f), (int) ((((float) Color.red(i)) * 0.85f) + 38.25f), (int) ((((float) Color.green(i)) * 0.85f) + 38.25f), (int) ((((float) Color.blue(i)) * 0.85f) + 38.25f));
            }
            this.f3323b = i2;
            this.f3324c = i3;
        }
    }

    public SearchOrbView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.searchOrbViewStyle);
    }

    public SearchOrbView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3316o = new ArgbEvaluator();
        this.f3317p = new C0761a();
        this.f3319r = new C0762b();
        Resources resources = context.getResources();
        View inflate = ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(mo3559c(), this, true);
        this.f3303b = inflate;
        this.f3304c = inflate.findViewById(R.id.search_orb);
        this.f3305d = (ImageView) this.f3303b.findViewById(R.id.icon);
        this.f3308g = context.getResources().getFraction(R.fraction.lb_search_orb_focused_zoom, 1, 1);
        this.f3309h = context.getResources().getInteger(R.integer.lb_search_orb_pulse_duration_ms);
        this.f3310i = context.getResources().getInteger(R.integer.lb_search_orb_scale_duration_ms);
        float dimensionPixelSize = (float) context.getResources().getDimensionPixelSize(R.dimen.lb_search_orb_focused_z);
        this.f3312k = dimensionPixelSize;
        float dimensionPixelSize2 = (float) context.getResources().getDimensionPixelSize(R.dimen.lb_search_orb_unfocused_z);
        this.f3311j = dimensionPixelSize2;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825b.f17418k, i, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(2);
        mo3563g(drawable == null ? resources.getDrawable(R.drawable.lb_ic_in_app_search) : drawable);
        int color = obtainStyledAttributes.getColor(1, resources.getColor(R.color.lb_default_search_color));
        mo3562f(new C0763c(color, obtainStyledAttributes.getColor(0, color), obtainStyledAttributes.getColor(3, 0)));
        obtainStyledAttributes.recycle();
        setFocusable(true);
        setClipChildren(false);
        setOnClickListener(this);
        setSoundEffectsEnabled(false);
        View view = this.f3304c;
        float a = C4924a.m17874a(dimensionPixelSize, dimensionPixelSize2, 0.0f, dimensionPixelSize2);
        int i2 = C4761m.f17241f;
        view.setZ(a);
        this.f3305d.setZ(dimensionPixelSize);
    }

    /* renamed from: j */
    private void m3350j() {
        ValueAnimator valueAnimator = this.f3313l;
        if (valueAnimator != null) {
            valueAnimator.end();
            this.f3313l = null;
        }
        if (this.f3314m && this.f3315n) {
            ValueAnimator ofObject = ValueAnimator.ofObject(this.f3316o, new Object[]{Integer.valueOf(this.f3307f.f3322a), Integer.valueOf(this.f3307f.f3323b), Integer.valueOf(this.f3307f.f3322a)});
            this.f3313l = ofObject;
            ofObject.setRepeatCount(-1);
            this.f3313l.setDuration((long) (this.f3309h * 2));
            this.f3313l.addUpdateListener(this.f3317p);
            this.f3313l.start();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo3557a(boolean z) {
        float f = z ? this.f3308g : 1.0f;
        this.f3303b.animate().scaleX(f).scaleY(f).setDuration((long) this.f3310i).start();
        int i = this.f3310i;
        if (this.f3318q == null) {
            ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{0.0f, 1.0f});
            this.f3318q = ofFloat;
            ofFloat.addUpdateListener(this.f3319r);
        }
        ValueAnimator valueAnimator = this.f3318q;
        if (z) {
            valueAnimator.start();
        } else {
            valueAnimator.reverse();
        }
        this.f3318q.setDuration((long) i);
        this.f3314m = z;
        m3350j();
    }

    /* renamed from: b */
    public void mo3558b(boolean z) {
        this.f3314m = z;
        m3350j();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public int mo3559c() {
        return R.layout.lb_search_orb;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public void mo3560d(float f) {
        this.f3304c.setScaleX(f);
        this.f3304c.setScaleY(f);
    }

    /* renamed from: e */
    public void mo3561e(View.OnClickListener onClickListener) {
        this.f3302a = onClickListener;
    }

    /* renamed from: f */
    public void mo3562f(C0763c cVar) {
        this.f3307f = cVar;
        this.f3305d.setColorFilter(cVar.f3324c);
        if (this.f3313l == null) {
            mo3564h(this.f3307f.f3322a);
            return;
        }
        this.f3314m = true;
        m3350j();
    }

    /* renamed from: g */
    public void mo3563g(Drawable drawable) {
        this.f3306e = drawable;
        this.f3305d.setImageDrawable(drawable);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public void mo3564h(int i) {
        if (this.f3304c.getBackground() instanceof GradientDrawable) {
            ((GradientDrawable) this.f3304c.getBackground()).setColor(i);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public void mo3565i(float f) {
        View view = this.f3304c;
        float f2 = this.f3311j;
        float a = C4924a.m17874a(this.f3312k, f2, f, f2);
        int i = C4761m.f17241f;
        view.setZ(a);
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f3315n = true;
        m3350j();
    }

    public void onClick(View view) {
        View.OnClickListener onClickListener = this.f3302a;
        if (onClickListener != null) {
            onClickListener.onClick(view);
        }
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        this.f3315n = false;
        m3350j();
        super.onDetachedFromWindow();
    }

    /* access modifiers changed from: protected */
    public void onFocusChanged(boolean z, int i, Rect rect) {
        super.onFocusChanged(z, i, rect);
        mo3557a(z);
    }
}
