package androidx.leanback.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import com.vidio.android.p195tv.R;

public final class SeekBar extends View {

    /* renamed from: a */
    private final RectF f3325a = new RectF();

    /* renamed from: b */
    private final RectF f3326b = new RectF();

    /* renamed from: c */
    private final RectF f3327c = new RectF();

    /* renamed from: d */
    private final Paint f3328d;

    /* renamed from: e */
    private final Paint f3329e;

    /* renamed from: f */
    private final Paint f3330f;

    /* renamed from: g */
    private final Paint f3331g;

    /* renamed from: h */
    private int f3332h;

    /* renamed from: i */
    private int f3333i;

    /* renamed from: j */
    private int f3334j;

    /* renamed from: k */
    private int f3335k;

    public SeekBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        Paint paint = new Paint(1);
        this.f3328d = paint;
        Paint paint2 = new Paint(1);
        this.f3329e = paint2;
        Paint paint3 = new Paint(1);
        this.f3330f = paint3;
        Paint paint4 = new Paint(1);
        this.f3331g = paint4;
        setWillNotDraw(false);
        paint3.setColor(-7829368);
        paint.setColor(-3355444);
        paint2.setColor(-65536);
        paint4.setColor(-1);
        this.f3334j = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_transport_progressbar_bar_height);
        this.f3335k = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_transport_progressbar_active_bar_height);
        this.f3333i = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_transport_progressbar_active_radius);
    }

    /* renamed from: a */
    private void m3360a() {
        int i = isFocused() ? this.f3335k : this.f3334j;
        int width = getWidth();
        int height = getHeight();
        int i2 = (height - i) / 2;
        RectF rectF = this.f3327c;
        int i3 = this.f3334j;
        float f = (float) i2;
        float f2 = (float) (height - i2);
        rectF.set((float) (i3 / 2), f, (float) (width - (i3 / 2)), f2);
        int i4 = isFocused() ? this.f3333i : this.f3334j / 2;
        float f3 = (float) 0;
        float f4 = (f3 / f3) * ((float) (width - (i4 * 2)));
        RectF rectF2 = this.f3325a;
        int i5 = this.f3334j;
        rectF2.set((float) (i5 / 2), f, ((float) (i5 / 2)) + f4, f2);
        this.f3326b.set(this.f3325a.right, f, ((float) (this.f3334j / 2)) + f4, f2);
        this.f3332h = i4 + ((int) f4);
        invalidate();
    }

    public CharSequence getAccessibilityClassName() {
        return android.widget.SeekBar.class.getName();
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float f = (float) (isFocused() ? this.f3333i : this.f3334j / 2);
        canvas.drawRoundRect(this.f3327c, f, f, this.f3330f);
        RectF rectF = this.f3326b;
        if (rectF.right > rectF.left) {
            canvas.drawRoundRect(rectF, f, f, this.f3328d);
        }
        canvas.drawRoundRect(this.f3325a, f, f, this.f3329e);
        canvas.drawCircle((float) this.f3332h, (float) (getHeight() / 2), f, this.f3331g);
    }

    /* access modifiers changed from: protected */
    public void onFocusChanged(boolean z, int i, Rect rect) {
        super.onFocusChanged(z, i, rect);
        m3360a();
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        m3360a();
    }

    public boolean performAccessibilityAction(int i, Bundle bundle) {
        return super.performAccessibilityAction(i, bundle);
    }
}
