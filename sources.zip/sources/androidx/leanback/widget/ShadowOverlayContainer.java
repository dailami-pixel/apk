package androidx.leanback.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.vidio.android.p195tv.R;

public class ShadowOverlayContainer extends FrameLayout {

    /* renamed from: a */
    private static final Rect f3336a = new Rect();

    /* renamed from: b */
    public static final /* synthetic */ int f3337b = 0;

    /* renamed from: c */
    private boolean f3338c;

    /* renamed from: d */
    private Object f3339d;

    /* renamed from: e */
    private View f3340e;

    /* renamed from: f */
    private boolean f3341f;

    /* renamed from: g */
    private int f3342g;

    /* renamed from: h */
    private float f3343h;

    /* renamed from: i */
    private float f3344i;

    /* renamed from: j */
    private int f3345j;

    /* renamed from: k */
    private Paint f3346k;

    /* renamed from: l */
    int f3347l;

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0054  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x006d  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    ShadowOverlayContainer(android.content.Context r3, int r4, boolean r5, float r6, float r7, int r8) {
        /*
            r2 = this;
            r2.<init>(r3)
            r3 = 1
            r2.f3342g = r3
            r2.f3343h = r6
            r2.f3344i = r7
            boolean r0 = r2.f3338c
            if (r0 != 0) goto L_0x0074
            r2.f3338c = r3
            r2.f3345j = r8
            r0 = 0
            if (r8 <= 0) goto L_0x0017
            r1 = 1
            goto L_0x0018
        L_0x0017:
            r1 = 0
        L_0x0018:
            r2.f3341f = r1
            r2.f3342g = r4
            r1 = 2
            if (r4 == r1) goto L_0x0028
            r1 = 3
            if (r4 == r1) goto L_0x0023
            goto L_0x0052
        L_0x0023:
            java.lang.Object r4 = androidx.leanback.widget.C0839p.m3626a(r2, r6, r7, r8)
            goto L_0x0050
        L_0x0028:
            r2.setLayoutMode(r3)
            android.content.Context r4 = r2.getContext()
            android.view.LayoutInflater r4 = android.view.LayoutInflater.from(r4)
            r6 = 2131558643(0x7f0d00f3, float:1.8742608E38)
            r4.inflate(r6, r2, r3)
            androidx.leanback.widget.f1 r4 = new androidx.leanback.widget.f1
            r4.<init>()
            r6 = 2131362431(0x7f0a027f, float:1.8344642E38)
            android.view.View r6 = r2.findViewById(r6)
            r4.f3441a = r6
            r6 = 2131362429(0x7f0a027d, float:1.8344638E38)
            android.view.View r6 = r2.findViewById(r6)
            r4.f3442b = r6
        L_0x0050:
            r2.f3339d = r4
        L_0x0052:
            if (r5 == 0) goto L_0x006d
            r2.setWillNotDraw(r0)
            r2.f3347l = r0
            android.graphics.Paint r3 = new android.graphics.Paint
            r3.<init>()
            r2.f3346k = r3
            int r4 = r2.f3347l
            r3.setColor(r4)
            android.graphics.Paint r3 = r2.f3346k
            android.graphics.Paint$Style r4 = android.graphics.Paint.Style.FILL
            r3.setStyle(r4)
            goto L_0x0073
        L_0x006d:
            r2.setWillNotDraw(r3)
            r3 = 0
            r2.f3346k = r3
        L_0x0073:
            return
        L_0x0074:
            java.lang.IllegalStateException r3 = new java.lang.IllegalStateException
            r3.<init>()
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.ShadowOverlayContainer.<init>(android.content.Context, int, boolean, float, float, int):void");
    }

    public ShadowOverlayContainer(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* renamed from: a */
    public void mo3577a(int i) {
        Paint paint = this.f3346k;
        if (paint != null && i != this.f3347l) {
            this.f3347l = i;
            paint.setColor(i);
            invalidate();
        }
    }

    /* renamed from: b */
    public void mo3578b(float f) {
        Object obj = this.f3339d;
        if (obj != null) {
            C0888z0.m3786c(obj, this.f3342g, f);
        }
    }

    /* renamed from: c */
    public void mo3579c(View view) {
        if (!this.f3338c || this.f3340e != null) {
            throw new IllegalStateException();
        }
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams != null) {
            FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(layoutParams.width, layoutParams.height);
            int i = -2;
            layoutParams.width = layoutParams.width == -1 ? -1 : -2;
            if (layoutParams.height == -1) {
                i = -1;
            }
            layoutParams.height = i;
            setLayoutParams(layoutParams);
            addView(view, layoutParams2);
        } else {
            addView(view);
        }
        if (this.f3341f && this.f3342g != 3) {
            C0839p.m3628c(this, true, getResources().getDimensionPixelSize(R.dimen.lb_rounded_rect_corner_radius));
        }
        this.f3340e = view;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.f3346k != null && this.f3347l != 0) {
            canvas.drawRect((float) this.f3340e.getLeft(), (float) this.f3340e.getTop(), (float) this.f3340e.getRight(), (float) this.f3340e.getBottom(), this.f3346k);
        }
    }

    public boolean hasOverlappingRendering() {
        return false;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        View view;
        super.onLayout(z, i, i2, i3, i4);
        if (z && (view = this.f3340e) != null) {
            Rect rect = f3336a;
            rect.left = (int) view.getPivotX();
            rect.top = (int) this.f3340e.getPivotY();
            offsetDescendantRectToMyCoords(this.f3340e, rect);
            setPivotX((float) rect.left);
            setPivotY((float) rect.top);
        }
    }

    public ShadowOverlayContainer(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3342g = 1;
        if (!this.f3338c) {
            this.f3342g = 2;
            float dimension = getResources().getDimension(R.dimen.lb_material_shadow_normal_z);
            float dimension2 = getResources().getDimension(R.dimen.lb_material_shadow_focused_z);
            if (!this.f3338c) {
                this.f3342g = 3;
                this.f3343h = dimension;
                this.f3344i = dimension2;
                return;
            }
            throw new IllegalStateException("Already initialized");
        }
        throw new IllegalStateException("Already initialized");
    }
}
