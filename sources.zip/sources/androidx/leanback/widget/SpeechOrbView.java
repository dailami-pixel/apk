package androidx.leanback.widget;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import androidx.leanback.widget.SearchOrbView;
import com.vidio.android.p195tv.R;

public class SpeechOrbView extends SearchOrbView {

    /* renamed from: s */
    private final float f3348s;

    /* renamed from: t */
    private SearchOrbView.C0763c f3349t;

    /* renamed from: u */
    private SearchOrbView.C0763c f3350u;

    /* renamed from: v */
    private int f3351v;

    /* renamed from: w */
    private boolean f3352w;

    public SpeechOrbView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public SpeechOrbView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3351v = 0;
        this.f3352w = false;
        Resources resources = context.getResources();
        this.f3348s = resources.getFraction(R.fraction.lb_search_bar_speech_orb_max_level_zoom, 1, 1);
        this.f3350u = new SearchOrbView.C0763c(resources.getColor(R.color.lb_speech_orb_not_recording), resources.getColor(R.color.lb_speech_orb_not_recording_pulsed), resources.getColor(R.color.lb_speech_orb_not_recording_icon));
        this.f3349t = new SearchOrbView.C0763c(resources.getColor(R.color.lb_speech_orb_recording), resources.getColor(R.color.lb_speech_orb_recording), 0);
        mo3583k();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public int mo3559c() {
        return R.layout.lb_speech_orb;
    }

    /* renamed from: k */
    public void mo3583k() {
        mo3562f(this.f3350u);
        mo3563g(getResources().getDrawable(R.drawable.lb_ic_search_mic_out));
        mo3557a(hasFocus());
        mo3560d(1.0f);
        this.f3352w = false;
    }
}
