package androidx.leanback.widget;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.AttributeSet;
import android.util.Property;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.EditText;
import androidx.core.widget.C0502c;
import com.appsflyer.oaid.BuildConfig;
import com.vidio.android.p195tv.R;
import java.util.Random;
import java.util.regex.Pattern;

class StreamingTextView extends EditText {

    /* renamed from: a */
    private static final Pattern f3353a = Pattern.compile("\\S+");

    /* renamed from: b */
    private static final Property<StreamingTextView, Integer> f3354b = new C0764a(Integer.class, "streamPosition");

    /* renamed from: c */
    final Random f3355c = new Random();

    /* renamed from: d */
    Bitmap f3356d;

    /* renamed from: e */
    Bitmap f3357e;

    /* renamed from: f */
    int f3358f;

    /* renamed from: g */
    private ObjectAnimator f3359g;

    /* renamed from: androidx.leanback.widget.StreamingTextView$a */
    static class C0764a extends Property<StreamingTextView, Integer> {
        C0764a(Class cls, String str) {
            super(cls, str);
        }

        public Object get(Object obj) {
            return Integer.valueOf(((StreamingTextView) obj).f3358f);
        }

        public void set(Object obj, Object obj2) {
            StreamingTextView streamingTextView = (StreamingTextView) obj;
            streamingTextView.f3358f = ((Integer) obj2).intValue();
            streamingTextView.invalidate();
        }
    }

    public StreamingTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public StreamingTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* renamed from: a */
    private Bitmap m3366a(int i, float f) {
        Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), i);
        return Bitmap.createScaledBitmap(decodeResource, (int) (((float) decodeResource.getWidth()) * f), (int) (((float) decodeResource.getHeight()) * f), false);
    }

    /* renamed from: b */
    public void mo3584b() {
        this.f3358f = -1;
        ObjectAnimator objectAnimator = this.f3359g;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
        setText(BuildConfig.FLAVOR);
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        super.onFinishInflate();
        this.f3356d = m3366a(R.drawable.lb_text_dot_one, 1.3f);
        this.f3357e = m3366a(R.drawable.lb_text_dot_two, 1.3f);
        mo3584b();
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(StreamingTextView.class.getCanonicalName());
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C0502c.m2298h(this, callback));
    }
}
