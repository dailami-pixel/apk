package androidx.leanback.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.vidio.android.p195tv.R;

public class ThumbsBar extends LinearLayout {

    /* renamed from: a */
    int f3360a;

    /* renamed from: b */
    int f3361b;

    /* renamed from: c */
    int f3362c;

    /* renamed from: d */
    int f3363d;

    /* renamed from: e */
    int f3364e;

    /* renamed from: f */
    int f3365f;

    public ThumbsBar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ThumbsBar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3360a = -1;
        new SparseArray();
        this.f3361b = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_transport_thumbs_width);
        this.f3362c = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_transport_thumbs_height);
        this.f3364e = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_transport_hero_thumbs_width);
        this.f3363d = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_transport_hero_thumbs_height);
        this.f3365f = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_transport_thumbs_margin);
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        int childCount = getChildCount() / 2;
        View childAt = getChildAt(childCount);
        int width = (getWidth() / 2) - (childAt.getMeasuredWidth() / 2);
        int measuredWidth = (childAt.getMeasuredWidth() / 2) + (getWidth() / 2);
        childAt.layout(width, getPaddingTop(), measuredWidth, childAt.getMeasuredHeight() + getPaddingTop());
        int measuredHeight = (childAt.getMeasuredHeight() / 2) + getPaddingTop();
        for (int i5 = childCount - 1; i5 >= 0; i5--) {
            int i6 = width - this.f3365f;
            View childAt2 = getChildAt(i5);
            childAt2.layout(i6 - childAt2.getMeasuredWidth(), measuredHeight - (childAt2.getMeasuredHeight() / 2), i6, (childAt2.getMeasuredHeight() / 2) + measuredHeight);
            width = i6 - childAt2.getMeasuredWidth();
        }
        while (true) {
            childCount++;
            if (childCount < this.f3360a) {
                int i7 = measuredWidth + this.f3365f;
                View childAt3 = getChildAt(childCount);
                childAt3.layout(i7, measuredHeight - (childAt3.getMeasuredHeight() / 2), childAt3.getMeasuredWidth() + i7, (childAt3.getMeasuredHeight() / 2) + measuredHeight);
                measuredWidth = i7 + childAt3.getMeasuredWidth();
            } else {
                return;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3;
        super.onMeasure(i, i2);
        int measuredWidth = getMeasuredWidth() - this.f3363d;
        int i4 = this.f3361b + this.f3365f;
        int i5 = ((measuredWidth + i4) - 1) / i4;
        if (i5 < 2) {
            i5 = 2;
        } else if ((i5 & 1) != 0) {
            i5++;
        }
        int i6 = i5 + 1;
        if (this.f3360a != i6) {
            this.f3360a = i6;
            while (getChildCount() > this.f3360a) {
                removeView(getChildAt(getChildCount() - 1));
            }
            while (getChildCount() < this.f3360a) {
                addView(new ImageView(getContext()), new LinearLayout.LayoutParams(this.f3361b, this.f3362c));
            }
            int childCount = getChildCount() / 2;
            for (int i7 = 0; i7 < getChildCount(); i7++) {
                View childAt = getChildAt(i7);
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) childAt.getLayoutParams();
                if (childCount == i7) {
                    layoutParams.width = this.f3363d;
                    i3 = this.f3364e;
                } else {
                    layoutParams.width = this.f3361b;
                    i3 = this.f3362c;
                }
                layoutParams.height = i3;
                childAt.setLayoutParams(layoutParams);
            }
        }
    }
}
