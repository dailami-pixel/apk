package androidx.leanback.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.leanback.widget.C0815j1;
import com.vidio.android.p195tv.R;

public class TitleView extends FrameLayout implements C0815j1.C0816a {

    /* renamed from: a */
    private ImageView f3366a;

    /* renamed from: b */
    private TextView f3367b;

    /* renamed from: c */
    private SearchOrbView f3368c;

    /* renamed from: d */
    private int f3369d;

    /* renamed from: e */
    private boolean f3370e;

    /* renamed from: f */
    private final C0815j1 f3371f;

    /* renamed from: androidx.leanback.widget.TitleView$a */
    class C0765a extends C0815j1 {
        C0765a() {
        }

        /* renamed from: a */
        public View mo3599a() {
            return TitleView.this.mo3594c();
        }

        /* renamed from: b */
        public void mo3600b(boolean z) {
            TitleView.this.mo3593b(z);
        }

        /* renamed from: c */
        public void mo3601c(Drawable drawable) {
            TitleView.this.mo3595d((Drawable) null);
        }

        /* renamed from: d */
        public void mo3602d(View.OnClickListener onClickListener) {
            TitleView.this.mo3596e(onClickListener);
        }

        /* renamed from: e */
        public void mo3603e(CharSequence charSequence) {
            TitleView.this.mo3597f(charSequence);
        }

        /* renamed from: f */
        public void mo3604f(int i) {
            TitleView.this.mo3598h(i);
        }
    }

    public TitleView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.browseTitleViewStyle);
    }

    public TitleView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3369d = 6;
        this.f3370e = false;
        this.f3371f = new C0765a();
        View inflate = LayoutInflater.from(context).inflate(R.layout.lb_title_view, this);
        this.f3366a = (ImageView) inflate.findViewById(R.id.title_badge);
        this.f3367b = (TextView) inflate.findViewById(R.id.title_text);
        this.f3368c = (SearchOrbView) inflate.findViewById(R.id.title_orb);
        setClipToPadding(false);
        setClipChildren(false);
    }

    /* renamed from: g */
    private void m3368g() {
        if (this.f3366a.getDrawable() != null) {
            this.f3366a.setVisibility(0);
            this.f3367b.setVisibility(8);
            return;
        }
        this.f3366a.setVisibility(8);
        this.f3367b.setVisibility(0);
    }

    /* renamed from: a */
    public C0815j1 mo3592a() {
        return this.f3371f;
    }

    /* renamed from: b */
    public void mo3593b(boolean z) {
        SearchOrbView searchOrbView = this.f3368c;
        searchOrbView.mo3558b(z && searchOrbView.hasFocus());
    }

    /* renamed from: c */
    public View mo3594c() {
        return this.f3368c;
    }

    /* renamed from: d */
    public void mo3595d(Drawable drawable) {
        this.f3366a.setImageDrawable(drawable);
        m3368g();
    }

    /* renamed from: e */
    public void mo3596e(View.OnClickListener onClickListener) {
        int i = 0;
        this.f3370e = onClickListener != null;
        this.f3368c.mo3561e(onClickListener);
        if (!this.f3370e || (this.f3369d & 4) != 4) {
            i = 4;
        }
        this.f3368c.setVisibility(i);
    }

    /* renamed from: f */
    public void mo3597f(CharSequence charSequence) {
        this.f3367b.setText(charSequence);
        m3368g();
    }

    /* renamed from: h */
    public void mo3598h(int i) {
        this.f3369d = i;
        if ((i & 2) == 2) {
            m3368g();
        } else {
            this.f3366a.setVisibility(8);
            this.f3367b.setVisibility(8);
        }
        int i2 = 4;
        if (this.f3370e && (this.f3369d & 4) == 4) {
            i2 = 0;
        }
        this.f3368c.setVisibility(i2);
    }
}
