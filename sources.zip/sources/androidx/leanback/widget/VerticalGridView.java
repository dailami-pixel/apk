package androidx.leanback.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import p098d.p140l.C4825b;

public class VerticalGridView extends C0789e {
    public VerticalGridView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VerticalGridView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3425a.mo3345B2(1);
        mo3709e(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825b.f17421n);
        if (obtainStyledAttributes.peekValue(0) != null) {
            this.f3425a.mo3347C2(obtainStyledAttributes.getLayoutDimension(0, 0));
            requestLayout();
        }
        this.f3425a.mo3423y2(obtainStyledAttributes.getInt(1, 1));
        requestLayout();
        obtainStyledAttributes.recycle();
    }
}
