package androidx.leanback.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.SurfaceView;

public class VideoSurfaceView extends SurfaceView {
    public VideoSurfaceView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public VideoSurfaceView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public void setTransitionVisibility(int i) {
    }
}
