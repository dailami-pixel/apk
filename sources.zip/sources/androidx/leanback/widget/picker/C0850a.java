package androidx.leanback.widget.picker;

/* renamed from: androidx.leanback.widget.picker.a */
class C0850a implements Runnable {

    /* renamed from: a */
    final /* synthetic */ boolean f3577a;

    /* renamed from: b */
    final /* synthetic */ DatePicker f3578b;

    C0850a(DatePicker datePicker, boolean z) {
        this.f3578b = datePicker;
        this.f3577a = z;
    }

    public void run() {
        this.f3578b.mo3823l(this.f3577a);
    }
}
