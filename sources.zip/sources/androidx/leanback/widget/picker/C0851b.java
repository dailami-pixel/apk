package androidx.leanback.widget.picker;

/* renamed from: androidx.leanback.widget.picker.b */
public class C0851b {

    /* renamed from: a */
    private int f3579a;

    /* renamed from: b */
    private int f3580b;

    /* renamed from: c */
    private int f3581c;

    /* renamed from: d */
    private CharSequence[] f3582d;

    /* renamed from: e */
    private String f3583e;

    /* renamed from: a */
    public int mo3838a() {
        return (this.f3581c - this.f3580b) + 1;
    }

    /* renamed from: b */
    public int mo3839b() {
        return this.f3579a;
    }

    /* renamed from: c */
    public CharSequence mo3840c(int i) {
        CharSequence[] charSequenceArr = this.f3582d;
        if (charSequenceArr != null) {
            return charSequenceArr[i];
        }
        return String.format(this.f3583e, new Object[]{Integer.valueOf(i)});
    }

    /* renamed from: d */
    public int mo3841d() {
        return this.f3581c;
    }

    /* renamed from: e */
    public int mo3842e() {
        return this.f3580b;
    }

    /* renamed from: f */
    public void mo3843f(int i) {
        this.f3579a = i;
    }

    /* renamed from: g */
    public void mo3844g(String str) {
        this.f3583e = str;
    }

    /* renamed from: h */
    public void mo3845h(int i) {
        this.f3581c = i;
    }

    /* renamed from: i */
    public void mo3846i(int i) {
        this.f3580b = i;
    }

    /* renamed from: j */
    public void mo3847j(CharSequence[] charSequenceArr) {
        this.f3582d = charSequenceArr;
    }
}
