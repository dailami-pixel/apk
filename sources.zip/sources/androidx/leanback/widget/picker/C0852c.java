package androidx.leanback.widget.picker;

import java.text.DateFormatSymbols;
import java.util.Calendar;
import java.util.Locale;

/* renamed from: androidx.leanback.widget.picker.c */
class C0852c {

    /* renamed from: androidx.leanback.widget.picker.c$a */
    public static class C0853a {

        /* renamed from: a */
        public final Locale f3584a;

        /* renamed from: b */
        public final String[] f3585b;

        C0853a(Locale locale) {
            this.f3584a = locale;
            this.f3585b = DateFormatSymbols.getInstance(locale).getShortMonths();
            Calendar instance = Calendar.getInstance(locale);
            C0852c.m3676a(instance.getMinimum(5), instance.getMaximum(5), "%02d");
        }
    }

    /* renamed from: androidx.leanback.widget.picker.c$b */
    public static class C0854b {

        /* renamed from: a */
        public final Locale f3586a;

        /* renamed from: b */
        public final String[] f3587b = C0852c.m3676a(0, 23, "%02d");

        /* renamed from: c */
        public final String[] f3588c = C0852c.m3676a(0, 59, "%02d");

        /* renamed from: d */
        public final String[] f3589d;

        C0854b(Locale locale) {
            this.f3586a = locale;
            DateFormatSymbols instance = DateFormatSymbols.getInstance(locale);
            C0852c.m3676a(1, 12, "%02d");
            this.f3589d = instance.getAmPmStrings();
        }
    }

    /* renamed from: a */
    public static String[] m3676a(int i, int i2, String str) {
        String[] strArr = new String[((i2 - i) + 1)];
        for (int i3 = i; i3 <= i2; i3++) {
            strArr[i3 - i] = String.format(str, new Object[]{Integer.valueOf(i3)});
        }
        return strArr;
    }

    /* renamed from: b */
    public static Calendar m3677b(Calendar calendar, Locale locale) {
        if (calendar == null) {
            return Calendar.getInstance(locale);
        }
        long timeInMillis = calendar.getTimeInMillis();
        Calendar instance = Calendar.getInstance(locale);
        instance.setTimeInMillis(timeInMillis);
        return instance;
    }
}
