package androidx.leanback.widget.picker;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import androidx.leanback.widget.picker.C0852c;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import p098d.p140l.C4825b;
import p165e.p166a.p167a.p168a.C4924a;

public class DatePicker extends Picker {

    /* renamed from: o */
    private static final int[] f3530o = {5, 2, 1};

    /* renamed from: A */
    Calendar f3531A;

    /* renamed from: B */
    Calendar f3532B;

    /* renamed from: p */
    private String f3533p;

    /* renamed from: q */
    C0851b f3534q;

    /* renamed from: r */
    C0851b f3535r;

    /* renamed from: s */
    C0851b f3536s;

    /* renamed from: t */
    int f3537t;

    /* renamed from: u */
    int f3538u;

    /* renamed from: v */
    int f3539v;

    /* renamed from: w */
    final DateFormat f3540w;

    /* renamed from: x */
    C0852c.C0853a f3541x;

    /* renamed from: y */
    Calendar f3542y;

    /* renamed from: z */
    Calendar f3543z;

    public DatePicker(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public DatePicker(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        boolean z;
        String str = "MM/dd/yyyy";
        this.f3540w = new SimpleDateFormat(str);
        Locale locale = Locale.getDefault();
        getContext().getResources();
        this.f3541x = new C0852c.C0853a(locale);
        this.f3532B = C0852c.m3677b(this.f3532B, locale);
        this.f3542y = C0852c.m3677b(this.f3542y, this.f3541x.f3584a);
        this.f3543z = C0852c.m3677b(this.f3543z, this.f3541x.f3584a);
        this.f3531A = C0852c.m3677b(this.f3531A, this.f3541x.f3584a);
        C0851b bVar = this.f3534q;
        if (bVar != null) {
            bVar.mo3847j(this.f3541x.f3585b);
            mo3825c(this.f3537t, this.f3534q);
        }
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825b.f17414g);
        String string = obtainStyledAttributes.getString(0);
        String string2 = obtainStyledAttributes.getString(1);
        this.f3532B.clear();
        if (TextUtils.isEmpty(string) || !m3648k(string, this.f3532B)) {
            this.f3532B.set(1900, 0, 1);
        }
        this.f3542y.setTimeInMillis(this.f3532B.getTimeInMillis());
        this.f3532B.clear();
        if (TextUtils.isEmpty(string2) || !m3648k(string2, this.f3532B)) {
            this.f3532B.set(2100, 0, 1);
        }
        this.f3543z.setTimeInMillis(this.f3532B.getTimeInMillis());
        String string3 = obtainStyledAttributes.getString(2);
        string3 = TextUtils.isEmpty(string3) ? new String(android.text.format.DateFormat.getDateFormatOrder(context)) : string3;
        string3 = TextUtils.isEmpty(string3) ? new String(android.text.format.DateFormat.getDateFormatOrder(getContext())) : string3;
        if (!TextUtils.equals(this.f3533p, string3)) {
            this.f3533p = string3;
            String bestDateTimePattern = android.text.format.DateFormat.getBestDateTimePattern(this.f3541x.f3584a, string3);
            str = !TextUtils.isEmpty(bestDateTimePattern) ? bestDateTimePattern : str;
            ArrayList arrayList = new ArrayList();
            StringBuilder sb = new StringBuilder();
            char[] cArr = {'Y', 'y', 'M', 'm', 'D', 'd'};
            boolean z2 = false;
            char c = 0;
            for (int i2 = 0; i2 < str.length(); i2++) {
                char charAt = str.charAt(i2);
                if (charAt != ' ') {
                    if (charAt != '\'') {
                        if (!z2) {
                            int i3 = 0;
                            while (true) {
                                if (i3 >= 6) {
                                    z = false;
                                    break;
                                } else if (charAt == cArr[i3]) {
                                    z = true;
                                    break;
                                } else {
                                    i3++;
                                }
                            }
                            if (z) {
                                if (charAt != c) {
                                    arrayList.add(sb.toString());
                                    sb.setLength(0);
                                }
                                c = charAt;
                            }
                        }
                        sb.append(charAt);
                        c = charAt;
                    } else if (!z2) {
                        sb.setLength(0);
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                }
            }
            arrayList.add(sb.toString());
            if (arrayList.size() == string3.length() + 1) {
                mo3830h(arrayList);
                this.f3535r = null;
                this.f3534q = null;
                this.f3536s = null;
                this.f3537t = -1;
                this.f3538u = -1;
                this.f3539v = -1;
                String upperCase = string3.toUpperCase();
                ArrayList arrayList2 = new ArrayList(3);
                for (int i4 = 0; i4 < upperCase.length(); i4++) {
                    char charAt2 = upperCase.charAt(i4);
                    if (charAt2 != 'D') {
                        if (charAt2 != 'M') {
                            if (charAt2 != 'Y') {
                                throw new IllegalArgumentException("datePicker format error");
                            } else if (this.f3536s == null) {
                                C0851b bVar2 = new C0851b();
                                this.f3536s = bVar2;
                                arrayList2.add(bVar2);
                                this.f3539v = i4;
                                this.f3536s.mo3844g("%d");
                            } else {
                                throw new IllegalArgumentException("datePicker format error");
                            }
                        } else if (this.f3534q == null) {
                            C0851b bVar3 = new C0851b();
                            this.f3534q = bVar3;
                            arrayList2.add(bVar3);
                            this.f3534q.mo3847j(this.f3541x.f3585b);
                            this.f3537t = i4;
                        } else {
                            throw new IllegalArgumentException("datePicker format error");
                        }
                    } else if (this.f3535r == null) {
                        C0851b bVar4 = new C0851b();
                        this.f3535r = bVar4;
                        arrayList2.add(bVar4);
                        this.f3535r.mo3844g("%02d");
                        this.f3538u = i4;
                    } else {
                        throw new IllegalArgumentException("datePicker format error");
                    }
                }
                mo3828e(arrayList2);
                post(new C0850a(this, false));
                return;
            }
            StringBuilder P = C4924a.m17863P("Separators size: ");
            P.append(arrayList.size());
            P.append(" must equal");
            P.append(" the size of datePickerFormat: ");
            P.append(string3.length());
            P.append(" + 1");
            throw new IllegalStateException(P.toString());
        }
    }

    /* renamed from: k */
    private boolean m3648k(String str, Calendar calendar) {
        try {
            calendar.setTime(this.f3540w.parse(str));
            return true;
        } catch (ParseException unused) {
            Log.w("DatePicker", "Date: " + str + " not in format: " + "MM/dd/yyyy");
            return false;
        }
    }

    /* renamed from: b */
    public final void mo3822b(int i, int i2) {
        Calendar calendar;
        Calendar calendar2;
        this.f3532B.setTimeInMillis(this.f3531A.getTimeInMillis());
        ArrayList<C0851b> arrayList = this.f3547d;
        int b = (arrayList == null ? null : arrayList.get(i)).mo3839b();
        if (i == this.f3538u) {
            this.f3532B.add(5, i2 - b);
        } else if (i == this.f3537t) {
            this.f3532B.add(2, i2 - b);
        } else if (i == this.f3539v) {
            this.f3532B.add(1, i2 - b);
        } else {
            throw new IllegalArgumentException();
        }
        this.f3531A.set(this.f3532B.get(1), this.f3532B.get(2), this.f3532B.get(5));
        if (this.f3531A.before(this.f3542y)) {
            calendar2 = this.f3531A;
            calendar = this.f3542y;
        } else {
            if (this.f3531A.after(this.f3543z)) {
                calendar2 = this.f3531A;
                calendar = this.f3543z;
            }
            post(new C0850a(this, false));
        }
        calendar2.setTimeInMillis(calendar.getTimeInMillis());
        post(new C0850a(this, false));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l */
    public void mo3823l(boolean z) {
        boolean z2;
        boolean z3;
        int i;
        int i2;
        int[] iArr = {this.f3538u, this.f3537t, this.f3539v};
        boolean z4 = true;
        boolean z5 = true;
        for (int length = f3530o.length - 1; length >= 0; length--) {
            if (iArr[length] >= 0) {
                int i3 = f3530o[length];
                int i4 = iArr[length];
                ArrayList<C0851b> arrayList = this.f3547d;
                C0851b bVar = arrayList == null ? null : arrayList.get(i4);
                if (!z4 ? (i2 = this.f3531A.getActualMinimum(i3)) == bVar.mo3842e() : (i2 = this.f3542y.get(i3)) == bVar.mo3842e()) {
                    z2 = false;
                } else {
                    bVar.mo3846i(i2);
                    z2 = true;
                }
                boolean z6 = z2 | false;
                if (!z5 ? (i = this.f3531A.getActualMaximum(i3)) == bVar.mo3841d() : (i = this.f3543z.get(i3)) == bVar.mo3841d()) {
                    z3 = false;
                } else {
                    bVar.mo3845h(i);
                    z3 = true;
                }
                boolean z7 = z6 | z3;
                z4 &= this.f3531A.get(i3) == this.f3542y.get(i3);
                z5 &= this.f3531A.get(i3) == this.f3543z.get(i3);
                if (z7) {
                    mo3825c(iArr[length], bVar);
                }
                mo3826d(iArr[length], this.f3531A.get(i3), z);
            }
        }
    }
}
