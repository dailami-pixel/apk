package androidx.leanback.widget.picker;

import android.content.Context;
import android.graphics.Rect;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.leanback.widget.C0802g0;
import androidx.leanback.widget.VerticalGridView;
import androidx.recyclerview.widget.RecyclerView;
import com.appsflyer.oaid.BuildConfig;
import com.vidio.android.p195tv.R;
import java.util.ArrayList;
import java.util.List;
import p165e.p166a.p167a.p168a.C4924a;

public class Picker extends FrameLayout {

    /* renamed from: a */
    private ViewGroup f3544a;

    /* renamed from: b */
    private ViewGroup f3545b;

    /* renamed from: c */
    final List<VerticalGridView> f3546c = new ArrayList();

    /* renamed from: d */
    ArrayList<C0851b> f3547d;

    /* renamed from: e */
    private float f3548e;

    /* renamed from: f */
    private float f3549f;

    /* renamed from: g */
    private float f3550g;

    /* renamed from: h */
    private int f3551h;

    /* renamed from: i */
    private Interpolator f3552i;

    /* renamed from: j */
    private float f3553j = 3.0f;

    /* renamed from: k */
    private int f3554k = 0;

    /* renamed from: l */
    private List<CharSequence> f3555l = new ArrayList();

    /* renamed from: m */
    private int f3556m = R.layout.lb_picker_item;

    /* renamed from: n */
    private final C0802g0 f3557n = new C0847a();

    /* renamed from: androidx.leanback.widget.picker.Picker$a */
    class C0847a extends C0802g0 {
        C0847a() {
        }

        /* renamed from: a */
        public void mo3059a(RecyclerView recyclerView, RecyclerView.C1142b0 b0Var, int i, int i2) {
            C0848b bVar = (C0848b) recyclerView.getAdapter();
            int indexOf = Picker.this.f3546c.indexOf(recyclerView);
            Picker.this.mo3831i(indexOf, true);
            if (b0Var != null) {
                Picker.this.mo3822b(indexOf, Picker.this.f3547d.get(indexOf).mo3842e() + i);
            }
        }
    }

    /* renamed from: androidx.leanback.widget.picker.Picker$b */
    class C0848b extends RecyclerView.C1147g<C0849c> {

        /* renamed from: a */
        private final int f3559a;

        /* renamed from: b */
        private final int f3560b;

        /* renamed from: c */
        private final int f3561c;

        /* renamed from: d */
        private C0851b f3562d;

        C0848b(int i, int i2, int i3) {
            this.f3559a = i;
            this.f3560b = i3;
            this.f3561c = i2;
            this.f3562d = Picker.this.f3547d.get(i3);
        }

        public int getItemCount() {
            C0851b bVar = this.f3562d;
            if (bVar == null) {
                return 0;
            }
            return bVar.mo3838a();
        }

        public void onBindViewHolder(RecyclerView.C1142b0 b0Var, int i) {
            C0851b bVar;
            C0849c cVar = (C0849c) b0Var;
            TextView textView = cVar.f3564a;
            if (!(textView == null || (bVar = this.f3562d) == null)) {
                textView.setText(bVar.mo3840c(bVar.mo3842e() + i));
            }
            Picker picker = Picker.this;
            picker.mo3829g(cVar.itemView, picker.f3546c.get(this.f3560b).mo3703a() == i, this.f3560b, false);
        }

        public RecyclerView.C1142b0 onCreateViewHolder(ViewGroup viewGroup, int i) {
            View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(this.f3559a, viewGroup, false);
            int i2 = this.f3561c;
            return new C0849c(inflate, i2 != 0 ? (TextView) inflate.findViewById(i2) : (TextView) inflate);
        }

        public void onViewAttachedToWindow(RecyclerView.C1142b0 b0Var) {
            ((C0849c) b0Var).itemView.setFocusable(Picker.this.isActivated());
        }
    }

    /* renamed from: androidx.leanback.widget.picker.Picker$c */
    static class C0849c extends RecyclerView.C1142b0 {

        /* renamed from: a */
        final TextView f3564a;

        C0849c(View view, TextView textView) {
            super(view);
            this.f3564a = textView;
        }
    }

    public Picker(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setEnabled(true);
        setDescendantFocusability(262144);
        this.f3549f = 1.0f;
        this.f3548e = 1.0f;
        this.f3550g = 0.5f;
        this.f3551h = 200;
        this.f3552i = new DecelerateInterpolator(2.5f);
        new AccelerateInterpolator(2.5f);
        ViewGroup viewGroup = (ViewGroup) LayoutInflater.from(getContext()).inflate(R.layout.lb_picker, this, true);
        this.f3544a = viewGroup;
        this.f3545b = (ViewGroup) viewGroup.findViewById(R.id.picker);
    }

    /* renamed from: f */
    private void m3651f(View view, boolean z, float f, float f2, Interpolator interpolator) {
        view.animate().cancel();
        if (!z) {
            view.setAlpha(f);
            return;
        }
        if (f2 >= 0.0f) {
            view.setAlpha(f2);
        }
        view.animate().alpha(f).setDuration((long) this.f3551h).setInterpolator(interpolator).start();
    }

    /* renamed from: j */
    private void m3652j(VerticalGridView verticalGridView) {
        ViewGroup.LayoutParams layoutParams = verticalGridView.getLayoutParams();
        float f = isActivated() ? this.f3553j : 1.0f;
        layoutParams.height = (int) C4924a.m17874a(f, 1.0f, (float) verticalGridView.mo3704b(), ((float) getContext().getResources().getDimensionPixelSize(R.dimen.picker_item_height)) * f);
        verticalGridView.setLayoutParams(layoutParams);
    }

    /* renamed from: a */
    public int mo3824a() {
        ArrayList<C0851b> arrayList = this.f3547d;
        if (arrayList == null) {
            return 0;
        }
        return arrayList.size();
    }

    /* renamed from: b */
    public void mo3822b(int i, int i2) {
        C0851b bVar = this.f3547d.get(i);
        if (bVar.mo3839b() != i2) {
            bVar.mo3843f(i2);
        }
    }

    /* renamed from: c */
    public void mo3825c(int i, C0851b bVar) {
        this.f3547d.set(i, bVar);
        VerticalGridView verticalGridView = this.f3546c.get(i);
        C0848b bVar2 = (C0848b) verticalGridView.getAdapter();
        if (bVar2 != null) {
            bVar2.notifyDataSetChanged();
        }
        verticalGridView.mo3737x(bVar.mo3839b() - bVar.mo3842e());
    }

    /* renamed from: d */
    public void mo3826d(int i, int i2, boolean z) {
        C0851b bVar = this.f3547d.get(i);
        if (bVar.mo3839b() != i2) {
            bVar.mo3843f(i2);
            VerticalGridView verticalGridView = this.f3546c.get(i);
            if (verticalGridView != null) {
                int e = i2 - this.f3547d.get(i).mo3842e();
                if (z) {
                    verticalGridView.mo3739z(e);
                } else {
                    verticalGridView.mo3737x(e);
                }
            }
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (!isActivated()) {
            return super.dispatchKeyEvent(keyEvent);
        }
        int keyCode = keyEvent.getKeyCode();
        if (keyCode != 23 && keyCode != 66) {
            return super.dispatchKeyEvent(keyEvent);
        }
        if (keyEvent.getAction() == 1) {
            performClick();
        }
        return true;
    }

    /* renamed from: e */
    public void mo3828e(List<C0851b> list) {
        if (this.f3555l.size() != 0) {
            if (this.f3555l.size() == 1) {
                CharSequence charSequence = this.f3555l.get(0);
                this.f3555l.clear();
                this.f3555l.add(BuildConfig.FLAVOR);
                for (int i = 0; i < list.size() - 1; i++) {
                    this.f3555l.add(charSequence);
                }
                this.f3555l.add(BuildConfig.FLAVOR);
            } else if (this.f3555l.size() != list.size() + 1) {
                StringBuilder P = C4924a.m17863P("Separators size: ");
                P.append(this.f3555l.size());
                P.append(" must");
                P.append("equal the size of columns: ");
                P.append(list.size());
                P.append(" + 1");
                throw new IllegalStateException(P.toString());
            }
            this.f3546c.clear();
            this.f3545b.removeAllViews();
            ArrayList<C0851b> arrayList = new ArrayList<>(list);
            this.f3547d = arrayList;
            if (this.f3554k > arrayList.size() - 1) {
                this.f3554k = this.f3547d.size() - 1;
            }
            LayoutInflater from = LayoutInflater.from(getContext());
            int a = mo3824a();
            if (!TextUtils.isEmpty(this.f3555l.get(0))) {
                TextView textView = (TextView) from.inflate(R.layout.lb_picker_separator, this.f3545b, false);
                textView.setText(this.f3555l.get(0));
                this.f3545b.addView(textView);
            }
            int i2 = 0;
            while (i2 < a) {
                VerticalGridView verticalGridView = (VerticalGridView) from.inflate(R.layout.lb_picker_column, this.f3545b, false);
                m3652j(verticalGridView);
                verticalGridView.mo3700B(0);
                verticalGridView.setHasFixedSize(false);
                verticalGridView.setFocusable(isActivated());
                verticalGridView.setItemViewCacheSize(0);
                this.f3546c.add(verticalGridView);
                this.f3545b.addView(verticalGridView);
                int i3 = i2 + 1;
                if (!TextUtils.isEmpty(this.f3555l.get(i3))) {
                    TextView textView2 = (TextView) from.inflate(R.layout.lb_picker_separator, this.f3545b, false);
                    textView2.setText(this.f3555l.get(i3));
                    this.f3545b.addView(textView2);
                }
                getContext();
                verticalGridView.setAdapter(new C0848b(this.f3556m, 0, i2));
                verticalGridView.mo3727q(this.f3557n);
                i2 = i3;
            }
            return;
        }
        StringBuilder P2 = C4924a.m17863P("Separators size is: ");
        P2.append(this.f3555l.size());
        P2.append(". At least one separator must be provided");
        throw new IllegalStateException(P2.toString());
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public void mo3829g(View view, boolean z, int i, boolean z2) {
        boolean z3 = i == this.f3554k || !hasFocus();
        m3651f(view, z2, z ? z3 ? this.f3549f : this.f3548e : z3 ? this.f3550g : 0.0f, -1.0f, this.f3552i);
    }

    /* renamed from: h */
    public final void mo3830h(List<CharSequence> list) {
        this.f3555l.clear();
        this.f3555l.addAll(list);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public void mo3831i(int i, boolean z) {
        VerticalGridView verticalGridView = this.f3546c.get(i);
        int a = verticalGridView.mo3703a();
        int i2 = 0;
        while (i2 < verticalGridView.getAdapter().getItemCount()) {
            View x = verticalGridView.getLayoutManager().mo4651x(i2);
            if (x != null) {
                mo3829g(x, a == i2, i, z);
            }
            i2++;
        }
    }

    /* access modifiers changed from: protected */
    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        int i2 = this.f3554k;
        if (i2 < this.f3546c.size()) {
            return this.f3546c.get(i2).requestFocus(i, rect);
        }
        return false;
    }

    public void requestChildFocus(View view, View view2) {
        super.requestChildFocus(view, view2);
        for (int i = 0; i < this.f3546c.size(); i++) {
            if (this.f3546c.get(i).hasFocus() && this.f3554k != i) {
                this.f3554k = i;
                for (int i2 = 0; i2 < this.f3546c.size(); i2++) {
                    mo3831i(i2, true);
                }
            }
        }
    }

    public void setActivated(boolean z) {
        boolean isActivated = isActivated();
        super.setActivated(z);
        if (z != isActivated) {
            boolean hasFocus = hasFocus();
            int i = this.f3554k;
            setDescendantFocusability(131072);
            if (!z && hasFocus && isFocusable()) {
                requestFocus();
            }
            for (int i2 = 0; i2 < mo3824a(); i2++) {
                this.f3546c.get(i2).setFocusable(z);
            }
            for (int i3 = 0; i3 < mo3824a(); i3++) {
                m3652j(this.f3546c.get(i3));
            }
            boolean isActivated2 = isActivated();
            for (int i4 = 0; i4 < mo3824a(); i4++) {
                VerticalGridView verticalGridView = this.f3546c.get(i4);
                for (int i5 = 0; i5 < verticalGridView.getChildCount(); i5++) {
                    verticalGridView.getChildAt(i5).setFocusable(isActivated2);
                }
            }
            if (z && hasFocus && i >= 0) {
                this.f3546c.get(i).requestFocus();
            }
            setDescendantFocusability(262144);
        }
    }
}
