package androidx.leanback.widget.picker;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import androidx.leanback.widget.picker.C0852c;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import p098d.p140l.C4825b;
import p165e.p166a.p167a.p168a.C4924a;

public class TimePicker extends Picker {

    /* renamed from: o */
    C0851b f3565o;

    /* renamed from: p */
    C0851b f3566p;

    /* renamed from: q */
    C0851b f3567q;

    /* renamed from: r */
    int f3568r;

    /* renamed from: s */
    int f3569s;

    /* renamed from: t */
    int f3570t;

    /* renamed from: u */
    private final C0852c.C0854b f3571u;

    /* renamed from: v */
    private boolean f3572v;

    /* renamed from: w */
    private int f3573w;

    /* renamed from: x */
    private int f3574x;

    /* renamed from: y */
    private int f3575y;

    /* renamed from: z */
    private String f3576z;

    public TimePicker(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public TimePicker(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        boolean z;
        Locale locale = Locale.getDefault();
        context.getResources();
        this.f3571u = new C0852c.C0854b(locale);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825b.f17420m);
        this.f3572v = obtainStyledAttributes.getBoolean(0, DateFormat.is24HourFormat(context));
        boolean z2 = obtainStyledAttributes.getBoolean(1, true);
        String k = mo3836k();
        if (!TextUtils.equals(k, this.f3576z)) {
            this.f3576z = k;
            String k2 = mo3836k();
            boolean z3 = TextUtils.getLayoutDirectionFromLocale(locale) == 1;
            boolean z4 = k2.indexOf(97) < 0 || k2.indexOf("a") > k2.indexOf("m");
            String str = z3 ? "mh" : "hm";
            if (!this.f3572v) {
                StringBuilder sb = new StringBuilder();
                if (z4) {
                    sb.append(str);
                    sb.append("a");
                } else {
                    sb.append("a");
                    sb.append(str);
                }
                str = sb.toString();
            }
            String k3 = mo3836k();
            ArrayList arrayList = new ArrayList();
            StringBuilder sb2 = new StringBuilder();
            int i2 = 7;
            char[] cArr = {'H', 'h', 'K', 'k', 'm', 'M', 'a'};
            int i3 = 0;
            boolean z5 = false;
            char c = 0;
            while (i3 < k3.length()) {
                char charAt = k3.charAt(i3);
                if (charAt != ' ') {
                    if (charAt != '\'') {
                        if (!z5) {
                            int i4 = 0;
                            while (true) {
                                if (i4 >= i2) {
                                    z = false;
                                    break;
                                } else if (charAt == cArr[i4]) {
                                    z = true;
                                    break;
                                } else {
                                    i4++;
                                    i2 = 7;
                                }
                            }
                            if (z) {
                                if (charAt != c) {
                                    arrayList.add(sb2.toString());
                                    sb2.setLength(0);
                                }
                                c = charAt;
                            }
                        }
                        sb2.append(charAt);
                        c = charAt;
                    } else if (!z5) {
                        sb2.setLength(0);
                        z5 = true;
                    } else {
                        z5 = false;
                    }
                }
                i3++;
                i2 = 7;
            }
            arrayList.add(sb2.toString());
            if (arrayList.size() == str.length() + 1) {
                mo3830h(arrayList);
                String upperCase = str.toUpperCase();
                this.f3567q = null;
                this.f3566p = null;
                this.f3565o = null;
                this.f3570t = -1;
                this.f3569s = -1;
                this.f3568r = -1;
                ArrayList arrayList2 = new ArrayList(3);
                for (int i5 = 0; i5 < upperCase.length(); i5++) {
                    char charAt2 = upperCase.charAt(i5);
                    if (charAt2 == 'A') {
                        C0851b bVar = new C0851b();
                        this.f3567q = bVar;
                        arrayList2.add(bVar);
                        this.f3567q.mo3847j(this.f3571u.f3589d);
                        this.f3570t = i5;
                        m3663m(this.f3567q, 0);
                        m3662l(this.f3567q, 1);
                    } else if (charAt2 == 'H') {
                        C0851b bVar2 = new C0851b();
                        this.f3565o = bVar2;
                        arrayList2.add(bVar2);
                        this.f3565o.mo3847j(this.f3571u.f3587b);
                        this.f3568r = i5;
                    } else if (charAt2 == 'M') {
                        C0851b bVar3 = new C0851b();
                        this.f3566p = bVar3;
                        arrayList2.add(bVar3);
                        this.f3566p.mo3847j(this.f3571u.f3588c);
                        this.f3569s = i5;
                    } else {
                        throw new IllegalArgumentException("Invalid time picker format.");
                    }
                }
                mo3828e(arrayList2);
            } else {
                StringBuilder P = C4924a.m17863P("Separators size: ");
                P.append(arrayList.size());
                P.append(" must equal");
                P.append(" the size of timeFieldsPattern: ");
                P.append(str.length());
                P.append(" + 1");
                throw new IllegalStateException(P.toString());
            }
        }
        m3663m(this.f3565o, this.f3572v ^ true ? 1 : 0);
        m3662l(this.f3565o, this.f3572v ? 23 : 12);
        m3663m(this.f3566p, 0);
        m3662l(this.f3566p, 59);
        C0851b bVar4 = this.f3567q;
        if (bVar4 != null) {
            m3663m(bVar4, 0);
            m3662l(this.f3567q, 1);
        }
        if (z2) {
            Calendar b = C0852c.m3677b((Calendar) null, this.f3571u.f3586a);
            int i6 = b.get(11);
            if (i6 < 0 || i6 > 23) {
                throw new IllegalArgumentException(C4924a.m17901p("hour: ", i6, " is not in [0-23] range in"));
            }
            this.f3573w = i6;
            boolean z6 = this.f3572v;
            if (!z6) {
                if (i6 >= 12) {
                    this.f3575y = 1;
                    if (i6 > 12) {
                        this.f3573w = i6 - 12;
                    }
                } else {
                    this.f3575y = 0;
                    if (i6 == 0) {
                        this.f3573w = 12;
                    }
                }
                if (!z6) {
                    mo3826d(this.f3570t, this.f3575y, false);
                }
            }
            mo3826d(this.f3568r, this.f3573w, false);
            int i7 = b.get(12);
            if (i7 < 0 || i7 > 59) {
                throw new IllegalArgumentException(C4924a.m17901p("minute: ", i7, " is not in [0-59] range."));
            }
            this.f3574x = i7;
            mo3826d(this.f3569s, i7, false);
            if (!this.f3572v) {
                mo3826d(this.f3570t, this.f3575y, false);
            }
        }
    }

    /* renamed from: l */
    private static boolean m3662l(C0851b bVar, int i) {
        if (i == bVar.mo3841d()) {
            return false;
        }
        bVar.mo3845h(i);
        return true;
    }

    /* renamed from: m */
    private static boolean m3663m(C0851b bVar, int i) {
        if (i == bVar.mo3842e()) {
            return false;
        }
        bVar.mo3846i(i);
        return true;
    }

    /* renamed from: b */
    public void mo3822b(int i, int i2) {
        if (i == this.f3568r) {
            this.f3573w = i2;
        } else if (i == this.f3569s) {
            this.f3574x = i2;
        } else if (i == this.f3570t) {
            this.f3575y = i2;
        } else {
            throw new IllegalArgumentException("Invalid column index.");
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k */
    public String mo3836k() {
        String bestDateTimePattern = DateFormat.getBestDateTimePattern(this.f3571u.f3586a, this.f3572v ? "Hma" : "hma");
        return TextUtils.isEmpty(bestDateTimePattern) ? "h:mma" : bestDateTimePattern;
    }
}
