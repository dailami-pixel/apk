package androidx.lifecycle;

import androidx.lifecycle.C0903f;
import kotlin.Metadata;
import kotlin.jvm.internal.C12358j;

@Metadata(mo39552bv = {1, 0, 3}, mo39553d1 = {"\u0000\u001d\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u001f\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0007\u0010\b¨\u0006\t¸\u0006\u0000"}, mo39554d2 = {"androidx/lifecycle/WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$observer$1", "Landroidx/lifecycle/h;", "Landroidx/lifecycle/j;", "source", "Landroidx/lifecycle/f$a;", "event", "Lkotlin/n;", "c", "(Landroidx/lifecycle/j;Landroidx/lifecycle/f$a;)V", "lifecycle-runtime-ktx_release"}, mo39555k = 1, mo39556mv = {1, 4, 1})
/* renamed from: androidx.lifecycle.WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 */
public final class C0895x3029b39e implements C0907h {
    /* renamed from: c */
    public void mo360c(C0909j jVar, C0903f.C0904a aVar) {
        C12358j.m34085e(jVar, "source");
        C12358j.m34085e(aVar, "event");
        throw null;
    }
}
