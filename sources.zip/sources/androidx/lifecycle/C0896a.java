package androidx.lifecycle;

import androidx.lifecycle.C0903f;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.lifecycle.a */
final class C0896a {

    /* renamed from: a */
    static C0896a f3708a = new C0896a();

    /* renamed from: b */
    private final Map<Class<?>, C0897a> f3709b = new HashMap();

    /* renamed from: c */
    private final Map<Class<?>, Boolean> f3710c = new HashMap();

    /* renamed from: androidx.lifecycle.a$a */
    static class C0897a {

        /* renamed from: a */
        final Map<C0903f.C0904a, List<C0898b>> f3711a = new HashMap();

        /* renamed from: b */
        final Map<C0898b, C0903f.C0904a> f3712b;

        C0897a(Map<C0898b, C0903f.C0904a> map) {
            this.f3712b = map;
            for (Map.Entry next : map.entrySet()) {
                C0903f.C0904a aVar = (C0903f.C0904a) next.getValue();
                List list = this.f3711a.get(aVar);
                if (list == null) {
                    list = new ArrayList();
                    this.f3711a.put(aVar, list);
                }
                list.add(next.getKey());
            }
        }

        /* renamed from: b */
        private static void m3830b(List<C0898b> list, C0909j jVar, C0903f.C0904a aVar, Object obj) {
            if (list != null) {
                int size = list.size() - 1;
                while (size >= 0) {
                    C0898b bVar = list.get(size);
                    Objects.requireNonNull(bVar);
                    try {
                        int i = bVar.f3713a;
                        if (i == 0) {
                            bVar.f3714b.invoke(obj, new Object[0]);
                        } else if (i == 1) {
                            bVar.f3714b.invoke(obj, new Object[]{jVar});
                        } else if (i == 2) {
                            bVar.f3714b.invoke(obj, new Object[]{jVar, aVar});
                        }
                        size--;
                    } catch (InvocationTargetException e) {
                        throw new RuntimeException("Failed to call observer method", e.getCause());
                    } catch (IllegalAccessException e2) {
                        throw new RuntimeException(e2);
                    }
                }
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo3930a(C0909j jVar, C0903f.C0904a aVar, Object obj) {
            m3830b(this.f3711a.get(aVar), jVar, aVar, obj);
            m3830b(this.f3711a.get(C0903f.C0904a.ON_ANY), jVar, aVar, obj);
        }
    }

    /* renamed from: androidx.lifecycle.a$b */
    static final class C0898b {

        /* renamed from: a */
        final int f3713a;

        /* renamed from: b */
        final Method f3714b;

        C0898b(int i, Method method) {
            this.f3713a = i;
            this.f3714b = method;
            method.setAccessible(true);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof C0898b)) {
                return false;
            }
            C0898b bVar = (C0898b) obj;
            return this.f3713a == bVar.f3713a && this.f3714b.getName().equals(bVar.f3714b.getName());
        }

        public int hashCode() {
            return this.f3714b.getName().hashCode() + (this.f3713a * 31);
        }
    }

    C0896a() {
    }

    /* renamed from: a */
    private C0897a m3826a(Class<?> cls, Method[] methodArr) {
        int i;
        C0897a b;
        Class<? super Object> superclass = cls.getSuperclass();
        HashMap hashMap = new HashMap();
        if (!(superclass == null || (b = mo3928b(superclass)) == null)) {
            hashMap.putAll(b.f3712b);
        }
        for (Class b2 : cls.getInterfaces()) {
            for (Map.Entry next : mo3928b(b2).f3712b.entrySet()) {
                m3827d(hashMap, (C0898b) next.getKey(), (C0903f.C0904a) next.getValue(), cls);
            }
        }
        if (methodArr == null) {
            try {
                methodArr = cls.getDeclaredMethods();
            } catch (NoClassDefFoundError e) {
                throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e);
            }
        }
        boolean z = false;
        for (Method method : methodArr) {
            C0917q qVar = (C0917q) method.getAnnotation(C0917q.class);
            if (qVar != null) {
                Class[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length <= 0) {
                    i = 0;
                } else if (parameterTypes[0].isAssignableFrom(C0909j.class)) {
                    i = 1;
                } else {
                    throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
                }
                C0903f.C0904a value = qVar.value();
                if (parameterTypes.length > 1) {
                    if (!parameterTypes[1].isAssignableFrom(C0903f.C0904a.class)) {
                        throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
                    } else if (value == C0903f.C0904a.ON_ANY) {
                        i = 2;
                    } else {
                        throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
                    }
                }
                if (parameterTypes.length <= 2) {
                    m3827d(hashMap, new C0898b(i, method), value, cls);
                    z = true;
                } else {
                    throw new IllegalArgumentException("cannot have more than 2 params");
                }
            }
        }
        C0897a aVar = new C0897a(hashMap);
        this.f3709b.put(cls, aVar);
        this.f3710c.put(cls, Boolean.valueOf(z));
        return aVar;
    }

    /* renamed from: d */
    private void m3827d(Map<C0898b, C0903f.C0904a> map, C0898b bVar, C0903f.C0904a aVar, Class<?> cls) {
        C0903f.C0904a aVar2 = map.get(bVar);
        if (aVar2 != null && aVar != aVar2) {
            Method method = bVar.f3714b;
            StringBuilder P = C4924a.m17863P("Method ");
            P.append(method.getName());
            P.append(" in ");
            P.append(cls.getName());
            P.append(" already declared with different @OnLifecycleEvent value: previous value ");
            P.append(aVar2);
            P.append(", new value ");
            P.append(aVar);
            throw new IllegalArgumentException(P.toString());
        } else if (aVar2 == null) {
            map.put(bVar, aVar);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public C0897a mo3928b(Class<?> cls) {
        C0897a aVar = this.f3709b.get(cls);
        return aVar != null ? aVar : m3826a(cls, (Method[]) null);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public boolean mo3929c(Class<?> cls) {
        Boolean bool = this.f3710c.get(cls);
        if (bool != null) {
            return bool.booleanValue();
        }
        try {
            Method[] declaredMethods = cls.getDeclaredMethods();
            for (Method annotation : declaredMethods) {
                if (((C0917q) annotation.getAnnotation(C0917q.class)) != null) {
                    m3826a(cls, declaredMethods);
                    return true;
                }
            }
            this.f3710c.put(cls, Boolean.FALSE);
            return false;
        } catch (NoClassDefFoundError e) {
            throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e);
        }
    }
}
