package androidx.lifecycle;

/* renamed from: androidx.lifecycle.b */
public final /* synthetic */ class C0899b {
    /* renamed from: a */
    public static void m3832a(C0900c cVar, C0909j jVar) {
    }

    /* renamed from: b */
    public static void m3833b(C0900c cVar, C0909j jVar) {
    }

    /* renamed from: c */
    public static void m3834c(C0900c cVar, C0909j jVar) {
    }

    /* renamed from: d */
    public static void m3835d(C0900c cVar, C0909j jVar) {
    }

    /* renamed from: e */
    public static void m3836e(C0900c cVar, C0909j jVar) {
    }
}
