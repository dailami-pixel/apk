package androidx.lifecycle;

/* renamed from: androidx.lifecycle.c */
public interface C0900c extends C0901d {
}
