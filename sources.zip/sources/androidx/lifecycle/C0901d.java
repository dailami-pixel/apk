package androidx.lifecycle;

/* renamed from: androidx.lifecycle.d */
interface C0901d extends C0908i {
    /* renamed from: a */
    void mo3933a(C0909j jVar);

    /* renamed from: b */
    void mo3934b(C0909j jVar);

    /* renamed from: d */
    void mo3935d(C0909j jVar);

    /* renamed from: e */
    void mo3936e(C0909j jVar);

    /* renamed from: f */
    void mo3937f(C0909j jVar);

    /* renamed from: g */
    void mo3938g(C0909j jVar);
}
