package androidx.lifecycle;

import androidx.lifecycle.C0903f;

/* renamed from: androidx.lifecycle.e */
public interface C0902e {
    /* renamed from: a */
    void mo3939a(C0909j jVar, C0903f.C0904a aVar, boolean z, C0914n nVar);
}
