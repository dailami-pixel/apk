package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicReference;

/* renamed from: androidx.lifecycle.f */
public abstract class C0903f {

    /* renamed from: androidx.lifecycle.f$a */
    public enum C0904a {
        ON_CREATE,
        ON_START,
        ON_RESUME,
        ON_PAUSE,
        ON_STOP,
        ON_DESTROY,
        ON_ANY;

        /* renamed from: b */
        public static C0904a m3847b(C0905b bVar) {
            int ordinal = bVar.ordinal();
            if (ordinal == 1) {
                return ON_CREATE;
            }
            if (ordinal == 2) {
                return ON_START;
            }
            if (ordinal != 3) {
                return null;
            }
            return ON_RESUME;
        }

        /* renamed from: a */
        public C0905b mo3943a() {
            int ordinal = ordinal();
            if (ordinal != 0) {
                if (ordinal != 1) {
                    if (ordinal == 2) {
                        return C0905b.RESUMED;
                    }
                    if (ordinal != 3) {
                        if (ordinal != 4) {
                            if (ordinal == 5) {
                                return C0905b.DESTROYED;
                            }
                            throw new IllegalArgumentException(this + " has no target state");
                        }
                    }
                }
                return C0905b.STARTED;
            }
            return C0905b.CREATED;
        }
    }

    /* renamed from: androidx.lifecycle.f$b */
    public enum C0905b {
        DESTROYED,
        INITIALIZED,
        CREATED,
        STARTED,
        RESUMED
    }

    public C0903f() {
        new AtomicReference();
    }

    /* renamed from: a */
    public abstract void mo3940a(C0908i iVar);

    /* renamed from: b */
    public abstract C0905b mo3941b();

    /* renamed from: c */
    public abstract void mo3942c(C0908i iVar);
}
