package androidx.lifecycle;

/* renamed from: androidx.lifecycle.g */
public abstract class C0906g {
}
