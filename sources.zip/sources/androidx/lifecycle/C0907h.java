package androidx.lifecycle;

import androidx.lifecycle.C0903f;

/* renamed from: androidx.lifecycle.h */
public interface C0907h extends C0908i {
    /* renamed from: c */
    void mo360c(C0909j jVar, C0903f.C0904a aVar);
}
