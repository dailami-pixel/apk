package androidx.lifecycle;

/* renamed from: androidx.lifecycle.i */
public interface C0908i {
}
