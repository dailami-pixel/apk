package androidx.lifecycle;

/* renamed from: androidx.lifecycle.j */
public interface C0909j {
    /* renamed from: G */
    C0903f mo341G();
}
