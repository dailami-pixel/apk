package androidx.lifecycle;

import androidx.lifecycle.C0903f;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import p098d.p107b.p108a.p109a.C4602a;
import p098d.p107b.p108a.p110b.C4607a;
import p098d.p107b.p108a.p110b.C4608b;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.lifecycle.k */
public class C0910k extends C0903f {

    /* renamed from: a */
    private C4607a<C0908i, C0911a> f3721a = new C4607a<>();

    /* renamed from: b */
    private C0903f.C0905b f3722b;

    /* renamed from: c */
    private final WeakReference<C0909j> f3723c;

    /* renamed from: d */
    private int f3724d = 0;

    /* renamed from: e */
    private boolean f3725e = false;

    /* renamed from: f */
    private boolean f3726f = false;

    /* renamed from: g */
    private ArrayList<C0903f.C0905b> f3727g = new ArrayList<>();

    /* renamed from: h */
    private final boolean f3728h;

    /* renamed from: androidx.lifecycle.k$a */
    static class C0911a {

        /* renamed from: a */
        C0903f.C0905b f3729a;

        /* renamed from: b */
        C0907h f3730b;

        C0911a(C0908i iVar, C0903f.C0905b bVar) {
            this.f3730b = C0913m.m3868d(iVar);
            this.f3729a = bVar;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo3947a(C0909j jVar, C0903f.C0904a aVar) {
            C0903f.C0905b a = aVar.mo3943a();
            this.f3729a = C0910k.m3853h(this.f3729a, a);
            this.f3730b.mo360c(jVar, aVar);
            this.f3729a = a;
        }
    }

    public C0910k(C0909j jVar) {
        this.f3723c = new WeakReference<>(jVar);
        this.f3722b = C0903f.C0905b.INITIALIZED;
        this.f3728h = true;
    }

    /* renamed from: d */
    private C0903f.C0905b m3851d(C0908i iVar) {
        Map.Entry<C0908i, C0911a> j = this.f3721a.mo21289j(iVar);
        C0903f.C0905b bVar = null;
        C0903f.C0905b bVar2 = j != null ? j.getValue().f3729a : null;
        if (!this.f3727g.isEmpty()) {
            ArrayList<C0903f.C0905b> arrayList = this.f3727g;
            bVar = arrayList.get(arrayList.size() - 1);
        }
        return m3853h(m3853h(this.f3722b, bVar2), bVar);
    }

    /* renamed from: e */
    private void m3852e(String str) {
        if (this.f3728h && !C4602a.m16557d().mo21282b()) {
            throw new IllegalStateException(C4924a.m17909x("Method ", str, " must be called on the main thread"));
        }
    }

    /* renamed from: h */
    static C0903f.C0905b m3853h(C0903f.C0905b bVar, C0903f.C0905b bVar2) {
        return (bVar2 == null || bVar2.compareTo(bVar) >= 0) ? bVar : bVar2;
    }

    /* renamed from: i */
    private void m3854i(C0903f.C0905b bVar) {
        if (this.f3722b != bVar) {
            this.f3722b = bVar;
            if (this.f3725e || this.f3724d != 0) {
                this.f3726f = true;
                return;
            }
            this.f3725e = true;
            m3856l();
            this.f3725e = false;
        }
    }

    /* renamed from: j */
    private void m3855j() {
        ArrayList<C0903f.C0905b> arrayList = this.f3727g;
        arrayList.remove(arrayList.size() - 1);
    }

    /* renamed from: l */
    private void m3856l() {
        C0903f.C0905b bVar;
        C0909j jVar = (C0909j) this.f3723c.get();
        if (jVar != null) {
            while (true) {
                boolean z = true;
                if (!(this.f3721a.size() == 0 || (this.f3721a.mo21290a().getValue().f3729a == (bVar = this.f3721a.mo21293e().getValue().f3729a) && this.f3722b == bVar))) {
                    z = false;
                }
                this.f3726f = false;
                if (!z) {
                    if (this.f3722b.compareTo(this.f3721a.mo21290a().getValue().f3729a) < 0) {
                        Iterator<Map.Entry<C0908i, C0911a>> descendingIterator = this.f3721a.descendingIterator();
                        while (descendingIterator.hasNext() && !this.f3726f) {
                            Map.Entry next = descendingIterator.next();
                            C0911a aVar = (C0911a) next.getValue();
                            while (aVar.f3729a.compareTo(this.f3722b) > 0 && !this.f3726f && this.f3721a.contains(next.getKey())) {
                                int ordinal = aVar.f3729a.ordinal();
                                C0903f.C0904a aVar2 = ordinal != 2 ? ordinal != 3 ? ordinal != 4 ? null : C0903f.C0904a.ON_PAUSE : C0903f.C0904a.ON_STOP : C0903f.C0904a.ON_DESTROY;
                                if (aVar2 != null) {
                                    this.f3727g.add(aVar2.mo3943a());
                                    aVar.mo3947a(jVar, aVar2);
                                    m3855j();
                                } else {
                                    StringBuilder P = C4924a.m17863P("no event down from ");
                                    P.append(aVar.f3729a);
                                    throw new IllegalStateException(P.toString());
                                }
                            }
                        }
                    }
                    Map.Entry<C0908i, C0911a> e = this.f3721a.mo21293e();
                    if (!this.f3726f && e != null && this.f3722b.compareTo(e.getValue().f3729a) > 0) {
                        C4608b<K, V>.d c = this.f3721a.mo21291c();
                        while (c.hasNext() && !this.f3726f) {
                            Map.Entry entry = (Map.Entry) c.next();
                            C0911a aVar3 = (C0911a) entry.getValue();
                            while (aVar3.f3729a.compareTo(this.f3722b) < 0 && !this.f3726f && this.f3721a.contains(entry.getKey())) {
                                this.f3727g.add(aVar3.f3729a);
                                C0903f.C0904a b = C0903f.C0904a.m3847b(aVar3.f3729a);
                                if (b != null) {
                                    aVar3.mo3947a(jVar, b);
                                    m3855j();
                                } else {
                                    StringBuilder P2 = C4924a.m17863P("no event up from ");
                                    P2.append(aVar3.f3729a);
                                    throw new IllegalStateException(P2.toString());
                                }
                            }
                        }
                    }
                } else {
                    return;
                }
            }
        } else {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
        }
    }

    /* renamed from: a */
    public void mo3940a(C0908i iVar) {
        C0909j jVar;
        m3852e("addObserver");
        C0903f.C0905b bVar = this.f3722b;
        C0903f.C0905b bVar2 = C0903f.C0905b.DESTROYED;
        if (bVar != bVar2) {
            bVar2 = C0903f.C0905b.INITIALIZED;
        }
        C0911a aVar = new C0911a(iVar, bVar2);
        if (this.f3721a.mo21287g(iVar, aVar) == null && (jVar = (C0909j) this.f3723c.get()) != null) {
            boolean z = this.f3724d != 0 || this.f3725e;
            C0903f.C0905b d = m3851d(iVar);
            this.f3724d++;
            while (aVar.f3729a.compareTo(d) < 0 && this.f3721a.contains(iVar)) {
                this.f3727g.add(aVar.f3729a);
                C0903f.C0904a b = C0903f.C0904a.m3847b(aVar.f3729a);
                if (b != null) {
                    aVar.mo3947a(jVar, b);
                    m3855j();
                    d = m3851d(iVar);
                } else {
                    StringBuilder P = C4924a.m17863P("no event up from ");
                    P.append(aVar.f3729a);
                    throw new IllegalStateException(P.toString());
                }
            }
            if (!z) {
                m3856l();
            }
            this.f3724d--;
        }
    }

    /* renamed from: b */
    public C0903f.C0905b mo3941b() {
        return this.f3722b;
    }

    /* renamed from: c */
    public void mo3942c(C0908i iVar) {
        m3852e("removeObserver");
        this.f3721a.mo21288h(iVar);
    }

    /* renamed from: f */
    public void mo3944f(C0903f.C0904a aVar) {
        m3852e("handleLifecycleEvent");
        m3854i(aVar.mo3943a());
    }

    @Deprecated
    /* renamed from: g */
    public void mo3945g(C0903f.C0905b bVar) {
        m3852e("markState");
        m3852e("setCurrentState");
        m3854i(bVar);
    }

    /* renamed from: k */
    public void mo3946k(C0903f.C0905b bVar) {
        m3852e("setCurrentState");
        m3854i(bVar);
    }
}
