package androidx.lifecycle;

@Deprecated
/* renamed from: androidx.lifecycle.l */
public interface C0912l extends C0909j {
    /* renamed from: G */
    C0910k mo341G();
}
