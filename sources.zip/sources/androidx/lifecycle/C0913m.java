package androidx.lifecycle;

import com.appsflyer.oaid.BuildConfig;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: androidx.lifecycle.m */
public class C0913m {

    /* renamed from: a */
    private static Map<Class<?>, Integer> f3731a = new HashMap();

    /* renamed from: b */
    private static Map<Class<?>, List<Constructor<? extends C0902e>>> f3732b = new HashMap();

    /* renamed from: a */
    private static C0902e m3865a(Constructor<? extends C0902e> constructor, Object obj) {
        try {
            return (C0902e) constructor.newInstance(new Object[]{obj});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e2) {
            throw new RuntimeException(e2);
        } catch (InvocationTargetException e3) {
            throw new RuntimeException(e3);
        }
    }

    /* renamed from: b */
    public static String m3866b(String str) {
        return str.replace(".", "_") + "_LifecycleAdapter";
    }

    /* renamed from: c */
    private static int m3867c(Class<?> cls) {
        Constructor<?> constructor;
        Map<Class<?>, List<Constructor<? extends C0902e>>> map;
        Integer num = f3731a.get(cls);
        if (num != null) {
            return num.intValue();
        }
        Class<C0908i> cls2 = C0908i.class;
        int i = 1;
        if (cls.getCanonicalName() != null) {
            List<?> list = null;
            try {
                Package packageR = cls.getPackage();
                String canonicalName = cls.getCanonicalName();
                String name = packageR != null ? packageR.getName() : BuildConfig.FLAVOR;
                if (!name.isEmpty()) {
                    canonicalName = canonicalName.substring(name.length() + 1);
                }
                String b = m3866b(canonicalName);
                if (!name.isEmpty()) {
                    b = name + "." + b;
                }
                constructor = Class.forName(b).getDeclaredConstructor(new Class[]{cls});
                if (!constructor.isAccessible()) {
                    constructor.setAccessible(true);
                }
            } catch (ClassNotFoundException unused) {
                constructor = null;
            } catch (NoSuchMethodException e) {
                throw new RuntimeException(e);
            }
            if (constructor != null) {
                map = f3732b;
                list = Collections.singletonList(constructor);
            } else if (!C0896a.f3708a.mo3929c(cls)) {
                Class<? super Object> superclass = cls.getSuperclass();
                if (superclass != null && cls2.isAssignableFrom(superclass)) {
                    if (m3867c(superclass) != 1) {
                        list = new ArrayList<>(f3732b.get(superclass));
                    }
                }
                Class[] interfaces = cls.getInterfaces();
                int length = interfaces.length;
                int i2 = 0;
                while (true) {
                    if (i2 < length) {
                        Class cls3 = interfaces[i2];
                        if (cls3 != null && cls2.isAssignableFrom(cls3)) {
                            if (m3867c(cls3) == 1) {
                                break;
                            }
                            if (list == null) {
                                list = new ArrayList<>();
                            }
                            list.addAll(f3732b.get(cls3));
                        }
                        i2++;
                    } else if (list != null) {
                        map = f3732b;
                    }
                }
            }
            map.put(cls, list);
            i = 2;
        }
        f3731a.put(cls, Integer.valueOf(i));
        return i;
    }

    /* renamed from: d */
    static C0907h m3868d(Object obj) {
        boolean z = obj instanceof C0907h;
        boolean z2 = obj instanceof C0901d;
        if (z && z2) {
            return new FullLifecycleObserverAdapter((C0901d) obj, (C0907h) obj);
        }
        if (z2) {
            return new FullLifecycleObserverAdapter((C0901d) obj, (C0907h) null);
        }
        if (z) {
            return (C0907h) obj;
        }
        Class<?> cls = obj.getClass();
        if (m3867c(cls) != 2) {
            return new ReflectiveGenericLifecycleObserver(obj);
        }
        List list = f3732b.get(cls);
        if (list.size() == 1) {
            return new SingleGeneratedAdapterObserver(m3865a((Constructor) list.get(0), obj));
        }
        C0902e[] eVarArr = new C0902e[list.size()];
        for (int i = 0; i < list.size(); i++) {
            eVarArr[i] = m3865a((Constructor) list.get(i), obj);
        }
        return new CompositeGeneratedAdaptersObserver(eVarArr);
    }
}
