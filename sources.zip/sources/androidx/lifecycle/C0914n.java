package androidx.lifecycle;

import java.util.HashMap;

/* renamed from: androidx.lifecycle.n */
public class C0914n {
    public C0914n() {
        new HashMap();
    }
}
