package androidx.lifecycle;

/* renamed from: androidx.lifecycle.o */
public class C0915o<T> extends LiveData<T> {
    /* renamed from: i */
    public void mo3923i(T t) {
        super.mo3923i(t);
    }
}
