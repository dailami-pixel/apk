package androidx.lifecycle;

/* renamed from: androidx.lifecycle.p */
public interface C0916p<T> {
    /* renamed from: a */
    void mo2903a(T t);
}
