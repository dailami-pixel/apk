package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Build;
import android.os.Bundle;
import androidx.lifecycle.C0903f;

/* renamed from: androidx.lifecycle.r */
public class C0918r extends Fragment {

    /* renamed from: androidx.lifecycle.r$a */
    static class C0919a implements Application.ActivityLifecycleCallbacks {
        C0919a() {
        }

        static void registerIn(Activity activity) {
            activity.registerActivityLifecycleCallbacks(new C0919a());
        }

        public void onActivityCreated(Activity activity, Bundle bundle) {
        }

        public void onActivityDestroyed(Activity activity) {
        }

        public void onActivityPaused(Activity activity) {
        }

        public void onActivityPostCreated(Activity activity, Bundle bundle) {
            C0918r.m3871a(activity, C0903f.C0904a.ON_CREATE);
        }

        public void onActivityPostResumed(Activity activity) {
            C0918r.m3871a(activity, C0903f.C0904a.ON_RESUME);
        }

        public void onActivityPostStarted(Activity activity) {
            C0918r.m3871a(activity, C0903f.C0904a.ON_START);
        }

        public void onActivityPreDestroyed(Activity activity) {
            C0918r.m3871a(activity, C0903f.C0904a.ON_DESTROY);
        }

        public void onActivityPrePaused(Activity activity) {
            C0918r.m3871a(activity, C0903f.C0904a.ON_PAUSE);
        }

        public void onActivityPreStopped(Activity activity) {
            C0918r.m3871a(activity, C0903f.C0904a.ON_STOP);
        }

        public void onActivityResumed(Activity activity) {
        }

        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        }

        public void onActivityStarted(Activity activity) {
        }

        public void onActivityStopped(Activity activity) {
        }
    }

    /* renamed from: a */
    static void m3871a(Activity activity, C0903f.C0904a aVar) {
        if (activity instanceof C0912l) {
            ((C0912l) activity).mo341G().mo3944f(aVar);
        } else if (activity instanceof C0909j) {
            C0903f G = ((C0909j) activity).mo341G();
            if (G instanceof C0910k) {
                ((C0910k) G).mo3944f(aVar);
            }
        }
    }

    /* renamed from: b */
    private void m3872b(C0903f.C0904a aVar) {
        if (Build.VERSION.SDK_INT < 29) {
            m3871a(getActivity(), aVar);
        }
    }

    /* renamed from: c */
    public static void m3873c(Activity activity) {
        if (Build.VERSION.SDK_INT >= 29) {
            C0919a.registerIn(activity);
        }
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new C0918r(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        m3872b(C0903f.C0904a.ON_CREATE);
    }

    public void onDestroy() {
        super.onDestroy();
        m3872b(C0903f.C0904a.ON_DESTROY);
    }

    public void onPause() {
        super.onPause();
        m3872b(C0903f.C0904a.ON_PAUSE);
    }

    public void onResume() {
        super.onResume();
        m3872b(C0903f.C0904a.ON_RESUME);
    }

    public void onStart() {
        super.onStart();
        m3872b(C0903f.C0904a.ON_START);
    }

    public void onStop() {
        super.onStop();
        m3872b(C0903f.C0904a.ON_STOP);
    }
}
