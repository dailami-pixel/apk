package androidx.lifecycle;

import java.io.Closeable;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/* renamed from: androidx.lifecycle.s */
public abstract class C0920s {

    /* renamed from: a */
    private final Map<String, Object> f3733a = new HashMap();

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public final void mo3968a() {
        Map<String, Object> map = this.f3733a;
        if (map != null) {
            synchronized (map) {
                for (Object next : this.f3733a.values()) {
                    if (next instanceof Closeable) {
                        try {
                            ((Closeable) next).close();
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            }
        }
        mo3034c();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public <T> T mo3969b(String str) {
        T t;
        Map<String, Object> map = this.f3733a;
        if (map == null) {
            return null;
        }
        synchronized (map) {
            t = this.f3733a.get(str);
        }
        return t;
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public void mo3034c() {
    }
}
