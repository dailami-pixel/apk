package androidx.lifecycle;

import java.util.Objects;
import p165e.p166a.p167a.p168a.C4924a;

/* renamed from: androidx.lifecycle.t */
public class C0921t {

    /* renamed from: a */
    private final C0922a f3734a;

    /* renamed from: b */
    private final C0925u f3735b;

    /* renamed from: androidx.lifecycle.t$a */
    public interface C0922a {
        /* renamed from: a */
        <T extends C0920s> T mo3047a(Class<T> cls);
    }

    /* renamed from: androidx.lifecycle.t$b */
    static abstract class C0923b extends C0924c implements C0922a {
        C0923b() {
        }

        /* renamed from: a */
        public <T extends C0920s> T mo3047a(Class<T> cls) {
            throw new UnsupportedOperationException("create(String, Class<?>) must be called on implementaions of KeyedFactory");
        }

        /* renamed from: b */
        public abstract <T extends C0920s> T mo3971b(String str, Class<T> cls);
    }

    /* renamed from: androidx.lifecycle.t$c */
    static class C0924c {
        C0924c() {
        }
    }

    public C0921t(C0925u uVar, C0922a aVar) {
        this.f3734a = aVar;
        this.f3735b = uVar;
    }

    /* renamed from: a */
    public <T extends C0920s> T mo3970a(Class<T> cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            String v = C4924a.m17907v("androidx.lifecycle.ViewModelProvider.DefaultKey:", canonicalName);
            T b = this.f3735b.mo3973b(v);
            if (cls.isInstance(b)) {
                C0922a aVar = this.f3734a;
                if (!(aVar instanceof C0924c)) {
                    return b;
                }
                Objects.requireNonNull((C0924c) aVar);
                return b;
            }
            C0922a aVar2 = this.f3734a;
            T b2 = aVar2 instanceof C0923b ? ((C0923b) aVar2).mo3971b(v, cls) : aVar2.mo3047a(cls);
            this.f3735b.mo3975d(v, b2);
            return b2;
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }
}
