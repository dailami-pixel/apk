package androidx.lifecycle;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/* renamed from: androidx.lifecycle.u */
public class C0925u {

    /* renamed from: a */
    private final HashMap<String, C0920s> f3736a = new HashMap<>();

    /* renamed from: a */
    public final void mo3972a() {
        for (C0920s a : this.f3736a.values()) {
            a.mo3968a();
        }
        this.f3736a.clear();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public final C0920s mo3973b(String str) {
        return this.f3736a.get(str);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public Set<String> mo3974c() {
        return new HashSet(this.f3736a.keySet());
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public final void mo3975d(String str, C0920s sVar) {
        C0920s put = this.f3736a.put(str, sVar);
        if (put != null) {
            put.mo3034c();
        }
    }
}
