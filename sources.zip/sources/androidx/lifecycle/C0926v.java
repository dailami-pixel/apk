package androidx.lifecycle;

/* renamed from: androidx.lifecycle.v */
public interface C0926v {
    /* renamed from: h1 */
    C0925u mo345h1();
}
