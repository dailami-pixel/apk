package androidx.lifecycle;

import androidx.lifecycle.C0903f;

class CompositeGeneratedAdaptersObserver implements C0907h {

    /* renamed from: a */
    private final C0902e[] f3683a;

    CompositeGeneratedAdaptersObserver(C0902e[] eVarArr) {
        this.f3683a = eVarArr;
    }

    /* renamed from: c */
    public void mo360c(C0909j jVar, C0903f.C0904a aVar) {
        C0914n nVar = new C0914n();
        for (C0902e a : this.f3683a) {
            a.mo3939a(jVar, aVar, false, nVar);
        }
        for (C0902e a2 : this.f3683a) {
            a2.mo3939a(jVar, aVar, true, nVar);
        }
    }
}
