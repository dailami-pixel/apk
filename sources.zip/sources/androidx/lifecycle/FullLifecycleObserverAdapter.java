package androidx.lifecycle;

import androidx.lifecycle.C0903f;

class FullLifecycleObserverAdapter implements C0907h {

    /* renamed from: a */
    private final C0901d f3684a;

    /* renamed from: b */
    private final C0907h f3685b;

    FullLifecycleObserverAdapter(C0901d dVar, C0907h hVar) {
        this.f3684a = dVar;
        this.f3685b = hVar;
    }

    /* renamed from: c */
    public void mo360c(C0909j jVar, C0903f.C0904a aVar) {
        switch (aVar.ordinal()) {
            case 0:
                this.f3684a.mo3934b(jVar);
                break;
            case 1:
                this.f3684a.mo3938g(jVar);
                break;
            case 2:
                this.f3684a.mo3933a(jVar);
                break;
            case 3:
                this.f3684a.mo3935d(jVar);
                break;
            case 4:
                this.f3684a.mo3936e(jVar);
                break;
            case 5:
                this.f3684a.mo3937f(jVar);
                break;
            case 6:
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
        }
        C0907h hVar = this.f3685b;
        if (hVar != null) {
            hVar.mo360c(jVar, aVar);
        }
    }
}
