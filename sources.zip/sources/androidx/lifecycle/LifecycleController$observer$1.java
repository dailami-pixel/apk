package androidx.lifecycle;

import androidx.lifecycle.C0903f;
import java.util.Objects;
import kotlin.Metadata;
import kotlin.jvm.internal.C12358j;

@Metadata(mo39552bv = {1, 0, 3}, mo39553d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0001\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u0002H\n¢\u0006\u0004\b\u0005\u0010\u0006"}, mo39554d2 = {"Landroidx/lifecycle/j;", "source", "Landroidx/lifecycle/f$a;", "<anonymous parameter 1>", "Lkotlin/n;", "c", "(Landroidx/lifecycle/j;Landroidx/lifecycle/f$a;)V"}, mo39555k = 3, mo39556mv = {1, 4, 1})
final class LifecycleController$observer$1 implements C0907h {
    /* renamed from: c */
    public final void mo360c(C0909j jVar, C0903f.C0904a aVar) {
        C12358j.m34085e(jVar, "source");
        C12358j.m34085e(aVar, "<anonymous parameter 1>");
        C0903f G = jVar.mo341G();
        C12358j.m34084d(G, "source.lifecycle");
        if (G.mo3941b() == C0903f.C0905b.DESTROYED) {
            throw null;
        }
        C12358j.m34084d(jVar.mo341G(), "source.lifecycle");
        Objects.requireNonNull((Object) null);
        throw null;
    }
}
