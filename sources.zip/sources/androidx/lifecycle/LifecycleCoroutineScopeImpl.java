package androidx.lifecycle;

import androidx.lifecycle.C0903f;
import kotlin.Metadata;
import kotlin.jvm.internal.C12358j;

@Metadata(mo39552bv = {1, 0, 3}, mo39553d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0000\u0018\u00002\u00020\u00012\u00020\u0002J\u001f\u0010\b\u001a\u00020\u00072\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\b\u0010\t¨\u0006\n"}, mo39554d2 = {"Landroidx/lifecycle/LifecycleCoroutineScopeImpl;", "Landroidx/lifecycle/g;", "Landroidx/lifecycle/h;", "Landroidx/lifecycle/j;", "source", "Landroidx/lifecycle/f$a;", "event", "Lkotlin/n;", "c", "(Landroidx/lifecycle/j;Landroidx/lifecycle/f$a;)V", "lifecycle-runtime-ktx_release"}, mo39555k = 1, mo39556mv = {1, 4, 1})
public final class LifecycleCoroutineScopeImpl extends C0906g implements C0907h {
    /* renamed from: c */
    public void mo360c(C0909j jVar, C0903f.C0904a aVar) {
        C12358j.m34085e(jVar, "source");
        C12358j.m34085e(aVar, "event");
        throw null;
    }
}
