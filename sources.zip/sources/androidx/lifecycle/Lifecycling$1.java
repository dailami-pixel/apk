package androidx.lifecycle;

import androidx.lifecycle.C0903f;

class Lifecycling$1 implements C0907h {
    /* renamed from: c */
    public void mo360c(C0909j jVar, C0903f.C0904a aVar) {
        throw null;
    }
}
