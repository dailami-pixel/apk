package androidx.lifecycle;

import androidx.lifecycle.C0903f;
import java.util.Map;
import p098d.p107b.p108a.p109a.C4602a;
import p098d.p107b.p108a.p110b.C4608b;
import p165e.p166a.p167a.p168a.C4924a;

public abstract class LiveData<T> {

    /* renamed from: a */
    static final Object f3686a = new Object();

    /* renamed from: b */
    final Object f3687b = new Object();

    /* renamed from: c */
    private C4608b<C0916p<? super T>, LiveData<T>.C1430b> f3688c = new C4608b<>();

    /* renamed from: d */
    int f3689d = 0;

    /* renamed from: e */
    private boolean f3690e;

    /* renamed from: f */
    private volatile Object f3691f;

    /* renamed from: g */
    volatile Object f3692g;

    /* renamed from: h */
    private int f3693h;

    /* renamed from: i */
    private boolean f3694i;

    /* renamed from: j */
    private boolean f3695j;

    class LifecycleBoundObserver extends LiveData<T>.C1430b implements C0907h {

        /* renamed from: e */
        final C0909j f3696e;

        /* renamed from: f */
        final /* synthetic */ LiveData f3697f;

        /* renamed from: c */
        public void mo360c(C0909j jVar, C0903f.C0904a aVar) {
            C0903f.C0905b b = this.f3696e.mo341G().mo3941b();
            if (b == C0903f.C0905b.DESTROYED) {
                this.f3697f.mo3922h(this.f3698a);
                return;
            }
            C0903f.C0905b bVar = null;
            while (bVar != b) {
                mo3926h(mo3925j());
                bVar = b;
                b = this.f3696e.mo341G().mo3941b();
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: i */
        public void mo3924i() {
            this.f3696e.mo341G().mo3942c(this);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: j */
        public boolean mo3925j() {
            return this.f3696e.mo341G().mo3941b().compareTo(C0903f.C0905b.STARTED) >= 0;
        }
    }

    /* renamed from: androidx.lifecycle.LiveData$a */
    private class C0891a extends LiveData<T>.C1430b {
        C0891a(LiveData liveData, C0916p<? super T> pVar) {
            super(pVar);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: j */
        public boolean mo3925j() {
            return true;
        }
    }

    /* renamed from: androidx.lifecycle.LiveData$b */
    private abstract class C0892b {

        /* renamed from: a */
        final C0916p<? super T> f3698a;

        /* renamed from: b */
        boolean f3699b;

        /* renamed from: c */
        int f3700c = -1;

        C0892b(C0916p<? super T> pVar) {
            this.f3698a = pVar;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: h */
        public void mo3926h(boolean z) {
            if (z != this.f3699b) {
                this.f3699b = z;
                LiveData.this.mo3917b(z ? 1 : -1);
                if (this.f3699b) {
                    LiveData.this.mo3918d(this);
                }
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: i */
        public void mo3924i() {
        }

        /* access modifiers changed from: package-private */
        /* renamed from: j */
        public abstract boolean mo3925j();
    }

    public LiveData() {
        Object obj = f3686a;
        this.f3692g = obj;
        this.f3691f = obj;
        this.f3693h = -1;
    }

    /* renamed from: a */
    static void m3803a(String str) {
        if (!C4602a.m16557d().mo21282b()) {
            throw new IllegalStateException(C4924a.m17909x("Cannot invoke ", str, " on a background thread"));
        }
    }

    /* renamed from: c */
    private void m3804c(LiveData<T>.C1430b bVar) {
        if (bVar.f3699b) {
            if (!bVar.mo3925j()) {
                bVar.mo3926h(false);
                return;
            }
            int i = bVar.f3700c;
            int i2 = this.f3693h;
            if (i < i2) {
                bVar.f3700c = i2;
                bVar.f3698a.mo2903a(this.f3691f);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo3917b(int i) {
        int i2 = this.f3689d;
        this.f3689d = i + i2;
        if (!this.f3690e) {
            this.f3690e = true;
            while (true) {
                try {
                    int i3 = this.f3689d;
                    if (i2 != i3) {
                        boolean z = i2 == 0 && i3 > 0;
                        boolean z2 = i2 > 0 && i3 == 0;
                        if (z) {
                            mo3920f();
                        } else if (z2) {
                            mo3921g();
                        }
                        i2 = i3;
                    } else {
                        return;
                    }
                } finally {
                    this.f3690e = false;
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public void mo3918d(LiveData<T>.C1430b bVar) {
        if (this.f3694i) {
            this.f3695j = true;
            return;
        }
        this.f3694i = true;
        do {
            this.f3695j = false;
            if (bVar == null) {
                C4608b<K, V>.d c = this.f3688c.mo21291c();
                while (c.hasNext()) {
                    m3804c((C0892b) ((Map.Entry) c.next()).getValue());
                    if (this.f3695j) {
                        break;
                    }
                }
            } else {
                m3804c(bVar);
                bVar = null;
            }
        } while (this.f3695j);
        this.f3694i = false;
    }

    /* renamed from: e */
    public void mo3919e(C0916p<? super T> pVar) {
        m3803a("observeForever");
        C0891a aVar = new C0891a(this, pVar);
        C0892b g = this.f3688c.mo21287g(pVar, aVar);
        if (g instanceof LifecycleBoundObserver) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        } else if (g == null) {
            aVar.mo3926h(true);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public void mo3920f() {
    }

    /* access modifiers changed from: protected */
    /* renamed from: g */
    public void mo3921g() {
    }

    /* renamed from: h */
    public void mo3922h(C0916p<? super T> pVar) {
        m3803a("removeObserver");
        C0892b h = this.f3688c.mo21288h(pVar);
        if (h != null) {
            h.mo3924i();
            h.mo3926h(false);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: i */
    public void mo3923i(T t) {
        m3803a("setValue");
        this.f3693h++;
        this.f3691f = t;
        mo3918d((LiveData<T>.C1430b) null);
    }
}
